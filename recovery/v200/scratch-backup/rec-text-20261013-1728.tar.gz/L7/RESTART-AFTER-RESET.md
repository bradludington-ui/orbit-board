# Restart after the usage-limit reset (written 4:48 PM ET, 13 Oct; reset expected about 7:31 PM ET)

Brad, about 4:45 PM ET: "Let's prepare for a usage timeout. We're at 78% with 2hrs 46mins to go. Prepare accordingly so we
don't have to rerun anything."

## What was done at about 4:46 PM ET
- Stopped (their agents were early or long-running; all their work is on disk and resumes from it):
  mathA wf_5b40c662-ed2 (u10 round-3 reviews), saveB wf_db4b1829-a41 (adopt round-2 tests, hold fix 1),
  u44g wf_4398bdbd-cd2 (u44 builder), codexB wf_6a154929-f05 (u41u42 builder, u40 round-1 tests). Earlier (4:42 PM ET):
  mathU28 wf_92019e7a-ad5 (round-3 reviews). No leftover processes (checked by command line and by working directory).
- Kept, because their agents were mid-to-late and can finish: saveA wf_b5e73cec-5e2 (u20u30 r2 tests, u19 r3 money),
  codex wf_92077d4c-3db (cycreg fix 3), mathU9 wf_2930765d-ee9 (u9 fix 3 with U43), codexYR wf_b4198302-8c5 (yearsel r3
  tests, regtext r3 tests). A background watcher (rec/L7/watch-events.sh) wakes the lead on each journal event; each
  group is stopped as soon as its current agents finish, so no agent is left mid-step when the limit hits.
- fixes-state.js: resume notes now name the 4:46 PM ET stop; RESUME_D covers u37, u40, u41u42 and u44; new groups
  mathU10 ['u10'] and codexC ['cycreg'] (u9 runs as mathU9, yearsel+regtext as codexYR). Launches use the stop-on-failure
  logic (a reviewer or fixer that returns nothing stops its track instead of burning rounds).

## Usage budget (the binding limit)
78% of a 5-hour window was used in about 2 h 14 min with about 13 agents: about 0.58% a minute. A full window therefore
sustains only about 7-8 agents at once. Run at most 8 agents (4 groups x 2) at a time; add a group only when one ends.

## After the reset, in this order (each: rebuild state, then launch fixes-state.js with resume:true)
State for the already-stopped groups is precomputed in rec/L7/restart/args-<group>.json (pass its contents as args).
For a group stopped later, rebuild first:
  python3 -I rec/L7/wfstate.py <group> <journals...> > rec/L7/restart/state-<group>.json
  python3 -I rec/L7/compact.py rec/L7/restart/state-<group>.json > rec/L7/restart/cstate-<group>.json
Journals per group (append the run that was still going if it ran past this note):
  saveA   : /root/.claude/projects/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/subagents/workflows/{wf_12f3bad9-2bc,wf_99519359-797,wf_5500090d-4a1,wf_b5e73cec-5e2}/journal.jsonl
  saveB   : /root/.claude/projects/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/subagents/workflows/{wf_12f3bad9-2bc,wf_99519359-797,wf_7d88dfb5-7c0,wf_db4b1829-a41}/journal.jsonl
  mathU10 : /root/.claude/projects/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/subagents/workflows/{wf_041e5055-bb1,wf_534cd8b6-9c3,wf_c08338b2-f2f,wf_5b40c662-ed2}/journal.jsonl
  mathU9  : /root/.claude/projects/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/subagents/workflows/{wf_041e5055-bb1,wf_534cd8b6-9c3,wf_c08338b2-f2f,wf_5b40c662-ed2,wf_2930765d-ee9}/journal.jsonl
  codexC  : /root/.claude/projects/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/subagents/workflows/{wf_66312e0c-108,wf_f45a7fab-957,wf_92077d4c-3db}/journal.jsonl
  codexYR : /root/.claude/projects/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/subagents/workflows/{wf_66312e0c-108,wf_f45a7fab-957,wf_92077d4c-3db,wf_b4198302-8c5}/journal.jsonl
  codexB  : /root/.claude/projects/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/subagents/workflows/{wf_ce8b2b90-1a7,wf_6a154929-f05}/journal.jsonl
  u44g    : /root/.claude/projects/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/subagents/workflows/wf_4398bdbd-cd2/journal.jsonl
  mathU28 : /root/.claude/projects/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/subagents/workflows/{wf_041e5055-bb1,wf_534cd8b6-9c3,wf_36500498-c4d,wf_92019e7a-ad5}/journal.jsonl
Priority (release blockers first; at most 8 agents):
  wave 1: codexB (u37 round 1 + u40 round 1; u41u42 builder queued behind them), u44g (u44 builder), mathU10 (u10
          round 3), saveB (adopt round 2, u18 round 2, hold fix 1).
  wave 2, as wave-1 groups end: whichever of saveA, codexC, mathU9, codexYR still has steps; then mathU28 (only after
          Brad's answer on the font setting, Codex C2 memo 3).
  Then: the dry run's exports and locked-view reviewers on the newer copies (rec/L7/INTEGRATION-NOTES.md item 10).
Before each launch: no process of that group's agents is running (check pids.txt entries by command line and cwd).

## Commits
A track clean in both reviews of its last round is committed locally at once (rec/L7/INTEGRATION-NOTES.md for the
overlap rules), and pushed only after its commit check passes (rec/L8/commit-check.js, one agent; counts toward the 8).

## U20/U30 (clean in round 2 at 5:07 PM ET): committed LOCALLY, not pushed (5:10 PM ET)
- Local branch pending/v200-fixes in /home/user/orbit-board: ddc1d1b (U20), 1bba980 (U30), on 6060ee7. Bundle (restore
  verified): rec/L8/pending-v200-fixes-1bba980.bundle. Blobs match the track's: U20 board 83b87782, audit-import d7d41c6a,
  mutate 6b4c83d6; U30 board 84cf2bf4, audit-import 3a34d922, mutate d174d05d.
- After the reset: (1) rebase pending/v200-fixes onto the then tip of claude/v200-fixes-wip (records only between; no
  product-file conflict expected); (2) run rec/L8/commit-check.js with both commits (their NEW shas; one agent each);
  (3) when both pass, fast-forward claude/v200-fixes-wip to them, append the ledger texts from
  rec/L6/u20u30/drafts/NEXT-VERSION-U20-U30-fr.txt (UNRESOLVED-LEDGER section) with the final shas and times, and push.
  Until then do not push anything that contains these commits.

## Update 5:17 PM ET: four commits now pending (U20, U30, U34, U36); YEARSEL and REGTEXT are done
- pending/v200-fixes: ddc1d1b U20, 1bba980 U30, a817068 U34 (one commit = build + both fix rounds; board 81d3c493 on
  U30's), 6934613 U36 (board 304d8d3d). Bundle (restore verified): rec/L8/pending-v200-fixes-6934613.bundle.
- After the reset: rebase onto the then tip, run rec/L8/commit-check.js on all four (4 agents, at the head of wave 1),
  then fast-forward, append each ledger text (U20/U30: rec/L6/u20u30/drafts/NEXT-VERSION-U20-U30-fr.txt; U34:
  rec/L6/yearsel/drafts/LEDGER-U34-append.md; U36: rec/L6/regtext/drafts/LEDGER-append.md) with the final shas, and push.
- codexYR (yearsel, regtext) is FINISHED; do not relaunch it.
- U34 integration note: its audit-recon block never awaits settleBoards() between shapes, so boards build up (a 768 MB
  heap ran out). If the final-tree audit-recon runs short of memory, add the awaits (tests only) as a follow-up.
- U49 (locked-view funds-flow edits counted): added to U10's brief in fixes-state.js; U10's next fix round takes it.

## Update 5:28 PM ET: every group stopped at a clean point; nothing running
- 5:25 PM ET: codex stopped (cycreg fix round 3 done; resumes at its round-4 reviews) -> group codexC, args-codexC.json.
- 5:27 PM ET: saveA stopped (u19 round-3 tests: 1 must-fix; its fix round 3 was seconds old) -> group u19g (u19 ONLY),
  args-u19g.json. NEVER relaunch saveA or codexYR: u20u30, yearsel and regtext are done and committed locally.
- Precomputed args for every group to relaunch: rec/L7/restart/args-{codexB,u44g,mathU10,saveB,mathU9,codexC,u19g,mathU28}.json
- Wave 1 after the reset (about 8 agents): the commit check on the four pending commits (4 agents), then codexB, u44g,
  mathU10, saveB as slots free; wave 2: mathU9, codexC, u19g; mathU28 after Brad's font answer.
