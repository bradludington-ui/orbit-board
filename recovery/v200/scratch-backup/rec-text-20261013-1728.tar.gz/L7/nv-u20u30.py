# nv-u20u30.py <draft> <NEXT-VERSION.md> <1|2>: applies the U20 (1) or U30 (2) release-note edits from the track's draft.
import sys
draft, nv, which = sys.argv[1], sys.argv[2], sys.argv[3]
D = open(draft).read().split("\n")
def section(start_prefix, end_prefix):
    i = next(k for k, l in enumerate(D) if l.startswith(start_prefix))
    j = next(k for k, l in enumerate(D) if k > i and (l.startswith(end_prefix) or l.startswith("=====")))
    body = D[i+1:j]
    while body and not body[0].strip(): body.pop(0)
    while body and not body[-1].strip(): body.pop()
    return "\n".join(body)
s = open(nv).read()
def rep(old, new):
    global s
    assert s.count(old) == 1, ("count", s.count(old), old[:80])
    s = s.replace(old, new)
UNRES = "- **Unresolved after R1–R5 (11 Oct).**"
if which == "1":
    entry = section("(1a)", "(1b)")
    assert entry.startswith("- **U20 — ")
    rep(UNRES, entry + "\n" + UNRES)
    rep("  - **Not covered:** a save waiting for another tab's Web Lock is not counted as under way until it starts.",
        "  - **Not covered:** a save waiting for another tab's Web Lock was not counted as under way until it started; U20\n    (below) counts it from the moment it is asked for.")
    rep("    a save waiting for another tab's Web Lock is not counted (U20); the other adoption paths in the ledger (U24).",
        "    a save waiting for another tab's Web Lock was not counted (U20, below, counts it); the other adoption paths in the\n    ledger (U24).")
    rep("Its separate reopening and adoption findings stay open in the ledger (U15–U20).",
        "Its separate reopening and adoption findings stay open in the ledger (U15–U19); U20 is built (below).")
    rep("stay open in the ledger (U16–U18,\n    U20)", "stay open in the ledger (U16–U18; U20 is built,\n    below)")
    u14end = "a blank year left by a Cancel).\n"
    rep(u14end, u14end + "  - **U20: built as its own commit** (the lead's decision under Brad's word of 12 Oct, about 5:30 PM ET, to keep pressing):\n    a save, or Load theirs, waiting for another tab's Web Lock is counted as under way from the moment it is asked for,\n    until it ends (above). U2's refusal and U13's two guards now see it.\n")
else:
    entry = section("(2a)", "(2b)")
    assert entry.startswith("- **U30 — ")
    rep(UNRES, entry + "\n" + UNRES)
    rep("    `v200-u13-said-nothing-loaded`, `v200-u13-clash-while-saving`; each caught by the focused block (full-suite sensitivity\n    runs in the final-tree queue).",
        "    `v200-u13-said-nothing-loaded`, `v200-u13-clash-while-saving`; each caught by the focused block (full-suite sensitivity\n    runs in the final-tree queue). Since U30 (below), this block's case (3c) stops at U30's rule before U13's\n    base-record guard, so `v200-u13-base-while-saving` and `v200-u13-clash-while-saving` are caught by the U20 and U30\n    blocks' cases that put the folder's copy itself on screen (U20 (4), U30 (5b)).")
    u20line = "    until it ends (above). U2's refusal and U13's two guards now see it.\n"
    line = section("(2c)", "=====")
    assert line.strip().startswith("- **U30: built as its own commit after U20**")
    rep(u20line, u20line + line + "\n")
open(nv, "w").write(s)
print("ok", which)
