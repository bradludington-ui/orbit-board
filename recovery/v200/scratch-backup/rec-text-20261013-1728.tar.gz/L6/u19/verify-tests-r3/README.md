# U19 verify, round 3, lens B (test adequacy and regressions)

Independent adversarial verifier for ORBIT v2.00 track U19, round 3, lens B. It checks the builder's fix round 2 copy
`rec/L6/u19/fr2/c1`. Every time is Eastern, read from `TZ=America/New_York date`. I started at 4:50 PM ET on 13 Oct 2026.

**No earlier attempt of this review existed.** `verify-tests-r3/` did not exist when I started (4:50 PM ET), so nothing was
reused. Nothing in `/home/user/orbit-board` or `/home/user/orbit-ui` was edited, staged, committed or pushed; I only read the
builder's files. `mutate.mjs` was never imported or run: its text was read only by `rec/bin/mcount.py` and `rec/bin/mkmut.py`
(`python3 -I`). No Chromium or Playwright was run. The board stays the empty template; all data is synthetic, made at run time.

## 1. Verdict

**sound-with-issues; one must-fix (a test gap on a data-loss path), two should-fixes (one words gap, one memory decision).**

What holds, measured:
- **My rebuild is the builder's commit.** `c2/` = the read-only base + the builder's own text scripts (copied unchanged into
  `bin/b/`), in `fr2/build.sh`'s order. `diff -rq` against `fr2/c1`: identical. Board `7a6e29cb`, audit-import `424cd9ae`,
  mutate.mjs.txt `07b53964`; my diffs against the base have the same bodies as the builder's `fr2/diffs/c1-*.diff`.
- **Every builder run I re-ran matches theirs row for row, observed values included** (`bin/cmprows.py`): U19 block on c2
  136/0, on the base 136/68, on fix round 1's copy 136/3 ((r), (t), (y)); U2 57/0; v1.89 40/0; v1.95-kept 10/0; the crossed
  runs both ways (U2 2 fail in (d); v1.89 1 fail, "one click puts it back").
- **Literals and base failures.** Every expected value of the block's 83 `chk(` calls is `J([...])` of hand-written literals
  and literal constants, or a bare literal; board helpers appear only on the observed side. On the base, all 68 non-control
  checks fail and all 68 controls pass.
- **Changed existing expectations:** exactly the three checks and one comment the builder lists, at the lines it gives
  (§4). Nothing else in audit-import, audit-recon, audit-board or audit-other changes; mutate.mjs.txt only gains lines.
- **Every suite I may run passes on c2 and on the base alike** (audit-recon, boot-same, audit, audit-ppt, audit-other,
  legacy-fsrc, audit-hostile, audit-inject, npm run check's script).
- **mcount (text only):** c2 1351/1351 once; base 1328/1328; the base's text on c2 1328/1328; c2's text on fix round 1's
  board 1349 (the two ids that find this round's code missing), on the base 1328 (the 23 U19 ids missing).
- **The ten older entries the builder did not re-run** (8 U19, 2 U2) are all caught on c2, each with the same count as on
  fix round 1's copy or more (`-putback-folder-keeps-nothing` now 12 through U19: (m) 4, (r) 4, (s) 4).
- **Six of my eight mutants of fix round 2's change are caught** ((y) catches the three wrong placements of the locked-view
  refusal; (f) catches the off-by-one count).

What does not hold:
- **MF-1 (must-fix, test gap on a data-loss path).** U19 now writes what is on screen into the kept slot *before* the load
  for every saved put-back in the board file. When the load is refused (a kept copy built for another service list), only
  the write-back line returns K to the slot. No check drives that refusal. My mutant `vt3-restore-unsaved-only` (the
  write-back limited to unsaved work, as the keep itself used to be) passes the whole U19 block 136/136 and loses K: after
  the refusal and after a reopen, K is in no byte of browser storage or of the file (probe VZ-F). The money verifier (lens
  A, round 3) found the same gap with a cruder mutant (the line removed) and rated it a should-fix; I rate it a must-fix for
  this lens (§8). The board is right; the fix is a scenario and an entry, both drafted and measured.
- **SF-1 (words).** The new `scrWhere` is pinned only where it must say "the shared folder". Two plausible wrong versions,
  `driveStoreOn()` and "the folder holds ANY copy of this browser's", pass all 136 checks and make the question say K is
  "still in the shared folder it came from" when K is only in the board file. Probe VZ-E catches both; the scenario and two
  entries are drafted and measured.
- **SF-2 (memory, a decision for the lead).** The U19 harness peaked at 2920 MB on c2 in my run (the builder measured
  2752 MB). It ran clean here, but under load the builder lost six runs to the shared memory limit.

## 2. Identities (`git hash-object`)

| what | path (mine unless said) | blob |
|---|---|---|
| base board / audit-import / mutate | `base/` (cp -a of `rec/L6/base`, 7ee498a; product d66dd60) | `fce8a391` / `4aba2506` / `cbc6defc` |
| fix round 2 board / audit-import / mutate | `c2/` (rebuilt by `bin/build.sh` from the base with the builder's scripts in `bin/b/`; `diff -rq` vs `fr2/c1`: IDENTICAL) | `7a6e29cb` / `424cd9ae` / `07b53964` |
| fix round 1 (crossed runs only) | `frc1/` (cp -a of `fr/c1`) | `f6ac4b9d` / `cfaeac17` / `9028eaa8` |
| audit-recon / audit-board / audit-other / boot.mjs / shim | the same in all three | `529e36f7` / `a7c575e5` / `d89396b0` / `9c4f49ad` / `6e2ce2e6` |
| the U19 block as inserted (c2 audit-import L7804–8341) | `out/u19-block.c2.txt`, byte-identical to the builder's `fr2/block-u19.fr2.mjs.txt` | `944d7c67` |
| focused harnesses, built VERBATIM by `bin/mkfocused-u2.py` (unchanged copy of `rec/L2/u2impl`'s) | `h/src-c2/`, `h/src-base/` | U19 `ce6a1ff6`, U2.c2 `a1edf6a8`, U2.base `32cc5ac7`, v189.c2 `49261f6a`, v189.base `ed54e613`, v195kept `f2adbb73`: each the builder's own blob |
| runner | `bin/runner.mjs` (verify-tests-r2's, identical to the builder's) | `f720ce18` |
| my probes | `probe/vz-scenarios.mjs.txt` → `h/src-c2/VZ.mjs`; `probe/vze-scenarios.mjs.txt` → `VZE.mjs`; `probe/vzd-scenarios.mjs.txt` → `VZD.mjs` (each = the U19 block's own head and helpers, verbatim but for the name, + my scenarios, built by `probe/mkvz*.py`, then extracted by `mkfocused-u2.py`) | VZ `251647ee`, VZE `b430b859`, VZD `4dbb8208` |
| my mutants | `mut/mkvt3.py` (text only; every find matched once) → `mut/c2/vt3-*.html` | see `mut/blobs.txt` |
| scratch clones (never committed in) | `git/base` (7ee498a as is), `git/c2` (7ee498a + c2's board and audit-import) | board `fce8a391` / `7a6e29cb` |

orbit-board HEAD is now `71f46c3`; `git diff --stat 7ee498a HEAD -- prioritization-board-grid.html tools package.json` is
empty, so 7ee498a is still the right base. Every other blob of mine is in `out/blobs.txt`; my diffs in `diffs/`
(`base-to-c2.*` and `frc1-to-c2.*`).

## 3. The builder's runs, re-run and compared (`bin/cmprows.py`: place, claim, verdict, then every observed value)

| run (mine vs the builder's) | mine | builder | rows / observed values |
|---|---|---|---|
| U19 block on c2 (`F-r3-U19.c2-on-c2` vs `F-f2b-U19.fr2c1-on-fr2c1`) | 136, 0 fail | 136, 0 fail | SAME / SAME |
| U19 block on the base (`F-r3-U19.c2-on-base` vs `F-f2a-…-on-base`) | 136, 68 fail | 136, 68 fail | SAME / SAME |
| U19 block on fix round 1's copy (`F-r3-U19.c2-on-frc1` vs `F-f2a-…-on-frc1`) | 136, 3 fail: (r) 1, (t) 1, (y) 1 | 3 | SAME / SAME |
| U2 blocks on c2 | 57, 0 | 57, 0 | SAME / SAME |
| U2, base text on c2 | 57, 2 fail ((d)) | 2 | SAME / SAME |
| U2, c2 text on the base (vs fix round 1's `F-fr1-U2.frc1-on-base`; the harness blob is the same) | 57, 2 fail ((d)) | 2 | SAME / SAME |
| v1.89 on c2 / base text on c2 / c2 text on base | 40/0, 40/1, 40/1 | the same | SAME / SAME |
| v1.95 kept on c2 | 10/0 | 10/0 | SAME / SAME |
| suites on c2 (builder's `S-*-fr2c1`) | all exit 0, all passed | all exit 0 | §6a |
| mcount | §7 | the same numbers | — |

The builder's mutant runs on c2 are reproduced in §5 for every entry it did not re-run; the ones it did re-run I did not
repeat (their boards' blobs match: `-putback-locked-asks` `e2a9b5e5`, `-putback-words-swap-file` `343040b5`,
`-putback-folder-base-any` `361cc1e9`, `-putback-folder-keeps-nothing` `1744614c`).

## 4. Literals, base failures and changed existing expectations

**Literals.** `bin/lastargs.py` lists the last argument of each of the block's 83 `chk(` calls (`out/lastargs.txt`). Every
expected value is `J([...])` of hand-written literals and the block's literal constants (`K`, `N`, `S0`, `S1`, `N2`, `S1E`,
`K + ' RETYPED'`, `'file'`, `'swap'`, the sentence constants `PUTQ`, `UNSAVEDQ`, `PUTAGAINQ`, `FOLDQ`, `CANCEL_IMPORT`,
`CANCELLED_IMPORT`, `SWAPSAID`, `SWAPMENU`), or a bare literal. The new rows of (r)–(y) are those at block lines 404–530 in that list. Board helpers (`kept`, `where`, `anywhere`, `status`, `qs` …) appear only on the observed side.

**Every new check fails on the base, controls aside** (`F-r3-U19.c2-on-base`): 136 checks, 68 controls (each labelled
"(a CONTROL)" or in a "CONTROL:" scenario). Non-control checks passing on the base: none. Controls failing on either board:
none. Fails by place: (a) 8, (b) 4, (c) 5, (d) 4, (e) 4, (f) 8, (g) 3, (h) 1, (m) 4, (o) 4, (p) 2, (q) 1, (r) 3, (s) 4,
(t) 6, (u) 1, (w) 2, (x) 3, (y) 1.

**The suites against the base** (`diffs/base-to-c2.*`):
- mutate.mjs.txt: one hunk, 74 inserted lines (23 entries of 3 lines, 5 comment lines) before the R3 line; nothing else changes.
- audit-recon, audit-board, audit-other: unchanged.
- audit-import: the U19 block inserted after the U13 end marker, and exactly these changed existing lines, each listed
  file:line, old → new, why, in the builder's NEXT-VERSION draft:

| # | file:line (base → c2) | old | new | crossed runs (mine) |
|---|---|---|---|---|
| 1 | audit-import L3512 → L3512–3514, v1.89 "the file is newer", "one click puts it back" | observed `…+String(kept===null)`, want `'BRAD NOTE||true'` | claim widened; observed `…+String(/COLLEAGUE NOTE/ in kept && !/BRAD NOTE/ in kept)`, want unchanged | old text fails on c2 (1), new text fails on the base (1) |
| 2 | L7326 → L7328, U2 "put back waits", `retry` comment | "(`was`: null when S1 is saved)" | "… or if it is saved only in a board file (v2.00, U19) (`was`: null when S1 is saved in the folder)" | comment only |
| 3 | L7396–7397 → L7400–7401, the same block, case (d) | want `[1,'K',true,true,true,null]` | want `[1,'K',true,true,true,'S1']` | old fails on c2, new fails on the base |
| 4 | L7398 → L7402, case (d), reopened | `afterFile(…, ['S1','K'])` | `afterFile(…, ['K','S1'])` | the second (d) failure, both ways |

The first U2 block's case (c) (base ~L7228–7244, the file-retry route) observes nothing new: 0 failures in either crossed
run. It reads no kept slot after its retry; (b) of the U19 block covers that route.

## 5. Mutants

Each cell is failing checks / checks (failing places for U19 and the probes) and the run's exit. Every mutant board was
made from text only, its find matched exactly once on c2's board, and it differs from c2's board in the one intended place
(`mut/c2/*.diff`, `mut/blobs.txt`). `vt3-*` are mine (`mut/mkvt3.py`); `v200-*` are the builder's entries, built from c2's
own mutate.mjs.txt by `rec/bin/mkmut.py` (`bin/mkmuts.sh`). Each ran with `BOARD` = the mutant through the harnesses named.

| mutant | U19 | U2 | VZ | VZE | VZD |
|---|---|---|---|---|---|
| `vt3-scrwhere-store-on` | 0/136 (exit 0) | — | 2/15 (VZ-A)1,(VZ-B)1 (exit 1) | 1/10 (VZ-E)1 (exit 1) | — |
| `vt3-scrwhere-base-any` | 0/136 (exit 0) | — | 0/15 (exit 0) | 1/10 (VZ-E)1 (exit 1) | — |
| `vt3-restore-unsaved-only` | 0/136 (exit 0) | — | 1/15 (z)1 (exit 1) | 2/10 (VZ-F)2 (exit 1) | — |
| `vt3-locked-after-keep` | 2/136 (y)2 (exit 1) | — | — | — | — |
| `vt3-locked-after-question` | 1/136 (y)1 (exit 1) | — | — | — | — |
| `vt3-locked-silent` | 1/136 (y)1 (exit 1) | — | — | — | — |
| `vt3-keep-base-older` | 0/136 (exit 0) | 0/57 (exit 0) | — | — | 4/4 (VZ-D)4 (exit 1) |
| `vt3-putsavedgen-before-count` | 2/136 (f)2 (exit 1) | — | — | — | — |
| `v200-u19-swap-status-by-kept` | 2/136 (a)1,(r)1 (exit 1) | — | — | — | — |
| `v200-u19-swap-menu-replaced` | 3/136 (a)1,(c)1,(r)1 (exit 1) | — | — | — | — |
| `v200-u19-swap-title-any-kind` | 1/136 (r)1 (exit 1) | — | — | — | — |
| `v200-u19-putback-needs-handle` | 4/136 (o)4 (exit 1) | — | — | — | — |
| `v200-u19-swap-menu-any-kind` | 1/136 (r)1 (exit 1) | — | — | — | — |
| `v200-u19-putback-again-unsaved-said` | 2/136 (f)2 (exit 1) | — | — | — | — |
| `v200-u19-putback-folder-keeps-nothing` | 12/136 (m)4,(r)4,(s)4 (exit 1) | — | — | — | — |
| `v200-u2-putback-gen` | — | 1/57 (exit 1) | — | — | — |
| `v200-u19-putback-again-any` | 2/136 (f)2 (exit 1) | — | — | — | — |
| `v200-u2-putback-while-saving` | — | 35/57 (exit 1) | — | — | — |
| `v200-u19-swap-saved-forgotten` | 1/136 (f)1 (exit 1) | — | — | — | — |

**My eight mutants, each a plausible wrong fix of fix round 2's change or of the keep it relies on:**

| id | the wrong fix | caught by the block? |
|---|---|---|
| `vt3-scrwhere-store-on` | the question names the folder for a 'swap' copy whenever 💾 Save goes to a folder (`… && driveStoreOn()`) | **no** (136/136); VZ-A, VZ-B and VZ-E catch it |
| `vt3-scrwhere-base-any` | … once the folder holds any copy of this browser's (`… && driveBaseOf(mySlug())`), the MF-T1 shape for the words | **no** (136/136); VZ-E catches it (VZ-B did not: putting K back restores K's folder checkpoint, so the folder's S0 is forgotten there) |
| `vt3-restore-unsaved-only` | the write-back after a refused load kept only for unsaved work (`if(swapped && nowUnsaved)`), as the keep itself used to be | **no** (136/136); the money verifier's (z) and my VZ-F catch it; **K lost** on it (MF-1) |
| `vt3-locked-after-keep` | the locked-view refusal placed just before the load, after the slot took the locked view | yes, (y) 2 (on it the slot no longer holds K: `kv===k0` false, the view left) |
| `vt3-locked-after-question` | the refusal placed after the question | yes, (y) 1 |
| `vt3-locked-silent` | refused with `if(CYCVIEW) return;`, saying nothing | yes, (y) 1 |
| `vt3-keep-base-older` | keep unless the folder copy this browser knows is at least as new as the screen (`<` for `!==`) | no (U19 136/136, U2 57/57); no reachable route found (§6, VZ-D), so likely equivalent where reachable; minor |
| `vt3-putsavedgen-before-count` | the put-back count recorded one change early | yes, (f) 2 |

**The builder's ten entries not re-run in fix round 2** (8 U19, 2 U2), now on c2: all caught; every count equals fix round
1's on `fr/c1` (§FR.6) or more. `-putback-folder-keeps-nothing` is now caught by the U19 block itself with 12 ((m) 4, (r) 4,
(s) 4; fix round 1: 7). Several entries are still caught by one check only: `-swap-title-any-kind` (r) 1,
`-swap-menu-any-kind` (r) 1, `-swap-saved-forgotten` (f) 1, and among the new ones `-cancel-swap-only` (u) 1,
`-putsavedgen-zero` (v) 1 (a CONTROL row), `-asput-ignores-edits` (w) 1, `-putback-locked-asks` (y) 1 (the builder's runs).

## 6. Probes (focused harnesses of the U19 block's own head and helpers plus my scenarios; not suite blocks)

| probe | route | c2 | base | catches |
|---|---|---|---|---|
| VZ-A | S1 saved; K put back; 💾 Save, OK (K only in the file); an EMPTY folder connected; ↶ Put back S1: the question must say "still in the saved file", and K is kept | pass | fails (base keeps nothing at K's put-back) | store-on |
| VZ-B | the same with the folder holding S0, connected again after K's Save | pass | fails | store-on (not base-any: K's put-back restored K's empty folder checkpoint) |
| VZ-C | the money verifier's (z), verbatim: the kept work built for another service list; ↶ Put back refused by the load | pass | pass (a CONTROL) | restore-unsaved-only (1) |
| VZ-E | the folder holds S0; switched back; S1 saved in the file; K put back (S1 kept); S1 put back (K kept; S1's checkpoint knows S0); 💾 Save (file, nothing asked); working out of the folder again; ↶ Put back K: "still in the saved file", S1 kept | pass | fails (4) | store-on, base-any |
| VZ-F | VZ-C read wider: after the refusal and after a reopen, K is still kept and its text is in browser storage | pass | pass | restore-unsaved-only (2): `got ["clicked",false,["U19-S1-SAVED","swap"],false,…]`, reopened `got [["U19-S1-SAVED","swap"],false]` |
| VZ-D | for keep-base-older: N saved elsewhere; K written to a folder after it; K2 typed; reopened | **route not reached**: the reopen kept nothing (K2, typed after N's save, is the newer copy, so the classic HOLD ON route opens instead) | same | inconclusive; its 4 rows fail on c2 and base alike, by the probe's own wrong expectation, not by the board |

Runs: `F-r3-VZ-on-c2`/`-base`, `F-r3-VZE-on-c2`/`-base`, `F-r3-VZD-on-c2`/`-base`, and the `M-r3-vt3-*-VZ*` rows of §10.

## 6a. The other suites, on c2 and on the base (scratch clones `git/c2` and `git/base` at 7ee498a; `bin/mkclone.sh`, `bin/srun.sh`)

| suite | c2 (`S-r3-<suite>-c2`) | base (`S-r3-<suite>-base`) |
|---|---|---|
| audit-recon | 17:00:25 ET, exit 0, 200.7 s, ALL CHECKS PASSED | 17:03:46 ET, exit 0, 191.0 s, ALL CHECKS PASSED |
| boot-same | 17:06:57 ET, exit 0, 12.5 s, every page, source, save and error list is identical either way | 17:07:10 ET, exit 0, 14.3 s, every page, source, save and error list is identical either way |
| audit | 17:07:24 ET, exit 0, 16.5 s, ALL CHECKS PASSED | 17:07:41 ET, exit 0, 18.4 s, ALL CHECKS PASSED |
| audit-ppt | 17:07:59 ET, exit 0, 9.0 s, ALL CHECKS PASSED | 17:08:08 ET, exit 0, 7.8 s, ALL CHECKS PASSED |
| audit-other | 17:08:16 ET, exit 0, 50.6 s, ALL CHECKS PASSED | 17:09:07 ET, exit 0, 59.1 s, ALL CHECKS PASSED |
| legacy-fsrc | 17:10:06 ET, exit 0, 7.4 s, every legacy Force setting computes exactly as before | 17:10:13 ET, exit 0, 5.9 s, every legacy Force setting computes exactly as before |
| audit-hostile | 17:10:19 ET, exit 0, 81.4 s, ALL CHECKS PASSED | 17:11:41 ET, exit 0, 52.7 s, ALL CHECKS PASSED |
| audit-inject | 17:12:33 ET, exit 0, 11.0 s, ALL CHECKS PASSED | 17:12:44 ET, exit 0, 9.6 s, ALL CHECKS PASSED |
| npm run check (its script: node tools/check.mjs prioritization-board-grid.html) | 17:12:54 ET, exit 0, 3.0 s, all checks passed | 17:12:57 ET, exit 0, 3.1 s, all checks passed |

The same result on both boards for every suite; the builder's `S-*-fr2c1` runs agree.

## 7. mcount (text only, `rec/bin/mcount.py`, `python3 -I`; `out/mcount/`)

- c2's text on c2: `{"entries": 1351, "once": 1351, "missing": [], "multiple": [], "unparsed": []}`
- base's text on the base: 1328 / 1328 once.
- base's text on c2: 1328 / 1328 once (every existing entry still matches exactly once).
- c2's text on the base: 1351 entries, 1328 once, the 23 U19 ids missing.
- c2's text on fix round 1's board: 1349 once; missing `v200-u19-putback-words-swap-file`, `v200-u19-putback-locked-asks`.
- my proposal (`proposal/mutate.mjs.txt` = c2's text + the three entries of `proposal/entries.txt` before the R3 line) on
  c2: 1354 / 1354 once. Each of the three builds, by `mkmut.py`, the same board blob as my matching `vt3-*` mutant.

## 8. Findings

### MUST-FIX

**MF-1. The write-back after a refused load is now load-bearing for every saved put-back in the board file, and no check
drives it; a data-losing wrong version passes the whole block.**

- **What changed.** On the base, saved work on screen was never written into the kept slot, so a put-back whose load was
  refused left K untouched. With U19, `keepScreen` holds for saved work too, so the slot takes what is on screen *before*
  `applyStore(st)`; if the load refuses, only `if(swapped){ … setItem(…, JSON.stringify(k.meta)+'\n'+k.raw) … }` puts K back.
  Since fix round 2 refuses a locked view first, the only refusal left is `svcGuardImport` (the kept copy built for another
  set of services: an alert; or another order with "Import it?" answered Cancel).
- **Reproduction.** Mutant `vt3-restore-unsaved-only` (`mut/c2/vt3-restore-unsaved-only.html`, blob `c4b84f4a`; one line:
  `if(swapped){` → `if(swapped && nowUnsaved){`).
  - U19 block: 136/136 pass, exit 0 (`M-r3-vt3-restore-unsaved-only-U19.c2-on-c2`).
  - Probe VZ-F (`M-r3-vt3-restore-unsaved-only-VZE-on-c2`, exit 1): S1 saved; K kept by the opening, its service list
    skewed; ↶ Put back is refused by the load. The slot then holds S1 ('swap'), and K's text is in no byte of browser storage
    or of the file: `got ["clicked",false,["U19-S1-SAVED","swap"],false,"U19-S1-SAVED","U19-S1-SAVED"]`, and after a reopen
    `got [["U19-S1-SAVED","swap"],false]`. On c2 the same rows pass (`F-r3-VZE-on-c2`), and on the base too.
  - The money verifier's own mutant (the line removed) passes the block the same way (its `F-r2-U19.vfr2-on-vm-no-restore`).
- **Why a must-fix for this lens.** It is the can't-fail (DATA LOSS), on a dependency the commit itself created: before
  U19 no refused load could lose K for saved work on screen. The commit's block claims the put-back routes and drives none
  through this one. The money verifier rated the same gap a should-fix (the board is right); I rate it higher because the
  test is the only guard the release has on it, and the fix is small.
- **Minimal fix (tests only).** Add the money verifier's scenario (z) to the U19 block, after (y)
  (`verify-money-r3/proposal/scenario-z.txt`), or my wider form `proposal/scenario-z-reach.txt`, which also checks K's text
  is in browser storage after the refusal and after a reopen. Both are CONTROLS (they pass on the base). Add one entry; the
  money verifier's `v200-u19-putback-refused-no-restore`, or `v200-u19-putback-restore-unsaved-only` from
  `proposal/entries.txt`, or both. Measured: (z) 1 fail and VZ-F 2 fails on `vt3-restore-unsaved-only`; 0 on c2.

### SHOULD-FIX

**SF-1. The new `scrWhere` is pinned only where it must say "the shared folder"; two plausible wrong versions pass 136/136
and make the put-back question false.**

- The block drives a 'swap' copy with what is on screen saved and 💾 Save going to a folder only where the screen IS the
  folder's copy ((r), (t)). Nothing drives it where the screen is saved only in the board file.
- `vt3-scrwhere-store-on` (`(k.meta.why==='swap' && driveStoreOn())`) and `vt3-scrwhere-base-any`
  (`(k.meta.why==='swap' && +MS.ts && driveBaseOf(mySlug()))`) each pass all 136 checks. On probe VZ-E both make the
  question say that what is on screen (S1, saved only in the board file) is "still in the shared folder it came from"
  (`q[0].endsWith(PUTQ)` false: `got ["clicked",true,1,false,"U19-K-KEPTWORK",["U19-S1-SAVED","swap"]]`). Principle 4.
- **Fix:** add `proposal/scenario-aa.txt` (VZ-E in the block's helpers and voice; on the base its two put-back rows and both
  of its own rows fail, its two `savedS1` rows are controls) and the two entries `v200-u19-putback-words-store-on` and
  `v200-u19-putback-words-base-any` (`proposal/entries.txt`). Measured through VZE: each mutant 1 fail, c2 0.

**SF-2. Memory, for the lead before the full audit-import run.** `F-r3rss-U19.c2-on-c2` (my runner with one line printing
`process.resourceUsage().maxRSS`): 136/136, peak RSS **2920 MB** (the builder: 2752 MB; its per-scenario release variant
1182 MB). My runs were not killed, but the builder lost six to the shared memory limit this afternoon. Adding (z) and (aa)
adds a little more. The block keeps every board to its end, as every v2.00 block does; whether to release per scenario
(the builder's `fr2/probe/var/mkvar.py`) or to run the full suite with headroom is the lead's call.

### MINOR

- `vt3-keep-base-older` survives U19 and U2. I found no reachable route where the folder copy this browser knows is newer
  than a screen copy saved only in the file (VZ-D did not reach the state), so it is likely equivalent where reachable.
- Single-check catches (§5): `-swap-title-any-kind`, `-swap-menu-any-kind`, `-swap-saved-forgotten`, `-cancel-swap-only`,
  `-putsavedgen-zero` (a CONTROL row), `-asput-ignores-edits`, `-putback-locked-asks`.
- The NEXT-VERSION draft says fifteen entries were re-run on the final copy and eight only on fix round 1's. With §5, all 23
  are now caught on the final copy (this verifier's runs for the eight, plus U2's two); the lead may say so.
- (y) tells "asked or not" and the kept bytes, but runs the refusal only for saved work; an unsaved-work locked put-back is
  not driven (on the base it asked and swapped; now it is refused first, so no loss either way).

## 9. Proposals for the builder (text only; nothing applied to the builder's files)

- `proposal/scenario-aa.txt` (blob `1937d935`): scenario (aa), VZ-E in the block's own helpers and voice (labels renamed).
- `proposal/scenario-z-reach.txt` (blob `492bffc0`): the money verifier's (z) with K's reach checked after the refusal and
  after a reopen (VZ-F), labels renamed.
- `proposal/entries.txt` (blob `f22ad886`): three entries, `v200-u19-putback-words-store-on`,
  `v200-u19-putback-words-base-any`, `v200-u19-putback-restore-unsaved-only`, with a comment line, to go before the R3 line.
- `proposal/mutate.mjs.txt` (blob `0ce836b9`): c2's mutate.mjs.txt with them inserted; mcount 1354/1354 once on c2.
- Measured as written: through VZE (the same scenario code under VZ-E/VZ-F labels): c2 0 fail; base 4 fail (all in VZ-E, none
  a control); store-on 1, base-any 1, restore-unsaved-only 2.

## 10. Every run (`logs/runs.txt`; each log starts with its command and ends with its exit and wall time)

| label | start (ET) | exit | wall s | result | log |
|---|---|---|---|---|---|
| F-r3-v195kept.c2-on-c2 | 16:54:24 | 0 | 19.7 | 10 checks, 0 fail | `logs/F-r3-v195kept.c2-on-c2.log` |
| F-r3-v189.c2-on-c2 | 16:54:44 | 0 | 26.7 | 40 checks, 0 fail | `logs/F-r3-v189.c2-on-c2.log` |
| F-r3-U19.c2-on-c2 | 16:54:24 | 0 | 127.2 | 136 checks, 0 fail | `logs/F-r3-U19.c2-on-c2.log` |
| F-r3-U2.c2-on-c2 | 16:55:10 | 0 | 84.9 | 57 checks, 0 fail | `logs/F-r3-U2.c2-on-c2.log` |
| F-r3-v189.base-on-c2 | 16:56:35 | 1 | 36.8 | 40 checks, 1 fail | `logs/F-r3-v189.base-on-c2.log` |
| F-r3-U2.base-on-c2 | 16:57:12 | 1 | 71.5 | 57 checks, 2 fail | `logs/F-r3-U2.base-on-c2.log` |
| F-r3-U19.c2-on-base | 16:56:31 | 1 | 118.1 | 136 checks, 68 fail | `logs/F-r3-U19.c2-on-base.log` |
| F-r3-v189.c2-on-base | 16:58:24 | 1 | 28.5 | 40 checks, 1 fail | `logs/F-r3-v189.c2-on-base.log` |
| F-r3-U2.c2-on-base | 16:58:52 | 1 | 81.6 | 57 checks, 2 fail | `logs/F-r3-U2.c2-on-base.log` |
| F-r3-U19.c2-on-frc1 | 16:58:29 | 1 | 119.3 | 136 checks, 3 fail | `logs/F-r3-U19.c2-on-frc1.log` |
| F-r3-VZ-on-c2 | 17:00:55 | 0 | 21.7 | 15 checks, 0 fail | `logs/F-r3-VZ-on-c2.log` |
| F-r3-VZ-on-base | 17:01:17 | 1 | 19.5 | 15 checks, 6 fail | `logs/F-r3-VZ-on-base.log` |
| M-r3-vt3-scrwhere-store-on-U19.c2-on-c2 | 17:01:36 | 0 | 119.5 | 136 checks, 0 fail | `logs/M-r3-vt3-scrwhere-store-on-U19.c2-on-c2.log` |
| S-r3-audit-recon-c2 | 17:00:25 | 0 | 200.7 | ALL CHECKS PASSED | `logs/S-r3-audit-recon-c2.log` |
| M-r3-vt3-scrwhere-store-on-VZ-on-c2 | 17:03:36 | 1 | 19.6 | 15 checks, 2 fail | `logs/M-r3-vt3-scrwhere-store-on-VZ-on-c2.log` |
| M-r3-vt3-scrwhere-base-any-U19.c2-on-c2 | 17:03:55 | 0 | 111.4 | 136 checks, 0 fail | `logs/M-r3-vt3-scrwhere-base-any-U19.c2-on-c2.log` |
| M-r3-vt3-scrwhere-base-any-VZ-on-c2 | 17:05:47 | 0 | 21.7 | 15 checks, 0 fail | `logs/M-r3-vt3-scrwhere-base-any-VZ-on-c2.log` |
| S-r3-audit-recon-base | 17:03:46 | 0 | 191.0 | ALL CHECKS PASSED | `logs/S-r3-audit-recon-base.log` |
| S-r3-boot-same-c2 | 17:06:57 | 0 | 12.5 | identical either way | `logs/S-r3-boot-same-c2.log` |
| S-r3-boot-same-base | 17:07:10 | 0 | 14.3 | identical either way | `logs/S-r3-boot-same-base.log` |
| S-r3-audit-c2 | 17:07:24 | 0 | 16.5 | ALL CHECKS PASSED | `logs/S-r3-audit-c2.log` |
| S-r3-audit-base | 17:07:41 | 0 | 18.4 | ALL CHECKS PASSED | `logs/S-r3-audit-base.log` |
| M-r3-vt3-restore-unsaved-only-U19.c2-on-c2 | 17:06:08 | 0 | 118.3 | 136 checks, 0 fail | `logs/M-r3-vt3-restore-unsaved-only-U19.c2-on-c2.log` |
| S-r3-audit-ppt-c2 | 17:07:59 | 0 | 9.0 | ALL CHECKS PASSED | `logs/S-r3-audit-ppt-c2.log` |
| S-r3-audit-ppt-base | 17:08:08 | 0 | 7.8 | ALL CHECKS PASSED | `logs/S-r3-audit-ppt-base.log` |
| M-r3-vt3-restore-unsaved-only-VZ-on-c2 | 17:08:07 | 1 | 19.1 | 15 checks, 1 fail | `logs/M-r3-vt3-restore-unsaved-only-VZ-on-c2.log` |
| S-r3-audit-other-c2 | 17:08:16 | 0 | 50.6 | ALL CHECKS PASSED | `logs/S-r3-audit-other-c2.log` |
| S-r3-audit-other-base | 17:09:07 | 0 | 59.1 | ALL CHECKS PASSED | `logs/S-r3-audit-other-base.log` |
| S-r3-legacy-fsrc-c2 | 17:10:06 | 0 | 7.4 | computes exactly as before | `logs/S-r3-legacy-fsrc-c2.log` |
| S-r3-legacy-fsrc-base | 17:10:13 | 0 | 5.9 | computes exactly as before | `logs/S-r3-legacy-fsrc-base.log` |
| M-r3-vt3-locked-after-keep-U19.c2-on-c2 | 17:08:26 | 1 | 119.3 | 136 checks, 2 fail | `logs/M-r3-vt3-locked-after-keep-U19.c2-on-c2.log` |
| S-r3-audit-hostile-c2 | 17:10:19 | 0 | 81.4 | ALL CHECKS PASSED | `logs/S-r3-audit-hostile-c2.log` |
| M-r3-vt3-locked-after-question-U19.c2-on-c2 | 17:10:25 | 1 | 97.9 | 136 checks, 1 fail | `logs/M-r3-vt3-locked-after-question-U19.c2-on-c2.log` |
| S-r3-audit-hostile-base | 17:11:41 | 0 | 52.7 | ALL CHECKS PASSED | `logs/S-r3-audit-hostile-base.log` |
| S-r3-audit-inject-c2 | 17:12:33 | 0 | 11.0 | ALL CHECKS PASSED | `logs/S-r3-audit-inject-c2.log` |
| S-r3-audit-inject-base | 17:12:44 | 0 | 9.6 | ALL CHECKS PASSED | `logs/S-r3-audit-inject-base.log` |
| S-r3-check-c2 | 17:12:54 | 0 | 3.0 | all checks passed | `logs/S-r3-check-c2.log` |
| S-r3-check-base | 17:12:57 | 0 | 3.1 | all checks passed | `logs/S-r3-check-base.log` |
| M-r3-vt3-locked-silent-U19.c2-on-c2 | 17:12:03 | 1 | 63.6 | 136 checks, 1 fail | `logs/M-r3-vt3-locked-silent-U19.c2-on-c2.log` |
| M-r3-vt3-keep-base-older-U19.c2-on-c2 | 17:13:07 | 0 | 57.2 | 136 checks, 0 fail | `logs/M-r3-vt3-keep-base-older-U19.c2-on-c2.log` |
| M-r3-vt3-keep-base-older-U2.c2-on-c2 | 17:14:04 | 0 | 33.3 | 57 checks, 0 fail | `logs/M-r3-vt3-keep-base-older-U2.c2-on-c2.log` |
| M-r3-vt3-putsavedgen-before-count-U19.c2-on-c2 | 17:14:37 | 1 | 56.3 | 136 checks, 2 fail | `logs/M-r3-vt3-putsavedgen-before-count-U19.c2-on-c2.log` |
| F-r3-VZE-on-c2 | 17:15:57 | 0 | 8.6 | 10 checks, 0 fail | `logs/F-r3-VZE-on-c2.log` |
| F-r3-VZE-on-base | 17:16:06 | 1 | 8.7 | 10 checks, 4 fail | `logs/F-r3-VZE-on-base.log` |
| M-r3-vt3-scrwhere-base-any-VZE-on-c2 | 17:16:14 | 1 | 9.0 | 10 checks, 1 fail | `logs/M-r3-vt3-scrwhere-base-any-VZE-on-c2.log` |
| M-r3-vt3-scrwhere-store-on-VZE-on-c2 | 17:16:23 | 1 | 9.4 | 10 checks, 1 fail | `logs/M-r3-vt3-scrwhere-store-on-VZE-on-c2.log` |
| M-r3-vt3-restore-unsaved-only-VZE-on-c2 | 17:16:33 | 1 | 8.7 | 10 checks, 2 fail | `logs/M-r3-vt3-restore-unsaved-only-VZE-on-c2.log` |
| F-r3-VZD-on-c2 | 17:16:41 | 1 | 6.3 | 4 checks, 4 fail | `logs/F-r3-VZD-on-c2.log` |
| F-r3-VZD-on-base | 17:16:48 | 1 | 5.9 | 4 checks, 4 fail | `logs/F-r3-VZD-on-base.log` |
| M-r3-vt3-keep-base-older-VZD-on-c2 | 17:16:54 | 1 | 5.7 | 4 checks, 4 fail | `logs/M-r3-vt3-keep-base-older-VZD-on-c2.log` |
| M-r3b-v200-u19-swap-status-by-kept-U19.c2-on-c2 | 17:15:57 | 1 | 64.6 | 136 checks, 2 fail | `logs/M-r3b-v200-u19-swap-status-by-kept-U19.c2-on-c2.log` |
| M-r3b-v200-u19-swap-menu-replaced-U19.c2-on-c2 | 17:16:59 | 1 | 60.4 | 136 checks, 3 fail | `logs/M-r3b-v200-u19-swap-menu-replaced-U19.c2-on-c2.log` |
| M-r3b-v200-u19-swap-title-any-kind-U19.c2-on-c2 | 17:17:02 | 1 | 60.8 | 136 checks, 1 fail | `logs/M-r3b-v200-u19-swap-title-any-kind-U19.c2-on-c2.log` |
| M-r3b-v200-u19-putback-needs-handle-U19.c2-on-c2 | 17:18:00 | 1 | 63.6 | 136 checks, 4 fail | `logs/M-r3b-v200-u19-putback-needs-handle-U19.c2-on-c2.log` |
| M-r3b-v200-u19-swap-menu-any-kind-U19.c2-on-c2 | 17:18:02 | 1 | 61.9 | 136 checks, 1 fail | `logs/M-r3b-v200-u19-swap-menu-any-kind-U19.c2-on-c2.log` |
| M-r3b-v200-u19-putback-again-unsaved-said-U19.c2-on-c2 | 17:19:03 | 1 | 61.1 | 136 checks, 2 fail | `logs/M-r3b-v200-u19-putback-again-unsaved-said-U19.c2-on-c2.log` |
| M-r3b-v200-u19-putback-folder-keeps-nothing-U19.c2-on-c2 | 17:19:04 | 1 | 61.0 | 136 checks, 12 fail | `logs/M-r3b-v200-u19-putback-folder-keeps-nothing-U19.c2-on-c2.log` |
| M-r3b-v200-u2-putback-gen-U2.c2-on-c2 | 17:20:05 | 1 | 35.8 | 57 checks, 1 fail | `logs/M-r3b-v200-u2-putback-gen-U2.c2-on-c2.log` |
| M-r3b-v200-u19-putback-again-any-U19.c2-on-c2 | 17:20:05 | 1 | 60.0 | 136 checks, 2 fail | `logs/M-r3b-v200-u19-putback-again-any-U19.c2-on-c2.log` |
| M-r3b-v200-u2-putback-while-saving-U2.c2-on-c2 | 17:20:41 | 1 | 35.5 | 57 checks, 35 fail | `logs/M-r3b-v200-u2-putback-while-saving-U2.c2-on-c2.log` |
| M-r3b-v200-u19-swap-saved-forgotten-U19.c2-on-c2 | 17:21:04 | 1 | 51.9 | 136 checks, 1 fail | `logs/M-r3b-v200-u19-swap-saved-forgotten-U19.c2-on-c2.log` |
| F-r3rss-U19.c2-on-c2 | 17:22:20 | 0 | 44.5 | 136 checks, 0 fail; peak RSS 2920 MB | `logs/F-r3rss-U19.c2-on-c2.log` |

Exit 1 on the base, on fix round 1's copy, on a crossed run, on a probe of the base or on a mutant means checks failed, as
intended. No run hit its 600 s cap or was killed. The AUDIT_IMPORT_RUNNING lock was absent at every run's start (run.sh logs
a wait; none is logged). At most two of my node processes ran at once (two sequential lanes; the memory run alone).

## 11. PIDs

`pids.txt` lists every bounded command's `timeout` PID and its child, with the time, the label and the command (160 lines,
4:51 PM to 5:23 PM ET). At 5:23 PM ET none of them was still running. I killed no process by PID, name or pattern. I did
stop four of my own Monitor watchers (each a `tail -F`/`until … sleep` loop reading my own `logs/runs.txt`, not a run) with
the task tool once their events were no longer needed.

## 12. What I did not do, and rule deviations (plainly)

- **Not run (the lead's):** the full audit-import and audit-board, and the mutation sweep. mutate.mjs was read as text only.
- **Not run:** Chromium, Playwright, the verify:grid tools.
- **Not re-run:** the builder's mutant runs that it already re-ran on fr2/c1 (the mutant boards' blobs match theirs), and
  the builder's probe P2 (its findings are wording points identical on the base).
- **Not adopted or applied:** any change to the builder's files. My proposals are in `proposal/` only.
- **VZ-D** (for `vt3-keep-base-older`) did not reach its intended state on c2; I report it as inconclusive, not as a defect.
- **Deviations:** read-only commands (`cat`, `sed -n`, `grep`, `ls`, `diff` to the screen, `cmp`, `git hash-object`,
  `git diff --stat`/`rev-parse`/`status` in orbit-board, `date`, `free`, `ps`) and small `python3 -I` analyses of my own outputs
  (`tally.py`, `fails.py`, `cmprows.py`, `lastargs.py`, `muttable.py`, the runs-table and proposal-assembly snippets) ran
  without `setsid -w timeout`; so did `mkdir -p`, `chmod +x`, `ln -s` of my run directories' links, and `cp` of harness files
  inside my directory (in `bin/mk-harness.sh`, itself run through `bx.sh`). Every node run went through `run.sh` (600 s cap,
  lock check, PIDs). The scratch clone `git/c2` briefly had c2's mutate.mjs.txt copied in as an untracked file; I removed it
  before any suite ran (no suite reads it). Nothing was committed in either clone.
