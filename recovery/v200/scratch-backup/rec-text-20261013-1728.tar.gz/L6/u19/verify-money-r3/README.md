# U19 verify, lens A (data loss and money), round 3

**Track U19, ORBIT v2.00.** I verified the builder's fix round 2 (`rec/L6/u19/fr2/c1`). Lens A covers data loss and money,
and whether every word stays true. I started at 3:49 PM ET on 13 Oct 2026 (`TZ=America/New_York date`).

**No earlier attempt of this review existed.** `verify-money-r3/` did not exist when I started, so I reused nothing. Every
time below is Eastern.

Nothing in `/home/user/orbit-board` or `/home/user/orbit-ui` was edited, staged, committed or pushed. I only read the
builder's files. `mutate.mjs` was never imported or run; I read its text only with `rec/bin/mcount.py` and `rec/bin/mkmut.py`
(`python3 -I`).

## 1. Verdict

**Sound with issues. There is no must-fix.**

The board change does what the lead asked on every route I drove. Round 2's findings are closed on `fr2/c1`:

- **MF-A (the false "still in the saved file").** Round 2's W1 and W1c now pass. The question names the shared folder.
- **SF-1, the folder-base gap.** Round 2's X1 passes. The builder's (s) catches `v200-u19-putback-folder-base-any` with
  4 checks.
- **SF-5, the locked view.** ↶ Put back is refused at once, and the kept work is byte for byte the same (W6 passes).

Nothing lost the copy that was on screen at the put-back. No money figure or export changed: audit, audit-ppt, audit-other
and the board check all pass.

I found two should-fixes and a few minor points:

- **SF-1, a test gap on a data-loss path that the change widened.** With U19, every saved put-back in the board file now
  writes what is on screen into the kept slot *before* the load. When the load refuses (for example, the kept copy was
  built for another service list), only the restore line writes the kept work back. Remove that line and all 136 checks
  still pass. On that mutant the kept work K is then in no byte the board can reach. A scenario and a mutation entry that
  close the gap are written and measured (§3).
- **SF-2, the drafts' scope for the one-slot point.** The open point (round 2's W4) is narrower in the drafts than in
  fact. It needs no Save after the put-back, and no S1 at all. The commonest put-back has it: the opening keeps K, and K
  is put back at once. A newer copy that arrives afterwards is not loaded. The next 💾 Save's HOLD ON, answered OK, then
  leaves that newer copy only in Teams version history. On the board before, this route lost nothing but that copy's own
  predecessor (Y2). Replacement wording is in §3.

## 2. Identities

| what | blob |
|---|---|
| base board (`rec/L6/base`, 7ee498a; product d66dd60) | `fce8a391` |
| fix board (`fr2/c1`, copied here as `vfr2/`) | `7a6e29cb` |
| fix audit-import | `424cd9ae` (base `4aba2506`) |
| fix mutate.mjs.txt | `07b53964` (base `cbc6defc`) |
| audit-recon / audit-board / audit-other | `529e36f7` / `a7c575e5` / `d89396b0`, unchanged |

- `vbase/` and `vfr2/` are `cp -a` copies, with the node_modules symlink and `chmod u+w`. `diff -rq` finds only the three
  files above.
- My diffs against the base (`diffs/vfr2-*.diff`) match the builder's `fr2/diffs/c1-*.diff` line for line. Without their
  header lines, they hash to the same blobs: board `54acb94a`, audit-import `baf5df7b`, mutate `f501a15c`.
- orbit-board HEAD is now `4bbec77`. `git diff --stat 7ee498a HEAD` on the board, `tools/` and `package.json` is empty:
  32 records-only commits. HEAD's board is `fce8a391`.
- My focused harnesses were built with `mkfocused-u2.py`, copied unchanged from round 2.
  - **Byte-identical to the builder's and round 2's:** U19 `ce6a1ff6`, U2 `a1edf6a8`/`32cc5ac7`, v1.89
    `49261f6a`/`ed54e613`.
  - **Byte-identical to round 2's:** W `6d0a7b6b` and X `c26ec369`.
  - **New:** Y `e25fc8df` and Z `a2d7afa1`.

## 3. Findings

### MUST-FIX

None. I looked for a route that loses the copy on screen at the put-back, misstates money, exports a wrong figure, or
leaves a newly false word, and found none. §4 lists the angles tried.

### SHOULD-FIX

**SF-1. The restore after a refused load is now load-bearing for saved work, and no check drives it.**

**What the code does.** In `keptPutBack` (board L6990–7001), when `keepScreen` holds, the slot is overwritten with what is
on screen (`swapped=m2`) before `applyStore(st)`. If `applyStore` refuses, the kept work is written back by this line:

```
    if(swapped){ try{ localStorage.setItem(_AP.key+'.kept', JSON.stringify(k.meta)+'\n'+k.raw); }catch(e){} }
```

On the base this ran only for unsaved work. With U19 it runs for every put-back in the board file. Since fix round 2 made
the locked view refuse first, the only remaining refusal is `svcGuardImport`: a kept copy built for another set of
services (alert), or listed in another order with "Import it?" answered Cancel. The builder lists this under "Not covered".

**Evidence.**
- **The mutants.** Two mutants of `fr2/c1` drop the line: `vm-no-restore` (the line → `if(false){}`, blob `ba1ea835`) and
  `v200-u19-putback-refused-no-restore` (my proposed entry, built by `mkmut.py`, the line deleted, blob `0ec26c7c`).
- **The U19 block on `vm-no-restore`:** 136/136 pass, exit 0 (`F-r2-U19.vfr2-on-vm-no-restore`). The block does not catch
  it.
- **My probe Y** (`probe/yblock.mjs.txt`). S1 is saved into the board file and K is kept by the opening. The kept copy's
  service list is then skewed (`USAF,ANG,AFRC,XTRA`), and ↶ Put back is pressed.
  - **On `fr2/c1` and on the base:** one question, the load's alert, K still kept byte for byte, and S1 on screen and in
    the file. Y1b (the same services in another order, the order question answered Cancel) behaves the same.
  - **On both mutants:** the slot holds S1 ('swap'), and K is in no byte of browser storage or the file. This also holds
    after a reopen. The mutants fail 3 rows in Y1 and 1 in Y1b (`F-p1-Y-on-vm-no-restore`,
    `F-p2-Y-on-v200-u19-putback-refused-no-restore`).

**Minimal fix (tests only; the board is right):**

1. Add a scenario (z) to the U19 block, after (y). The text is `proposal/scenario-z.txt`, in the block's own helpers and
   voice.
   - It skews the kept copy's service list.
   - It presses ↶ Put back.
   - It checks one question, the kept work byte for byte, S1 on screen and in the file, and S1 saved.
   - It is labelled a CONTROL, because the base never touched the slot for saved work. This follows the builder's (v).
   - **Measured** in a focused harness made of the block's own head and helpers plus (z) (`proposal/zblock.mjs.txt`,
     `h/src/Z.mjs`):
     - `fr2/c1`: 3/3 pass;
     - base: 3/3 pass;
     - the proposed entry's mutant: 1 fail, `got ["clicked",1,false,["U19-S1-SAVED","swap"],…]`.
2. Add the mutation entry `proposal/entry.txt` before the R3 line:

```
  { id: "v200-u19-putback-refused-no-restore", area: "keptPutBack", what: "a put-back the load itself refuses (the kept work built for another service list) leaves what was on screen in the kept slot and does not write the kept work back: with saved work on screen (U19 keeps it too), the kept work is then in no copy this board can reach",
    find: "    if(swapped){ try{ localStorage.setItem(_AP.key+'.kept', JSON.stringify(k.meta)+'\\n'+k.raw); }catch(e){} }\n",
    repl: "" },
```

`mcount` (text only) on `proposal/mutate.mjs.txt` gives 1352 of 1352 entries matching exactly once on `fr2/c1`.

**SF-2. The drafts state the one-slot open point too narrowly.**

The Unresolved bullet and the ledger Status text both say the newer copy is lost "after the put-back's Save". Probe Y2
reaches the same end with no Save after the put-back and no S1:

1. Alice's work K is kept aside by the opening, and her other browser's N is on screen.
2. She puts K back at once. U19 keeps N.
3. Her other browser saves N2 into the file.
4. She reopens.

**What each board does:**
- **On `fr2/c1`:**
  - The reopen keeps K on screen. It says "…already keeps earlier work aside … the newer copy was not loaded and nothing
    was lost".
  - 💾 Save asks one HOLD ON, naming N2's save.
  - Answered OK, it writes K over N2.
  - Afterwards: K ✓, N ✓ (kept), N2 ✗ (Teams version history only).
- **On the base:**
  - The reopen loads N2 and keeps K. Save asks nothing.
  - Afterwards: K ✓, N2 ✓. N ✗, but N is N2's own predecessor, replaced by that browser's ordinary save.

Every word on the way is true, and the HOLD ON asks, so this is not a must-fix. It is the lead's one-slot decision. But it
must be accepted at its real scope. NEXT-VERSION's "What users may see" already says it in general terms. The two other
drafts should say it too.

- **Unresolved bullet.** Replace "the board keeps one copy aside, so a newer copy saved into the file from another browser
  after the put-back's Save is not loaded on a reopen while that copy is kept, and the next Save's HOLD ON answered OK
  leaves it only in Teams version history (on the board before, the same route lost the copy the put-back replaced
  instead)" with:

  > the board keeps one copy aside, and every ↶ Put back in the board file now fills it with the copy it replaced. While
  > that copy is kept, a newer copy saved into the file afterwards -- from another browser or by a colleague, with or
  > without a Save since the put-back -- is not loaded over new work on a reopen (the board says so), and the next 💾
  > Save's HOLD ON answered OK leaves that newer copy only in Teams version history. On the board before, the route with
  > a Save after the put-back lost the copy the put-back replaced instead; with no Save after it, the board before loaded
  > the newer copy and kept the new work (measured: verify-money-r2 W4, verify-money-r3 Y2)

- **Ledger Status text.** Replace "so after the put-back's Save a newer copy saved into the file from another browser
  (N2)" with "so after any put-back in the board file, with or without a Save since, a newer copy saved into the file from
  another browser or by a colleague (N2)". Add round 3's evidence: `rec/L6/u19/verify-money-r3`, `F-p1-Y-on-vfr2` /
  `F-p1-Y-on-vbase`.

### MINOR

- **The builder's README (§F2.2) and summary say "`persist()` sets MS.ts on every change".** It is `save()`
  (`MS.ts=Date.now()`, board L6774); `persist()` (L6511) only writes. The substance holds: every edit goes through
  `save()`, and buildSavedHtml and the folder push stamp `MS.ts`. By code, the boot opens the file's state only when its
  `ts` is newer than this browser's copy (L6461–6470), so a file state with no `ts` is not opened over the default (read,
  not run). So I found no route that gives real work `MS.ts` 0. The drafts do not repeat the slip.
- **P2 is still open, and identical on the base.** For work kept by an opening or by Load theirs, the question names the
  place by the kept copy's kind. Round 2's W2 shows the 'file' kind's words are true when the screen is in both places.
- **The HOLD ON's Cancel advice names only ⬅ Import.** Import replaces K after its own "DISCARD" question. On the U19
  route, the copy Import would load is the very copy already kept aside, and ↶ Put back of it would load it *and* keep K.
  The builder lists this for Brad.
- **The refusal alert's words.** When a put-back's load is refused for its service list, the alert says "that file was
  built for a different set of services … Nothing was imported". That is the same wording as on the base for unsaved work.
- **Memory.** Two of my U19-block runs were killed by the memory-cgroup OOM killer (exit 137) while one other node process
  of mine ran beside them. The kills are recorded in `out/dmesg-killed.txt` (PIDs 26023 and 18104). Both runs passed when
  re-run alone. The lead's whole audit-import should run alone, as planned.

## 4. Round 2's findings, and the angles I tried on `fr2/c1`

| item | on `fr2/c1` | evidence |
|---|---|---|
| MF-A: W1 and W1c question words | **fixed**: "still in the shared folder it came from" | `F-p1-W-on-vfr2` (the W1/W1c PRINCIPLE 4 rows pass) |
| SF-1 (X1, folder base older) | **fixed**: X passes. `-folder-base-any` caught by (s), 4 checks | `F-p1-X-on-vfr2` exit 0; `F-m2-U19…-folder-base-any` |
| SF-2 (W4, one slot) | open, as the lead's decision; scope too narrow in the drafts | W4 fails as in round 2; Y2 (SF-2 above) |
| SF-3 (U15 row) | done: withdrawn and appended to U15 | `fr2/drafts/LEDGER-U19.md` |
| SF-4 (W7, a new row) | drafted as `U<next>`; W7 still fails identically, not U19's | `F-p1-W-on-vfr2` W7 rows |
| SF-5 (locked view) | **fixed**: refused at once; K byte for byte; S1 after leaving | W6 passes; the builder's (y) |
| minor 0===0 | not changed; no route found (see MINOR) | reading: `save()` L6767–6774, boot L6460–6475 |
| minor "stays in the folder whatever" | comment fixed | board L6970 |
| minor ledger quote | fixed: `(+MS.ts||0)` quoted exactly | ledger draft |
| W3 money | the kept S1 exported as a file equals S1's own save, key for key; asks and allocations equal | `F-p1-W-on-vfr2` W3 rows pass |

**Angles tried, without a must-fix:**

- **The folder exception, where `keepScreen` is false.** For the next folder Save to write K without asking, K's checkpoint
  must equal the folder copy's time. That happens only when K descends from it, which is ordinary editing, or through U30's
  "taken as the base" refresh, which loses a copy with no put-back at all. In every other case Save's clash forces a spaced
  history copy, so the replaced copy stays in the history (round 2 W2, the builder's (k) and (t)).
- **Year handling.** `MS.ts` is store-wide, and a folder copy carries the whole store (`livePayload` → `pkgStrip(MS)`). So
  "the folder base for this year equals `MS.ts`" does mean the whole store on screen is in that copy or its history.
- **Every other `keepAside` caller** (boot, the shared state file, the folder refresh, Load theirs, an earlier copy put
  back) still refuses on `'occupied'`. None loads over the kept copy.
- **Who removes the kept slot.** Only `keptPutBack` (the restore covered by SF-1) and `keptDiscard` (asks first). A
  put-back that cannot keep (no room) changes nothing (the builder's (h)).
- **The new `asPut` and `saved` words.** `DIRTY` is set only together with `_saveGen++` (board L2248, L6771, L7013,
  L27191). So "was put back and has not been saved since" holds until the next change or save.
- **The status after the put-back** ("💾 Save will ask before it writes over a copy saved after the one this work came
  from"), the top bar, the 📁 File menu, the reopen's "not loaded" message and the HOLD ON: all true on the routes driven
  (round 2's W5, my Y2).
- **Money and exports.** No export path or figure is touched. W3 is equal key for key. audit, audit-ppt and audit-other
  all pass, and so does the board check.

## 5. The six principles, checked literally

1. **Never lose any copy.**
   - **Met** for the copy on screen at every put-back I drove: the builder's 136 checks, round 2's W1, W2, W5 and W6, X1,
     and my Y1 and Y1b.
   - **Not met** for a newer copy that arrives while the slot is occupied (W4, Y2). This comes with the lead's "kept aside,
     like the unsaved 'swap' case", which means one slot. The board says the newer copy was not loaded, and the HOLD ON
     asks. It needs explicit acceptance at its full scope (SF-2).
   - **Not U19's:** W7 (identical on the base).
2. **Refuse or ask rather than guess.**
   - The locked view is refused at once.
   - A refused load restores the kept work.
   - The reopen refuses to load over new work while the slot is full, and says so.
   - The HOLD ON asks.
3. **Money and every export match.** Unchanged (§4).
4. **Every word stays true.**
   - MF-A is fixed.
   - I found no new false word.
   - P2 (older, identical on the base) stays open for Brad.
5. **The smallest change.** Round 2 adds one guard line, one constant and one comment line to the board (+10/−2 against
   fix round 1). The keep test itself is unchanged.
6. **Existing checks preserved.** No committed expectation changes in this round. The build's three changed checks and one
   comment are listed by file:line in the NEXT-VERSION draft. My crossed runs fail exactly there:
   - `U2.vbase` on `fr2/c1`: 2 fails, both case (d) ("put back again … nothing kept", got `'S1'`; "then reopened", got
     `["K","S1",…]`);
   - `v189.vbase` on `fr2/c1`: 1 fail ("one click puts it back", got `BRAD NOTE||false`).
   - The fix's own copies pass: U2 57/57 and v1.89 40/40.
   - `mcount` (text only): `fr2/c1` 1351 of 1351 entries match exactly once; the base 1328 of 1328.

## 6. Runs

Every node run went through `bin/run.sh`:
- `setsid -w timeout -k 10 600`;
- the `AUDIT_IMPORT_RUNNING` lock check (polled every 20 s, up to 30 min);
- PIDs (the timeout PID and its child) recorded in `pids.txt`;
- an end line written to `logs/runs.txt`.

The lock was absent at every start, so no run waited or was skipped. At most two node processes of mine ran at once
(lanes A+B, then D+E). The load average was 28–33 on 4 CPUs.

| label | start (ET) | exit | wall s | log | result |
|---|---|---|---|---|---|
| F-r1-U19.vfr2-on-vfr2 | 2026-10-13 16:04:16 | 137 | 193.4 | logs/F-r1-U19.vfr2-on-vfr2.log | **killed by the memory-cgroup OOM killer** (PID 26023); incomplete, re-run as F-r2 |
| F-p1-Y-on-vfr2 | 2026-10-13 16:06:42 | 1 | 51.6 | logs/F-p1-Y-on-vfr2.log | Y1 and Y1b pass; observe rows; Y2 PRINCIPLE 1 fails (N2 lost after HOLD ON OK) |
| F-r1-U19.vfr2-on-vbase | 2026-10-13 16:07:30 | 1 | 222.5 | logs/F-r1-U19.vfr2-on-vbase.log | 68 of 136 fail; 0 of 68 controls fail. By scenario: (a) 8, (b) 4, (c) 5, (d) 4, (e) 4, (f) 8, (g) 3, (h) 1, (m) 4, (o) 4, (p) 2, (q) 1, (r) 3, (s) 4, (t) 6, (u) 1, (w) 2, (x) 3, (y) 1 |
| F-p1-Y-on-vbase | 2026-10-13 16:07:33 | 1 | 44.4 | logs/F-p1-Y-on-vbase.log | Y1 and Y1b pass; Y2: N2 loaded, K kept, Save asks nothing (N, N2's predecessor, gone) |
| F-p1-Y-on-vm-no-restore | 2026-10-13 16:08:18 | 1 | 38.5 | logs/F-p1-Y-on-vm-no-restore.log | **Y1 3 rows and Y1b 1 row fail**: K in no byte |
| F-p1-W-on-vfr2 | 2026-10-13 16:08:56 | 1 | 91.2 | logs/F-p1-W-on-vfr2.log | W1, W1c, W2, W3, W5 and W6 pass; W4 and W7 fail (open / not U19's) |
| F-p1-X-on-vfr2 | 2026-10-13 16:10:28 | 0 | 26.8 | logs/F-p1-X-on-vfr2.log | 5/5 |
| F-r2-U19.vfr2-on-vfr2 | 2026-10-13 16:11:33 | 0 | 367.2 | logs/F-r2-U19.vfr2-on-vfr2.log | **136/136** (run alone) |
| F-r2-U19.vfr2-on-vm-no-restore | 2026-10-13 16:17:41 | 0 | 320.7 | logs/F-r2-U19.vfr2-on-vm-no-restore.log | **136/136: the mutant survives the block** (SF-1) |
| F-r1-U2.vfr2-on-vfr2 | 2026-10-13 16:23:13 | 0 | 181.8 | logs/F-r1-U2.vfr2-on-vfr2.log | 57/57 |
| F-r1-U2.vbase-on-vfr2 | 2026-10-13 16:26:14 | 1 | 175.0 | logs/F-r1-U2.vbase-on-vfr2.log | 2 fail, both case (d): the build's listed changes |
| S-audit-vfr2 | 2026-10-13 16:29:10 | 0 | 45.9 | logs/S-audit-vfr2.log | ALL CHECKS PASSED |
| F-m1-U19.vfr2-on-v200-u19-putback-folder-base-any | 2026-10-13 16:29:17 | 137 | 179.3 | logs/F-m1-U19.vfr2-on-v200-u19-putback-folder-base-any.log | **killed by the memory-cgroup OOM killer** (PID 18104); re-run as F-m2 |
| S-audit-ppt-vfr2 | 2026-10-13 16:29:55 | 0 | 18.7 | logs/S-audit-ppt-vfr2.log | ALL CHECKS PASSED |
| S-check-vfr2 | 2026-10-13 16:30:14 | 0 | 12.6 | logs/S-check-vfr2.log | "all checks passed" (`node tools/check.mjs prioritization-board-grid.html`, npm check's command) |
| F-p2-Y-on-v200-u19-putback-refused-no-restore | 2026-10-13 16:30:27 | 1 | 49.0 | logs/F-p2-Y-on-v200-u19-putback-refused-no-restore.log | **Y1 3 rows and Y1b 1 row fail** (caught) |
| S-audit-other-vfr2 | 2026-10-13 16:31:16 | 0 | 131.2 | logs/S-audit-other-vfr2.log | ALL CHECKS PASSED |
| F-m1-U19.vfr2-on-v200-u19-putback-keeps-nothing-saved | 2026-10-13 16:32:16 | 1 | 271.9 | logs/F-m1-U19.vfr2-on-v200-u19-putback-keeps-nothing-saved.log | caught: 62 fail, 0 controls (the builder's count) |
| F-r1-v189.vfr2-on-vfr2 | 2026-10-13 16:36:48 | 0 | 73.2 | logs/F-r1-v189.vfr2-on-vfr2.log | 40/40 |
| F-r1-v189.vbase-on-vfr2 | 2026-10-13 16:38:01 | 1 | 82.0 | logs/F-r1-v189.vbase-on-vfr2.log | 1 fail: "one click puts it back" (the build's listed change) |
| F-m2-U19.vfr2-on-v200-u19-putback-folder-base-any | 2026-10-13 16:39:30 | 1 | 355.1 | logs/F-m2-U19.vfr2-on-v200-u19-putback-folder-base-any.log | caught: 4 fail, all (s), 0 controls (the builder's count; run alone) |
| F-z1-Z-on-vfr2 | 2026-10-13 16:45:44 | 0 | 28.0 | logs/F-z1-Z-on-vfr2.log | 3/3 (proposed (z)) |
| F-z1-Z-on-vbase | 2026-10-13 16:46:12 | 0 | 27.1 | logs/F-z1-Z-on-vbase.log | 3/3 (a control on the base, as labelled) |
| F-z1-Z-on-v200-u19-putback-refused-no-restore | 2026-10-13 16:46:39 | 1 | 14.2 | logs/F-z1-Z-on-v200-u19-putback-refused-no-restore.log | 1 fail: (z) catches the proposed entry |

- **Where the suites ran.** The S- runs used the scratch clone `git/vfr2`, made with `git clone --shared` of orbit-board,
  checked out at 7ee498a. Only `fr2/c1`'s board (`7a6e29cb`) and audit-import (`424cd9ae`) were copied in. Nothing was
  committed there.
- **Where the F- runs ran.** Each F- run used `bin/runner.mjs` on the copy root named in its label.
- **Every check's value** is in `out/<label>.checks.jsonl`. `bin/tally.py` counts them.

**Mutants.** None was made through mutate.mjs. Each was made from `vfr2`'s board.

| mutant | how made | blob | result |
|---|---|---|---|
| `vm-no-restore` | `bin/vmut.py`: the restore line → `if(false){}` (1 match) | `ba1ea835` | **survives the U19 block** (136/136). Caught by Y1/Y1b (4 rows): K lost |
| `v200-u19-putback-refused-no-restore` (proposed) | `mkmut.py` from `proposal/mutate.mjs.txt` (1 match; the line deleted) | `0ec26c7c` | caught by Y (4 rows) and by the proposed (z) (1 check) |
| `v200-u19-putback-folder-base-any` (builder's) | `mkmut.py` from `fr2/c1`'s mutate text (1 match) | `361cc1e9` | caught: (s) 4 |
| `v200-u19-putback-keeps-nothing-saved` (builder's) | `mkmut.py` (1 match) | `627c95d8` | caught: 62 |

**Other blobs** (`git hash-object`):
- probe blocks: `probe/yblock.mjs.txt` `addba060`; round 2's `wblock` `dec7843a` and `xblock` `69557e2b` (copied unchanged);
- proposal: `proposal/scenario-z.txt` `ce5f5646`, `proposal/zblock.mjs.txt` `5ee7a478`, `proposal/entry.txt` `691e7c4b`,
  `proposal/mutate.mjs.txt` `5f209d27`;
- bin: `bin/run.sh` `aba8036c`, `bin/frun.sh` `b05bb299`, `bin/runner.mjs` `f720ce18` (identical to round 2's),
  `bin/mkfocused-u2.py` `252c00ef`, `bin/mkprobe.py` `cb6ba387`, `bin/vmut.py` `6e3f8f1e`, `bin/tally.py` `ebff2382`;
- diffs: `diffs/vfr2-board.diff` `cdfa16d8`, `diffs/vfr2-audit-import.diff` `82f420c0`, `diffs/vfr2-mutate.diff` `ca827ae0`,
  `diffs/vm-no-restore.diff` `cf387b94`, `diffs/v200-u19-putback-refused-no-restore.diff` `d8701dba`,
  `diffs/proposal-mutate.diff` `a1327918`.

**Exact diffs of my mutants and proposal:**

```
--- vfr2/prioritization-board-grid.html   (vm-no-restore)
-    if(swapped){ try{ localStorage.setItem(_AP.key+'.kept', JSON.stringify(k.meta)+'\n'+k.raw); }catch(e){} }
+    if(false){}
--- vfr2/prioritization-board-grid.html   (v200-u19-putback-refused-no-restore, from the proposed entry)
-    if(swapped){ try{ localStorage.setItem(_AP.key+'.kept', JSON.stringify(k.meta)+'\n'+k.raw); }catch(e){} }
```

The proposed entry sits before `  // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the
working plan.` (`diffs/proposal-mutate.diff`).

## 7. PIDs

- **What `pids.txt` records.** Each bounded command's `timeout` PID and its node child, with the time, label and command.
  It also records:
  - the lane shells (unwrapped bash scripts that only run bounded steps in turn);
  - the scratch clone;
  - one `node --check`.
- **No process was killed by me.** The two exit-137 runs were killed by the memory cgroup's OOM killer. The kernel lines
  are in `out/dmesg-killed.txt`.

## 8. Decisions, what I did not do, and deviations

**Decisions:**
- **SF-1 is a should-fix, not a must-fix.** The board is correct (Y1 and Y1b pass on `fr2/c1`). What is missing is a check
  and an entry on a data-loss path the change widened. Round 2 rated the same kind of gap (its SF-5) a should-fix.
- **SF-2 is a should-fix.** The behaviour is the lead's one-slot decision, and every word on the route is true. The fix is
  in the drafts, which must state the full scope for the lead or Brad to accept knowingly.
- **P2 and the Cancel advice are minor.** Both are older or listed wording points that lose no copy.

**Not done:**
- **The lead's runs:** the full audit-import and audit-board, and the mutation sweep. Only 2 of the builder's 23 entries
  were re-run, plus my two mutants.
- **Suites not run:** audit-recon, boot-same, legacy-fsrc, audit-hostile and audit-inject. The builder ran them on
  `fr2/c1`, and the change does not touch their areas.
- **Not run:** Chromium, Playwright and the verify:grid tools. Nothing was installed.
- **Not tested:** a second tab (U20), and real Teams or disk version history.
- **Not edited:** none of the builder's files. My proposal is in `proposal/`, for the lead.

**Deviations:**
- **Two unwrapped syntax checks.** `timeout 60 node --check` ran without `setsid -w` and without the lock check: on `Y.mjs`
  at about 4:03 PM ET, and on `Z.mjs` at about 4:44 PM ET. The lock was absent before and after.
- **Unwrapped shell work.** These ran without the wrapper:
  - read-only commands (`cat`, `grep`, `sed`, `diff`, `git hash-object`, `ls`, `dmesg`, `date`);
  - the `python3 -I` text tools on my own files;
  - the `cp -a`, `mkdir` and `ln -s` of my own directories;
  - the `git clone --shared` (with `timeout 300`).
- **Waits** were `until … sleep` loops with a tool timeout.

This README was written from about 4:47 PM ET and last edited at 4:49 PM ET on 13 Oct 2026, read from the clock. No
process of mine was running at that time.
