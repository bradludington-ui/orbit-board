# CYCREG (ledger U32 + U33) — builder record

Track: Codex P1 (12 Oct): an imported cycle whose RCN / EEIC list repeats a key (`K1`, `K1`), or holds an entry named
`__none__`, doubles the workbook export (USAF $1,800 / ANG $400 where the money is $900 / $200).
Builder started 12 Oct 7:31 PM ET. All times Eastern (`TZ=America/New_York date`).

> **SUPERSEDED IN PART AGAIN (13 Oct, fix round 3) — read "Fix round 3 (13 Oct)" at the very end first.** The proposed
> commit is now the copy `fr3/c1` (board 60bd0c3c); `fr2/c1` (board 59cff8f3) is no longer proposed. The banner below is
> kept as it was written after fix round 2.
>
> **SUPERSEDED IN PART — read "Fix round 2 (13 Oct)" at the end first, then "Fix round (13 Oct)".** The verifiers of round 1
> found the c1 build below unsound (it still doubled money for 1 beside "1", froze a shared folder, and refused a user's own
> board in untrue words); the verifiers of round 2 found fix round 1's sheet printed a requirement on the number 1 under the
> wrong codes. The proposed commit is now the copy `fr2/c1` (board 59cff8f3), not `fr/c1` (board 19e6e508) and not `c1`
> (board 2f9219a4). Everything below this banner is kept as it was; where a later round says otherwise, the later round holds.

## What I kept from the earlier attempt
The directory held only empty folders (`bin blocks diffs harness logs mut out probe`) and an empty `pids.txt`, all
stamped 6:14 PM ET. Nothing to keep or re-check: **everything here was done fresh in this session.** `pids.txt` was
appended to (it was empty).

## Base
`../base` (read-only) = git archive of orbit-board `7ee498a` (records head; product = `d66dd60`, U14). Blobs verified in
`c1` before editing: board `fce8a391`, audit-recon `529e36f7`, mutate.mjs.txt `cbc6defc`.

## Proposed commit (ONE)
`1: v2.00 (U32, U33): an RCN / EEIC list that repeats a key or holds "__none__" is refused at the door; the RCN-EEIC sheet
counts each key once | copy c1 | board 2f9219a4b33b7d147eb64cd5ee367939899c84c8 | suites audit-recon
9c2cdd88033df65c1b756e863996ec0ee28b6509 (audit-import 4aba2506, audit-board a7c575e5, audit-other d89396b0 unchanged) |
mutate bfb8770849c1a0eebe44f3277d64f519d18a65c0`

Message draft: `drafts/COMMIT-MSG.txt` (the lead adds the attribution lines).

**Why one commit, not two:** the door and the export fix close one finding, and the suite block needs both. Its
door/import checks fail without the door. Its "file opened" checks fail without the export fix, because that route
passes no door. With two commits, the first commit's own block would fail, or the block would have to be split in two.
Each half is a few lines, so one commit is the smaller, reviewable unit.

## Files changed (c1 vs base; nothing else differs: `diff -rq ../base c1` lists only these three)
| file | base blob | c1 blob | diff |
|---|---|---|---|
| prioritization-board-grid.html | fce8a391bd8a248d5185e199d22190c1687eaea0 | 2f9219a4b33b7d147eb64cd5ee367939899c84c8 | `diffs/c1-board.diff` (93 lines) |
| tools/export-audit/audit-recon.mjs | 529e36f7c20e635b2722ea53b6a4f44b4ed328af | 9c2cdd88033df65c1b756e863996ec0ee28b6509 | `diffs/c1-audit-recon.diff` |
| tools/export-audit/mutate.mjs.txt | cbc6defc6803851e847844848fc9b186daeeb268 | bfb8770849c1a0eebe44f3277d64f519d18a65c0 | `diffs/c1-mutate.diff` (28 lines) |
All three diffs concatenated: `diffs/c1-all.diff`.

### The board change, exactly
1. **The door** (`inShapeWhy`, after the destination-key checks, ~L9612): an `rcn` array, wherever it sits (the working
   plan's list or a locked cycle's), refuses the file if an entry's `k` begins with two underscores, or if a `k` appears
   twice. The two messages are:
   - `the RCN / EEIC key at <path>.rcn[i].k “__none__” begins with two underscores, which the board keeps for its own bookkeeping`
   - `the RCN / EEIC list at <path>.rcn holds the key “K1” twice (rcn[0] and rcn[1]); a key names one combination`
   `inRefuse` then says it in the alert and the status line, and nothing is taken. Every import route runs this one door:
   Import (`importState`, and through it one appropriation via `consTakeApply` → `cycTake`), Import a full board
   (`fullImportText`), several boards at once (`importBoards`), folder copies (`driveParse`), the shared state file
   (`loadShared`) and band import.
2. **The export** (`monSheet`, ~L30113–30323): `const NONE=Symbol('none')`, where it was `'__none__'`. A Symbol equals no
   text, so no list key can be the not-assigned bucket. `const keys=keysOf().filter((k,i,a)=>a.indexOf(k)===i)`, and the
   three key loops (the rollup, the breakout and NOT FUNDED) walk `keys`. `anyMoney` asks for `b[NONE]` / `p[NONE]` by
   name, because `Object.keys` does not list a Symbol.
3. **rcnAdd** (~L10867): the key is `'r'+Date.now().toString(36)+'_'+n`, starting at `n = L.length` and stepping past any
   key in use. The base reused a key when two adds came in one millisecond after a removal.

## Decisions, and how each meets the lead's principles
- **(1) Never lose a copy.** The import refuses whole: browser storage stays byte-identical (checked), and the user's
  file is untouched on disk. Opening a file that already holds such a list is NOT refused. That file is the user's own
  board, and refusing it would lose it. It is not normalized either, because normalizing means choosing which of two
  same-keyed entries the pointers mean (a guess). Both entries are kept as they are, and the export is made right for any
  list.
- **(2) Refuse or ask rather than guess.** Import refuses. Nothing is re-keyed or dropped anywhere.
- **(3) Money and every export match exactly.** The RCN-EEIC sheet counts each key once by construction, and the
  not-assigned bucket cannot be forged. The XLSX bytes were read and checked against hand-worked literals (900 / 200 /
  1,100) on every route.
- **(4) Every word stays true.** The refusal names the list, the key and where. The underscore wording reuses the board's
  existing rule ("begins with two underscores, which the board keeps for its own bookkeeping", the `inIdWhy` phrase for
  ids), so it stays true now that the sheet no longer uses `'__none__'`. The `inRefuse` tail ("written by ORBIT never
  carries that") is made true by the rcnAdd fix: this build never writes a repeated key. Choosing a Symbol rather than
  "exclude `__none__` from the known keys": with the exclusion, an entry keyed `__none__` on a board that already holds it
  would have its money printed "not assigned", while the pickers and the Spend Plan Source name that entry's codes. With
  the Symbol it is an ordinary combination everywhere.
- **(5) Smallest change.** About 11 lines at the door, 3 in rcnAdd, and 6 changed lines plus comments in monSheet.
- **(6) Every existing check, fixture and expected value is preserved.** No existing check, fixture or expected value was
  edited, and every existing mutation still finds its text exactly once (mcount below).
- **Refusing every `__` key, not only `__none__`:** this is the same size of change, matches the established id rule, and
  ORBIT never writes such a key (rcnAdd keys start with `r`). Broader than "equal to the sentinel" by design.

## Every rcnReg() / code-list walk checked (base line numbers)
Only `monSheet` (L30402, keysOf for 'RCN-EEIC by Month') **sums money by walking the list**; fixed. The rest:
- L5100: the RCN / EEIC panel (lists rows; "Used by" is a pointer count).
- L9493: codeIssues (lengths).
- L10846–10917: the registry's own functions.
- L19045: cycLock copies the list.
- L23790, L23819, L24273: pickers (options).
- L23994: filter options.
- L26127: the menu's "N combos".
- Per-key lookups, never a walk: rcnEntry/rcnLabel, Spend Plan Source (L17238), ACE breakout (L14089, L29326).
None of these doubles money. A repeated key still shows as two rows in these lists ("Not covered").
- SI: `SI_CODES` is a constant with no repeats, and the SI sheet's unknown codes go to NONE (now the Symbol). The SI
  snapshot (L24592) totals over `Object.keys(rows)`, once per code. CR return / CR Cash Needs sum per requirement row,
  not per code.
- PPBE lines (`ppKeysOf`) already de-duplicate with a seen set.
- FYDP views read a cycle only through cycView.
- No merge path combines RCN lists: the only `*merge*` function is rpMerge (the reprogramming log), and `MS.rcn` is
  assigned only by rcnReg's create-if-missing and cycView's copy.

## Reproduction on the base (probe/repro.mjs; synthetic data at run time only)
O&M; services USAF/ANG/AFRC; R1 asks 900/200/0; pots 5,000 each; award single in FYMON[2].
**By hand:** USAF 900, ANG 200, AFRC 0, all services 900+200+0 = 1,100, all in the award month.
`logs/probe-base-2.log` (start 7:40:48 PM ET, exit 0, 15.3 s):
| case | door | import | reopened PB27 sheet (USAF / ANG / all) |
|---|---|---|---|
| Codex 1: [K1, K1], R1 on K1 | passes | taken | 1,800 / 400 / 2,200 (K1 row twice) |
| Codex 2: [K1, `__none__`], R1 on none | passes | taken | 1,800 / 400 / 2,200 (900 under "22222 / BBBBB" + 900 "not assigned") |
| CONTROL [K1, K2], R1 on K1 | passes | taken | 900 / 200 / 1,100 |
| CONTROL [K1, K2], R1 on none | passes | taken | 900 / 200 / 1,100 |
Save-and-reopen and the file opened directly give the same. rcnAdd in one ms after a removal: `["rmgj6k3cw_1","rmgj6k3cw_1"]`.
On c1 (`logs/probe-c1-1.log`): the defect cases are refused at the door, storage is unchanged, and every route reads
900 / 200 / 1,100. The controls are unchanged. rcnAdd gives `["rmgj6k3cw_1","rmgj6k3cw_2"]`.

## The suite block (audit-recon, after "end v2.00 (U14)")
`blocks/block-cycreg.mjs.txt` (blob d84372262c81429845a1262f626493cd44815a34), inserted verbatim. Name: "v2.00 (CYCREG) — a
cycle whose RCN / EEIC list repeats a key or holds “__none__” is refused at the door, and the RCN-EEIC sheet counts each key
once". It has 31 checks:
- For each of 4 cases, there are 7 checks: fixture, door, full import, imported-reopened, imported-saved-reopened,
  opened, opened-saved-reopened.
- 2 checks on the working plan's list at the door.
- 1 check on rcnAdd.
Expected values are hand-written literals; board helpers are used only for observed values. It follows the v2.00 shape:
async wrapper, bootMark/bootRelease(__bm, [])/settleBoards (audit-recon's own form; this suite has no keepBoards), the
two-space `  const name = '...';` line, and the `// ==== ` and `// ==== end ` markers.

## Mutations (mutate.mjs.txt, TEXT only; inserted before the R3 comment line)
`blocks/entries-cycreg.mjs.txt`: `v200-cycreg-keys-repeat`, `v200-cycreg-none-is-text`, `v200-cycreg-door-repeat`,
`v200-cycreg-door-underscores`, `v200-cycreg-none-money-unseen`, `v200-cycreg-add-key-reused`. Mutants were built with
`rec/bin/mkmut.py` (text read; each find matched once) into `mut/c1/`.

mcount (text only, `rec/bin/mcount.py`):
- base mutate on base board: 1328 entries, 1328 once.
- c1 mutate on c1 board: 1334 entries, 1334 once (the six new ones 1 each).
- base mutate on c1 board: 1328 once.
(`out/mcount-*.json`)

## Every run (label, start ET, exit, wall seconds, log)
Each node run went through `bin/run.sh` (setsid -w timeout -k 10 600; lock checked first; it never had to wait).

| label | start (ET) | exit | wall s | log | note |
|---|---|---|---|---|---|
| probe-base-1 | 2026-10-12 19:40:37 EDT | 1 | 3.6 | logs/probe-base-1.log |  |
| probe-base-2 | 2026-10-12 19:40:48 EDT | 0 | 15.3 | logs/probe-base-2.log |  |
| probe-c1-1 | 2026-10-12 19:42:38 EDT | 0 | 20.5 | logs/probe-c1-1.log |  |
| F1-c1 | 2026-10-12 19:44:52 EDT | 0 | 24.4 | logs/F1-c1.log |  |
| F1-base | 2026-10-12 19:45:20 EDT | 1 | 25.9 | logs/F1-base.log |  |
| M-v200-cycreg-keys-repeat | 2026-10-12 19:46:29 EDT | 1 | 34.0 | logs/M-v200-cycreg-keys-repeat.log |  |
| M-v200-cycreg-none-is-text | 2026-10-12 19:47:03 EDT | 1 | 34.0 | logs/M-v200-cycreg-none-is-text.log |  |
| M-v200-cycreg-door-repeat | 2026-10-12 19:47:37 EDT | 1 | 28.8 | logs/M-v200-cycreg-door-repeat.log |  |
| M-v200-cycreg-door-underscores | 2026-10-12 19:48:06 EDT | 1 | 27.8 | logs/M-v200-cycreg-door-underscores.log |  |
| M-v200-cycreg-none-money-unseen | 2026-10-12 19:48:34 EDT | 1 | 28.4 | logs/M-v200-cycreg-none-money-unseen.log |  |
| M-v200-cycreg-add-key-reused | 2026-10-12 19:49:03 EDT | 1 | 27.8 | logs/M-v200-cycreg-add-key-reused.log |  |
| S-boot-same-c1 | 2026-10-12 19:50:28 EDT | 0 | 27.0 | logs/S-boot-same-c1.log |  |
| S-audit-c1 | 2026-10-12 19:50:55 EDT | 0 | 23.7 | logs/S-audit-c1.log |  |
| S-audit-ppt-c1 | 2026-10-12 19:51:19 EDT | 0 | 9.4 | logs/S-audit-ppt-c1.log |  |
| FI-hi-v196-c1 | 2026-10-12 19:51:28 EDT | 1 | 1.8 | logs/FI-hi-v196-c1.log |  |
| FI-hi-v196-base | 2026-10-12 19:51:30 EDT | 1 | 2.4 | logs/FI-hi-v196-base.log |  |
| FI-hi-v197w1-c1 | 2026-10-12 19:51:33 EDT | 1 | 2.4 | logs/FI-hi-v197w1-c1.log |  |
| FI-hi-v197w1-base | 2026-10-12 19:51:36 EDT | 1 | 1.6 | logs/FI-hi-v197w1-base.log |  |
| S-audit-other-c1 | 2026-10-12 19:51:28 EDT | 0 | 94.0 | logs/S-audit-other-c1.log |  |
| FI2-hi-v196-c1 | 2026-10-12 19:51:46 EDT | 0 | 85.3 | logs/FI2-hi-v196-c1.log |  |
| FI2-hi-v196-base | 2026-10-12 19:53:12 EDT | 0 | 71.9 | logs/FI2-hi-v196-base.log |  |
| FI2-hi-v197w1-c1 | 2026-10-12 19:54:24 EDT | 0 | 27.9 | logs/FI2-hi-v197w1-c1.log |  |
| FI2-hi-v197w1-base | 2026-10-12 19:54:52 EDT | 0 | 32.9 | logs/FI2-hi-v197w1-base.log |  |
| F2-c1 | 2026-10-12 19:56:29 EDT | 0 | 48.2 | logs/F2-c1.log |  |
| S-audit-recon-c1 | 2026-10-12 19:53:02 EDT | 0 | 266.7 | logs/S-audit-recon-c1.log |  |
| S-legacy-fsrc-c1 | 2026-10-12 19:57:29 EDT | 0 | 6.1 | logs/S-legacy-fsrc-c1.log |  |
| F2-base | 2026-10-12 19:57:17 EDT | 1 | 48.1 | logs/F2-base.log |  |
| F2-mut-v200-cycreg-keys-repeat | 2026-10-12 19:58:05 EDT | 1 | 52.6 | logs/F2-mut-v200-cycreg-keys-repeat.log |  |
| S-audit-hostile-c1 | 2026-10-12 19:57:35 EDT | 0 | 130.7 | logs/S-audit-hostile-c1.log |  |
| F2-mut-v200-cycreg-none-is-text | 2026-10-12 19:58:58 EDT | 1 | 48.1 | logs/F2-mut-v200-cycreg-none-is-text.log |  |
| S-audit-inject-c1 | 2026-10-12 19:59:46 EDT | 0 | 22.7 | logs/S-audit-inject-c1.log |  |
| check-c1 | 2026-10-12 20:00:09 EDT | 0 | 7.6 | logs/check-c1.log |  |
| F2-mut-v200-cycreg-door-repeat | 2026-10-12 19:59:46 EDT | 1 | 46.8 | logs/F2-mut-v200-cycreg-door-repeat.log |  |
| S-boot-same-base | 2026-10-12 20:00:16 EDT | 0 | 24.0 | logs/S-boot-same-base.log |  |
| S-audit-base | 2026-10-12 20:00:40 EDT | 0 | 25.9 | logs/S-audit-base.log |  |
| S-audit-ppt-base | 2026-10-12 20:01:06 EDT | 0 | 10.6 | logs/S-audit-ppt-base.log |  |
| F2-mut-v200-cycreg-door-underscores | 2026-10-12 20:00:33 EDT | 1 | 52.8 | logs/F2-mut-v200-cycreg-door-underscores.log |  |
| F2-mut-v200-cycreg-none-money-unseen | 2026-10-12 20:01:26 EDT | 1 | 55.0 | logs/F2-mut-v200-cycreg-none-money-unseen.log |  |
| S-audit-other-base | 2026-10-12 20:01:17 EDT | 0 | 75.2 | logs/S-audit-other-base.log |  |
| F2-mut-v200-cycreg-add-key-reused | 2026-10-12 20:02:22 EDT | 1 | 51.6 | logs/F2-mut-v200-cycreg-add-key-reused.log |  |
| S-audit-recon-c1-final | 2026-10-12 20:00:41 EDT | 0 | 295.9 | logs/S-audit-recon-c1-final.log |  |
| S-audit-recon-base | 2026-10-12 20:02:32 EDT | 0 | 222.7 | logs/S-audit-recon-base.log |  |
| S-legacy-fsrc-base | 2026-10-12 20:06:15 EDT | 0 | 4.3 | logs/S-legacy-fsrc-base.log |  |
| S-audit-hostile-base | 2026-10-12 20:06:19 EDT | 0 | 92.9 | logs/S-audit-hostile-base.log |  |
| S-audit-inject-base | 2026-10-12 20:07:52 EDT | 0 | 26.4 | logs/S-audit-inject-base.log |  |
| check-base | 2026-10-12 20:08:19 EDT | 0 | 6.8 | logs/check-base.log |  |

## Suites (scratch git clones gc/c1 and gc/base at 7ee498a; c1 = 7ee498a + this board + this audit-recon)
```
batch c1 start 19:50:28 EDT
S-boot-same-c1 |  | exit: 0  wall_s: 27.0
S-audit-c1 | ALL CHECKS PASSED | exit: 0  wall_s: 23.7
S-audit-ppt-c1 | ALL CHECKS PASSED | exit: 0  wall_s: 9.4
S-audit-other-c1 | ALL CHECKS PASSED | exit: 0  wall_s: 94.0
S-audit-recon-c1 | ALL CHECKS PASSED | exit: 0  wall_s: 266.7
S-legacy-fsrc-c1 |  | exit: 0  wall_s: 6.1
S-audit-hostile-c1 | ALL CHECKS PASSED | exit: 0  wall_s: 130.7
S-audit-inject-c1 | ALL CHECKS PASSED | exit: 0  wall_s: 22.7
check-c1 | exit: 0  wall_s: 7.6
batch c1 done 20:00:16 EDT
batch base start 20:00:16 EDT
S-boot-same-base |  | exit: 0  wall_s: 24.0
S-audit-base | ALL CHECKS PASSED | exit: 0  wall_s: 25.9
S-audit-ppt-base | ALL CHECKS PASSED | exit: 0  wall_s: 10.6
S-audit-other-base | ALL CHECKS PASSED | exit: 0  wall_s: 75.2
S-audit-recon-base | ALL CHECKS PASSED | exit: 0  wall_s: 222.7
S-legacy-fsrc-base |  | exit: 0  wall_s: 4.3
S-audit-hostile-base | ALL CHECKS PASSED | exit: 0  wall_s: 92.9
S-audit-inject-base | ALL CHECKS PASSED | exit: 0  wall_s: 26.4
check-base | exit: 0  wall_s: 6.8
batch base done 20:08:26 EDT
```

## Focused harness runs
```
F1-c1 | ALL CHECKS PASSED | 31p/0f
F1-base | 14 FAILING CHECK(S) | 17p/14f
M-v200-cycreg-keys-repeat | 2 FAILING CHECK(S) | 29p/2f
M-v200-cycreg-none-is-text | 2 FAILING CHECK(S) | 29p/2f
M-v200-cycreg-door-repeat | 3 FAILING CHECK(S) | 28p/3f
M-v200-cycreg-door-underscores | 2 FAILING CHECK(S) | 29p/2f
M-v200-cycreg-none-money-unseen | 8 FAILING CHECK(S) | 23p/8f
M-v200-cycreg-add-key-reused | 1 FAILING CHECK(S) | 30p/1f
FI-hi-v196-c1 |  | 
FI-hi-v196-base |  | 
FI-hi-v197w1-c1 |  | 
FI-hi-v197w1-base |  | 
FI2-hi-v196-c1 | ALL CHECKS PASSED | 6p/0f 3p/0f 4p/0f 5p/0f 4p/0f
FI2-hi-v196-base | ALL CHECKS PASSED | 6p/0f 3p/0f 4p/0f 5p/0f 4p/0f
FI2-hi-v197w1-c1 | ALL CHECKS PASSED | 9p/0f 3p/0f 3p/0f
FI2-hi-v197w1-base | ALL CHECKS PASSED | 9p/0f 3p/0f 3p/0f
final focused start 19:56:28 EDT harness e47701665076f2a0ed53962c327485745652ab35
F2-c1 | ALL CHECKS PASSED | 31p/0f
F2-base | 14 FAILING CHECK(S) | 17p/14f
F2-mut-v200-cycreg-keys-repeat | 2 FAILING CHECK(S) | 29p/2f
F2-mut-v200-cycreg-none-is-text | 2 FAILING CHECK(S) | 29p/2f
F2-mut-v200-cycreg-door-repeat | 3 FAILING CHECK(S) | 28p/3f
F2-mut-v200-cycreg-door-underscores | 2 FAILING CHECK(S) | 29p/2f
F2-mut-v200-cycreg-none-money-unseen | 8 FAILING CHECK(S) | 23p/8f
F2-mut-v200-cycreg-add-key-reused | 1 FAILING CHECK(S) | 30p/1f
final focused done 20:03:14 EDT
```
- **F2-base**: 17 pass, 14 fail:
  - FAIL `Codex 1 · K1 listed twice · the door` — the file is refused, saying which list, which key and why — got ``
  - FAIL `Codex 1 · K1 listed twice · Import a full board` — refused whole: it returns false, says what was refused and why, and browser storage is byte-identical — got `[true,"",[],"⬅ Full board imported from “cycle.html” (v2.0): O&M (1 year). Locked cycles: O&M PB27. The BAE list — 0 rows; Execution data — 0 appropriations; Co`
  - FAIL `Codex 1 · K1 listed twice · imported, the same browser reopened` — PB27’s RCN-EEIC sheet, read from the workbook’s bytes: USAF 900, ANG 200, all services 1,100, each once, in the award month — got `{"on":"PB|2027","err":"","rows":[["USAF","11111 / AAAAA",900,0,900],["USAF","11111 / AAAAA",900,0,900],["USAF","USAF TOTAL",1800,0,1800],["ANG","11111 / AAAAA",`
  - FAIL `Codex 1 · K1 listed twice · imported, saved and reopened` — the same, from the saved file — got `{"on":"PB|2027","err":"","rows":[["USAF","11111 / AAAAA",900,0,900],["USAF","11111 / AAAAA",900,0,900],["USAF","USAF TOTAL",1800,0,1800],["ANG","11111 / AAAAA",`
  - FAIL `Codex 1 · K1 listed twice · the file opened` — PB27’s RCN-EEIC sheet counts each key once: USAF 900, ANG 200, all services 1,100 — got `{"on":"PB|2027","err":"","rows":[["USAF","11111 / AAAAA",900,0,900],["USAF","11111 / AAAAA",900,0,900],["USAF","USAF TOTAL",1800,0,1800],["ANG","11111 / AAAAA",`
  - FAIL `Codex 1 · K1 listed twice · the file opened, saved and reopened` — the same, from the saved file — got `{"on":"PB|2027","err":"","rows":[["USAF","11111 / AAAAA",900,0,900],["USAF","11111 / AAAAA",900,0,900],["USAF","USAF TOTAL",1800,0,1800],["ANG","11111 / AAAAA",`
  - FAIL `Codex 2 · K1 and an entry named “__none__” · the door` — the file is refused, saying which list, which key and why — got ``
  - FAIL `Codex 2 · K1 and an entry named “__none__” · Import a full board` — refused whole: it returns false, says what was refused and why, and browser storage is byte-identical — got `[true,"",[],"⬅ Full board imported from “cycle.html” (v2.0): O&M (1 year). Locked cycles: O&M PB27. The BAE list — 0 rows; Execution data — 0 appropriations; Co`
  - FAIL `Codex 2 · K1 and an entry named “__none__” · imported, the same browser reopened` — PB27’s RCN-EEIC sheet, read from the workbook’s bytes: USAF 900, ANG 200, all services 1,100, each once, in the award month — got `{"on":"PB|2027","err":"","rows":[["USAF","22222 / BBBBB",900,0,900],["USAF","— no RCN/EEIC assigned —",900,0,900],["USAF","USAF TOTAL",1800,0,1800],["ANG","2222`
  - FAIL `Codex 2 · K1 and an entry named “__none__” · imported, saved and reopened` — the same, from the saved file — got `{"on":"PB|2027","err":"","rows":[["USAF","22222 / BBBBB",900,0,900],["USAF","— no RCN/EEIC assigned —",900,0,900],["USAF","USAF TOTAL",1800,0,1800],["ANG","2222`
  - FAIL `Codex 2 · K1 and an entry named “__none__” · the file opened` — PB27’s RCN-EEIC sheet counts each key once: USAF 900, ANG 200, all services 1,100 — got `{"on":"PB|2027","err":"","rows":[["USAF","22222 / BBBBB",900,0,900],["USAF","— no RCN/EEIC assigned —",900,0,900],["USAF","USAF TOTAL",1800,0,1800],["ANG","2222`
  - FAIL `Codex 2 · K1 and an entry named “__none__” · the file opened, saved and reopened` — the same, from the saved file — got `{"on":"PB|2027","err":"","rows":[["USAF","22222 / BBBBB",900,0,900],["USAF","— no RCN/EEIC assigned —",900,0,900],["USAF","USAF TOTAL",1800,0,1800],["ANG","2222`
  - FAIL `the working plan’s list · the door` — K1 twice in the working plan’s own list is refused, by its place in the file — got ``
  - FAIL `Add RCN / EEIC` — two entries, two keys: the one kept keeps its key and the new one has a key of its own — got `[2,1,true]`
- **F2-c1**: 31 pass, 0 fail
- **F2-mut-v200-cycreg-add-key-reused**: 30 pass, 1 fail:
  - FAIL `Add RCN / EEIC` — two entries, two keys: the one kept keeps its key and the new one has a key of its own — got `[2,1,true]`
- **F2-mut-v200-cycreg-door-repeat**: 28 pass, 3 fail:
  - FAIL `Codex 1 · K1 listed twice · the door` — the file is refused, saying which list, which key and why — got ``
  - FAIL `Codex 1 · K1 listed twice · Import a full board` — refused whole: it returns false, says what was refused and why, and browser storage is byte-identical — got `[true,"",[],"⬅ Full board imported from “cycle.html” (v2.0): O&M (1 year). Locked cycles: O&M PB27. The BAE list — 0 rows; Execution data — 0 appropriations; Co`
  - FAIL `the working plan’s list · the door` — K1 twice in the working plan’s own list is refused, by its place in the file — got ``
- **F2-mut-v200-cycreg-door-underscores**: 29 pass, 2 fail:
  - FAIL `Codex 2 · K1 and an entry named “__none__” · the door` — the file is refused, saying which list, which key and why — got ``
  - FAIL `Codex 2 · K1 and an entry named “__none__” · Import a full board` — refused whole: it returns false, says what was refused and why, and browser storage is byte-identical — got `[true,"",[],"⬅ Full board imported from “cycle.html” (v2.0): O&M (1 year). Locked cycles: O&M PB27. The BAE list — 0 rows; Execution data — 0 appropriations; Co`
- **F2-mut-v200-cycreg-keys-repeat**: 29 pass, 2 fail:
  - FAIL `Codex 1 · K1 listed twice · the file opened` — PB27’s RCN-EEIC sheet counts each key once: USAF 900, ANG 200, all services 1,100 — got `{"on":"PB|2027","err":"","rows":[["USAF","11111 / AAAAA",900,0,900],["USAF","11111 / AAAAA",900,0,900],["USAF","USAF TOTAL",1800,0,1800],["ANG","11111 / AAAAA",`
  - FAIL `Codex 1 · K1 listed twice · the file opened, saved and reopened` — the same, from the saved file — got `{"on":"PB|2027","err":"","rows":[["USAF","11111 / AAAAA",900,0,900],["USAF","11111 / AAAAA",900,0,900],["USAF","USAF TOTAL",1800,0,1800],["ANG","11111 / AAAAA",`
- **F2-mut-v200-cycreg-none-is-text**: 29 pass, 2 fail:
  - FAIL `Codex 2 · K1 and an entry named “__none__” · the file opened` — PB27’s RCN-EEIC sheet counts each key once: USAF 900, ANG 200, all services 1,100 — got `{"on":"PB|2027","err":"","rows":[["USAF","22222 / BBBBB",900,0,900],["USAF","— no RCN/EEIC assigned —",900,0,900],["USAF","USAF TOTAL",1800,0,1800],["ANG","2222`
  - FAIL `Codex 2 · K1 and an entry named “__none__” · the file opened, saved and reopened` — the same, from the saved file — got `{"on":"PB|2027","err":"","rows":[["USAF","22222 / BBBBB",900,0,900],["USAF","— no RCN/EEIC assigned —",900,0,900],["USAF","USAF TOTAL",1800,0,1800],["ANG","2222`
- **F2-mut-v200-cycreg-none-money-unseen**: 23 pass, 8 fail:
  - FAIL `Codex 2 · K1 and an entry named “__none__” · imported, the same browser reopened` — PB27’s RCN-EEIC sheet, read from the workbook’s bytes: USAF 900, ANG 200, all services 1,100, each once, in the award month — got `{"on":"PB|2027","err":"","rows":[],"tot":[[],[],[]]}`
  - FAIL `Codex 2 · K1 and an entry named “__none__” · imported, saved and reopened` — the same, from the saved file — got `{"on":"PB|2027","err":"","rows":[],"tot":[[],[],[]]}`
  - FAIL `Codex 2 · K1 and an entry named “__none__” · the file opened` — PB27’s RCN-EEIC sheet counts each key once: USAF 900, ANG 200, all services 1,100 — got `{"on":"PB|2027","err":"","rows":[],"tot":[[],[],[]]}`
  - FAIL `Codex 2 · K1 and an entry named “__none__” · the file opened, saved and reopened` — the same, from the saved file — got `{"on":"PB|2027","err":"","rows":[],"tot":[[],[],[]]}`
  - FAIL `CONTROL · ordinary K1, K2, R1 on none · imported, the same browser reopened` — PB27’s RCN-EEIC sheet, read from the workbook’s bytes: USAF 900, ANG 200, all services 1,100, each once, in the award month — got `{"on":"PB|2027","err":"","rows":[],"tot":[[],[],[]]}`
  - FAIL `CONTROL · ordinary K1, K2, R1 on none · imported, saved and reopened` — the same, from the saved file — got `{"on":"PB|2027","err":"","rows":[],"tot":[[],[],[]]}`
  - FAIL `CONTROL · ordinary K1, K2, R1 on none · the file opened` — PB27’s RCN-EEIC sheet counts each key once: USAF 900, ANG 200, all services 1,100 — got `{"on":"PB|2027","err":"","rows":[],"tot":[[],[],[]]}`
  - FAIL `CONTROL · ordinary K1, K2, R1 on none · the file opened, saved and reopened` — the same, from the saved file — got `{"on":"PB|2027","err":"","rows":[],"tot":[[],[],[]]}`

## Drafts for the lead
- `drafts/NEXT-VERSION-entry.md`: the v2.00 entry (U13/U1/U14 style), to go after the U14 bullet.
- `drafts/UNRESOLVED-line.md`: there is NO existing line for U32/U33 in "Unresolved after R1–R5" on the base (searched),
  so this is a proposed NEW line, not a replacement.
- `drafts/LEDGER-append.md`: text to append to rows U32 and U33 of `recovery/v200/UNRESOLVED-LEDGER.md` (the rows exist at
  orbit-board `60336a0`), with `<sha>` and `<time>` placeholders.
- `drafts/COMMIT-MSG.txt`: the commit message (the attribution lines are the lead's to add).

## PIDs
`pids.txt`: every timeout PID and its child, recorded by `bin/run.sh` and `bin/bx.sh` with the command; also the three
background wrappers (`batch-wrapper`, `final-focused-wrapper`, `recon-final-wrapper`). I killed nothing. Every run ended
on its own (exit codes above), and no run hit its 600 s cap.

## What I did NOT do
- I did not run the full `audit-import.mjs` or `audit-board.mjs` (the lead's). Instead I ran focused audit-import
  harnesses, built verbatim with `rec/L2/u2impl/mkfocused-u2.py`, from the two blocks that put the board's own saved files
  through `inboundCheck` ("v1.96 review" and "v1.97 W1"). They pass on base and c1. audit-board's RCN blocks (v1.97 W1
  rcnSet, v1.98 item 83 CLIN grid) touch neither the door, monSheet nor rcnAdd (checked by reading), so they were not run.
  audit-import's full-import tests (files written by v1.80–v1.87, through `git show`) go through the new door and were not
  run. A file from those versions with a repeated or `__`-prefixed RCN key would now be refused; rcnAdd in those versions
  wrote `r…` keys.
- I did not import, execute or run `mutate.mjs`. It was read as text only (mcount.py / mkmut.py), and the scratch clones
  keep the repository's own mutate.mjs untouched and unrun.
- Nothing is edited, staged, committed or pushed in /home/user/orbit-board or /home/user/orbit-ui. The scratch clones
  (`gc/base`, `gc/c1`, `git clone --shared`) were never committed to.
- No playwright install, and no Chromium run (none was needed: every check is jsdom).
- The board file stays the empty template. Synthetic data exists only at run time.
- Not built: a notice when a board that already holds a repeated or `__` key opens, a way to repair such a list, or a
  guard on Remove for a repeated row (Remove clears every assignment to that key, as its question already says). These
  are proposed follow-ups for the lead, not part of this fix.
- The other import routes (Import, one appropriation, several boards, folder copies, the shared state file, band import)
  run the same `inboundCheck`, but this block drives only the door itself and Import a full board.

## Notes on the runs (read before trusting a line above)
- **Suites: base and c1 match.** Every allowed suite passes on both. boot-same, legacy-fsrc and `npm run check` print
  their own pass lines ("every page, source, save and error list is identical either way", "every legacy Force setting
  computes exactly as before", "all checks passed"), found in both logs, and exit 0. audit, audit-ppt, audit-other,
  audit-recon, audit-hostile and audit-inject print ALL CHECKS PASSED on both.
- **S-audit-recon-c1 (7:53 PM) ran audit-recon blob `3616efcb`.** That is the block before a comment-only edit (the
  "FAILS ON" line now names `d66dd60` and the 14/31 count). The final blob `9c2cdd88` was re-run whole as
  **S-audit-recon-c1-final** (8:00 PM ET, exit 0, 295.9 s, ALL CHECKS PASSED). The focused F1-* and M-* runs used the
  harness before that edit (`02b53ec8`). The F2-* runs are the final ones (harness `e4770166`, built verbatim from the
  final suite): c1 31/31; base 17 pass, 14 fail; every mutant caught.
- The first FI-* runs exited 1 in about 2 s, before any check, because jsdom could not be found from the harness folder.
  A `node_modules` symlink was added to `harness/c1/`, and FI2-* are the real runs.
- probe-base-1 exited 1 because the probe called buildSavedHtml while the locked view was still on screen.
  The probe was fixed to leave the view, and probe-base-2 is the reproduction.
- The AUDIT_IMPORT_RUNNING lock was never present, so no run waited.
- **Deviations from "every command bounded by setsid -w timeout -k 10 600":** three non-node commands. The first look
  at this folder (ls/cat/grep, 7:31 PM) was unbounded. Two wait loops (`timeout 1500 bash -c 'until grep …'` and
  `timeout 290/580/170 bash -c …`, sleeping on file checks) were bounded by `timeout` but not by setsid; the first had a
  1,500 s cap (it ran about 7 minutes). The background batch wrappers were capped at 7000 s and 3000 s around many 600 s runs. Every node run
  itself went through run.sh. The PIDs I could see are in `pids.txt`.

---

# Fix round (13 Oct)

> **SUPERSEDED IN PART by "Fix round 2 (13 Oct)" below.** Its board `fr/c1` is no longer proposed (verification round 2,
> money M1); its runs and drafts are kept as the record of that build.

Builder, fix round after verification round 1. Resumed at 4:12 AM ET on 13 Oct, after the container restarted at 4:11 AM ET.
This section was written from 5:24 AM ET on. All times are Eastern (`TZ=America/New_York date`).

## The current proposal: ONE commit, revised
`1: v2.00 (U32, U33): an RCN / EEIC list that repeats a key, or holds "__none__" or a key that is not text, never counts money
twice; a file handed over with one is refused, the user's own board is taken and says so | copy fr/c1 | board
19e6e5089ab801dcd4e4777c794fa82992f0c28d | suites audit-recon 089703716ac470a6d5ce3114eccd8b5d478c32fe (audit-import 4aba2506,
audit-board a7c575e5, audit-other d89396b0 unchanged) | mutate 0cfd2487af96ee0a731a723ce24b50c9231bb179`

It replaces the c1 commit; c1 is kept on disk for the record.

**Why it is still one commit:** c1 was never committed. Committing it and then this fix as a second commit would put a commit
in the history that freezes a shared folder (M2). It would also mean editing c1's own checks in the second commit. One
reviewed commit is the smaller unit. `fr/c1` = base + this commit (`cp -a c1`, node_modules a symlink, `chmod -R u+w`, the
board edited by `fr/bin/edit-board.py`). Its audit-recon and mutate.mjs.txt are rebuilt from the BASE files by
`fr/bin/assemble-suites.py`: the new block goes after `// ==== end v2.00 (U14) ====`, and the new entries go before the R3
comment line. `diff -rq ../base fr/c1` lists only those three files.

| file | base blob | fr/c1 blob | diff vs base | delta vs c1 |
|---|---|---|---|---|
| prioritization-board-grid.html | fce8a391 | 19e6e5089ab801dcd4e4777c794fa82992f0c28d | `diffs/fr-c1-board.diff` (-14 +95) | `diffs/fr-delta-vs-c1-board.diff` |
| tools/export-audit/audit-recon.mjs | 529e36f7 | 089703716ac470a6d5ce3114eccd8b5d478c32fe | `diffs/fr-c1-audit-recon.diff` (+249, pure additions) | `diffs/fr-delta-vs-c1-audit-recon.diff` |
| tools/export-audit/mutate.mjs.txt | cbc6defc | 0cfd2487af96ee0a731a723ce24b50c9231bb179 | `diffs/fr-c1-mutate.diff` (+67, pure additions) | `diffs/fr-delta-vs-c1-mutate.diff` |

All three diffs against base are concatenated in `diffs/fr-c1-all.diff`. The block is `fr/blocks/block-cycreg.mjs.txt`
(7509c3e1), and the entries are `fr/blocks/entries-cycreg.mjs.txt` (075307cf, written by `fr/bin/mkentries.py`, a10f2165).

## What I kept from the stopped attempt (12:44–12:48 AM ET)
The stopped attempt left `fr/bin/edit-board.py` (470e4cdd), a partly edited copy `fr/c1` (board d3be5286), and
`fr/delta-board-vs-c1.diff`. It ran nothing (`logs/` and `runs.txt` have no entry after 8:08 PM ET on 12 Oct), and it had no
Fix round section. All three are kept, unchanged, in `fr/stopped/` (the copy as `fr/stopped/c1-partial`).

**Kept:** its design, which follows both verifiers' sketches:
- one helper for the list rule;
- the team's copies and the user's own board are not held to it;
- true refusal words;
- monSheet takes text keys only;
- the panel marks a repeated row, and Remove removes that row alone.

**Rewritten:** the script itself (`fr/bin/edit-board.py`, now 7d686a7a). Three things were unsound or incomplete:
1. Its own-copy switch stayed set after the check it was asked for. It is now read by `inboundCheck` for that one check only.
2. The shared folder still refused an entry that is not one. That would freeze a folder too (M2), so the folder and the sidecar
   now skip the new rule entirely, as on base.
3. The full import named only the first problem in each list. It now names every one, up to five per list, and gives
   "3 times" where a key is repeated more than twice.

I wrote the block, the entries, the probes and the drafts new.

## What was wrong, and the fix for each finding
**M1 (money; both verifiers): 1 beside "1" was one bag counted twice.**
- monSheet now keeps only text keys, each once, and builds `known` from those. A bag is found by name, so text keys are the
  only ones whose names cannot collide.
- The sheet now labels a row with the entry the screen shows (rcnEntry's strict text match). The verifier's "unique by
  String(k)" sketch labelled R1 11111/AAAAA while the screen said 22222/BBBBB.
- The door refuses a key that is not text, and an entry with no key, in a file handed over.

**MUST-FIX 2 (tests): two money paths had no check.**
- The block now covers the working plan's own list (opened, imported, reopened, saved) and the NOT FUNDED Ask, each with a
  control.
- New mutations: `-notfunded-repeat` (the tests verifier's vm-pk-dup) and `-keys-cycle-only` (uniqueness only while a cycle is
  on screen, a stand-in for vm-dedupe-at-view).

**M2 (data): the shared folder froze.**
- `driveParse` and the sidecar read (`loadShared`) now call `inboundCheckOwn(txt, 'copy')`, which skips the RCN / EEIC rule.
  Every other door rule still applies.
- Both are now read exactly as on base.

**M3 (words, and the upgrade route): the full import refused the user's own board as "never written by ORBIT".**
- `fullImportText` asks for mode `'board'`. The user's own board comes across with its lists as saved.
- The import question and the report on the reopened board say what each list holds.
- Only an entry that is not an object is still refused: every reader of the list stops at it.
- `inRefuse` gives every RCN / EEIC refusal true words. It says an earlier ORBIT took such a list and could save it, how a
  user's own board comes across, and that an unlocked list can be put right in 🗂 RCN / EEIC.
- The generic "written by ORBIT never carries that" tail is unchanged for every other refusal, byte for byte.

**S1 (null entry):**
- An entry that is not an object is refused in a file handed over and by the full import.
- The team's copies take it as base did. Refusing there could freeze a folder.

**S2 (lossless repair):**
- On the 🗂 RCN / EEIC panel, a row that repeats an earlier row's key reads "⚠ repeats row N" under Used by.
- ✕ on that row asks "It has the same key as row N (…), and every assignment to that key reads row N, which stays. No
  assignment is changed." It then removes that row alone.

**S3 (sidecar words):**
- The sidecar is no longer refused for the RCN / EEIC rule, so this rule never reaches "No shared state file found".
- That wording for other refused sidecar files predates this track and is unchanged ("not done").

**Minor findings:**
- A key that is not text is now named by type ("rcn[0].k is the number 1").
- The import checks now exercise a reopened import, because the import is taken.
- The drafts are rewritten (see below).

## How the change meets the lead's principles
1. **Never lose any copy of anyone's work.**
   - Nothing is ever re-keyed, dropped or rewritten. A list is either taken whole, as saved, or refused whole with storage
     byte-identical (checked).
   - The two places where refusing would lose work, the team's folder copies and the user's own board on a new version, are
     not refused, and the full import says what it took.
   - Two entries with one key are both kept, and said (principle 1's "keep both and say"): in the import question, on the
     reopened board, and on the panel.
   - Removing a repeated row changes no assignment.
2. **Refuse or ask rather than guess.**
   - A file handed over is refused, not repaired.
   - The full import already asks before replacing anything, and the question now says what the lists hold.
   - Which entry a key means is not guessed: every reader already takes the first, as every ORBIT has, and the sheet now does
     too.
3. **Money and every export match the computation.**
   - The RCN-EEIC sheet (rollup, breakout, NOT FUNDED) counts each text key once, and money on no combination once.
   - The bytes are read on every route against hand literals: 900 / 200 / 1,100 and the NOT FUNDED Ask 900 / 200.
   - The other walks of the list were checked by reading in the 12 Oct record (only monSheet sums money by walking it). That
     is unchanged.
4. **Every word stays true, including after the operation lands.**
   - The untrue "never written by ORBIT" no longer reaches these lists.
   - The full import says what it took both before and after the reload (the reopened board's status is checked).
   - The panel says a repeated row repeats.
   - The drafts' untrue sentences are gone. c1's "refused by another board's door until the list is corrected" and "a list the
     board already holds … is counted right" were both untrue.
5. **The smallest change.**
   - The board diff is -14 / +95 against base: one helper, a three-way mode on the existing door, the words, two monSheet
     lines, and the panel and Remove branch.
   - Nothing else in the import routes changed.
6. **Every existing check, fixture and expected value is preserved.**
   - No base check, fixture or expected value is edited. The audit-recon and mutate diffs against base are pure additions.
   - Every base mutation entry still matches exactly once (mcount below). The door line that `door-full-open` finds is kept
     byte-identical (the mode is set on the line before it).
   - c1's own block and entries were never committed. Their changed expectations are listed here anyway:

| c1 file:line | old expectation | new expectation | why |
|---|---|---|---|
| c1 audit-recon.mjs:5187 | `TAIL` = the generic "…written by ORBIT never carries that…" | `LIST_TAIL` / `ENTRY_TAIL` (the words above) | M3: the old words are untrue for these lists |
| c1 audit-recon.mjs:5192 | Codex 2 door: "the RCN / EEIC key at …rcn[1].k “__none__” begins with two underscores, which the board keeps for its own bookkeeping" | "the RCN / EEIC list at …PB\|2027.rcn holds the key “__none__” (rcn[1]); a key beginning with two underscores is one the board keeps for its own bookkeeping" | every list refusal now starts "the RCN / EEIC list at", so inRefuse can give the true words |
| c1 audit-recon.mjs:5210 | Codex 1 and 2, Import a full board: refused whole, storage byte-identical | taken, and the question and the reopened board say what the list holds (exact line) | M3: the user's own board on a new version |
| c1 audit-recon.mjs:5213 | CONTROL "taken … writes the plan and the cycles" | CONTROL "taken, and the question says nothing about the lists" (plus the plan and cycles written) | the same route, now also checked for silence |
| c1 audit-recon.mjs:5233–5235 | the working plan's list at the door (two checks, own section) | the same refusal string and control, now inside the working-plan cases | folded in, not changed |
| c1 mutate.mjs.txt:4289, 4295, 4298 | finds on c1's lines | finds on the new lines (`keys-repeat` follows the text-only filter; `door-repeat` / `door-underscores` follow `rcnListOdd`) | the code they mutate moved |

## The block: 90 checks (audit-recon "v2.00 (CYCREG) — …")
**Literal money:**
- funded: USAF 900, ANG 200, AFRC 0, all services 1,100, in the award month and in TOTAL, NO DATE 0, and every service total in
  the breakout;
- NOT FUNDED: Ask USAF 900, ANG 200, with every total 0.

**Cases and routes:**
- Codex 1 [K1, K1] and Codex 2 [K1, "__none__"] in PB27's own list: all seven routes (door, Import one appropriation, full
  import, reopened, saved-reopened, opened, opened-saved).
- Their two ordinary-key controls: all seven routes, and all but Import one appropriation, respectively.
- R1 on the entry named "__none__", with its control.
- The working plan's [K1, K1], with its control.
- The working plan's [1, "1"], with its control.
- PB27 locked before v1.99 reading [1, "1"], with its control.
- NOT FUNDED on [K1, K1], with its control.
- A NOT FUNDED control with R1 on no combination. It guards the Symbol bucket's `|| !!p[NONE]`.

**Further checks:**
- an entry that is not one (door, and the full import refused);
- the door on [K1, K2, K1], [K1, K1, K1], "__x", a missing key, and `true`;
- the shared folder's copy and the sidecar read as is, with the same text handed over refused;
- the panel and ✕ on a repeated row;
- Add RCN / EEIC.

**Every new check fails on base, or is a CONTROL.**
- FR2-base: 50 fail, 40 pass. Every pass is a CONTROL or a fixture, as listed by `out/FR2-base.checks.jsonl`.
- The fails show USAF 1,800 / ANG 400 / 2,200, the NOT FUNDED Ask 1,800 / 400 ("(2 requirements)"), the door passing, the
  import taking silently, ✕ clearing R1, and the add sharing a key.
- In the WHOLE fix-round audit-recon run against the base board, exactly these 50 fail and nothing else
  (S-audit-recon-fr-suite-on-base-board).

## Mutations: 22 entries, each caught
The ids are `v200-cycreg-*`. They are inserted before the R3 comment line and built with `rec/bin/mkmut.py` (text only; each
find matched once) into `fr/mut/`, whose blobs are in `fr/mut/blobs.txt`. The failing checks for each are in
`fr/mutant-failures.txt`, and no mutant made the block throw.

The task's three are caught:
- drop the uniqueness: `keys-repeat`, 15 fail;
- let a key equal the sentinel: `none-is-text`, 6;
- drop the import refusal: `door-open`, 16.

The rest:

| entry | fails | entry | fails |
|---|---|---|---|
| keys-by-value (M1) | 6 | own-takes-entry (S1) | 1 |
| keys-cycle-only (MF2b) | 9 | own-board-refused (M3) | 13 |
| notfunded-repeat (MF2a) | 2 | own-board-unsaid (M3) | 10 |
| none-money-unseen | 8 | folder-refused (M2) | 1 |
| none-ask-unseen (verifier's should-fix) | 1 | sidecar-refused (M2/S3) | 1 |
| door-repeat | 11 | refusal-untrue (M3) | 4 |
| door-adjacent (verifier's vm-door-adjacent) | 1 | repeat-row-clears (S2) | 1 |
| door-underscores | 5 | repeat-row-unsaid (S2) | 1 |
| door-sentinel-only (verifier's vm-door-eq-sentinel) | 1 | add-key-reused | 1 |
| door-not-text (M1) | 8 | | |

**mcount (text only, `python3 -I rec/bin/mcount.py`; mutate.mjs never imported or run):**
- fr/c1 mutate on the fr/c1 board: 1350 entries, 1350 once.
- base mutate on the fr/c1 board: 1328 once.
- base mutate on the base board: 1328 once.

## Every fix-round run
Each node run went through `bin/run.sh`: the lock is checked first (it was never present, so no run waited), then
`setsid -w timeout -k 10 600`. The records are in `logs/runs.txt`, and the PIDs, with their commands, are in `pids.txt`.

| label | start (ET, 13 Oct) | exit | wall s | log | result |
|---|---|---|---|---|---|
| FR-probe-base-1 | 4:26:34 AM | 0 | 20.8 | logs/FR-probe-base-1.log | base: WP-dup, W1, P1 and C2b export 1,800 / 400 / 2,200; NF-dup Ask 1,800 / 400; door passes all |
| FR-probe-fr-1 | 4:26:34 AM | 0 | 21.7 | logs/FR-probe-fr-1.log | fix: every shape 900 / 200 / 1,100 (NF 900 / 200); door words; folder copy read |
| FR-probe2-fr-1 | 4:28:46 AM | 0 | 16.1 | logs/FR-probe2-fr-1.log | fix: full import taken, question and reopened report say the list; Import one appropriation refused; null refused; sidecar read; ✕ keeps R1 |
| FR-probe2-base-1 | 4:28:46 AM | 0 | 16.7 | logs/FR-probe2-base-1.log | base: everything taken silently; ✕ clears R1 |
| FR1-fix / FR1-base | 4:34:36 AM | 0 / 1 | 94.0 / 93.2 | logs/FR1-*.log | the first focused run, harness b9eabe43 (the block before its comment-only FAILS ON count was written in): 90/90; 50 fail |
| **FR2-fix** | 4:36:51 AM | 0 | 174.6 | logs/FR2-fix.log | final harness 393bc9c6 (every FR2 run records it): **ALL CHECKS PASSED, 90/90** |
| **FR2-base** | 4:36:51 AM | 1 | 174.1 | logs/FR2-base.log | **50 FAILING, 40 pass** |
| FR2-mut-* (22) | 4:36:51 to 4:45:46 AM | 1 each | 127.8–182.6 | logs/FR2-mut-*.log | every one caught (table above) |
| FR-vprobe-fix, -vprobe2, -vprobe3, -vprobe4, -vprobe5, -vprobe6 | 4:48:20 AM | 0 each | 31.5, 26.2, 29.8, 19.9, 22.2, 17.4 | logs/FR-vprobe*-fix.log | the money verifier's own probes, unchanged (blobs as theirs): M1 shapes 900 / 200 / 1,100 on every route; M2 every folder save, refresh, pen and teammate save lands; M3 a board saved by base ORBIT with [K1, K1] comes across; S1 null refused |
| S-audit-recon-fr | 4:49:35 AM | 0 | 245.0 | logs/S-audit-recon-fr.log | ALL CHECKS PASSED (the whole suite, with the new block) |
| S-boot-same-fr | 4:49:35 AM | 0 | 22.3 | logs/S-boot-same-fr.log | "every page, source, save and error list is identical either way" |
| S-audit-fr | 4:49:58 AM | 0 | 23.7 | logs/S-audit-fr.log | ALL CHECKS PASSED |
| S-audit-ppt-fr | 4:50:21 AM | 0 | 10.5 | logs/S-audit-ppt-fr.log | ALL CHECKS PASSED |
| S-legacy-fsrc-fr | 4:50:32 AM | 0 | 5.6 | logs/S-legacy-fsrc-fr.log | "every legacy Force setting computes exactly as before" |
| S-audit-inject-fr | 4:50:38 AM | 0 | 14.6 | logs/S-audit-inject-fr.log | ALL CHECKS PASSED |
| S-audit-other-fr | 4:53:50 AM | 0 | 65.0 | logs/S-audit-other-fr.log | ALL CHECKS PASSED |
| S-audit-hostile-fr | 4:53:50 AM | 0 | 120.0 | logs/S-audit-hostile-fr.log | ALL CHECKS PASSED |
| check-fr | 4:53:50 AM | 0 | 7.3 | logs/check-fr.log | "all checks passed" |
| FRI-v186-fix | 4:57:28 AM | 1 | 3.3 | logs/FRI-v186-fix.log | **not a result**: the harness did not compile ("failures already declared"); see "not done" |
| FRI-w1-fix / -base | 4:57:28 / 5:11:00 AM | 0 / 0 | 142.2 / 85.5 | logs/FRI-w1-*.log | audit-import "v1.95 W1" (folder), focused: ALL PASSED on both (53 checks) |
| FRI-w2-fix / -base | 4:57:28 / 5:11:00 AM | 0 / 0 | 400.9 / 163.5 | logs/FRI-w2-*.log | "v1.95 W2" (full import) including "v1.96 review": ALL PASSED on both (242 checks) |
| FRI-v197w1-fix / -base | 5:04:55 / 5:11:00 AM | 0 / 0 | 57.1 / 41.9 | logs/FRI-v197w1-*.log | "v1.97 W1": ALL PASSED on both (15) |
| FRI-v197w3-fix / -base | 5:04:55 / 5:13:44 AM | 0 / 0 | 355.4 / 264.4 | logs/FRI-v197w3-*.log | "v1.97 W3" (several boards, folder history): ALL PASSED on both (111) |
| FRI-v200-fix / -base | 5:04:55 / 5:13:44 AM | 0 / 0 | 255.0 / 184.1 | logs/FRI-v200-*.log | v2.00 R3 to U13 (folder saves): ALL PASSED on both (167) |
| FRB-v197w1-fix / -base | 5:19:05 AM | 0 / 0 | 56.9 / 56.4 | logs/FRB-v197w1-*.log | audit-board "v1.97 W1" (rcnSet), focused: ALL PASSED on both (178) |
| FRB-83-fix / -base | 5:19:05 AM | 1 / 1 | 18.0 / 14.8 | logs/FRB-83-*.log | audit-board "v1.98 item 83": 3 scenarios ran and passed on both; the 4th needed `_v7w4Mark` (harness, not product) |
| FRB2-83-fix / -base | 5:20:25 AM | 1 / 1 | 10.6 / 10.3 | logs/FRB2-83-*.log | with `_v7w4Mark` added: 4 of 5 scenarios ran, 21 checks, all pass on both, including "removing a combination clears every pointer at it" (rcnDel, 4/4); the 5th needs `w4Template` (harness, identical on both) |
| S-audit-recon-fr-suite-on-base-board | 5:20:57 AM | 1 | 205.8 | logs/S-audit-recon-fr-suite-on-base-board.log | the WHOLE fix-round audit-recon with BOARD = base: 50 FAILING, every one in the CYCREG block; every other block passes |

**How the harnesses were built (all verbatim slices):**
- The audit-recon harness, `fr/harness/h-cycreg.mjs` (393bc9c6; b9eabe43 before the comment-only count edit), was built by `rec/L3/u14/mkfocused.py` from fr/c1's suite.
  The block is in it byte for byte (checked).
- The audit-import harnesses `gc/fr/tools/export-audit/hi-*.mjs` were built by `rec/L2/u2impl/mkfocused-u2.py`. hi-w1 is
  310b30b8, byte-identical to the verifier's.
- The audit-board harnesses `hb-*.mjs` were built by `fr/bin/mkfocused-board.py` (6c9729b3). It copies the preamble, the block,
  any named extra lines and the guard, all verbatim.
- `gc/fr` is a scratch `git clone --shared /home/user/orbit-board` at 7ee498a, with the fix's board and audit-recon copied in
  (`runtime-encoding-shim.mjs` was copied in for the runner). It was never committed to.

**Base parity for the other suites:** the builder's 12 Oct base runs (gc/base, 8:00–8:08 PM ET, every one passing) stand.
Base's files are unchanged, so I did not re-run them.

## Decisions, with reasons
- **The full import takes the user's own board with such a list, and says so; it does not refuse it or rewrite it.**
  - Refusing kept a whole board, saved by ORBIT itself, out of the new version (M3). Base's rcnAdd could write a repeated key
    by itself: two adds in one millisecond after a removal (proved on 12 Oct).
  - Normalizing would mean re-keying entries inside locked cycles and moving pointers in their frozen years. That changes
    locked records, and it guesses.
  - Taking it as saved changes nothing, and the export is now right for any list.
- **Files handed over are still refused.** This is the lead's default. The sender can put an unlocked list right losslessly
  with ✕ on the repeated row, or bring their own board across with the full import, and the refusal says both.
- **The team's folder copy and the sidecar are fully exempt from the new rule** (null entries included), so this route is
  exactly as on base. Any refusal there freezes every save.
- **The full import still refuses an entry that is not an object.** The base board then throws on export, on the panel and on
  every RCN label, so taking it would bring a board that cannot export. No ORBIT makes one.
- **Text keys only in monSheet, not "unique by String(k)".** This keeps the sheet's row label equal to what the screen shows.
  The one case it leaves is a NUMBER assignment, which only a hand-made file holds ("not covered").
- **A Write-tool quirk.** It turned the board's backslash-u escapes into characters in my edit script. The three affected
  panel lines are converted back by `U()` in the script, and the diff shows the board's own escapes unchanged.

## Process notes (read before trusting a line above)
- **A safety check stopped two of my commands. Neither ran anything.**
  - The first was a batch that ran `bin/fr.sh` through `bash -c`. `fr.sh` contains `rm -f` of the run's own checks file.
  - The second was a `bash -c` with unresolved variables, which held no removal.
  - I did not route around the removal. `fr/bin/frr.sh` is `bin/fr.sh` with that one line replaced by a truncation of its own
    new output file (every fix-round label is new), and I called it directly.
- **Bounding.**
  - Every node run went through run.sh (`setsid -w timeout -k 10 600`).
  - The text helpers (edit-board, mkentries, assemble-suites, mkfocused*, mkmut, mcount) and the `git clone` / `git show`
    reads ran under `setsid -w timeout -k 10 600` directly. Their PIDs were not recorded in `pids.txt`.
  - Read-only `ls`, `cat`, `grep`, `sed -n`, `diff` and `git hash-object` ran unbounded.
  - The wait for the last background run used `timeout 500` (not setsid) around a 15-second `sleep` loop on its log.
- **One heredoc slip.** An unquoted heredoc made the shell try to run the words `fr/c1` and `c1` from the banner text, as
  commands. Both failed ("No such file or directory", "command not found"), and nothing was changed except the banner, which I
  repaired.
- **Killed nothing.** Every run ended on its own, and none hit its cap.

## What I did not do
- I did not run the full `audit-import.mjs` or `audit-board.mjs`; the lead runs those alone.
  - audit-import's v1.86 old-file full imports (git show 68b02e9, 84dcaf9, 77882d9, 1589749) are not run: my focused build of
    that unmarked region did not compile.
  - By reading, it cannot reach this change. Lines 3140–3736 never set an RCN list. Every older ORBIT's Add RCN / EEIC writes
    object entries with text keys (checked in each revision with `git show` in gc/fr). For the user's own board, the full
    import now refuses only an entry that is not an object, which no ORBIT writes.
  - audit-board ran only as the two focused blocks above.
- I did not import, execute or run `mutate.mjs`. It is text only to mkmut.py and mcount.py, and the scratch clone's own
  mutate.mjs was never touched.
- No Chromium and no playwright install. Every check is jsdom.
- Nothing was edited, staged, committed or pushed in /home/user/orbit-board or /home/user/orbit-ui. The scratch clone gc/fr was
  never committed to. The board stays the empty template, with synthetic data only at run time.
- **Not built:**
  - a notice when a board that holds such a list opens (the panel says it, the export is right);
  - a way to put a locked cycle's list right;
  - ✕ on the FIRST row of a repeated key still clears every assignment to it, as its question says;
  - the pickers and "N combos" list repeated rows as they are;
  - S3's wording for other refused sidecar files is unchanged;
  - a board already holding a null entry, or a file with one opened directly, still throws on export, as on base.
- **Not driven by the block:** ⇊ Import several boards, packages, submittals and band ladders. They run the same door; by
  reading, every caller of `inboundCheck` besides the three own-copy ones gets the full rule.

## Drafts for the lead (fix round; they SUPERSEDE `drafts/*.md` and `drafts/COMMIT-MSG.txt`)
- `drafts/fr/NEXT-VERSION-entry.md` (1968070c): the v2.00 entry, after the U14 bullet.
- `drafts/fr/UNRESOLVED-line.md` (2b2f2f95): base has no U32/U33 line, so this is a proposed NEW line. It names Brad's open
  question: a locked cycle's list cannot be put right.
- `drafts/fr/LEDGER-append.md` (0f305934): text for rows U32 and U33, with `<sha>` and `<time>` placeholders.
- `drafts/fr/COMMIT-MSG.txt` (311a8570): the lead adds the attribution lines.

The 12 Oct drafts are kept as they were. Three of their sentences are untrue for the 12 Oct build and superseded:
- "counts each key once": 1 beside "1" doubled;
- "a list the board already holds … is counted right": 1 beside "1" was not;
- "refused by another board's door until the list is corrected": a corrected board could not save to the folder.

## Fix-round file identities (git hash-object)
- `fr/bin/edit-board.py` 7d686a7a
- `fr/bin/mkentries.py` a10f2165
- `fr/bin/assemble-suites.py` fbaef9a4
- `fr/bin/mkfocused-board.py` 6c9729b3
- `fr/bin/frr.sh` f961b193
- `fr/probe/frprobe.mjs` 82acc731
- `fr/probe/frprobe2.mjs` 2b4a5e21
- `fr/probe/verifier/vprobe*.mjs`: 3f06a07b, 35366793, 6c44dea9, 805d7239, 1ee09b91, 910e2fe1 (copied unchanged from
  `verify-money-r1/probe/`)
- `fr/harness/h-cycreg.mjs` 393bc9c6 (the FR2 runs; FR1 ran b9eabe43)
- the stopped attempt: `fr/stopped/edit-board.py` 470e4cdd, `fr/stopped/delta-board-vs-c1.diff` a3838923,
  `fr/stopped/c1-partial` board d3be5286

# Fix round 2 (13 Oct)

Builder, fix round after verification round 2 (money and tests lenses, both "sound with issues", one must-fix each). Two
attempts: the first ran from 11:00 AM ET and was stopped by the lead at about 11:45 AM ET to lower the machine's load (its
last runs ended at 11:51 AM ET); this one resumed at 11:57 AM ET, after none of that attempt's processes was still running.
This section was written from 12:38 PM ET on. All times are Eastern (`TZ=America/New_York date`).

**Where this leaves the record:** "Fix round (13 Oct)" above is superseded wherever this section says otherwise. Its board
`fr/c1` (19e6e508) is no longer proposed: verification round 2 showed its RCN-EEIC sheet printed a requirement on the number 1
under the wrong codes (or as not assigned). Its runs, probes and drafts are kept as they were, as the record of that build.

## The current proposal: ONE commit, revised again
`1: v2.00 (U32, U33): an RCN / EEIC list that repeats a key, or holds "__none__" or a key that is not text, never counts money
twice; a file handed over with one is refused, the user's own board is taken and says so | copy fr2/c1 | board
59cff8f34a04d656604c352909966b27998f7384 | suites audit-recon 03b7fda90c0a3dd6f90e02b19d731ebc6d7bd16d (audit-import
4aba2506, audit-board a7c575e5, audit-other d89396b0 unchanged) | mutate 755c298941d34f83c52ee765d931f6345cd8d652 | message
drafts/fr2/COMMIT-MSG.txt`

`fr2/c1` = base + this commit: a `cp -a` of `fr/c1` (node_modules a symlink, `chmod -R u+w`), its board edited by
`fr2/bin/edit-board2.py` (c8e282c2), its audit-recon and mutate.mjs.txt rebuilt from the BASE files by
`fr/bin/assemble-suites.py` (the block after `// ==== end v2.00 (U14) ====`, the entries before the R3 comment line).
`diff -rq ../base fr2/c1` lists only these three files; `fr2/bin/check-assembly.py` confirms, as text, that audit-recon = base +
the block and mutate = base + the entries, and that the focused harness carries the block byte for byte.

| file | base blob | fr2/c1 blob | diff vs base | delta vs fix round 1 (`fr/c1`) |
|---|---|---|---|---|
| prioritization-board-grid.html | fce8a391 | 59cff8f34a04d656604c352909966b27998f7384 | `diffs/fr2-c1-board.diff` (+101 −14) | `diffs/fr2-delta-vs-fr-board.diff` |
| tools/export-audit/audit-recon.mjs | 529e36f7 | 03b7fda90c0a3dd6f90e02b19d731ebc6d7bd16d | `diffs/fr2-c1-audit-recon.diff` (+295 −0) | `diffs/fr2-delta-vs-fr-audit-recon.diff` |
| tools/export-audit/mutate.mjs.txt | cbc6defc | 755c298941d34f83c52ee765d931f6345cd8d652 | `diffs/fr2-c1-mutate.diff` (+91 −0) | `diffs/fr2-delta-vs-fr-mutate.diff` |

All three diffs against base: `diffs/fr2-c1-all.diff`. The block is `fr2/blocks/block-cycreg.mjs.txt` (656d9bec), the entries
`fr2/blocks/entries-cycreg.mjs.txt` (1d0309bf, written by `fr2/bin/mkentries3.py`, 68992a5f). The only change this attempt made
to the stopped attempt's files is the removal of one mutation entry (`diffs/fr2-resume-mutate-vs-stopped.diff`, below).

## What I kept from the stopped attempt (11:00–11:51 AM ET)
I read everything it left before using any of it, and checked every identity:

- **Kept, unchanged:** the board `fr2/c1` (59cff8f3) and `fr2/bin/edit-board2.py`; the block (656d9bec, `fr2/bin/mkblock2.py`
  f8fa17f4) and the assembled audit-recon (03b7fda9); the final focused harness `fr2/harness/h-cycreg.mjs` (26a9ee0c, built by
  `rec/L3/u14/mkfocused.py`, carrying the block verbatim); the 31 mutants in `fr2/mut/`; every run with an exit record (below);
  the round-2 verifiers' probes, copied unchanged (pa, pb, pb2, pc, pd byte-identical to `verify-money-r2/probe/`); the
  independent XLSX reader `fr2/bin/xread.py` and its probe `fr2/harness/p2.mjs`.
- **Re-checked before keeping:** I rebuilt all 30 remaining mutants from the final mutate text with `rec/bin/mkmut.py` into
  `fr2/mut2/`; every blob is identical to the one the stopped attempt ran (`fr2/mut2/blobs.txt`). Every FX3 mutant log records
  that blob and harness 26a9ee0c. FX3-fix and FX3-base record board 59cff8f3 / fce8a391 and harness 26a9ee0c.
- **Read for soundness** (the review is under "The board change, reviewed" below): rcnAt, the monSheet lines, the door's
  three modes, the cycle-path rule for a null entry, the full import's statement, the advice text, rcnBody/rcnDel/rcnAdd.
- **Unsound, and fixed here:**
  1. `v200-cycreg-at-last` survived 142 of 142 (FX3-mut-v200-cycreg-at-last, exit 0). It is an **equivalent mutant**, not a
     gap: the sheet labels a row with `rcnLabel(e.k)`, which finds the FIRST entry with that key, so reading a repeated key at
     its first or its last index gives the same rows, in the same order, under the same labels, with the same money. It is
     removed from the entries (`fr2/bin/drop-at-last.py`, then `mkentries3.py` and `assemble-suites.py`): 30 entries.
  2. `v200-cycreg-clin-by-name` also passed the focused block (FX3, exit 0). The stopped attempt tried to show it caught by
     audit-recon's own CLIN blocks with a focused build (`fr2/harness/h-8388.mjs`), but that build threw on the FIX too
     ("headerRow is not defined", FX2-8388-fix), so it proved nothing on its own. I ran the WHOLE audit-recon on the mutant
     instead (below).
  3. Two suite runs never finished: S-audit-recon-fr2 hit its 600 s cap (exit 124) and S-audit-hostile-fr2 was killed (exit
     137, "Killed" in `fr2/out/suites.out`). Both re-run here.
  4. The drafts named `-at-last` and "31 entries", left the `-clin-by-name` proof "in the final-tree queue", and dated the
     verification rounds with time ranges I could not confirm. Edited (`fr2/bin/edit-drafts3.py`); the stopped attempt's
     drafts are kept in `drafts/fr2/stopped/`.
- **A rule the stopped attempt broke:** it ran up to **seven** node processes of this track at once (11:21:11 AM ET, from
  `logs/runs.txt`): four mutant lanes (`fr2/bin/lane.sh`, `fr2/mut/lane-00`..`03`) beside the probes and the suites. The rule is
  at most two. Its results are deterministic and every one I kept has an exit record, so I kept them rather than spend the
  machine's time again; the two runs the load cut short are re-run. This attempt never ran more than two (two lanes, each
  serial, `fr2/bin/resume-lane1.sh`, `resume-lane2.sh`, and `resume-lane1b.sh`, which starts only after lane 1's last run).

## Each verifier finding and what closes it
**Money M1 (must-fix): a number key or pointer was filed under the wrong code, or as not assigned.** The money verifier's
sketch 2, taken as proposed:
- `rcnAt(p)` (new, beside the RCN-EEIC sheet's caller in exportExcel): the first entry whose key `===` the pointer, as `rcnEntry`,
  the screen and the Spend Plan Source find it, named `'e'+index`; `''` when none is. The list (`keysOf`), each requirement
  (`keyOfReq`) and each CLIN (`clinOf`) reach monSheet through it, and `labelOf` prints that entry's `rcnLabel`.
- monSheet is base again except the one line that keeps each key once (`const keys=…filter(… a.indexOf(k)===i)`) and its three
  walks (rollup, breakout, NOT FUNDED). The Symbol, the text-only filter and the changed `known` line are gone.
- Why it closes the finding: no row name is ever a list key, so no key can be the not-assigned row (`'__none__'`) or a name
  every object answers to (`constructor`); a repeated key is one row; 1 and "1" are two rows only when both are listed, and each
  pointer sits under the codes the screen shows (B1 [1] with R1 on 1 → 11111 / AAAAA, as d66dd60; B2 [1, "1"] with R1 on 1 →
  11111 / AAAAA; B3 ["1"] with R1 on 1 → not assigned) — FX3-pb2-fr2, and from the bytes in the block.
- Checks: GUARD "[1] alone, R1 on the number 1" (passes on d66dd60, failed on round 1's board); "[1, "1"], R1 on the number 1";
  "[1] alone, R1 on "1"" (not assigned); "a hand-made file … keyed "constructor"" (d66dd60's export threw).

**Tests MUST-FIX 1: a changed money line (`known`) had no check.** That line is base again (`const known={};
keysOf().forEach(…)`), so no changed monSheet line is left unguarded; the verifier's case ("the working plan lists the number 1
alone, R1 on "1"", routes door, full, reopened, saved, opened, opened-saved) is in the block. Their proposed mutation
(`known` built from `keysOf()`) has no text to find any more: on this board that IS the line.

**Money S1: the full import refused the user's own board for a null entry in a LOCKED CYCLE's list.** In 'board' mode the door
applies the entry rule only to a list whose path is not `…cycles.<key>` (`/\.cycles\.[^.]+$/`); a cycle's list is read through
`cycRcnOf`, which leaves such an entry out, as since v1.99. The full import's statement names it: "O&M PB27’s list holds rcn[0],
which is not a combination (“null”)". Check: GUARD "PB27’s list holds null, then K1" (door refused; full import taken and said;
reopened; saved; opened; 900 / 200 / 1,100 from the bytes). Mutation `-own-cycle-entry-refused` (2 checks fail).

**Money S2: the refusal's advice sent a one-appropriation file to a whole-board replace.** The advice now says: "A whole board of
your own comes across with its lists as they are by 📁 File → ⬅ Import a full board, which says first what they hold. That
replaces this board’s whole BAE list and execution data with the file’s, when it carries them, so it is not the way to take one
appropriation." Checked word for word in every refusal (`LIST_TAIL`); FX3-pd-fr2 shows the alert on the verifier's file.
Mutation `-advice-unwarned` (5 fail).

**Money minors:** `constructor` / `toString` / `valueOf` keys no longer break the export (FX3-pc-fr2: 900 / 200 with all
three). Not built: the menu's "N combos" count and the pickers still list a repeated key's rows. PPBE "+ add an RCN / EEIC line"
(ppLineAdd) keeps the same-millisecond key pattern; PPBE totals de-duplicate keys (`ppKeysOf`), so no total doubles (read, not
run). The text helpers' PIDs are now recorded (`bin/bx.sh`).

**Tests S1–S4:** S1 ✕ on the FIRST of two rows with one key, as d66dd60 (CONTROL; mutation `-first-row-alone`, 1 fail). S2 ⇊
Import several boards for both Codex shapes and their controls (mutation `-several-own-board`, 2 fail). S3 four adds in one
millisecond, two removed, one more: three keys (mutation `-add-steps-once`, 1 fail). S4 the full import names every problem
in PB27 [K1, K1, "__none__"] (mutation `-say-first-only`, 2 fail).

**Tests minors:** M1 (the not-assigned row renamed) is now harmless by construction: no list key reaches the sheet as itself,
so any NONE name is unforgeable. M2 the sidecar's file:// (XHR) branch is changed exactly as the fetch branch but not driven
(jsdom takes fetch). M4 the counts: 142 checks, 86 fail on d66dd60. M5 the block costs roughly 20–40 s of audit-recon time.

## The board change, reviewed (fr2/c1 vs base; `diffs/fr2-c1-board.diff`)
- **The RCN / EEIC panel (rcnBody, ~L5106):** a row whose key is an earlier row's reads "⚠ repeats row N" under Used by.
- **The door (~L9539–9567, ~L9646–9652, ~L9698):** `rcnListOdd(L)` lists, in order, an entry that is not an object, a key that
  is not text, a missing key, a key beginning with two underscores, and a key held more than once (all its places). The door
  (`inShapeWhy`, reached only from `inboundCheck` → `inWalk`) refuses the first, as `the RCN / EEIC list at <path>.rcn …` or
  `the RCN / EEIC entry at <path>.rcn[i] …`, unless the check was asked for as the user's own board ('board': only an entry
  that is not one, and not in a cycle's list) or the team's own copy ('copy': none of it). The mode is read once at the start
  of `inboundCheck` and cleared, so no other check inherits it.
- **inRefuse (~L9715):** a list or entry refusal gets true words (above); every other refusal's words are byte-identical.
- **fullImportText (~L9768, ~L9816):** 'board' mode; the question, and the reopened board's report, add the list statement.
- **rcnAdd (~L10921):** a key no entry has. **rcnDel (~L10984):** a row that repeats an earlier key is removed alone; the first
  row keeps the base question and behaviour.
- **driveParse (~L26805) and loadShared (~L31689, ~L31696):** 'copy' mode, so the team's copies are read exactly as on base.
- **monSheet (~L30189, ~L30296, ~L30358, ~L30379):** the `keys` line and its three walks. **exportExcel (~L30478–30497):**
  rcnAt and the RCN-EEIC sheet's four callbacks. The SI sheet is unchanged (it walks the constant `SI_CODES`).

## How the change meets the lead's principles
1. **Never lose a copy.** A file handed over is refused whole, browser storage byte-identical (checked on ⬅ Import one
   appropriation, ⇊ Import several boards, and the full import's refusal of an entry that is not one). The user's own board
   comes across whole with its lists as saved, null cycle entries included, and says what they hold; the team's folder copy and
   sidecar are read as on base, so no save is frozen. Two entries with one key are both kept. ✕ on a repeated row changes no
   assignment; on the first row it asks first, as on base.
2. **Refuse or ask rather than guess.** Nothing is re-keyed or dropped; which entry a pointer means is the board's own rule
   (the first with that exact key), not a new guess.
3. **Money and every export match the computation.** Read from the workbook's bytes against hand literals on every route: USAF
   900, ANG 200, AFRC 0, all services 1,100 in the award month and TOTAL, NO DATE 0, every breakout service total, the NOT
   FUNDED Ask 900 / 200; and the independent Python reader (FX3-p2-fr2) gives the same for Codex 1, Codex 2, the control and the
   plan's [K1, K1] after import-and-reopen, save-and-reopen and opening. Each pointer prints under the codes the screen and the
   Spend Plan Source show. Every other rcnReg() / SI walk was checked in the 12 Oct record; none sums money.
4. **Every word stays true.** The refusal no longer says ORBIT never writes such a list; its advice says what a full import
   replaces; the full import says what it took, before and after the reload; the panel says a row repeats. The draft's round-1
   sentence "as the board finds a combination by its text key" is gone.
5. **The smallest change.** monSheet differs from base by one line and its three uses; the money fix is one helper and four
   callbacks at its one caller.
6. **Every existing check, fixture and expected value is preserved.** The audit-recon and mutate diffs against base remove 0
   lines; every base mutation entry finds its text exactly once on fr2/c1 (mcount below). Round 1's block and entries were
   never committed; what round 2 changed in them is listed below anyway.

| fr/c1 file:line (round 1, never committed) | old expectation | new expectation | why |
|---|---|---|---|
| audit-recon.mjs, LIST_TAIL (`diffs/fr2-delta-vs-fr-audit-recon.diff` lines 63–65) | "…a board of your own comes across whole, its lists as they are, with 📁 File → ⬅ Import a full board, which says what they hold; a list that is not a locked cycle’s can be put right on the board that holds it, in 🗂 RCN / EEIC." | "…A list that is not a locked cycle’s can be put right … and the file saved again. A whole board of your own comes across … That replaces this board’s whole BAE list and execution data with the file’s, when it carries them, so it is not the way to take one appropriation." | money S2: the old advice hid what a full import replaces |
| audit-recon.mjs, `ALL` routes (delta line 75) | door, one, full, reopened, saved, opened, opened-saved | the same plus `several` | tests S2 |
| audit-recon.mjs, header comment (delta lines 7–36) | "FIRST entry whose key is R1's, as text"; "50 of its 90 checks" | "the pointer exactly"; "86 of its 142 checks" | money M1; the new counts |
| mutate.mjs.txt (round 1 entries) | `keys-by-value`, `none-is-text`, `none-money-unseen`, `none-ask-unseen`; `keys-repeat` / `keys-cycle-only` / `own-takes-entry` on round 1's lines | gone (their lines are base again, or rcnAt replaces them); the three follow the new lines | the code they mutated is gone or moved |

## The block: 142 checks (audit-recon "v2.00 (CYCREG) — …")
Unchanged from the stopped attempt. Round 1's 90 checks (`fr` section above) plus: ⇊ Import several boards on Codex 1 and 2 and
both controls; PB27 [K1, K1, "__none__"] (every problem named); the GUARD PB27 [null, K1] (taken by the full import, said,
900 / 200 on every route); the working plan [K1 11111, K1 22222] with R1 on K1 (11111 / AAAAA); [1, "1"] and [1] with R1 on
the number 1 (11111 / AAAAA; the second a GUARD); [1] with R1 on "1" (not assigned); the "constructor" file; ✕ on the first of
two rows (CONTROL, as d66dd60); four adds in one millisecond. Literal money and words throughout; board helpers only for what
is observed.

**Fails on base, passes on the fix:** FX3-base (11:13:10 AM ET, exit 1): **86 fail, 56 pass**; every pass is a fixture (22), a
CONTROL (27) or a GUARD (7) — counted from `out/FX3-base.checks.jsonl`. The failures show USAF 1,800 / ANG 400 / all services
2,200, the NOT FUNDED Ask 1,800 / 400, the door, ⬅ Import one appropriation and ⇊ Import several boards taking the file, the
full import silent, the "constructor" export throwing, ✕ clearing R1, adds sharing a key. FX3-fix (11:13:10 AM ET, exit 0): **ALL CHECKS PASSED, 142 of
142.** FX4-r1 (12:33:15 PM ET, exit 1, 279.0 s, `logs/FX4-r1.log`): the same final harness on fix round 1's board `fr/c1`
(19e6e508): **17 fail**, each a round-2 finding — the five refusals by ⬅ Import one appropriation and ⇊ Import several boards
(the old advice words), the GUARD PB27 [null, K1] refused by the full import (2), [1, "1"] with R1 on the number 1 printed under
22222 / BBBBB (4), the GUARD [1] with R1 on the number 1 printed as not assigned (4), and the "constructor" export throwing (2).

## Mutations: 30 entries, each caught
Ids `v200-cycreg-*`, inserted before the R3 comment line; built with `rec/bin/mkmut.py` (text only, each find matched once).
The failing checks of each are in `fr2/mutant-failures.txt` (1f05f4fe); no mutant made the block throw. The task's three:
**drop the uniqueness** `keys-repeat` 14 fail; **let a key equal the sentinel** `key-as-name` (rcnAt returns the raw key, so an
entry keyed "__none__" is the not-assigned row again) 28; **drop the import refusal** `door-open` 24.

| entry | fails | entry | fails | entry | fails |
|---|---|---|---|---|---|
| keys-cycle-only | 8 | door-adjacent | 1 | say-first-only | 2 |
| notfunded-repeat | 2 | door-underscores | 8 | say-entry-garbled | 2 |
| at-by-name | 10 | door-sentinel-only | 1 | folder-refused | 1 |
| at-text-only | 8 | door-not-text | 17 | sidecar-refused | 1 |
| req-by-name | 44 | several-own-board | 2 | refusal-untrue | 6 |
| clin-by-name | 0 here; **11** in the WHOLE audit-recon (7 in its v1.98 item 83 blocks, 4 in v1.99 item 88) | own-takes-entry | 1 | advice-unwarned | 5 |
| door-repeat | 18 | own-cycle-entry-refused | 2 | repeat-row-clears | 1 |
| own-board-refused | 29 | own-board-unsaid | 22 | first-row-alone | 1 |
| repeat-row-unsaid | 1 | add-key-reused | 2 | add-steps-once | 1 |

**mcount (text only, `python3 -I rec/bin/mcount.py`; mutate.mjs never imported or run):** fr2/c1 mutate on the fr2/c1 board,
1,358 entries, 1,358 once; base mutate on the fr2/c1 board, 1,328 once; fr2/c1 mutate on the base board, 1,329 once (29 of the
30 new finds are absent there, as they should be; `several-own-board`'s find is a base line). `out/mcount-fr2r-*.txt`,
`out/mcount-base-mutate-on-fr2.txt`.

## Every fix-round-2 run
Each node run went through `bin/run.sh` (lock checked first — it was never present, so no run waited — then `setsid -w
timeout -k 10 600`; PIDs and commands in `pids.txt`; records in `logs/runs.txt`). Focused runs through `fr/bin/frr.sh`.

**The stopped attempt's runs, kept** (all on board 59cff8f3 unless named; harness 26a9ee0c for FX3):
| label | start (ET) | exit | wall s | log | result |
|---|---|---|---|---|---|
| FX2-fix / FX2-base / FX2-r1 | 11:06:01 AM | 0 / 1 / 1 | 360.8 / 359.9 / 362.1 | logs/FX2-*.log | an EARLIER harness (98b4cfd4): 142/142; 86 fail; 17 fail on fr/c1. Superseded by FX3 and FX4-r1 |
| FX2-hb83-fix / -mut-clin-by-name | 11:07:08 AM | 1 / 1 | 37.4 / 36.2 | logs/FX2-hb83-*.log | audit-board v1.98 item 83, focused: the same 21 pass on both; the 5th scenario lacks w4Template (as in round 1) |
| FX2-8388-fix / -mut-clin-by-name | 11:09:35 / 11:08:37 AM | 1 / 1 | 42.5 / 39.7 | logs/FX2-8388-*.log | audit-recon v1.98 item 83 + v1.99 item 88, focused: threw "headerRow is not defined" on the fix too — not a result |
| **FX3-fix** | 11:13:10 AM | 0 | 313.1 | logs/FX3-fix.log | **ALL CHECKS PASSED, 142/142** |
| **FX3-base** | 11:13:10 AM | 1 | 315.9 | logs/FX3-base.log | **86 FAILING, 56 pass** |
| FX3-mut-* (31) | 11:13:10 to 11:50:37 AM | 1 each but two | 55.6–475.9 | logs/FX3-mut-*.log | 29 caught; `at-last` (exit 0, equivalent, removed) and `clin-by-name` (exit 0, see below) passed |
| FX3-pa-fr2 | 11:18:56 AM | 0 | 135.1 | logs/FX3-pa-fr2.log | money verifier's pa: Codex 1 / 2 refused by Import one appropriation, word for word, storage unchanged; full import taken; 900 / 200 / 1,100 on every route |
| FX3-pb-fr2 | 11:21:11 AM | 0 | 99.7 | logs/FX3-pb-fr2.log | pb: case C (PB27 [null, K1]) taken by the full import, 900 / 200 |
| FX3-pb2-fr2 | 11:22:51 AM | 0 | 53.0 | logs/FX3-pb2-fr2.log | pb2 (M1): B1, B2 under 11111 / AAAAA, B3 not assigned, as the screen and the Spend Plan Source; base doubled B2 |
| FX3-pc-fr2 | 11:23:44 AM | 0 | 33.1 | logs/FX3-pc-fr2.log | pc: constructor / toString / valueOf keys export 900 / 200 |
| FX3-pd-fr2 | 11:24:17 AM | 0 | 23.9 | logs/FX3-pd-fr2.log | pd (S2): the refusal's advice now says what a full import replaces |
| FX3-vprobe3-fr2 | 11:24:41 AM | 0 | 62.9 | logs/FX3-vprobe3-fr2.log | round 1's vprobe3: every shape 900 / 200 / 1,100 |
| FX3-p2-fr2 | 11:25:44 AM | 0 | 79.5 | logs/FX3-p2-fr2.log | 15 workbooks written and read by the independent Python reader (`fr2/out/xsum-FX3-p2-fr2.txt`): 900 / 200 / 1,100 in each |
| S-boot-same-fr2 | 11:20:06 AM | 0 | 75.8 | logs/S-boot-same-fr2.log | identical either way |
| S-audit-fr2 / S-audit-ppt-fr2 | 11:21:22 / 11:22:06 AM | 0 / 0 | 44.3 / 26.4 | logs/S-audit*-fr2.log | ALL CHECKS PASSED |
| S-audit-other-fr2 | 11:22:33 AM | 0 | 129.3 | logs/S-audit-other-fr2.log | ALL CHECKS PASSED |
| S-legacy-fsrc-fr2 / S-audit-inject-fr2 | 11:34:43 / 11:39:52 AM | 0 / 0 | 15.9 / 77.3 | logs/ | pass |
| check-fr2 | 11:41:09 AM | 0 | 21.0 | logs/check-fr2.log | "all checks passed" (npm run check: the board only) |
| S-audit-recon-fr2 | 11:24:42 AM | 124 | 601.0 | logs/S-audit-recon-fr2.log | **incomplete** (cap, under load) — re-run below |
| S-audit-hostile-fr2 | 11:34:59 AM | 137 | 291.9 | logs/S-audit-hostile-fr2.log | **incomplete** (killed) — re-run below |

**This attempt's runs** (two at most at once):
| label | start (ET) | exit | wall s | log | result |
|---|---|---|---|---|---|
| **S-audit-recon-fr2r** | 12:04:02 PM | 0 | 593.5 | logs/S-audit-recon-fr2r.log | the WHOLE audit-recon on fr2/c1 (gc/fr2): **ALL CHECKS PASSED**; the CYCREG block 142/142 inside it. Re-runs the stopped attempt's S-audit-recon-fr2 (cap). 593.5 s of 600 under a load average near 27 |
| **S-audit-recon-fr2r-suite-on-base-board** | 12:13:55 PM | 1 | 480.8 | logs/S-audit-recon-fr2r-suite-on-base-board.log | the same suite with BOARD = base (fce8a391): **86 FAILING**, every one in the CYCREG block and the same 86 as FX3-base (compared check by check); every other block passes |
| **S-audit-recon-fr2r-mut-clin-by-name** | 12:21:56 PM | 1 | 467.9 | logs/S-audit-recon-fr2r-mut-clin-by-name.log | the whole suite with BOARD = the `clin-by-name` mutant (015d4457): **11 FAILING** — v1.98 item 83 "a prime’s CLINs …" (summary, requirements, prime contracts, agreement), "a CLIN pointing at a removed combination …" (summary, prime contracts), "a prime funded nothing …" (not funded), and v1.99 item 88 (the working plan, the cycle's view, saved and reopened, locked before v1.99): prime money filed as not assigned. Caught |
| S-audit-hostile-fr2r | 12:29:44 PM | 0 | 202.7 | logs/S-audit-hostile-fr2r.log | ALL CHECKS PASSED. Re-runs the stopped attempt's S-audit-hostile-fr2 (killed) |
| FR2R-hi-w2-fr2 | 12:04:02 PM | 0 | 214.7 | logs/FR2R-hi-w2-fr2.log | audit-import "v1.95 W2" (full import) + "v1.96 review", focused (hi-w2 86fe022f, as round 1): ALL PASSED, 242 checks |
| FR2R-hi-w1-fr2 | 12:07:37 PM | 0 | 99.0 | logs/FR2R-hi-w1-fr2.log | "v1.95 W1" (folder): ALL PASSED, 53 |
| FR2R-hi-v200-fr2 | 12:09:16 PM | 0 | 307.5 | logs/FR2R-hi-v200-fr2.log | v2.00 R3 to U13 (folder saves): ALL PASSED, 167 |
| FR2R-hi-v197w3-fr2 | 12:14:24 PM | 0 | 303.5 | logs/FR2R-hi-v197w3-fr2.log | "v1.97 W3" (several boards, folder history): ALL PASSED, 111 |
| FR2R-hi-v197w1-fr2 | 12:19:28 PM | 0 | 29.5 | logs/FR2R-hi-v197w1-fr2.log | "v1.97 W1": ALL PASSED, 15 |
| FR2R-hb-v197w1-fr2 | 12:19:57 PM | 0 | 70.6 | logs/FR2R-hb-v197w1-fr2.log | audit-board "v1.97 W1" (rcnSet), focused: ALL PASSED, 178 |
| FX4-r1 | 12:33:15 PM | 1 | 279.0 | logs/FX4-r1.log | the final CYCREG harness on fix round 1's board: 17 fail (above) |

The focused audit-import and audit-board counts equal round 1's and the base's (`out/focused-summary.txt`; the base files
are unchanged since those base runs). Lanes: `fr2/bin/resume-lane1.sh` (the four whole-suite runs, in order),
`resume-lane2.sh` (the six focused runs, in order), `resume-lane1b.sh` (FX4-r1, started only once lane 1's last run was
recorded). At no moment were more than two of these running (computed from the start times and wall seconds; two boundaries
touch within a second, where one run's record and the next one's start are written).

**PIDs of this attempt's node runs** (timeout / node, from `pids.txt`, each with its command there): S-audit-recon-fr2r
27451 / 27454; FR2R-hi-w2-fr2 27479 / 27481; FR2R-hi-w1-fr2 30141 / 30144; FR2R-hi-v200-fr2 31152 / 31155;
S-audit-recon-fr2r-suite-on-base-board 2311 / 2313; FR2R-hi-v197w3-fr2 2869 / 2872; FR2R-hi-v197w1-fr2 6376 / 6379;
FR2R-hb-v197w1-fr2 6725 / 6727; S-audit-recon-fr2r-mut-clin-by-name 8305 / 8307; S-audit-hostile-fr2r 14965 / 14967; FX4-r1
17952 / 17955. The text helpers' PIDs are there too, under `bx:fr2r-*`.

## Decisions, with reasons
- **The money verifier's sketch 2, as proposed.** It names a combination where the board finds it, so the export cannot
  disagree with the screen, and it leaves monSheet as on base but for the uniqueness line. The verifier's sketch 1 changed
  monSheet and broke five base mutation finds.
- **`at-last` removed, not kept failing.** An equivalent mutant can never be caught; leaving it in would fail the lead's sweep
  for no defect. The reason is written where the entry was (`fr2/bin/mkentries3.py`).
- **`clin-by-name` kept.** It is a real fault (a prime's money split over its CLINs prints as not assigned) and audit-recon's
  own CLIN checks catch it; the focused block does not drive CLINs, and adding a CLIN case would duplicate those blocks.
- **A null entry in a locked cycle's list: taken from the user's own board, refused in a file handed over.** The cycle's reader
  already leaves it out, so taking it changes no figure; refusing it kept a whole board out of the new version (money S1).
- **The stopped attempt's results kept despite its process count**, because each is deterministic and recorded with an exit
  code; only the two cut-short runs are re-run.

## Process notes (read before trusting a line above)
- The stopped attempt ran up to seven node processes at once (rule: two). This attempt ran two at most.
- Every node run of this attempt went through run.sh; every text helper (check-assembly, drop-at-last, mkentries3,
  assemble-suites, mkmut, mcount, edit-drafts3) through `bin/bx.sh` (`setsid -w timeout -k 10 600`, PIDs in `pids.txt`).
  Read-only `ls`, `cat`, `grep`, `sed -n`, `diff`, `cmp` and `git hash-object` ran unbounded.
- I killed nothing. Every run ended on its own; none hit its cap.

## What I did not do
- I did not run the full `audit-import.mjs` or `audit-board.mjs`; the lead runs those alone. audit-import's v1.86 old-file
  imports are still not run (my focused build of that unmarked region did not compile in round 1); by reading they never set
  an RCN list. audit-board ran only as focused blocks.
- I did not import, execute or run `mutate.mjs`; it is text to mkmut.py and mcount.py only. No Chromium, no playwright
  install. Nothing edited, staged, committed or pushed in /home/user/orbit-board or /home/user/orbit-ui; the scratch clone
  `gc/fr2` was never committed to. The board stays the empty template; synthetic data only at run time.
- Not built: a notice when a board that holds such a list opens; a way to put a locked cycle's list right (open for Brad);
  marks in the pickers and the "N combos" count; a lossless ✕ for the FIRST row of a repeated key (it clears every assignment,
  as its question says, as on base); S3's wording for other refused sidecar files; a board that already holds a null entry in
  its working plan's list (or a file opened directly with one) still cannot export, as on base.
- Not driven by the block: packages, submittals and band ladders (the same door, by reading); the sidecar's file:// branch.
- Not re-run: the base copies of the other suites (base unchanged; the 12 Oct base runs all passed), and the 29 caught mutants
  and the probes (identical blobs; exit records present).

## Drafts for the lead (fix round 2; they SUPERSEDE `drafts/fr/*` and `drafts/*`)
- `drafts/fr2/NEXT-VERSION-entry.md` (b68675a2): the v2.00 entry, after the U14 bullet.
- `drafts/fr2/UNRESOLVED-line.md` (31abc979, unchanged from the stopped attempt): base has no U32/U33 line, so a proposed NEW line, with Brad's open question.
- `drafts/fr2/LEDGER-append.md` (78dd8881): text for rows U32 and U33, with `<sha>` and `<time>` placeholders.
- `drafts/fr2/COMMIT-MSG.txt` (a991a588): the lead adds the attribution lines.
The stopped attempt's drafts: `drafts/fr2/stopped/` (98166b3c, ec3ae921, 0b448ca9, 31abc979).

## Fix-round-2 file identities (git hash-object, first 8)
- the copy: board 59cff8f3, audit-recon 03b7fda9, mutate.mjs.txt 755c2989 (the stopped attempt's mutate 8c37ef30 is kept as
  `fr2/stopped/mutate-31.mjs.txt`, its entries f72502b8 as `fr2/stopped/entries-cycreg-31.mjs.txt`)
- block 656d9bec, entries 1d0309bf, focused harness 26a9ee0c, `fr2/mut2/blobs.txt` de85dc30, `fr2/mutant-failures.txt` 1f05f4fe
- diffs: `fr2-c1-board` 42a52a07, `fr2-c1-audit-recon` 40ea011a, `fr2-c1-mutate` 1ffdc78a, `fr2-c1-all` c32357fc,
  `fr2-resume-mutate-vs-stopped` a6a89eba (the stopped attempt's mutate diffs kept in `diffs/stopped-fr2/`)
- scripts: edit-board2.py c8e282c2, mkblock2.py f8fa17f4, mkentries2.py ee2d50a8, mkentries3.py 68992a5f, drop-at-last.py
  9218aad6, check-assembly.py ce81fe05, edit-drafts3.py 2fd2d47a, lane.sh f24e48e9, probes.sh 106498ca, probes2.sh 810aa7cf,
  xread.py b0579e48, resume-lane1.sh 44497c6f, resume-lane2.sh d9a5cf07, resume-lane1b.sh bd588c2e; `bin/bx.sh` 31841103,
  `bin/run.sh` 17900e9b, `bin/runner.mjs` f851f139, `fr/bin/frr.sh` f961b193
- probes (the round-2 money verifier's, unchanged): pa 1d0a0c84, pb de4dca09, pb2 4e0b16d3, pc dd6417b3, pd c2658492; round 1's
  vprobe3 6c44dea9; `fr2/harness/p2.mjs` a5388df2, `fr2/harness/h-8388.mjs` 1112e504
- the scratch clone `gc/fr2` (`git clone --shared /home/user/orbit-board` at 7ee498a, never committed to) holds fr2/c1's board
  and audit-recon (cmp-identical) and the focused harnesses hi-w1 310b30b8, hi-w2 86fe022f, hi-v197w1 3893ed4b, hi-v197w3
  b9a3e852, hi-v200 e231e09f, hb-v197w1 edd74fd9, hb-83 4577d6a8
  **[Corrected in Fix round 3 (tests verifier r3, M1): four of those blobs were paired with the wrong files. Hashed one file at a
  time, they are hi-v197w1 b9a3e852, hi-v197w3 e231e09f, hi-v200 edd74fd9 and hb-v197w1 3893ed4b; each run's log records the right one.]**

# Fix round 3 (13 Oct)

Builder, fix round after verification round 3: the money lens (`verify-money-r3`) found no must-fix, one should-fix (S1) and
minors m1 to m4; the tests lens (`verify-tests-r3`) found one must-fix (MUST-FIX 1), four should-fixes (S1 to S4) and minors M1
to M4. Both said "sound with issues". This round started at 3:13 PM ET. No earlier attempt of it existed: apart from the
verifiers' own folders, nothing in this directory was newer than this README's round-2 text (12:39 PM ET), so nothing was
kept from a stopped attempt. All times are Eastern (`TZ=America/New_York date`).

**Where this leaves the record:** "Fix round 2 (13 Oct)" above is superseded wherever this section says otherwise. Its board
`fr2/c1` (59cff8f3) is no longer proposed. Its runs, probes and drafts are kept as they were, as the record of that build.
One line of it was wrong and is marked there: four focused-harness blobs were paired with the wrong file names (tests M1).

## The current proposal: ONE commit, revised a third time
`1: v2.00 (U32, U33): an RCN / EEIC list that repeats a key, or holds "__none__" or a key that is not text, never counts money
twice; a file handed over with one is refused, the user's own board is taken and says so | copy fr3/c1 | board
60bd0c3cf1ab80c008dfb538fe3a9169c2163690 | suites audit-recon e2207681b654fac3a0a956c47308115b221213c1 (audit-import
4aba2506, audit-board a7c575e5, audit-other d89396b0 unchanged) | mutate 37dea5f128bb8e9c32055c501f453dc78d070ec1 | message
drafts/fr3/COMMIT-MSG.txt`

`fr3/c1` = base + this commit. It is a `cp -a` of `fr2/c1` (node_modules a symlink, `chmod -R u+w`). Its board is fr2/c1's,
edited by `fr3/bin/edit-board3.py` (1be121d0, 21 exact replacements, each found once). Its audit-recon and mutate.mjs.txt were
rebuilt from the BASE files by `fr/bin/assemble-suites.py`: the block goes after `// ==== end v2.00 (U14) ====`, the entries
before the R3 comment line. `diff -rq ../base fr3/c1` lists only these three files. `fr2/bin/check-assembly.py` confirms, as
text, that audit-recon = base + the block, mutate = base + the entries, and the focused harness carries the block byte for byte.

| file | base blob | fr3/c1 blob | diff vs base | delta vs fix round 2 (`fr2/c1`) |
|---|---|---|---|---|
| prioritization-board-grid.html | fce8a391 | 60bd0c3cf1ab80c008dfb538fe3a9169c2163690 | `diffs/fr3-c1-board.diff` (+107 −14, 17 hunks) | `diffs/fr3-delta-vs-fr2-board.diff` (+37 −31) |
| tools/export-audit/audit-recon.mjs | 529e36f7 | e2207681b654fac3a0a956c47308115b221213c1 | `diffs/fr3-c1-audit-recon.diff` (+341 −0, 1 hunk) | `diffs/fr3-delta-vs-fr2-audit-recon.diff` (+67 −21) |
| tools/export-audit/mutate.mjs.txt | cbc6defc | 37dea5f128bb8e9c32055c501f453dc78d070ec1 | `diffs/fr3-c1-mutate.diff` (+118 −0, 1 hunk) | `diffs/fr3-delta-vs-fr2-mutate.diff` (+33 −6) |

All three diffs against base are in `diffs/fr3-c1-all.diff`. The block is `fr3/blocks/block-cycreg.mjs.txt` (13369c80, written by
`fr3/bin/mkblock3.py` 56e799a5 from round 2's block). The entries are `fr3/blocks/entries-cycreg.mjs.txt` (6b66643d, written by
`fr3/bin/mkentries4.py` a8fa6e44 from round 2's entries). The focused harness is `fr3/harness/h-cycreg.mjs` (598db47b, built by
`rec/L3/u14/mkfocused.py` from fr3/c1's audit-recon, marker `v2.00 (U32, U33)`).

## Each verifier finding and what closes it
**Tests MUST-FIX 1: rcnAt's empty-pointer guard had no check.** This is closed as proposed. A new CONTROL case: "CONTROL (as
d66dd60) · the working plan lists K1 and an entry keyed “”, R1 on none".
- Route door: the file passes.
- Route opened: the RCN-EEIC sheet, read from the XLSX bytes, prints R1's USAF 900 / ANG 200 as `— no RCN/EEIC assigned —`.
  All services are 1,100.
- The new mutation `v200-cycreg-at-empty-matches` deletes `if(!p) return '';`. Its mutant is the verifier's vm3-at-no-guard
  change, line for line. The board's rcnAt comment now says why: "No pointer ('') is on no combination, beside an entry keyed
  "" as well."

**Money S1: the full import kept the user's own board out for "K9", 5 or [] in the working plan's list.** This is closed by
the verifier's sketch sk1, as proposed. In inShapeWhy, on the user's own board, an entry that is not one is refused only when
it is null and in the working plan's list:
`return x.entry? !(_inRcnOwn && (cy || o.rcn[x.i]!==null)) : !_inRcnOwn;`. The comments above it and at `_inRcnNext` say the
same.
- New GUARD case: "the working plan’s list holds “K9”, then K1, R1 on K1". Its routes are the door (refused, as an entry that
  is not one), the full import (taken, and the question says "O&M working plan’s list holds rcn[0], which is not a
  combination (“"K9"”)"), reopened (said again; 900 / 200 / 1,100 from the bytes), saved and reopened (the same), and opened.
- The null case is unchanged ("a null entry in the working plan's list", refused at the door and by the full import, word for
  word).
- Mutation `v200-cycreg-own-entry-any` puts back round 2's `!(_inRcnOwn && cy)`.
- Round 2's `-own-takes-entry` and `-own-cycle-entry-refused` now find the new line.
- The draft's "which every reader of that list stops at" now says null.

**Tests S1: nothing told the team's copies ('copy') from the user's own board ('board').** Two CONTROL checks were added, read
through driveParse and through loadShared (fetch). The list is [null, K1], and each check expects `[null,"K1"]`, as d66dd60
reads it. Mutations: `v200-cycreg-folder-as-own` and `v200-cycreg-sidecar-as-own`.

**Tests S2: the 'board' mode could outlive a full import that stops early.** Two checks were added. The first is ⬅ Import a
full board of `{"x":1}`: it says "“notes.json” is not a board file.", and the next file handed over, PB27 [K1, K1], is
refused. The second is a full import answered no, then the same file handed over, which is refused. Both fail on d66dd60,
which has no rule. The verifier's two-edit mutant cannot be one entry. The one-edit `v200-cycreg-mode-sticks` (inboundCheck
reads the mode and never clears it; lens B's vm3-mode-not-cleared) is added.

**Tests S3: the door could throw instead of refusing.** Two checks were added in the door block, through a wrapper that
reports a throw as text:
- A CONTROL: [K1, "constructor", "toString", "valueOf"] is refused by the existing key-value rule, "the k at the file.rcn[1]
  is “constructor”, a name the board keeps for itself or every object already answers to".
- "constructor" twice is refused as a repeated key. This fails on d66dd60.
Mutation: `v200-cycreg-odd-plain-object`.

**Tests S4: ✕ on a repeated row was never checked as saved.** One check was added: the same file reopened with the browser
storage ✕ left holds [K1 11111] with R1 still on K1. It fails on d66dd60, whose ✕ clears R1. Mutation:
`v200-cycreg-del-unsaved`.

**Money m1: the full import's sentence was untrue for a locked cycle's number key.** rcnListOdd marks an entry whose key is not
text (`nt`). When a locked cycle's list holds one, the sentence reads "… as the ORBIT that saved the file did (a locked
cycle’s list leaves out an entry whose key is not text, as every ORBIT since v1.99 has), and …".
- New GUARD case: "PB27’s list holds the number 1 alone, R1 on the number 1". Its routes are the door, the full import (the
  words), reopened (the words; not assigned 900 / 200 from the bytes, as d66dd60 prints it) and opened.
- Mutation `v200-cycreg-say-cycle-unsaid`.

**Money m2: the advice.**
- (b) is closed. "can be put right on the board that holds it" now reads "can be put right on a board of this version, in 🗂
  RCN / EEIC, where ✕ on a row marked ⚠ repeats removes that row alone, and the file saved again". On an earlier ORBIT, ✕ on
  the repeated row clears every assignment to its key. Mutation `v200-cycreg-advice-any-board` puts back the old words.
- (a) is not changed: the advice says "A whole board of your own comes across … by ⬅ Import a full board". That is a
  conditional sentence, and it is true for a package too. It is disclosed under Not covered.

**Money m3, m4 and tests M4:** disclosed in the drafts' "Not covered", not built. These are: files sent from a board that
holds such a list are refused elsewhere, with no warning at export; the pickers and the "N combos" count; ppLineAdd; a null
working-plan entry still breaks the panel and the export; ✕ on the first row of a repeated key; an entry keyed "" passes the
door, unreachable by any pointer.

**Tests M1:** the four mis-paired blobs are marked corrected in the round-2 section. **Tests M2:** the drafts now say which checks
pass on d66dd60: the fixtures, the controls, and the money of the four guards. The guards' door, full-import and statement
checks fail there. **Tests M3 (house style):** every board comment `// v2.00 (CYCREG …)` now carries the ledger ids:
`(U32)` where only repeated keys are concerned (rcnBody, rcnAdd, rcnDel, monSheet's keys line), `(U32, U33)` elsewhere. The
block is named `v2.00 (U32, U33) — …`, with markers `// ==== v2.00 (U32, U33): …` and `// ==== end v2.00 (U32, U33) ====`, as
the U14 block is named. No board comment says CYCREG now.

## The board change, reviewed (fr3/c1 vs fr2/c1; `diffs/fr3-delta-vs-fr2-board.diff`)
- 14 comment prefixes, CYCREG to U32 / U33. There is no behaviour in them.
- rcnListOdd: `nt:true` on an entry whose key is not text or is missing, and its comment.
- The mode comment: 'board' is "only a null entry in a working plan's list".
- inShapeWhy: the sk1 condition and its comment.
- IN_RCN_TAIL.list: the advice for this version.
- fullImportText: `rcnCyNT`, set by rcnSay for a locked cycle's list that holds an `nt` entry, and the sentence's parenthesis.
- rcnAt: one comment line.
Nothing else changes. monSheet, rcnAt's code, the door's other modes, driveParse, loadShared, rcnBody, rcnDel and rcnAdd are
byte-identical to round 2 apart from comment prefixes.

## How the change meets the lead's principles
1. **Never lose a copy.** A user's own board holding "K9", 5 or [] in its working plan's list now comes across whole, says what
   it holds, reopens and exports right. Round 2 kept it out. The team's copies holding null are read as before; this is now
   checked. ✕ on a repeated row is saved, so the removal does not come back. A file handed over is still refused whole, with
   browser storage byte-identical.
2. **Refuse or ask rather than guess.** Only null is refused on the user's own board, because every reader stops at it.
   Anything else is taken as d66dd60 took it, and said. The mode a check is asked for lives for that one check, and a full
   import that stops early leaves nothing behind (checked).
3. **Money and every export match the computation.** The new CONTROL proves that a requirement on no combination prints as not
   assigned beside an entry keyed "", from the bytes. The two new GUARDs print 900 / 200 / 1,100 under the codes the screen
   shows, on every route, here and on d66dd60.
4. **Every word stays true.** The full import's sentence holds for a cycle's number key. The advice names this version's way to
   put a list right. The door refuses a "constructor" key in words. The drafts say null, and say which checks pass on
   d66dd60.
5. **The smallest change.** For money S1 it is one condition, for m1 one flag and one clause, and for m2 one sentence. The
   rest is tests.
6. **Every existing check, fixture and expected value is preserved.** audit-recon and mutate remove 0 lines against base. Every
   base mutation entry finds its text exactly once on fr3/c1 (1,328 of 1,328). All 142 round-2 checks give the same verdict
   and the same recorded value on the fix (FX3-fix vs FX6-fix) and on d66dd60 (FX3-base vs FX5-base), compared check by check.
   What round 3 changed in my own never-committed block and entries:

| fr2/c1 file:line (round 2, never committed) | old expectation | new expectation | why |
|---|---|---|---|
| audit-recon.mjs, LIST_TAIL (`diffs/fr3-delta-vs-fr2-audit-recon.diff`) | "…can be put right on the board that holds it, in 🗂 RCN / EEIC, and the file saved again…" | "…can be put right on a board of this version, in 🗂 RCN / EEIC, where ✕ on a row marked ⚠ repeats removes that row alone, and the file saved again…" | money m2(b): the old advice was untrue on an earlier ORBIT, whose ✕ clears assignments |
| audit-recon.mjs, SAYS | one sentence for every list | the same, plus "(a locked cycle’s list leaves out an entry whose key is not text, as every ORBIT since v1.99 has)" when the case says `cyNT` (only the new PB27 [1] case) | money m1 |
| audit-recon.mjs, the block's name and markers | `v2.00 (CYCREG) — …` | `v2.00 (U32, U33) — …` | tests M3, house style |
| audit-recon.mjs, header comment | "86 of its 142 checks"; "the two GUARDS" pass on d66dd60 | "96 of its 165 checks"; its 69 passes are the fixtures, the CONTROLS and the four GUARDS' money | the new counts; tests M2 |
| audit-recon.mjs, "an entry that is not one" comment | "every reader of the list stops at it" | "a null entry in the working plan's list: every reader of that list stops at it" | money S1 |
| audit-recon.mjs, ✕ block | `const O = boot({ html: make(…).file })` | `const FR = make(…), O = boot({ html: FR.file })` | the new reopen check reuses the same file |
| mutate.mjs.txt, `-own-takes-entry` / `-own-cycle-entry-refused` finds | round 2's `return x.entry? !(_inRcnOwn && cy) : !_inRcnOwn;` | the sk1 line | the line they mutate changed |
| mutate.mjs.txt, `-own-board-refused` find, the header comment | `// v2.00 (CYCREG)` | `// v2.00 (U32, U33)` | the comment prefix changed |

## The block: 165 checks (audit-recon "v2.00 (U32, U33) — …")
It is round 2's 142 checks plus 23 new ones.
- CONTROL (as d66dd60) [K1, an entry keyed ""], R1 on none: 3 checks (fixture, door, opened).
- GUARD PB27 [the number 1], R1 on the number 1: 6 checks (fixture, door, full, reopened ×2, opened).
- GUARD working plan ["K9", K1]: 7 checks (fixture, door, full, reopened ×2, saved, opened).
- The door on keys every object answers to: 2 checks.
- A full import that stops early: 2 checks.
- The team's copies with [null, K1]: 2 checks.
- ✕ on row 2, reopened: 1 check.
Every expected value is a hand-written literal, or a concatenation of the block's literal constants. Board helpers are used
only for what is observed.

**Fails on base, passes on the fix:**
- **FX5-base** (3:25:26 PM ET, exit 1, harness 25dc6fa5): **96 fail, 69 pass**. Counted from `out/FX5-base.checks.jsonl`, the
  69 passes are 25 fixtures, 32 CONTROL checks and 12 GUARD money checks; nothing else passes on d66dd60.
  - The 96 failures are round 2's 86 (check for check: verdict and recorded value identical to FX3-base) and 10 new ones.
  - The 10 new failures: the door, the full import and the reopened statement of both new GUARDs (6); "constructor" twice;
    both stopped-early full imports; ✕ on row 2 reopened.
  - USAF 1,800 / ANG 400 / all services 2,200 are read from the bytes, as before.
- **FX7-fix** (3:49:40 PM ET, exit 0, harness 598db47b): **ALL CHECKS PASSED, 165 of 165.**
  - FX6-fix (3:35:09 PM ET, harness 25dc6fa5) gave the same: 165 of 165.
  - The two harnesses differ by four comment lines (`diffs/fr3-harness-first-vs-final.diff`, +4 −3, no line of code). FX5-base
    on 25dc6fa5 therefore stands for the final harness, and FX7-base re-runs it on 598db47b (below).
- **Round 2's board:** **FX6-fr2** (3:35:11 PM ET, exit 1): the round-3 harness on round 2's board `fr2/c1` (59cff8f3) fails 9
  checks, each a round-3 finding:
  - the old advice in five refusals (⬅ Import one appropriation and ⇊ Import several boards, Codex 1 and 2; Import one
    appropriation, the working plan's [K1, K1]);
  - the PB27 [1] statement, in the full import and when reopened (2);
  - the "K9" board refused by the full import, with nothing said when reopened (2).
  - The new CONTROLs and the S1 to S4 checks pass there, as they should: round 2 already had those rules, and nothing checked
    them.

## The whole audit-recon: two tries cut short, two verbatim parts, then one whole run that finished
- **S-audit-recon-fr3b** (3:55:10 PM ET) was killed by the memory cgroup's OOM killer after 575.5 s (exit 137). dmesg reads
  "Memory cgroup out of memory: Killed process 18563 (node)", my recorded node. It had 362 recorded checks, none failing.
- **S-audit-recon-fr3c** (4:10:13 PM ET) hit the 600 s cap (exit 124) with 341 recorded checks, none failing. The load average
  was about 30 to 45.
- The round-3 tests verifier had the same result three times.
- The rule is to re-run, not to report a failure. So `fr3/bin/mksplit.py` (text only) cut the suite into two parts:
  - `hr-minus-v200.mjs` (d48361f4) is the suite byte for byte with its five v2.00 blocks cut out whole. Those blocks run from
    `// ==== v2.00 (R1): funds flow` to `// ==== end v2.00 (U32, U33) ====` and sit together, with nothing between them.
  - `hr-v200.mjs` (22310d15) is those five blocks through `rec/L3/u14/mkfocused.py`: the suite's preamble helpers, the blocks
    verbatim and the guard.
- Every `  const name = '…'` line of the suite is in exactly one part (58 = 53 + 5, compared by sort). Each part keeps the
  scenario-ran guard.
- **S-hr-minus-v200-fr3** (4:23:00 PM ET, exit 0, 288.2 s): ALL CHECKS PASSED.
- **S-hr-v200-fr3** (4:26:46 PM ET, exit 0, 525.6 s): ALL CHECKS PASSED.
  - R1 19, R1 (11 Oct decisions) 19, U1 78, U14 63, U32/U33 165.
  - With the first part's 127, that is 471 recorded checks: round 2's whole run had 448, and this block adds 23.
- **A whole run then finished.** The load average fell to about 14, so S-audit-recon-fr3d was moved to the front of the queue.
  **S-audit-recon-fr3d** (4:52:23 PM ET, exit 0, 331.7 s): the WHOLE audit-recon on fr3/c1 (gc/fr3, audit-recon e2207681)
  prints **ALL CHECKS PASSED**, with 471 recorded checks, none failing, and the U32/U33 block at 165 of 165. The two parts
  above agree with it.

## Mutations: 39 entries, each caught
Ids are `v200-cycreg-*`, inserted before the R3 comment line. Each was built with `rec/bin/mkmut.py` as text only
(`fr3/bin/mkmuts.sh`; every find matched once; blobs in `fr3/mut/blobs.txt` b463e68b). Each was run as the focused block with the
final harness 598db47b, as FX7-mut-*.
- Every run's log records its mutant blob, identical to `fr3/mut/blobs.txt` for all 39, and harness 598db47b (checked by script).
- The failing checks of each are in `fr3/mutant-failures.txt`. No mutant made the block throw.
- The task's three: **drop the uniqueness** `keys-repeat` 14 failing; **let a key equal the sentinel** `key-as-name` 28; **drop
  the import refusal** `door-open` 29.
- The new ones:
  - `at-empty-matches` fails "CONTROL (as d66dd60) · … entry keyed “” · the file opened". Its XLSX rows read `33333 / CCCCC`
    900 / 200 where the fix reads `— no RCN/EEIC assigned —`.
  - `own-entry-any` fails the "K9" full import and its reopened statement.
  - `folder-as-own` gives "threw: a copy in the shared folder was refused: …", and `sidecar-as-own` gives null.
  - `mode-sticks` fails both stopped-early checks and "the team’s own copies · the same text, handed over".
  - `odd-plain-object` gives "threw: at[k].push is not a function" on both door checks.
  - `del-unsaved` fails "✕ on row 2, the same browser reopened": the row is back.
  - `say-cycle-unsaid` fails the PB27 [1] full import and its reopened statement.
  - `advice-any-board` fails the five LIST_TAIL refusals.

| entry | failing checks of 165 (FX7-mut-*) | round 2 (FX3-mut-*, of 142) |
|---|---|---|
| `-keys-repeat` | 14 | 14 |
| `-keys-cycle-only` | 8 | 8 |
| `-notfunded-repeat` | 2 | 2 |
| `-key-as-name` | 28 | 28 |
| `-at-by-name` | 10 | 10 |
| `-at-text-only` | 8 | 8 |
| `-req-by-name` | 47 | 44 |
| `-clin-by-name` | 0 here; **11** in hr-minus-v200 on its mutant (S-hr-minus-v200-fr3-mut-clin-by-name) | 0 here; 11 in the whole suite |
| `-door-open` | 29 | 24 |
| `-door-repeat` | 21 | 18 |
| `-door-adjacent` | 1 | 1 |
| `-door-underscores` | 8 | 8 |
| `-door-sentinel-only` | 1 | 1 |
| `-door-not-text` | 20 | 17 |
| `-several-own-board` | 2 | 2 |
| `-own-takes-entry` | 1 | 1 |
| `-own-cycle-entry-refused` | 4 | 2 |
| `-own-board-refused` | 33 | 29 |
| `-own-board-unsaid` | 26 | 22 |
| `-say-first-only` | 2 | 2 |
| `-say-entry-garbled` | 4 | 2 |
| `-folder-refused` | 2 | 1 |
| `-sidecar-refused` | 2 | 1 |
| `-refusal-untrue` | 6 | 6 |
| `-advice-unwarned` | 5 | 5 |
| `-repeat-row-clears` | 2 | 1 |
| `-first-row-alone` | 1 | 1 |
| `-repeat-row-unsaid` | 1 | 1 |
| `-add-key-reused` | 2 | 2 |
| `-add-steps-once` | 1 | 1 |
| `-own-entry-any` | 2 | new in round 3 |
| `-at-empty-matches` | 1 | new in round 3 |
| `-folder-as-own` | 1 | new in round 3 |
| `-sidecar-as-own` | 1 | new in round 3 |
| `-mode-sticks` | 3 | new in round 3 |
| `-odd-plain-object` | 2 | new in round 3 |
| `-del-unsaved` | 1 | new in round 3 |
| `-say-cycle-unsaid` | 2 | new in round 3 |
| `-advice-any-board` | 5 | new in round 3 |

**`-clin-by-name`** passes the focused block, as in round 2: the block drives no CLIN. On the first split part (the suite
without its v2.00 blocks) it fails **11** checks. Seven are in v1.98 item 83: "a prime’s CLINs …" (summary, requirements, prime
contracts, agreement), "a CLIN pointing at a removed combination …" (summary, prime contracts) and "a prime funded nothing …"
(not funded). Four are in v1.99 item 88: the working plan, the cycle's view, saved and reopened, and locked before v1.99. The
run is S-hr-minus-v200-fr3-mut-clin-by-name (5:20:18 PM ET, exit 1, 51.7 s). These are the same 11 checks that round 2's whole
suite failed on its clin-by-name mutant (S-audit-recon-fr2r-mut-clin-by-name).

**mcount (text only, `python3 -I rec/bin/mcount.py`; mutate.mjs never imported or run):**
- fr3/c1's mutate on the fr3/c1 board: **1,367 entries, 1,367 found once**;
- the base mutate on the fr3/c1 board: **1,328 of 1,328 once**, so every existing entry still applies;
- fr3/c1's mutate on the base board: 1,329 once. The other 38 are the new finds, absent there as they should be;
  `several-own-board`'s find is a base line.
- Outputs: `fr3/out/mcount-fr3mut-on-fr3.txt` d7cfe024, `-basemut-on-fr3.txt` 915681ab, `-fr3mut-on-base.txt` 0ce295db.
- The lens-B verifier's mutate plus its 5 proposed entries counted 1,363 on round 2's board; this round's 1,367 is round 2's
  1,358 plus 9 entries.

## Every fix-round-3 run
Each was a node run through `bin/run.sh`: the `AUDIT_IMPORT_RUNNING` lock was checked first (it was never present, and
`logs/runs.txt` has no wait or skip line), then `setsid -w timeout -k 10 600`. Logs are in `logs/`, and per-check records
(SUITE_CHECKS) in `out/<label>.checks.jsonl`. The table is `fr3/out/runs-table.md` (99671753, written by
`fr3/bin/report.py` 06802eb8 from `logs/runs.txt`).
- Focused CYCREG runs use `bin/runner.mjs` (f851f139), which records the board and harness blobs in each log's IDS line.
- Suites run in the scratch clone `gc/fr3`.
- **FX5-fix is void as a fix run** (process notes below). FX6-* used the first harness 25dc6fa5, FX7-* the final 598db47b.
- **Exit 143** means stopped by me (superseded harness; both re-run). **137** means the memory cgroup's OOM killer. **124**
  means the 600 s cap.
- "p/f recorded" counts only checks that go through w5Chk. For the whole suites, ALL CHECKS PASSED is the suite's own
  verdict.

| label | start (ET, 13 Oct) | exit | wall s | log | result |
|---|---|---|---|---|---|
| FX5-base | 15:25:26 | 1 | 493.2 | `logs/FX5-base.log` | 96 FAILING CHECK(S) ; 69p/96f recorded |
| FX5-fix | 15:25:26 | 1 | 501.9 | `logs/FX5-fix.log` | 9 FAILING CHECK(S) ; 156p/9f recorded |
| FX6-fix | 15:35:09 | 0 | 449.3 | `logs/FX6-fix.log` | ALL CHECKS PASSED ; 165p/0f recorded |
| FX6-fr2 | 15:35:11 | 1 | 450.6 | `logs/FX6-fr2.log` | 9 FAILING CHECK(S) ; 156p/9f recorded |
| FX6-mut-v200-cycreg-keys-repeat | 15:42:39 | 1 | 334.5 | `logs/FX6-mut-v200-cycreg-keys-repeat.log` | 14 FAILING CHECK(S) ; 151p/14f recorded |
| FX6-mut-v200-cycreg-key-as-name | 15:48:13 | 143 | 87.0 | `logs/FX6-mut-v200-cycreg-key-as-name.log` | STOPPED by me (143): superseded harness -- incomplete;  ; 32p/11f recorded |
| S-audit-recon-fr3 | 15:42:51 | 143 | 410.0 | `logs/S-audit-recon-fr3.log` | STOPPED by me (143): superseded harness -- incomplete;  ; 325p/0f recorded |
| check-fr3 | 15:49:41 | 0 | 8.8 | `logs/check-fr3.log` | all checks passed |
| S-boot-same-fr3 | 15:49:49 | 0 | 33.1 | `logs/S-boot-same-fr3.log` | every page, source, save and error list is identical either way |
| S-audit-fr3 | 15:50:23 | 0 | 36.4 | `logs/S-audit-fr3.log` | ALL CHECKS PASSED |
| S-audit-ppt-fr3 | 15:50:59 | 0 | 20.7 | `logs/S-audit-ppt-fr3.log` | ALL CHECKS PASSED |
| S-legacy-fsrc-fr3 | 15:51:20 | 0 | 14.1 | `logs/S-legacy-fsrc-fr3.log` | every legacy Force setting computes exactly as before |
| S-audit-inject-fr3 | 15:51:34 | 0 | 43.4 | `logs/S-audit-inject-fr3.log` | ALL CHECKS PASSED |
| FX7-fix | 15:49:40 | 0 | 329.5 | `logs/FX7-fix.log` | ALL CHECKS PASSED ; 165p/0f recorded |
| FR3-hi-w2-fr3 | 15:52:17 | 0 | 292.4 | `logs/FR3-hi-w2-fr3.log` | ALL CHECKS PASSED ; 242p/0f recorded |
| FR3-hi-w1-fr3 | 15:57:10 | 0 | 125.6 | `logs/FR3-hi-w1-fr3.log` | ALL CHECKS PASSED ; 53p/0f recorded |
| FR3-hi-v197w1-fr3 | 15:59:16 | 0 | 53.1 | `logs/FR3-hi-v197w1-fr3.log` | ALL CHECKS PASSED ; 15p/0f recorded |
| FR3-hb-v197w1-fr3 | 16:00:09 | 0 | 104.8 | `logs/FR3-hb-v197w1-fr3.log` | ALL CHECKS PASSED ; 178p/0f recorded |
| S-audit-recon-fr3b | 15:55:10 | 137 | 575.5 | `logs/S-audit-recon-fr3b.log` | KILLED by the OOM killer (137) -- incomplete;  ; 362p/0f recorded |
| FR3-hi-v197w3-fr3 | 16:01:54 | 0 | 440.7 | `logs/FR3-hi-v197w3-fr3.log` | ALL CHECKS PASSED ; 111p/0f recorded |
| FX7-base | 16:04:46 | 1 | 327.0 | `logs/FX7-base.log` | 96 FAILING CHECK(S) ; 69p/96f recorded |
| FR3-hi-v200-fr3 | 16:09:15 | 0 | 410.6 | `logs/FR3-hi-v200-fr3.log` | ALL CHECKS PASSED ; 167p/0f recorded |
| S-audit-other-fr3 | 16:16:06 | 0 | 167.9 | `logs/S-audit-other-fr3.log` | ALL CHECKS PASSED |
| S-audit-recon-fr3c | 16:10:13 | 124 | 600.7 | `logs/S-audit-recon-fr3c.log` | TIMED OUT at the cap -- incomplete;  ; 341p/0f recorded |
| S-audit-hostile-fr3 | 16:18:54 | 0 | 245.6 | `logs/S-audit-hostile-fr3.log` | ALL CHECKS PASSED ; 124p/0f recorded |
| FX7-mut-v200-cycreg-keys-repeat | 16:20:14 | 1 | 392.1 | `logs/FX7-mut-v200-cycreg-keys-repeat.log` | 14 FAILING CHECK(S) ; 151p/14f recorded |
| S-hr-minus-v200-fr3 | 16:23:00 | 0 | 288.2 | `logs/S-hr-minus-v200-fr3.log` | ALL CHECKS PASSED ; 127p/0f recorded |
| FX7-mut-v200-cycreg-key-as-name | 16:27:48 | 1 | 368.6 | `logs/FX7-mut-v200-cycreg-key-as-name.log` | 28 FAILING CHECK(S) ; 137p/28f recorded |
| S-hr-v200-fr3 | 16:26:46 | 0 | 525.6 | `logs/S-hr-v200-fr3.log` | ALL CHECKS PASSED ; 344p/0f recorded |
| FX7-mut-v200-cycreg-door-open | 16:33:57 | 1 | 372.9 | `logs/FX7-mut-v200-cycreg-door-open.log` | 29 FAILING CHECK(S) ; 136p/29f recorded |
| FX7-mut-v200-cycreg-at-empty-matches | 16:35:32 | 1 | 396.0 | `logs/FX7-mut-v200-cycreg-at-empty-matches.log` | 1 FAILING CHECK(S) ; 164p/1f recorded |
| FX7-mut-v200-cycreg-own-entry-any | 16:40:10 | 1 | 410.3 | `logs/FX7-mut-v200-cycreg-own-entry-any.log` | 2 FAILING CHECK(S) ; 163p/2f recorded |
| FX7-mut-v200-cycreg-own-takes-entry | 16:42:08 | 1 | 321.7 | `logs/FX7-mut-v200-cycreg-own-takes-entry.log` | 1 FAILING CHECK(S) ; 164p/1f recorded |
| FX7-mut-v200-cycreg-own-cycle-entry-refused | 16:47:01 | 1 | 147.1 | `logs/FX7-mut-v200-cycreg-own-cycle-entry-refused.log` | 4 FAILING CHECK(S) ; 161p/4f recorded |
| FX7-mut-v200-cycreg-own-board-refused | 16:47:30 | 1 | 156.7 | `logs/FX7-mut-v200-cycreg-own-board-refused.log` | 33 FAILING CHECK(S) ; 132p/33f recorded |
| FX7-mut-v200-cycreg-folder-as-own | 16:49:28 | 1 | 143.6 | `logs/FX7-mut-v200-cycreg-folder-as-own.log` | 1 FAILING CHECK(S) ; 164p/1f recorded |
| FX7-mut-v200-cycreg-sidecar-as-own | 16:50:07 | 1 | 135.9 | `logs/FX7-mut-v200-cycreg-sidecar-as-own.log` | 1 FAILING CHECK(S) ; 164p/1f recorded |
| FX7-mut-v200-cycreg-mode-sticks | 16:51:52 | 1 | 124.1 | `logs/FX7-mut-v200-cycreg-mode-sticks.log` | 3 FAILING CHECK(S) ; 162p/3f recorded |
| FX7-mut-v200-cycreg-odd-plain-object | 16:53:56 | 1 | 157.7 | `logs/FX7-mut-v200-cycreg-odd-plain-object.log` | 2 FAILING CHECK(S) ; 163p/2f recorded |
| S-audit-recon-fr3d | 16:52:23 | 0 | 331.7 | `logs/S-audit-recon-fr3d.log` | ALL CHECKS PASSED ; 471p/0f recorded |
| FX7-mut-v200-cycreg-del-unsaved | 16:56:34 | 1 | 170.1 | `logs/FX7-mut-v200-cycreg-del-unsaved.log` | 1 FAILING CHECK(S) ; 164p/1f recorded |
| FX7-mut-v200-cycreg-say-cycle-unsaid | 16:57:55 | 1 | 169.0 | `logs/FX7-mut-v200-cycreg-say-cycle-unsaid.log` | 2 FAILING CHECK(S) ; 163p/2f recorded |
| FX7-mut-v200-cycreg-advice-any-board | 16:59:24 | 1 | 167.1 | `logs/FX7-mut-v200-cycreg-advice-any-board.log` | 5 FAILING CHECK(S) ; 160p/5f recorded |
| FX7-mut-v200-cycreg-keys-cycle-only | 17:00:44 | 1 | 162.0 | `logs/FX7-mut-v200-cycreg-keys-cycle-only.log` | 8 FAILING CHECK(S) ; 157p/8f recorded |
| FX7-mut-v200-cycreg-notfunded-repeat | 17:02:11 | 1 | 158.3 | `logs/FX7-mut-v200-cycreg-notfunded-repeat.log` | 2 FAILING CHECK(S) ; 163p/2f recorded |
| FX7-mut-v200-cycreg-at-by-name | 17:03:26 | 1 | 151.8 | `logs/FX7-mut-v200-cycreg-at-by-name.log` | 10 FAILING CHECK(S) ; 155p/10f recorded |
| FX7-mut-v200-cycreg-at-text-only | 17:04:50 | 1 | 148.4 | `logs/FX7-mut-v200-cycreg-at-text-only.log` | 8 FAILING CHECK(S) ; 157p/8f recorded |
| FX7-mut-v200-cycreg-req-by-name | 17:05:58 | 1 | 149.2 | `logs/FX7-mut-v200-cycreg-req-by-name.log` | 47 FAILING CHECK(S) ; 118p/47f recorded |
| FX7-mut-v200-cycreg-clin-by-name | 17:07:18 | 0 | 157.4 | `logs/FX7-mut-v200-cycreg-clin-by-name.log` | ALL CHECKS PASSED ; 165p/0f recorded |
| FX7-mut-v200-cycreg-door-repeat | 17:08:28 | 1 | 150.5 | `logs/FX7-mut-v200-cycreg-door-repeat.log` | 21 FAILING CHECK(S) ; 144p/21f recorded |
| FX7-mut-v200-cycreg-door-adjacent | 17:09:56 | 1 | 126.8 | `logs/FX7-mut-v200-cycreg-door-adjacent.log` | 1 FAILING CHECK(S) ; 164p/1f recorded |
| FX7-mut-v200-cycreg-door-underscores | 17:10:59 | 1 | 94.9 | `logs/FX7-mut-v200-cycreg-door-underscores.log` | 8 FAILING CHECK(S) ; 157p/8f recorded |
| FX7-mut-v200-cycreg-door-sentinel-only | 17:12:03 | 1 | 71.5 | `logs/FX7-mut-v200-cycreg-door-sentinel-only.log` | 1 FAILING CHECK(S) ; 164p/1f recorded |
| FX7-mut-v200-cycreg-door-not-text | 17:12:34 | 1 | 65.8 | `logs/FX7-mut-v200-cycreg-door-not-text.log` | 20 FAILING CHECK(S) ; 145p/20f recorded |
| FX7-mut-v200-cycreg-several-own-board | 17:13:15 | 1 | 60.0 | `logs/FX7-mut-v200-cycreg-several-own-board.log` | 2 FAILING CHECK(S) ; 163p/2f recorded |
| FX7-mut-v200-cycreg-own-board-unsaid | 17:13:39 | 1 | 58.1 | `logs/FX7-mut-v200-cycreg-own-board-unsaid.log` | 26 FAILING CHECK(S) ; 139p/26f recorded |
| FX7-mut-v200-cycreg-say-first-only | 17:14:15 | 1 | 60.5 | `logs/FX7-mut-v200-cycreg-say-first-only.log` | 2 FAILING CHECK(S) ; 163p/2f recorded |
| FX7-mut-v200-cycreg-say-entry-garbled | 17:14:38 | 1 | 58.9 | `logs/FX7-mut-v200-cycreg-say-entry-garbled.log` | 4 FAILING CHECK(S) ; 161p/4f recorded |
| FX7-mut-v200-cycreg-folder-refused | 17:15:15 | 1 | 59.2 | `logs/FX7-mut-v200-cycreg-folder-refused.log` | 2 FAILING CHECK(S) ; 163p/2f recorded |
| FX7-mut-v200-cycreg-sidecar-refused | 17:15:37 | 1 | 69.0 | `logs/FX7-mut-v200-cycreg-sidecar-refused.log` | 2 FAILING CHECK(S) ; 163p/2f recorded |
| FX7-mut-v200-cycreg-refusal-untrue | 17:16:14 | 1 | 74.2 | `logs/FX7-mut-v200-cycreg-refusal-untrue.log` | 6 FAILING CHECK(S) ; 159p/6f recorded |
| FX7-mut-v200-cycreg-advice-unwarned | 17:16:46 | 1 | 70.0 | `logs/FX7-mut-v200-cycreg-advice-unwarned.log` | 5 FAILING CHECK(S) ; 160p/5f recorded |
| FX7-mut-v200-cycreg-repeat-row-clears | 17:17:29 | 1 | 70.1 | `logs/FX7-mut-v200-cycreg-repeat-row-clears.log` | 2 FAILING CHECK(S) ; 163p/2f recorded |
| FX7-mut-v200-cycreg-first-row-alone | 17:17:56 | 1 | 70.6 | `logs/FX7-mut-v200-cycreg-first-row-alone.log` | 1 FAILING CHECK(S) ; 164p/1f recorded |
| FX7-mut-v200-cycreg-repeat-row-unsaid | 17:18:39 | 1 | 68.2 | `logs/FX7-mut-v200-cycreg-repeat-row-unsaid.log` | 1 FAILING CHECK(S) ; 164p/1f recorded |
| FX7-mut-v200-cycreg-add-key-reused | 17:19:06 | 1 | 71.1 | `logs/FX7-mut-v200-cycreg-add-key-reused.log` | 2 FAILING CHECK(S) ; 163p/2f recorded |
| FX7-mut-v200-cycreg-add-steps-once | 17:19:47 | 1 | 67.9 | `logs/FX7-mut-v200-cycreg-add-steps-once.log` | 1 FAILING CHECK(S) ; 164p/1f recorded |
| S-hr-minus-v200-fr3-mut-clin-by-name | 17:20:18 | 1 | 51.7 | `logs/S-hr-minus-v200-fr3-mut-clin-by-name.log` | 11 FAILING CHECK(S) ; 123p/4f recorded |
| S-hr-v200-fr3-on-base-board | 17:20:55 | 1 | 75.0 | `logs/S-hr-v200-fr3-on-base-board.log` | 96 FAILING CHECK(S) ; 248p/96f recorded |

**Results in one place (all on fr3/c1 unless named):**
- The block on the fix: FX7-fix (FX6-fix the same) passes 165 of 165.
- On d66dd60: FX7-base (FX5-base the same) fails 96 and passes 69.
- On round 2's board: FX6-fr2 fails 9.
- The 39 mutants are each caught; `-clin-by-name` by the suite's own CLIN checks.
- audit-recon passes whole (S-audit-recon-fr3d, 471 recorded checks), and in its two verbatim parts.
- On d66dd60, the five v2.00 blocks of audit-recon (S-hr-v200-fr3-on-base-board) fail only in the U32/U33 block: 96 there,
  and R1, R1 (decisions), U1 and U14 all pass.
- `npm run check` passes. So do boot-same (identical either way), audit, audit-ppt, legacy-fsrc, audit-inject, audit-other and
  audit-hostile.
- The focused audit-import blocks pass with the same counts as rounds 1 and 2 and the base: hi-w2 242 (the full import, which
  money S1 and m1 touch), hi-w1 53, hi-v197w1 15, hi-v197w3 111 and hi-v200 167. The focused audit-board hb-v197w1 passes
  178.
- The harness blobs, hashed one file at a time, are in `fr3/out/gc-fr3-blobs.txt`: hi-w1 310b30b8, hi-w2 86fe022f, hi-v197w1
  b9a3e852, hi-v197w3 e231e09f, hi-v200 edd74fd9, hb-v197w1 3893ed4b. They are unchanged from round 2, built from the
  unchanged audit-import and audit-board.

**PIDs** (timeout / node, each with its command in `pids.txt`): `fr3/out/pids-fr3.txt` (d7c9e46f) lists all 69 runs.
- Examples: FX7-fix 11580 / 11583; FX7-base 26212 / 26214; S-audit-recon-fr3d and every FX7-mut run are there too.
- The lane scripts' PIDs are in `pids.txt` under `fr3-lane`, `fr3-qlane` and `fr3-qlane-*-launcher`.
- The only processes I stopped are 4843 (S-audit-recon-fr3) and 10127 (FX6-mut-…-key-as-name), both mine and recorded; the
  reason is written beside them in `pids.txt`.
- When I finished, no process of this track was running (checked with `ps`).

## Decisions, with reasons
- **Money S1 is taken as sketched (sk1), not widened.** Only null stops the working plan's readers, so only null keeps a user's
  own board out. Anything else is taken as d66dd60 took it and said in the question. One condition closes it.
- **Money m1 is said only when it applies.** The parenthesis appears only when a locked cycle's list holds an entry whose key
  is not text (`nt`). Every other full import's words are byte-identical to round 2's, so no existing statement check changed.
- **Money m2(a) is not changed.** "A whole board of your own comes across … by ⬅ Import a full board" is true as a conditional
  for a package or a submittal too. Naming every file kind would lengthen every refusal, so it is disclosed instead.
- **Tests S2's two-edit mutant is not an entry**, because one mutate entry is one find. The one-edit `-mode-sticks` stands
  for it, and the two new checks catch both (lens B ran its two-edit version: 2 failing checks).
- **The block is renamed to its ledger ids** (house style, tests M3). This changes every check's scenario string, not one
  expected value. Round 2's 142 checks were compared with this round's by their `where` and `what`, which did not change.
- **An entry keyed "" stays legal at the door** (tests M4). No pointer can reach it: a pointer of '' means none, and the new
  CONTROL proves the money stays not assigned. Refusing it would be a new rule with no money behind it.
- **FX5-fix is void as a fix run** (see the process notes). It is kept, and it equals FX6-fr2 check for check.
- **Two of my runs were stopped by me** (4843, 10127; both recorded in pids.txt) when the block's header comment was corrected.
  They are re-run on the final files. The harness changed only in comment lines (`diffs/fr3-harness-first-vs-final.diff`), and
  FX6-fix equals FX7-fix and FX5-base equals FX7-base, check for check and value for value.

## Process notes (read before trusting a line above)
- **A copying mistake, caught before any result was used.** `fr3/harness` was made by `cp -a` of `fr2/harness`, so its
  `boot.mjs` was a symlink to **fr2/c1's** boot.mjs. Every board the harness booted without html was therefore fr2/c1's
  (59cff8f3), although the runner recorded fr3/c1's board, which it checks through the copy's own boot.mjs.
  - FX5-fix (3:25:26 PM ET) is therefore the round-3 harness on round 2's board, not a fix run. It equals FX6-fr2 check for
    check.
  - The symlink was repointed at 3:34:59 PM ET to `fr3/c1/tools/export-audit/boot.mjs`. Every later run used it:
    `readlink -f fr3/harness/boot.mjs` gives `…/fr3/c1/tools/export-audit/boot.mjs`.
  - FX5-base was not affected: it sets BOARD, which both boot.mjs instances read.
- **Two lanes, never more than two node runs of mine at once.**
  - `fr3/bin/flane.sh` ran the first runs (FX5, FX6).
  - Then `fr3/bin/qlane.sh` ran twice. Lane A starts only after FX6-fix's lane has exited, and lane B only after FX6-fr2's.
    Each runs a list through `fr3/bin/slane.sh`, then takes from the shared queue `fr3/out/mqueue.txt` under flock.
  - Every node run goes through `bin/run.sh`: the lock is checked first (it was never present, so no run waited), then
    `setsid -w timeout -k 10 600`, with PIDs and commands recorded in `pids.txt`.
  - `npm run check` was run as its own command (`node tools/check.mjs prioritization-board-grid.html`), so npm added no third
    node process.
- **The queue was edited three times under its lock:**
  - the final-harness re-runs were put first;
  - the OOM-killed whole suite was re-queued;
  - the two split parts were added, the clin-by-name run and the base-board run were moved onto the split parts, and one last
    whole try was added.
- **Lane B's own list** (`fr3/out/lane-s1b.txt`) lost its last line, the whole-suite clin-by-name run. The file was truncated
  in place, on the same inode, while the lane was on the line before it; the original is kept as `fr3/out/lane-s1b.orig.txt`.
- **Text helpers** (edit-board3, mkblock3, mkentries4, assemble, check-assembly, mkfocused, mkmut via mkmuts.sh, mcount,
  mksplit, report, git clone and checkout) ran through `bin/bx.sh`, with PIDs recorded. Read-only `ls`, `cat`, `grep`,
  `sed -n`, `diff`, `cmp` and `git hash-object` ran unbounded.
- `pids.txt` also holds two lines (21008, 21085) that are my recording command's own shells, which `pgrep -f` matched. They
  had already exited, and a note there says so.

## What I did not do
- I did not run the full `audit-import.mjs` or `audit-board.mjs`; the lead runs those alone. Their focused blocks ran on fr3/c1:
  hi-w2 242, hi-w1 53, hi-v197w1 15, hi-v197w3 111, hi-v200 167 and hb-v197w1 178, all passing, with the same counts as rounds 1
  and 2.
- I did not import, execute or run `mutate.mjs`. It is text to mkmut.py and mcount.py only. No Chromium, no playwright install.
- Nothing was edited, staged, committed or pushed in /home/user/orbit-board or /home/user/orbit-ui. The scratch clone
  `gc/fr3` was never committed to. The board stays the empty template; synthetic data exists only at run time.
- Not built: a way to put a locked cycle's list right; a remedy in the full import's refusal of a null working-plan entry;
  marks in the pickers and the "N combos" count; a warning at export time that another board will refuse the file; a lossless
  ✕ for the FIRST row of a repeated key; per-kind wording of the advice for packages, submittals and band ladders (m2(a)).
- I did not re-run the round-2 probes (pa, pb, pb2, pc, pd, vprobe3, p2) or the verifiers' q1 to q3. The block's own XLSX
  reads cover the new shapes, and the board's money code (monSheet, rcnAt) is unchanged from round 2 but one comment line.

## Drafts for the lead (fix round 3; they SUPERSEDE `drafts/fr2/*`, `drafts/fr/*` and `drafts/*`)
- `drafts/fr3/NEXT-VERSION-entry.md` (e745a9bb): the v2.00 entry, after the U14 bullet. It says null where round 2 said "an
  entry that is not one", gives the advice's new words and the m1 parenthesis, 165 checks, 96 failing on d66dd60, and the 69
  that pass there (the fixtures, the controls and the money of the four guards), lists 39 mutations, and updates Not covered.
- `drafts/fr3/UNRESOLVED-line.md` (b41254f9): a proposed NEW line, since base has no U32/U33 line. It keeps Brad's open
  question and adds the null working-plan entry that still cannot export.
- `drafts/fr3/LEDGER-append.md` (00545894): text for rows U32 and U33, with `<sha>` and `<time>` placeholders. The evidence
  adds verification round 3, and the status lists 39 mutations.
- `drafts/fr3/COMMIT-MSG.txt` (f81d3d75): the lead adds the attribution lines.

## Fix-round-3 file identities (git hash-object)
- **The copy `fr3/c1`:**
  - board 60bd0c3cf1ab80c008dfb538fe3a9169c2163690;
  - audit-recon e2207681b654fac3a0a956c47308115b221213c1;
  - mutate.mjs.txt 37dea5f128bb8e9c32055c501f453dc78d070ec1;
  - audit-import 4aba2506, audit-board a7c575e5, audit-other d89396b0 and boot.mjs 9c4f49ad, unchanged from base.
  - The first assembly's audit-recon (ebf0447a, with harness 25dc6fa5) is kept as `fr3/out/audit-recon-first.mjs`; it differs
    by four comment lines.
- **Block, entries and harness:** block 13369c80, entries 6b66643d, focused harness 598db47b (first 25dc6fa5, kept as
  `fr3/out/h-cycreg-first.mjs`); `fr3/mut/blobs.txt` b463e68b; `fr3/mutant-failures.txt` 56b07b1c.
- **Diffs against base:** `fr3-c1-board` 415d2148, `fr3-c1-audit-recon` 8f3d2074, `fr3-c1-mutate` 3f829423, `fr3-c1-all`
  0676e6c3.
- **Diffs against round 2:** `fr3-delta-vs-fr2-board` 522038e9, `-audit-recon` 7ed189d4, `-mutate` e627e900, `-block`
  c6403073; and `fr3-harness-first-vs-final` e9dec94b.
- **Scripts:** edit-board3.py 1be121d0, mkblock3.py 56e799a5, mkentries4.py a8fa6e44, mkmuts.sh dc5788dc, mksplit.py 3f87704b,
  report.py 06802eb8, flane.sh 3fbf542a, slane.sh 19893d16, qlane.sh 7d43acb3. Unchanged: `bin/run.sh` 17900e9b,
  `bin/runner.mjs` f851f139, `fr/bin/frr.sh` f961b193, `bin/bx.sh` 31841103, `fr/bin/assemble-suites.py`,
  `fr2/bin/check-assembly.py`.
- **The scratch clone `gc/fr3`** (`git clone --shared --no-checkout /home/user/orbit-board`, detached at 7ee498a, never
  committed to) holds fr3/c1's board and audit-recon (cmp-identical, e2207681). It also holds the focused harnesses listed
  above and the two split parts, hr-minus-v200 d48361f4 and hr-v200 22310d15. One line per file is in
  `fr3/out/gc-fr3-blobs.txt` and `fr3/out/split-blobs.txt`.
