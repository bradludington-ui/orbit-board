# REGTEXT (U36), verifier round 3, LENS B: test adequacy and regressions

Independent adversarial review of the builder's fix-round-2 commit for the REGTEXT track (U36: "an RCN / EEIC title over 80
characters is refused, never cut", plus round 2's clearing of the title's own refusal from the status line). All times are
Eastern (`TZ=America/New_York date`), 13 Oct 2026. Work started 4:31 PM ET; this record was finished at the time in its last
section.

**Stopped attempt:** none to resume. At 4:31 PM ET `rec/L6/regtext/verify-tests-r3` did not exist (`ls` printed nothing), so
everything here was done fresh in this session.

Nothing in the builder's folder, the other verifiers' folders, `/home/user/orbit-board` or `/home/user/orbit-ui` was edited.
Nothing was committed, staged or pushed. `mutate.mjs` was read as text only (mkmut.py, mcount.py); it was never imported or
run. At most two node or Chromium processes of mine ran at a time. The AUDIT_IMPORT_RUNNING lock was checked before every
node or Chromium run (in `bin/run.sh`) and was never present.

## Identities (git hash-object)

| file | base (`base/` = cp of `rec/L6/base`) | builder's c1 = my `c1/` | round 1's board (`fr1/`) | my proposal `prop2/` |
|---|---|---|---|---|
| prioritization-board-grid.html | fce8a391 | abcb8bac | 0949c3ed | abcb8bac (unchanged) |
| tools/export-audit/audit-recon.mjs | 529e36f7 | b2a8b693 | — | 0eeb79b8 |
| tools/export-audit/mutate.mjs.txt | cbc6defc | 7843cae0 | — | c3a55bb0 |
| audit-import / audit-board / audit-other | 4aba2506 / a7c575e5 / d89396b0 | same | — | same |

All match the builder's record and `rec/L6/BASE.txt`. `diff -rq base c1` lists only the three files. The builder's 20 mutants,
rebuilt here with `mkmut.py` from c1's mutate text, are byte-identical to the builder's `mut/fr2/*` (all 20 blobs equal).
Focused harness `harness/h-u36.mjs` 67169982, built with `rec/L3/u14/mkfocused.py` from c1's audit-recon; it differs from the
builder's `harness/fr2/h-u36.mjs` (f93cc9a7) only in the header line naming the source path.

## Verdict: sound-with-issues

The board change is right, and every builder number I re-ran holds exactly (focused block, 20 mutants with the same failing
checks, mcount, every suite, the whole audit-recon check by check, all ten builder probes byte-for-byte). No must-fix.

**Should-fix (tests):** the round-2 clearing is under-tested. **7 of my 8** plausible wrong fixes pass all 24 checks; 4 of
them are wrong versions of the clearing itself, and 2 of those wipe the board's own data-loss warning ("⚠ This change is not
in browser storage") in the same call that says it. The builder's comment and records say "anything save() said stands",
but no check makes save() say anything. A ready proposal (`prop2/`): 3 checks and 4 mutation entries, each check failing on
the base and passing on c1, each entry caught.

## Must-fix
None.

## Should-fix

**S1. The clearing's tests cannot see four wrong clearings, two of which lose a data-loss warning.** Own mutants
(`own/own3r-mutants.json` 20422197, built by `bin/ownmk.py` into `mut/own/`; each find matched the c1 board once), run through
the builder's 24-check block (`harness/h-u36.mjs`):

| mutant (blob) | the wrong fix | block result | what goes wrong (probe `probe/v3clear.mjs` 2e47e18d, run on that mutant) |
|---|---|---|---|
| om1-clears-any-warning (5111b638) | regex widened to `/^⚠/` | **passes 24/24** (V3O-om1) | A: a refused title, then the title corrected while browser storage refuses the save: save() says "⚠ This change is not in browser storage — it was refused (QuotaExceededError) …" and the clear wipes it at once (`[“good title”, false]`, want `true`; V3P-clear2-om1). Also D: item 91's RCN refusal is wiped. |
| om2-clears-text-only (587e7728) | `st.textContent=''` instead of `setStat('')` | **passes 24/24** (V3O-om2) | B: the line is empty but the save state's tooltip still reads "Saved … ⚠ RCN / EEIC title not changed … Nothing was changed." and the line stays marked fresh (`["", "Saved … ⚠ RCN / EEIC title not changed…", true]`, want `["", "", false]`; V3P-clear2-om2). False words after the operation lands (principle 4). |
| om3-clears-only-on-title (a1fa0587) | clear only when `field==='t'` | **passes 24/24** (V3O-om3) | C: an RCN kept after a title refusal leaves "title not changed … Nothing was changed" on the line (V3P-clear2-om3). The records say an RCN or EEIC kept clears it (NEXT-VERSION draft, ledger U36 append, matrix row "The status line after a refused title"); only the builder's probe FR2-clear-c1 shows it, no check. |
| om4-decided-before-save (6bcf535a) | read the line before `save()`, clear after it (the "before save" placement round 2 suggested, done the plausible way) | **passes 24/24** (V3O-om4) | A: save()'s storage warning wiped, as om1 (V3P-clear2-om4). |
| om5-clears-item91-too (026fc3fa) | regex `/^⚠ (RCN|EEIC|RCN \/ EEIC title) not changed\./` (round 2's alternative) | passes 24/24 (V3O-om5) | D: item 91's RCN refusal is cleared after a corrected RCN. The records say item 91 is "left as it was". See Minor 1. |
| om6-clear-says-kept (7528d6ff) | the refusal replaced by "✓ RCN / EEIC title kept." | **caught**, 1 fail: "a refused title corrected in its field" (V3O-om6) | — |
| om7-count-uppercased (3691a878) | the title counted upper-cased, as an EEIC is (R2's rule) | passes 24/24 (V3O-om7) | E: 41 "ß" (41 code points) refused as "82 characters" (V3P-clear2-om7). See Minor 2. |
| om8-formula-plus-minus (3422997a) | the workbook writer makes formulas of cells beginning `+` or `-` | passes 24/24 (V3O-om8) | F: an RCN "-5" and an EEIC "+a1" put 4 `<f>` into the Spend Plan Source (V3P-clear2-om8). See Minor 3. |

On c1 every probe section A–F gives its literal expected value (V3P-clear2-c1, "SAME" on all six). On the base only B
differs (no refusal is ever said, so nothing is cleared and the tooltip keeps "Saved … by …"; V3P-clear2-base); on round 1's
board B and C differ (the refusal stays; V3P-clear2-fr1).

Why it matters for the records: the NEXT-VERSION draft, the commit message and the ledger append say "any other message on
the line stays" and "anything save() says stands", and the matrix row cites the CONTROL "a title kept under another message"
for it. That control sets its message before the title is kept, with no refusal on the line, so it tests only the pattern's
selectivity; nothing makes save() speak in the same call, and nothing reads the tooltip or keeps an RCN after a refusal.

**Minimal fix: adopt `prop2/`** (built from c1 by `own/mkprop.py` 41f243ae, text edits only; exact diffs below and in
`diffs/prop2-vs-c1-audit-recon.mjs.diff` 09cf0704 and `diffs/prop2-vs-c1-mutate.mjs.txt.diff` ab268768). Three checks are
added to the U36 block after "a refused title corrected in its field", in the block's own voice, expected values literals:
- **"a refused title corrected while browser storage refuses the save"**: 81 letters refused, `Storage.prototype.setItem`
  made to throw QuotaExceededError, "good title" typed, setItem put back; expected
  `[no('A'.repeat(60), 81), 'good title', '⚠ This change is not in browser storage — it was refused (QuotaExceededError).']`
  (the line's first 78 characters). It resets `_persistFail` and the title after, so the checks after it see the board as before.
- **"a refused title corrected: the save state's tooltip"**: expected `[no('A'.repeat(60), 81), 'good title', '', false, false]`
  (the tooltip held the refusal; afterwards the line is empty, the tooltip no longer contains "title not changed", and the
  line is not marked fresh). It reads "contains", not "equals ''", because `setStat('')` also drops the tooltip's "Saved …
  by …" part (Minor 5), which a later fix may rightly put back.
- **"a refused title, then an RCN kept"**: the RCN changed to 22222 after a title refusal; expected
  `[no('A'.repeat(60), 81), 'base', '22222', '']`; the RCN is put back to 11111 after.

Four entries after the builder's twenty, before the R3 comment line: `v200-regtext-clears-any-warning` (om1),
`v200-regtext-clear-decided-before-save` (om4), `v200-regtext-clear-text-only` (om2), `v200-regtext-clear-title-only` (om3);
each mutant built by `mkmut.py` from prop2's mutate text is byte-identical to my own mutant of the same change.

Results on the proposal harness `harness-prop2/h-u36-prop2.mjs` (59d88c9e):
- c1 board: ALL CHECKS PASSED, 27/27 (V3PR2-c1). Base: 17 fail, the 10 controls pass (V3PR2-base); the 3 new checks fail there
  because no refusal is ever said (first element `''`). Round 1's board: 3 fail, the M1 check and two of the new ones
  (V3PR2-fr1).
- The 4 new entries: each caught, 1 fail each, by the check named for it (V3PR2-clears-any-warning, -clear-decided-before-save:
  the storage check; -clear-text-only: the tooltip check; -clear-title-only: the RCN check).
- The builder's 20 mutants: all still caught on the proposal harness (V3PR2M-*; the counts rise only where a mutant also
  breaks a new check: title-no-limit and refused-but-kept 14, kept-unsaved 4, kept-not-drawn 3, refusal-left-standing 3,
  clears-any-message 2).
- Whole audit-recon on a scratch clone with the proposal (`gc/prop2`): ALL CHECKS PASSED, 333 checks; against my c1 stream,
  0 checks only in c1, 3 only in the proposal (all U36), 0 with a different verdict or observed value
  (`out/cmpchecks-audit-recon-prop2.txt`).
- mcount (text only): prop2 mutate on the c1 board 1352/1352 once; base mutate on the c1 board 1328/1328 once; prop2 mutate on
  the base board 1331 once, 21 U36 ids missing as they should be (`out/mcount-prop*.txt`).

If the lead adopts it, these record sentences change (no other words): NEXT-VERSION "Test": "(27 checks)", add after "…and
the refusal gone from the status line": "; the same corrected while browser storage refuses the save (save()'s own warning
stays on the line); the save state's tooltip no longer carrying the refusal; and an RCN kept after a refusal, which clears it
too", and "17 checks fail on the board before this change"; "Mutations": add `-clears-any-warning`, `-clear-decided-before-save`,
`-clear-text-only`, `-clear-title-only` (24 entries); COMMIT-MSG: "27 checks. 17 fail on d66dd60" and the four ids; ledger
U36 append: "27/27 … 17 fail before it … 24 mutations". The matrix row "The status line after a refused title" can then cite
these three checks for "any other message stays" and "an RCN or EEIC kept".

## Minor
1. **Item 91's refusal staying is unpinned.** om5 passes the block. The records say "Item 91's own code refusals are not
   cleared this way"; only the builder's probe (FR2-v2stale) shows it. If the lead wants the sentence held, add a CONTROL
   (my probe section D: RCN "12345678901" refused, then "44444": kept, line still the RCN refusal). It pins a known limit, so I
   left it out of the proposal.
2. **The count is not pinned against upper-casing.** om7 passes the block; a CONTROL "41 ß kept, nothing said" (probe
   section E) would catch it.
3. **The formula evidence covers `=` and `@` only.** The block's control types "=1+1" and "@a1"; the builder's r3formula probe
   adds "+3+3" in the workbook; a cell beginning `-` is checked nowhere. om8 passes the block (4 `<f>` in the Spend Plan
   Source, V3P-clear2-om8). The matrix row "Workbook formulas" should say a cell beginning `-` was not checked, or the control
   could type "-5" (probe section F gives `[0, 0, ['+A1', '-5']]` on c1). Brad's brief names `=, +, -, @`.
4. **The clear is wider than M1 needs.** M1 was "not changed" said of a title just changed, which only the same row's title
   can make false. c1 also clears a still-true refusal when another row's title, or any RCN or EEIC, is kept; render() has
   then already put back that field's stored value, so nothing on screen says the typed title was refused (probe section G:
   row 0 refused, row 1's title kept: line `''` on c1; on round 1's board the refusal stays; V3P-clear2-c1 / -fr1). The
   records state this behaviour, so it is a design note, not a false word.
5. **The tooltip loses "Saved … by …".** After a refusal and a correction, the save state's tooltip is `''` on c1, where a
   plain kept title leaves "Saved Oct 13 8:57 PM by unknown. " (probe B on the base). This is what every `setStat` call does
   to the tooltip, so it is existing behaviour, until the next redraw.
6. **The M1 check fails on the base only through its first element** (no refusal is said there); its "line empty" element is
   discriminated only against round 1's board, where it does fail (V3F-fr1). This is adequate; noted so its base failure is not
   read as covering the stale line.
7. The 10 CONTROLS pass on the base, as house style allows (audit-recon has 84 CONTROL lines on the base).

## The builder's claims, re-run and compared

| claim | my run | result |
|---|---|---|
| focused block: c1 24/24; base 14 fail, 10 controls pass; round 1's board exactly 1 fail (M1) | V3F-c1 (4:33:50 PM, exit 0), V3F-base (4:33:50 PM, exit 1), V3F-fr1 (4:34:33 PM, exit 1) | same; the 14 failing checks on the base are the builder's 14 |
| 20 mutants caught (11, 3, 4, 11, 2, 2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1 failing) | V3M-* (4:40:27 to 4:46:21 PM, each exit 1) | **same counts and the same failing checks for all 20** (`bin/cmpfails.py` against `out/FR2-M-fails.txt`: 20 SAME) |
| mcount: c1 mutate on the c1 board 1348/1348 once; base mutate on the c1 board 1328/1328; c1 mutate on the base board 1331 once, 17 U36 ids missing | `out/mcount-*.txt` (text only) | same |
| 306 existing audit-recon checks keep verdict and observed value; 330/330 | V3S-audit-recon-c1 (5:00:05 PM, exit 0, 212.1 s, 330/330) against **my own** V3S-audit-recon-base (5:03:48 PM, exit 0, 192.5 s, 306/306) | **0 only in the base, 24 only in c1 (all U36), 0 different** (`out/cmpchecks-audit-recon.txt`); my base stream is line-for-line identical to verifier B's (7946cd78) |
| other suites pass on the final copy | boot-same, audit, audit-ppt, legacy-fsrc, npm run check, audit-other, audit-inject, audit-hostile on `gc/c1` | all exit 0, pass lines below |
| audit-hostile unchanged | V3S-audit-hostile-c1 vs V3S-audit-hostile-base | 124/124 both; 0 / 0 / 0 differences (`out/cmpchecks-audit-hostile.txt`) |
| probes v2stale, v2chrome (Chromium 141), r3formula (incl. the formula-cells mutant), fr2-clear, v2 (money verifier) | V3B-* (5:07:29 to 5:08:24 PM, each exit 0) | **output identical to the builder's FR2-* logs** once times and paths are set aside (`out/cmp-*.txt`, all empty) |
| no existing expectation edited | `diff base c1`: audit-recon +162/-0, mutate.mjs.txt +61/-0; audit-import, audit-board, audit-other unchanged | **true: pure additions; no changed existing expectation to list** |

## Literals, and fails-on-the-base
- Every expected value in the 24 checks is a literal or built only from the test's own literals (`'A'.repeat(60)`, `E80`,
  `L100`, the `no()` sentence template, `F`). Board helpers appear only on the observed side (rcnSet, setStat to set up a
  message, w6Book / xlsxRead, exportSrc, buildSavedHtml, rcnReg, render).
- The round-2 additions: "a refused title corrected in its field" fails on the base (V3F-base) and on round 1's board
  (V3F-fr1) and passes on c1; the CONTROLS "a title kept under another message" and the Spend Plan Source codes pass on both,
  and each catches its own entry (clears-any-message, formula-cells). Verifier B's six (adopted verbatim): 3 fail on the base,
  3 controls.
- House shape matches the U14 block: async wrapper, `bootMark` / `bootRelease(__bm, [])` / `settleBoards`, the two-space
  `  const name = '…';` line, the `// ====` markers. Entries are `{ id, area, what, find, repl }`, ids `v200-regtext-*`,
  before the R3 comment line.
- By reading: audit-board calls rcnSet only for `'rcn'` / `'eeic'` (lines 4063, 4112, 4145) and reads the status only right
  after a refusal, where the new line is never reached; no other suite types a title. The clearing touches nothing else.

## Suites (scratch clones `gc/c1` = 7ee498a + the c1 board and audit-recon; `gc/base` = clean 7ee498a; never committed)

| suite | c1 | base |
|---|---|---|
| boot-same | V3S-boot-same-c1 4:58:51 PM, exit 0, 19.4 s, "every page, source, save and error list is identical either way" | (the builder's and verifier B's base runs stand; the base did not change) |
| audit | V3S-audit-c1 4:59:11 PM, exit 0, 20.5 s, ALL CHECKS PASSED | as above |
| audit-ppt | V3S-audit-ppt-c1 4:59:31 PM, exit 0, 10.4 s, ALL CHECKS PASSED | as above |
| legacy-fsrc | V3S-legacy-fsrc-c1 4:59:42 PM, exit 0, 6.1 s, "every legacy Force setting computes exactly as before" | as above |
| npm run check | V3S-check-c1 4:59:48 PM, exit 0, 7.8 s, "all checks passed" | as above |
| audit-recon | V3S-audit-recon-c1 5:00:05 PM, exit 0, 212.1 s, 330/330 | **V3S-audit-recon-base 5:03:48 PM, exit 0, 192.5 s, 306/306** |
| audit-other | V3S-audit-other-c1 5:07:19 PM, exit 0, 59.8 s, ALL CHECKS PASSED | as above |
| audit-inject | V3S-audit-inject-c1 5:08:19 PM, exit 0, 23.9 s, ALL CHECKS PASSED | as above |
| audit-hostile | V3S-audit-hostile-c1 5:09:00 PM, exit 0, 95.5 s, 124/124 | **V3S-audit-hostile-base 5:10:35 PM, exit 0, 73.0 s, 124/124** |
| audit-recon (proposal) | V3S-audit-recon-prop2 5:09:00 PM, exit 0, 175.8 s, 333/333 (`gc/prop2`) | — |

Exact start times are in the run table below and `logs/runs.txt`.

## The board change (c1 against round 1's board, `diffs/fr1-to-c1-board.diff` 0f24295e)
```diff
@@ -10883,6 +10883,9 @@
     if(n>80){ codeRefusedIn(el, 'RCN / EEIC title not changed', 'The title '+inShow(t)+' is '+n+' characters; it can be at most 80. Nothing was changed'); return; }
     e.t=t; }
   save(); render();
+  // v2.00 (U36): a title refusal still on the line once a value is kept here would say "not changed" of a title just
+  // changed, so it goes. Only that refusal, and only if nothing has been said since: anything save() said stands.
+  const st=document.getElementById('shareStat'); if(st && /^⚠ RCN \/ EEIC title not changed\./.test(st.textContent)) setStat('');
 }
```
Read against the board: `setStat('')` bumps `_statN`, sets the line and the save state's tooltip to `''` and clears the fresh
mark; `persist()`'s refusal text begins "⚠ This change", `cycRefuse`'s begins "🔒", so neither matches the pattern and both
stand (probe A on c1). The full base diffs are `diffs/base-to-c1-*.diff` (board e15dfc6e, audit-recon dd369a9c, mutate
d2ada51b), the same content as the builder's `diffs/c1-*.diff`.

## The proposal, exactly (`prop2/` against `c1/`)
`diffs/prop2-vs-c1-audit-recon.mjs.diff` (58 lines; the 4 removed lines are the builder's own new header comment, now
recounted) and `diffs/prop2-vs-c1-mutate.mjs.txt.diff` (21 lines, pure addition). Read them there; their content is the three
checks and four entries described under S1.

## Decisions, with reasons
- **No must-fix.** The code is right in every case I probed (A–F on c1 all SAME), every builder number re-ran exactly, and no
  existing expectation changed. The gaps are in what the tests can see, so they are should-fix, as round 2 classed the same
  kind of gap.
- **The storage-warning gap is the first should-fix**, not a minor: the wrong clearings it lets through lose "⚠ This change
  is not in browser storage", the board's own data-loss notice, and the records claim exactly the property that is untested.
- **The proposal holds three checks and four entries only.** Item 91's stale refusal (om5) is a stated limit the lead may
  change; pinning it would make that change edit an expectation, so it is offered as a choice (Minor 1). The `ß` count and the
  `-` cell are cheap controls but off the round-2 change, so they are minor.
- **The proposal's tooltip check reads "still names the refusal", not "is empty"**, so it does not pin `setStat`'s existing
  habit of dropping "Saved … by …" from the tooltip (Minor 5).
- **My own base audit-recon and audit-hostile were run**, rather than relying only on verifier B's streams, because those are
  the suites with check-by-check streams; the other base suites did not change and their earlier runs stand.

## Every run (all through `bin/run.sh`: setsid -w timeout -k 10 600, lock checked first, PIDs recorded)
Focused runs use `bin/runner.mjs` (verifier B's, unchanged) with root `c1` and, for other boards, BOARD set to the board named;
proposal runs use root `prop2`. Text-only runs (mcount, mkmut, mkfocused, ownmk, mkprop, cmpchecks, clones, copies) went
through `bin/bx.sh` (setsid -w timeout -k 10 600) and are in `pids.txt`; each exited 0.

See `out/runs-table.md` (generated from `logs/runs.txt`), reproduced here:

| label | start (ET, 13 Oct) | exit | wall s | log | result |
|---|---|---|---|---|---|
| V3F-c1 | 16:33:50 | 0 | 31.2 | logs/V3F-c1.log | ALL CHECKS PASSED, 24p/0f |
| V3F-base | 16:33:50 | 1 | 34.8 | logs/V3F-base.log | 14 FAILING CHECK(S), 10p/14f |
| V3F-fr1 | 16:34:33 | 1 | 27.7 | logs/V3F-fr1.log | 1 FAILING CHECK(S), 23p/1f |
| V3M-v200-regtext-count-untrimmed | 16:40:27 | 1 | 36.6 | logs/V3M-v200-regtext-count-untrimmed.log | 2 FAILING CHECK(S), 22p/2f |
| V3M-v200-regtext-title-no-limit | 16:40:27 | 1 | 40.2 | logs/V3M-v200-regtext-title-no-limit.log | 11 FAILING CHECK(S), 13p/11f |
| V3M-v200-regtext-preview-untrimmed | 16:41:04 | 1 | 41.6 | logs/V3M-v200-regtext-preview-untrimmed.log | 1 FAILING CHECK(S), 23p/1f |
| V3M-v200-regtext-title-cut | 16:41:07 | 1 | 43.2 | logs/V3M-v200-regtext-title-cut.log | 3 FAILING CHECK(S), 21p/3f |
| V3M-v200-regtext-refused-but-saved | 16:41:46 | 1 | 42.0 | logs/V3M-v200-regtext-refused-but-saved.log | 1 FAILING CHECK(S), 23p/1f |
| V3M-v200-regtext-title-halves | 16:41:51 | 1 | 41.4 | logs/V3M-v200-regtext-title-halves.log | 4 FAILING CHECK(S), 20p/4f |
| V3M-v200-regtext-kept-unsaved | 16:42:28 | 1 | 37.6 | logs/V3M-v200-regtext-kept-unsaved.log | 2 FAILING CHECK(S), 22p/2f |
| V3M-v200-regtext-refused-but-kept | 16:42:33 | 1 | 50.6 | logs/V3M-v200-regtext-refused-but-kept.log | 11 FAILING CHECK(S), 13p/11f |
| V3M-v200-regtext-kept-not-drawn | 16:43:06 | 1 | 29.3 | logs/V3M-v200-regtext-kept-not-drawn.log | 2 FAILING CHECK(S), 22p/2f |
| V3M-v200-regtext-field-unmarked | 16:43:24 | 1 | 32.3 | logs/V3M-v200-regtext-field-unmarked.log | 2 FAILING CHECK(S), 22p/2f |
| V3M-v200-regtext-field-maxlength | 16:43:44 | 1 | 30.1 | logs/V3M-v200-regtext-field-maxlength.log | 1 FAILING CHECK(S), 23p/1f |
| V3M-v200-regtext-file-title-shown-cut | 16:44:02 | 1 | 30.7 | logs/V3M-v200-regtext-file-title-shown-cut.log | 1 FAILING CHECK(S), 23p/1f |
| V3M-v200-regtext-count-glyphs | 16:44:15 | 1 | 37.7 | logs/V3M-v200-regtext-count-glyphs.log | 1 FAILING CHECK(S), 23p/1f |
| V3M-v200-regtext-long-title-retyped | 16:44:33 | 1 | 36.5 | logs/V3M-v200-regtext-long-title-retyped.log | 2 FAILING CHECK(S), 22p/2f |
| V3M-v200-regtext-count-normalized | 16:44:53 | 1 | 35.0 | logs/V3M-v200-regtext-count-normalized.log | 1 FAILING CHECK(S), 23p/1f |
| V3M-v200-regtext-refusal-left-standing | 16:45:10 | 1 | 34.7 | logs/V3M-v200-regtext-refusal-left-standing.log | 1 FAILING CHECK(S), 23p/1f |
| V3M-v200-regtext-empty-refused | 16:45:28 | 1 | 36.1 | logs/V3M-v200-regtext-empty-refused.log | 1 FAILING CHECK(S), 23p/1f |
| V3M-v200-regtext-clears-any-message | 16:45:45 | 1 | 36.0 | logs/V3M-v200-regtext-clears-any-message.log | 1 FAILING CHECK(S), 23p/1f |
| V3M-v200-regtext-spaces-collapsed | 16:46:05 | 1 | 34.6 | logs/V3M-v200-regtext-spaces-collapsed.log | 1 FAILING CHECK(S), 23p/1f |
| V3M-v200-regtext-formula-cells | 16:46:21 | 1 | 29.5 | logs/V3M-v200-regtext-formula-cells.log | 1 FAILING CHECK(S), 23p/1f |
| V3O-om5-clears-item91-too | 16:55:37 | 0 | 19.6 | logs/V3O-om5-clears-item91-too.log | ALL CHECKS PASSED, 24p/0f |
| V3O-om1-clears-any-warning | 16:55:37 | 0 | 20.2 | logs/V3O-om1-clears-any-warning.log | ALL CHECKS PASSED, 24p/0f |
| V3O-om6-clear-says-kept | 16:55:57 | 1 | 16.1 | logs/V3O-om6-clear-says-kept.log | 1 FAILING CHECK(S), 23p/1f |
| V3O-om2-clears-text-only | 16:55:57 | 0 | 17.1 | logs/V3O-om2-clears-text-only.log | ALL CHECKS PASSED, 24p/0f |
| V3O-om7-count-uppercased | 16:56:13 | 0 | 17.1 | logs/V3O-om7-count-uppercased.log | ALL CHECKS PASSED, 24p/0f |
| V3O-om3-clears-only-on-title | 16:56:15 | 0 | 19.2 | logs/V3O-om3-clears-only-on-title.log | ALL CHECKS PASSED, 24p/0f |
| V3O-om8-formula-plus-minus | 16:56:30 | 0 | 16.7 | logs/V3O-om8-formula-plus-minus.log | ALL CHECKS PASSED, 24p/0f |
| V3O-om4-decided-before-save | 16:56:34 | 0 | 17.1 | logs/V3O-om4-decided-before-save.log | ALL CHECKS PASSED, 24p/0f |
| V3P-clear-c1 | 16:56:55 | 0 | 6.0 | logs/V3P-clear-c1.log | superseded: the probe had no requirement, so section F made no file; re-run seeded as V3P-clear2-c1 |
| V3P-clear2-c1 | 16:57:17 | 0 | 6.1 | logs/V3P-clear2-c1.log | probe: no DIFFERS |
| V3P-clear2-om4 | 16:57:36 | 0 | 8.0 | logs/V3P-clear2-om4.log | probe: 1 DIFFERS line(s) |
| V3P-clear2-base | 16:57:36 | 0 | 8.4 | logs/V3P-clear2-base.log | probe: 1 DIFFERS line(s) |
| V3P-clear2-fr1 | 16:57:44 | 0 | 8.2 | logs/V3P-clear2-fr1.log | probe: 2 DIFFERS line(s) |
| V3P-clear2-om5 | 16:57:44 | 0 | 8.6 | logs/V3P-clear2-om5.log | probe: 1 DIFFERS line(s) |
| V3P-clear2-om7 | 16:57:53 | 0 | 8.7 | logs/V3P-clear2-om7.log | probe: 1 DIFFERS line(s) |
| V3P-clear2-om1 | 16:57:52 | 0 | 9.1 | logs/V3P-clear2-om1.log | probe: 2 DIFFERS line(s) |
| V3P-clear2-om8 | 16:58:01 | 0 | 6.7 | logs/V3P-clear2-om8.log | probe: 1 DIFFERS line(s) |
| V3P-clear2-om2 | 16:58:02 | 0 | 7.0 | logs/V3P-clear2-om2.log | probe: 1 DIFFERS line(s) |
| V3P-clear2-om3 | 16:58:09 | 0 | 7.2 | logs/V3P-clear2-om3.log | probe: 1 DIFFERS line(s) |
| V3PR-c1 | 16:58:23 | 0 | 13.3 | logs/V3PR-c1.log | ALL CHECKS PASSED, 27p/0f |
| V3PR-base | 16:58:37 | 1 | 17.4 | logs/V3PR-base.log | 17 FAILING CHECK(S), 10p/17f |
| V3PR-fr1 | 16:58:54 | 1 | 12.8 | logs/V3PR-fr1.log | 3 FAILING CHECK(S), 24p/3f |
| V3S-boot-same-c1 | 16:58:51 | 0 | 19.4 | logs/V3S-boot-same-c1.log | every page, source, save and error list is identical either way |
| V3S-audit-c1 | 16:59:11 | 0 | 20.5 | logs/V3S-audit-c1.log | ALL CHECKS PASSED |
| V3S-audit-ppt-c1 | 16:59:31 | 0 | 10.4 | logs/V3S-audit-ppt-c1.log | ALL CHECKS PASSED |
| V3S-legacy-fsrc-c1 | 16:59:42 | 0 | 6.1 | logs/V3S-legacy-fsrc-c1.log | every legacy Force setting computes exactly as before |
| V3PR2-c1 | 16:59:32 | 0 | 16.0 | logs/V3PR2-c1.log | ALL CHECKS PASSED, 27p/0f |
| V3S-check-c1 | 16:59:48 | 0 | 7.8 | logs/V3S-check-c1.log | all checks passed |
| V3PR2-base | 16:59:48 | 1 | 16.4 | logs/V3PR2-base.log | 17 FAILING CHECK(S), 10p/17f |
| V3PR2-fr1 | 17:00:05 | 1 | 14.6 | logs/V3PR2-fr1.log | 3 FAILING CHECK(S), 24p/3f |
| V3PR2-clears-any-warning | 17:00:19 | 1 | 13.0 | logs/V3PR2-clears-any-warning.log | 1 FAILING CHECK(S), 26p/1f |
| V3PR2-clear-decided-before-save | 17:00:32 | 1 | 16.1 | logs/V3PR2-clear-decided-before-save.log | 1 FAILING CHECK(S), 26p/1f |
| V3PR2-clear-text-only | 17:00:49 | 1 | 15.4 | logs/V3PR2-clear-text-only.log | 1 FAILING CHECK(S), 26p/1f |
| V3PR2-clear-title-only | 17:01:04 | 1 | 15.9 | logs/V3PR2-clear-title-only.log | 1 FAILING CHECK(S), 26p/1f |
| V3PR2M-title-no-limit | 17:01:29 | 1 | 15.3 | logs/V3PR2M-title-no-limit.log | 14 FAILING CHECK(S), 13p/14f |
| V3PR2M-title-cut | 17:01:44 | 1 | 15.0 | logs/V3PR2M-title-cut.log | 3 FAILING CHECK(S), 24p/3f |
| V3PR2M-title-halves | 17:01:59 | 1 | 15.1 | logs/V3PR2M-title-halves.log | 4 FAILING CHECK(S), 23p/4f |
| V3PR2M-refused-but-kept | 17:02:15 | 1 | 18.0 | logs/V3PR2M-refused-but-kept.log | 14 FAILING CHECK(S), 13p/14f |
| V3PR2M-field-unmarked | 17:02:33 | 1 | 15.5 | logs/V3PR2M-field-unmarked.log | 2 FAILING CHECK(S), 25p/2f |
| V3PR2M-count-untrimmed | 17:02:48 | 1 | 13.3 | logs/V3PR2M-count-untrimmed.log | 2 FAILING CHECK(S), 25p/2f |
| V3PR2M-preview-untrimmed | 17:03:02 | 1 | 12.3 | logs/V3PR2M-preview-untrimmed.log | 1 FAILING CHECK(S), 26p/1f |
| V3S-audit-recon-c1 | 17:00:05 | 0 | 212.1 | logs/V3S-audit-recon-c1.log | ALL CHECKS PASSED |
| V3PR2M-refused-but-saved | 17:03:22 | 1 | 16.5 | logs/V3PR2M-refused-but-saved.log | 1 FAILING CHECK(S), 26p/1f |
| V3PR2M-kept-unsaved | 17:03:39 | 1 | 11.5 | logs/V3PR2M-kept-unsaved.log | 4 FAILING CHECK(S), 23p/4f |
| V3PR2M-kept-not-drawn | 17:03:50 | 1 | 11.6 | logs/V3PR2M-kept-not-drawn.log | 3 FAILING CHECK(S), 24p/3f |
| V3PR2M-field-maxlength | 17:04:02 | 1 | 13.4 | logs/V3PR2M-field-maxlength.log | 1 FAILING CHECK(S), 26p/1f |
| V3PR2M-count-glyphs | 17:04:16 | 1 | 12.4 | logs/V3PR2M-count-glyphs.log | 1 FAILING CHECK(S), 26p/1f |
| V3PR2M-count-normalized | 17:04:28 | 1 | 15.3 | logs/V3PR2M-count-normalized.log | 1 FAILING CHECK(S), 26p/1f |
| V3PR2M-empty-refused | 17:04:44 | 1 | 12.8 | logs/V3PR2M-empty-refused.log | 1 FAILING CHECK(S), 26p/1f |
| V3PR2M-spaces-collapsed | 17:05:05 | 1 | 13.3 | logs/V3PR2M-spaces-collapsed.log | 1 FAILING CHECK(S), 26p/1f |
| V3PR2M-file-title-shown-cut | 17:05:18 | 1 | 11.7 | logs/V3PR2M-file-title-shown-cut.log | 1 FAILING CHECK(S), 26p/1f |
| V3PR2M-long-title-retyped | 17:05:30 | 1 | 12.3 | logs/V3PR2M-long-title-retyped.log | 2 FAILING CHECK(S), 25p/2f |
| V3PR2M-refusal-left-standing | 17:05:42 | 1 | 12.6 | logs/V3PR2M-refusal-left-standing.log | 3 FAILING CHECK(S), 24p/3f |
| V3PR2M-clears-any-message | 17:05:55 | 1 | 13.7 | logs/V3PR2M-clears-any-message.log | 2 FAILING CHECK(S), 25p/2f |
| V3PR2M-formula-cells | 17:06:09 | 1 | 15.9 | logs/V3PR2M-formula-cells.log | 1 FAILING CHECK(S), 26p/1f |
| V3PR2M-om5 | 17:06:25 | 0 | 13.3 | logs/V3PR2M-om5.log | ALL CHECKS PASSED, 27p/0f |
| V3PR2M-om7 | 17:06:38 | 0 | 16.0 | logs/V3PR2M-om7.log | ALL CHECKS PASSED, 27p/0f |
| V3S-audit-recon-base | 17:03:48 | 0 | 192.5 | logs/V3S-audit-recon-base.log | ALL CHECKS PASSED |
| V3PR2M-om8 | 17:06:54 | 0 | 10.5 | logs/V3PR2M-om8.log | ALL CHECKS PASSED, 27p/0f |
| V3B-v2stale-c1 | 17:07:29 | 0 | 4.4 | logs/V3B-v2stale-c1.log | output identical to the builder's FR2-v2stale-c1 (times and paths aside, out/cmp-v2stale-c1.txt empty); its 0 DIFFERS line(s) are the builder's too |
| V3B-v2stale-base | 17:07:34 | 0 | 4.6 | logs/V3B-v2stale-base.log | output identical to the builder's FR2-v2stale-base (times and paths aside, out/cmp-v2stale-base.txt empty); its 0 DIFFERS line(s) are the builder's too |
| V3B-v2chrome-c1 | 17:07:38 | 0 | 5.8 | logs/V3B-v2chrome-c1.log | output identical to the builder's FR2-v2chrome-c1 (times and paths aside, out/cmp-v2chrome-c1.txt empty); its 0 DIFFERS line(s) are the builder's too |
| V3B-v2chrome-base | 17:07:44 | 0 | 6.2 | logs/V3B-v2chrome-base.log | output identical to the builder's FR2-v2chrome-base (times and paths aside, out/cmp-v2chrome-base.txt empty); its 3 DIFFERS line(s) are the builder's too |
| V3B-r3formula-c1 | 17:07:51 | 0 | 5.3 | logs/V3B-r3formula-c1.log | output identical to the builder's FR2-r3formula-c1 (times and paths aside, out/cmp-r3formula-c1.txt empty); its 0 DIFFERS line(s) are the builder's too |
| V3B-r3formula-base | 17:07:56 | 0 | 5.0 | logs/V3B-r3formula-base.log | output identical to the builder's FR2-r3formula-base (times and paths aside, out/cmp-r3formula-base.txt empty); its 0 DIFFERS line(s) are the builder's too |
| V3B-r3formula-mut | 17:08:01 | 0 | 4.9 | logs/V3B-r3formula-mut.log | output identical to the builder's FR2-r3formula-mut (times and paths aside, out/cmp-r3formula-mut.txt empty); its 2 DIFFERS line(s) are the builder's too |
| V3B-clear-c1 | 17:08:06 | 0 | 5.5 | logs/V3B-clear-c1.log | output identical to the builder's FR2-clear-c1 (times and paths aside, out/cmp-clear-c1.txt empty); its 0 DIFFERS line(s) are the builder's too |
| V3S-audit-other-c1 | 17:07:19 | 0 | 59.8 | logs/V3S-audit-other-c1.log | ALL CHECKS PASSED |
| V3B-v2probe-c1 | 17:08:11 | 0 | 12.2 | logs/V3B-v2probe-c1.log | output identical to the builder's FR2-v2probe-c1 (times and paths aside, out/cmp-v2probe-c1.txt empty); its 2 DIFFERS line(s) are the builder's too |
| V3B-v2probe-base | 17:08:24 | 0 | 15.1 | logs/V3B-v2probe-base.log | output identical to the builder's FR2-v2probe-base (times and paths aside, out/cmp-v2probe-base.txt empty); its 2 DIFFERS line(s) are the builder's too |
| V3S-audit-inject-c1 | 17:08:19 | 0 | 23.9 | logs/V3S-audit-inject-c1.log | ALL CHECKS PASSED |
| V3S-audit-hostile-c1 | 17:09:00 | 0 | 95.5 | logs/V3S-audit-hostile-c1.log | ALL CHECKS PASSED |
| V3S-audit-hostile-base | 17:10:35 | 0 | 73.0 | logs/V3S-audit-hostile-base.log | ALL CHECKS PASSED |
| V3S-audit-recon-prop2 | 17:09:00 | 0 | 175.8 | logs/V3S-audit-recon-prop2.log | ALL CHECKS PASSED |

Superseded, kept as history: `V3PR-*` (my first proposal `prop/`, harness f7508f63, whose tooltip check compared the whole
tooltip to `''`; replaced by prop2 for the reason in S1); `V3P-clear-c1` (the probe before it was given a requirement).

## PIDs
`pids.txt` holds every timeout PID and its child, with the command, from `bin/run.sh` and `bin/bx.sh` (335 lines). At
5:12:19 PM ET none of them was running (`ps -p` on each). I killed nothing. One background wait loop of mine that could not end
(its `pgrep -f` matched its own command line) was stopped through the task tool (task bq37r34lf), not by PID; it ran no node.

## Deviations
- Read-only commands (`ls`, `cat`, `sed -n`, `grep`, `diff`, `cmp`, `wc`, `git hash-object`, `git status/log` on the scratch
  clones, `ps`, `free`, `uptime`, `date`), small file writes (heredocs of `bin/*.sh`, `bin/cmpfails.py`, `own/*.py`, this
  README, two inline python edits of `probe/v3clear.mjs` and `own/mkprop.py`, the run-table generator), `ln -s`, `cp` into the
  scratch clones, and the background `until … sleep` wait loops ran without the 600 s bound. None runs node or Chromium.
- One `sleep 1` ran in the foreground after the first focused pair.
- Loop wrappers (`bin/mutloop.sh`, `bin/proploop*.sh`, `bin/probeloop.sh`, `bin/bprobes.sh`, `bin/suites.sh`) ran inside
  `bin/bx.sh`'s 600 s cap; every node run inside them had its own cap. None hit a cap.

## What I did NOT do
- Run the full `audit-import.mjs` or `audit-board.mjs` (the lead's), or any focused audit-board harness (by reading, no
  audit-board check reaches the new line).
- Import, execute or run `mutate.mjs`; it was read as text only.
- Edit, stage, commit or push anything in /home/user/orbit-board or /home/user/orbit-ui, or in the builder's folder or the
  other verifiers' folders. The scratch clones `gc/c1`, `gc/base`, `gc/prop2` were never committed to.
- Run `playwright install`; the one Chromium probe (v2chrome) used /opt/pw-browsers/chromium and the copy's playwright-core.
- Re-run base suites other than audit-recon and audit-hostile (the base did not change; the builder's and verifier B's base
  runs of the others stand).
- Re-run the builder's round-1 or verifier rounds' own mutants (`own2-*`, `own3-*`, round 1's 14): the builder's 20 entries
  include their effective ones, and each is caught.
- Check Excel, LibreOffice, PowerPoint or a PDF; or a real browser for the round-2 clearing beyond the builder's v2chrome step 5.
- Build or run the records-only variant of M1 (the lead's choice, described by the builder).
- Change the board from the empty template; synthetic data only at run time.

Record finished: 5:14 PM ET, 13 Oct 2026.
