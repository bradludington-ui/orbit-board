# YEARSEL (U34) — independent verifier, round 3, LENS B (test adequacy and regressions)

Folder: `rec/L6/yearsel/verify-tests-r3` (this folder). I started at 2:57 PM ET on 13 Oct. The folder did not exist then, so no
stopped attempt of this review left work to reuse. Nothing here edits the builder's files. Every copy, harness, mutant and
clone is my own. Nothing was committed or pushed. orbit-board was only read: `git clone --shared` into my own scratch clones,
then `git checkout 7ee498a` inside those clones. orbit-ui was not touched. I wrote this README between 5:11 and 5:13 PM ET.

## Verdict: sound, with one test gap to close (no must-fix)

- **Everything the builder reports for this round reproduced, value for value**, on my own copies:
  - **The U34 block (39 checks):** none fail on c3, 28 fail on the base, 6 fail on c1. The values are identical to the builder's FR4.
  - **U14's 63 checks** pass on c3 and on the base, identical to the builder's.
  - **audit-recon in full on c3:** 345 pass, identical to the builder's FS3. Its 306 base checks are identical to a base run.
  - **The 33 catalog mutants:** each is byte-identical to the builder's. Each is caught, and each fails the same set of checks as the builder's FM3.
  - **npm run check:** the output equals the builder's. Against the base, only the size and line counts differ.
  - **mcount:** 1,361 / 1,361 on c3. The base, c1 and c2 catalogs count once on c3.
  - **The P1 and NaN probes:** equal to the builder's FP1 and FP2, except for the fixture's save time. All 26 + 26 workbooks are well-formed.
- **No existing check, fixture or expected value changed.** audit-recon base→c3 is `+263 −0`, all inside the new U34 block
  after U14's end marker. mutate.mjs.txt base→c3 is `+105 −0`, all before the R3 line. No other suite file changed.
- **Four of my ten plausible wrong fixes pass all 39 U34 checks.** All four are wording faults on the panel and in the
  export's NOTE: `om3-more-counts-all`, `om3-more-at-three`, `om3-counts-saved-years` and `om3-cut-then-escape`. One of them
  makes the export's NOTE name a year that is not counted. A measured addition closes all four: four shapes and four catalog
  entries (`proposal/c4`, section 6). Its four new checks fail on the base and pass on c3, and each catches its own mutant.
  - A fifth survivor, the panel's notice order, I judge harmless. I propose nothing for it.
- **The board itself measured right everywhere I looked.** The minor points are in section 7.

## 1. Identities (my copies in `copies/`, made with `cp -a` from rec/L6/base and the builder's c1/c2/c3)

| copy | board | audit-recon | mutate.mjs.txt | audit-import / audit-board / audit-other / boot.mjs |
|---|---|---|---|---|
| base (`7ee498a`, product `d66dd60`) | `fce8a391` | `529e36f7` | `cbc6defc` | `4aba2506` / `a7c575e5` / `d89396b0` / `9c4f49ad` |
| c1 = builder's commit 1 | `a67635bb` | `98758fe5` | `bb57fce8` | same as base |
| c2 = builder's commit 2 | `593593a4` | `5eac80ea` | `f4e0739f` | same as base |
| **c3 = builder's commit 3 (final)** | **`593593a4`** (= c2) | **`2d34269d`** | **`ba8b55ad`** | same as base |
| proposal c4 = c3 + my test additions | `593593a4` (unchanged) | `e22393ab` | `40290cdc` | same as base |

Every blob matches the builder's claims (`out/blobs-copies.txt`). `diff -rq base c3` lists only the board, audit-recon.mjs
and mutate.mjs.txt. `diff -rq c2 c3` lists only audit-recon.mjs and mutate.mjs.txt.

## 2. Diffs, and the existing expectations

Mine are in `diffs/`. Each body is identical, line for line, to the builder's `diffs/c3-*-vs-base.diff`.

- board base→c3 `+46 −9` (`diffs/c3-vs-base-prioritization-board-grid.html.diff`). c2→c3: none.
- audit-recon base→c3 `+263 −0` (`diffs/c3-vs-base-audit-recon.mjs.diff`). It is one hunk at line 5123, the new
  `// ==== v2.00 (U34) ... ====` … `// ==== end v2.00 (U34) ====` block, placed after U14's end marker.
  - c2→c3 is `+37 −8`, all inside that same unlanded block: its comment, the five new checks, and three comment lines reworded.
- mutate.mjs.txt base→c3 `+105 −0` (`diffs/c3-vs-base-mutate.mjs.txt.diff`). It is one hunk: 33 `v200-yearsel-*` entries placed
  before the line `  // v2.00 (R3, Brad 11 Oct): ...`.
- **No existing check, fixture or expected value changed.** So there is no file:line to list. The 306 audit-recon checks
  shared with the base keep the same verdict and value (VS-audit-recon-c3 against the round-2 verifier's base run).

## 3. The new checks: literals, and fail-before / pass-after

- **Literals.** The five checks added this round use hand-written literals only:
  - `by27(...)`, `one(...)` and `want(...)` take string and number literals;
  - `'B'.repeat(38)` and `'C'.repeat(39)` are literal expressions;
  - the partner and FMS check expects `[[[0,0,0],[0,0],[0,0],[0,0]],[[0,2000000,502000000],[0,0],[2000000,2000000],[502000000,502000000]]]`.
  - Board helpers produce observed values only.
  - Two relational expectations were carried over from round 2: `fileFys(h2) === J(JSON.parse(text))` and "the export beside the
    NOTE". They are unchanged, and round 2 recorded them.
- **The raw-character check.** c3's audit-recon and mutate hold no raw U+FFFE or U+FFFF. The escape text is used throughout.
  (My own first proposal did hold one raw U+FFFF; see section 7.)
- **Fail before, pass after.** These are my runs; the values are identical to the builder's.
  - Of the 39 U34 checks, **28 fail on the base**.
  - **11 pass there by design:** the eight controls, the two click controls ("[2025, 2026.5], then FY27 switched on" and
    "\"2026\", then ALL YEARS, then FY27's only") and "nothing asked".
  - **6 fail on c1, and none on c3.**
  - The four checks new this round (two forbidden characters, 40, 41, partner and FMS) each fail on the base. The fifth new
    check, "CONTROL — a whole number no year could be", passes there by design.
  - The hard rule says every new test must fail on the base. These 11 are controls, as U14's are, and the drafts say so.
- **The header's FAILS ON claims** match my base values. For example:
  - "2026" counts $3M of partner money and $2M of FMS money, $545M in all;
  - FY27 switched on beside "2026" gives `[2025,2028,2029,2030,2031]` and $40M.

## 4. Every run the builder reports, re-run on my copies and compared

| builder's run | my run (start ET, exit, wall) | compared | result |
|---|---|---|---|
| FR4-focused-on-c3 (exit 0, 102) | U14: from VF-focused-on-c3 (15:19:20, 134 heap limit), whose U14 block finished (63 records). U34: VP3-c4-on-c3 (16:20:29, 0, 178.3 s) and VP-c4block-on-c3 (15:32:04, 0, 194.5 s) | by check, verdict and value | U14 63/63 pass, identical. U34 39/39 pass, identical (`bin/cmpu34.py`) |
| FR4-focused-on-base (exit 1, 28 failing) | U14: VF-focused-on-base (15:15:09, 137 OOM), whose U14 block finished (63 records). U34: VP3-c4-on-base (16:23:37, 1, 191.3 s) | same | U14 63/63 pass, identical. U34 28 fail, identical in verdict and value, with the same 11 passing |
| FR4-focused-on-c1 (exit 1, 6 failing) | VF-focused-on-c1 (15:09:57, 1, 294.5 s), the full 102-check harness | all 102 | identical, 6 failing |
| FM3 × 33 | VC-<id> × 33 (15:59–17:10, each exit 1, 48–190 s), the c3 U34 block alone, mutants from `rec/bin/mkmut.py` (text only) | U34 failing set against FM3's | 33/33 caught, **every failing set identical** (`out/VC-tally.txt`). FM3 had U14 0 failing in all 33 |
| FS3-audit-recon-c3 (exit 0, 345) | VS-audit-recon-c3 (16:39:16, 0, 513.9 s) | all 345 | identical (times masked). Against the base: 306 common, 0 differing, 39 new |
| FR5-npm-check-c3 (exit 0) | VR-npm-check-c3 (15:21:25, 0, 17.1 s), scratch clone `gc-c3` at `7ee498a` + c3's files. VR-npm-check-base (15:21:47, 0, 22.8 s), `gc-base` | output | equal to FR5. Against the base, only "31672→31709 lines, 3.57→3.58 MB" and "29650→29687 lines" differ |
| FP1 probe c3 / base | VP-p1-on-c3 (16:48:23, 0, 54.6 s), VP-p1-on-base (16:48:27, 0, 51.7 s); probe blob `7e648acf`, the same as the builder's and the money verifier's | builder's `cmpp1.py` | 15/15 keys the same on each board. Workbooks: 26/26 WELL-FORMED on each |
| FP2 NaN probe c3 / base | VP-nan-on-c3 (16:39:25, 0, 21.0 s), VP-nan-on-base (16:39:46, 0, 20.9 s); blob `97f20b64` | log | equal, but for the fixture's save time |
| mcount | text only, `rec/bin/mcount.py` under bx.sh | — | c3 catalog on c3: 1,361/1,361 once. Base 1,328, c1 1,340 and c2 1,355 all once on c3. Base on base: 1,328 once |
| syntax | `node --check` of my harnesses under bx.sh | — | ok |

**Why some comparisons use the U34 block alone.** On this shared machine, three of my full 102-check runs were OOM-killed by the
memory cgroup. A fourth, capped at a 768 MB heap, ran out of heap. So I took U14 from the complete U14 portion of those runs, and
U34 from runs of the U34 block alone (`harness/c3/u34only.mjs`, the block verbatim). The U34 block's own memory need is in section 7.

Not re-run, with reasons: audit, audit-ppt, audit-other, audit-hostile, audit-inject, boot-same and legacy-fsrc. The builder
did not re-run them this round either. Their files and the board blob (`593593a4`) are unchanged from c2, which the builder and
the round-2 verifier both ran with results identical to the base.

## 5. Mutations

### 5.1 The catalog (33)
Each was made from my c3 `mutate.mjs.txt` by `rec/bin/mkmut.py`, text only. All 33 are byte-identical to the builder's
`fr2/mut3/*.html` (`out/blobs-catmutants.txt`). Each ran the c3 U34 block (39 checks). 33/33 were caught, and each failing set
equals FM3's. The six entries new this round are caught by exactly their own check:

- quote-escape-first-only: "two characters XML forbids in one entry";
- quote-cut-at-40-or-more: "a quote of exactly 40 characters";
- quote-cut-above-41: "a quote of 41 characters";
- year-four-digits and year-positive: "CONTROL — a whole number no year could be";
- other-sources-all-years: "partner and FMS money".

### 5.2 My own mutants of c3: ten plausible wrong fixes (`bin/om3.py`, `mut/om/om3.json`; each find matches exactly once)
Each ran the U34 block with my proposed additions: 39 of c3's checks plus my new ones (`harness/c4*`).

| mutant (blob) | the plausible wrong fix | c3's 39 checks | my new checks |
|---|---|---|---|
| `om3-more-counts-all` (`021cd9d8`) | "and N more" counts every saved entry, not the ones it cannot read. [2025,"a","b","c","d"] says "and 2 more" | **SURVIVES (39/39 pass)** | caught: four entries it cannot read beside a year |
| `om3-more-at-three` (`28642e15`) | "and N more" from three on. ["a","b","c"] says `"a", "b", "c" and 0 more` | **SURVIVES** | caught: exactly three entries it cannot read |
| `om3-counts-saved-years` (`a49b935c`) | the U34 notice and NOTE name the saved years it can read, not the years counted. [2025, 2040, "x"] says "this total counts FY25, FY40 only" (FY2025, FY2040 in the export) while FY40 is not counted | **SURVIVES** | caught: a year counted beside one U14 says and one it cannot read |
| `om3-cut-then-escape` (`4a096dda`) | cut first, escape after. A quote with U+FFFF early in it runs to 45 characters, not 40 | **SURVIVES** | caught: U+FFFF at the start of a long entry |
| `om3-panel-notice-above-u14` (`26e9e04c`) | the panel draws U34's notice above U14's; the export keeps U14's NOTE first | **SURVIVES** | caught only by a draft check I then withdrew as taste (7.3) |
| `om3-save-cleans` (`43cab30d`) | DATA LOSS: save() replaces what cannot be read with the years it can read | caught, 22 failing ("kept through the save": buildSavedHtml's path saves) | — |
| `om3-bare-value-wrapped` (`26eb87d6`) | a bare value is read as a one-entry list: 2027 is counted as FY27, $500M | caught, 2 (a bare number; zero) | — |
| `om3-empty-list-all-years` (`b30685a8`) | [] is ALL YEARS again, $540M, while it says "nothing is counted" | caught, 1 (an empty list) | — |
| `om3-note-two-digit` (`02327c86`) | the export's NOTE says "FY27", not "FY2027" | caught, 6 | — |
| `om3-u14-notice-hidden` (`0bf47038`) | U14's panel notice is dropped beside U34's | caught, 1 (beside a year U14 says) | caught |

The U14 block cannot catch any of the survivors. U14's fixtures only ever hold null or proper lists of years, so
`flowUnreadSaved()` is null in every U14 check, and every mutated line sits on the unread path.

The four survivors were re-run with the final proposal harness (VN-*, 16:27–16:39 ET, each exit 1). Each fails exactly its
own new check and none of c3's 39.

## 6. Proposal (`proposal/c4`, tests and catalog only; the board is unchanged): four shapes, four entries

- **audit-recon** c3→c4 is `+23 −1` (`diffs/c4-proposal-vs-c3-audit-recon.mjs.diff`). It touches only U34's unlanded block:
  - three AND comment lines;
  - one FAILS-ON line reworded and extended;
  - one shape after "a quote of 41 characters": "U+FFFF at the start of a long entry" (`["￿" + 38 × "D"]`), which expects
    `"￿` + 33 × D + `…`, 40 characters;
  - three shapes after "every offered year beside an entry": "four entries it cannot read beside a year", "exactly three
    entries it cannot read", and "a year counted beside one U14 says and one it cannot read".
  - Every expectation is a literal written in the block's own `want(...)`, `H1(...)` and `TAIL` form. It writes U+FFFF as
    escape text, with no raw character.
- **mutate.mjs.txt** c3→c4 is `+14 −0` (`diffs/c4-proposal-vs-c3-mutate.mjs.txt.diff`). It adds two comment lines and
  `v200-yearsel-more-counts-all`, `-more-at-three`, `-counts-saved-years` and `-cut-then-escape`, before the R3 line.
  - mcount, text only: **1,365 / 1,365** once on c3.
  - mkmut from these entries gives mutants byte-identical to my `om3-*` four (`out/mcount-prop-and-blobs.txt`).
- **Measured** (`harness/c4/u34only.mjs`, `11e5065a`):

  | board | result |
  |---|---|
  | c3 | 43/43 pass (VP3-c4-on-c3); the 39 old values are identical to the builder's |
  | base | **32 fail** = the builder's 28 (identical) + all 4 new; the same 11 pass by design (VP3-c4-on-base) |
  | c1 | 9 fail = the 6 + 3 new; "a year counted beside…" passes on c1 (VP3-c4-on-c1) |

  Each of the 4 new entries' mutants is caught by its own check (VN-*).
- **Draft text if adopted** (the builder's drafts):
  - NEXT-VERSION "Test": "(43 checks)" in place of "(39 checks)". "The 27 shapes are …" adds: U+FFFF at the start of a 39-character
    entry, four entries it cannot read beside a year, exactly three entries it cannot read, and a year counted beside one U14
    says and one it cannot read. "32 checks fail on the board before the change (`d66dd60`); the other 11 pass there by design".
  - "Mutations": add `-more-counts-all`, `-more-at-three`, `-counts-saved-years` and `-cut-then-escape`.
  - Ledger: "The block: 43 checks. 32 fail on `d66dd60`; the other 11 pass there by design; 9 fail on commit 1 alone; all 43 pass
    after." Then "Mutations: 37, each caught" and "The catalog, counted as text: 1,365 / 1,365". The third round's line:
    "four plausible wrong fixes passed every check: 'and N more' counting every entry or starting at three, the notices naming
    the saved years rather than the years counted, and the quote cut before it is escaped. Four checks and four mutations now
    pin them."

## 7. Other observations (minor)

1. **The U34 block's memory.** Each shape releases its boards (`bootRelease(__bm, [X.w])`), but nothing lets the loop turn and
   collect them until the block ends (`settleBoards()` runs once, at the end).
   - Measured with the c3 block alone: it ran out of heap at a 768 MB cap and at a 1024 MB cap. At 1024 MB it had recorded
     24 of 39 checks (VU-u34-on-c3).
   - Three full runs were OOM-killed by the shared cgroup at 1.3–1.6 GB RSS.
   - A measurement copy with `await settleBoards();` after each per-shape release (`harness/c3/u34only-settle.mjs`) passed
     39/39 under a 768 MB cap, value-identical, in 115 s (VMEM-settle-768-on-c3).
   - The full audit-recon still passed at a 2,500 MB cap in 514 s. This is a resource point, not a correctness one.
2. **Raw characters in tool input.** My own first proposal held a raw U+FFFF character where I had typed the escape. This is
   the same tool behaviour the builder reported. I replaced it with the escape text and re-ran (VP3-*): the results were
   identical. c3's suite and catalog hold no raw U+FFFE or U+FFFF. The board holds one of each, as the base does.
3. **The panel's notice order is not pinned.** `om3-panel-notice-above-u14` survives c3's checks. I first drafted a check for
   it, then withdrew it: neither order makes a word false, and the export's order is pinned.
4. **Clean-on-save is already pinned.** I first drafted an "ordinary save" check for `om3-save-cleans` and withdrew it. c3's
   own "kept through the save" catches that mutant in 22 checks, because the path that builds the saved file saves.

## 8. Every run (`logs/runs.txt`; all on 13 Oct, ET; each node run under `setsid -w timeout -k 10 600` inside `run.sh`)

Logs of runs stopped by the OOM killer or the heap limit, and of the run I stopped, are kept in `logs/killed/`. Their partial
records are in `out/killed/`. A later run with the same label rewrote `logs/<label>.log`.

| label | start | exit | wall s | note |
|---|---|---|---|---|
| VF-focused-on-c3 | 15:04:22 | 137 | 327.0 | OOM-killed (shared cgroup); partial, 79 records, all pass |
| VF-focused-on-base | 15:04:20 | 137 | 329.8 | OOM-killed; partial |
| VF-focused-on-c1 | 15:09:57 | 1 | 294.5 | complete, 102; 6 failing, identical to FR4 |
| VF-focused-on-c3 | 15:12:22 | 137 | 234.1 | OOM-killed; 81 records, identical |
| VF-focused-on-base | 15:15:09 | 137 | 232.2 | OOM-killed; U14 63 complete, identical |
| VR-npm-check-c3 | 15:21:25 | 0 | 17.1 | all checks passed |
| VR-npm-check-base | 15:21:47 | 0 | 22.8 | all checks passed |
| VF-focused-on-c3 | 15:19:20 | 134 | 361.3 | heap limit 768 MB; U14 63 complete, identical |
| VU-u34-on-c3 | 15:25:58 | 134 | 272.7 | heap limit 1024 MB; 24 of 39 recorded |
| VS-supp-on-c3 / -base | 15:26:09 / 15:27:42 | 0 / 1 | 61.6 / 57.2 | measurement supplement (6 + nothing asked): 0 fail / 6 fail |
| VP-c4block-on-c3 / -base | 15:32:04 / 15:35:35 | 0 / 1 | 194.5 / 230.1 | first draft proposal (45 checks): 0 / 34 failing |
| VM-om3-* × 10 | 15:39:54–15:57:00 | 1 each | 137–224 | section 5.2 |
| VP2-c4-on-c3 / -base | 15:56:54 / 15:59:44 | 0 / 1 | 156.2 / 152.9 | trimmed proposal, raw-character build: 43 pass / 32 fail |
| VC-* × 33 | 15:59:49–17:09:36 | 1 each | 48.5–190.4 | section 5.1 |
| VC year-four-digits / year-positive | 16:05:36 / 16:05:41 | 137 / 137 | 132.9 / 126.9 | OOM-killed as a pair, after their catching check was recorded; re-run alone at 16:10:38 / 16:13:46 (exit 1, complete) |
| VP3-c4-on-c3 / -base / -c1 | 16:20:29 / 16:23:37 / 16:52:47 | 0 / 1 / 1 | 178.3 / 191.3 / 57.5 | final proposal: 0 / 32 / 9 failing |
| VN-om3-* × 4 | 16:27:06–16:35:54 | 1 each | 163–193 | survivors on the final proposal |
| VS-audit-recon-c3 | 16:39:16 | 0 | 513.9 | 345 pass, identical to FS3 |
| VP-nan-on-c3 / -base | 16:39:25 / 16:39:46 | 0 / 0 | 21.0 / 20.9 | equal to FP2 but the save time |
| VP-p1-on-c3 / -base | 16:48:23 / 16:48:27 | 0 / 0 | 54.6 / 51.7 | 15/15 keys equal; 26/26 workbooks well-formed each |
| VMEM-settle-768-on-c3 | 16:49:40 | 0 | 115.1 | measurement only (7.1) |
| VC-v200-yearsel-toggle-from-all | 16:49:48 | 143 | 13.7 | stopped by me (section 9); re-run 16:51:55, exit 1, 48.5 s, complete |

Text-only helpers (mkfocused, om3, mksupp3, mkprop/mkprop2, mkmut, mcount, xmlcheck, git clone and checkout) ran under `bx.sh`.

## 9. PIDs, signals and deviations

- Every timeout PID and node PID is in `pids.txt`: 270 distinct PIDs. At 5:11 PM ET none was still running.
- **Signals sent, each to a PID I had recorded:**
  - 15:11 ET: TERM to 27429, my queue wrapper. I had rewritten `queue.sh` while it waited, and stopped it before it could read
    the new text. Its last run went on.
  - 16:49:5x ET: TERM to 8748 (my `p.sh` timeout) and to 8879 (the timeout of VC-toggle-from-all).
- **Deviations:**
  - From 16:49:48 to about 16:50:02 ET, about 14 s, three of my node runs overlapped: VMEM-settle, VC-counted-unsaid and
    VC-toggle-from-all. I had started a pair while VMEM-settle was running. I stopped the third run, and re-ran it alone.
  - During the two npm checks (17 s and 23 s), npm, check.mjs and its `node --check` child ran beside one focused run.
  - The first `node --check` of my supplement harnesses ran without the bound (under a second). Every later one ran under `bx.sh`.
  - My `until … sleep` waiting loops in the tool calls had no 600 s bound of their own. Each tool call was bounded by its own
    timeout.
  - The audit-import lock was absent before every run. None waited for it and none was skipped.
- `--max-old-space-size` was set on later runs (768, 1024, 1800 or 2500 MB). It only bounds the heap; it changes nothing that runs.

## 10. What I did not do

- I did not run the full audit-import or audit-board, Chromium, playwright, or any probe in a browser.
- I did not re-run audit, audit-ppt, audit-other, audit-hostile, audit-inject, boot-same or legacy-fsrc. Their inputs are
  unchanged from c2, as section 4 says.
- I ran the 33 catalog mutants through the U34 block alone, not U34 + U14. The builder's FM3 shows U14 with 0 failing for all 33.
- mutate.mjs was never imported or run. It was read as text only, by mcount.py and mkmut.py.
- I committed nothing, pushed nothing, and edited nothing in orbit-board, orbit-ui or the builder's folder.
- I did not draft new ledger rows. Section 6 gives only the text changes the proposal would need in the builder's drafts.
