# U20U30, independent adversarial verification, round 2, LENS B (test adequacy and regressions)

Reviewer of the builder's fix round (`c1f/`, `c2f/`). Times are Eastern, each read with `TZ=America/New_York date`. This review
started at 2:42 PM ET on Tue 13 Oct 2026. No earlier attempt of this review (lens B, round 2) existed: `verify-tests-r2/` did not
exist when I started, so nothing was reused; every run below is mine. Round 1's directory (`verify-tests-r1/`) and the builder's
files were only read.

**Nothing was edited, staged, committed or pushed** in `/home/user/orbit-board` or `/home/user/orbit-ui`. orbit-board was only
read (`git log`, `git show HEAD:<path> | git hash-object --stdin`, its recovery notes) and cloned with `git clone --shared` into
`clones/b0` and `clones/c2f` (never committed in). Its HEAD is now `379a9f7` (records-only commits since `7ee498a`); its product
blobs are still the base's (board `fce8a391`, audit-import `4aba2506`, audit-board `a7c575e5`, mutate.mjs `cbc6defc`).
`mutate.mjs` was never run, imported or executed: it was read as text only, with `rec/bin/mcount.py`, `mcread.py` and `mkmut.py`
(`python3 -I`). `playwright install` was never run. The full audit-import and audit-board were not run.

## VERDICT: sound-with-issues (no must-fix)

- **Re-runs.** Every run of the builder's fix round that I repeated gives the builder's verdicts, check by check. That is 35 of
  my runs, with 0 checks differing. Among them: the four focused harnesses on base / c1f / c2f, every mutant, the folder
  harnesses, the probe and checker, the other suites, and real Chromium.
- **New checks.** All 173 new checks (U20 84, U30 89) use hand-written literal expected values. On the base board, every
  CONTROL and GUARD passes and every other check fails: 0 breaches.
- **Existing tests.** The suite and mutate diffs add lines only, and no existing expectation changed. mcount is 1328 / 1330 /
  1342 of 1328 / 1330 / 1342 (base, c1f, c2f).
- **My own mutants (16).** 11 are caught by the new blocks and one by the existing U2/U13 blocks. The other four are word-only
  gaps: three are closed by the one case I propose (S1, tested), and one is minor (m3).
- **Regressions.** I found none:
  - 9 extra audit-import scenarios that reach the changed code: 68/68 on base and on c2f;
  - the existing `saves-not-serial` entry, whose find is the line U20 rewrote around: the same 5 failing checks on base and
    c2f;
  - the other suites: identical logs on base and c2f, apart from the board's line count.

## Identities (`git hash-object`; `out/blobs.txt` has every one)

| copy | board | audit-import | mutate.mjs.txt | audit-recon / audit-board / audit-other |
|---|---|---|---|---|
| `copies/b0` (= `rec/L6/base`, 7ee498a) | `fce8a391` | `4aba2506` | `cbc6defc` | `529e36f7` / `a7c575e5` / `d89396b0` |
| `copies/c1f` (= builder `c1f/`) | `83b87782` | `d7d41c6a` | `6b4c83d6` | unchanged |
| `copies/c2f` (= builder `c2f/`) | `84cf2bf4` | `3a34d922` | `d174d05d` | unchanged |

My copies are `cp -a` of `rec/L6/base`, the builder's `c1f/` and `c2f/` (node_modules link kept, `chmod u+w`), made at 2:43 PM
ET; the blobs equal the builder's stated ones. `diff -rq` against the base: only the board, audit-import and mutate.mjs.txt
differ. My diffs (`diffs/`): base→c1f board −1 +8, audit-import +531 −0, mutate +7 −0; c1f→c2f board −5 +22, audit-import
+369 −0, mutate +39 −0. These equal the builder's `fr/diffs`.

## What I checked, and how

1. **Additions only; no existing expectation changed.** Both audit-import diffs are single hunks of added lines: U20's blocks
   after `// ==== end v2.00 (U13) ====`, U30's after `// ==== end v2.00 (U20) ====`. Both sit before the scenario-ran guard.
   The mutate diffs add entries before the R3 line only. audit-recon, audit-board and audit-other are unchanged. There are no
   duplicate top-level names in c2f's audit-import (the new `webLocks` is unique), and `node --check` parses c1f's and c2f's
   audit-import. **Changed existing expectations: none.**
2. **Expected values are literals** (`src/wants.py` → `out/wants.txt`). I read all 140 `chk(` calls in the added lines.
   - Every 5th argument is a literal `J([...])`, number, boolean or string.
   - Otherwise it is a constant built from literals: `WAITW`, `SANEW([...literal order])`, `UNRECW(h)`, `SAID`, `HANDEDW`,
     `RECORDEDW`, or the literal regexes `UNSAID`, `PUT_*` and `OCC_*`.
   - Board helpers appear only in observed values.
3. **Fail-before / labels** (`src/labels2.py`, my own reading of the rule):
   - U20 on b0: CONTROL 48 pass, GUARD 13 pass, all other 23 fail.
   - U30 on b0: CONTROL 34 pass, GUARD 9 pass, all other 46 fail.
   - Breaches: 0.
   - U30 on c1f: 2 breaches (m1).
4. **Builder's harnesses rebuilt independently.** I rebuilt them from my copies' suites with the same `mkfocused-multi.py`.
   Bodies (header lines aside) are identical to the builder's: G-u20 `176113e3`, G-u30 `6db58daf`, G-u2u13 `ba5163e3`,
   F-folderA `9d90cda8`, F-folderB `e500aa0f`.
5. **More regression coverage than the builder ran.** `src/scen.py` lists 35 audit-import scenarios whose block calls a changed
   function or the shared folder harness `W1H`. The builder ran 26 of them (U2 ×2, U13, U20 ×2, U30, and the 21 in F-folderA/B).
   The other 9 I ran as **F-folderC**, built verbatim from c2f's suite (`21c6cc12`): base 68/68, c2f 68/68, identical verdicts.
   Those 9 are: v1.95 import all-or-nothing, the import that lifts the hold, NR02, NR03, NR05, NR04, item 77, item 95, and W5's
   shared log.
6. **mcount (text only):**
   - b0 1328/1328, c1f 1330/1330, c2f 1342/1342 match exactly once; none missing, multiple or unparsed.
   - With my proposed entries (S1): 1345/1345.

## The builder's runs, re-run (my run vs the builder's run with the same copy, mutant and harness; `out/cmpall.txt`)

| harness / mutant | copy | mine | builder | per-check verdicts |
|---|---|---|---|---|
| G-u20 (84) | b0 / c1f / c2f | 23 fail / 0 / 0 | 23 / 0 / 0 | identical |
| G-u30 (89) | b0 / c1f / c2f | 46 fail / 44 / 0 | 46 / 44 / 0 | identical |
| G-u2u13 (128) | c2f (and b0, mine only) | 0 (b0 0) | 0 | identical |
| F-folderA (297) | c2f | 0 | 0 | identical |
| F-folderB (142) | c2f | 0: 98 checks in `v2-F-folderB-c2f` (capped at 600 s, load ~34) + 55 in `v8-F-folderB2-c2f` (its last 6 scenarios) | 0 | identical, 142 of 142 |
| `v200-u20-wait-uncounted` | c1f / c2f | 23 / 17 | 23 / 17 | identical |
| `v200-u20-failed-stays-counted` | c1f / c2f | 2 / 2 | 2 / 2 | identical |
| 12 `v200-u30-*` entries | c2f, G-u30 | 42, 44, 5, 1, 21, 16, 14, 1, 2, 1, 1, 1 | the same | identical |
| own `ownUnsaved` rule (mine rebuilt independently: blob `fb879f74`, = the builder's) | c2f, G-u30 | 14 | 14 | identical |
| `kept-theirs-wrong-word` | c2f, F-folderA | 1 (v1.95 "folder theirs") | 1 | identical |
| `v200-u2-putback-gen` / `-while-saving` | c2f, G-u2u13 | 1 / 34 | 1 / 34 | identical |
| `v200-u13-pull-while-saving` / `-pull-unchecked` / `-said-nothing-loaded` | c2f, G-u2u13 | 40 / 40 / 10 | 40 / 40 / 10 | identical |
| `v200-u13-base-while-saving` | c2f, G-u20 / G-u30 | 2 / 2 | 2 / 2 | identical |
| `v200-u13-clash-while-saving` | c2f, G-u20 / G-u30 | 1 / 1 | 1 / 1 | identical |

All 24 of the builder's entry mutants were rebuilt text-only with `mkmut.py` from my copies' `mutate.mjs.txt` (each `matches:
1`). Their blobs are byte-identical to the builder's (`out/builder-mutants.txt` vs `fr/out/mutant-blobs.txt`). Not re-run:
G-all. Its four blocks ran here as G-u2u13, G-u20 and G-u30; the builder's G-all took 576 s of the 600 s cap, and here, at load
26–38, it would not fit. The full audit-import is the lead's.

**Other suites** (`bin/suites.sh` in scratch clones `clones/c2f` and `clones/b0`: `git clone --shared` at `379a9f7`, the copy's
board, `tools/`, package.json and NEXT-VERSION.md over it, nothing committed):
- boot-same, audit, audit-ppt, audit-other, audit-recon, legacy-fsrc, audit-hostile, audit-inject and `npm run check`: every
  one exits 0 on both.
- With timings normalised, every log is identical between base and c2f, except npm check's board size (31672 → 31696 lines,
  main script 29650 → 29674).

**The U20 probe and checker** (the builder's r4 sequence, re-run from my copies of `probe/b` and `probe/x`, only their `out/`
mine; 40 runs, all exit 0), on c2f:
- probe by kind: U20 77/77, OUT 26/26, CTL 109/109, LCK 27/27 (locktest 19/19); only the 10 PRE checks fail (the premise
  "B `_saveBusy` 0", which the fix changes);
- checker: U20 24/24, CNT 45/45, CTL 10/10; PRE 8, INFO 4 and O4 2 fail, all "observed mechanism" checks the fix removes;
- exactly the builder's r4.

**Real Chromium** (`src/rc-u20.mjs`: the builder's `fr/src/rc-u20.mjs` with only its temp directory moved here; Chromium
`/opt/pw-browsers/chromium`; run alone, with no other node run of mine going):

| board | pass | failing checks |
|---|---|---|
| c2f | 13 of 14 | only the script's own "no request but the page" check (the board asks for `prio-state-om.json`) |
| c1f | 13 of 14 | the same check |
| base | 7 of 14 | W1–W6, as expected, and the same check |

## My own mutants (16; text-only on the c2f board with `src/mkown.py`, each find asserted to match once; specs `src/own*.json`)

| mutant (plausible wrong fix) | blob | harness | failing checks |
|---|---|---|---|
| `own-u20-count-in-run`: counted when this tab's chain reaches it, not when asked | `71f7b569` | G-u20 | 1: (6d) |
| `own-u20-msg-after-count`: count raised before the "already under way" test | `92e07a67` | G-u20 | 1: (6d) |
| `own-u20-count-wait-only`: only the wait counted; down at the grant | `501408c3` | G-u20 | 1: (5a) |
| `own-u20-never-uncounted` (file `own-u20-uncount-in-go.html`; built without the intended `finally`, so it never uncounts) | `33e00db9` | G-u20 | 16 |
| `own-u20-uncount-in-go2`: uncounted only in go's `finally`, so a refused lock request stays counted | `60f1f032` | G-u20 | 1: (6b) |
| `own-u20-locks-only`: counted only where the browser has Web Locks | `c291f47a` | G-u20 / G-u2u13 | **0** / 79 (U2 a–h, U13) |
| `own-u30-stamp-and-dirty`: `theirs!==ours && DIRTY` | `ec664ffc` | G-u30 | 21 |
| `own-u30-stamp-and-unsaved`: `theirs!==ours && (DIRTY \|\| _baseDirty)` | `77135674` | G-u30 | 14 |
| `own-u30-say-on-refresh`: the refresh says the clash instead of nothing | `bfd0f692` | G-u30 | 7: (1), (1h), (4) |
| `own-u30-ownunsaved-rule`: the rule keyed on `ownUnsaved` | `fb879f74` | G-u30 | 14 |
| `own-u30-occupied-words-swapped`: "a copy" and "a newer copy" swapped | `3e60ba63` | G-u30 | 2: (9), (9c) |
| `own-u30-clash-words-on-busy`: Save's words chosen on "a save under way" | `ef46a4db` | G-u30 | 5 |
| `own-u30-putback-why-file`: MF1's test written `why==='file'` | `4837d916` | G-u30 / F-folderC | **0 / 0** (m3) |
| `own-u30-putback-any-year`: a record for any year counts | `d6a60183` | G-u30 / P-u30w | **0** / 1 (S1) |
| `own-u30-clash-any-year` | `83361415` | G-u30 / P-u30w | **0** / 1 (S1) |
| `own-u30-occupied-any-year` | `f005a865` | G-u30 / P-u30w | **0** / 1 (S1) |

The existing entry `saves-not-serial` (its find, `const p=_saveChain.then(run, run);`, is the line U20 counts around) on
F-folderA: base 5 failing checks, c2f the same 5 (v1.95 "two saves" 2, "a queued save" 1, "autosave and Save" 2).

## Findings

### Must-fix: none

Every claim of the builder that I could re-run held, check by check (below). Every new expected value is a literal. Every new
check fails on the base board unless it is labelled a CONTROL or a GUARD, and every CONTROL and GUARD passes there. No existing
line of any suite or of `mutate.mjs` changed. Every mutation entry (old and new) matches its board exactly once, and every one
of the builder's 24 entry mutants (22 entries; the two U20 ones on c1f and on c2f) plus its own mutant is caught, in the same
26 harness runs, with exactly the builder's failing checks. Of my 16 own mutants, 11 are
caught by the new blocks, one more by the existing U2/U13 blocks, and four are not caught: three word-only gaps (S1, each
caught by the case proposed there) and one (m3). None of the four brings data loss back.

### S1 (should-fix, tests; principle 4): no U30 check tells this year's record from another year's, so three wrong forms of MF1's words survive

MF1 makes three lines depend on "a copy recorded for the folder": Save's question (`driveClashSay`: `driveBaseOf(ap)`), ↶ Put
back's line (`keptPutBack`: `driveBaseOf(mySlug())`) and Load theirs refused for kept work (`_driveResolveRun`:
`driveBaseOf(ap)`). All three are keyed on the year on screen (`MS.cur`), which is right. No check in the U30 block
distinguishes "recorded for this year" from "recorded for some year of this appropriation". Case (10) runs the other-year route,
but it checks only that Save asks, not what it says. Three plausible wrong forms each read "a record for any year of the
appropriation":

| mutant (text-only, c2f board) | blob | G-u30 (89 checks) | under it, on FY28 with only FY27 recorded |
|---|---|---|---|
| `own-u30-putback-any-year` | `d6a60183` | 0 of 89 fail (exit 0) | ↶ Put back says the folder's copy was "saved after it" |
| `own-u30-clash-any-year` | `83361415` | 0 of 89 fail (exit 0) | 💾 Save says theirs was saved "after the copy you are working from" |
| `own-u30-occupied-any-year` | `f005a865` | 0 of 89 fail (exit 0) | Load theirs refused calls it "a newer copy" |

These are the claims MF1 was made to stop (the money review's round-1 must-fix), on a route the U30 block already runs. The money
lens found the first one too (its round-2 minor m4, `vr2-u30-putback-any-year`). The board itself is right; the gap is in the
tests, and a later edit to any of the three lines (for example ADOPT's merge, which the builder's rebase note says must rewrite
exactly these lines) could slip it in unseen.

**Minimal fix (tested):** one case, (10w), added to the U30 block after (10), and three mutation entries.
- `proposal/u30-case-10w.mjs.txt` (blob `5a2b0cbd`, 25 lines, additions only;
  `diffs/proposal-audit-import-10w.diff`, giving audit-import `7e681a21`). It reuses the block's own helpers (`open`, `folder`,
  `connect`, `scr`, `based`, `asks`, `keepOther`, `PUT_UNREC`, `OCC_UNREC`) and adds one literal pattern, `UNSAID28` (the FY28
  form of `UNSAID`). B saves FY27 (recorded); Alice's other machine saves FY28 (A28); B switches to FY28 and types B28. Four
  checks: a CONTROL (FY27 recorded, nothing for FY28, B28 on screen, A28 the folder's FY28 copy); 💾 Save on FY28 asks in the
  no-record words and not "after the copy you are working from"; Load theirs then ↶ Put back, in `PUT_UNREC`'s words and not
  "saved after it"; with other work kept, Load theirs refused in `OCC_UNREC`'s words and not "newer". Every expected value is
  a hand-written literal.
- Results with the focused harness `P-u30w` (G-u30 with the case inserted, blob `674bf120`): on the base `fce8a391`, 93 checks, 49 fail (the 46 as before, plus the 3 new word checks; the new CONTROL passes; my labelling check gives 0 breaches); on c1f, 47 fail (the 44 as before, plus the 3); on c2f, 93/93. Under each any-year mutant, exactly one check fails, its own: putback-any-year the ↶ Put back check, clash-any-year the 💾 Save check, occupied-any-year the refusal check (each 1 of 93).
- `proposal/u30-entries-10w.txt` (three entries in house format: `v200-u30-putback-any-year`, `v200-u30-clash-any-year`,
  `v200-u30-occupied-any-year`), inserted before the R3 line (`diffs/proposal-mutate-10w.diff`, 10 added lines). mcount on the
  result: 1345/1345, each once. Each entry's mutant, built with `mkmut.py`, is byte-identical to my own mutant above.
- Drafts, if taken: U30 "Test" gains "another year, the words: Save's question, ↶ Put back's line and Load theirs refused, on a
  year with nothing recorded while another year is recorded"; its count becomes 93 checks, with 49 failing before U20 and 47 on the U20 board; "Mutations" gains
  the three ids.

If the lead does not take S1, U30's "Not covered" should say: "The three lines' words are checked on the year on screen only;
that a record for another year does not count is not tested."

### S2 (should-fix, operations; for the lead's full runs): the two blocks add minutes to every full audit-import run, whose cap is 900 s

The lead runs the full audit-import alone with a 900 s cap (`recovery/v200/IMMINENT-CHANGES-RETESTS.md`: "audit-import alone,
900 s + 20 s"); the unmutated full runs recorded in `recovery/v200/evidence` (its "BASELINE (unmutated)" rows, from earlier v2.00 commits) took 483–551 s. The two new blocks, run alone as
focused harnesses here under load 26–38, took: G-u20 130–166 s, G-u30 228–369 s, against 304–365 s for the existing U2+U13
blocks (G-u2u13) under the same load. The builder's own G-all (all four blocks) took 576 s. So each full audit-import run, and
each sensitivity run of the 14 new entries (17 with S1) in the final-tree queue, will take several minutes longer and may reach 900 s on a loaded
machine. Nothing is wrong with the tests; the lead should plan the cap or the timing for it (the builder said "several minutes";
these are my numbers).

## Minor

- **m1 (labels, commit 2 on its own parent).** On c1f, the board commit 2 is applied to, two U30 checks pass that are neither
  CONTROL nor GUARD: (4) "B counts both as under way (U20) …" and (4) "tick 2’s refresh during the wait records nothing". They
  test U20, which c1f already has. The block's header says "Every other check that is not a CONTROL fails there" (on the board
  before this change). True against the track base `fce8a391` (0 breaches), not against c1f (2 breaches, `src/labels2.py`). The
  drafts' "46 fail before U20, 44 on the U20 board" is right. A label such as " (U20's: it passes once U20 has landed)" on those
  two checks would make the block's own words exact.
- **m2 (a check's label is wider than what it reads).** U30 (2) "↻ Refresh now records nothing and says no clash" reads "a
  clash said" with `/after the copy you are working from/`, which is the recorded-copy wording only. My mutant
  `own-u30-say-on-refresh` (the refresh says the clash, in the no-record words) passes that check. It is still caught, by 7
  checks in (1), (1h) and (4), so this is not a gap in the block, only in that check. A pattern for both wordings (for example
  `/saved O&M FY27 to the shared folder/`) would make (2) catch it.
- **m3 (sidecar words not pinned).** `own-u30-putback-why-file` (MF1's test written `why==='file'` instead of `why!=='folder'`)
  passes G-u30 (89/89) and F-folderC (68/68, including v1.96 NR05, the shared-state-file scenario). Only work kept aside from a
  board file is pinned ((8d)); work kept aside from the shared state file (`why:'sidecar'`) is not. Under the mutant such work
  is put back saying there is "no record of which copy there, if any, this work came from" instead of the old words. Words only;
  a sidecar variant of (8d) would close it.
- **m4 (thin catches, all caught).** `own-u20-count-in-run` and `own-u20-msg-after-count` are caught by one check each, (6d);
  `own-u20-count-wait-only` by one, (5a). `own-u20-locks-only` (the count kept only where the browser has Web Locks) passes the
  whole U20 block (84/84), because every U20 tab has the stand-in installed; the U2 and U13 blocks catch it (79 of 128). In the
  full audit-import it is caught; the U20 block alone does not hold the no-Web-Locks path.
- **m5 (drafts).** (1c)'s "U13 line (800-801)" is lines **799–800** of NEXT-VERSION.md at `7ee498a` (the money lens's m2
  too; 701, 723–725, 727 and 786 are right). The U20 "Test" bullet's list of GUARD checks leaves out (6d)'s landing check; the
  U30 one leaves out (1)'s "F0 and B-EDIT each still in a copy the board reaches". Counts are right (U20: 13 GUARD; U30: 9).
- **m6 (existing entry `saves-not-serial`, not run by the builder).** Its find is the line U20 rewrote around
  (`const p=_saveChain.then(run, run);`). It still matches once on c1f and c2f and is still caught on c2f (F-folderA: 5 checks
  in v1.95 "two saves", "a queued save" and "autosave and Save"; on the base the same 5 checks fail).

## The lead's six principles, read through this lens

1. **No copy is lost.** My mutants that bring the unasked overwrite back are all caught, by 14–21 checks each:
   `stamp-and-dirty`, `stamp-and-unsaved` and `ownunsaved-rule`. So are the builder's.
2. **Refuse or ask rather than guess.** The block holds "ask" on every route it runs. S1 is a guess about the order of saves
   that the tests do not yet hold on another year.
3. **Money and exports.** The board diffs touch no money or export code. The export suites (audit, audit-ppt, audit-other,
   audit-recon) give identical logs on base and c2f.
4. **Every word stays true.** There are 15 word mutants: the builder's 7 word entries and 8 of mine. 11 are caught; the
   three year forms and the sidecar form are not (S1, m3). The drafts carry one wrong line number (m5).
5. **Smallest change.** This lens takes the change as built. S1's fix adds one case and three entries, and nothing on the
   board.
6. **Existing checks preserved.** The changes add lines only. Every old entry still matches once and the old ones I re-ran are
   still caught (`saves-not-serial`, `kept-theirs-wrong-word`, the U2 and U13 entries). F-folderA/B pass on c2f. F-folderC,
   G-u2u13 and the other suites pass on base and c2f alike.

## Every run (`logs/runs.txt`; bounded by `bin/run.sh`: `setsid -w timeout -k 10 600`, the AUDIT_IMPORT_RUNNING lock checked first)

The lock was never present, so no run waited and none was skipped. One run reached the cap, `v2-F-folderB-c2f`, at load ~34;
its unfinished part was re-run as `v8-F-folderB2-c2f` and is not counted as a failure. The 12 `v1-*` runs were a setup error:
`h/<copy>` had no node_modules link, so jsdom could not load and no check ran. They were re-run as `v2-*`. Exit 1 on the base,
on c1f's U30 runs and on every mutant means checks failed, as intended. Exit 1 on `rc-u20-*` is that script's own environment
check (above). With the 1 s start rounding allowed for, at most two of my runs overlapped at any time
(`logs/runs.txt`, checked by script); the exception is under Deviations.

| label | start (ET) | exit | wall s | checks / failing | board | log |
|---|---|---|---|---|---|---|
| v1-G-u20-b0 | 2026-10-13 14:48:12 | 1 | 3.5 |  | fce8a391 | logs/v1-G-u20-b0.log |
| v1-G-u2u13-c2f | 2026-10-13 14:48:12 | 1 | 3.8 |  | 84cf2bf4 | logs/v1-G-u2u13-c2f.log |
| v1-G-u20-c1f | 2026-10-13 14:48:16 | 1 | 2.7 |  | 83b87782 | logs/v1-G-u20-c1f.log |
| v1-F-folderA-c2f | 2026-10-13 14:48:16 | 1 | 3.4 |  | 84cf2bf4 | logs/v1-F-folderA-c2f.log |
| v1-G-u20-c2f | 2026-10-13 14:48:19 | 1 | 3.5 |  | 84cf2bf4 | logs/v1-G-u20-c2f.log |
| v1-F-folderB-c2f | 2026-10-13 14:48:20 | 1 | 3.2 |  | 84cf2bf4 | logs/v1-F-folderB-c2f.log |
| v1-G-u30-b0 | 2026-10-13 14:48:23 | 1 | 3.4 |  | fce8a391 | logs/v1-G-u30-b0.log |
| v1-F-folderC-b0 | 2026-10-13 14:48:23 | 1 | 3.4 |  | fce8a391 | logs/v1-F-folderC-b0.log |
| v1-G-u30-c1f | 2026-10-13 14:48:26 | 1 | 3.5 |  | 83b87782 | logs/v1-G-u30-c1f.log |
| v1-F-folderC-c2f | 2026-10-13 14:48:27 | 1 | 3.5 |  | 84cf2bf4 | logs/v1-F-folderC-c2f.log |
| v1-G-u30-c2f | 2026-10-13 14:48:30 | 1 | 3.4 |  | 84cf2bf4 | logs/v1-G-u30-c2f.log |
| v1-G-u2u13-b0 | 2026-10-13 14:48:31 | 1 | 3.6 |  | fce8a391 | logs/v1-G-u2u13-b0.log |
| v2-G-u20-b0 | 2026-10-13 14:50:01 | 1 | 165.9 | 84 / 23 | fce8a391 | logs/v2-G-u20-b0.log |
| v2-G-u20-c1f | 2026-10-13 14:52:47 | 0 | 129.6 | 84 / 0 | 83b87782 | logs/v2-G-u20-c1f.log |
| v2-G-u2u13-c2f | 2026-10-13 14:50:01 | 0 | 304.2 | 128 / 0 | 84cf2bf4 | logs/v2-G-u2u13-c2f.log |
| v2-G-u20-c2f | 2026-10-13 14:54:57 | 0 | 136.8 | 84 / 0 | 84cf2bf4 | logs/v2-G-u20-c2f.log |
| v2-G-u30-b0 | 2026-10-13 14:57:14 | 1 | 237.5 | 89 / 46 | fce8a391 | logs/v2-G-u30-b0.log |
| v2-F-folderA-c2f | 2026-10-13 14:55:06 | 0 | 420.5 | 297 / 0 | 84cf2bf4 | logs/v2-F-folderA-c2f.log |
| v2-G-u30-c1f | 2026-10-13 15:01:12 | 1 | 228.0 | 89 / 44 | 83b87782 | logs/v2-G-u30-c1f.log |
| v2-G-u30-c2f | 2026-10-13 15:05:00 | 0 | 368.9 | 89 / 0 | 84cf2bf4 | logs/v2-G-u30-c2f.log |
| v2-F-folderB-c2f | 2026-10-13 15:02:06 | 124 (cap) | 600.2 | 98 / 0 | 84cf2bf4 | logs/v2-F-folderB-c2f.log |
| m-own-u20-count-in-run-G-u20 | 2026-10-13 15:11:24 | 1 | 152.0 | 84 / 1 | 71f7b569 | logs/m-own-u20-count-in-run-G-u20.log |
| v2-F-folderC-b0 | 2026-10-13 15:12:07 | 0 | 204.1 | 68 / 0 | fce8a391 | logs/v2-F-folderC-b0.log |
| m-own-u20-msg-after-count-G-u20 | 2026-10-13 15:13:56 | 1 | 177.0 | 84 / 1 | 92e07a67 | logs/m-own-u20-msg-after-count-G-u20.log |
| v2-F-folderC-c2f | 2026-10-13 15:15:31 | 0 | 223.5 | 68 / 0 | 84cf2bf4 | logs/v2-F-folderC-c2f.log |
| m-own-u20-count-wait-only-G-u20 | 2026-10-13 15:16:53 | 1 | 156.3 | 84 / 1 | 501408c3 | logs/m-own-u20-count-wait-only-G-u20.log |
| m-own-u20-uncount-in-go-G-u20 | 2026-10-13 15:19:29 | 1 | 157.0 | 84 / 16 | 33e00db9 | logs/m-own-u20-uncount-in-go-G-u20.log |
| m-own-u20-locks-only-G-u20 | 2026-10-13 15:22:07 | 0 | 190.5 | 84 / 0 | c291f47a | logs/m-own-u20-locks-only-G-u20.log |
| v2-G-u2u13-b0 | 2026-10-13 15:19:14 | 0 | 364.6 | 128 / 0 | fce8a391 | logs/v2-G-u2u13-b0.log |
| m-own-u30-stamp-and-dirty-G-u30 | 2026-10-13 15:25:17 | 1 | 279.5 | 89 / 21 | ec664ffc | logs/m-own-u30-stamp-and-dirty-G-u30.log |
| m-c2f-v200-u30-base-whatever-on-screen-G-u30 | 2026-10-13 15:25:24 | 1 | 281.8 | 89 / 42 | 994ee8d3 | logs/m-c2f-v200-u30-base-whatever-on-screen-G-u30.log |
| m-own-u30-stamp-and-unsaved-G-u30 | 2026-10-13 15:29:57 | 1 | 240.5 | 89 / 14 | 77135674 | logs/m-own-u30-stamp-and-unsaved-G-u30.log |
| m-c2f-v200-u30-base-only-other-copy-G-u30 | 2026-10-13 15:30:06 | 1 | 237.0 | 89 / 44 | 9675d720 | logs/m-c2f-v200-u30-base-only-other-copy-G-u30.log |
| m-c2f-v200-u30-unrecorded-said-after-G-u30 | 2026-10-13 15:34:03 | 1 | 207.0 | 89 / 5 | 47c162b6 | logs/m-c2f-v200-u30-unrecorded-said-after-G-u30.log |
| m-own-u30-say-on-refresh-G-u30 | 2026-10-13 15:33:58 | 1 | 219.0 | 89 / 7 | bfd0f692 | logs/m-own-u30-say-on-refresh-G-u30.log |
| m-c2f-v200-u30-recorded-said-unknown-G-u30 | 2026-10-13 15:37:30 | 1 | 249.7 | 89 / 1 | bf1b960e | logs/m-c2f-v200-u30-recorded-said-unknown-G-u30.log |
| m-own-u30-putback-why-file-G-u30 | 2026-10-13 15:37:37 | 0 | 245.9 | 89 / 0 | 4837d916 | logs/m-own-u30-putback-why-file-G-u30.log |
| m-c2f-v200-u30-unsaved-this-session-only-G-u30 | 2026-10-13 15:41:40 | 1 | 201.0 | 89 / 21 | a0eed275 | logs/m-c2f-v200-u30-unsaved-this-session-only-G-u30.log |
| m-own-u30-occupied-words-swapped-G-u30 | 2026-10-13 15:41:43 | 1 | 199.9 | 89 / 2 | 3e60ba63 | logs/m-own-u30-occupied-words-swapped-G-u30.log |
| m-own-u30-clash-words-on-busy-G-u30 | 2026-10-13 15:45:03 | 1 | 148.6 | 89 / 5 | ef46a4db | logs/m-own-u30-clash-words-on-busy-G-u30.log |
| m-c2f-v200-u30-quiet-refresh-only-G-u30 | 2026-10-13 15:45:01 | 1 | 156.8 | 89 / 16 | bdf4db36 | logs/m-c2f-v200-u30-quiet-refresh-only-G-u30.log |
| m-own-u30-ownunsaved-rule-G-u30 | 2026-10-13 15:47:31 | 1 | 132.6 | 89 / 14 | fb879f74 | logs/m-own-u30-ownunsaved-rule-G-u30.log |
| m-c2f-v200-u30-unsaved-only-G-u30 | 2026-10-13 15:47:38 | 1 | 148.5 | 89 / 14 | 76cb0459 | logs/m-c2f-v200-u30-unsaved-only-G-u30.log |
| m-c2f-v200-u30-putback-said-after-G-u30 | 2026-10-13 15:50:07 | 1 | 163.7 | 89 / 1 | 4e66ae9a | logs/m-c2f-v200-u30-putback-said-after-G-u30.log |
| m-c2f-saves-not-serial-F-folderA | 2026-10-13 15:49:55 | 1 | 373.0 | 297 / 5 | e4005437 | logs/m-c2f-saves-not-serial-F-folderA.log |
| m-c2f-v200-u30-putback-said-unknown-G-u30 | 2026-10-13 15:52:51 | 1 | 205.0 | 89 / 2 | 355e5bac | logs/m-c2f-v200-u30-putback-said-unknown-G-u30.log |
| m-c2f-v200-u30-putback-file-unknown-G-u30 | 2026-10-13 15:56:16 | 1 | 172.4 | 89 / 1 | 160242dc | logs/m-c2f-v200-u30-putback-file-unknown-G-u30.log |
| m-c2f-v200-u2-putback-gen-G-u2u13 | 2026-10-13 15:56:08 | 1 | 252.9 | 128 / 1 | 6e937bbd | logs/m-c2f-v200-u2-putback-gen-G-u2u13.log |
| m-c2f-v200-u30-occupied-said-newer-G-u30 | 2026-10-13 15:59:08 | 1 | 165.1 | 89 / 1 | 5ae2fad8 | logs/m-c2f-v200-u30-occupied-said-newer-G-u30.log |
| m-c2f-v200-u2-putback-while-saving-G-u2u13 | 2026-10-13 16:00:21 | 1 | 287.0 | 128 / 34 | d6b3fa7e | logs/m-c2f-v200-u2-putback-while-saving-G-u2u13.log |
| m-c2f-v200-u30-occupied-said-unknown-G-u30 | 2026-10-13 16:01:54 | 1 | 210.7 | 89 / 1 | 51a0fd9b | logs/m-c2f-v200-u30-occupied-said-unknown-G-u30.log |
| m-c2f-v200-u13-base-while-saving-G-u30 | 2026-10-13 16:05:24 | 1 | 177.8 | 89 / 2 | a13c0aa9 | logs/m-c2f-v200-u13-base-while-saving-G-u30.log |
| m-own-u20-locks-only-G-u2u13 | 2026-10-13 16:05:08 | 1 | 254.7 | 128 / 79 | c291f47a | logs/m-own-u20-locks-only-G-u2u13.log |
| m-c2f-v200-u13-clash-while-saving-G-u30 | 2026-10-13 16:08:22 | 1 | 160.1 | 89 / 1 | d78227bc | logs/m-c2f-v200-u13-clash-while-saving-G-u30.log |
| m-own-u30-putback-why-file-F-folderC | 2026-10-13 16:09:23 | 0 | 147.8 | 68 / 0 | 4837d916 | logs/m-own-u30-putback-why-file-F-folderC.log |
| S-c2f-boot-same | 2026-10-13 16:11:53 | 0 | 43.5 |  |  | logs/S-c2f-boot-same.log |
| m-c2f-v200-u20-wait-uncounted-G-u20 | 2026-10-13 16:11:02 | 1 | 162.3 | 84 / 17 | dc0cff4f | logs/m-c2f-v200-u20-wait-uncounted-G-u20.log |
| S-c2f-audit | 2026-10-13 16:12:37 | 0 | 84.4 | ALL CHECKS PASSED |  | logs/S-c2f-audit.log |
| S-c2f-audit-ppt | 2026-10-13 16:14:01 | 0 | 26.0 | ALL CHECKS PASSED |  | logs/S-c2f-audit-ppt.log |
| m-c2f-v200-u20-failed-stays-counted-G-u20 | 2026-10-13 16:13:45 | 1 | 151.6 | 84 / 2 | c5cff638 | logs/m-c2f-v200-u20-failed-stays-counted-G-u20.log |
| S-c2f-audit-other | 2026-10-13 16:14:28 | 0 | 157.3 | ALL CHECKS PASSED |  | logs/S-c2f-audit-other.log |
| m-c2f-v200-u13-base-while-saving-G-u20 | 2026-10-13 16:16:17 | 1 | 169.6 | 84 / 2 | a13c0aa9 | logs/m-c2f-v200-u13-base-while-saving-G-u20.log |
| m-c2f-v200-u13-clash-while-saving-G-u20 | 2026-10-13 16:19:06 | 1 | 145.7 | 84 / 1 | d78227bc | logs/m-c2f-v200-u13-clash-while-saving-G-u20.log |
| m-c1f-v200-u20-wait-uncounted-G-u20 | 2026-10-13 16:21:32 | 1 | 132.1 | 84 / 23 | dc6fd5d6 | logs/m-c1f-v200-u20-wait-uncounted-G-u20.log |
| S-c2f-audit-recon | 2026-10-13 16:17:05 | 0 | 488.7 | ALL CHECKS PASSED |  | logs/S-c2f-audit-recon.log |
| S-c2f-legacy-fsrc | 2026-10-13 16:25:14 | 0 | 16.2 |  |  | logs/S-c2f-legacy-fsrc.log |
| m-c1f-v200-u20-failed-stays-counted-G-u20 | 2026-10-13 16:23:44 | 1 | 151.5 | 84 / 2 | 5a25ded3 | logs/m-c1f-v200-u20-failed-stays-counted-G-u20.log |
| S-c2f-audit-hostile | 2026-10-13 16:25:30 | 0 | 224.7 | ALL CHECKS PASSED |  | logs/S-c2f-audit-hostile.log |
| S-c2f-audit-inject | 2026-10-13 16:29:15 | 0 | 52.0 | ALL CHECKS PASSED |  | logs/S-c2f-audit-inject.log |
| S-c2f-npm-check | 2026-10-13 16:30:07 | 0 | 12.4 | all checks passed |  | logs/S-c2f-npm-check.log |
| S-b0-boot-same | 2026-10-13 16:30:20 | 0 | 43.1 |  |  | logs/S-b0-boot-same.log |
| S-b0-audit | 2026-10-13 16:31:03 | 0 | 41.0 | ALL CHECKS PASSED |  | logs/S-b0-audit.log |
| S-b0-audit-ppt | 2026-10-13 16:31:44 | 0 | 22.6 | ALL CHECKS PASSED |  | logs/S-b0-audit-ppt.log |
| m-b0-saves-not-serial-F-folderA | 2026-10-13 16:26:37 | 1 | 381.9 | 297 / 5 | 879b25b1 | logs/m-b0-saves-not-serial-F-folderA.log |
| S-b0-audit-other | 2026-10-13 16:32:07 | 0 | 129.3 | ALL CHECKS PASSED |  | logs/S-b0-audit-other.log |
| m-c2f-kept-theirs-wrong-word-F-folderA | 2026-10-13 16:32:59 | 1 | 381.1 | 297 / 1 | b05f4428 | logs/m-c2f-kept-theirs-wrong-word-F-folderA.log |
| S-b0-audit-recon | 2026-10-13 16:34:16 | 0 | 462.3 | ALL CHECKS PASSED |  | logs/S-b0-audit-recon.log |
| S-b0-legacy-fsrc | 2026-10-13 16:41:59 | 0 | 18.4 |  |  | logs/S-b0-legacy-fsrc.log |
| m-c2f-v200-u13-pull-while-saving-G-u2u13 | 2026-10-13 16:39:20 | 1 | 316.7 | 128 / 40 | 6caf125e | logs/m-c2f-v200-u13-pull-while-saving-G-u2u13.log |
| S-b0-audit-hostile | 2026-10-13 16:42:17 | 0 | 254.3 | ALL CHECKS PASSED |  | logs/S-b0-audit-hostile.log |
| S-b0-audit-inject | 2026-10-13 16:46:32 | 0 | 29.1 | ALL CHECKS PASSED |  | logs/S-b0-audit-inject.log |
| S-b0-npm-check | 2026-10-13 16:47:01 | 0 | 5.6 | all checks passed |  | logs/S-b0-npm-check.log |
| v5-locktest | 2026-10-13 16:47:25 | 0 | 2.3 |  |  | logs/v5-locktest.log |
| v5-PB-W | 2026-10-13 16:47:27 | 0 | 11.8 |  | 84cf2bf4 | logs/v5-PB-W.log |
| m-c2f-v200-u13-pull-unchecked-G-u2u13 | 2026-10-13 16:44:37 | 1 | 185.7 | 128 / 40 | 0b18930c | logs/m-c2f-v200-u13-pull-unchecked-G-u2u13.log |
| v5-PB-Wtick | 2026-10-13 16:47:39 | 0 | 13.0 |  | 84cf2bf4 | logs/v5-PB-Wtick.log |
| v5-PB-C1 | 2026-10-13 16:47:52 | 0 | 10.1 |  | 84cf2bf4 | logs/v5-PB-C1.log |
| v5-PB-C2a | 2026-10-13 16:48:02 | 0 | 11.6 |  | 84cf2bf4 | logs/v5-PB-C2a.log |
| v5-PB-C2b | 2026-10-13 16:48:14 | 0 | 11.0 |  | 84cf2bf4 | logs/v5-PB-C2b.log |
| v5-PB-NL | 2026-10-13 16:48:25 | 0 | 14.2 |  | 84cf2bf4 | logs/v5-PB-NL.log |
| v5-AD-W | 2026-10-13 16:48:39 | 0 | 15.4 |  | 84cf2bf4 | logs/v5-AD-W.log |
| v5-AD-Wtick | 2026-10-13 16:48:54 | 0 | 21.4 |  | 84cf2bf4 | logs/v5-AD-Wtick.log |
| v5-AD-C1 | 2026-10-13 16:49:16 | 0 | 10.5 |  | 84cf2bf4 | logs/v5-AD-C1.log |
| v5-AD-C2a | 2026-10-13 16:49:26 | 0 | 11.3 |  | 84cf2bf4 | logs/v5-AD-C2a.log |
| m-c2f-v200-u13-said-nothing-loaded-G-u2u13 | 2026-10-13 16:47:43 | 1 | 116.9 | 128 / 10 | 610ee8f0 | logs/m-c2f-v200-u13-said-nothing-loaded-G-u2u13.log |
| v5-AD-C2b | 2026-10-13 16:49:38 | 0 | 11.3 |  | 84cf2bf4 | logs/v5-AD-C2b.log |
| v5-BR-W | 2026-10-13 16:49:49 | 0 | 14.8 |  | 84cf2bf4 | logs/v5-BR-W.log |
| v5-BR-Wtick | 2026-10-13 16:50:04 | 0 | 14.9 |  | 84cf2bf4 | logs/v5-BR-Wtick.log |
| v5-BR-C1 | 2026-10-13 16:50:19 | 0 | 12.0 |  | 84cf2bf4 | logs/v5-BR-C1.log |
| v5-BR-C2a | 2026-10-13 16:50:31 | 0 | 12.6 |  | 84cf2bf4 | logs/v5-BR-C2a.log |
| v5-BR-C2b | 2026-10-13 16:50:44 | 0 | 11.9 |  | 84cf2bf4 | logs/v5-BR-C2b.log |
| v5-BR-Wperm | 2026-10-13 16:50:56 | 0 | 12.5 |  | 84cf2bf4 | logs/v5-BR-Wperm.log |
| m-own-u30-putback-any-year-G-u30 | 2026-10-13 16:49:47 | 0 | 87.7 | 89 / 0 | d6a60183 | logs/m-own-u30-putback-any-year-G-u30.log |
| v5-BR-C1perm | 2026-10-13 16:51:08 | 0 | 10.2 |  | 84cf2bf4 | logs/v5-BR-C1perm.log |
| v5-BR-Wh | 2026-10-13 16:51:18 | 0 | 9.9 |  | 84cf2bf4 | logs/v5-BR-Wh.log |
| v5-BR-C1h | 2026-10-13 16:51:28 | 0 | 8.6 |  | 84cf2bf4 | logs/v5-BR-C1h.log |
| v5-BR-Wpermh | 2026-10-13 16:51:37 | 0 | 8.1 |  | 84cf2bf4 | logs/v5-BR-Wpermh.log |
| v5-BR-C2ah | 2026-10-13 16:51:45 | 0 | 8.1 |  | 84cf2bf4 | logs/v5-BR-C2ah.log |
| v5-BR-C2bh | 2026-10-13 16:51:53 | 0 | 9.2 |  | 84cf2bf4 | logs/v5-BR-C2bh.log |
| v5-PF-W | 2026-10-13 16:52:02 | 0 | 11.2 |  | 84cf2bf4 | logs/v5-PF-W.log |
| m-own-u30-clash-any-year-G-u30 | 2026-10-13 16:51:15 | 0 | 62.5 | 89 / 0 | 83361415 | logs/m-own-u30-clash-any-year-G-u30.log |
| v5-PF-C1 | 2026-10-13 16:52:14 | 0 | 10.0 |  | 84cf2bf4 | logs/v5-PF-C1.log |
| v5-PF-C2a | 2026-10-13 16:52:24 | 0 | 9.5 |  | 84cf2bf4 | logs/v5-PF-C2a.log |
| v5-x-PB-Wcount | 2026-10-13 16:52:33 | 0 | 9.6 |  | 84cf2bf4 | logs/v5-x-PB-Wcount.log |
| v5-x-AD-Wcount | 2026-10-13 16:52:43 | 0 | 9.3 |  | 84cf2bf4 | logs/v5-x-AD-Wcount.log |
| v5-x-BR-Wcount | 2026-10-13 16:52:52 | 0 | 9.3 |  | 84cf2bf4 | logs/v5-x-BR-Wcount.log |
| v5-x-BR-Wreal | 2026-10-13 16:53:02 | 0 | 10.3 |  | 84cf2bf4 | logs/v5-x-BR-Wreal.log |
| v5-x-BR-Wrealtick | 2026-10-13 16:53:12 | 0 | 10.8 |  | 84cf2bf4 | logs/v5-x-BR-Wrealtick.log |
| m-own-u30-occupied-any-year-G-u30 | 2026-10-13 16:52:18 | 0 | 67.2 | 89 / 0 | f005a865 | logs/m-own-u30-occupied-any-year-G-u30.log |
| v5-x-BR-C1real | 2026-10-13 16:53:23 | 0 | 9.3 |  | 84cf2bf4 | logs/v5-x-BR-C1real.log |
| v5-x-BR-Wrealcount | 2026-10-13 16:53:32 | 0 | 10.5 |  | 84cf2bf4 | logs/v5-x-BR-Wrealcount.log |
| v5-x-BR-Wrealh | 2026-10-13 16:53:43 | 0 | 10.1 |  | 84cf2bf4 | logs/v5-x-BR-Wrealh.log |
| v5-x-O4-tick | 2026-10-13 16:53:53 | 0 | 8.7 |  | 84cf2bf4 | logs/v5-x-O4-tick.log |
| v5-x-O4-tickh | 2026-10-13 16:54:01 | 0 | 8.7 |  | 84cf2bf4 | logs/v5-x-O4-tickh.log |
| v5-x-BR-Wrealtickcount | 2026-10-13 16:54:10 | 0 | 10.4 |  | 84cf2bf4 | logs/v5-x-BR-Wrealtickcount.log |
| v5-check | 2026-10-13 16:54:21 | 0 | 0.2 |  |  | logs/v5-check.log |
| v5-xcheck | 2026-10-13 16:54:21 | 0 | 0.2 |  |  | logs/v5-xcheck.log |
| p-P-u30w-b0 | 2026-10-13 16:53:39 | 1 | 74.7 | 93 / 49 | fce8a391 | logs/p-P-u30w-b0.log |
| v8-F-folderB2-c2f | 2026-10-13 16:54:40 | 0 | 88.1 | 55 / 0 | 84cf2bf4 | logs/v8-F-folderB2-c2f.log |
| p-P-u30w-c2f | 2026-10-13 16:54:54 | 0 | 101.1 | 93 / 0 | 84cf2bf4 | logs/p-P-u30w-c2f.log |
| m-own-u20-uncount-in-go2-G-u20 | 2026-10-13 16:56:14 | 1 | 62.4 | 84 / 1 | 60f1f032 | logs/m-own-u20-uncount-in-go2-G-u20.log |
| pm-own-u30-putback-any-year-P-u30w | 2026-10-13 16:56:35 | 1 | 93.3 | 93 / 1 | d6a60183 | logs/pm-own-u30-putback-any-year-P-u30w.log |
| pm-own-u30-clash-any-year-P-u30w | 2026-10-13 16:58:09 | 1 | 91.4 | 93 / 1 | 83361415 | logs/pm-own-u30-clash-any-year-P-u30w.log |
| pm-own-u30-occupied-any-year-P-u30w | 2026-10-13 16:59:40 | 1 | 92.3 | 93 / 1 | f005a865 | logs/pm-own-u30-occupied-any-year-P-u30w.log |
| p-P-u30w-c1f | 2026-10-13 17:01:22 | 1 | 97.8 | 93 / 47 | 83b87782 | logs/p-P-u30w-c1f.log |
| rc-u20-c2f | 2026-10-13 17:03:16 | 1 | 7.1 |  | 84cf2bf4 | logs/rc-u20-c2f.log |
| rc-u20-b0 | 2026-10-13 17:03:23 | 1 | 6.8 |  | fce8a391 | logs/rc-u20-b0.log |
| rc-u20-c1f | 2026-10-13 17:03:30 | 1 | 7.5 |  | 83b87782 | logs/rc-u20-c1f.log |

Notes in runs.txt:
- lanes v1A/v1B launched 2026-10-13 14:48:12 EDT
- the 12 v1-* runs above exited 1 in ~3 s at boot: h/<copy> had no node_modules link, so the harness could not import jsdom (setup error; no check ran). Link added; re-run as v2-*. 2026-10-13 14:49:54 EDT
- lanes v2A/v2B launched 2026-10-13 14:50:01 EDT
- DEVIATION 2026-10-13 15:05:41 EDT: two 'node --check' parse-only runs (c1f, c2f audit-import; nothing executed) were started from my shell while lanes A and B each had a node run going, so for under a second each I had three node processes; and I did not check the AUDIT_IMPORT_RUNNING lock first (it was absent when checked right after). No further node run outside the lanes.
- v2-F-folderB-c2f reached the 600 s cap (load ~34) after 98 of 142 checks, all passing; the 6 scenarios it had not finished are re-run as F-folderB2 (v8A), not counted as a failure. 2026-10-13 15:12:34 EDT
- NOTE 2026-10-13 15:25:51 EDT: m-own-u20-uncount-in-go-G-u20 ran a mutant that, as built, never uncounts at all (done made a no-op, go unchanged): it is reported as own-u20-never-uncounted. The intended 'uncount in go' form is own-u20-uncount-in-go2 (v9A).
- suites lane started 2026-10-13 16:11:53 EDT
- suites lane done 2026-10-13 16:47:06 EDT
- probe v5 started 2026-10-13 16:47:25 EDT
- probe v5 done 2026-10-13 16:54:21 EDT
- real Chromium rc-u20 launched 2026-10-13 17:03:16 EDT (alone; no other node run of mine going)

## PIDs

`pids.txt` has 321 lines:
- 276 are bounded runs, each with its `timeout` PID and its child (`node` 137, `npm` 1, `timeout` 138);
- the rest are each bounded text, copy or hash command (setsid PID), each lane wrapper (`batch.sh`, `after.sh`,
  `after-suites.sh`, `after-probe.sh`, `suites.sh`; each only starts bounded runs in turn and polls the previous wrapper with
  `kill -0`, which sends no signal), and the deviations below.

**Nothing was killed or stopped.** No process was sent a signal by me, and nothing was killed by name or pattern. Every wrapper
ended by itself. No node or Chromium process of mine is left (`ps`, 5:04 PM ET).

## Deviations, stated plainly

- **Three node processes for under a second, twice, and no lock check (3:05 PM ET).** I ran `node --check` (parse only,
  nothing executed) on c1f's and c2f's audit-import from my shell. Lanes A and B each had a node run going, so for a moment I
  had three node processes. I did not check the AUDIT_IMPORT_RUNNING lock first; it was absent when I checked right after.
  Recorded in `logs/runs.txt` and `pids.txt`.
- **An unbounded read-only `grep -rln` over `rec/`** (PID 22030, 3:00 PM ET). It looked for earlier results of
  `saves-not-serial`, ran ~3 min, and was moved to the background by the tool. Recorded in `pids.txt`.
- **Read-only commands and small writes outside the wrapper**, as in round 1 and the builder's round:
  - read-only: `ls`, `cat`, `grep`, `sed -n`, `diff`, `wc`, `ps`, `git log` / `show` / `hash-object` / `status`, and short
    `python3 -I` readers (`src/cmp.py`, `cmpall.py`, `labels2.py`, `mres.py`, `wants.py`, `scen.py`, `runtable.py`, and inline
    summaries);
  - small writes: `mkdir`, `ln -s` (the `h/<copy>/node_modules` links), `chmod`, the heredocs and editor writes of my
    scripts, of `proposal/*` and of these README parts, the `sed` copies of the round-1 reviewer's `run.sh` / `frun.sh` /
    `batch.sh` / `suites.sh` with only the directory changed, the inline `python3 -I` that wrote
    `proposal/mutate-c2f-plus-10w.mjs.txt`, and the `diff -u` files in `diffs/`.
  - Every node, npm and Chromium run, every mutant build, and every copy of a copy was bounded.
- **One own mutant built other than intended.** `own-u20-uncount-in-go` came out as "never uncounted". It is reported under that
  name, and the intended form was built and run as `own-u20-uncount-in-go2`.

## Not done (plainly)

- The full audit-import and audit-board were not run (the lead's). G-all, the four blocks in one process, was not run: its
  blocks ran in three harnesses. `mutate.mjs` was never run, imported or executed; it was read as text only. `playwright
  install` was never run.
- Real Chromium was run only with the builder's script (W1–W7, F1), not with new cases. U30 was not run in a browser, as the
  builder said: it does not depend on the browser's locks.
- The base's other suites were run here, but the round-1 base logs were not compared.
- S1's proposal is a tested draft (`proposal/`), not applied to any copy the builder owns. Nothing was committed or pushed, and
  no NEXT-VERSION.md or ledger text was written beyond the draft lines quoted in S1.

---
README finalised at 5:06 PM ET on Tue 13 Oct 2026 (read with `TZ=America/New_York date`). The last bounded run, `rc-u20-c1f`, started at 5:03:30
PM ET and ended at 5:03:37 PM ET.
