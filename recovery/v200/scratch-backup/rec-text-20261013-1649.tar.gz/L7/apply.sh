#!/bin/bash
# apply.sh <track> [<onto-ref>]: in the scratch clone, cherry-pick draft branch t-<track> (base 7ee498a -> the track's c1)
# onto <onto-ref> (default: orbit-board's claude/v200-fixes-wip). Only add/add conflicts are resolved (union.py); anything
# else stops. Prints the resulting blobs. Never touches /home/user/orbit-board.
set -u; L7=$(cd "$(dirname "$0")" && pwd -P); M=$L7/merge; t=$1; onto=${2:-}
cd $M || exit 2
git fetch -q origin claude/v200-fixes-wip || exit 2
[ -z "$onto" ] && onto=origin/claude/v200-fixes-wip
git checkout -q -B apply-$t $onto || exit 2
if ! git cherry-pick --no-commit t-$t >/dev/null 2>&1; then
  for f in $(git diff --name-only --diff-filter=U); do python3 -I $L7/union.py $f || { git cherry-pick --abort; exit 3; }; git add $f; done
fi
git -c core.hooksPath=/dev/null commit -qm "apply $t onto $(git rev-parse --short $onto)" || exit 4
grep -c '^<<<<<<<\|^>>>>>>>\|^=======$' prioritization-board-grid.html tools/export-audit/*.mjs | grep -v ':0$' && { echo "MARKERS LEFT"; exit 5; }
echo "apply-$t = $(git rev-parse --short HEAD) onto $(git rev-parse --short $onto)"
for f in prioritization-board-grid.html tools/export-audit/audit-recon.mjs tools/export-audit/audit-import.mjs tools/export-audit/audit-other.mjs tools/export-audit/audit-board.mjs tools/export-audit/mutate.mjs; do echo "  $f $(git rev-parse --short=8 HEAD:$f)"; done
git diff --stat $onto HEAD | tail -1
