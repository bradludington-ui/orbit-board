# apply2.py <track> <onto-ref> <copy1> [<copy2> ...]   (copies relative to rec/L6/<track>, cumulative from the base)
# In the scratch clone rec/L7/merge: builds the track's draft chain (base 7ee498a -> copy1 -> copy2 ...) as commits on
# branch d-<track>, then cherry-picks that chain onto <onto-ref> as branch a-<track>. Only add/add conflict hunks
# (empty base side) are resolved, as ours+theirs (union.py); anything else stops. Files present in a copy but not in the
# base tree are reported and NOT added. mutate.mjs.txt in a copy is applied as tools/export-audit/mutate.mjs (text only;
# never run). Never touches /home/user/orbit-board.
import sys, os, subprocess, filecmp, shutil
L6 = '/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6'
L7 = os.path.dirname(os.path.abspath(__file__)); M = os.path.join(L7, 'merge'); BASE = '7ee498a46507972f803cd48ce9f27d5d668acb63'
track, onto, copies = sys.argv[1], sys.argv[2], sys.argv[3:]
def g(*a, ok=False):
    r = subprocess.run(['git', '-C', M, '-c', 'core.hooksPath=/dev/null', '-c', 'merge.conflictStyle=diff3'] + list(a), capture_output=True, text=True)
    if r.returncode and not ok: print('GIT FAIL', a, r.stdout, r.stderr); sys.exit(2)
    return r
g('fetch', '-q', 'origin', 'claude/v200-fixes-wip')
base_files = [l for l in g('ls-tree', '-r', '--name-only', BASE).stdout.split('\n') if l]
g('checkout', '-q', '-B', f'd-{track}', BASE)
for i, c in enumerate(copies, 1):
    cd = os.path.join(L6, track, c); changed = []
    for f in base_files:
        src = os.path.join(cd, f + '.txt') if f == 'tools/export-audit/mutate.mjs' else os.path.join(cd, f)
        if f == 'tools/export-audit/mutate.mjs' and not os.path.exists(src): src = os.path.join(cd, f)
        if not os.path.exists(src):
            if f.startswith(('tools/', 'prioritization-board-grid.html', 'package.json', 'NEXT-VERSION.md')) and os.path.exists(os.path.join(L6, 'base', f)):
                print(f'{c}: MISSING {f}'); sys.exit(3)
            continue
        dst = os.path.join(M, f)
        if not filecmp.cmp(src, dst, shallow=False): shutil.copyfile(src, dst); changed.append(f)
    extra = []
    for dp, dn, fs in os.walk(cd):
        dn[:] = [d for d in dn if not os.path.islink(os.path.join(dp, d)) and d != 'node_modules']
        for f in fs:
            rel = os.path.relpath(os.path.join(dp, f), cd)
            if rel == 'tools/export-audit/mutate.mjs.txt' or rel == 'runtime-encoding-shim.mjs': continue
            if rel not in base_files: extra.append(rel)
    g('add', '-A', '.'); g('commit', '-q', '--allow-empty', '-m', f'draft {track} {c}')
    print(f'draft {track} {c}: changed {changed}' + (f' | NOT ADDED (not in base): {extra}' if extra else ''))
chain = g('rev-list', '--reverse', f'{BASE}..d-{track}').stdout.split()
g('checkout', '-q', '-B', f'a-{track}', onto)
for sha in chain:
    r = g('cherry-pick', '--no-commit', sha, ok=True)
    if r.returncode:
        for f in [x for x in g('diff', '--name-only', '--diff-filter=U').stdout.split('\n') if x]:
            u = subprocess.run(['python3', '-I', os.path.join(L7, 'union.py'), os.path.join(M, f)], capture_output=True, text=True)
            print('  ' + u.stdout.strip())
            if u.returncode: g('cherry-pick', '--abort', ok=True); print('STOP: non add/add conflict in', f); sys.exit(4)
            g('add', f)
    msg = g('log', '-1', '--format=%s', sha).stdout.strip()
    g('commit', '-q', '-m', f'apply {msg}')
for f in ['prioritization-board-grid.html', 'tools/export-audit/audit-import.mjs', 'tools/export-audit/audit-recon.mjs', 'tools/export-audit/audit-board.mjs', 'tools/export-audit/audit-other.mjs', 'tools/export-audit/mutate.mjs']:
    t = open(os.path.join(M, f)).read()
    if '\n<<<<<<< ' in t or '\n>>>>>>> ' in t or '\n||||||| ' in t: print('MARKERS LEFT in', f); sys.exit(5)
print(f'a-{track} = {g("rev-parse", "--short", "HEAD").stdout.strip()} onto {g("rev-parse", "--short", onto).stdout.strip()}; {len(chain)} commit(s)')
for sha in g('rev-list', '--reverse', f'{onto}..HEAD').stdout.split():
    print('  ', g('log', '-1', '--format=%h %s', sha).stdout.strip(), '| board', g('rev-parse', '--short=8', f'{sha}:prioritization-board-grid.html').stdout.strip())
