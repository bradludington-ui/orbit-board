# wfstate.py <group> <journal1> [<journal2> ...]  (journals in chronological order)
# Rebuilds each track's finished chain (build -> round r reviews (money, tests) -> fix r -> ...) from workflow journals,
# writes every used result to rec/L6/<track>/wfstate/<label>.json, and prints a compact JSON state for the
# state-driven fix workflow. A round-r review counts only if it STARTED after the result it reviewed (the build or
# fix r-1) was recorded, so a stale review of an older draft is never reused.
import json, sys, os
GROUPS = {'save': ['u19','u20u30','adopt','u18','hold'], 'saveA': ['u19','u20u30'], 'saveB': ['adopt','u18','hold'], 'mathA': ['u9','u10'], 'mathU28': ['u28'], 'math': ['u9','u10','u28'], 'codex': ['cycreg','yearsel','regtext'], 'codexB': ['u37','u40','u41u42'], 'mathU9': ['u9'], 'codexYR': ['yearsel','regtext'], 'u44g': ['u44'], 'mathU10': ['u10'], 'codexC': ['cycreg']}
L6 = '/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6'
group = sys.argv[1]; ev = []; n = 0
for p in sys.argv[2:]:
    for l in open(p):
        l = l.strip()
        if not l: continue
        try: j = json.loads(l)
        except Exception: continue
        ev.append((n, j)); n += 1
label = {}; start = {}
for i, j in ev:
    if j.get('type') == 'started': label[j['agentId']] = j.get('label'); start[j['agentId']] = i
res = {}  # label -> list of (startIdx, resultIdx, result)
for i, j in ev:
    if j.get('type') == 'result' and j.get('agentId') in label:
        r = j.get('result', j.get('value'))
        if r is None: continue
        res.setdefault(label[j['agentId']], []).append((start[j['agentId']], i, r))
def pick(lab, after):
    c = [x for x in res.get(lab, []) if x[0] > after]
    return max(c, key=lambda x: x[1]) if c else None
def save(k, lab, r):
    d = os.path.join(L6, k, 'wfstate'); os.makedirs(d, exist_ok=True)
    f = os.path.join(d, lab.replace(':', '_').replace('#', '_r') + '.json')
    json.dump(r, open(f, 'w'), indent=1); return f
state = {}
for k in GROUPS[group]:
    b = pick('build:' + k, -1)
    if not b: continue
    st = {'build': {'file': save(k, 'build:' + k, b[2]), 'dir': b[2].get('dir'), 'commits': b[2].get('commits')}, 'rounds': []}
    curIdx = b[1]
    for r in range(1, 5):
        rd = {}
        for lens in ('money', 'tests'):
            v = pick(f'verify:{k}#{r}:{lens}', curIdx)  # started after the draft it reviews was recorded
            if v:
                mf = v[2].get('mustFix') or []
                rd[lens] = {'file': save(k, f'verify:{k}#{r}:{lens}', v[2]), 'verdict': v[2].get('verdict'),
                            'mustFix': [m[:400] for m in mf], 'idx': v[1]}
        if not rd: break
        st['rounds'].append(rd)
        if 'money' not in rd or 'tests' not in rd: break
        must = len(rd['money']['mustFix']) + len(rd['tests']['mustFix'])
        if must == 0: break
        lastV = max(rd['money']['idx'], rd['tests']['idx'])
        f = pick(f'fix:{k}#{r}', lastV)  # the fix must have started after BOTH reviews it answers finished
        if not f: break
        rd['fix'] = {'file': save(k, f'fix:{k}#{r}', f[2]), 'dir': f[2].get('dir'), 'commits': f[2].get('commits')}
        curIdx = f[1]
    for rd in st['rounds']:
        for lens in ('money', 'tests'):
            if lens in rd: rd[lens].pop('idx', None)
    state[k] = st
print(json.dumps(state))
