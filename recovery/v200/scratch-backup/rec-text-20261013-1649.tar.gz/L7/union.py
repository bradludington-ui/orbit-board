# union.py <file>: resolve diff3 conflict hunks ONLY when the base side is empty (both sides added at the same place):
# keep ours, then theirs. Any hunk with a non-empty base -> exit 3, file untouched.
import sys
f=sys.argv[1]; L=open(f).read().split('\n'); out=[]; i=0; n=0
while i<len(L):
    if L[i].startswith('<<<<<<< '):
        a=[];o=[];b=[];st='a';i+=1
        while not L[i].startswith('>>>>>>> '):
            if L[i].startswith('||||||| '): st='o'
            elif L[i]=='=======' : st='b'
            else: {'a':a,'o':o,'b':b}[st].append(L[i])
            i+=1
        if o: print(f'{f}: hunk {n+1} has a non-empty base ({len(o)} lines); not resolved'); sys.exit(3)
        out+=a+b; n+=1; i+=1; continue
    out.append(L[i]); i+=1
open(f,'w').write('\n'.join(out)); print(f'{f}: {n} add/add hunk(s) resolved as ours+theirs')
