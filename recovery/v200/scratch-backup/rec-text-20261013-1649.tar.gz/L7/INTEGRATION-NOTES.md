# Integration notes for committing tracks (from the dry run wf_176cd076-f61, rec/L9/dryrun; written 3:45 PM ET, 13 Oct)

Planned order: u20u30 -> u19 -> adopt -> u18 -> hold -> u9 -> u10 -> cycreg -> yearsel -> regtext -> u37 -> u40 -> u41u42 (+ u43, u44).
Tracks commit as they become clean, so the order on the branch may differ. These hold WHATEVER the commit order:

1. u18 x hold (_driveStorePushRun): U4's synchronous hold check  if(impMixedOn()){...}  must sit IMMEDIATELY BEFORE
   await driveWrite(dir, driveName(fy, ap), body), AFTER U18's awaited re-read. union.py (ours, then theirs) gets this
   wrong when hold is already on the branch and u18 lands second: hand-place it. Evidence: rec/L9/dryrun/save/ (I1).
2. u20u30 x adopt (driveClashSay, C1): nest the two rules, keep both. U30: nothing recorded -> 'this browser has no
   record of which copy in the folder, if any, the work on screen came from.'; U29: theirs not newer than the recorded
   copy -> 'that is not the copy you are working from'. Spec: rec/L9/dryrun/save/spec/allfr-nested.json. Then re-anchor
   v200-u30-unrecorded-said-after, v200-u30-recorded-said-unknown, v200-adopt-u29-clash-after and re-run them.
3. u18 x u20u30 x adopt (driveClashSay refused? line, C2): independent edits; hand-merge keeping all
   (save/spec/u18-holdfirst.json, save/spec/allfr-nested.json) plus a union of the two add/add comments.
4. u18's entry v200-u18-pen-line-kept matches twice once hold is in: re-anchor it to include
   'if(MS.ts===wroteTs){ MS.ts=was.ts;'.
5. u20u30's c2f x u19 (keptPutBack's put-back message): keep U19's 'swap' branch first, then c2f's 'after' wording.
6. u40: integrate the u40 BUILDER's own copy (c1, board 278bf731 at 2:55 PM ET or later), never Codex's stand-in
   2419366b (its onchange text breaks U10's block). Keep U10's cycBlock('Changing a destination') as the FIRST statement
   of flowSetEnt.
7. u10 must ship with cycreg and yearsel (they rely on U10's whole-copy cycReapply).
8. regtext: integrate its fix round 2 or later (board abcb8bac or later); when u40 lands, drop regtext's draft lines that
   carry U40 as unresolved (NEXT-VERSION paragraph 'stands only if that fix does not land', UNRESOLVED-line, MATRIX-limits).
9. Notes to pass on (optional): yearsel's U34 notice says 'Click ALL YEARS ...' in a locked view (add 'on the working
   plan'); cycreg's fullImportText _inRcnNext adjacency (re-check when u10 c4 lands); rcnAdd/rcnDel/rcnSet ask before
   save() refuses in a view (u10, optional).
10. The dry run's exports and locked-view reviewers were stopped at 3:44 PM ET (memory); re-run them once u37, u40, u10
   fix 2 and u44 have drafts (resume wf_176cd076-f61, or a fresh run on the newer copies).
