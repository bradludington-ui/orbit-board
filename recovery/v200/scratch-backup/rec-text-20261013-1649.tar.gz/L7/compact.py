# compact.py <state.json>: shortens a wfstate.py state for passing as Workflow args: paths relative to rec/L6,
# must-fix texts replaced by numbered pointers into the verdict file (the count is kept), commits dropped.
import json, sys
L6 = '/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/'
s = json.load(open(sys.argv[1])); out = {}
rel = lambda p: p[len(L6):] if p and p.startswith(L6) else p
for k, v in s.items():
    o = {'build': {'file': rel(v['build']['file']), 'dir': rel(v['build']['dir'])}, 'rounds': []}
    for rd in v['rounds']:
        r = {}
        for lens in ('money', 'tests'):
            if lens in rd:
                r[lens] = {'file': rel(rd[lens]['file']), 'verdict': rd[lens]['verdict'],
                           'mustFix': [f'must-fix {i+1} (full text in the file)' for i in range(len(rd[lens]['mustFix']))]}
        if 'fix' in rd: r['fix'] = {'file': rel(rd['fix']['file']), 'dir': rel(rd['fix']['dir'])}
        o['rounds'].append(r)
    out[k] = o
print(json.dumps(out, separators=(',', ':')))
