# Restart after the usage-limit reset (written 4:48 PM ET, 13 Oct; reset expected about 7:31 PM ET)

Brad, about 4:45 PM ET: "Let's prepare for a usage timeout. We're at 78% with 2hrs 46mins to go. Prepare accordingly so we
don't have to rerun anything."

## What was done at about 4:46 PM ET
- Stopped (their agents were early or long-running; all their work is on disk and resumes from it):
  mathA wf_5b40c662-ed2 (u10 round-3 reviews), saveB wf_db4b1829-a41 (adopt round-2 tests, hold fix 1),
  u44g wf_4398bdbd-cd2 (u44 builder), codexB wf_6a154929-f05 (u41u42 builder, u40 round-1 tests). Earlier (4:42 PM ET):
  mathU28 wf_92019e7a-ad5 (round-3 reviews). No leftover processes (checked by command line and by working directory).
- Kept, because their agents were mid-to-late and can finish: saveA wf_b5e73cec-5e2 (u20u30 r2 tests, u19 r3 money),
  codex wf_92077d4c-3db (cycreg fix 3), mathU9 wf_2930765d-ee9 (u9 fix 3 with U43), codexYR wf_b4198302-8c5 (yearsel r3
  tests, regtext r3 tests). A background watcher (rec/L7/watch-events.sh) wakes the lead on each journal event; each
  group is stopped as soon as its current agents finish, so no agent is left mid-step when the limit hits.
- fixes-state.js: resume notes now name the 4:46 PM ET stop; RESUME_D covers u37, u40, u41u42 and u44; new groups
  mathU10 ['u10'] and codexC ['cycreg'] (u9 runs as mathU9, yearsel+regtext as codexYR). Launches use the stop-on-failure
  logic (a reviewer or fixer that returns nothing stops its track instead of burning rounds).

## Usage budget (the binding limit)
78% of a 5-hour window was used in about 2 h 14 min with about 13 agents: about 0.58% a minute. A full window therefore
sustains only about 7-8 agents at once. Run at most 8 agents (4 groups x 2) at a time; add a group only when one ends.

## After the reset, in this order (each: rebuild state, then launch fixes-state.js with resume:true)
State for the already-stopped groups is precomputed in rec/L7/restart/args-<group>.json (pass its contents as args).
For a group stopped later, rebuild first:
  python3 -I rec/L7/wfstate.py <group> <journals...> > rec/L7/restart/state-<group>.json
  python3 -I rec/L7/compact.py rec/L7/restart/state-<group>.json > rec/L7/restart/cstate-<group>.json
Journals per group (append the run that was still going if it ran past this note):
  saveA   : /root/.claude/projects/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/subagents/workflows/{wf_12f3bad9-2bc,wf_99519359-797,wf_5500090d-4a1,wf_b5e73cec-5e2}/journal.jsonl
  saveB   : /root/.claude/projects/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/subagents/workflows/{wf_12f3bad9-2bc,wf_99519359-797,wf_7d88dfb5-7c0,wf_db4b1829-a41}/journal.jsonl
  mathU10 : /root/.claude/projects/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/subagents/workflows/{wf_041e5055-bb1,wf_534cd8b6-9c3,wf_c08338b2-f2f,wf_5b40c662-ed2}/journal.jsonl
  mathU9  : /root/.claude/projects/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/subagents/workflows/{wf_041e5055-bb1,wf_534cd8b6-9c3,wf_c08338b2-f2f,wf_5b40c662-ed2,wf_2930765d-ee9}/journal.jsonl
  codexC  : /root/.claude/projects/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/subagents/workflows/{wf_66312e0c-108,wf_f45a7fab-957,wf_92077d4c-3db}/journal.jsonl
  codexYR : /root/.claude/projects/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/subagents/workflows/{wf_66312e0c-108,wf_f45a7fab-957,wf_92077d4c-3db,wf_b4198302-8c5}/journal.jsonl
  codexB  : /root/.claude/projects/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/subagents/workflows/{wf_ce8b2b90-1a7,wf_6a154929-f05}/journal.jsonl
  u44g    : /root/.claude/projects/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/subagents/workflows/wf_4398bdbd-cd2/journal.jsonl
  mathU28 : /root/.claude/projects/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/subagents/workflows/{wf_041e5055-bb1,wf_534cd8b6-9c3,wf_36500498-c4d,wf_92019e7a-ad5}/journal.jsonl
Priority (release blockers first; at most 8 agents):
  wave 1: codexB (u37 round 1 + u40 round 1; u41u42 builder queued behind them), u44g (u44 builder), mathU10 (u10
          round 3), saveB (adopt round 2, u18 round 2, hold fix 1).
  wave 2, as wave-1 groups end: whichever of saveA, codexC, mathU9, codexYR still has steps; then mathU28 (only after
          Brad's answer on the font setting, Codex C2 memo 3).
  Then: the dry run's exports and locked-view reviewers on the newer copies (rec/L7/INTEGRATION-NOTES.md item 10).
Before each launch: no process of that group's agents is running (check pids.txt entries by command line and cwd).

## Commits
A track clean in both reviews of its last round is committed locally at once (rec/L7/INTEGRATION-NOTES.md for the
overlap rules), and pushed only after its commit check passes (rec/L8/commit-check.js, one agent; counts toward the 8).
