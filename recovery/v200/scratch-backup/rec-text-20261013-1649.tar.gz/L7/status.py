# status.py [run ...]: for the given workflow runs (default: the current ones), print each agent's label, state and
# verdict with must/should counts, in journal order. Reads journals only.
import json, sys, os
J = '/root/.claude/projects/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/subagents/workflows'
runs = sys.argv[1:] or ['wf_b5e73cec-5e2', 'wf_db4b1829-a41', 'wf_5b40c662-ed2', 'wf_92077d4c-3db', 'wf_4398bdbd-cd2', 'wf_6a154929-f05', 'wf_2930765d-ee9', 'wf_b4198302-8c5']
for r in runs:
    p = f'{J}/{r}/journal.jsonl'
    if not os.path.exists(p): print(f'== {r}: no journal'); continue
    lab, rows = {}, []
    for l in open(p):
        try: e = json.loads(l)
        except Exception: continue
        if e.get('type') == 'started': lab[e['key']] = e.get('label'); rows.append([e.get('label'), 'running', ''])
        if e.get('type') == 'result':
            res = e.get('result')
            if isinstance(res, str):
                try: res = json.loads(res)
                except Exception: res = {}
            L = lab.get(e['key'])
            for row in rows:
                if row[0] == L and row[1] == 'running':
                    row[1] = 'done'
                    if isinstance(res, dict) and 'verdict' in res:
                        row[2] = f"{res['verdict']} must={len(res.get('mustFix') or [])} should={len(res.get('shouldFix') or [])}"
                    elif res is None: row[2] = 'NULL'
                    break
    print(f'== {r}')
    for L, s, v in rows: print(f'   {str(L):28s} {s:8s} {v}')
