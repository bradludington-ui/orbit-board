#!/bin/bash
# watch-events.sh: exits (printing the new journal lines' type and label) as soon as any of the given workflow journals
# gains a line. Read-only; polls every 20 s.
J=/root/.claude/projects/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/subagents/workflows
declare -A base
for r in "$@"; do base[$r]=$(wc -l < $J/$r/journal.jsonl); done
while true; do
  for r in "$@"; do
    n=$(wc -l < $J/$r/journal.jsonl)
    if [ "$n" -gt "${base[$r]}" ]; then
      echo "EVENT in $r at $(TZ=America/New_York date '+%-I:%M:%S %p ET'):"
      tail -n +$(( ${base[$r]} + 1 )) $J/$r/journal.jsonl | python3 -I -c "
import json,sys
for l in sys.stdin:
    e=json.loads(l); r=e.get('result')
    if isinstance(r,str):
        try: r=json.loads(r)
        except Exception: r={}
    v=(r or {}).get('verdict') if isinstance(r,dict) else None
    m=len((r or {}).get('mustFix') or []) if isinstance(r,dict) else ''
    print(' ', e.get('type'), e.get('label') or e.get('agentId'), v or '', ('must=%s'%m) if v else '')"
      exit 0
    fi
  done
  sleep 20
done
