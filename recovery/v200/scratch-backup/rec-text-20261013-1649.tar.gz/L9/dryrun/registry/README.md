# ORBIT v2.00 — interaction review: registry text and the import door (cycreg, yearsel, regtext, u10, u40)

Written 13 Oct 2026; work began at 2:47 PM ET, and this file was started at 3:32 PM ET. All times are Eastern. Nothing
was committed to, staged in or pushed from `/home/user/orbit-board` or `/home/user/orbit-ui`. `rec/L6/*`, `rec/L7/merge`
and the dry run's own `clone/`, `tree/` and `basetree/` were only read. All of my work is under `rec/L9/dryrun/registry/`
(below, a path with no prefix is relative to that folder). The board file stays the empty template: every populated board
existed only in memory during a run. `mutate.mjs` was read only as TEXT (`rec/bin/mcount.py`, `python3 -I`); it was never
imported, run or `node --check`ed. No Chromium and no `playwright install`. The full `audit-import.mjs` and `audit-board.mjs`
were not run.

## Verdict: compose-with-issues

The five tracks compose. On the dry run's combined tree plus u40 (its builder's own copy c1), every block of these tracks
passes, and so does every probe of their interplay. There are **three issues**:

1. **must-resolve: do not integrate the Codex U40 stand-in.** It adds `,this` to the destination name field's `onchange`.
   U10's "shared lists" block finds that field by its exact `onchange` text. The change sits OUTSIDE the C3 conflict hunk and
   merges cleanly, so the conflict resolution the dry run describes ("mechanically these compose") still leaves a failing
   suite:
   - `R-u10sl-codex`: exit 1, **2 of 27 checks fail**, both "no control".
   - The same block on dry-combined + u40 c1: 27/27.
   - u40 c1 keeps the `onchange` unchanged and composes cleanly: `F-u40v186-c1-r2` 106/106, mcount 1,502 of 1,502 once.
2. **should-resolve: in `flowSetEnt`, U10's locked-view guard must come before U40's duplicate-name refusal (C3's order).**
   With U40 first, a duplicate name typed in a locked view is told "give it a name of its own". The next name typed is then
   refused by the view (`P-destorder-u40first-r2`). Either order writes nothing.
3. **should-resolve (money, already on the base): a destination list breaks the rule that CYCREG now enforces for RCN / EEIC
   lists.**
   - The rule: a key names one entry, and no entry takes the name of the not-assigned row. A destination list that breaks it
     passes the door and survives ⬅ Import a full board.
   - Funds Flow then prints money twice: R1's $1,100 on two "Alpha Depot" rows against an OGC total of $1,400. An entry keyed
     `unassigned` prints "Not yet assigned" $1,400 twice and loses its own name.
   - U40's new notice then says, of two entries that share one key, "Each keeps its own requirements and money", which is
     false.
   - The base board `fce8a391` prints the same money twice, so this is class (a), not caused by the combination. It still
     breaks the money can't-fail in an exportable product, and it should go on the list as a new finding.

## Identities

| what | blob / commit |
|---|---|
| dry run's combined tree `dry-combined` | 6518730, board `a93abf27`, audit-recon `bd196d62`, audit-import `60f3631f`, mutate `4ed68b06` |
| base 7ee498a | board `fce8a391` (`../basetree`) |
| u40 c1 (builder's own, the README's final; copied to `src/u40c1/` at 2:55 PM ET) | board `278bf731`, audit-import `de59f3ce`, mutate text `c117c384` |
| u40 Codex stand-in (`src/u40codex/`; = the dry run's `d-u40`) | board `2419366b`, audit-import `f68e4a54`, mutate text `5a4d934a` |
| regtext fix round 2 c1 (`src/regtextfr2/`) | board `abcb8bac` (the dry run used round 1 `0949c3ed`) |
| cycreg fr2/c1 (`src/cycreg-fr2/`) | board `59cff8f3` (= the dry run's) |
| yearsel c3 (`src/yearsel-c3/`) | board `593593a4` (= the dry run's) |
| u10 c2 / c3 / c4 (`fwd/`, text merge only) | `cfc9e14f` / `1704bb11` / `f726ecfc` |
| **comp-c1** = dry-combined + u40 c1 (`gc` branch `comp-c1` 5cf1c5a, worktree `wt-c1/`) | board **`07ef754b`**, audit-import `ad3a68dd`, mutate `207ea069`, audit-recon `bd196d62` |
| **comp-codex** = dry-combined + u40 Codex (`comp-codex` 77dd4e4, `wt-codex/`) | board **`2640dc71`**, audit-import `cbd05715`, mutate `68927ce3` |
| `variants/c1-rt2.html` = comp-c1 + regtext fr2's one board hunk (its `rcnSet` is byte-identical to regtext c1 fr2) | `f107a80d` |
| `variants/c1-u40first.html` = comp-c1 with U10's guard moved after U40's refusal (the other order C3 allows) | `f513efab` |

How the compositions were made:
- `gc/` is `git clone --shared` of the dry run's `clone/`, with its push URL set to `NO-PUSH-registry`.
- comp-c1: a draft commit (base + u40 c1's 3 files) was cherry-picked onto `dry-combined`. The board merged with no
  conflict, and U10's guard ended up first. audit-import and mutate had one add/add hunk each, resolved by the dry run's
  unchanged `union.py`.
- comp-codex: the dry run's `d-u40` was cherry-picked onto `dry-combined`. C3 was resolved by `bin/resolve-c3.py`: U40's
  signature `(i, field, v, el)` plus U10's three comment lines and guard first. mutate went through `union.py`.
- The first build of `resolve-c3.py` dropped the guard line's newline. `mcount-codex` caught it: U10's two `flowSetEnt`
  anchors were missing. The script was fixed, and comp-codex was rebuilt and recounted as `mcount-codex-r2`: 1,497 of 1,497
  once. That was my error, not a product error. It also shows that U10's mutation anchors depend on how C3 is hand-resolved.

## What two or more of these tracks touch

Functions (`bin/touchmap.py`, text only; `logs/touchmap.txt`):

| name | tracks | what each does |
|---|---|---|
| `flowSetEnt` | u10, u40 | U10: `cycBlock('Changing a destination')` first. U40: refuses a typed name another destination has (Codex also changes the signature and the field's `onchange`) |
| `rcnBody` | cycreg, regtext | cycreg: "⚠ repeats row N" in Used by. regtext: the title field passes `this` (`rcnSet(i,"t",this.value,this)`) |
| `loadShared` (neighbourhood) | cycreg, u40 | cycreg: the sidecar goes through `inboundCheckOwn(…,'copy')`. u40: the opening-notice statement just before it (no shared line) |

Shared state, messages and doors:
- **MS.rcn**: cycreg's `rcnAdd`/`rcnDel`/`rcnBody`, regtext's `rcnSet` title rule, and U10's `cycCopy`/`cycReapply`, which
  rebuild the view's copy of it.
- **MS.flow.fys**: yearsel's reader, and U10's `cycCopy`, which rebuilds MS.flow in a view.
- **DESTDB.ents**: U10 refuses changes in a view. U40 keeps names apart (`destFold`), refuses typed duplicates and adds
  `destNotice`.
- **The status line**: cycreg's full-import report (`_impRep`), U40's opening notice (appended), U10's `cycRefuse`, and
  regtext fr2 clearing its own title refusal.
- **The door**: cycreg's `inShapeWhy`/`inboundCheck`/`inRefuse` and the `_inRcnNext` hand-off, beside U40's routes for
  destination lists (full import, `consTakeApply`, `applyStore`, `destPkgIn`).

Test blocks and entries:
- U10 "the shared lists" (audit-recon) drives the destination panel's name field by its exact `onchange` text.
- U40 (audit-import) uses `fullImportText`, which cycreg changed, as a control route.
- CYCREG and U36 (audit-recon) both build `rcnBody` boards.
- Mutation entries anchored in `flowSetEnt`: U10's two (`v200-u10-dest-change-in-view`, `-no-redraw`) and U40's.

## Interactions, with evidence

**I1 (must-resolve) U10 × U40 (Codex stand-in): the merged suite fails.**
- What: Codex rewrites the panel's name field to `onchange="flowSetEnt(i,"n",this.value,this)"`. U10's block
  (`fireDest('name',…)`) looks for exactly `flowSetEnt(i,"n",this.value)`.
- The `onchange` line is in `flowEntEditor`, outside the C3 hunk, so it merges silently.
- Evidence:
  - `R-u10sl-codex` (2:58:35 PM ET, exit 1, 62.7 s, `logs/R-u10sl-codex.log`): 2 failing of 27.
    - "PB27 viewed · Lockheed Martin renamed RENAMED DEST": got `["no control", "👁 Viewing PB27…", []]`.
    - CONTROL "+ add a destination, named Depot Z": got `"no control"`, with R's $630 left under Not yet assigned.
  - `R-u10sl-c1` (2:58:35 PM ET, exit 0, 66.2 s): 27/27.
  - The harness is the U10 block verbatim from audit-recon `bd196d62`, which is the same text in both compositions; the two
    harness files differ only in their header line.
- Resolution (u40): integrate the u40 builder's own c1, which keeps the `onchange` text and reaches the field by
  `querySelector`, not the Codex stand-in. If the Codex copy were kept, U10's selector would have to be widened, and that
  would be a change to U10's suite.

**I2 (should-resolve) U10 × U40: which refusal speaks in a locked view (C3's order).**
- `P-destorder-c1-r2` (3:11:29 PM ET, exit 0, 24.5 s), 7/7:
  - In PB27's view, "ALPHA DEPOT" typed over Bravo Yard is refused by the view ("🔒 Changing a destination is off while PB27
    is on screen…"). So is "Charlie Field".
  - The list, browser storage and R1's destination are unchanged.
  - On the working plan, the duplicate is refused by U40 and the unique name is kept (controls).
- `P-destorder-u40first-r2` (3:11:29 PM ET, exit 1, 23.0 s), the same probe on the other order:
  - In the view, U40 speaks first ("⚠ Destination name not changed. … give it a name of its own. Nothing was changed.").
  - The next, unique name is then refused by the view.
  - Nothing is written in either order: 1 failing check, the "which refusal speaks" check.
- Resolution (u40, and the lead if C3 is ever resolved by hand): keep U10's `cycBlock` as the first statement of
  `flowSetEnt`. u40 c1 and comp-c1 already have it there.

**I3 (should-resolve; money; class (a), on the base too) The key rule for RCN / EEIC lists against destination lists.**
- CYCREG refuses, at the door, an RCN / EEIC list that holds a key twice or holds `__none__`, the name of the not-assigned
  row. The destination list has the same shape of hazard and no such rule.
- `P-destkey-c1-r2` (3:24:46 PM ET, exit 1, 44.6 s) on comp-c1. Fixture: R1 asks USAF 900 / ANG 200 and R2 asks USAF 300;
  the flow is by destination.
  - Case K, a list holding `dA` twice ("Alpha Depot"), R1 to dA:
    - Funds Flow (from the workbook's bytes) gives `[["Alpha Depot",1100],["Alpha Depot",1100],["Not yet assigned",300],["OGC total",1400]]`.
    - Expected by hand: Alpha Depot 1,100 once, Not yet assigned 300, OGC total 1,400.
  - Case U, an entry keyed `unassigned` ("Depot U"), R1 on it:
    - Got `[["Not yet assigned",1400],["Not yet assigned",1400],["OGC total",1400]]`; Depot U's name is lost.
  - Both files pass `inboundCheck` (`""`), and ⬅ Import a full board keeps the keys as they are: the reopened board holds
    `["dA","dA"]`. Both double prints repeat after the reopen.
  - On comp-c1, the reopened board's opening line and `destNotice()` say "⚠ Destinations with matching names are kept
    apart: Alpha Depot [dA] · Alpha Depot [dA]. Each keeps its own requirements and money; rename one so they can be told
    apart." There is one key and one requirement, and the money is printed twice.
  - The CONTROL, distinct keys `dA`/`dB`, is right on every route.
- `P-destkey-base` (3:24:46 PM ET, exit 1, 46.1 s) on the base `fce8a391`: the same 4 failures and no notice, so the double
  print is class (a). U40's sentence is new.
- Resolution:
  - u40, or a new finding: give destination lists the CYCREG rule. A file handed over is refused when a key is repeated or
    when an entry takes `unassigned` / `destsplit` (`DEST_NONE` / `DEST_SPLIT`). The user's own board says it on full import.
    `flowAxisCats` / `exportFlow` count each key once.
  - At minimum, `destNotice` must not pair two entries that share a key.

**I4 (note; a dependency) cycreg relies on U10's whole-copy `cycReapply`.**
- Fixture: a list `[K1 "11111 / AAAAA Title one", K1 again "22222 / BBBBB"]` (the user's own board or a folder copy keeps
  it), R1 on K1, PB27 locked with it.
- `P-viewrcn-c1-r2` (3:30:34 PM ET, exit 0, 30.6 s), 24/24 on comp-c1. In the view, each of these is refused, and the view's
  list, R1's pointer, RCN-EEIC by Month from the view (USAF 900 / ANG 200 under "11111 / AAAAA  Title one", once) and the
  working plan afterwards are all unchanged:
  - ✕ on row 1, and ✕ on the repeated row;
  - an 81-character title, refused by U36 in its own words;
  - "Short title";
  - + Add;
  - ANG unticked.
- `P-viewrcn-c1rt2` (3:06:12 PM ET, exit 0, 40.8 s): the same 24/24 with regtext fix round 2.
- `P-viewrcn-cycregalone` (3:06:12 PM ET, exit 1, 38.8 s), the same probe on cycreg fr2 alone (no U10): 9 failing.
  - After the refused ✕ on row 1, the view's list is `[K1 "22222 / BBBBB"]`. RCN-EEIC by Month from the view files R1's
    **USAF 900 / ANG 200 under "22222 / BBBBB"**, while the line says "the change was not kept".
- Within one release the merge order does not matter, but U10's `cycCopy`/`cycReapply` must not be dropped or reverted while
  cycreg ships.

**I5 (note) U34 × U10: the saved year selection in a locked view.**
- `P-viewyears-c1` (3:12:13 PM ET, exit 0, 16.2 s), 4/4. The saved selection is `["2027"]` (text). In PB27's view, ALL YEARS
  is refused ("🔒 Saving is off…"), and the selection stays `["2027"]`, still read as unreadable (`{whole:false,n:1,what:'"2027"'}`).
- U34's panel notice is still shown with its instruction "Click ALL YEARS, a year's only, or a year … any of these replaces
  what cannot be read". In a view, that instruction is not true.
- `P-viewyears-yearselalone` (3:12:58 PM ET, exit 1, 17.5 s), yearsel c3 alone (no U10): the view showed ALL YEARS (`fys`
  null, notice gone) while saying "not kept". U10 fixes that in the combination.
- Optional resolution (yearsel): say "on the working plan", or leave the instruction out while `CYCVIEW` is set.

**I6 (note) regtext fix round 2 × U10.**
- regtext's clear of its own title refusal never fires in a view, because save() always says "🔒 …". So the view's refusal
  stands.
- Off the view, the clear works: after a kept "Short title", the status line reads `""` on `c1-rt2`. On round 1 it still
  says "⚠ RCN / EEIC title not changed…" (`P-viewrcn-c1-r2` SEE line).
- fr2's one board hunk composes with every track here.

**I7 (note) cycreg's door and report × U40's notice on one opening line.**
- `P-importsay-c1` (3:12:12 PM ET, exit 0, 22.3 s), 7/7. The file is the user's own board: K1 twice in the RCN list, and
  "Alpha Depot" [dA] / "ALPHA DEPOT" [dB].
  - Handed over, it is refused, with CYCREG's alert word for word.
  - By ⬅ Import a full board it is taken. The question says the RCN list; the destination list is only counted ("— 10").
  - Reopened, the line is the import's report (with CYCREG's RCN sentence) followed by U40's "kept apart" sentence.
  - R1 → Alpha Depot and R2 → ALPHA DEPOT; RCN-EEIC counts K1 once (USAF 1,200, ANG 200).
- `P-importsay-drycombined` (3:12:58 PM ET, exit 1, 28.2 s): identical, except that U40's sentence is missing (expected
  without U40).

**I8 (note) The 80-character title is a typing rule only.**
- `P-doortitle-c1` (3:13:35 PM ET, exit 0, 14.4 s), 7/7:
  - The door refuses an RCN key held twice, `__none__` and the number 1, in CYCREG's words.
  - It passes a 100-character title.
  - On the board, that title plus one character is refused ("101 characters; it can be at most 80"), and `codeIssues` does
    not list the long title.
- Already recorded by regtext as U38 (open, by item 91's design). No money or data loss.

**I9 (note, by reading) Ask, then refuse.**
- In a view, `rcnDel` asks its question first ("Remove RCN … No assignment is changed."), and only then does save() refuse.
- U10 refuses destination edits before anything is asked. The RCN editors (`rcnAdd`/`rcnDel`/`rcnSet`/`rcnToggleSvc`) could
  take an up-front `cycBlock` the same way (U10).

**I10 (note) The `_inRcnNext` hand-off is fragile.**
- `fullImportText` sets `_inRcnNext='board'` on one line and calls `inboundCheck` on the next. A guard inserted between them
  would let the next file handed over in through the lenient 'board' rule.
- No copy does that today. U10's fix round 2 board (c4, `f726ecfc`) merges onto comp-c1 by `git merge-file` with **0
  conflicts**, and the two lines stay adjacent (merged lines 9829–9830).
- Suggestion for cycreg: pass `own` explicitly, or reset it in a `finally`.

**I11 (note) Records.**
- regtext's drafts carry U40 as unresolved:
  - `NEXT-VERSION-entry.md` (a paragraph "stands only if that fix does not land");
  - `UNRESOLVED-line.md`;
  - `MATRIX-limits.md` ("Not fixed by this track").
- When u40 lands, the lead drops those lines. regtext's U39 (two RCN entries with the same text print identical rows) is
  untouched by CYCREG, which works by key.

## Checks on the c1 composition (all blocks of these tracks, plus U40, together)

| run | blocks | result |
|---|---|---|
| `R-u10sl-c1` | U10 (the shared lists) | 27/27 |
| `F-u40v186-c1-r2` | v1.86 destination section (3) + U40 | 106/106 |
| `R-cyc36-c1` | CYCREG + U36 | 157/157, ALL CHECKS PASSED |
| `R-v200c3-c1-r2` | U34 | 39/39 (the first run, `R-v200c3-c1`, was killed with exit 137 at 119.5 s under load after 23 passing checks; re-run once) |
| `R-v200b3-c1` | U9, U9 every export, U10, U10 beside the codes, U10 the shared lists | 152/152 |
| `mcount-c1` | text only | 1,502 entries, 1,502 once (dry-combined 1,487 + U40's 15) |
| `syntax-audit-import-c1` / `-codex` | `node --check` of the composed audit-import | exit 0 / 0 |

These harnesses are verbatim:
- `R-u10sl` was built by `../bin/mkfocused-extra.py` from `wt-c1`'s audit-recon `bd196d62`.
- `R-cyc36` by `../bin/mkfocused.py`.
- `R-v200c3` and `R-v200b3` are byte copies of the dry run's own harnesses, built from the same suite text.
- `F-u40v186` was built by `../bin/mkfocused-multi.py` from comp-c1's audit-import, with the same ranges as the u40 builder's
  `rebuild-c1.sh`.

## Every run

Each run was bounded with `setsid -w timeout -k 10 600` (`bin/run.sh`). Its PID is in `../pids.txt` with the label prefixed
`registry:`, and its row is in `runs.tsv`. The AUDIT_IMPORT_RUNNING lock was checked before each node run and was never
present. No more than two of my node processes ran at once. At 3:34 PM ET none of the 31 recorded PIDs was alive (`kill -0`).
I killed nothing.

| label | start (ET) | exit | wall s | log | what |
|---|---|---|---|---|---|
| mcount-c1 | 2:57:04 PM | 0 | 12.5 | logs/mcount-c1.log | 1,502 / 1,502 once |
| mcount-codex | 2:57:17 PM | 0 | 15.1 | logs/mcount-codex.log | 2 missing: MY C3 resolution lost a newline (fixed) |
| mcount-codex-r2 | 2:57:54 PM | 0 | 12.6 | logs/mcount-codex-r2.log | 1,497 / 1,497 once |
| R-u10sl-codex | 2:58:35 PM | 1 | 62.7 | logs/R-u10sl-codex.log | **I1: 2 of 27 fail** |
| R-u10sl-c1 | 2:58:35 PM | 0 | 66.2 | logs/R-u10sl-c1.log | 27/27 |
| F-u40v186-c1 | 3:00:37 PM | 1 | 8.1 | logs/F-u40v186-c1.log | my harness: no node_modules link beside it (ERR_MODULE_NOT_FOUND jsdom) |
| F-u40v186-c1-r2 | 3:03:08 PM | 0 | 143.1 | logs/F-u40v186-c1-r2.log | 106/106 |
| P-viewrcn-c1 | 3:05:22 PM | 1 | 31.4 | logs/P-viewrcn-c1.log | 23/24; the 1 is MY probe (a 32-character slice of a 31-character literal); re-run below |
| P-viewrcn-cycregalone | 3:06:12 PM | 1 | 38.8 | logs/P-viewrcn-cycregalone.log | I4 contrast: 9 failing without U10 |
| P-viewrcn-c1rt2 | 3:06:12 PM | 0 | 40.8 | logs/P-viewrcn-c1rt2.log | 24/24 (regtext fr2) |
| P-destorder-u40first | 3:07:37 PM | 1 | 142.6 | logs/P-destorder-u40first.log | MY fixture lacked BASE_ITEMS (R1 vanished in the view); superseded by -r2 |
| P-destorder-c1 | 3:07:37 PM | 1 | 143.4 | logs/P-destorder-c1.log | same fixture error; superseded |
| dbg-dest-c1 | 3:10:30 PM | 0 | 16.1 | logs/dbg-dest-c1.log | debug of that fixture: the pointer was intact (`probes/dbg/dest-dbg.mjs`) |
| dbg-dest-c1-r2 | 3:11:01 PM | 0 | 17.3 | logs/dbg-dest-c1-r2.log | showed `itemById('R1')` undefined in the view: BASE_ITEMS not set |
| P-destorder-u40first-r2 | 3:11:29 PM | 1 | 23.0 | logs/P-destorder-u40first-r2.log | I2: U40 speaks first in the view (1 failing = that check) |
| P-destorder-c1-r2 | 3:11:29 PM | 0 | 24.5 | logs/P-destorder-c1-r2.log | I2: 7/7 |
| P-viewyears-c1 | 3:12:13 PM | 0 | 16.2 | logs/P-viewyears-c1.log | I5: 4/4 |
| P-importsay-c1 | 3:12:12 PM | 0 | 22.3 | logs/P-importsay-c1.log | I7: 7/7 |
| P-viewyears-yearselalone | 3:12:58 PM | 1 | 17.5 | logs/P-viewyears-yearselalone.log | I5 contrast |
| P-importsay-drycombined | 3:12:58 PM | 1 | 28.2 | logs/P-importsay-drycombined.log | I7 contrast (no U40 sentence) |
| P-doortitle-c1 | 3:13:35 PM | 0 | 14.4 | logs/P-doortitle-c1.log | I8: 7/7 |
| R-v200c3-c1 | 3:14:18 PM | 137 | 119.5 | logs/R-v200c3-c1.log | killed under load (23 checks, 0 failing); re-run once |
| R-cyc36-c1 | 3:14:18 PM | 0 | 418.3 | logs/R-cyc36-c1.log | 157/157 |
| P-destkey-c1 | 3:21:32 PM | 1 | 47.7 | logs/P-destkey-c1.log | I3: 4 failing (first version, without the opening-line capture) |
| R-v200c3-c1-r2 | 3:21:32 PM | 0 | 192.2 | logs/R-v200c3-c1-r2.log | 39/39 |
| P-destkey-c1-r2 | 3:24:46 PM | 1 | 44.6 | logs/P-destkey-c1-r2.log | **I3 on comp-c1**: 4 failing, U40's false sentence captured |
| P-destkey-base | 3:24:46 PM | 1 | 46.1 | logs/P-destkey-base.log | **I3 on the base**: the same 4 failing, so class (a) |
| R-v200b3-c1 | 3:27:06 PM | 0 | 182.4 | logs/R-v200b3-c1.log | 152/152 |
| syntax-audit-import-c1 | 3:30:19 PM | 0 | 0.3 | logs/syntax-audit-import-c1.log | parses |
| syntax-audit-import-codex | 3:30:19 PM | 0 | 0.5 | logs/syntax-audit-import-codex.log | parses |
| P-viewrcn-c1-r2 | 3:30:34 PM | 0 | 30.6 | logs/P-viewrcn-c1-r2.log | I4: 24/24 |

Also run, not through `run.sh` because they are text-only Python with no node: `bin/touchmap.py` (`logs/touchmap.txt`), and
`git merge-file` of u10 c4 onto comp-c1 at 3:26 PM ET (0 conflicts).

`probes/ix.mjs` was edited between runs, so the probe blob is printed in each log's `IDS` line:
- `b5d2bfc4` (first `P-viewrcn-c1`).
- `8afb5625`: the 31-character slice fixed; used by viewrcn c1rt2 / cycregalone and the first destorder runs.
- `94ca4646`: BASE_ITEMS added to the destorder and viewyears fixtures; importsay gained its SEE line.
- `01ad81bd` (final): the `destkey` section added, and `see` lines in it.

No expected literal was changed to make a check pass. The two fixes are the slice length (my probe) and the fixture baseline.

## Merge order (for these tracks)

1. u10, then cycreg / yearsel / regtext, as in the dry run. Within one release the order does not matter, but cycreg (I4)
   and yearsel (I5) rely on U10's whole-copy `cycReapply`, so U10 must ship with them.
2. regtext: use fix round 2. Its one board hunk composes (`c1-rt2`).
3. u40: the builder's **c1**, after u10 (applies with no board conflict, U10's guard first). Not the Codex stand-in (I1).
4. u10 fix round 2 (c4), when its reviews are done: it merges onto comp-c1 by text with 0 conflicts. Re-run `R-u10sl` and the
   U10 blocks after it lands.

## Not done, and limits

- Not run on comp-c1: the U40 Codex block (Codex is not recommended), audit-recon's 53 pre-v2.00 scenarios (`R-old`), the
  other tracks' audit-import blocks (U19/U20/U30/U3/U4), and audit-other / audit / boot-same.
  - u40 c1 changes only `destFold`, `destJoin`, `flowSetEnt`, `destNotice`, `flowEntEditor` and an opening statement.
  - The u40 builder's own suite runs on c1 are still pending in its README.
- No mutants were made or run. mcount checks anchors only.
- U37 and U41/U42 (stand-ins in the combined tree) and the in-flux copies (cycreg fix round 3, u10 c3/c4 runtime, adopt)
  were not composed. u10 c4 was merged by text only.
- I3 was probed on the full-import route and in memory. Whether ⬅ Import one appropriation (`consTakeApply`, through
  `destFold`) or the shared folder (`applyStore`) also keep a repeated destination key was not run. By reading, `destFold`
  maps a repeated incoming key to one entry. The `destsplit` key was not run (by reading, it is the same as `unassigned`).

## Files

- `README.md` (this file) and `runs.tsv`.
- `logs/`: every run's log, plus `src-blobs.txt`, `fwd-blobs.txt` and `touchmap.txt`. `out/`: the SUITE_CHECKS rows.
- `bin/`: `run.sh` (`3b301dce`), `resolve-c3.py` (`e893171d`), `mkvariants.py` (`6bb5c05a`) and `touchmap.py` (`5dd3e8dd`).
- `probes/ix.mjs` (`01ad81bd`) and `probes/dbg/dest-dbg.mjs` (`2db5051c`).
- `h/c1/`, `h/codex/`: the focused harnesses, each beside a link to its tree's `boot.mjs` and `node_modules`.
- `gc/` (clone; branches `comp-c1`, `comp-codex`, `d40c1`), `wt-c1/`, `wt-codex/` (worktrees), `src/` (snapshots of the
  copies used), `variants/`, and `fwd/` (u10 c2/c3/c4 boards and the text merge `merged-u10c4.out.html`).
