# ORBIT v2.00 integration dry run (L9) — do the fix tracks' current drafts apply together and pass together?

Written 13 Oct 2026, finished 2:45 PM ET (the work ran from 1:27 PM ET). Nothing here is committed or pushed. `/home/user/orbit-board`,
`/home/user/orbit-ui`, `rec/L6/*` (the tracks' directories) and `rec/L7/merge` were only read. Every path below is under
`rec/L9/dryrun/` unless it starts with `<L6>` (= `rec/L6`) or `<SP>` (= the scratchpad).

## Answer in five lines

1. **10 of 13 tracks apply together** in the planned order (u20u30, u19, hold, u9, u10, cycreg, yearsel, regtext, u37, u41u42).
   **3 stop on a real conflict: adopt, u18, u40.** Each of the three applies cleanly **alone on the base**, so every conflict
   comes from the combination.
2. The conflicts are small and all in the board: **`driveClashSay`** (one sentence of the folder-clash message) is edited by
   **U30 (u20u30), U29 (adopt) and U18 (u18)** on the same or adjacent lines; **`flowSetEnt`**'s first line is edited by **U10
   (u10)** and **U40 (u40 stand-in)**. Every other overlap met (in the chain, and in a pairwise merge of each stopped track
   against every other track) is an add/add hunk (new test blocks / new mutation entries at the same place) that the script
   resolves as a union.
3. **On the combined tree (`dry-combined` = 6518730, board a93abf27) nothing failed**: npm run check, audit-other, audit,
   boot-same, audit-ppt, audit-hostile, audit-inject, legacy-fsrc, all 7 focused audit-import harnesses (every v2.00 block in
   the combined suite, including U3, U4, U19, U20, U30, plus the v1.86 destination blocks), and every block of audit-recon.
   So there is **no class (a), (b) or (c) failure**: the base also passed everything it was given.
4. **audit-recon as one whole run did not finish**: it hit the 600 s cap twice (load 33–45 on 4 CPUs; the base's whole run
   took 501.7 s). Every one of its 68 scenarios was then run, verbatim, in split harnesses, and each passed in a run whose
   verdict was ALL CHECKS PASSED (two harness runs of mine failed on missing helpers in the harness, not the board; below).
5. mcount (text only): combined **1,487 of 1,487** entries match exactly once (base 1,328 + 159 from the 10 applied tracks; no
   id lost, none doubled, none missing, multiple or unparsed).

## What was used (identities)

- Base: `7ee498a46507972f803cd48ce9f27d5d668acb63` (board `fce8a391`, audit-import `4aba2506`, audit-recon `529e36f7`,
  audit-board `a7c575e5`, audit-other `d89396b0`, mutate.mjs `cbc6defc`, package.json `7cf8186f`, NEXT-VERSION.md `65265c13`).
  `<L6>/base` was checked equal to the base commit, file by file (53 files).
- `clone/` = `git clone --shared /home/user/orbit-board` (HEAD then 73cd226); its push URL is set to `NO-PUSH-dryrun`.
- `apply2-dry.py` = `<SP>/rec/L7/apply2.py` with ONLY the clone path `M` changed (diff: one line). `union.py` is an unchanged copy
  of `<SP>/rec/L7/union.py` placed beside it, because apply2.py looks for `union.py` in its own directory; the first u19
  attempt (1:30:42 PM) stopped for that reason alone (`logs/apply-u19-attempt1-no-union.log`: apply2 prints only
  union.py's stdout, so the log shows an empty line, then "STOP"; union.py was not beside the copy); it was re-run at 1:31:19 PM after the copy and applied cleanly. The originals were not edited.
- The Codex stand-ins (`<L6>/<track>/codex/applied`) hold only 4 files (board, audit-import, audit-recon, mutate.mjs.txt), and
  apply2.py refuses such a copy (`MISSING NEXT-VERSION.md`, exit 3 — shown by `probe-codex-partial-copy`). So for u37, u40 and
  u41u42 I passed a FULL copy built under `copies/<track>/applied-full` = `<L6>/base` (no node_modules) + the 4 Codex files, by
  absolute path (apply2 joins an absolute copy path unchanged). Blobs below prove they equal the Codex copies.

Every copy's blobs were taken with `git hash-object` before applying (`logs/ident-1.txt`, 1:29 PM), again at 1:37 PM
(`ident-2`), 2:07 PM (`ident-3`) and 2:42 PM (`ident-4`); each draft commit's blobs are in `logs/draft-chain-blobs.txt`.

| track | copies used | board / suite / mutate.mjs blobs used (all = the latest recorded result) | recorded in | in flux? |
|---|---|---|---|---|
| u20u30 | c1 → c2 | c1 `83b87782` / import `776c6680` / `6b4c83d6`; c2 `c42be8e7` / import `e0d4186b` / `54c7d928` | wfstate build_u20u30 | no (c1f/c2f being written beside; c1, c2 unchanged through 2:42 PM) |
| u19 | fr/c1 | `f6ac4b9d` / import `cfaeac17` / `9028eaa8` | wfstate fix_u19_r1 | no (fix round 2 writes `fr2/`; fr/c1 unchanged through 2:42 PM) |
| adopt | c1 → c2 → c3 | c1 `00c2ac15`/`b111bfe1`/`d8f3956b`; c2 `d020543e`/`16ae9949`/`22df04f5`; c3 `c0d14fcd`/`97bc28bf`/`f0c7dbf4` | wfstate build_adopt | **YES**: the adopt fix round rewrote c1–c3 IN PLACE at 1:44:55–1:44:59 PM ET, after my applies (1:31:26 and 1:33:57 PM). Used as found = the build copies; they are kept by the builder as `<L6>/adopt/superseded-r3/c1..c3` (blobs checked equal). As of 2:42 PM: c1 import `195381b5`; c2 board `0bbfedb6`; c3 board `d1cdcdf5` |
| u18 | c1 | `e3986f30` / import `329cf6e8` / `fc364266` | wfstate build_u18 | no |
| hold | c1 → c2 | c1 `82a2f1cc`/`22cdd78e`/`c3cab761`; c2 `4b755576`/`f25c69f7`/`27f0fdb6` | wfstate build_hold | no |
| u9 | c1 | `46e522a8` / recon `755647cc` / `8fd34e94` | wfstate fix_u9_r2 (and the task) | no |
| u10 | c1r → c2 | c1r `4a8b0be3`/recon `746dac83`/`c6c1ea47`; c2 `cfc9e14f`/`2c4c466a`/`3a408399` | wfstate fix_u10_r1 | no (fix round 2 writes new `c3`, `c4`; c1r, c2 unchanged) |
| cycreg | fr2/c1 | `59cff8f3` / recon `03b7fda9` / `755c2989` | README Fix round 2 (and the task) | no |
| yearsel | c1 → c2 → c3 | c1 `a67635bb`/`98758fe5`/`bb57fce8`; c2 `593593a4`/`5eac80ea`/`f4e0739f`; c3 `593593a4`/`2d34269d`/`ba8b55ad` | wfstate fix_yearsel_r1 + README Fix round 2 | no |
| regtext | c1 | `0949c3ed` / recon `08c1275e` / `41c64701` | wfstate fix_regtext_r1 | **YES**: fix round 2 rewrote c1 IN PLACE from 1:35:20 PM ET (board `abcb8bac`, recon `b2a8b693`, mutate `7843cae0` at 2:42 PM), after my apply at 1:33:17 PM. Used as found = round 1 (kept by the builder as `<L6>/regtext/superseded/c1-fr1`, blobs equal) |
| u37 | codex/applied (stand-in) | `aa8f441f` / recon `7be8b6e5` / `db7a7a28` | lead's note in `rec/L7/new-tracks.txt` | no (written 1:16:50 PM; unchanged). The u37 builder's own c1 is not used |
| u40 | codex/applied (stand-in) | `2419366b` / import `f68e4a54` / `5a4d934a` | same | no |
| u41u42 | codex/applied (stand-in) | `5053534a` / recon `2a5dff7f` / `d677e436` | same | no |

## Per-track result (planned order; each onto the previous good `a-<track>`)

| # | track | onto | result | a-ref | board after |
|---|---|---|---|---|---|
| 1 | u20u30 | base 7ee498a | applied, clean (2 commits) | a-u20u30 e31971a | c42be8e7 |
| 2 | u19 | a-u20u30 | applied; add/add unions in audit-import (U19 block after U20/U30) and mutate | a-u19 d3f3b72 | dcfd1b4f |
| 3 | adopt | a-u19 | **STOPPED** at commit 2 (adopt c2, U29): real conflict in the board (driveClashSay). Commit 1 (c1) had applied with add/add unions; that partial branch is kept as `stopped-a-adopt-chain` (04026d9) — NOT a good ref | — | — |
| 4 | u18 | a-u19 | **STOPPED**: real conflict in the board (driveClashSay) + one add/add comment hunk | — | — |
| 5 | hold | a-u19 | applied; add/add union in mutate | a-hold 8a6b09c | 1f98c3c0 |
| 6 | u9 | a-hold | applied; add/add union in mutate | a-u9 1420fcb | c88afec5 |
| 7 | u10 | a-u9 | applied; add/add unions in audit-recon, mutate | a-u10 cbf94f0 | 75ce8dc6 |
| 8 | cycreg | a-u10 | applied; add/add unions in audit-recon, mutate | a-cycreg fab6d23 | dca29d9e |
| 9 | yearsel | a-cycreg | applied (3 commits); add/add unions in audit-recon, mutate | a-yearsel bf23a92 | 9601cc02 |
| 10 | regtext | a-yearsel | applied; add/add unions in audit-recon, mutate | a-regtext 4541046 | 39d29903 |
| 11 | u37 (stand-in) | a-regtext | applied; add/add union in mutate | a-u37 82d374f | 454ef367 |
| 12 | u40 (stand-in) | a-u37 | **STOPPED**: real conflict in the board (flowSetEnt) + add/add in mutate | — | — |
| 13 | u41u42 (stand-in) | a-u37 | applied; add/add union in mutate | a-u41u42 6518730 | **a93abf27** |

`dry-combined` = a-u41u42 = **6518730** (tree 317e1a6d): board `a93abf27`, audit-import `60f3631f`, audit-recon `bd196d62`,
audit-board `a7c575e5` (= base), audit-other `d89396b0` (= base), mutate.mjs `4ed68b06`, package.json and NEXT-VERSION.md = base.
vs base (`git diff --numstat`): board +371 −67, audit-import +1,368 −5 (the 5 are U19's own edits to two U2 checks, shipped by u19), audit-recon +1,739 −0, mutate.mjs +509 −0.
Checked by text (`bin/contained.py`, `logs/contained.txt`): every added hunk of every applied track's draft is found whole in
the combined files (the one "deleted block still present" it flags, U10's in `cycView`, is a moved block: it occurs once in
U10's own draft too). No data was added here: the combined board is only the merge of the tracks' board drafts, and no run wrote into `tree/`
(`git status`: only the untracked shim and node_modules link).

Skipped tracks alone on the base (to show the conflicts come from the combination): `alone-adopt` (7837883, board `c0d14fcd`
= adopt c3), `alone-u18` (0cb0e3c, board `e3986f30` = u18 c1), `alone-u40` (9beb016, board `2419366b` = the stand-in) all
apply with no conflict at all.

## Every conflicting hunk

Files with the conflict markers (diff3 style) are kept: `conflicts/adopt-chain/`, `conflicts/u18-chain/`, `conflicts/u40-chain/`,
and every pair in `conflicts/pairs/` (summary `conflicts/pairs/summary.txt`, board hunks `conflicts/pairs/board-hunks.txt`).

**C1 — adopt onto a-u19 (stops at draft adopt c2, U29).** `prioritization-board-grid.html`, `driveClashSay` (combined line ~27051).
- base: `+' to the shared folder '+esc(liveAge(theirs))+', after the copy you are working from. '`
- ours (U30, u20u30 c2): `+' to the shared folder '+esc(liveAge(theirs)) +(driveBaseOf(ap)? ', after the copy you are working from. ' : ', and this browser has no record of which copy in the folder, if any, the work on screen came from. ')`
- theirs (U29, adopt c2): `// v2.00 (U29): "after" only when it is. …` + `+' to the shared folder '+esc(liveAge(theirs))+(theirs>driveBaseOf(ap)? ', after the copy you are working from. ' : ', and that is not the copy you are working from. ')`
- A merge of the whole adopt chain (base → c3) against a-u19 (`git merge-tree`, `conflicts/adopt-chain/squash-hunks.txt`) has
  this ONE real hunk; audit-import and mutate are add/add only. Both sides choose the words after "saved … to the shared folder
  <age>" by a different test (recorded base or not, vs theirs newer than the base); a person has to decide the combined rule.
- Note (in flux): the adopt fix round's rewritten c2/c3 (1:44 PM) still change this line AND now also the next line
  (`+(refused? '<b>Nothing was written.</b> ' : theirs>driv…`), which U18 also changes (C2 below).

**C2 — u18 onto a-u19.** `prioritization-board-grid.html`, two hunks:
- hunk 1 (add/add, comment just above `driveClashSay`): ours = U30's 3-line comment "WITH NOTHING RECORDED THERE IS NO TELLING…";
  theirs = U18's 3-line comment "`refused` 'late' -- their copy landed while a save was under way…". Union-resolvable.
- hunk 2 (REAL, `driveClashSay`): base = the "after" line + `+(refused? '<b>Nothing was written.</b> ' : 'What is on screen does not have their changes. ')`;
  ours (U30) = the driveBaseOf conditional (as in C1) + the unchanged `refused?` line; theirs (U18) = the unchanged "after" line +
  `+(refused==='late'? 'Their copy landed while your save was under way, and <b>your save stopped before writing over it</b>. ' : refused? '<b>Nothing was written.</b> ' : 'What is on screen does not have their changes. ')`.
  The two edits are on ADJACENT lines (git's conflict), so they look composable line by line; the combined sentence still needs
  reading by the U18/U30 owners ("…after the copy you are working from. Their copy landed while your save was under way…").
- also add/add only: audit-import (U18 block after U20/U30/U19) and mutate.

**C3 — u40 (stand-in) onto a-u37.** `prioritization-board-grid.html`, `flowSetEnt` (combined line ~15268):
- base: `function flowSetEnt(i, field, v){`
- ours (U10, u10 c2): `function flowSetEnt(i, field, v){` + 3 comment lines + `if(cycBlock('Changing a destination')){ render(); return; }`
- theirs (U40, Codex A3): `function flowSetEnt(i, field, v, el){`
- mutate: add/add only. Mechanically these compose (U40's signature with U10's guard first), but the refusal ORDER (locked-view
  refusal before the duplicate-name refusal) is exactly what the U40 brief asks the u40 builder to decide.

Pairwise (each skipped track against every other track's whole draft, `git merge-tree`, `conflicts/pairs/summary.txt`): the
ONLY real hunks are adopt×u20u30 (C1), adopt×u18 (driveClashSay: U29's "after" line vs U18's `refused` line, adjacent),
u18×u20u30 (C2) and u40×u10 (C3). Everything else is add/add (mutate.mjs entries before the R3 line, audit-import blocks after
U13) or clean. One add/add pair matters for the real run: **u18×hold** in `_driveStorePushRun` — two declarations
(`const was={ts:MS.ts, by:MS.by};` U18 / `const ts0=MS.ts, by0=MS.by;` U4) and two checks just before `driveWrite` (U18's
re-read of the folder copy, which awaits, and U4's synchronous hold check). union.py would keep both silently, in apply order;
in the planned order (u18 before hold) U18's await comes first and U4's check stays "after the last wait before the write" as
its comment promises; in the opposite order it would not.

## The runs on the combined tree and on the base

Trees: `tree/` = `git worktree add` of `dry-combined` (left in place, as asked); `basetree/` = detached worktree of the base.
Each has an untracked `runtime-encoding-shim.mjs` (copied from `<L6>/base`) and a `node_modules` link to orbit-board's.
Every node run went through `bin/run.sh` (`setsid -w timeout -k 10 600`, PID appended to `pids.txt`, one line per run in
`runs.tsv`, the AUDIT_IMPORT_RUNNING lock checked first — it was never present), from two lanes at most (`bin/lane.sh`,
lane files `bin/lane*.txt`), so never more than two of my node processes at once; `npm run check` ran with nothing else of
mine running. BOARD and MUT_FIRST_FAIL were unset for every suite.

"Checks recorded" counts the rows the suite's recording helper wrote to SUITE_CHECKS (`out/<label>.checks.jsonl`, tallied by `bin/tally.py`); audit-recon's own `chk` does not record, so its counts are partial — its verdict is the suite's own ALL CHECKS PASSED, which includes the scenario-ran guard.

Focused audit-import harnesses (`h/<tree>/tools/export-audit/F-*.mjs`, run by `bin/runner.mjs` = an unchanged copy of
`<SP>/rec/L3/u14/runner.mjs`, from a folder holding a link to that tree's own `boot.mjs`), built VERBATIM from each tree's own
audit-import.mjs by `bin/mkfocused-u2.py` (unchanged copy of `<SP>/rec/L2/u2impl/mkfocused-u2.py`) and, for the v1.86
destination section (from "Brad, 25 Sep 2026: a destination added on one appropriation" up to, not including, "v1.86 —
MANDATORY IN EVERY CONSOLIDATED SPEND PLAN"), `bin/mkfocused-multi.py` (unchanged copy of the u40 builder's
`<L6>/u40/bin/mkfocused-u40.py`, which is mkfocused-u2.py with several ranges). Builder output: `logs/mkharness-*.txt`.

| harness | blocks | combined: checks recorded / failing | base |
|---|---|---|---|
| F-r3 | v2.00 R3, R3 message | 12 / 0, ALL PASSED | 12 / 0, ALL PASSED |
| F-r4u3u4 (combined) / F-r4 (base) | R4 (+ U3, U4 from hold) | 85 / 0, ALL PASSED | R4 only: 20 / 0, ALL PASSED |
| F-r5u2u13 | R5, U2, U2 put back waits, U13 (U19 edits two U2 checks, so this harness differs by 2 lines between the trees) | 135 / 0, ALL PASSED | 135 / 0, ALL PASSED |
| F-u20 | U20 (u20u30) | 78 / 0, ALL PASSED (the track's own count on c2: 78/78) | block not in the base suite |
| F-u30 | U30 (u20u30) | 48 / 0, ALL PASSED (track: 48/48) | not in base |
| F-u19 | U19 (u19) | 104 / 0, ALL PASSED | not in base |
| F-v186dest | the v1.86 destination section (3 scenarios) | 48 / 0, ALL PASSED | 48 / 0, ALL PASSED |

The U24/U29/U31 (adopt), U18 (u18) and U40 (u40) blocks are NOT in the combined suite, because those tracks did not apply;
they were not run in combination (see "What I did not do").

audit-recon on the combined tree: the whole suite (`C-audit-recon`, re-run once as `C-audit-recon-r2`) stopped at the 600 s
cap both times — machine load 33–45 on 4 CPUs; the base's whole suite took 501.7 s and passed (`B-audit-recon`). Not a
defect. To still run every block, I split the combined suite VERBATIM into harnesses (all in `h/tree/tools/export-audit/`):

| harness (builder) | what it holds | result |
|---|---|---|
| R-old (`bin/mkrecon-old.py`) | the whole suite minus its contiguous v2.00 blocks (lines 4290–6864): every pre-v2.00 check, the preamble and the scenario-ran guard — 53 named scenarios | `C-R-old` ALL CHECKS PASSED (366.5 s) |
| R-v200a (`bin/mkfocused.py` = unchanged copy of `<SP>/rec/L3/u14/mkfocused.py`) | v2.00 R1, R1 decisions, U1, U14 (already in the base) | `C-R-v200a` ALL CHECKS PASSED (179 recorded checks: 19+19+78+63) |
| R-v200b3 (`bin/mkfocused-extra.py`: mkfocused.py plus named top-level helpers copied verbatim — headerRow, colOf, w6Hdrs, w6Col, w5Dol, v198K, v198Lab, v198NONE, v198Board, v198Sec — as the U9 and U10 builders' own variants add them) | U9, U9 every export, U10, U10 beside the codes, U10 the shared lists | `C-R-v200b3` ALL CHECKS PASSED (152 recorded checks) |
| R-v200c (mkfocused.py) | CYCREG, U34, U36 | CYCREG and U36 passed; U34 "threw: w7Ok is not defined" (my harness lacked a helper; not the board) |
| R-v200c3 (mkfocused-extra.py with w7Pkg, w7Ok) | U34 | `C-R-v200c3` ALL CHECKS PASSED (39 recorded checks; the yearsel track's count is 39) |
| R-v200d (mkfocused.py) | U37, U41, U42 | `C-R-v200d` ALL CHECKS PASSED ("U37 CHECKS 53") |

Together: 53 + 4 + 5 + 2 (CYCREG, U36) + 1 (U34) + 3 = all 68 named scenarios of the combined suite, each in a run that
passed, guard included. Harness runs that do not count: `C-R-v200` (all 15 v2.00 blocks in one harness) was KILLED by the
kernel's OOM killer at 357 s (memory cgroup shared by every agent's processes; dmesg: "Memory cgroup out of memory: Killed
process … (node) … anon-rss:1465132kB"); its single re-run `C-R-v200-r2` hit the 600 s cap; and `C-R-v200b` (U9/U10 via plain
mkfocused.py) failed 6 checks, all "the block threw: w6Hdrs / v198Board is not defined" plus the guard's "never ran" for the
same scenarios — missing helpers in MY harness, fixed by R-v200b3. None of these is a product failure.

Other suites on the combined tree, whole: npm run check, audit-other, audit, boot-same, audit-ppt, audit-hostile,
audit-inject, legacy-fsrc — all pass. Base, whole: npm run check, audit-recon, audit-other, audit, boot-same — all pass.
`npm run check` reads the same on both apart from size lines (combined 31,976 lines / 3.60 MB, main script 29,954 lines,
133 sorts; base 31,672 / 3.57 MB, 29,650, 131). `node --check` parses the combined audit-import.mjs and audit-recon.mjs.
mutate.mjs was never imported, executed or run: mcount and every mutate check here read it as TEXT (`bin/` scripts and
`<SP>/rec/bin/mcount.py` with `python3 -I`); a text check of the MUTATIONS array finds no entry start missing its comma after
the unions (the one flagged spot is a trailing comment after a comma, the same in the base).

### Failures and their class

| run | failing | class |
|---|---|---|
| (none) | No completed run on the combined tree failed a product check. | — |
| C-audit-recon, C-audit-recon-r2, C-R-v200-r2 | incomplete: 600 s cap under load | environment (not a defect; every block covered by passing split harnesses) |
| C-R-v200 | incomplete: OOM-killed (shared memory cgroup) | environment |
| C-R-v200b (6), C-R-v200c (2) | "block threw: … is not defined" / "never ran" | my harness construction (missing helpers); re-built with the helpers, passed |

So: (a) present on the base too — none; (b) a track's own block failing only in combination — none (U3, U4, U19, U20, U30,
U9, U10, CYCREG, U34, U36, U37, U41, U42 all pass on the combined board); (c) an older check broken by the combination — none
(R3, R4, R5, U2, U13, the v1.86 destination blocks, all pre-v2.00 audit-recon blocks, R1, U1, U14 pass, and so does every
whole-suite run that completed).

## Every run

Times are Eastern; "wall s" is the run's wall-clock seconds. Logs are under this folder.

| label | start (ET) | exit | wall s | log | result |
|---|---|---|---|---|---|
| apply-u20u30 | 01:30:28 PM ET | 0 | 10.5 | `logs/apply-u20u30.log` | a-u20u30 = e31971a onto 7ee498a; 2 commit(s) |
| apply-u19 | 01:30:42 PM ET | 4 | 1.6 | `logs/apply-u19-attempt1-no-union.log` | STOP: non add/add conflict in tools/export-audit/audit-import.mjs |
| apply-u19 | 01:31:19 PM ET | 0 | 2.3 | `logs/apply-u19.log` | a-u19 = d3f3b72 onto e31971a; 1 commit(s) |
| apply-adopt | 01:31:26 PM ET | 4 | 4.5 | `logs/apply-adopt.log` | STOP: non add/add conflict in prioritization-board-grid.html |
| apply-u18 | 01:32:20 PM ET | 4 | 2.4 | `logs/apply-u18.log` | STOP: non add/add conflict in prioritization-board-grid.html |
| apply-hold | 01:32:33 PM ET | 0 | 5.4 | `logs/apply-hold.log` | a-hold = 8a6b09c onto d3f3b72; 2 commit(s) |
| apply-u9 | 01:32:43 PM ET | 0 | 3.0 | `logs/apply-u9.log` | a-u9 = 1420fcb onto 8a6b09c; 1 commit(s) |
| apply-u10 | 01:32:50 PM ET | 0 | 5.3 | `logs/apply-u10.log` | a-u10 = cbf94f0 onto 1420fcb; 2 commit(s) |
| apply-cycreg | 01:32:59 PM ET | 0 | 3.8 | `logs/apply-cycreg.log` | a-cycreg = fab6d23 onto cbf94f0; 1 commit(s) |
| apply-yearsel | 01:33:07 PM ET | 0 | 5.6 | `logs/apply-yearsel.log` | a-yearsel = bf23a92 onto fab6d23; 3 commit(s) |
| apply-regtext | 01:33:17 PM ET | 0 | 2.6 | `logs/apply-regtext.log` | a-regtext = 4541046 onto bf23a92; 1 commit(s) |
| apply-u37 | 01:33:23 PM ET | 0 | 2.8 | `logs/apply-u37.log` | a-u37 = 82d374f onto 4541046; 1 commit(s) |
| apply-u40 | 01:33:30 PM ET | 4 | 2.1 | `logs/apply-u40.log` | STOP: non add/add conflict in prioritization-board-grid.html |
| apply-u41u42 | 01:33:42 PM ET | 0 | 3.4 | `logs/apply-u41u42.log` | a-u41u42 = 6518730 onto 82d374f; 1 commit(s) |
| alone-adopt | 01:33:57 PM ET | 0 | 3.5 | `logs/alone-adopt.log` | a-adopt = 7837883 onto 7ee498a; 3 commit(s) |
| alone-u18 | 01:34:00 PM ET | 0 | 2.1 | `logs/alone-u18.log` | a-u18 = 0cb0e3c onto 7ee498a; 1 commit(s) |
| alone-u40 | 01:34:03 PM ET | 0 | 1.7 | `logs/alone-u40.log` | a-u40 = 9beb016 onto 7ee498a; 1 commit(s) |
| mcount-combined | 01:36:13 PM ET | 0 | 6.7 | `logs/mcount-combined.log` | {"entries": 1487, "once": 1487, "missing": [], "multiple": [], "unparsed": []} |
| mcount-base | 01:36:20 PM ET | 0 | 8.3 | `logs/mcount-base.log` | {"entries": 1328, "once": 1328, "missing": [], "multiple": [], "unparsed": []} |
| C-npm-check | 01:40:10 PM ET | 0 | 11.8 | `logs/C-npm-check.log` | all checks passed |
| B-npm-check | 01:40:27 PM ET | 0 | 12.2 | `logs/B-npm-check.log` | all checks passed |
| C-syntax-audit-import | 01:41:00 PM ET | 0 | 0.5 | `logs/C-syntax-audit-import.log` | parses (node --check) |
| C-syntax-audit-recon | 01:41:01 PM ET | 0 | 0.5 | `logs/C-syntax-audit-recon.log` | parses (node --check) |
| probe-codex-partial-copy | 01:43:04 PM ET | 3 | 0.5 | `logs/probe-codex-partial-copy.log` | `<L6>/u37/codex/applied: MISSING NEXT-VERSION.md` (exit 3, as expected: the Codex copy holds 4 files) |
| B-audit-recon | 01:41:00 PM ET | 0 | 501.7 | `logs/B-audit-recon.log` | ALL CHECKS PASSED |
| C-audit-recon | 01:41:01 PM ET | 124 | 601.0 | `logs/C-audit-recon.log` | STOPPED AT THE 600 s CAP (incomplete) |
| B-audit-other | 01:49:22 PM ET | 0 | 207.9 | `logs/B-audit-other.log` | ALL CHECKS PASSED |
| B-audit | 01:52:50 PM ET | 0 | 65.7 | `logs/B-audit.log` | ALL CHECKS PASSED |
| C-audit-other | 01:51:02 PM ET | 0 | 220.2 | `logs/C-audit-other.log` | ALL CHECKS PASSED |
| B-boot-same | 01:53:56 PM ET | 0 | 68.1 | `logs/B-boot-same.log` | every page, source, save and error list identical |
| C-audit | 01:54:43 PM ET | 0 | 60.8 | `logs/C-audit.log` | ALL CHECKS PASSED |
| C-boot-same | 01:55:44 PM ET | 0 | 68.2 | `logs/C-boot-same.log` | every page, source, save and error list identical |
| C-F-u30 | 01:55:04 PM ET | 0 | 158.6 | `logs/C-F-u30.log` | ALL CHECKS PASSED |
| C-F-u20 | 01:56:52 PM ET | 0 | 179.9 | `logs/C-F-u20.log` | ALL CHECKS PASSED |
| C-F-u19 | 01:57:43 PM ET | 0 | 251.2 | `logs/C-F-u19.log` | ALL CHECKS PASSED |
| C-F-r4u3u4 | 02:01:55 PM ET | 0 | 120.5 | `logs/C-F-r4u3u4.log` | ALL CHECKS PASSED |
| C-F-r3 | 02:03:55 PM ET | 0 | 66.4 | `logs/C-F-r3.log` | ALL CHECKS PASSED |
| C-F-r5u2u13 | 01:59:52 PM ET | 0 | 340.8 | `logs/C-F-r5u2u13.log` | ALL CHECKS PASSED |
| B-F-r3 | 02:05:02 PM ET | 0 | 66.2 | `logs/B-F-r3.log` | ALL CHECKS PASSED |
| C-F-v186dest | 02:05:33 PM ET | 0 | 61.9 | `logs/C-F-v186dest.log` | ALL CHECKS PASSED |
| B-F-r4 | 02:06:08 PM ET | 0 | 55.6 | `logs/B-F-r4.log` | ALL CHECKS PASSED |
| B-F-r5u2u13 | 02:07:04 PM ET | 0 | 395.8 | `logs/B-F-r5u2u13.log` | ALL CHECKS PASSED |
| B-F-v186dest | 02:13:40 PM ET | 0 | 58.7 | `logs/B-F-v186dest.log` | ALL CHECKS PASSED |
| C-audit-recon-r2 | 02:07:10 PM ET | 124 | 600.7 | `logs/C-audit-recon-r2.log` | STOPPED AT THE 600 s CAP (incomplete) |
| C-R-v200 | 02:14:46 PM ET | 137 | 357.1 | `logs/C-R-v200.log` | KILLED by the kernel OOM killer (shared memory cgroup; incomplete) |
| C-R-old | 02:17:16 PM ET | 0 | 366.5 | `logs/C-R-old.log` | ALL CHECKS PASSED |
| C-R-v200-r2 | 02:23:33 PM ET | 124 | 600.7 | `logs/C-R-v200-r2.log` | STOPPED AT THE 600 s CAP (incomplete) |
| C-R-v200b | 02:33:56 PM ET | 1 | 29.2 | `logs/C-R-v200b.log` | 6 FAILING CHECK |
| C-R-v200a | 02:34:25 PM ET | 0 | 74.2 | `logs/C-R-v200a.log` | ALL CHECKS PASSED |
| C-R-v200c | 02:33:56 PM ET | 1 | 163.0 | `logs/C-R-v200c.log` | 2 FAILING CHECK |
| C-R-v200d | 02:36:39 PM ET | 0 | 39.3 | `logs/C-R-v200d.log` | ALL CHECKS PASSED |
| C-R-v200c3 | 02:38:03 PM ET | 0 | 84.3 | `logs/C-R-v200c3.log` | ALL CHECKS PASSED |
| C-R-v200b3 | 02:38:03 PM ET | 0 | 84.9 | `logs/C-R-v200b3.log` | ALL CHECKS PASSED |
| C-audit-inject | 02:39:49 PM ET | 0 | 33.5 | `logs/C-audit-inject.log` | ALL CHECKS PASSED |
| C-audit-ppt | 02:40:23 PM ET | 0 | 12.1 | `logs/C-audit-ppt.log` | ALL CHECKS PASSED |
| C-audit-hostile | 02:39:49 PM ET | 0 | 111.9 | `logs/C-audit-hostile.log` | ALL CHECKS PASSED |
| C-legacy-fsrc | 02:41:41 PM ET | 0 | 5.9 | `logs/C-legacy-fsrc.log` | every legacy Force setting computes exactly as before |

PIDs: `pids.txt` (PID, label, start ET, cwd, command) — 57 recorded runs, one PID each (the `setsid`/`timeout` process of
the run); none was still alive at 2:41:58 PM ET (`kill -0` on each). I killed nothing at any time.

## For the real integration (what the dry run showed about the procedure)

1. **Three conflicts need a decision before apply2.py can pass adopt, u18 and u40**: C1/C2 in `driveClashSay` (U30 × U29 × U18,
   one sentence edited three ways — best settled by the three owners as one wording, since adopt's fix round now edits the
   `refused?` line too) and C3 in `flowSetEnt` (U10 × U40: signature + guard; decide the refusal order). Everything else in
   the 13 tracks merges as add/add unions.
2. **apply2.py, after a STOP, leaves the clone dirty**: its `cherry-pick --no-commit` leaves no CHERRY_PICK_HEAD, so its
   `cherry-pick --abort` fails ("no cherry-pick or revert in progress") and the unmerged files stay (`UU`). The next apply2 run
   then fails at its first `checkout -B`. I cleared it with `git reset --hard HEAD` each time (my clone only). The stopped
   track's `a-<track>` branch is also left pointing at a PARTIAL chain (adopt: c1 applied, c2 not) — easy to mistake for a good ref.
3. **apply2.py resolves union.py next to itself**; a copy of the script elsewhere needs union.py beside it (or it stops on the
   first add/add hunk, as my first u19 attempt did).
4. **The Codex stand-in copies (`codex/applied`) are partial** (4 files); apply2.py refuses them (`MISSING NEXT-VERSION.md`).
   A full copy (base + the 4 files) works, as here — or the real u37/u40 copies, once their builders finish.
5. **union.py order matters in `_driveStorePushRun`** if u18 and hold both land: keep the planned order (u18 before hold), or
   U4's hold check ends up before U18's awaited re-read.
6. **audit-recon is now longer than the 600 s cap under load** (combined suite: 68 scenarios; the base's 501.7 s run was close).
   The lead's whole-suite run may need a quiet machine or a longer cap; the split in this README is a verbatim alternative.

## What I did not do

- No commit, branch, stage or push in `/home/user/orbit-board` or `/home/user/orbit-ui`; nothing pushed from `clone/` (push URL
  disabled). Nothing written under `rec/L6` or `rec/L7/merge`; the original `rec/L7/apply2.py` and `union.py` are unchanged.
- No fix of any conflict or failure; no resolution of C1–C3 was attempted, not even as a probe.
- Did not run the full `audit-import.mjs` or `audit-board.mjs` (the lead's), nor any focused audit-board harness.
- Never imported, executed or ran `mutate.mjs` (not even `node --check`); no mutants were made or run.
- No Chromium / Playwright run of any kind (no verify:grid tools); no `playwright install`.
- Did not run the adopt (U24/U29/U31), u18 (U18) or u40 (U40) suite blocks in combination — those tracks did not apply. Their
  alone-on-base trees (`alone-a-adopt`, `alone-a-u18`, `alone-a-u40`) equal their own copies, which their tracks tested.
- Did not use the newer copies being written now (u20u30 c1f/c2f, u19 fr2, u10 c3/c4, the rewritten adopt c1–c3 and regtext
  c1, the u37/u40 builders' own c1): a dry run on those is a later step. Did not run audit-recon's whole suite to completion
  (cap, twice) — covered by the split harnesses instead.
- Base-side runs of audit-ppt, audit-hostile, audit-inject and legacy-fsrc were not made (nothing failed on the combined tree,
  so there was nothing to class).

## Files

- `README.md` (this), `runs.tsv`, `pids.txt`, `logs/` (every run's log; `ident-1..4.txt`, `draft-chain-blobs.txt`,
  `contained.txt`, `runs-table.md`), `out/` (SUITE_CHECKS rows per harness run).
- `apply2-dry.py`, `union.py` (copy), `bin/` (run.sh, lane.sh + lane lists, ident.py, hunks.py, contained.py, tally.py,
  mkharness.sh, mkrecon-old.py, mkfocused-extra.py, mkfocused-closure.py [built, not used: its naive closure pulled boot-time
  globals], copies of mkfocused.py, mkfocused-u2.py, mkfocused-multi.py, runner.mjs).
- `clone/` (branches: `d-<track>` drafts; `a-<track>` applied refs; `dry-combined` = 6518730; `stopped-a-adopt-chain`,
  `stopped-a-u18-chain` (= a-u19 d3f3b72, nothing applied), `stopped-a-u40-chain` (= a-u37 82d374f, nothing applied) = where each stop left its branch; `alone-a-adopt|u18|u40` = alone on the base).
- `tree/` = checkout of `dry-combined`; `basetree/` = checkout of the base; `h/` = focused harnesses; `copies/` = full
  stand-in copies; `conflicts/` = every conflicted file and hunk list.
