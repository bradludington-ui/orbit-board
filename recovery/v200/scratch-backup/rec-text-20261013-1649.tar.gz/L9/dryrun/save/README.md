# Save, reopen and adoption paths: what the tracks do when combined (L9 dry run, interaction review)

Written 13 Oct 2026, from 2:47 PM ET to 3:30 PM ET. Tracks: **u20u30** (U20, U30), **u19** (U19), **adopt** (U24, U29, U31),
**u18** (U18) and **hold** (U3, U4). Every path below is under `rec/L9/dryrun/save/` unless it starts with `<L6>` (= `rec/L6`)
or `<DRY>` (= `rec/L9/dryrun`).

Nothing was staged, committed or pushed in `/home/user/orbit-board` or `/home/user/orbit-ui`, and nothing was pushed
anywhere. `<L6>`, `<DRY>/clone`, `<DRY>/tree` and `rec/L7/merge` were only read. The only commits are probe commits in my
own scratch clone, `save/clone`: a `git clone --shared` of `<DRY>/clone` with push URL `NO-PUSH-save`. Its worktrees are in
`wt/` and its harnesses in `h/`.

The user's request was "B2 and C2". **C2** is the dry run's second conflict (u18 onto a-u19, `driveClashSay`), and it is
covered as **I3**, together with its two hidden companions, I1 and I4. I could not find a "B2" label in the lead's records
I can read. Everything in this area that touches save, reopen and adoption is below.

`mutate.mjs` was never imported, executed or run. It was read as text only, with `rec/bin/mcount.py` under `python3 -I`. No Chromium was used and nothing was installed. The full
audit-import and audit-board were not run.

## The answer

**Verdict: compose-with-issues.** No product check fails once the two known conflicts are settled by hand, but **two
must-resolve items** depend on how they are settled. I composed all five tracks on `dry-combined` (6518730), adding the
two that stopped there, u18 and adopt. Every v2.00 block of the area then passes, at the tracks' own check counts:

| block | count |
|---|---|
| U18 | 58 |
| U24 | 58 |
| U29 | 33 |
| U31 | 34 |
| U30 | 48 |
| U20 | 78 |
| U19 | 104 |
| R4 + U3 + U4 | 85 |
| R5 + U2 + U13 | 135 |

The same holds with adopt's current fix-round copies in place of its build copies: U24 65, U29 55, U31 34, U18 58 and
U30 48, all passing.

1. **MUST: u18 × hold, the order of two checks in `_driveStorePushRun`.**
   - hold is already in `dry-combined` and u18 is not. Re-applying u18 onto it makes `union.py` put U4's hold check
     *before* U18's re-read. That is ours-then-theirs, and I verified it with a real cherry-pick.
   - The re-read then becomes the last wait before the write, and U4's guarantee is gone. An import that stops part-way
     during that re-read lets the save write over the folder's copy and say "✅ Saved" with the hold on.
   - **Proven** by `S-u18hf-P-order2`: 3 checks fail (1 write, "✅ Saved", the stamp moved). The same probe passes on the
     U18-first board (`S-u18uf-P-order2`).
   - **No existing test sees this.** On the wrong-order board, R4+U3+U4 still pass 85/85 and U18 passes 58/58.
2. **MUST: C1, `driveClashSay` U30 × U29. Neither side can simply be kept.**
   - Keeping U29's line makes U30 fail 2 of 48: with nothing recorded, the board again says "after the copy you are
     working from".
   - Keeping U30's line makes U29 fail 4 of 33: "after" is said when the folder's copy is *older* than the copy on screen.
   - The nested rule below passes both, 48/48 and 33/33.
3. **SHOULD: C2, `driveClashSay` U30 × U18.** Composing it line by line (U30's "after/no record" line plus U18's `refused==='late'`
   line) passes U18 58/58 and U30 48/48. So does the four-way line with adopt's fix-round wording. It is mechanical, but
   the lines must be merged by hand: `apply2.py` stops on it.
4. **SHOULD: mutation entries broken by the combination.** Checked by text with mcount; nothing was run.
   - `v200-u18-pen-line-kept` matches **twice** once hold is in, because U4 has the same two lines. `mutate.mjs` then
     reports it "NOT APPLIED" (`hits !== 1`).
   - Any resolution of C1 leaves `v200-u30-unrecorded-said-after`, `v200-u30-recorded-said-unknown` and
     `v200-adopt-u29-clash-after` matching nothing.
5. **SHOULD (coming next): u20u30's fix-round copy c2f × u19 conflicts in `keptPutBack`'s put-back message.** c1/c2 do
   not; c2f does. c2f also keeps both `driveClashSay` conflicts.
6. Notes: U20 makes every `_saveBusy` guard (U2, U13, U24, U19's put-back) count a save that is waiting, and they all pass
   in combination. The order of the U18/U4 refusals, U3 at the moment of asking, the U18 × U30 wording and U29 × U19 all
   compose (details below).

**Recommended merge order for my tracks:**
- Keep the planned order, u20u30 → u19 → adopt → **u18 → hold**. What matters is **u18 before hold**: U18's re-read then
  comes before U4's check.
- I applied the u18 → hold part of that order myself on `a-u19` (`p-planned-u18`, `p-planned-hold`). The whole
  `_driveStorePushRun` then equals my U18-first board, except for the order of two `const` lines.
- Because hold is already applied, re-applying u18 is the dangerous step. Either rebuild the chain in the planned order,
  or place U4's `if(impMixedOn()){…}` block by hand immediately before `await driveWrite(...)`, after U18's block.
- Whether adopt comes before or after u18 does not matter: both are hand merges of `driveClashSay`, and they reach the
  same text (item 2, and C2 in item 3). I built `s-all` u18-then-adopt and checked that text with every block.

## What I combined (identities)

Base 7ee498a (board `fce8a391`). The tracks' copies were checked by `git hash-object` at 3:06 PM ET. They are unchanged
from what the dry run used:
- u20u30 c1 `83b87782`, c2 `c42be8e7`
- u19 fr/c1 `f6ac4b9d`
- u18 c1 `e3986f30` (import `329cf6e8`, mutate `fc364266`)
- hold c1 `82a2f1cc`, c2 `4b755576`
- adopt build copies (`<L6>/adopt/superseded-r3`; the dry run's `d-adopt` branch): c1 `00c2ac15`, c2 `d020543e`, c3
  `c0d14fcd`
- adopt fix-round copies (`<L6>/adopt/c1..c3`, unchanged since 1:44:58 PM ET), used for contrast: c1 `00c2ac15`, c2
  `0bbfedb6`, c3 `d1cdcdf5`

| branch (save/clone) | what | board | audit-import | mutate.mjs |
|---|---|---|---|---|
| `dry/dry-combined` 6518730 | the dry run's combined tree (no adopt, no u18) | a93abf27 | 60f3631f | 4ed68b06 |
| `s-u18-holdfirst` 4f6392e | + u18 c1, every hunk resolved ours-then-theirs (what `union.py` gives today: **U4 check, then U18 re-read**); C2 composed line by line | 4ee95039 | 2f2eeda5 | 6086d73f |
| `s-u18-u18first` f297778 | the same with the check hunk swapped: **U18 re-read, then U4 check** | 5526462f | 2f2eeda5 | 6086d73f |
| `s-adopt-nested` 6d556a1 | dry-combined + adopt build c1–c3; C1 resolved by the nested rule | 653bfd6f | fc4184bb | af3f152d |
| `s-adopt-u30side` 14bac24 | the same, C1 = U30's lines kept ("ours") | 3f624194 | fc4184bb | af3f152d |
| `s-adopt-u29side` 4553750 | the same, C1 = U29's lines kept ("theirs") | 5d06c0f3 | fc4184bb | af3f152d |
| `s-all` 68b76a4 | `s-u18-u18first` + adopt build c1–c3, the three-way `driveClashSay` | 2c483163 | 17494fe9 | 7807bd75 |
| `s-allfr` 630a97c | `s-u18-u18first` + adopt **fix-round** c1–c3 (`d-adopt-fr` a2baf80), the four-way `driveClashSay` | ef496747 | 72fcbadd | 43a335fb |
| `p-planned-u18` d2a978e → `p-planned-hold` 890d6cd | the planned order on `a-u19`: u18, then hold (for the order check only) | 1f0e6120 | 2f2eeda5 | 53439910 |
| `d-u20u30-f` 05c8d5a | u20u30's fix-round c1f/c2f as a draft chain (for merge-tree only) | 84cf2bf4 | 3a34d922 | d174d05d |

How each branch was built:
- `bin/chain.sh` cherry-picks each draft commit.
- `bin/resolve.py` resolves it. An add/add hunk is resolved as ours-then-theirs, exactly as `union.py` does, or swapped
  where said. A real hunk is replaced by hand text from `spec/*.json`.
- `bin/mkdraft.py` builds the fix-round draft chains the way `apply2.py` builds its own (from the base, every base file
  the copy holds).

The worktrees are in `wt/`. Each has the base's `runtime-encoding-shim.mjs` and a `node_modules` link.

The `driveClashSay` text used in `s-all` is the C1/C2 resolution I propose:
```
    +' to the shared folder '+esc(liveAge(theirs))
    +(!driveBaseOf(ap)? ', and this browser has no record of which copy in the folder, if any, the work on screen came from. '
      : theirs>driveBaseOf(ap)? ', after the copy you are working from. ' : ', and that is not the copy you are working from. ')
    +(refused==='late'? 'Their copy landed while your save was under way, and <b>your save stopped before writing over it</b>. '
      : refused? '<b>Nothing was written.</b> ' : 'What is on screen does not have their changes. ')
```
In `s-allfr`, the last line's final alternative is adopt's fix-round clause: `theirs>driveBaseOf(ap)? 'What is on screen does
not have their changes. ' : 'What is on screen came from another copy, which may not have their changes. '`. The full texts
are in `spec/all-nested.json` and `spec/allfr-nested.json`.

## What two or more of these tracks touch

| place | tracks | kind of overlap | composed? |
|---|---|---|---|
| `driveClashSay`, the "after the copy" line | U30, U29 (+ U29 fix round) | **real conflict (C1)**: two different tests for the same words | only by hand: the nested rule (item 2) |
| `driveClashSay`, the `refused?` line | U18, U29 fix round (U30 keeps it) | U18 adds `'late'`; adopt's fix round adds a `theirs>base` alternative | line by line, shown in `s-allfr` |
| comment above `driveClashSay` | U30, U18 | add/add | union |
| `_driveStorePushRun`: the stamp kept before the write (`const was` / `const ts0`) | U18, U4 | add/add, two names | union (order irrelevant) |
| `_driveStorePushRun`: last check before `driveWrite` | U18 (awaited re-read), U4 (synchronous hold check) | add/add, **order is semantic** | U18 must come first (item 1) |
| `_driveStorePushRun` top: hold, R3, U4 after the read, clash | U3/U4, U30 (via `driveClashSay`), U18 ('late') | sequence of refusals | composes (note) |
| `saveSerial`, `_saveBusy` | U20 (counted from the ask); read by U2/U13 (base), U24 ×3, U30's refresh guard | semantic widening | composes; U24 58/58, U20 78/78 |
| `driveStorePull` (refresh) | U30 (`!base && theirs!==ours`), U13 (base), U29 (base re-pointed by `loadedNotSaved`) | semantic | composes; U29 (5) passes under the nested words |
| `keptPutBack` | U19 (keep test, words), U2 (base), U20 (`_saveBusy`), **u20u30 c2f** (words) | c1/c2: none; **c2f: real conflict** | c1/c2 compose; c2f needs a hand merge (item 5) |
| DIRTY / `_baseDirty` / record dirty | U29 (`loadedNotSaved`), U31 (import), U18/U4 (stamp put back on refusal), U19/U2 (put-back) | same rule, different triggers | consistent |
| audit-import blocks | U18, U24, U29, U31 after U20/U30/U19 | add/add | union; every block passes |
| mutate.mjs entries | every track | add/add | union; **4 entries break** (item 4) |

## Interactions

### I1 (MUST): U4's hold check must stay after U18's re-read; today's apply path puts it before

**What happens.** Both tracks insert a block at the same spot, between the history copy and `await driveWrite(...)`:
- U18: re-read the folder's copy, which awaits, and stop if it changed.
- U4: a synchronous check that refuses if the mixed-import hold is on.

`union.py` keeps both, ours then theirs. hold is already applied in `dry-combined` and u18 stopped there, so re-applying u18
makes hold "ours" and gives **U4 check → U18 re-read**. The re-read then becomes the last wait before the write, and an
import that stops part-way during it is never checked. U4's own draft says this check "belongs after U18's re-read"
(`<L6>/hold/drafts/NEXT-VERSION-U4.md`, "Not covered"), but nothing in the apply path or the suites enforces it.

**Evidence.**
- **The order.** `s-u18-holdfirst` was resolved exactly as `union.py` does it and has U4 first. The planned order
  (`p-planned-u18` → `p-planned-hold`) produces U18 first. Its whole `_driveStorePushRun` equals `s-u18-u18first`
  except for the order of the two `const` lines (`out/push-planned.txt`, `out/push-u18uf.txt`, `out/push-u18hf.txt`).
- **The probe.** `probe/block-order2.mjs.txt`, built into `h/<wt>/tools/export-audit/P-order2.mjs`. It uses the U4 block's
  own helpers, verbatim, and its expected values are hand-written: U4's own expectations.
  1. The board saves its first folder copy and EDIT-1 is typed.
  2. 💾 Save is held at its **second** read of the folder's copy. A control shows this is after its history copy closed,
     with `_saveBusy` 1.
  3. A full import stops part-way there (control: the hold is on), and then the save is let go.
  4. Control: the same hold with nothing happening there writes once and says Saved.
- **Results.**
  - `S-u18hf-P-order2` (hold-first board 4ee95039), 3:22:03 PM ET, exit 1, 46.8 s, `logs/S-u18hf-P-order2.log`.
    **3 failing checks** (every control passes): 1 write over the folder's copy (the folder now holds EDIT-1), the
    status "✅ Saved O&M FY27 to the shared folder — 5 KB…" with `impMixedOn()` true, and the board's stamp moved.
  - `S-u18uf-P-order2` (U18-first board 5526462f), exit 0, `logs/S-u18uf-P-order2.log`. ALL CHECKS PASSED: 0 writes,
    the same bytes, "Writing to the shared folder is refused", the stamp as it was.
- **The existing tests miss it.** On the hold-first board, `S-u18hf-F-r4u3u4` passes 85/85 and `S-u18hf-F-u18` passes
  58/58. U4's own test makes the import stop during the *history copy*, which is before both checks in either order.

The first probe runs (`S-u18hf-P-order`, `S-u18uf-P-order`) carried a wrong literal of mine: they expected the folder's note
A to be '' where v1 holds the fixture's 'p…' note. They are superseded by r2 and do not count, though their write/refuse
outcome was the same.

**Smallest resolution.** When u18 is re-applied (after the C2 hand merge), put U18's re-read block before U4's
`if(impMixedOn()){…}`, i.e. U4's check immediately before `await driveWrite(dir, driveName(fy, ap), body);`. The other
way is to rebuild the chain in the planned order (u18 before hold). **Carried by:** the u18 track, since it is the one
being re-based onto a tree that has hold. **Lock it with a test:** the hold track adds the probe's scenario to its U4
block ("the hold set during the re-read just before the write"), so either order is caught in future.

### I2 (MUST): C1, `driveClashSay`'s "after the copy" words, U30 × U29

**What happens.** The two tracks pick the words after "saved … to the shared folder <age>" by different tests:
- U30 asks whether anything is recorded. If nothing is, it says "this browser has no record…".
- U29 asks whether theirs is newer than the recorded copy. If it is not, it says "that is not the copy you are working
  from".

Each fixes the other's blind spot, so keeping one side reintroduces the defect the other fixed.

**Evidence.** Each run is the track's own block, verbatim, on the combined tree. The only difference between the trees is
this line.

| run | board | result | log |
|---|---|---|---|
| `S-a29-F-u30` (U29's line kept), 3:10:14 PM ET | 5d06c0f3 | exit 1, 115.0 s, **2 of 48 fail**: U30 (1) and (1h). With nothing recorded, the Live autosave's refusal says "after the copy you are working from" again, and the "no record" words are missing | `logs/S-a29-F-u30.log` |
| `S-a30-F-u29` (U30's line kept), 3:11:50 PM ET | 3f624194 | exit 1, 120.9 s, **4 of 33 fail**: U29 (5) ×3 and (6). After loading a copy newer than the folder's, the refresh, the Live autosave and 💾 Save say the folder's older copy was saved "after the copy you are working from" | `logs/S-a30-F-u29.log` |
| `S-all-F-u30` (nested) | 2c483163 | 48/48, exit 0 | `logs/S-all-F-u30.log` |
| `S-all-F-u29` (nested), 3:24:39 PM ET | 2c483163 | U29 33/33, exit 0, 143.7 s | `logs/S-all-F-u29.log` |
| `S-allfr-F-u30`, `S-allfr-F-u29` (four-way, adopt fix round) | ef496747 | 48/48 and 55/55 | logs as named |

**Smallest resolution.** Use the nested rule: nothing recorded → "no record"; recorded and theirs newer → "after";
recorded and theirs not newer → "that is not the copy you are working from". The text is above. **Carried by:** adopt,
whose c2 lands after u20u30 in the planned order and is the commit that stops. u20u30's owner must agree the words. The
wording is a person's call; the rule is not, because both tracks' tests demand it.

### I3 (SHOULD): C2, `driveClashSay`'s `refused` line, U30 × U18 (and adopt's fix round)

**What happens.** U18 changes the `refused?` line, adding `'late'`, next to U30's change of the "after" line. git
reports one conflict hunk, but the edits are independent: each one's line can be taken as it is.

Two combinations are worth checking:
- With nothing recorded and a first copy landing during the save (U18 (7a)), the combined words are "…, and this browser
  has no record of which copy in the folder, if any, the work on screen came from. Their copy landed while your save was
  under way, and your save stopped before writing over it." That is true. U18's check for this case tests only the start
  and end of the sentence, so it allows the U30 middle.
- Adopt's fix round also rewrites the same `refused?` line, giving four edits on two lines. They nest the same way:
  `'late'` → `refused` → `theirs>base` → "came from another copy".

**Evidence.** All exit 0:

| run | board | blocks passing |
|---|---|---|
| `S-all-F-u18`, 2:55:57 PM ET, 118.3 s | 2c483163 | U18 58/58 |
| `S-all-F-u30` | 2c483163 | U30 48/48 |
| `S-allfr-F-u18` | ef496747 | U18 58/58 |
| `S-allfr-F-u30` | ef496747 | U30 48/48 |
| `S-allfr-F-u24` / `-u29` / `-u31` | ef496747 | 65/65, 55/55, 34/34, adopt fix round's own counts (`<L6>/adopt/out/FR-U*-on-c3`) |

**Smallest resolution.** A hand merge taking both lines, as in `spec/u18-holdfirst.json` (C2 alone) or
`spec/allfr-nested.json` (all four), plus the add/add comment union. **Carried by:** u18 at its re-base, with adopt's
fix-round wording if that lands.

### I4 (SHOULD): mutation entries the combination breaks (text only)

mcount (`python3 -I rec/bin/mcount.py`, text only) on each composed tree; logs in `logs/mcount-<wt>.log`:

| tree | entries | once | missing | multiple |
|---|---|---|---|---|
| u18hf / u18uf (u18 + hold) | 1495 | 1494 | — | `v200-u18-pen-line-kept` ×2 |
| adn (nested C1) | 1508 | 1505 | `v200-u30-unrecorded-said-after`, `v200-u30-recorded-said-unknown`, `v200-adopt-u29-clash-after` | — |
| a30 (U30 side) | 1508 | 1507 | `v200-adopt-u29-clash-after` | — |
| a29 (U29 side) | 1508 | 1506 | the two U30 entries | — |
| all | 1516 | 1512 | the three above | `v200-u18-pen-line-kept` ×2 |
| allfr | 1522 | 1518 | the three above | `v200-u18-pen-line-kept` ×2 |

What breaks and why:
- `v200-u18-pen-line-kept` finds `      if(penLine) writerJournalUndo(penLine);\n      if(MS.ts===wroteTs)`. U4's refusal
  holds exactly the same two lines.
- `mutate.mjs` (read as text, line ~4997) refuses any entry whose target matches other than once ("NOT APPLIED: target
  matched 2 times"). That mutant would never run.
- The three `driveClashSay` entries find the pre-merge text, which no resolution of C1 keeps. (`v200-adopt-u29-clash-lacks`,
  from the fix round, still matches once under the four-way text.)

**Smallest resolution.**
- u18: re-anchor its entry to `…if(MS.ts===wroteTs){ MS.ts=was.ts;`.
- adopt (as it resolves C1): re-anchor the three entries on the composed lines and re-run those four mutants against U30's
  and U29's blocks.

### I5 (SHOULD, upcoming): u20u30's fix-round c2f × u19 fr/c1, `keptPutBack`'s put-back message

The task said to use c1/c2, and those compose with u19 (merge-tree: 0 board conflicts). But c2f, now being written by
u20u30's fix round, rewrites the same `setStat('↶ <b>Put back</b>…')` line that U19 rewrites. In c2f the words depend on
`after = (k.meta.why!=='folder') || !!driveBaseOf(mySlug())`; U19 adds its `'swap'` alternative.

`git merge-tree` of `d-u20u30-f` against each other track's draft:
- u19: 1 real hunk (`conflicts/u20u30f_x_dry_d-u19.board-hunks.txt`)
- u18: 1 (`driveClashSay`)
- adopt build: 1
- adopt fix round: 1
- hold: 0

**Composition:** U19's `'swap'` branch first, then c2f's `after` wording for the rest. Not run. **Carried by:** u20u30, in
its fix round, in step with u19's fix round 2 (`<L6>/u19/fr2`). That round also edits `keptPutBack`, though not, on a quick
read, this line.

### Notes (no action needed; each is shown by a run unless marked "by reading the code")

- **U20 × the `_saveBusy` guards.** U20 counts a save from the moment it is asked for, so every reader of `_saveBusy` also
  refuses while a save is merely waiting. The readers are U2's put-back, U13's refresh, U30's base guard and U24's three
  load guards. All their blocks pass in combination:

  | block | count |
  |---|---|
  | U20 | 78/78 |
  | U24 | 58/58 (`S-all-F-u24`) |
  | R5+U2+U13 | 135/135 |
  | U30 | 48/48 |
  | U19 | 104/104 |

  U24's checks of `_saveBusy` (1 while held, 0 after) hold under U20's decrement (`p.then(done)`), which is registered
  before the caller's await.
- **U18 'late' and U4 hold refusals in the same save** (by reading the code; not run). With U18 first, a copy that landed
  *and* a hold set both refuse. The clash words win and offer "Save yours over theirs", which U3 then refuses at once under
  the hold. Nothing is written either way.
- **U30 × U18** (by reading the code; not run). After a late refusal with nothing recorded, a refresh records nothing
  even when theirs ≤ ours (clock skew). Before U30, `driveStorePull` (`if(!base){ if(!_saveBusy) driveBaseSet(…) }`)
  would record Bob's copy and the next Save would write over it, so U30 also covers U18's path.
- **U29 × U19** (by reading the code; both blocks pass in `s-all`, but neither runs this exact sequence). `loadedNotSaved` sets DIRTY, so U19's keep test keeps the loaded copy at a put-back. The put-back restores
  the record from the kept meta, as before. U19 passes 104/104 and U29 33/33 in `s-all`.
- **U31 × U3/U4** (by reading the code; both blocks pass). U31 marks records dirty only for an applied import. A stopped import returns earlier
  (`batchImportUndone`), so the hold paths are untouched (U31 34/34, R4+U3+U4 85/85).

## Runs

Every node run went through `bin/run.sh` (a copy of `<DRY>/bin/run.sh` with only its folder changed):
- bounded with `setsid -w timeout -k 10 600`;
- PID appended to `<DRY>/pids.txt`;
- one line per run in `runs.tsv`;
- the `AUDIT_IMPORT_RUNNING` lock checked first (never present).

Runs went through two lanes at most, so there were never more than two of my node processes at once. Focused harnesses
were built VERBATIM from each tree's own audit-import by `<DRY>/bin/mkfocused-u2.py` (unchanged), through `bin/mkh.sh`, and
run by `<DRY>/bin/runner.mjs` (unchanged), with BOARD unset (= the worktree's own board, asserted). "checks" counts the rows
each run recorded in `out/<label>.checks.jsonl` (`<DRY>/bin/tally.py`).

| label | start (ET) | exit | wall s | log | result |
|---|---|---|---|---|---|
| S-all-F-u18 | 02:55:57 PM ET | 0 | 118.3 | `logs/S-all-F-u18.log` | 58 checks recorded, 0 failing; ALL CHECKS PASSED |
| S-all-F-u30 | 02:57:55 PM ET | 0 | 141.2 | `logs/S-all-F-u30.log` | 48 checks recorded, 0 failing; ALL CHECKS PASSED |
| S-all-F-adopt | 02:55:57 PM ET | 137 | 298.0 | `logs/S-all-F-adopt.log` | 117 checks recorded, 0 failing;  -- KILLED (OOM, shared memory cgroup) |
| mcount-u18hf | 03:00:41 PM ET | 0 | 20.9 | `logs/mcount-u18hf.log` | {"entries": 1495, "once": 1494, "missing": [], "multiple": [["v200-u18-pen-line-kept", 2]], "unparsed": []} |
| mcount-u18uf | 03:01:02 PM ET | 0 | 12.9 | `logs/mcount-u18uf.log` | {"entries": 1495, "once": 1494, "missing": [], "multiple": [["v200-u18-pen-line-kept", 2]], "unparsed": []} |
| mcount-adn | 03:01:15 PM ET | 0 | 10.1 | `logs/mcount-adn.log` | {"entries": 1508, "once": 1505, "missing": ["v200-u30-unrecorded-said-after", "v200-u30-recorded-said-unknown", "v200-adopt-u29-clash-after"], "multiple": [], " |
| mcount-a30 | 03:01:25 PM ET | 0 | 9.6 | `logs/mcount-a30.log` | {"entries": 1508, "once": 1507, "missing": ["v200-adopt-u29-clash-after"], "multiple": [], "unparsed": []} |
| mcount-a29 | 03:01:34 PM ET | 0 | 14.7 | `logs/mcount-a29.log` | {"entries": 1508, "once": 1506, "missing": ["v200-u30-unrecorded-said-after", "v200-u30-recorded-said-unknown"], "multiple": [], "unparsed": []} |
| mcount-all | 03:01:49 PM ET | 0 | 18.5 | `logs/mcount-all.log` | {"entries": 1516, "once": 1512, "missing": ["v200-u30-unrecorded-said-after", "v200-u30-recorded-said-unknown", "v200-adopt-u29-clash-after"], "multiple": [["v2 |
| mcount-allfr | 03:02:08 PM ET | 0 | 18.6 | `logs/mcount-allfr.log` | {"entries": 1522, "once": 1518, "missing": ["v200-u30-unrecorded-said-after", "v200-u30-recorded-said-unknown", "v200-adopt-u29-clash-after"], "multiple": [["v2 |
| S-all-F-u20 | 03:00:56 PM ET | 0 | 157.4 | `logs/S-all-F-u20.log` | 78 checks recorded, 0 failing; ALL CHECKS PASSED |
| S-all-F-u19 | 03:00:17 PM ET | 0 | 236.6 | `logs/S-all-F-u19.log` | 104 checks recorded, 0 failing; ALL CHECKS PASSED |
| S-all-F-r4u3u4 | 03:04:13 PM ET | 0 | 129.4 | `logs/S-all-F-r4u3u4.log` | 85 checks recorded, 0 failing; ALL CHECKS PASSED |
| S-u18hf-P-order (r1: a literal of mine wrong; superseded by r2) | 03:06:32 PM ET | 1 | 54.1 | `logs/S-u18hf-P-order.log` | 3 FAILING CHECK |
| S-u18uf-P-order (r1: its 1 failure is my wrong literal; superseded by r2) | 03:07:26 PM ET | 1 | 167.7 | `logs/S-u18uf-P-order.log` | 1 FAILING CHECK |
| S-all-F-r5u2u13 | 03:03:34 PM ET | 0 | 487.2 | `logs/S-all-F-r5u2u13.log` | 135 checks recorded, 0 failing; ALL CHECKS PASSED |
| S-a29-F-u30 | 03:10:14 PM ET | 1 | 115.0 | `logs/S-a29-F-u30.log` | 48 checks recorded, 2 failing; 2 FAILING CHECK |
| S-a30-F-u29 | 03:11:50 PM ET | 1 | 120.9 | `logs/S-a30-F-u29.log` | 33 checks recorded, 4 failing; 4 FAILING CHECK |
| S-all-F-u31 | 03:12:09 PM ET | 0 | 107.3 | `logs/S-all-F-u31.log` | 34 checks recorded, 0 failing; ALL CHECKS PASSED |
| S-allfr-F-u24 | 03:13:51 PM ET | 0 | 202.7 | `logs/S-allfr-F-u24.log` | 65 checks recorded, 0 failing; ALL CHECKS PASSED |
| S-allfr-F-u29 | 03:13:56 PM ET | 0 | 225.1 | `logs/S-allfr-F-u29.log` | 55 checks recorded, 0 failing; ALL CHECKS PASSED |
| S-allfr-F-u31 | 03:17:13 PM ET | 0 | 111.6 | `logs/S-allfr-F-u31.log` | 34 checks recorded, 0 failing; ALL CHECKS PASSED |
| S-u18hf-F-r4u3u4 | 03:17:47 PM ET | 0 | 121.2 | `logs/S-u18hf-F-r4u3u4.log` | 85 checks recorded, 0 failing; ALL CHECKS PASSED |
| S-allfr-F-u18 | 03:19:05 PM ET | 0 | 128.7 | `logs/S-allfr-F-u18.log` | 58 checks recorded, 0 failing; ALL CHECKS PASSED |
| S-u18hf-F-u18 | 03:19:48 PM ET | 0 | 133.7 | `logs/S-u18hf-F-u18.log` | 58 checks recorded, 0 failing; ALL CHECKS PASSED |
| S-u18hf-P-order2 | 03:22:03 PM ET | 1 | 46.8 | `logs/S-u18hf-P-order2.log` | 3 FAILING CHECK |
| S-allfr-F-u30 | 03:21:14 PM ET | 0 | 167.2 | `logs/S-allfr-F-u30.log` | 48 checks recorded, 0 failing; ALL CHECKS PASSED |
| S-u18uf-P-order2 | 03:22:49 PM ET | 0 | 73.4 | `logs/S-u18uf-P-order2.log` | ALL CHECKS PASSED |
| S-all-npm-check | 03:24:04 PM ET | 0 | 16.3 | `logs/S-all-npm-check.log` | all checks passed |
| S-allfr-npm-check | 03:24:21 PM ET | 0 | 16.3 | `logs/S-allfr-npm-check.log` | all checks passed |
| S-all-syntax-import | 03:24:37 PM ET | 0 | 0.5 | `logs/S-all-syntax-import.log` | parses (node --check) |
| S-allfr-syntax-import | 03:24:38 PM ET | 0 | 0.4 | `logs/S-allfr-syntax-import.log` | parses (node --check) |
| S-all-F-u29 | 03:24:39 PM ET | 0 | 143.7 | `logs/S-all-F-u29.log` | 33 checks recorded, 0 failing; ALL CHECKS PASSED |
| S-all-F-u24 | 03:24:39 PM ET | 0 | 180.5 | `logs/S-all-F-u24.log` | 58 checks recorded, 0 failing; ALL CHECKS PASSED |

**Not runs of the product:**
- `S-all-F-adopt` was killed by the kernel's OOM killer at 298 s: dmesg reported "Memory cgroup out of memory: Killed
  process 18759 (node) … anon-rss:1811088kB". The machine's memory is shared.
  - Its recorded rows show U24 58/58 and U29 33/33 complete with 0 failing. U31 reached 26 of 34.
  - U31 was re-run alone (`S-all-F-u31`, 34/34), and U24 and U29 were re-run separately (`S-all-F-u24` 58/58,
    `S-all-F-u29` 33/33, both ALL CHECKS PASSED) for a verdict that includes the scenario guard.
- The 7 mcount runs (text only, `python3 -I`, each bounded with `setsid -w timeout -k 10 600`, 10–21 s) were run directly
  from the shell. **Their PIDs were not recorded in pids.txt**, an omission of mine. They are in `runs.tsv` with their
  start times; all had exited (exit 0) before the next command.
- Git commands (clone, cherry-pick, merge-tree, worktree) were not bounded either. All ran in under a few seconds and only
  in `save/`.

PIDs: `<DRY>/pids.txt`, lines labelled `S-…`. I killed nothing at any time.

## What I did not do

- Did not edit any track's copy, or anything in `<DRY>/clone`, `<DRY>/tree`, `<L6>` or `rec/L7`. No commit or push outside
  my own scratch clone. Its branches exist only in `save/clone`.
- Did not run mutants (no `mkmut.py` mutant was built or run), the full audit-import, audit-board, or whole-suite
  audit-other/audit-recon on the composed trees. The dry run's whole-suite runs cover the other tracks, and only
  audit-import blocks and the board's save paths differ in my trees.
- Did not run U18/adopt blocks on the single-track copies again. Their tracks did, and the alone-on-base branches equal
  them.
- Did not compose c2f (u20u30 fix round), u19 fr2 or u10/regtext newer copies into a tree. I5 is from merge-tree only.

## Files

- `README.md` (this file) and `runs.tsv`
- `logs/`: every run's log, `mcount-*.log`, and `lane*.out`
- `out/`: SUITE_CHECKS rows, plus `push-*.txt`, `_driveStorePushRun` as each order leaves it
- `bin/`:
  - `chain.sh`, `resolve.py`, `mkdraft.py`, `mkh.sh`, `mkprobe.py`
  - `run.sh`, `lane.sh`, `lane2.sh`, and the lane lists
- `spec/`: the hand texts for each resolution
- `probe/`: `block-order.mjs.txt` (r1) and `block-order2.mjs.txt` (r2)
- `conflicts/`: merge-tree hunks for c2f
- `clone/`, `wt/`, `h/`
