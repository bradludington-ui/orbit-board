# REGTEXT (U36), verifier round 2, LENS B: test adequacy and regressions

Independent adversarial review of the builder's fix-round commit for the REGTEXT track (review row U35; the fix is U36: "an
RCN / EEIC title over 80 characters is refused, never cut"). All times are Eastern (`TZ=America/New_York date`), 13 Oct 2026.

Two sessions did this work:
- **Attempt 1**, 10:52 AM to about 11:43 AM ET. The lead stopped it at about 11:45 AM ET to lower the machine's load. Its
  README held only a header; its runs, logs and copies are all here.
- **Attempt 2 (this one)**, from 12:40 PM ET. It read everything attempt 1 left, checked the blobs, reused every run of
  attempt 1 that has an exit record on the same blobs, re-ran the two that had none, and added the runs listed as `R3*`.
  It ran at most two node or Chromium processes of its own at a time (one deviation of under a second: see "Deviations").

Nothing in the builder's folder, the other verifiers' folders, `/home/user/orbit-board` or `/home/user/orbit-ui` was edited.
Nothing was committed, staged or pushed. `mutate.mjs` was read as text only (mkmut.py, mcount.py); it was never imported or run.

## Identities (git hash-object)

| file | base (`rec/L6/base` = `base/`) | builder's c1 = my `c1/` | my proposal `prop/` |
|---|---|---|---|
| prioritization-board-grid.html | fce8a391 | 0949c3ed | 0949c3ed (unchanged) |
| tools/export-audit/audit-recon.mjs | 529e36f7 | 08c1275e | 8d36ef0a |
| tools/export-audit/mutate.mjs.txt | cbc6defc | 41c64701 | 88ec7eb6 |
| audit-import / audit-board / audit-other | 4aba2506 / a7c575e5 / d89396b0 | same | same |
| boot.mjs / runtime-encoding-shim.mjs | 9c4f49ad / 6e2ce2e6 | same | same |

`diff -rq base c1` lists only those three files; package.json and every other tool are identical. Scratch git clones:
`gc/base` (clean 7ee498a) and `gc/c1` (7ee498a plus the c1 board and audit-recon, never committed).
Focused harnesses (built verbatim with `rec/L3/u14/mkfocused.py`): `harness/h-u36.mjs` b4d3c2f4 (the block exactly as in c1,
checked line for line), `harness-prop/h-u36-prop.mjs` bb5de194 (the proposal's block).

## Verdict: sound-with-issues

The board change is correct, and every builder number I re-ran holds. **One must-fix (records; a one-sentence fix, or a
two-line code fix if the lead prefers):** the release note says the refusal's status line "stays true", and it does not
after the very correction the refusal invites. **Should-fix:** the 15-check block lets **10 of my 10** plausible wrong
fixes through, two of which bring back data loss, and its formula CONTROL cannot see a formula. A ready proposal (`prop/`)
closes the first gap: 6 checks (3 fail on the base, 3 controls) and 9 mutation entries, each caught.

## Must-fix

**M1. "The status line still says nothing was changed, which stays true" is false after the correction it invites.**
`drafts/NEXT-VERSION-entry.md`, "What users may see", third bullet. A refusal keeps the typed title in its field, marked, so
that it "can be corrected where it is" (codeRefusedIn's comment). When the person does exactly that, the corrected title is
kept, saved and drawn, but the status line keeps reading:
`⚠ RCN / EEIC title not changed. The title “CCC…” is 81 characters; it can be at most 80. Nothing was changed.`
The board says the title was not changed straight after it changed. That breaks principle (4) ("every word the board says
stays true, including after the operation lands"). It is **new with U36**: on the base the title had no refusal, so the line
stayed empty. Item 91's code refusals already behave this way on the base (an RCN refused, then corrected).
- Reproduction, jsdom (`probe/v2stale.mjs` fd7c8e67, attempt 1): c1, `logs/V2stale-c1.log` (11:39:24 AM ET, exit 0):
  `t refused then good: ["good title", "⚠ RCN / EEIC title not changed. The title “CCC…", "⚠ RCN / EEIC title not changed. The title “CCC…"]`.
  Base, `logs/V2stale-base.log` (11:39:52 AM ET, exit 0): `["good title", "", ""]`. The RCN row shows item 91 doing the same
  on both boards.
- Reproduction, real Chromium 141 (`probe/v2chrome.mjs` 6044afab, typing through the browser's own input path and Tab):
  `logs/V2chrome-c1.log` step 5 (11:32:33 AM ET, exit 0): `["good title", "⚠ RCN / EEIC title not changed. The title “CCCC…"]`;
  `logs/V2chrome-base.log` step 5: `["good title", ""]`.
- **Minimal fix (records only)**, replacing the bullet's last two sentences:
  > The status line keeps the refusal until the board's next message, and a title kept afterwards brings no message of its
  > own: after a refused title is corrected in its field, the corrected title is kept while the line still reads "RCN / EEIC
  > title not changed … Nothing was changed". Item 91's code refusals behave the same way.

  And add one line to "Not covered" (and the matrix row "Typed title over 80", Limit column): "After a refusal, the status
  line is not cleared when a corrected value is kept (titles, and item 91's codes)."
- **Alternative (code, two lines in rcnSet, before `save(); render();`)**, if the lead wants the words true rather than
  described: clear a refusal this function left, e.g.
  `const st=document.getElementById('shareStat'); if(st && /^⚠ (RCN|EEIC|RCN \/ EEIC title) not changed\./.test(st.textContent)) setStat('');`
  with a check (refuse 81 letters, then type "good title" in the same field: kept, status `''`; fails on c1) and a mutation
  that drops the line. It also changes item 91's RCN / EEIC behaviour, so it is the lead's call; I did not build it.

## Should-fix

**S1. Test gap: 10 of my 10 plausible wrong fixes pass all 15 checks** (`harness/h-u36.mjs`, `logs/V2O-*.log`, 11:01:53 to
11:04:38 AM ET, each exit 0, ALL CHECKS PASSED 15p/0f). `own/own2-mutants.json`:

| mutant (blob) | what goes wrong | why it matters |
|---|---|---|
| own2-kept-unsaved (6db15075) | a title within the limit is put in the list but neither saved nor drawn | **data loss**: the board is not marked changed and nothing is written |
| own2-display-cut (fc304e71) | the panel shows a stored title cut to 80 | **data loss**: a file's 100-character title is shown as 80, and any edit keeps the 80 (the loss the commit says U36 closes; no check covers it) |
| own2-maxlength (71243a30) | `maxlength="80"` on the title field | in Chromium 141 it brings the defect back: 81 letters become 80 and 79 letters + emoji become 79, silently (`logs/V2chrome-maxlength.log`); jsdom cannot see it. audit-board's item 91 block already checks the new-requirement form `hasAttribute('maxlength')`; this block does not |
| own2-grapheme-count (e7ff3d4e) | counted by grapheme | the released words ("a letter with a separate accent counts as several") become false |
| own2-nfc-count (f3f7d11d) | counted after NFC | the same: 41 é written with a separate accent are kept "as 41" |
| own2-refuse-empty (655d0800) | an empty title refused | clearing a title is refused as "0 characters; at most 80" |
| own2-collapse-spaces (72054247) | runs of spaces collapsed | what was typed changes without a word |
| own2-kept-not-redrawn (2c716ee8) | saved but not drawn | other views keep the old title |
| own2-grandfather (51798d89) | over 80 refused only if longer than the stored title | a file's 100-character title can be retyped as 100 other letters |
| own2-strip-controls (d38a2e90) | control characters dropped silently | a wrong U37 "fix"; **kept uncaught on purpose** (it is the lead's U37 decision) |

Round 1's 14 mutants (`own/r1-own-mutants.json`) are all caught by the final block (`logs/V2R1-*.log`, 11:09:02 to
11:13:35 AM ET, each exit 1). The builder's 8 are all caught with the same failing checks as the builder's
`out/FR-fails.txt` (`logs/V2M-*.log`).

**Proposal, ready in `prop/`** (diffs: `diffs/prop-vs-c1-audit-recon.mjs.diff`, `diffs/prop-vs-c1-mutate.mjs.txt.diff`).
Six checks added to the U36 block, same voice and helpers, expected values literals:
- *a 100-letter title from a file, retyped in the panel*: the field shows all 100; 100 other letters are refused, said as
  100 characters; the file's title is kept (fails on the base: `[true,false,null,""]`);
- *that file saved and reopened*: still the 100 letters (fails on the base: 80 M's);
- *41 letters each with a separate accent mark*: refused, said as 82 characters (fails on the base: cut to 80 code points);
- CONTROL *a title within the limit, typed in the panel*: kept, the board marked changed, its save stamp moved, the panel drawn
  again holding it, and the field has no maxlength;
- CONTROL *title cleared*: kept empty, nothing said; CONTROL *two spaces inside*: kept exactly.

Nine mutation entries (`v200-regtext-kept-unsaved`, `-kept-not-drawn`, `-field-maxlength`, `-count-glyphs`,
`-count-normalized`, `-empty-refused`, `-spaces-collapsed`, `-file-title-shown-cut`, `-long-title-retyped`), inserted after
the builder's eight, before the R3 line. mcount on the prop copy: 1345 entries, each exactly once (`out/mcount-prop-on-c1board.txt`).
Results on the proposal harness bb5de194: c1 21/21 (`VP2-c1`, 11:41:25 AM ET, exit 0); base 13 fail, 8 controls pass
(`VP2-base`, 11:42:05 AM ET, exit 1); each of the 9 new mutants caught (table under "Every run": `VP2-…count-glyphs` and the
`R3P-*` runs); own2-strip-controls passes, as intended. The builder's 8 and round 1's 14 stay caught by construction: the
proposal only adds checks after or between the existing 15, and a throw in an added check is itself recorded as a failure.

**S2. The formula CONTROL cannot see a formula, and the matrix cites it as evidence.** The block's last control ("printed in
the workbook as the very text it is (a workbook cell holds text, never a formula)") reads the RCN-EEIC by Month label, which
always begins `11111 / AAAAA  ` (rcnLabel puts the codes, or `-----`, first), so the `=` is never at the start of a cell.
`own3-formula-cells` (a4b2ac72; the XLSX writer emits `<f>` for any text cell beginning with `=`, `+`, `-` or `@`) passes all
15 checks (`R3O-own3-formula-cells`, 12:49:02 PM ET, exit 0, 15p/0f). `drafts/MATRIX-limits.md` row "Workbook formulas"
lists "block CONTROL" as evidence. Fix: drop "block CONTROL" there and the parenthesis in the block comment, or replace the
control with text that begins a cell (see `probe/r3formula.mjs` results below).

## Minor
- The draft's Test section says 79 letters plus an emoji are "kept whole on screen"; the check reads a detached input and the
  list, not anything drawn on screen.
- The refusal's preview (`inShow`) can end in half an emoji (disclosed by the builder; round 1's finding).

## Builder's claims, re-run and compared

| claim | my run | result |
|---|---|---|
| focused block: c1 15/15; base 10 fail, 5 controls pass | V2F-c1 (10:55:33 AM, exit 0), V2F-base (10:55:54 AM, exit 1) | same; the same 10 checks fail on the base |
| 8 mutants caught (7, 3, 4, 7, 1, 2, 1, 1 failing) | V2M-* (10:56:17 to 10:58:37 AM, each exit 1) | same counts and the same failing checks as `out/FR-fails.txt` |
| mcount: c1 1336/1336 once; base mutate on c1 board 1328/1328; c1 mutate on base board 1328 once, the 8 U36 ids missing | mcount-* (11:30:18 to 11:31:14 AM, text only) | same |
| 306 existing audit-recon checks keep verdict and observed value | R3S-audit-recon-base (12:45:46 PM, exit 0, 458.2 s) vs V2S-audit-recon-c1 (11:07:53 AM, exit 0, 487.4 s) | **0 differences**; 306/306 base, 321/321 c1, the 15 extra are U36's |
| audit-hostile unchanged | R3S-audit-hostile-base vs V2S-audit-hostile-c1 | see "Suites" |
| other suites pass on c1 | boot-same, audit, audit-ppt, legacy-fsrc, audit-inject, npm run check, audit-other on gc/c1 and gc/base | all exit 0 on both |
| probes vprobe / vdest / vsi / vflow / vpaste / probe-c1-type | V2-* (11:33:27 to 11:37:26 AM, each exit 0) | same results; only save timestamps in status lines differ (`out/cmp-*.txt`) |
| no existing expectation edited | `diff base c1`: audit-recon +89/-0, mutate +25/-0, board +8/-2 | true: pure additions in the suites |

## Suites, base vs c1 (scratch clones)

Run one at a time in `gc/base` (clean 7ee498a) and `gc/c1` (7ee498a plus the c1 board and audit-recon). Never the full
audit-import or audit-board (the lead's).

| suite | base | c1 |
|---|---|---|
| boot-same | V2S-boot-same-base 11:33:42 AM, exit 0, identical either way | V2S-boot-same-c1 10:59:58 AM, exit 0, identical either way |
| audit | V2S-audit-base 11:34:29 AM, exit 0, ALL CHECKS PASSED | V2S-audit-c1 11:00:36 AM, exit 0, ALL CHECKS PASSED |
| audit-ppt | V2S-audit-ppt-base 11:35:16 AM, exit 0, pass | V2S-audit-ppt-c1 11:01:15 AM, exit 0, pass |
| legacy-fsrc | V2S-legacy-fsrc-base 11:35:41 AM, exit 0 | V2S-legacy-fsrc-c1 11:01:33 AM, exit 0 |
| audit-inject | V2S-audit-inject-base 11:35:59 AM, exit 0, pass | V2S-audit-inject-c1 11:01:44 AM, exit 0, pass |
| npm run check | V2S-check-base 11:37:04 AM, exit 0, all checks passed | V2S-check-c1 11:02:26 AM, exit 0, all checks passed |
| audit-other | V2S-audit-other-base 11:38:19 AM, exit 0, pass | V2S-audit-other-c1 11:05:33 AM, exit 0, pass |
| audit-recon | **R3S-audit-recon-base 12:45:46 PM, exit 0, 458.2 s, 306/306** | V2S-audit-recon-c1 11:07:53 AM, exit 0, 487.4 s, 321/321 |
| audit-hostile | **R3S-audit-hostile-base 12:53:33 PM, exit 0, 230.7 s, 124/124** | V2S-audit-hostile-c1 11:30:06 AM, exit 0, 124/124 |

Check by check (`bin/cmpchecks.py`, every SUITE_CHECKS line [scenario, where, what, verdict, observed]): audit-recon, 0
checks only in the base, 15 only in c1 (all U36's), **0 with a different verdict or observed value**; audit-hostile, 0 / 0 / 0.
Attempt 1's base audit-recon (`V2S-audit-recon-base`, started 11:42:02 AM) has no exit record (stopped by the lead) and is
superseded by R3S-audit-recon-base. As a cross-check, c1's streams also match round 1's base streams
(`verify-tests-r1/out/VSC-audit-*-base.checks.jsonl`) with 0 differences.

## The formula probe (S2)
`probe/r3formula.mjs` (1d4cf8c6). Text that begins a cell: an RCN typed as "=1+1" (kept, 4 characters; RCN text is warned
about, never blocked) in the Spend Plan Source, and a requirement titled "+3+3" in the workbook. Each zip part is read from the
bytes and counted for `<f>`.
- c1 (R3F-formula-c1, 12:55:07 PM, exit 0) and base (R3F-formula-base, 12:55:33 PM, exit 0): `[0 <f>, 0 compressed parts, the
  cell read back as that text]` in both workbooks, as expected.
- own3-formula-cells (R3F-formula-own3, 12:55:21 PM, exit 0): Spend Plan Source **2** `<f>`, workbook **8** `<f>` (DIFFERS).
  The same mutant passes all 15 checks of the U36 block. A control built this way would catch it; the block's does not.

## Literals, and fails-on-the-base
- Every expected value in the 15 checks is a literal or built from the test's own literal inputs (`'A'.repeat(60)`, `E80`,
  the `no()` sentence template). Board helpers appear only on the observed side (rcnSet, w6Book / xlsxRead, rcnReg,
  buildSavedHtml).
- 10 of the 15 fail on the base (V2F-base), each for the defect it names (cut to 80, unmarked, nothing said, half an emoji,
  the field redrawn). The other 5 are labelled CONTROL and pass on both, which is the house style (round 1 noted the same).
- The block follows the v2.00 house shape: async wrapper, bootMark / `bootRelease(__bm, [])` / settleBoards (what every
  audit-recon v2.00 block uses), the two-space `  const name = '…';` line, and the `// ====` markers.
- The 8 mutation entries are `{ id, area, what, find, repl }`, ids `v200-regtext-*`, before the R3 line; mcount on c1: 1336
  entries, each exactly once; the base's 1328 still match once on the c1 board.
- No existing check, fixture or expected value was edited: the suite diffs are pure additions (audit-recon +89/-0,
  mutate.mjs.txt +25/-0).

## Every run
Attempt 1's runs are reused where they have an exit record and their blobs are the ones above (board, harness and probe
blobs are in each log's IDS line). Two attempt-1 runs have no exit record and were re-run: `V2S-audit-recon-base`
(re-run as R3S-audit-recon-base) and `VP2-v200-regtext-count-normalized` (re-run as R3P-count-normalized). The proposal
mutants of attempt 1's first proposal harness (`VP-*`, harness 906c9de8) are superseded by `VP2-*` / `R3P-*` on the final
proposal harness bb5de194. Runs of attempt 1 named `VP-*`, `VPR1-*` stand only as history.

| label | start (ET, 13 Oct) | exit | wall s | log | result |
|---|---|---|---|---|---|
| V2F-c1 | 10:55:33 | 0 | 20.2 | logs/V2F-c1.log | ALL CHECKS PASSED (15p/0f) |
| V2F-base | 10:55:54 | 1 | 23.3 | logs/V2F-base.log | 10 FAILING CHECK(S) (5p/10f) |
| V2M-title-no-limit | 10:56:17 | 1 | 22.7 | logs/V2M-title-no-limit.log | 7 FAILING CHECK(S) (8p/7f) |
| V2M-title-cut | 10:56:40 | 1 | 21.4 | logs/V2M-title-cut.log | 3 FAILING CHECK(S) (12p/3f) |
| V2M-title-halves | 10:57:02 | 1 | 19.3 | logs/V2M-title-halves.log | 4 FAILING CHECK(S) (11p/4f) |
| V2M-refused-but-kept | 10:57:21 | 1 | 21.9 | logs/V2M-refused-but-kept.log | 7 FAILING CHECK(S) (8p/7f) |
| V2M-field-unmarked | 10:57:44 | 1 | 17.6 | logs/V2M-field-unmarked.log | 1 FAILING CHECK(S) (14p/1f) |
| V2M-count-untrimmed | 10:58:01 | 1 | 19.1 | logs/V2M-count-untrimmed.log | 2 FAILING CHECK(S) (13p/2f) |
| V2M-preview-untrimmed | 10:58:21 | 1 | 16.1 | logs/V2M-preview-untrimmed.log | 1 FAILING CHECK(S) (14p/1f) |
| V2M-refused-but-saved | 10:58:37 | 1 | 17.8 | logs/V2M-refused-but-saved.log | 1 FAILING CHECK(S) (14p/1f) |
| V2S-boot-same-c1 | 10:59:58 | 0 | 37.6 | logs/V2S-boot-same-c1.log | every page, source, save and error list is identical either way |
| V2S-audit-c1 | 11:00:36 | 0 | 39.4 | logs/V2S-audit-c1.log | ALL CHECKS PASSED |
| V2S-audit-ppt-c1 | 11:01:15 | 0 | 17.6 | logs/V2S-audit-ppt-c1.log | ALL CHECKS PASSED |
| V2S-legacy-fsrc-c1 | 11:01:33 | 0 | 11.3 | logs/V2S-legacy-fsrc-c1.log | exit 0 (prints no summary line) |
| V2O-kept-unsaved | 11:01:53 | 0 | 13.1 | logs/V2O-kept-unsaved.log | ALL CHECKS PASSED (15p/0f) |
| V2O-kept-not-redrawn | 11:02:06 | 0 | 14.0 | logs/V2O-kept-not-redrawn.log | ALL CHECKS PASSED (15p/0f) |
| V2S-audit-inject-c1 | 11:01:44 | 0 | 41.7 | logs/V2S-audit-inject-c1.log | ALL CHECKS PASSED |
| V2O-maxlength | 11:02:21 | 0 | 16.2 | logs/V2O-maxlength.log | ALL CHECKS PASSED (15p/0f) |
| V2S-check-c1 | 11:02:26 | 0 | 12.1 | logs/V2S-check-c1.log | all checks passed |
| V2O-grapheme-count | 11:02:37 | 0 | 17.2 | logs/V2O-grapheme-count.log | ALL CHECKS PASSED (15p/0f) |
| V2O-nfc-count | 11:02:55 | 0 | 16.5 | logs/V2O-nfc-count.log | ALL CHECKS PASSED (15p/0f) |
| V2O-refuse-empty | 11:03:11 | 0 | 15.7 | logs/V2O-refuse-empty.log | ALL CHECKS PASSED (15p/0f) |
| V2O-collapse-spaces | 11:03:27 | 0 | 18.2 | logs/V2O-collapse-spaces.log | ALL CHECKS PASSED (15p/0f) |
| V2O-strip-controls | 11:03:46 | 0 | 16.8 | logs/V2O-strip-controls.log | ALL CHECKS PASSED (15p/0f) |
| V2O-display-cut | 11:04:03 | 0 | 17.4 | logs/V2O-display-cut.log | ALL CHECKS PASSED (15p/0f) |
| V2O-grandfather | 11:04:20 | 0 | 17.2 | logs/V2O-grandfather.log | ALL CHECKS PASSED (15p/0f) |
| V2S-audit-other-c1 | 11:05:33 | 0 | 139.5 | logs/V2S-audit-other-c1.log | ALL CHECKS PASSED |
| VP-c1 | 11:07:30 | 0 | 33.3 | logs/VP-c1.log | ALL CHECKS PASSED (21p/0f) |
| VP-base | 11:08:03 | 1 | 39.2 | logs/VP-base.log | 13 FAILING CHECK(S) (8p/13f) |
| V2R1-own-count-before-trim | 11:09:02 | 1 | 21.2 | logs/V2R1-own-count-before-trim.log | 2 FAILING CHECK(S) (13p/2f) |
| V2R1-own-cut-by-codepoint | 11:09:23 | 1 | 27.0 | logs/V2R1-own-cut-by-codepoint.log | 7 FAILING CHECK(S) (8p/7f) |
| V2R1-own-field-cleared | 11:09:51 | 1 | 22.6 | logs/V2R1-own-field-cleared.log | 5 FAILING CHECK(S) (10p/5f) |
| V2R1-own-limit-81 | 11:10:14 | 1 | 25.1 | logs/V2R1-own-limit-81.log | 6 FAILING CHECK(S) (9p/6f) |
| V2R1-own-off-by-one | 11:10:39 | 1 | 17.2 | logs/V2R1-own-off-by-one.log | 5 FAILING CHECK(S) (10p/5f) |
| V2R1-own-preview-untrimmed | 11:10:57 | 1 | 18.9 | logs/V2R1-own-preview-untrimmed.log | 1 FAILING CHECK(S) (14p/1f) |
| V2R1-own-redraw-after-refusal | 11:11:16 | 1 | 26.5 | logs/V2R1-own-redraw-after-refusal.log | 1 FAILING CHECK(S) (14p/1f) |
| V2R1-own-refuse-then-save | 11:11:43 | 1 | 20.5 | logs/V2R1-own-refuse-then-save.log | 1 FAILING CHECK(S) (14p/1f) |
| V2R1-own-says-halves | 11:12:03 | 1 | 16.3 | logs/V2R1-own-says-halves.log | 1 FAILING CHECK(S) (14p/1f) |
| V2R1-own-silent-refusal | 11:12:20 | 1 | 18.1 | logs/V2R1-own-silent-refusal.log | 4 FAILING CHECK(S) (11p/4f) |
| V2R1-own-title-cleared-on-refusal | 11:12:38 | 1 | 17.3 | logs/V2R1-own-title-cleared-on-refusal.log | 7 FAILING CHECK(S) (8p/7f) |
| V2R1-own-unmarked | 11:12:56 | 1 | 18.2 | logs/V2R1-own-unmarked.log | 5 FAILING CHECK(S) (10p/5f) |
| V2R1-own-untrimmed-store | 11:13:14 | 1 | 19.9 | logs/V2R1-own-untrimmed-store.log | 2 FAILING CHECK(S) (13p/2f) |
| V2R1-own-utf8-bytes | 11:13:35 | 1 | 18.9 | logs/V2R1-own-utf8-bytes.log | 4 FAILING CHECK(S) (11p/4f) |
| VP-v200-regtext-count-glyphs | 11:13:59 | 1 | 31.9 | logs/VP-v200-regtext-count-glyphs.log | 1 FAILING CHECK(S) (20p/1f) |
| VP-v200-regtext-count-normalized | 11:14:31 | 1 | 33.1 | logs/VP-v200-regtext-count-normalized.log | 1 FAILING CHECK(S) (20p/1f) |
| VP-v200-regtext-empty-refused | 11:15:04 | 1 | 29.1 | logs/VP-v200-regtext-empty-refused.log | 1 FAILING CHECK(S) (20p/1f) |
| V2S-audit-recon-c1 | 11:07:53 | 0 | 487.4 | logs/V2S-audit-recon-c1.log | ALL CHECKS PASSED; 321/321 (306 + 15 U36) |
| VP-v200-regtext-field-maxlength | 11:15:34 | 1 | 30.0 | logs/VP-v200-regtext-field-maxlength.log | 1 FAILING CHECK(S) (20p/1f) |
| VP-v200-regtext-file-title-shown-cut | 11:16:04 | 1 | 25.8 | logs/VP-v200-regtext-file-title-shown-cut.log | 1 FAILING CHECK(S) (20p/1f) |
| VP-v200-regtext-kept-not-drawn | 11:16:30 | 1 | 24.3 | logs/VP-v200-regtext-kept-not-drawn.log | 1 FAILING CHECK(S) (20p/1f) |
| VP-v200-regtext-kept-unsaved | 11:16:54 | 1 | 20.5 | logs/VP-v200-regtext-kept-unsaved.log | 1 FAILING CHECK(S) (20p/1f) |
| VP-v200-regtext-long-title-retyped | 11:17:15 | 1 | 25.8 | logs/VP-v200-regtext-long-title-retyped.log | 2 FAILING CHECK(S) (19p/2f) |
| VP-v200-regtext-spaces-collapsed | 11:17:42 | 1 | 25.1 | logs/VP-v200-regtext-spaces-collapsed.log | 1 FAILING CHECK(S) (20p/1f) |
| VP-own2-strip-controls | 11:18:07 | 0 | 26.7 | logs/VP-own2-strip-controls.log | ALL CHECKS PASSED (21p/0f) |
| VP-v200-regtext-count-untrimmed | 11:18:34 | 1 | 28.0 | logs/VP-v200-regtext-count-untrimmed.log | 2 FAILING CHECK(S) (19p/2f) |
| VP-v200-regtext-field-unmarked | 11:19:02 | 1 | 29.1 | logs/VP-v200-regtext-field-unmarked.log | 2 FAILING CHECK(S) (19p/2f) |
| VP-v200-regtext-preview-untrimmed | 11:19:32 | 1 | 65.9 | logs/VP-v200-regtext-preview-untrimmed.log | 1 FAILING CHECK(S) (20p/1f) |
| VP-v200-regtext-refused-but-kept | 11:20:38 | 1 | 39.1 | logs/VP-v200-regtext-refused-but-kept.log | 10 FAILING CHECK(S) (11p/10f) |
| VP-v200-regtext-refused-but-saved | 11:21:18 | 1 | 29.3 | logs/VP-v200-regtext-refused-but-saved.log | 1 FAILING CHECK(S) (20p/1f) |
| VP-v200-regtext-title-cut | 11:21:47 | 1 | 30.7 | logs/VP-v200-regtext-title-cut.log | 3 FAILING CHECK(S) (18p/3f) |
| VP-v200-regtext-title-halves | 11:22:18 | 1 | 33.9 | logs/VP-v200-regtext-title-halves.log | 4 FAILING CHECK(S) (17p/4f) |
| VP-v200-regtext-title-no-limit | 11:22:53 | 1 | 31.6 | logs/VP-v200-regtext-title-no-limit.log | 10 FAILING CHECK(S) (11p/10f) |
| VPR1-own-count-before-trim | 11:23:32 | 1 | 25.5 | logs/VPR1-own-count-before-trim.log | 2 FAILING CHECK(S) (19p/2f) |
| VPR1-own-cut-by-codepoint | 11:23:58 | 1 | 28.6 | logs/VPR1-own-cut-by-codepoint.log | 10 FAILING CHECK(S) (11p/10f) |
| VPR1-own-field-cleared | 11:24:27 | 1 | 26.4 | logs/VPR1-own-field-cleared.log | 6 FAILING CHECK(S) (15p/6f) |
| VPR1-own-limit-81 | 11:24:53 | 1 | 29.4 | logs/VPR1-own-limit-81.log | 6 FAILING CHECK(S) (15p/6f) |
| VPR1-own-off-by-one | 11:25:23 | 1 | 25.6 | logs/VPR1-own-off-by-one.log | 5 FAILING CHECK(S) (16p/5f) |
| VPR1-own-preview-untrimmed | 11:25:49 | 1 | 28.7 | logs/VPR1-own-preview-untrimmed.log | 1 FAILING CHECK(S) (20p/1f) |
| VPR1-own-redraw-after-refusal | 11:26:18 | 1 | 35.5 | logs/VPR1-own-redraw-after-refusal.log | 1 FAILING CHECK(S) (20p/1f) |
| VPR1-own-refuse-then-save | 11:26:53 | 1 | 29.2 | logs/VPR1-own-refuse-then-save.log | 1 FAILING CHECK(S) (20p/1f) |
| VPR1-own-says-halves | 11:27:23 | 1 | 22.4 | logs/VPR1-own-says-halves.log | 1 FAILING CHECK(S) (20p/1f) |
| VPR1-own-silent-refusal | 11:27:46 | 1 | 25.8 | logs/VPR1-own-silent-refusal.log | 6 FAILING CHECK(S) (15p/6f) |
| VPR1-own-title-cleared-on-refusal | 11:28:12 | 1 | 23.4 | logs/VPR1-own-title-cleared-on-refusal.log | 10 FAILING CHECK(S) (11p/10f) |
| VPR1-own-unmarked | 11:28:35 | 1 | 26.4 | logs/VPR1-own-unmarked.log | 7 FAILING CHECK(S) (14p/7f) |
| VPR1-own-untrimmed-store | 11:29:02 | 1 | 25.6 | logs/VPR1-own-untrimmed-store.log | 2 FAILING CHECK(S) (19p/2f) |
| VPR1-own-utf8-bytes | 11:29:28 | 1 | 27.0 | logs/VPR1-own-utf8-bytes.log | 5 FAILING CHECK(S) (16p/5f) |
| V2chrome-c1 | 11:32:33 | 0 | 9.6 | logs/V2chrome-c1.log | probe, see the log |
| V2chrome-maxlength | 11:32:51 | 0 | 8.6 | logs/V2chrome-maxlength.log | probe, see the log |
| V2chrome-base | 11:33:00 | 0 | 9.9 | logs/V2chrome-base.log | probe, see the log |
| V2S-audit-hostile-c1 | 11:30:06 | 0 | 215.7 | logs/V2S-audit-hostile-c1.log | ALL CHECKS PASSED; 124/124 |
| V2-vprobe-c1 | 11:33:27 | 0 | 37.6 | logs/V2-vprobe-c1.log | probe, see the log |
| V2S-boot-same-base | 11:33:42 | 0 | 46.5 | logs/V2S-boot-same-base.log | every page, source, save and error list is identical either way |
| V2-vdest-c1 | 11:34:05 | 0 | 28.2 | logs/V2-vdest-c1.log | probe, see the log |
| V2-vsi-c1 | 11:34:33 | 0 | 19.0 | logs/V2-vsi-c1.log | probe, see the log |
| V2-vflow-c1 | 11:34:52 | 0 | 17.1 | logs/V2-vflow-c1.log | probe, see the log |
| V2S-audit-base | 11:34:29 | 0 | 47.3 | logs/V2S-audit-base.log | ALL CHECKS PASSED |
| V2S-audit-ppt-base | 11:35:16 | 0 | 25.0 | logs/V2S-audit-ppt-base.log | ALL CHECKS PASSED |
| V2S-legacy-fsrc-base | 11:35:41 | 0 | 17.2 | logs/V2S-legacy-fsrc-base.log | exit 0 (prints no summary line) |
| V2-vprobe-base | 11:35:09 | 0 | 50.4 | logs/V2-vprobe-base.log | probe, see the log |
| V2-vdest-base | 11:36:00 | 0 | 35.0 | logs/V2-vdest-base.log | probe, see the log |
| V2-vsi-base | 11:36:35 | 0 | 21.2 | logs/V2-vsi-base.log | probe, see the log |
| V2S-audit-inject-base | 11:35:59 | 0 | 64.6 | logs/V2S-audit-inject-base.log | ALL CHECKS PASSED |
| V2-vflow-base | 11:36:56 | 0 | 23.7 | logs/V2-vflow-base.log | probe, see the log |
| V2S-check-base | 11:37:04 | 0 | 20.5 | logs/V2S-check-base.log | all checks passed |
| V2-vpaste-chromium | 11:37:20 | 0 | 5.7 | logs/V2-vpaste-chromium.log | probe, see the log |
| V2-probe-c1-type | 11:37:26 | 0 | 45.7 | logs/V2-probe-c1-type.log | probe, see the log |
| V2stale-c1 | 11:39:24 | 0 | 27.7 | logs/V2stale-c1.log | probe, see the log |
| V2stale-base | 11:39:52 | 0 | 16.3 | logs/V2stale-base.log | probe, see the log |
| V2S-audit-other-base | 11:38:19 | 0 | 223.3 | logs/V2S-audit-other-base.log | ALL CHECKS PASSED |
| VP2-c1 | 11:41:25 | 0 | 39.5 | logs/VP2-c1.log | ALL CHECKS PASSED (21p/0f) |
| VP2-base | 11:42:05 | 1 | 48.6 | logs/VP2-base.log | 13 FAILING CHECK(S) (8p/13f) |
| VP2-v200-regtext-count-glyphs | 11:42:54 | 1 | 40.0 | logs/VP2-v200-regtext-count-glyphs.log | 1 FAILING CHECK(S) (20p/1f) |
| *resume attempt started 2026-10-13 12:45:46 EDT* | | | | | |
| R3O-own3-formula-cells | 12:49:02 | 0 | 18.3 | logs/R3O-own3-formula-cells.log | ALL CHECKS PASSED (15p/0f) |
| R3P-count-normalized | 12:49:51 | 1 | 32.2 | logs/R3P-count-normalized.log | 1 FAILING CHECK(S) (20p/1f) |
| R3P-empty-refused | 12:50:23 | 1 | 34.6 | logs/R3P-empty-refused.log | 1 FAILING CHECK(S) (20p/1f) |
| R3P-field-maxlength | 12:50:58 | 1 | 28.4 | logs/R3P-field-maxlength.log | 1 FAILING CHECK(S) (20p/1f) |
| R3P-file-title-shown-cut | 12:51:27 | 1 | 37.3 | logs/R3P-file-title-shown-cut.log | 1 FAILING CHECK(S) (20p/1f) |
| R3P-kept-not-drawn | 12:52:04 | 1 | 25.1 | logs/R3P-kept-not-drawn.log | 1 FAILING CHECK(S) (20p/1f) |
| R3P-kept-unsaved | 12:52:30 | 1 | 30.9 | logs/R3P-kept-unsaved.log | 1 FAILING CHECK(S) (20p/1f) |
| R3S-audit-recon-base | 12:45:46 | 0 | 458.2 | logs/R3S-audit-recon-base.log | ALL CHECKS PASSED; 306/306; 0 differences against c1 |
| R3P-long-title-retyped | 12:53:01 | 1 | 35.8 | logs/R3P-long-title-retyped.log | 2 FAILING CHECK(S) (19p/2f) |
| R3P-spaces-collapsed | 12:53:37 | 1 | 35.9 | logs/R3P-spaces-collapsed.log | 1 FAILING CHECK(S) (20p/1f) |
| R3P-own2-strip-controls | 12:54:13 | 0 | 36.0 | logs/R3P-own2-strip-controls.log | ALL CHECKS PASSED (21p/0f) |
| R3F-formula-c1 | 12:55:07 | 0 | 13.5 | logs/R3F-formula-c1.log | 0 <f> in both workbooks; the "=1+1" and "+3+3" cells read back as text (OK) |
| R3F-formula-own3 | 12:55:21 | 0 | 12.1 | logs/R3F-formula-own3.log | Spend Plan Source 2 <f>, workbook 8 <f> (DIFFERS: the probe sees the mutant) |
| R3F-formula-base | 12:55:33 | 0 | 12.4 | logs/R3F-formula-base.log | 0 <f> in both workbooks; the "=1+1" and "+3+3" cells read back as text (OK) |
| R3S-audit-hostile-base | 12:53:33 | 0 | 230.7 | logs/R3S-audit-hostile-base.log | ALL CHECKS PASSED; 124/124; 0 differences against c1 |

## PIDs
`pids.txt` holds every bounded process with its command: the `timeout` PID and its child, the time (ET) and the label.
Attempt 2's entries follow the line "=== resume attempt (this session) started …". I killed nothing; at about 12:57 PM ET
none of the PIDs recorded in this session was alive (`ps -p` on each). PIDs from attempt 1 that `ps` still finds belong to
other processes now (PID reuse; for example 30878 was a 3-second-old `sleep 10` at 12:41 PM ET) and were left alone.

## Decisions, with reasons
- **M1 is a must-fix, on the records.** The lead's principle (4) covers words "after the operation lands", and the draft states
  the opposite of what Chromium shows. A one-sentence correction closes it. The code alternative is offered, not built,
  because it also changes item 91's RCN / EEIC behaviour, which is the lead's call.
- **S1 is a should-fix, not a must-fix,** although two survivors bring back data loss. The committed board code is right,
  every rule for new checks and mutations is met (each new non-control check fails on the base; each new mutation is
  caught), and round 1 graded the same kind of gap as should-fix. The proposal is ready to adopt unchanged.
- **own2-strip-controls stays uncaught on purpose:** dropping control characters may be the right U37 fix, and that choice
  belongs to the lead.
- **S2 is a should-fix:** the matrix cites a control as evidence for something it cannot see. No board defect was found:
  in my probe no workbook part holds an `<f>` on c1 or the base.

## Deviations
- At 12:52 PM ET I ran `node --check probe/r3formula.mjs` (syntax only, under a second) outside run.sh: no lock check, no
  600 s bound, PID not recorded. For that moment it was a third node process beside my two runs. Recorded in pids.txt.
- Small read-only commands (ls, cat, grep, diff, git hash-object, python text helpers that read files) were not all bounded.
  Every node and Chromium run went through run.sh (600 s cap, lock check, PIDs recorded). The lock was never present.

## Not done
- I did not run the full audit-import or audit-board (the lead's). The focused U36 block runs inside audit-recon only.
- I did not import, execute or run mutate.mjs; full-suite mutation sensitivity is for the final-tree queue.
- I did not run the Chromium verify:grid tools. By reading, no tool outside export-audit refers to rcnSet or the title field.
- I did not build the M1 code alternative or the S2 replacement control into a suite; the probe shows such a control works.
- I did not open any workbook in Excel or LibreOffice.
- I did not edit, stage, commit or push anything in /home/user/orbit-board or /home/user/orbit-ui, or anything in the
  builder's folder. gc/base and gc/c1 are scratch clones, never committed.

README finished at about 12:58 PM ET.
