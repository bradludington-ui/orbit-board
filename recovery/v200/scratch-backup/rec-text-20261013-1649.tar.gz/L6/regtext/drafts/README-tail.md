## Drafts for the lead
- `drafts/NEXT-VERSION-entry.md`: the v2.00 entry, in the U13/U1/U14 style, to go after the U14 bullet. It holds what was
  wrong, what changes, "What users may see", "Test", "Mutations", and "Not covered" with every limit.
- `drafts/UNRESOLVED-line.md`: "Unresolved after R1–R5" has NO line for U35 on the base, or at orbit-board `60336a0`
  (searched). This is a proposed NEW line after the U14 line, not a replacement.
- `drafts/LEDGER-append.md`: text to append to row U35, and new rows U36–U41 for `recovery/v200/UNRESOLVED-LEDGER.md`
  (rows exist up to U35 at `60336a0`), with `<sha>` and `<time>` placeholders. The numbers U36–U41 are placeholders too.
- `drafts/MATRIX-limits.md`: the evidence-matrix rows. Each question has its answer on the base, its evidence, and its
  limit (what is not established).
- `drafts/COMMIT-MSG.txt`: the commit message. The attribution lines are the lead's to add.

## PIDs
`pids.txt` holds every timeout PID and its child, recorded by `bin/run.sh` and `bin/bx.sh` with the command. It also holds
the background batch: bash 23472 (my shell), setsid 23474 and timeout 23475, which ran `bin/suites-both.sh` with a 7,000 s
cap around 600 s runs. I killed nothing. Every run ended on its own (exit codes above), and none hit its 600 s cap.

## What I did NOT do
- **Fix U37–U41.** They are open, with their limits stated; reasons are under Decisions.
- **Run the full `audit-import.mjs` or `audit-board.mjs`** (the lead's). By reading:
  - audit-board calls `rcnSet` only with `'rcn'` and `'eeic'` (lines 4063, 4112, 4145). audit-recon line 4075 does the same,
    and it ran whole here.
  - No tool in `tools/` types a title or uses the title field (searched for `what this line funds`, `rcnSet(…'t'` and
    `&quot;t&quot;`). layout-fits opens the panel only for layout, and the change adds no element.
  - No import path is touched, so no focused audit-import harness was run.
- **Import, execute or run `mutate.mjs`.** It was read as text only (`mcount.py` / `mkmut.py`). The scratch clones keep the
  repository's own `mutate.mjs` untouched and unrun.
- **Edit, stage, commit or push** anything in /home/user/orbit-board or /home/user/orbit-ui. The scratch clones (`gc/base`,
  `gc/c1`, `git clone --shared`, checked out at `7ee498a`) were never committed to.
- **Install playwright or run Chromium.** Every check is jsdom. Chromium's hostile-render with registry text planted was not
  run.
- **Change the board file** from the empty template. Synthetic data exists only at run time.
- **Check:**
  - Excel or LibreOffice opening a workbook with a forbidden character (U37), or a 32,767-character cell;
  - a real browser's paste of control characters into a field;
  - a PDF;
  - BAE budget names, beyond the existing hostile sweep;
  - a file carrying an unknown SI code (U41 was measured through `applyState`).
- **Count a ZWJ emoji sequence (one glyph, several code points) as one character.** The new limit counts Unicode code
  points, so such a sequence counts as several. `inShow` (the board's existing helper) cuts its quoted preview at 60 UTF-16
  units, so a preview can end in half an emoji. That is in the status line only, and nothing is stored.

## Notes on the runs (read before trusting a line above)
- **Suites: base and c1 match.** Every allowed suite passes on both, and so does `npm run check`. boot-same, legacy-fsrc
  and check print their own pass lines in both logs ("every page, source, save and error list is identical either way",
  "every legacy Force setting computes exactly as before", "all checks passed"). audit, audit-ppt, audit-other,
  audit-recon, audit-hostile and audit-inject print ALL CHECKS PASSED on both. audit-recon on c1 includes the new block,
  and its scenario-ran guard passed. The clones were checked after the batch: `gc/c1` differs from `7ee498a` only in the
  board (55b2973d) and audit-recon (cf65a9e6); `gc/base` is clean. Neither has a commit beyond `7ee498a`.
- **F1-c1 and F1-base used the first harness** (blob 5f0076e6). Its block said "9 of its 13 checks" in the FAILS ON comment.
  That comment was corrected to "8 of its 12" (a comment-only edit, `blocks/block-regtext.mjs.txt` now a9d4a1bc). The
  harness was rebuilt verbatim (4d886573), and **F2-* and the M-* runs used the final harness**: c1 12/12; base 4 pass and 8
  fail; every mutant caught.
- **The probe was edited after the base probes ran.**
  - Section 4's printed header said "… and in a PPBE line's codes" when it ran (`logs/probe-base-sweep.log`). **No PPBE line
    was planted**; the header was wrong, and it now reads "(rcn, eeic, t)" only.
  - Section 5 (`more`) was appended afterwards and ran as `probe-base-more`.
  - Sections 1–3 are unchanged since `probe-base-type`, `-file` and `-ctl` ran. `probe-c1-type` ran the current probe
    (blob 9c701174).
- **The AUDIT_IMPORT_RUNNING lock was never present**, so no run waited.
- **Deviations from "every command bounded by setsid -w timeout -k 10 600":**
  - The first looks at files (ls, cat, grep, sed, git log in /home/user/orbit-board, read only) were unbounded shell
    commands.
  - The diff, cp and git hash-object commands were unbounded.
  - The background batch wrapper had a 7,000 s cap around many 600 s runs.
  - The Monitor wait loop (5 s polls on a file and on PID 23475) was capped at 30 minutes by the tool.
  - Every node run itself went through `run.sh`, and every python text helper through `bx.sh`.
