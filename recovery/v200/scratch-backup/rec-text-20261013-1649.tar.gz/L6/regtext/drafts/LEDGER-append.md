# Ledger text for recovery/v200/UNRESOLVED-LEDGER.md

Fix round 2, 13 Oct (from 1:29 PM ET). Read at orbit-board 191daf0 (13 Oct, 1:43 PM ET, read-only): rows U36–U42 already
exist (the lead recorded them from this track's round-1 drafts), and U35 now holds Codex's A1 finding (a Live refresh
replacing uncommitted registry input), deferred past v2.00 by the lead. So this file no longer drafts new rows. It gives the
text to APPEND to existing rows. The round-1 "append to U35" text is withdrawn: that row is no longer the registry-text
placeholder, and its own History sentence already says where U36–U42 came from.

Placeholders: `<sha>` is the commit, `<time>` the time it is made (ET). Logs are under `rec/L6/regtext/logs/`.

## U36: append to the Status cell (it reads "Fix drafted, in review")

**Fixed by `<sha>` (`<time>`).** A typed title over 80 characters is refused, as item 91 does for codes: the list keeps what
it had, the field keeps what was typed, marked, the status says "RCN / EEIC title not changed", and nothing is saved. Counted
by Unicode code point (a joined emoji, a flag or a letter with a separate accent counts as several). Fix round 2 (second
reviews, 13 Oct): once a value is kept in the list (the title corrected in its field, or an RCN or EEIC kept in any row), the
title's refusal leaves the status line, so the line never says "not changed" of a title just changed (round-2 test review,
must-fix M1; three lines in `rcnSet`, after `save(); render();`, so anything save() says stands). Item 91's own code
refusals are left as they were: a refused and then corrected RCN or EEIC still leaves "RCN not changed" on the line until
the next message (a limit, stated in NEXT-VERSION.md). audit-recon block "v2.00 (U36)": 24/24 after the fix
(`FR2-F-c1`, 1:39 PM ET, 13 Oct); 14 fail before it (`FR2-F-base`); the 10 controls pass on both; on the round-1 board
exactly the stale-status check fails (`FR2-F-fr1`). 20 mutations, each caught (`FR2-M-*`, 1:41–1:54 PM ET). The 306 existing
audit-recon checks keep their verdicts and observed values (`FR2-SC3-audit-recon-fr2`, 2:46 PM ET, 13 Oct: 330/330, the 24
extra being U36's; see the track README).

## U37: append to the Evidence cell

**The slide deck too (regtext round-2 money review, re-run by the track, 13 Oct, 1:57–1:58 PM ET; `logs/FR2-v2probe-base.log`,
`logs/FR2-v2probe-c1.log`, the verifier's `probe/v2.mjs` section 4).** A Plan Event typed through the board's own prompt
(`editTitle`) as "Plan\u000Bevent", on a requirement made Mission Critical, is written raw into `ppt/slides/slide5.xml` by
exportPPT (one occurrence), so that slide part is not well-formed either; the same character goes into workbook sheets 2, 4,
7 and 11. The slide writer is the same `_xesc` (`_pRun`). A fix must cover both writers: escaping in `_xesc` covers both;
refusing and naming the cell (as `IDS_BADCH`) must be added to exportPPT as well. (The lead's 1:19 PM ET note already
records this for the u37 track.)

## U38: append to the Evidence and Status cells

Evidence: **The Spend Plan Source prints such codes as stored (regtext round-2 money review, re-run by the track, 13 Oct,
1:57–1:58 PM ET; `logs/FR2-v2probe-base.log` and `-c1.log`, section 3).** A file's RCN " 44444 " and EEIC " ddddd " are kept as
they arrived, `codeIssues()` returns `[]` (Pre-flight says nothing; Needs attention skips board-level lists), and exportSrc
prints " ddddd " and " 44444 " in `xl/worksheets/sheet1.xml`, padded and in lower case; RCN-EEIC by Month prints
" 44444  /  ddddd   pad". Pre-flight's own reason for flagging over-long codes ("the exports print them as they are, so CCaR
may not match them") applies to these too.

Status: **P2 proposed for the Spend Plan Source** (the file that goes to CCaR is not exactly what typing would give, and
nothing says so); P3 for the board's own views. "Nothing compares RCN or EEIC text, so no money moves" is true inside the
board only. Candidate: list padded, lower-case or over-long-once-upper-cased codes beside Pre-flight's "Codes longer than
their limit". Not fixed by this track.

## U42: append to the Evidence cell

**The same cut in the slide deck (regtext round-2 money review; re-run by the track, 13 Oct, 1:57–1:58 PM ET,
`logs/FR2-v2probe-*.log` section 5).** The slide tables cut a requirement title with `dispTitle(it).slice(0,56)` (board
lines 25146 and 25164 of the U36 copy), by UTF-16 unit: a Plan Event of 55 letters and an emoji prints in
`ppt/slides/slide5.xml` as 55 letters and U+FFFD. Not registry text, but the same pattern; a fix of U42's cut should cover it.
By code only: `buildXlsx` cuts every sheet name with `.slice(0,31)`, so any sheet name over 31 UTF-16 units has the same
risk; exportFlow's 28-unit cut keeps funds-flow names from reaching it.

## U35, U39, U40, U41: nothing new from this round
