<!-- "Unresolved after R1–R5 (11 Oct)" has no line for the registry-text review at 7ee498a, or at orbit-board 191daf0 (read
     13 Oct, about 2:20 PM ET; NEXT-VERSION.md there names none of U35–U42). This is a NEW line, to go after the U14 line. It
     replaces nothing. Fix round, 13 Oct: U37 is P1, U40 is data loss, U41 was measured through a file, U42 is new, and the
     routes not followed are named. Fix round 2: U37 names the slide deck; U38 names the Spend Plan Source; U42 names the slide
     table's cut; U35 is Codex's A1 finding now (the lead's row), and U37, U40, U41 and U42 have fix tracks of their own (the
     lead's notes in their rows); each of those bullets stands only if its fix does not land. -->
  - **The registry-text review** (first filed as U35 while Codex's text had not reached the lead). Checked on `d66dd60`:
    typed, in a file opened, saved and reopened, and through Import a full board; and on the screen, in the workbooks and
    the slide deck read from their bytes, and in the saved file. Not followed: a cycle file, a PMO copy or submittal, a
    package, a service file, a PDF, and Excel or PowerPoint themselves. **U36 is fixed above:** a typed RCN / EEIC title over
    80 characters is refused, not cut. The rest stay open, with their limits stated above under U36's "Not covered":
    - **U37 (P1, a release blocker; its own fix track).** A character that XML 1.0 forbids makes a workbook part or a slide
      part malformed, for any text (registry text, a requirement title, a Plan Event on a slide, a destination name, which
      reaches `xl/workbook.xml`). A real browser's paste lets such a character in.
    - **U40 (P1, a release blocker, data loss; its own fix track).** Two destinations typed with names that differ only in
      case or spaces merge into one when the file is opened in a browser whose destination list is newer: a requirement
      changes its destination, its money moves in the funds flow, and nothing is said.
    - **U41 (P2 proposed; a fix track joins v2.00 only if its reviews are clean in time).** An SI code the file carried that
      is not exactly one of the five is dropped on opening without a word, and lost on the next save; its money moves to the
      derived code's row in the SI matrix.
    - **U42 (P2; the same fix track).** A funds-flow sheet name cut to 28 UTF-16 units can end in half an emoji (a
      replacement mark in `xl/workbook.xml`); a leading apostrophe is kept in a sheet name. The slide deck's 56-unit cut of
      a requirement title can split an emoji the same way.
    - **U38 (P2 proposed for the Spend Plan Source, P3 on the board).** A file keeps RCN / EEIC text that typing would refuse
      or change, and the Spend Plan Source prints it as stored (padded, lower case) with nothing flagging it.
    - **U39 (P3).** Two entries with the same text print identical rows.
    - **U35 (P2, deferred by the lead; Codex's A1).** During a Live refresh, typing not yet committed in the RCN / EEIC
      dialog is replaced by the stored value without a question.
