# REGTEXT verifier, round 1, lens A (data loss and money): record

I verified the REGTEXT builder's result in `rec/L6/regtext`. That is one proposed commit (U36) plus drafts for U37 to U41.
I started on 13 Oct at 12:12 AM ET (`TZ=America/New_York date` printed 00:12:54 EDT) and finished this record at
12:32 AM ET (the clock read 00:32:32 EDT).
I worked only in this directory and edited none of the builder's files.

## Verdict
**The code is sound, but the records have problems.** The U36 change is right, minimal and well tested. My own
mutants confirm that its tests catch what they should.

**Two of the drafted records understate a data-loss or export defect, and both must be corrected before they are committed:**
- **U40:** a destination is merged and money moves with nothing said.
- **U37:** a real browser lets the character in by paste.

Four more statements in the drafts are not true as written (should-fix).

## Identities (git hash-object)
| file | blob |
|---|---|
| base/prioritization-board-grid.html (copy of `../../base`) | fce8a391bd8a248d5185e199d22190c1687eaea0 |
| c1/prioritization-board-grid.html (copy of the builder's c1) | 55b2973d6b6fe5285647d7008962063f608cc9a2 |
| c1/tools/export-audit/audit-recon.mjs | cf65a9e6d3684b2c0811f4cbf7c892e82f071b08 |
| c1/tools/export-audit/mutate.mjs.txt | c4b661cb77cce139328a904e7da06f2b68ddeb2c |
| harness/c1/h-regtext.mjs (mkfocused.py from c1's audit-recon, block "v2.00 (REGTEXT)"; same body as the builder's, line 1 path differs) | 4d6d1fdf86caa025445ebc96332e4afc60d3455c |
| probe/vprobe.mjs | 8395b14cd707be1f4e9ea97d165f6cf7c1d435e1 |
| probe/vdest.mjs | 77db7642d8637e75f8813e034994df5898c4efaf |
| probe/vsi.mjs | 84a7f571c0f674dacb1b1707dfb76e19e16d1635 |
| probe/vflow.mjs | cee432ab9057b10d39c0a630d1920f0ca63f58fb |
| probe/vpaste.mjs | 1081e2dfc5b53807cc97fba46b9ed904d29924e0 |
| bin/vmut.py (my own mutants; NOT mutate.mjs) | e6fc07512aa79a900cdd0ef3d59e971042c7eeeb |
| bin/run.sh (builder's, directory changed) / bin/fr.sh / bin/runner.mjs | 545e9495 / b4f89271 / f851f139 |

`diff -rq base c1` shows only the builder's three files. `out/board.diff` is the 25-line board diff, and it is identical to
the builder's.

## Every run (all through bin/run.sh: setsid -w timeout -k 10 600; lock checked first, never present; PIDs in pids.txt)
| label | start (ET, 13 Oct) | exit | wall s | log | result |
|---|---|---|---|---|---|
| V-F-c1 | 00:19:10 | 0 | 9.4 | logs/V-F-c1.log | ALL CHECKS PASSED, 12/12 |
| V-F-base | 00:19:20 | 1 | 9.4 | logs/V-F-base.log | 8 fail, 4 controls pass |
| V-probe-c1 | 00:20:58 | 0 | 11.8 | logs/V-probe-c1.log | sections 1 to 5 below |
| V-probe-base | 00:21:10 | 0 | 11.8 | logs/V-probe-base.log | sections 1 to 5 below |
| V-dest-c1 | 00:24:20 | 0 | 7.5 | logs/V-dest-c1.log | U40: merge on another browser's open (DIFFERS) |
| V-dest-base | 00:24:49 | 0 | 5.4 | logs/V-dest-base.log | the same on the base |
| V-si-c1 | 00:25:20 | 0 | 5.5 | logs/V-si-c1.log | U41 through a file: dropped, lost on save |
| V-flow-c1 | 00:26:36 | 0 | 3.7 | logs/V-flow-c1.log | destination names: tab cut splits emoji (U+FFFD); U+000B in workbook.xml |
| V-flow-base | 00:26:50 | 0 | 3.7 | logs/V-flow-base.log | the same on the base |
| V-si-base | 00:26:54 | 0 | 3.9 | logs/V-si-base.log | the same on the base |
| V-S-audit-recon-c1 (full suite, cwd c1) | 00:27:15 | 0 | 226.5 | logs/V-S-audit-recon-c1.log | ALL CHECKS PASSED |
| V-M-v200-regtext-title-no-limit | 00:27:43 | 1 | 6.4 | logs/… | caught, 5 fail |
| V-M-v200-regtext-title-cut | 00:27:49 | 1 | 6.3 | logs/… | caught, 3 fail |
| V-M-v200-regtext-title-halves | 00:27:56 | 1 | 6.2 | logs/… | caught, 4 fail |
| V-M-v200-regtext-refused-but-kept | 00:28:02 | 1 | 7.8 | logs/… | caught, 5 fail |
| V-M-v200-regtext-field-unmarked | 00:28:10 | 1 | 10.2 | logs/… | caught, 1 fail |
| V-M-x1-ge80 (mine: `n>=80`) | 00:28:20 | 1 | 9.2 | logs/… | caught, 4 fail |
| V-M-x2-notrim (mine: title not trimmed) | 00:28:30 | 1 | 10.0 | logs/… | caught, 1 fail |
| V-M-x3-redraw (mine: refusal redraws) | 00:28:40 | 1 | 12.4 | logs/… | caught, 1 fail |
| V-M-x4-nostat (mine: refusal says nothing) | 00:28:53 | 1 | 10.5 | logs/… | caught, 3 fail |
| V-paste-chromium | 00:29:52 | 0 | 2.9 | logs/V-paste-chromium.log | Chromium 141 keeps U+000B/0001/0007/001F through Ctrl+C/Ctrl+V |

Other runs:
- mcount (text only, `rec/bin/mcount.py`), 00:21:45 ET, exit 0:
  - c1's mutate on the c1 board: 1333 entries, each matching once (`out/mc-c1-on-c1.txt`);
  - the base's mutate on the c1 board: 1328 entries, each once;
  - the five new ids: 1 match each.
- mkmut.py built the five proposed mutants into `mut/` (1 match each). mutate.mjs was never imported or run.

## Findings (literals; reproductions are the probe files)
**MUST-FIX 1, record U40.** The draft says P3 and "no money is wrong". The README says "No money is wrong". The ledger says "by
code, not run: a pre-v1.86 list".

The run (`probe/vdest.mjs`) shows otherwise. X types two destinations, "Alpha Depot" and "ALPHA DEPOT", and points R1 at the
first and R2 at the second. The file then opens:
- **In a fresh browser:** both are kept.
- **In a browser whose own destination list is newer** (the ordinary case of a second person opening the file): the two merge.
  - The board now shows `{"ents":[["Alpha Depot",2]],"R1":"Alpha Depot","R2":"Alpha Depot"}`.
  - "ALPHA DEPOT" is gone, and R2's 300 now counts under Alpha Depot.
  - The status line says only "Opened with the saved board state…".
  - Saving there keeps the merge.

This happens on c1 and on the base. The route is `destFold`: a v1.86 entry whose key this board lacks is matched by NAME
(`destByName`), and that includes an entry added by the same fold. It breaks the v1.86 can't-fails at 7ee498a
NEXT-VERSION.md:3024-3028: "No requirement … loses or changes its destination" and "each merge is listed".

**MUST-FIX 2, record U37.** The builder's own rule is "P1 if a real browser lets the character in by typing or paste", and
it marked this as not checked. Checked now (`probe/vpaste.mjs`, real Chromium 141): Ctrl+C / Ctrl+V and insertText keep
U+000B, U+0001, U+0007 and U+001F in an `<input type="text">`.
- rcnSet (c1 too) and the Plan Event prompt store such text unchanged.
- The workbook writer then puts it into the worksheet raw (the builder's own probe-base-file and probe-base-ctl).
- A destination name puts it into `xl/workbook.xml` itself (`probe/vflow.mjs`: "forbidden 1" in workbook.xml).

So U37 is P1 by the builder's rule.

**SHOULD-FIX:**
- **"Nothing is cut on the way out" / matrix "Silent truncation … None found" is false.** In the funds-flow workbook on the
  destination axis, each destination's sheet tab is `tabName`, which slices to 28 UTF-16 units. A name of 27 D plus an emoji
  becomes the sheet "DDDDDDDDDDDDDDDDDDDDDDDDDDD�", with U+FFFD in `xl/workbook.xml`. A name with a leading apostrophe goes
  into a sheet name; Excel does not accept one, but I did not check Excel. Run on c1 and the base.
- **U41 through a file (the builder's "a file carrying one was not built").** A saved file whose year holds
  `si {R1:'at', R2:'EN'}` opens with `{"R2":"EN"}`. Nothing is said: the status line is the ordinary one, and Needs
  attention lists only "oblig". After a save and reopen it is still `{"R2":"EN"}`, so the file's value is lost. R1's money
  then counts under "— no code set —" in the SI matrix (siOf R1 = ''). The README's "No money is wrong" does not hold as
  written.
- **"The limit counts characters, so an emoji counts once" is false for several cases** (`probe/vprobe.mjs` section 3, c1):

  | typed | visible characters | refused as |
  |---|---|---|
  | family emoji | 20 | "is 100 characters" |
  | é, letter plus separate accent (NFD) | 41 | "82 characters" |
  | é, letter plus separate accent (NFD) | 80 | "160 characters" |

  The single-character é (NFC) ×80 is kept. Flags and skin-tone emoji count as 2. The builder disclosed only the joined
  (ZWJ) emoji case.
- **"Checked … through every way it comes in and every place it goes out" overclaims.** The probe never imported a cycle file,
  a PMO copy or submittal, a package or a service file. It also never read the funds-flow workbook.
- **Process.** The builder's batch wrapper had a 7,000 s cap, and its read-only commands were unbounded (it disclosed both).
  My own early read-only commands (ls, cat, grep, sed, cp, diff, hash-object) were unbounded too, before 00:31 ET. Every node
  and Chromium run was bounded.

**MINOR:**
- **A refused title is kept only until the next redraw.** `probe/vprobe.mjs` section 2: after Add a combination, a service
  box, or another row's code, the field shows "base" again and the 81 typed characters are gone from the screen. The status
  line still says "not changed". This is item 91's design. On the base, 80 of the 81 were kept.
- **U36 is larger than the entry says.** On the base, ANY edit of a title that arrived longer than 80 cut the FILE's title
  (section 1): 100 L plus "!" was kept as 80 and saved so. On c1 it is refused, and all 100 are kept through save and reopen.
  "What users may see" should add that such a title must be shortened to 80 before it can be edited.
- `inShow`'s preview can end in half an emoji. It appears in the status line only.
- The status says "it can be at most 80" while a file's longer title is kept and not flagged (U38).

## The lead's principles, applied to the U36 change
1. **No copy lost:** better than the base. There is no silent cut of typed text or of a file's title. A refused title lives
   only in the field until the next redraw (minor).
2. **Refuse rather than guess:** it refuses.
3. **Money and exports:** money is unchanged across a refusal (900 / 200). RCN-EEIC by Month prints the stored title.
4. **Words true:** "Nothing was changed" is true, because the function returns before `save()`. The "N characters" count
   is not what a reader sees for combining marks or joined emoji (should-fix).
5. **Smallest:** about 5 lines.
6. **Preserved:** no existing check, fixture or expected value is edited. The base's 1,328 mutation entries each still match
   once on c1, and the full audit-recon passes on c1.

## What I did NOT do
- **Suites.** I did not run audit-import or audit-board (the lead's), or the other suites (the builder ran them, and the
  board change is confined to rcnSet's title branch).
- **mutate.mjs.** I did not import or run it.
- **Excel / LibreOffice.** I did not open any workbook in them.
- **The board in Chromium.** I did not run it there. The paste check used a synthetic page; the board's field is a plain
  `<input>`.
- **Fixes.** I did not fix U37, U40 or U41.
- **The repositories.** I did not edit, stage, commit or push anything. orbit-board and orbit-ui are untouched.
- **Processes.** I killed nothing.

## Resumed after the usage limit
The session stopped after this record was written and before the result was returned. It resumed at 4:19 AM ET on 13 Oct (04:19:46 EDT).
After resuming I re-read the logs (no new node or Chromium run; the lock file was absent), confirmed that every rcnSet caller is
the panel's three fields (lines 5113, 5117 and 5121 of the c1 board), and returned the verdict.

**A note on probe section 5 (`logs/V-probe-c1.log`, "DIFFERS").** That DIFFERS is my literal's fault, not the board's. RCN-EEIC
by Month prints K1 twice, once by service and once with "(1 requirement)" appended; my expected value listed only the first
pair. Both pairs read "11111 / AAAAA  Ok title" with 900 and 200, which is what a refusal should leave. On the base the same
rows carry the 80-Q cut title.
