# REGTEXT verify, round 1, lens B (test adequacy and regressions): verifier record

Independent adversarial verifier of the REGTEXT builder's result (`../README.md`, copy `../c1`). The work was done in two
sessions. Session 1 ran 13 Oct, 00:28–00:49 EDT, and was cut off when the usage limit was hit. Its runs are all in
`logs/runs.txt`; the base `audit-recon` run it started at 00:47 EDT has no end line. Session 2 resumed at 04:20 EDT on
13 Oct. This record was written at 04:35 EDT, after its last run, which ended at 04:33:27 EDT. Every time below is Eastern (`TZ=America/New_York date`). Nothing outside this
directory was edited. Nothing was committed, staged or pushed.

## Verdict: sound with issues (no must-fix)

The board change is right, and the builder's runs reproduce exactly. Two things need care. First, the new block misses
3 of my 14 wrong-fix mutants; three checks and three mutation entries close that gap (the should-fix below, ready as
`prop2/`). Second, the refusal's own status line can still split an emoji (minor; the builder disclosed it).

## Identities (git hash-object)

| file | base (`../../base`, 7ee498a / d66dd60) | builder c1 = my `c1/` = `gc/c1` | my proposal `prop2/` |
|---|---|---|---|
| prioritization-board-grid.html | fce8a391bd8a248d5185e199d22190c1687eaea0 | 55b2973d6b6fe5285647d7008962063f608cc9a2 | (c1's, unchanged) |
| tools/export-audit/audit-recon.mjs | 529e36f7c20e635b2722ea53b6a4f44b4ed328af | cf65a9e6d3684b2c0811f4cbf7c892e82f071b08 | 09ae8ab740995c41a09b79ba7a2b37d74d4b4452 |
| tools/export-audit/mutate.mjs.txt | cbc6defc6803851e847844848fc9b186daeeb268 | c4b661cb77cce139328a904e7da06f2b68ddeb2c | 972f03a30013b56f6fe526dfa73a5f02e543683e |
| audit-import / audit-board / audit-other / boot.mjs | 4aba2506 / a7c575e5 / d89396b0 / 9c4f49ad | unchanged | unchanged |

`base/` and `c1/` here are `cp -a` copies of `../../base` and `../c1`, with the same blobs. `gc/base` and `gc/c1` are
`git clone --shared /home/user/orbit-board` at 7ee498a, with c1's board and audit-recon copied over in `gc/c1`. Neither
clone has any commit. Focused harnesses: `harness/h-regtext.mjs` (204765f3) is the builder's block, verbatim from c1. It
differs from the builder's `harness/c1/h-regtext.mjs` (4d886573) only in the path on its first comment line.
`harness/h-regtext-prop2.mjs` (32ef68e6) is the prop2 block, verbatim from `prop2/`. Both were made by
`rec/L3/u14/mkfocused.py` and run by `bin/runner.mjs` (copied from rec/L2/u2impl, unchanged).

## 1. The builder's runs, re-run and compared

| builder run | builder result | my run | my result |
|---|---|---|---|
| F2-c1 | 12/12 pass | VF-c1 (00:29:12) | 12p/0f, exit 0 |
| F2-base | 8 fail, 4 controls pass | VF-base (00:29:24) | 4p/8f, exit 1; the same 8 checks |
| M title-no-limit / title-cut / title-halves / refused-but-kept / field-unmarked | 5 / 3 / 4 / 5 / 1 fail | VM-v200-regtext-* (00:30:26–00:31:20) | 5 / 3 / 4 / 5 / 1 fail: identical |
| probe-base-type, -file, -ctl, -more, -c1-type | (logs) | Vprobe-* (00:36:16–00:37:28) | output identical line for line (`diff`, paths and times aside) |
| probe-base-sweep | (log) | Vprobe-base-sweep (00:37:59) | identical except the heading line: the builder's log says "... (rcn, eeic, t) **and in a PPBE line's codes**". The delivered `probe/regtext.mjs` (9c701174; its mtime is 20:21:30 EDT, after that run's 20:18:27 start) does not print that, so the logged sweep ran an earlier version of the script. Every result line matches. |
| suites on c1, 9 runs | all pass | VS-*-c1 (00:35:43–00:44:53) | all pass, exit 0 |
| suites on base, 9 runs | all pass | VS-*-base (00:44:53–00:45:37), then VSC-/VS-*-base (04:23:11–04:28:31) | all pass, exit 0 |
| mcount | c1 1333/1333 once; base 1328/1328; base entries on c1 board 1328 once | out/mcount-*.txt | identical |

F1 (the builder's first harness, 5f0076e6, superseded by F2) was not re-run.

## 2. Mutants: the builder's 5 and 14 of my own

I wrote 14 plausible wrong fixes (`own/own-mutants.py`; boards in `mut/`; each find matched the c1 board exactly once).
Under the builder's 12-check block (`harness/h-regtext.mjs`), all 5 of the builder's mutants and 11 of my 14 are caught.
**Three survive (12p/0f):**

| mutant | the wrong fix | why it matters |
|---|---|---|
| own-count-before-trim | counts the title before trimming: `n=Array.from(String(val\|\|'')).length` | 80 letters typed with spaces around them (which trims to 80) are refused as 84 characters |
| own-preview-untrimmed | the refusal quotes `inShow(val)`, not the trimmed title | the status quotes “   AAA…”, which is not the text the limit was measured on |
| own-refuse-then-save | refuses, then calls `save()` | `save()` sets `DIRTY`, stamps `MS.ts` / `MS.by`, may add a save-history entry and (under a locked view) shows its own refusal. The board reads as edited after "Nothing was changed". |

(In session 1 I first counted own-refuse-then-save as an equivalent mutant. Reading `save()`, line 6767 of the board,
shows it is not.)

**The prop2 proposal** (`diffs/prop2-audit-recon.diff`, `diffs/prop2-mutate.diff`) adds two checks and one control to the
block, and three mutation entries:
- check "a refused title saves nothing": `DIRTY=false; MS.ts=1`, type 81 letters, expect `['base', false, 1]`;
- check "title typed as 81 letters with spaces before them": expect refused, with the status quoting 60 A's and "81 characters";
- CONTROL "title typed as 80 letters with spaces around them": expect kept as the 80 letters, unmarked, nothing said;
- entries `v200-regtext-count-untrimmed`, `v200-regtext-preview-untrimmed` and `v200-regtext-refused-but-saved`, inserted
  after the builder's five (so before the R3 line).

**Results under the final prop2 harness (32ef68e6), 04:30:34–04:33:20 EDT:** c1 15p/0f (exit 0). Base 5p/10f (exit 1):
the two new checks fail there (base: `["AAAA…(80)", true, 1791879960614]`, and the padded 81 cut to 80), and the new
control passes. **All 22 mutants are caught.** Failing checks per mutant: the builder's no-limit 7, cut 3, halves 4,
refused-but-kept 7, field-unmarked 1; the new entries count-untrimmed 2, preview-untrimmed 1, refused-but-saved 1. My
own: off-by-one 5, limit-81 6, count-before-trim 2, cut-by-codepoint 7, unmarked 5, redraw-after-refusal 1, says-halves 1,
field-cleared 5, silent-refusal 4, untrimmed-store 2, title-cleared-on-refusal 7, preview-untrimmed 1, utf8-bytes 4,
refuse-then-save 1. (`out/focused-summary.txt` lines VR2-*; each run's checks are in `out/VR2-*.checks.jsonl`.)

mcount, read as text only, for prop2's mutate on the c1 board (`out/mcount-prop2mut-c1board.txt`): 1336 entries, every
one matching once. On the base board, the 8 REGTEXT entries miss and the other 1328 match once, as expected.

## 3. Literals, fail-before, changed expectations

- **Every new expected value is a hand-written literal**, or a literal built from literal constants: `'A'.repeat(81)`,
  `E80`, the `no()` message template, `['11111 / AAAAA  base', 900]`. Board helpers (`w6Book`, `w6Lbl`, `rcnReg`) are
  used only for observed values.
- **Fail-before:** 8 of the builder's 12 checks fail on the base. The other 4 are labelled CONTROLs and pass on both,
  which is house style (84 CONTROL mentions in audit-recon at the base). All 12 pass on c1.
- **No existing expectation changed.** Against the base, `audit-recon.mjs` is +78 lines and −0, and `mutate.mjs.txt` is
  +16 and −0. No other suite file changed (`diff -rq base c1`).
- **Check streams compared** (`bin/cmpchecks.py`, SUITE_CHECKS on both): audit-recon has 306 checks on the base and
  318 on c1. All 306 base checks are present on c1 with the same verdict and the same observed value; the 12 extra are
  REGTEXT. audit-hostile has 124 on each, all identical.
- **Focused audit-board:** its v1.97 W1 block holds every other `rcnSet` test (item 91, R2). Built verbatim with
  `bin/mkfocused-board.py`, it passes on c1 and on the base, with the same counts (VB-w1-*).

## 4. Suites (scratch clones at 7ee498a), all exit 0, all pass

c1, 13 Oct: boot-same 00:35:43 (26.4 s), audit 00:36:09 (32.4), audit-ppt 00:36:42 (18.3), audit-other 00:37:00 (82.2),
audit-recon 00:38:23 (218.9), legacy-fsrc 00:42:01 (8.0), audit-hostile 00:42:10 (135.0), audit-inject 00:44:25 (22.4),
npm run check 00:44:47 (6.1); and with SUITE_CHECKS: audit-recon 04:23:11 (191.4), audit-hostile 04:26:22 (109.7).
Base: boot-same 00:44:53 (14.0), audit 00:45:07 (18.3), audit-ppt 00:45:25 (11.5), audit-other 00:45:37 (82.7),
audit-recon with SUITE_CHECKS 04:23:11 (187.2), audit-hostile with SUITE_CHECKS 04:26:18 (103.7), legacy-fsrc 04:28:02
(6.7), audit-inject 04:28:08 (18.3), npm run check 04:28:27 (4.3). The `npm run check` output is identical on both apart
from the line count (31672 / 31677; 29650 / 29655). The session-1 base audit-recon run (VS-audit-recon-base, 00:47:00)
was cut off with the session and has no end line. VSC-audit-recon-base replaces it.

## 5. Findings

**Must-fix: none.**

**Should-fix (test adequacy): the new block lets 3 plausible wrong fixes through.** These are counting before the trim,
quoting the untrimmed text, and saving on a refusal (section 2).
- Repro: `bin/fr.sh X c1 harness/h-regtext.mjs mut/own-refuse-then-save.html` gives "ALL CHECKS PASSED" (12p/0f). The
  same holds for `own-count-before-trim` and `own-preview-untrimmed`.
- Fix: adopt `diffs/prop2-audit-recon.diff` (+3 checks; the header now says 10 of its 15 checks fail on d66dd60, with 5
  CONTROLS) and `diffs/prop2-mutate.diff` (+3 entries).
- If adopted, the builder's NEXT-VERSION "Test" (12 checks, 8 fail, 4 controls), its "Mutations" list and its commit
  message need the new counts and ids.

**Minor:**
1. **The refusal's own status line can split an emoji.** `inShow` cuts its preview at 60 UTF-16 units. A title of 59
   letters, an emoji and 30 letters is refused with a preview ending `61 d83d 2026 201d`, a lone high half
   (`logs/Vprobe-half-preview-c1.log`, 00:48:46). The field's tooltip carries the same text. Nothing is stored or exported
   that way. The builder disclosed it. A fix would count by character in `inShow` (it is shared with the code refusals,
   whose existing expected texts are ASCII). Test: that 90-character title, expecting the preview `“a×59😀…”`.
2. **Provenance:** the logged probe-base-sweep run used an earlier version of `probe/regtext.mjs` (section 1). The
   results reproduce with the delivered script.
3. **Ledger wording:** the block and the mutate comment say "U35" (the review row) and the commit says "U36" (the
   finding). This is consistent with the drafts' scheme, but the mutate comment introduces U36's entries as "REGTEXT,
   U35".

## 6. What I did not do

- I did not run the full audit-import or audit-board (the lead runs those alone). I did not run any Chromium tool or
  `verify:grid`. By reading: `row-controls` lists only the row and the inspector, and no other tool references
  `rcnSet` or the title field's handler.
- I never imported or ran `mutate.mjs`. It was read as text through `mcount.py` / `mkmut.py` with `python3 -I` only.
- I did not edit the builder's files, orbit-board or orbit-ui. `gc/*` are scratch clones with no commits.
- I did not re-run F1 (superseded), and did not check Excel or LibreOffice.
- Deviations from the bounding rule: read-only ls, cat, grep, diff, cp and hash-object commands ran unbounded. The two
  session-2 wrapper scripts (`bin/resume-base.sh`, `bin/resume-c1.sh`) were bounded at 3000 s and 1800 s, with each inner
  run still at 600 s through `bin/run.sh`.
- The lock file `AUDIT_IMPORT_RUNNING` was checked before every node run (`bin/run.sh`). It was never present: there was
  no wait and no skip (`grep -c 'SKIPPED|waiting' logs/runs.txt` = 0).

## 7. Every run and every PID

Every run (label, start ET, exit, wall seconds, log) is in `out/runs-table.md`, built from `logs/runs.txt` (99 runs).
Every PID with its command and start time is in `pids.txt`: each timeout PID and its child, plus the wrapper PIDs. No
process was killed. None of mine is still running.
