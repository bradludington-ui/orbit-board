# REGTEXT verify, round 2, lens A (data loss and money): verifier record

Track: REGTEXT (ledger U35; the commit is U36: "an RCN / EEIC title over 80 characters is refused, never cut"). This is the
independent adversarial review of the builder's fix round (`../README.md`, "Fix round"; `../wfstate/fix_regtext_r1.json`).
All times are Eastern (`TZ=America/New_York date`). I started at 10:23 AM ET on 13 Oct; this record was written at about
10:50 AM ET.

## What I kept from an earlier attempt
None. `verify-money-r2` did not exist at 10:23:36 AM ET (`ls`: "No such file or directory"). Everything here is new in this
session. `pids.txt` is new.

## Identities
My copies (`c1/`, `base/`) were made with `cp -a` from `../c1` and `../base` (bounded: `setsid -w timeout -k 10 600`), and
`chmod u+w`. Both keep the node_modules symlink. They are byte-identical to the builder's.

| file | base | c1 (final; = builder's c1) |
|---|---|---|
| prioritization-board-grid.html | fce8a391bd8a248d5185e199d22190c1687eaea0 | 0949c3ed169e6d0515c587ba030a564f9abd8ae9 |
| tools/export-audit/audit-recon.mjs | 529e36f7c20e635b2722ea53b6a4f44b4ed328af | 08c1275e8c260b1a037aa5aa8b072c2a979a57fe |
| tools/export-audit/mutate.mjs.txt | cbc6defc6803851e847844848fc9b186daeeb268 | 41c64701beaa3b9345e7c2b1a66b6f1ac67a2b2d |
| tools/export-audit/audit-import.mjs | 4aba2506 | 4aba2506 (unchanged) |
| tools/export-audit/audit-board.mjs | a7c575e5 | a7c575e5 (unchanged) |
| tools/export-audit/audit-other.mjs | d89396b0 | d89396b0 (unchanged) |

`diff -rq base c1` lists only those three files. Removed/added lines: board 2/8, audit-recon 0/89, mutate 0/25 (`diffs/`,
from `diff base/<f> c1/<f>`: `prioritization-board-grid.html.diff` 6d0ca714, `audit-recon.mjs.diff` c457c945,
`mutate.mjs.txt.diff` 67699038). Against the builder's first c1 (`../superseded/c1-build`, 55b2973d) the final board differs
only in the comment (`v2.00 (REGTEXT)` → `v2.00 (U36)`, and the counting sentence).

The board change, exactly (`diffs/prioritization-board-grid.html.diff`):
```
5121c5121
<       +'onchange="rcnSet('+i+',&quot;t&quot;,this.value)"></td>'
>       +'onchange="rcnSet('+i+',&quot;t&quot;,this.value,this)"></td>'
10878c10878,10884
<   else if(field==='t') e.t=String(val||'').trim().slice(0,80);
>   else if(field==='t'){ const t=String(val||'').trim(), n=Array.from(t).length;
>     // v2.00 (U36): ... (4 comment lines)
>     if(n>80){ codeRefusedIn(el, 'RCN / EEIC title not changed', 'The title '+inShow(t)+' is '+n+' characters; it can be at most 80. Nothing was changed'); return; }
>     e.t=t; }
```

## Every run (all node runs through `bin/run.sh`: lock checked first, `setsid -w timeout -k 10 600`, PIDs recorded)
The lock `AUDIT_IMPORT_RUNNING` was never present: no run waited, none was skipped.

| label | start (ET, 13 Oct) | exit | wall s | log | result |
|---|---|---|---|---|---|
| V2-F-c1 | 10:27:20 | 0 | 5.9 | logs/V2-F-c1.log | ALL CHECKS PASSED, 15p/0f |
| V2-F-base | 10:27:26 | 1 | 5.8 | logs/V2-F-base.log | 10 failing, 5 controls pass (the same 10 as the builder's FR-F3-base) |
| V2-M-title-no-limit | 10:27:51 | 1 | 9.2 | logs/V2-M-title-no-limit.log | caught, 7 fail |
| V2-M-title-cut | 10:28:01 | 1 | 8.2 | logs/V2-M-title-cut.log | caught, 3 fail |
| V2-M-title-halves | 10:28:10 | 1 | 5.3 | logs/V2-M-title-halves.log | caught, 4 fail |
| V2-M-refused-but-kept | 10:28:15 | 1 | 5.0 | logs/V2-M-refused-but-kept.log | caught, 7 fail |
| V2-M-field-unmarked | 10:28:21 | 1 | 4.8 | logs/V2-M-field-unmarked.log | caught, 1 fail |
| V2-M-count-untrimmed | 10:28:26 | 1 | 5.1 | logs/V2-M-count-untrimmed.log | caught, 2 fail |
| V2-M-preview-untrimmed | 10:28:31 | 1 | 4.4 | logs/V2-M-preview-untrimmed.log | caught, 1 fail |
| V2-M-refused-but-saved | 10:28:36 | 1 | 4.4 | logs/V2-M-refused-but-saved.log | caught, 1 fail |
| V2-probe-c1 | 10:32:45 | 0 | 9.6 | logs/V2-probe-c1.log | first run; sections 4/5 scanned binary parts too (superseded by c1c) |
| V2-probe-c1b | 10:33:17 | 0 | 9.7 | logs/V2-probe-c1b.log | XML parts only; R1 not on any slide yet (superseded by c1c) |
| V2-probe-c1c | 10:33:43 | 0 | 13.8 | logs/V2-probe-c1c.log | final probe on c1 (results below) |
| V2-probe-base | 10:34:22 | 0 | 12.3 | logs/V2-probe-base.log | final probe on the base (results below) |
| V2-S-audit-recon-c1 | 10:35:48 | 0 | 508.2 | logs/V2-S-audit-recon-c1.log | ALL CHECKS PASSED (gc/c1); 321 checks recorded |
| V2-S-audit-hostile-c1 | 10:44:39 | 0 | 217.4 | logs/V2-S-audit-hostile-c1.log | ALL CHECKS PASSED (gc/c1) |
| V2-check-c1 | 10:48:17 | 0 | 11.4 | logs/V2-check-c1.log | "all checks passed" (npm run check, gc/c1) |

Text-only runs (through `bin/bx.sh`, bounded, PIDs recorded; python3 -I; mutate.mjs read as TEXT only, never imported or run):
- `mkfocused` 10:26 ET, exit 0: `harness/h-u36.mjs` (2e02f256) from c1's audit-recon, block "v2.00 (U36)", verbatim by
  `rec/L3/u14/mkfocused.py`. It equals the builder's `harness/fr/h-u36.mjs` (c9910c10) apart from line 1 (the source path).
- `mcount` 10:27:39 ET, exit 0 each (`out/mcount-*.txt`): c1 mutate on the c1 board 1336/1336 once; base mutate on the c1
  board 1328/1328 once; c1 mutate on the base board 1328 once and the 8 U36 ids missing, as they should be.
- `mkmut-*` 10:27:51–10:28:36 ET, exit 0 each: the 8 mutants in `mut/`. They are byte-identical to the builder's `mut/fr/`.
- `clone`/`checkout` 10:35:34 ET, exit 0: `gc/c1` = `git clone --shared /home/user/orbit-board`, checked out at 7ee498a, with
  the c1 board and audit-recon copied over and a node_modules symlink. Its own `mutate.mjs` is the base's text (cbc6defc) and
  was never run. Nothing was committed there.
- `cmpchecks` (after V2-S-audit-recon-c1), exit 0 (`out/V2-cmpchecks-audit-recon.txt`): against verifier B's base stream
  (`../out/VSC-audit-recon-base.checks.jsonl.from-verifier`, identical to `../verify-tests-r1/out/VSC-audit-recon-base.checks.jsonl`):
  base 306, c1 321; missing 0, differing 0 (verdict and observed value), extra 15, all in "v2.00 (U36)". I did not re-run
  audit-recon on the base myself; that stream is verifier B's (13 Oct, 4:23 AM ET).

## The probe (`probe/v2.mjs`, d9fe0f7a; synthetic data built at run time; expectations are literals)
| section | c1 (V2-probe-c1c) | base (V2-probe-base) |
|---|---|---|
| 1 a 105-character title of markup (`<img onerror>`, `<b>`) typed | refused; the status line holds no `<img>` (its only element is the board's own `<b>` head); the markup reads as text in the status and the tooltip; nothing ran | cut to 80 and stored, nothing said (U36's defect) |
| 1b the same typed in the panel's field | refused, "base" kept, no `<img>` anywhere, nothing ran | stored cut to 80; no `<img>`, nothing ran |
| 1c CONTROL markup within 80 | kept, drawn back as the field's value, no `<img>` | the same |
| 2 a file's 100-character title, then the same row's EEIC, RCN, a service box, Add | title stays 100; saved and reopened, 100; shortened to 80 in its field, kept, unmarked | the same (only a title edit cut it on the base) |
| 3 a file's codes `' 44444 '` / `' ddddd '` | kept as they arrived; `codeIssues()` = [] (nothing in Pre-flight); **the Spend Plan Source (`exportSrc`, the CCaR file) prints `" ddddd "` and `" 44444 "`, padded and lower-case**; RCN-EEIC by Month prints `" 44444  /  ddddd   pad"`; ACE tie-out refuses (no ACE imported) | the same |
| 4 a Plan Event typed through the board's own prompt (`editTitle`) as `Plan\u000Bevent`, R1 Mission Critical | stored as typed; **`ppt/slides/slide5.xml` holds U+000B (1)**: the PPTX slide part is not well-formed XML; the workbook: sheets 2, 4, 7, 11 (U37 as recorded) | the same |
| 5 a Plan Event of 55 letters, an emoji and "tail" | the Mission Critical slide prints 55 `p` and U+FFFD: `dispTitle(it).slice(0,56)` cut the emoji in half | the same |

## Findings
### MUST-FIX (records; no code change needed for U36 itself)
**U37's reach leaves out the PPTX.** The drafts describe U37 as a workbook defect: NEXT-VERSION-entry.md:40–49 ("A workbook
can hold a character that XML 1.0 forbids … The workbook writer escapes only `& < > "`"), LEDGER-append.md:38 ("A workbook
part … The XLSX writer (`_xesc`)"), MATRIX-limits.md:17 ("Workbook well-formedness"), UNRESOLVED-line.md:9–11 ("makes a
workbook part malformed") and COMMIT-MSG.txt:22 ("a workbook part not well-formed"). But `_xesc` is also the PPTX writer
(`_pRun`, board line 24913; also 24923 and 25048), and the slide tables carry requirement titles (`dispTitle`). Measured on
the base and on c1 (probe section 4): a Plan Event typed through the board's own prompt as `Plan\u000Bevent` puts U+000B raw
into `ppt/slides/slide5.xml`, so the deck's slide part is not well-formed. Chromium 141 keeps U+000B on paste (the builder's
FR-vpaste-chromium). This matters for the lead's choice: escaping in `_xesc` covers both writers, but "refuse the export and
name the cell, as IDS_BADCH does" would have to be added to `exportPPT` too, or the deck stays broken while the release notes
say only workbooks are affected. **Minimal fix:** in those five places, name the PPTX (slides, through the same `_xesc`) as
measured, with this probe as evidence, and say the fix must cover both writers.

### SHOULD-FIX
- **U38 says "Nothing compares RCN or EEIC text, so no money moves", but the CCaR file carries the unnormalised codes and
  nothing flags them.** Probe section 3, base and c1: a file's `' 44444 '` / `' ddddd '` are printed padded and lower-case in
  the Spend Plan Source (`exportSrc`), which is what goes to CCaR. `codeIssues()` lists nothing, so Pre-flight is silent, and
  Needs attention skips board-level lists. The board's own Pre-flight text says that for an over-long code "the exports print
  them as they are, so CCaR may not match them". The same risk applies here, and nothing says so. Correct U38 in
  NEXT-VERSION-entry.md:50–59, LEDGER-append.md:39 and MATRIX-limits.md:13. "No money moves" is true only inside the board.
  Say that the Spend Plan Source prints such codes as stored, and that nothing flags them. Consider P2. Candidate fix: list
  such codes beside "Codes longer than their limit".

### MINOR
- **The PPTX cut splits an emoji.** The Mission Critical and Unfunded slides cut a requirement title with
  `dispTitle(it).slice(0,56)`, by UTF-16 unit, so 55 letters and an emoji print as 55 letters and U+FFFD (probe section 5,
  base and c1). This is not registry text. It is U42's pattern in another export, and could be named beside U42.
- **The builder's README mislabels the mutant blobs.** `../README.md:548` pairs the names in entry order with blobs in
  alphabetical order. 7 of 8 pairs are wrong. Example: title-no-limit is 708fa4ca, not 88ef10c2. 88ef10c2 is count-untrimmed.
  The actual pairs are `count-untrimmed` 88ef10c2, `field-unmarked` 7e0a2b5b, `preview-untrimmed` 1a92be1d, `refused-but-kept`
  a2b6a6c0, `refused-but-saved` ed2f6c13, `title-cut` 89ffd817, `title-halves` 8f4074df, `title-no-limit` 708fa4ca (`git
  hash-object ../mut/fr/*`, equal to mine).
- `buildXlsx` itself cuts every sheet name with `.slice(0,31)` (board line 24828), the same split risk for any sheet name
  over 31 units (by code only; exportFlow's tabName already cuts at 28, so U42's case does not reach it).

## The change against the lead's six principles (my reading, with the runs above)
1. **Never lose a copy:** a refusal writes nothing. A file's long title now survives every edit of its row, a save and a
   reopen (section 2). On the base, any title edit cut it. A refused text lives only in the field until the next redraw. The
   status says so ("Nothing was changed"), and item 91's code refusals behave the same way.
2. **Refuse rather than guess:** refused, never cut. Under a locked view it is refused too (the builder's FR-vprobe-c1 §4).
3. **Money and exports:** no figure changes. RCN-EEIC by Month stays 900 / 200 across refusals (block checks). U36 adds no
   new export defect. The export defects found here (PPTX, CCaR codes) are on the base too.
4. **Words true:** the refusal is escaped (section 1) and says what happened. The count is by code point, and the drafts
   now say so. The records still need the PPTX (must-fix) and the CCaR-file wording (should-fix).
5. **Smallest change:** three code lines, four comment lines, and the handler argument.
6. **Preserved:** the 306 base audit-recon checks keep their verdict and observed value. The suite diffs are additive only
   (audit-recon +89/−0, mutate +25/−0). Every existing mutation entry still matches once. No existing tool types a title:
   `grep rcnSet tools/` finds only 'rcn' and 'eeic', in audit-board 4063/4112/4145 and audit-recon 4075.

## PIDs
`pids.txt` (64 lines) holds every timeout PID and its child, each with its command, from `bin/run.sh` and `bin/bx.sh`. At the
end no recorded PID was running (`ps -p` on each found none). I killed nothing.

## Deviations
Not every command was bounded. These ran directly from my shell without `setsid -w timeout -k 10 600`: read-only `ls`,
`cat`, `sed`, `grep`, `cmp`, `diff` (including the three diffs into `diffs/`), `git hash-object`, `git log` and `grep` in
`/home/user/orbit-board`, `date`; the copy and `ln -s` into `gc/c1`; the `sed` copies of the run scripts into `bin/`; and two
inline python edits of `probe/v2.mjs`. None of them ran node or Chromium. Every node run was bounded and checked the lock first.

## What I did NOT do
- Did not run the full audit-import or audit-board (the lead's). Did not import, execute or run `mutate.mjs`: it was read as
  text only (mcount.py, mkmut.py).
- Did not re-run the base suites. The base audit-recon stream I compared against is verifier B's.
- Did not run Chromium. Did not open Excel, LibreOffice or PowerPoint. "Not well-formed" is judged by the XML 1.0 Char rule
  on the bytes, not by an application.
- Did not follow a cycle file, a PMO copy or submittal, a package, a service file, or BAE budget names.
- Did not edit, stage, commit or push anything in /home/user/orbit-board or /home/user/orbit-ui (read with `git log` and
  `grep` only). Did not edit the builder's files. Did not commit in `gc/c1`. Did not run `playwright install`.
- Did not change the board from the empty template. Synthetic data exists only at run time.
