# REGTEXT (ledger U35: the pending registry-text findings): builder record

Track: Codex's registry-text findings are still pending, and their text has not reached the lead. Brad, 12 Oct, about 6:05 PM
ET: "record the malformed saved-year selection and pending registry-text findings explicitly. If deferred, name their limits in
the matrix and release notes." The work here was to investigate registry text on the base, fix what is minimal and clearly
right, and name the limits of the rest.

Builder started 12 Oct, 8:09 PM ET. All times are Eastern (`TZ=America/New_York date`).

## What I kept from the earlier attempt
None. `rec/L6/regtext` did not exist when I started (8:09:50 PM ET; `ls` said "No such file or directory"), and nothing for
this track was found anywhere else under `rec/` (`find -iname '*regtext*' -o -iname '*registry*'`). **Everything here was
done fresh in this session.** `pids.txt` was created new. The run scripts `bin/run.sh`, `bin/bx.sh`, `bin/runner.mjs`,
`bin/fr.sh`, `bin/tally.py` and `bin/suites.sh` are copies of the CYCREG track's own (`rec/L6/cycreg/bin`), with only the
directory changed (`sed s#rec/L6/cycreg#rec/L6/regtext#`).

## Base
`../base` (read-only) is the git archive of orbit-board `7ee498a` (the product is `d66dd60`, U14). Before editing, I checked
the blobs in `c1` against `../BASE.txt`, and all match:
- board `fce8a391`
- audit-recon `529e36f7`
- audit-import `4aba2506`
- audit-board `a7c575e5`
- audit-other `d89396b0`
- mutate.mjs.txt `cbc6defc`

## Proposed commit (ONE)
> **Superseded (fix round, 13 Oct):** the commit is now board 0949c3ed, audit-recon 08c1275e, mutate.mjs.txt 41c64701 (see "Fix round" below). The blobs just below are the builder's, kept in `superseded/c1-build`.

`1: v2.00 (REGTEXT, U36): an RCN / EEIC title over 80 characters is refused, never cut | copy c1 | board
55b2973d6b6fe5285647d7008962063f608cc9a2 | suites audit-recon cf65a9e6d3684b2c0811f4cbf7c892e82f071b08 (audit-import
4aba2506, audit-board a7c575e5, audit-other d89396b0 unchanged) | mutate c4b661cb77cce139328a904e7da06f2b68ddeb2c`

The message draft is `drafts/COMMIT-MSG.txt`. The lead adds the attribution lines.

## Files changed (c1 against the base)
> **Superseded (fix round, 13 Oct):** the c1 blobs in this table are the builder's. The final ones and the final diffs are in "Fix round" below; the builder's diffs are kept in `superseded/diffs-build`.

`diff -rq ../base c1` lists only these three files.

| file | base blob | c1 blob | diff |
|---|---|---|---|
| prioritization-board-grid.html | fce8a391bd8a248d5185e199d22190c1687eaea0 | 55b2973d6b6fe5285647d7008962063f608cc9a2 | `diffs/c1-prioritization-board-grid.html.diff` (25 lines) |
| tools/export-audit/audit-recon.mjs | 529e36f7c20e635b2722ea53b6a4f44b4ed328af | cf65a9e6d3684b2c0811f4cbf7c892e82f071b08 | `diffs/c1-audit-recon.mjs.diff` (87 lines) |
| tools/export-audit/mutate.mjs.txt | cbc6defc6803851e847844848fc9b186daeeb268 | c4b661cb77cce139328a904e7da06f2b68ddeb2c | `diffs/c1-mutate.mjs.txt.diff` (25 lines) |

All three diffs are concatenated in `diffs/c1-all.diff` (blob 878961ef).

### The board change, exactly
> **Superseded (fix round, 13 Oct):** the code is unchanged; the comment now begins "// v2.00 (U36):" and says the count is by Unicode code point, with a joined emoji, a flag or a letter with a separate accent counting as several.

```diff
@@ -5118,7 +5118,7 @@   (rcnBody: the RCN / EEIC panel's title field)
-      +'onchange="rcnSet('+i+',&quot;t&quot;,this.value)"></td>'
+      +'onchange="rcnSet('+i+',&quot;t&quot;,this.value,this)"></td>'
@@ -10875,7 +10875,12 @@   (rcnSet)
-  else if(field==='t') e.t=String(val||'').trim().slice(0,80);
+  else if(field==='t'){ const t=String(val||'').trim(), n=Array.from(t).length;
+    // v2.00 (REGTEXT): a title over 80 characters is refused, never cut. It was cut to its first 80 without a word, and the
+    // cut could split a character in two: 79 letters and an emoji were kept as 79 letters and half of the emoji. Counted by
+    // Unicode character, so a character stored as two halves (most emoji) counts once.
+    if(n>80){ codeRefusedIn(el, 'RCN / EEIC title not changed', 'The title '+inShow(t)+' is '+n+' characters; it can be at most 80. Nothing was changed'); return; }
+    e.t=t; }
```
The refusal uses the board's own item 91 helpers (`codeRefusedIn`, `inShow`): the field is marked, the status line says why,
and nothing is written. The title is computed once, and that same value is both checked and stored (U7's concern, for the
title).

## Findings (reproduced on the base; literals; healthy controls)
Probe: `probe/regtext.mjs` (blob 9c701174), sections `type`, `file`, `ctl`, `sweep` and `more`. It builds synthetic data at
run time on O&M: USAF / ANG / AFRC, R1 asking 900 / 200 / 0 and R2 asking 300 / 0 / 0, pots of 5,000, awards in FYMON[2].

**U36 (FIXED in c1).** A typed title over 80 characters was cut silently. `logs/probe-base-type.log`:

| typed | base result | c1 result (`logs/probe-c1-type.log`) |
|---|---|---|
| 81 × A | kept 80, no status, field unmarked | refused, list keeps "base", status "⚠ RCN / EEIC title not changed. The title “A×60…” is 81 characters; it can be at most 80. Nothing was changed.", marked |
| 200 × B | kept 80, nothing said | refused, "… is 200 characters …" |
| 79 × a + U+1F600 | kept 80 units ending in a lone U+D83D; the workbook printed "…a�" (F2-base) | kept whole (81 units, ends `d83d de00`) |
| CONTROL 80 × x | kept | kept |
| CONTROL rcn 11 digits, eeic ß×10 | refused (item 91, R2) | the same |

**U37 (open; general to the workbook writer, not only the registry).** A character that XML 1.0 forbids goes into the
worksheet raw:
> **Superseded (fix round, 13 Oct):** U37 is P1: Chromium 141 keeps these characters on paste (FR-vpaste-chromium), and a destination name puts one into `xl/workbook.xml` (FR-vflow-*). "Not checked: … a real browser's paste" below no longer holds.

- An imported title `bad\u0001char\u000Bvt` puts U+0001 and U+000B into `xl/worksheets/sheet6.xml` (RCN-EEIC by Month),
  four times each. Measured on the opened file, after save and reopen, and after Import a full board and reopen
  (`logs/probe-base-file.log`).
- CONTROL (`logs/probe-base-ctl.log`): a requirement title with U+000B puts it into sheets 2, 4, 7 and 11 (Decision Bands,
  CR Cash Needs, Funded - Discretionary, PMO AV).
- The import door has no character rule for this text. rcnSet takes U+000B in a title and U+0001 in an RCN when it is
  called.
- The board's own reader reads the result back.
- Not checked: Excel or LibreOffice, and a real browser's paste.

**U38 (open).** A file keeps RCN / EEIC text that typing would refuse or change. The door passes it (`(passes)`), and it is
kept on every route:
- EEIC `aaaaa` (typing keeps `AAAAA`).
- `' 44444 '` and `' DDDDD '`, untrimmed.
- An EEIC of ten `ß`, not listed by codeIssues (it measures 10 as stored).
- A 300-character title, printed whole in RCN-EEIC by Month (315 characters with the codes).
- A 20-character EEIC is listed by codeIssues: "EEIC (RCN / EEIC list) “ABCDEFGHIJKLMNOPQRST” — 20 characters, at most 10".

**U39 (open).** Two entries with the same text print identical rows. K1 and K2, both "11111 / AAAAA  same", print USAF rows
of 900 and 300 under the same label (`logs/probe-base-more.log`). The totals are right.

**U40 (open).** Destination names. Typing "  Alpha  Depot " and then "ALPHA DEPOT" keeps both, and `destName` makes them
equal, so they are "the same destination" by the board's own rule. A name of 5,000 characters is kept
(`logs/probe-base-ctl.log`).
> **Superseded (fix round, 13 Oct):** U40 is data loss, measured (FR-vdest-*): opened in a browser whose destination list is newer, the two merge, a requirement changes its destination, and its money moves with nothing said. P1 proposed, at least P2.


**U41 (open).** SI codes. `S.si={R1:'la', R2:'LA '}` is applied, and the year then reads `{}`. Both codes are dropped,
nothing is said, and `siOf` gives `''` (`logs/probe-base-more.log`).
> **Superseded (fix round, 13 Oct):** U41 was measured through a file (FR-vsi-*): dropped on opening, lost on the next save, its money moved in the SI matrix to the derived code's row. P2 proposed. A new finding, U42 (funds-flow sheet names cut so as to split an emoji), is in "Fix round".


**Checked and sound (base):**
- **The screen.** In the hostile sweep with rcn, eeic and t planted (`logs/probe-base-sweep.log`, jsdom), the list was
  opened as a saved file and the sweep reached 7 requirements, 43 panels and 9 menus. All three planted tags were seen as
  text, no handler carries a planted call, and the RCN / EEIC panel's inputs hold the payload as their values with 0
  `<img>`.
- **Formulas.** No `<f>` appeared in any workbook part made by any route. A title `<b>&amp; =1+1` with money prints exactly
  so (`logs/probe-base-more.log`).
- **CSV.** The two CSVs (Proposed 1-N order, Exec Funding Synopsis) carry no registry text and use `csvCell` (by code).
- **PPTX.** It reads no registry field (by code: no `rcnEntry` / `rcnLabel` / `.eeic` in the slide builder).
- **Saved file.** Its JSON escapes `<` (`buildSavedHtml`, `.replace(/</g,'\\u003c')`).

## Decisions, and how each meets the lead's principles
- **Only U36 is fixed.** It is minimal (one stored line becomes a five-line branch, and the panel's field passes itself),
  and it follows a rule the board already has (item 91: "A CODE OVER ITS LIMIT IS REFUSED, NEVER CUT").
  - **(1) Never lose a copy:** typed text is no longer thrown away unseen, and the field keeps what was typed.
  - **(2) Refuse rather than guess:** refused, not cut.
  - **(3) Money and exports:** no figure changes. The workbook prints the title that is kept, and no longer half an emoji.
  - **(4) Words stay true:** the status names the title, its length and the limit, and says nothing was changed, which is
    true (the function returns before `save()`). The count is by Unicode character, so "81 characters" matches what was
    typed for an emoji. A ZWJ sequence (one glyph, several code points) still counts as several, which is a limit.
  - **(5) Smallest change:** about five lines.
  - **(6) Preserved:** no existing check, fixture or expected value was edited. No existing test types a title (searched
    `tools/` for `rcnSet(…'t'` and the title field), and every existing mutation still matches once (mcount below).
- **U37 is not fixed here.** The cause is the workbook writer (`_xesc` escapes `& < > "` only), and every export shares it,
  so a registry-only rule would leave every other text field open. A real fix needs a decision: refuse the export (naming
  the cell, as the IDS export already does with `IDS_BADCH`), or write the OOXML `_xHHHH_` escape (which also needs a
  literal `_xHHHH_` in text escaped, and the board's reader to decode it, or round-trip checks change). Neither is "minimal
  and clearly right" for this track.
- **U38 is not fixed.** Item 91's settled design is that a code arriving in a file is kept whole and flagged, never cut or
  refused. Normalizing (upper-casing, trimming) a file's text, or refusing a whole board for a long title, would change that
  design and needs Brad's decision. No money effect was found, because nothing compares RCN / EEIC text.
- **U39, U40 and U41 are not fixed.** No money is wrong, and each would need a new rule: uniqueness of codes, of
  destination names, or a notice for a dropped SI code.
> **Superseded (fix round, 13 Oct):** "No money is wrong" is false for U40 and U41 (see above and "Fix round"). They stay unfixed by this track, for the lead's decision.

- **Where the block goes:** audit-recon, after "end v2.00 (U14)", where the v2.00 blocks with markers sit. This is the same
  point the CYCREG track inserts at, so the lead's merge puts one block after the other. The rcnSet checks of R2 live in
  audit-board's W1 section, which has no v2.00 markers, and the lead runs audit-board alone.

## The suite block (audit-recon, after "// ==== end v2.00 (U14) ====")
> **Superseded (fix round, 13 Oct):** the block is now named "v2.00 (U36) — …", with 15 checks (10 fail on the base, 5 controls); blob of `blocks/block-regtext.mjs.txt` b42b2694. See "Fix round".

The block is `blocks/block-regtext.mjs.txt` (blob a9d4a1bc), inserted verbatim. Its name is "v2.00 (REGTEXT) — an RCN /
EEIC title over 80 characters is refused, never cut". It has 12 checks: 8 on the defect and 4 CONTROLS. Expected values are
literals ('A'.repeat(81) and the like are written in the block), and board helpers are used only to observe.

The block follows the v2.00 form:
- the async wrapper;
- `bootMark` / `bootRelease(__bm, [])` / `settleBoards` (audit-recon's own form, as in CYCREG; this suite has no
  keepBoards);
- the two-space `  const name = '...';` line;
- the `// ==== ` and `// ==== end ` markers.

## Mutations (mutate.mjs.txt, TEXT only; inserted before the R3 comment line)
> **Superseded (fix round, 13 Oct):** eight entries now (three added), under the comment "// v2.00 (U36): …"; mcount 1336/1336 once. See "Fix round".

Entries are in `blocks/entries-regtext.mjs.txt` (blob d4852f60), under one comment line:
- `v200-regtext-title-no-limit`
- `v200-regtext-title-cut`
- `v200-regtext-title-halves`
- `v200-regtext-refused-but-kept`
- `v200-regtext-field-unmarked`

Mutants were built with `rec/bin/mkmut.py` (each find matched once) into `mut/c1/`.

mcount (text only, `rec/bin/mcount.py`; `out/mcount-*.txt`):
- c1 mutate on the c1 board: 1333 entries, 1333 once. The five new ones match once each (`out/mcount-c1-ids.txt`).
- base mutate on the base board: 1328 entries, 1328 once.
- base mutate on the c1 board: 1328 entries, 1328 once. My edit breaks no existing find.
- c1 mutate on the base board: the five new ids are missing, as they should be. The other 1328 match once.

## Every run (label, start ET, exit, wall seconds, log)
Every node run went through `bin/run.sh` (setsid -w timeout -k 10 600, the lock checked first; it never had to wait).

| label | start (ET) | exit | wall s | log |
|---|---|---|---|---|
| probe-base-type | 2026-10-12 20:17:06 EDT | 0 | 22.1 | logs/probe-base-type.log |
| probe-base-file | 2026-10-12 20:17:34 EDT | 0 | 17.0 | logs/probe-base-file.log |
| probe-base-ctl | 2026-10-12 20:18:05 EDT | 0 | 9.9 | logs/probe-base-ctl.log |
| probe-base-sweep | 2026-10-12 20:18:27 EDT | 0 | 131.2 | logs/probe-base-sweep.log |
| probe-base-more | 2026-10-12 20:21:30 EDT | 0 | 11.5 | logs/probe-base-more.log |
| F1-c1 | 2026-10-12 20:24:55 EDT | 0 | 11.1 | logs/F1-c1.log |
| F1-base | 2026-10-12 20:25:07 EDT | 1 | 13.5 | logs/F1-base.log |
| F2-c1 | 2026-10-12 20:26:34 EDT | 0 | 9.6 | logs/F2-c1.log |
| F2-base | 2026-10-12 20:26:44 EDT | 1 | 11.4 | logs/F2-base.log |
| M-v200-regtext-title-no-limit | 2026-10-12 20:26:56 EDT | 1 | 11.9 | logs/M-v200-regtext-title-no-limit.log |
| M-v200-regtext-title-cut | 2026-10-12 20:27:08 EDT | 1 | 8.6 | logs/M-v200-regtext-title-cut.log |
| M-v200-regtext-title-halves | 2026-10-12 20:27:17 EDT | 1 | 8.5 | logs/M-v200-regtext-title-halves.log |
| M-v200-regtext-refused-but-kept | 2026-10-12 20:27:25 EDT | 1 | 9.7 | logs/M-v200-regtext-refused-but-kept.log |
| M-v200-regtext-field-unmarked | 2026-10-12 20:27:35 EDT | 1 | 9.7 | logs/M-v200-regtext-field-unmarked.log |
| S-boot-same-c1 | 2026-10-12 20:28:23 EDT | 0 | 24.4 | logs/S-boot-same-c1.log |
| S-audit-c1 | 2026-10-12 20:28:47 EDT | 0 | 19.4 | logs/S-audit-c1.log |
| S-audit-ppt-c1 | 2026-10-12 20:29:07 EDT | 0 | 6.8 | logs/S-audit-ppt-c1.log |
| probe-c1-type | 2026-10-12 20:29:49 EDT | 0 | 22.1 | logs/probe-c1-type.log |
| S-audit-other-c1 | 2026-10-12 20:29:13 EDT | 0 | 65.8 | logs/S-audit-other-c1.log |
| S-audit-recon-c1 | 2026-10-12 20:30:19 EDT | 0 | 200.2 | logs/S-audit-recon-c1.log |
| S-legacy-fsrc-c1 | 2026-10-12 20:33:39 EDT | 0 | 5.2 | logs/S-legacy-fsrc-c1.log |
| S-audit-hostile-c1 | 2026-10-12 20:33:45 EDT | 0 | 64.0 | logs/S-audit-hostile-c1.log |
| S-audit-inject-c1 | 2026-10-12 20:34:49 EDT | 0 | 11.7 | logs/S-audit-inject-c1.log |
| check-c1 | 2026-10-12 20:35:00 EDT | 0 | 3.1 | logs/check-c1.log |
| S-boot-same-base | 2026-10-12 20:35:04 EDT | 0 | 8.9 | logs/S-boot-same-base.log |
| S-audit-base | 2026-10-12 20:35:12 EDT | 0 | 12.0 | logs/S-audit-base.log |
| S-audit-ppt-base | 2026-10-12 20:35:25 EDT | 0 | 5.0 | logs/S-audit-ppt-base.log |
| S-audit-other-base | 2026-10-12 20:35:30 EDT | 0 | 39.5 | logs/S-audit-other-base.log |
| S-audit-recon-base | 2026-10-12 20:36:09 EDT | 0 | 93.3 | logs/S-audit-recon-base.log |
| S-legacy-fsrc-base | 2026-10-12 20:37:42 EDT | 0 | 4.8 | logs/S-legacy-fsrc-base.log |
| S-audit-hostile-base | 2026-10-12 20:37:47 EDT | 0 | 71.5 | logs/S-audit-hostile-base.log |
| S-audit-inject-base | 2026-10-12 20:38:59 EDT | 0 | 15.2 | logs/S-audit-inject-base.log |
| check-base | 2026-10-12 20:39:14 EDT | 0 | 4.4 | logs/check-base.log |

## Focused harness runs (`out/focused-summary.txt`)
> **Superseded (fix round, 13 Oct):** the final harness is `harness/fr/h-u36.mjs` (c9910c10): c1 15/15, base 5 pass / 10 fail, 8 mutants caught. See "Fix round".

```
F1-c1 | ALL CHECKS PASSED | 12p/0f
F1-base | 8 FAILING CHECK(S) | 4p/8f
focused start 20:26:34 EDT harness 4d88657319653846c7ec2cdf674d643f90ce4386
F2-c1 | ALL CHECKS PASSED | 12p/0f
F2-base | 8 FAILING CHECK(S) | 4p/8f
M-v200-regtext-title-no-limit | 5 FAILING CHECK(S) | 7p/5f
M-v200-regtext-title-cut | 3 FAILING CHECK(S) | 9p/3f
M-v200-regtext-title-halves | 4 FAILING CHECK(S) | 8p/4f
M-v200-regtext-refused-but-kept | 5 FAILING CHECK(S) | 7p/5f
M-v200-regtext-field-unmarked | 1 FAILING CHECK(S) | 11p/1f
focused done 20:27:45 EDT
```
- **F1-c1**: 12 pass, 0 fail
- **F1-base**: 4 pass, 8 fail:
  - FAIL `title typed as 81 letters` — refused: the list keeps "base", the field keeps what was typed, marked, and the status says the title was not changed — got `["AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",null,true,""]`
  - FAIL `title typed as 200 letters` — refused, the same: nothing is cut to 80 and kept — got `["BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB",null,true,""]`
  - FAIL `title typed as 80 letters and an emoji` — 81 characters (82 halves): refused, said as 81 characters — got `["aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",null,true,""]`
  - FAIL `the workbook after the refusals` — RCN-EEIC by Month still prints K1 as "11111 / AAAAA  base": USAF 900, ANG 200 — got `[["11111 / AAAAA  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",900],["11111 / AAAAA  aaaaaaaaaaaaaaaaaaaaaaaaaaaa`
  - FAIL `title typed as 79 letters and an emoji` — 80 characters: kept whole, the emoji too (no half of one), the field not marked, nothing said — got `["aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\ud83d",null,true,""]`
  - FAIL `the workbook with that title` — RCN-EEIC by Month prints it whole, emoji and all: USAF 900, ANG 200 — got `[["11111 / AAAAA  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa�",900],["11111 / AAAAA  aaaaaaaaaaaaaaaaaaaaaaaaaaaa`
  - FAIL `saved and reopened` — the file keeps the title whole, emoji and all — got `[["K1","aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\ud83d"]]`
  - FAIL `the title field in the RCN / EEIC panel` — 81 letters typed there: refused, and that same field stays on screen holding them, marked — got `["AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",null,true,false]`
- **F2-c1**: 12 pass, 0 fail
- **F2-base**: 4 pass, 8 fail:
  - FAIL `title typed as 81 letters` — refused: the list keeps "base", the field keeps what was typed, marked, and the status says the title was not changed — got `["AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",null,true,""]`
  - FAIL `title typed as 200 letters` — refused, the same: nothing is cut to 80 and kept — got `["BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB",null,true,""]`
  - FAIL `title typed as 80 letters and an emoji` — 81 characters (82 halves): refused, said as 81 characters — got `["aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",null,true,""]`
  - FAIL `the workbook after the refusals` — RCN-EEIC by Month still prints K1 as "11111 / AAAAA  base": USAF 900, ANG 200 — got `[["11111 / AAAAA  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",900],["11111 / AAAAA  aaaaaaaaaaaaaaaaaaaaaaaaaaaa`
  - FAIL `title typed as 79 letters and an emoji` — 80 characters: kept whole, the emoji too (no half of one), the field not marked, nothing said — got `["aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\ud83d",null,true,""]`
  - FAIL `the workbook with that title` — RCN-EEIC by Month prints it whole, emoji and all: USAF 900, ANG 200 — got `[["11111 / AAAAA  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa�",900],["11111 / AAAAA  aaaaaaaaaaaaaaaaaaaaaaaaaaaa`
  - FAIL `saved and reopened` — the file keeps the title whole, emoji and all — got `[["K1","aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\ud83d"]]`
  - FAIL `the title field in the RCN / EEIC panel` — 81 letters typed there: refused, and that same field stays on screen holding them, marked — got `["AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",null,true,false]`
- **M-v200-regtext-title-no-limit**: 7 pass, 5 fail:
  - FAIL `title typed as 81 letters` — refused: the list keeps "base", the field keeps what was typed, marked, and the status says the title was not changed — got `["AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",null,true,""]`
  - FAIL `title typed as 200 letters` — refused, the same: nothing is cut to 80 and kept — got `["BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB`
  - FAIL `title typed as 80 letters and an emoji` — 81 characters (82 halves): refused, said as 81 characters — got `["aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa😀",null,true,""]`
  - FAIL `the workbook after the refusals` — RCN-EEIC by Month still prints K1 as "11111 / AAAAA  base": USAF 900, ANG 200 — got `[["11111 / AAAAA  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa😀",900],["11111 / AAAAA  aaaaaaaaaaaaaaaaaaaaaaaaaaa`
  - FAIL `the title field in the RCN / EEIC panel` — 81 letters typed there: refused, and that same field stays on screen holding them, marked — got `["AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",null,true,false]`
- **M-v200-regtext-title-cut**: 9 pass, 3 fail:
  - FAIL `title typed as 79 letters and an emoji` — 80 characters: kept whole, the emoji too (no half of one), the field not marked, nothing said — got `["aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\ud83d",null,true,""]`
  - FAIL `the workbook with that title` — RCN-EEIC by Month prints it whole, emoji and all: USAF 900, ANG 200 — got `[["11111 / AAAAA  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa�",900],["11111 / AAAAA  aaaaaaaaaaaaaaaaaaaaaaaaaaaa`
  - FAIL `saved and reopened` — the file keeps the title whole, emoji and all — got `[["K1","aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\ud83d"]]`
- **M-v200-regtext-title-halves**: 8 pass, 4 fail:
  - FAIL `title typed as 80 letters and an emoji` — 81 characters (82 halves): refused, said as 81 characters — got `["base","true",true,"⚠ RCN / EEIC title not changed. The title “aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa…” is 82 characters; it ca`
  - FAIL `title typed as 79 letters and an emoji` — 80 characters: kept whole, the emoji too (no half of one), the field not marked, nothing said — got `["base","true",true,"⚠ RCN / EEIC title not changed. The title “aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa…” is 81 characters; it ca`
  - FAIL `the workbook with that title` — RCN-EEIC by Month prints it whole, emoji and all: USAF 900, ANG 200 — got `[["11111 / AAAAA  base",900],["11111 / AAAAA  base",200]]`
  - FAIL `saved and reopened` — the file keeps the title whole, emoji and all — got `[["K1","base"]]`
- **M-v200-regtext-refused-but-kept**: 7 pass, 5 fail:
  - FAIL `title typed as 81 letters` — refused: the list keeps "base", the field keeps what was typed, marked, and the status says the title was not changed — got `["AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","true",true,"⚠ RCN / EEIC title not changed. The title “AAAAAAAAA`
  - FAIL `title typed as 200 letters` — refused, the same: nothing is cut to 80 and kept — got `["BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB`
  - FAIL `title typed as 80 letters and an emoji` — 81 characters (82 halves): refused, said as 81 characters — got `["aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa😀","true",true,"⚠ RCN / EEIC title not changed. The title “aaaaaaaaa`
  - FAIL `the workbook after the refusals` — RCN-EEIC by Month still prints K1 as "11111 / AAAAA  base": USAF 900, ANG 200 — got `[["11111 / AAAAA  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa😀",900],["11111 / AAAAA  aaaaaaaaaaaaaaaaaaaaaaaaaaa`
  - FAIL `the title field in the RCN / EEIC panel` — 81 letters typed there: refused, and that same field stays on screen holding them, marked — got `["AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","true",true,false]`
- **M-v200-regtext-field-unmarked**: 11 pass, 1 fail:
  - FAIL `the title field in the RCN / EEIC panel` — 81 letters typed there: refused, and that same field stays on screen holding them, marked — got `["base",null,true,true]`

## Suites (scratch git clones gc/c1 and gc/base at 7ee498a; c1 = 7ee498a + this board + this audit-recon)
```
batch c1 start 20:28:23 EDT
S-boot-same-c1 |  | exit: 0  wall_s: 24.4
S-audit-c1 | ALL CHECKS PASSED | exit: 0  wall_s: 19.4
S-audit-ppt-c1 | ALL CHECKS PASSED | exit: 0  wall_s: 6.8
S-audit-other-c1 | ALL CHECKS PASSED | exit: 0  wall_s: 65.8
S-audit-recon-c1 | ALL CHECKS PASSED | exit: 0  wall_s: 200.2
S-legacy-fsrc-c1 |  | exit: 0  wall_s: 5.2
S-audit-hostile-c1 | ALL CHECKS PASSED | exit: 0  wall_s: 64.0
S-audit-inject-c1 | ALL CHECKS PASSED | exit: 0  wall_s: 11.7
check-c1 | exit: 0  wall_s: 3.1
batch c1 done 20:35:04 EDT
batch base start 20:35:04 EDT
S-boot-same-base |  | exit: 0  wall_s: 8.9
S-audit-base | ALL CHECKS PASSED | exit: 0  wall_s: 12.0
S-audit-ppt-base | ALL CHECKS PASSED | exit: 0  wall_s: 5.0
S-audit-other-base | ALL CHECKS PASSED | exit: 0  wall_s: 39.5
S-audit-recon-base | ALL CHECKS PASSED | exit: 0  wall_s: 93.3
S-legacy-fsrc-base |  | exit: 0  wall_s: 4.8
S-audit-hostile-base | ALL CHECKS PASSED | exit: 0  wall_s: 71.5
S-audit-inject-base | ALL CHECKS PASSED | exit: 0  wall_s: 15.2
check-base | exit: 0  wall_s: 4.4
batch base done 20:39:18 EDT
```

## Drafts for the lead
- `drafts/NEXT-VERSION-entry.md`: the v2.00 entry, in the U13/U1/U14 style, to go after the U14 bullet. It holds what was
  wrong, what changes, "What users may see", "Test", "Mutations", and "Not covered" with every limit.
- `drafts/UNRESOLVED-line.md`: "Unresolved after R1–R5" has NO line for U35 on the base, or at orbit-board `60336a0`
  (searched). This is a proposed NEW line after the U14 line, not a replacement.
- `drafts/LEDGER-append.md`: text to append to row U35, and new rows U36–U41 for `recovery/v200/UNRESOLVED-LEDGER.md`
  (rows exist up to U35 at `60336a0`), with `<sha>` and `<time>` placeholders. The numbers U36–U41 are placeholders too.
- `drafts/MATRIX-limits.md`: the evidence-matrix rows. Each question has its answer on the base, its evidence, and its
  limit (what is not established).
- `drafts/COMMIT-MSG.txt`: the commit message. The attribution lines are the lead's to add.

## PIDs
`pids.txt` holds every timeout PID and its child, recorded by `bin/run.sh` and `bin/bx.sh` with the command. It also holds
the background batch: bash 23472 (my shell), setsid 23474 and timeout 23475, which ran `bin/suites-both.sh` with a 7,000 s
cap around 600 s runs. I killed nothing. Every run ended on its own (exit codes above), and none hit its 600 s cap.

## What I did NOT do
- **Fix U37–U41.** They are open, with their limits stated; reasons are under Decisions.
- **Run the full `audit-import.mjs` or `audit-board.mjs`** (the lead's). By reading:
  - audit-board calls `rcnSet` only with `'rcn'` and `'eeic'` (lines 4063, 4112, 4145). audit-recon line 4075 does the same,
    and it ran whole here.
  - No tool in `tools/` types a title or uses the title field (searched for `what this line funds`, `rcnSet(…'t'` and
    `&quot;t&quot;`). layout-fits opens the panel only for layout, and the change adds no element.
  - No import path is touched, so no focused audit-import harness was run.
- **Import, execute or run `mutate.mjs`.** It was read as text only (`mcount.py` / `mkmut.py`). The scratch clones keep the
  repository's own `mutate.mjs` untouched and unrun.
- **Edit, stage, commit or push** anything in /home/user/orbit-board or /home/user/orbit-ui. The scratch clones (`gc/base`,
  `gc/c1`, `git clone --shared`, checked out at `7ee498a`) were never committed to.
- **Install playwright or run Chromium.** Every check is jsdom. Chromium's hostile-render with registry text planted was not
  run.
- **Change the board file** from the empty template. Synthetic data exists only at run time.
- **Check:**
  - Excel or LibreOffice opening a workbook with a forbidden character (U37), or a 32,767-character cell;
  - a real browser's paste of control characters into a field;
  - a PDF;
  - BAE budget names, beyond the existing hostile sweep;
  - a file carrying an unknown SI code (U41 was measured through `applyState`).
- **Count a ZWJ emoji sequence (one glyph, several code points) as one character.** The new limit counts Unicode code
  points, so such a sequence counts as several. `inShow` (the board's existing helper) cuts its quoted preview at 60 UTF-16
  units, so a preview can end in half an emoji. That is in the status line only, and nothing is stored.

## Notes on the runs (read before trusting a line above)
- **Suites: base and c1 match.** Every allowed suite passes on both, and so does `npm run check`. boot-same, legacy-fsrc
  and check print their own pass lines in both logs ("every page, source, save and error list is identical either way",
  "every legacy Force setting computes exactly as before", "all checks passed"). audit, audit-ppt, audit-other,
  audit-recon, audit-hostile and audit-inject print ALL CHECKS PASSED on both. audit-recon on c1 includes the new block,
  and its scenario-ran guard passed. The clones were checked after the batch: `gc/c1` differs from `7ee498a` only in the
  board (55b2973d) and audit-recon (cf65a9e6); `gc/base` is clean. Neither has a commit beyond `7ee498a`.
- **F1-c1 and F1-base used the first harness** (blob 5f0076e6). Its block said "9 of its 13 checks" in the FAILS ON comment.
  That comment was corrected to "8 of its 12" (a comment-only edit, `blocks/block-regtext.mjs.txt` now a9d4a1bc). The
  harness was rebuilt verbatim (4d886573), and **F2-* and the M-* runs used the final harness**: c1 12/12; base 4 pass and 8
  fail; every mutant caught.
- **The probe was edited after the base probes ran.**
  - Section 4's printed header said "… and in a PPBE line's codes" when it ran (`logs/probe-base-sweep.log`). **No PPBE line
    was planted**; the header was wrong, and it now reads "(rcn, eeic, t)" only.
  - Section 5 (`more`) was appended afterwards and ran as `probe-base-more`.
  - Sections 1–3 are unchanged since `probe-base-type`, `-file` and `-ctl` ran. `probe-c1-type` ran the current probe
    (blob 9c701174).
- **The AUDIT_IMPORT_RUNNING lock was never present**, so no run waited.
- **Deviations from "every command bounded by setsid -w timeout -k 10 600":**
  - The first looks at files (ls, cat, grep, sed, git log in /home/user/orbit-board, read only) were unbounded shell
    commands.
  - The diff, cp and git hash-object commands were unbounded.
  - The background batch wrapper had a 7,000 s cap around many 600 s runs.
  - The Monitor wait loop (5 s polls on a file and on PID 23475) was capped at 30 minutes by the tool.
  - Every node run itself went through `run.sh`, and every python text helper through `bx.sh`.


## Fix round (13 Oct; started 5:28 AM ET, after the two verifier reports)

Everything above this heading is the builder's record of 12 Oct. Where the fix round changed something, a "Superseded (fix
round, 13 Oct)" note now stands under that heading; no earlier line was deleted. The builder's copy, blocks, drafts, diffs and
README are kept as they were in `superseded/` (`c1-build`, `blocks-build`, `drafts-build`, `diffs-build`, `README-build.md`).

### What I kept from the stopped attempt
Nothing was there to keep. At 5:28 AM ET my directory held no fix-round work: no file outside the two verifier folders
(`verify-money-r1`, `verify-tests-r1`) and the harness's `wfstate/` had changed after the build's last write (8:39 PM ET,
12 Oct), there was no "Fix round" section, and c1's blobs were the builder's (board 55b2973d, audit-recon cf65a9e6, mutate
c4b661cb). The verifiers' folders were read, never edited. I took from them, as text: the verifier-B proposal `prop2`
(audit-recon 09ae8ab7, mutate 972f03a3, checked to differ from the builder's c1 only by `diffs/prop2-*.diff`), and the
verifier-A probes `vprobe`, `vdest`, `vsi`, `vflow`, `vpaste` (copied to `probe/verifier/`, unchanged except that `vpaste.mjs`
now loads playwright-core from the copy's own node_modules; blobs below). Every verifier result I rely on was re-run here.

### What each finding got
| verifier finding | kind | what I did |
|---|---|---|
| U40 understated (A, must-fix) | records | Rewritten in all five drafts: measured data loss (a requirement changes its destination, money moves, nothing said), P1 proposed / at least P2, the lead decides on release. "No money is wrong" and "by code, not run" removed. Re-measured here: `FR-vdest-base`, `FR-vdest-c1`. Code not changed (needs the lead's decision); both candidate fixes written in the ledger row. |
| U37 severity (A, must-fix) | records | P1 in all drafts, "a real browser's paste was not checked" struck, `xl/workbook.xml` added to its reach, release-note wording as a known P1 export defect, the two fixes named for the lead. Re-measured: `FR-vpaste-chromium`, `FR-vflow-*`, `FR-probe-c1-type`. |
| "Silent truncation: none found" false (A, should-fix) | records | Matrix row corrected; the funds-flow sheet-name cut is a new open row, **U42** (P2), with its candidate fix. Re-measured: `FR-vflow-*`. Code not changed (see Decisions). |
| U41 through a file (A, should-fix) | records | Rewritten: dropped on opening, lost on the next save, money moved to the derived code's row; P2 proposed; `pmoNorm` contrast added. Re-measured: `FR-vsi-*`. |
| "an emoji counts once" false (A, should-fix) | board comment, block comment, drafts | Reworded everywhere to "counted by Unicode code point … a joined emoji, a flag or a letter with a separate accent counts as several". Re-measured: `FR-vprobe-c1` section 3. |
| "every way in / every place out" overclaims (A, should-fix) | records | The routes not followed are named in NEXT-VERSION, the Unresolved line, the U35 append and the matrix. |
| Bounding (A, should-fix) | process | Every fix-round node and Chromium run went through `bin/run.sh` (600 s cap, lock checked); wrappers were themselves capped at 600 s. The exceptions are listed under "Deviations". |
| Test gap: 3 wrong fixes pass (B, should-fix) | test + mutations | `prop2` adopted verbatim: +2 checks, +1 control, +3 mutation entries. |
| inShow preview half emoji (B minor, A minor) | records | Not changed (shared helper); stated as a limit. |
| Refused title lives in the field until redraw (A minor) | records | Said in "What users may see". |
| U36 also stops a file's long title being cut (A minor) | records | Said in the entry, the commit message and the U36 row; re-measured `FR-vprobe-base` 1b–1e (80) against `FR-vprobe-c1` (100). |
| "at most 80" vs a file's longer title (A minor) | records | Said under U38. |
| Comment prefix "(REGTEXT)" (A minor; house-style rule) | board, suite, mutate | Now "// v2.00 (U36):", the block "v2.00 (U36) — …", its markers, and the mutate comment "// v2.00 (U36): …". |
| Mutate comment "REGTEXT, U35" (B minor) | mutate | Now "U36". |
| Controls pass on the base (B minor) | — | Kept: the block as a whole fails on the base (10 of 15) and passes on c1; its 5 controls are house style. |
| Probe provenance (B minor) | — | Already disclosed by the builder; the fix round's probes are logged with their blobs. |

### The commit, now (one commit; copy `c1`)
> **Superseded (fix round 2, 13 Oct):** the commit is now board abcb8bac, audit-recon b2a8b693, mutate.mjs.txt 7843cae0 (see "Fix round 2" below). The blobs in this section are round 1's, kept in `superseded/c1-fr1`.

`1: v2.00 (U36): an RCN / EEIC title over 80 characters is refused, never cut | copy c1 | board
0949c3ed169e6d0515c587ba030a564f9abd8ae9 | suites audit-recon 08c1275e8c260b1a037aa5aa8b072c2a979a57fe (audit-import 4aba2506,
audit-board a7c575e5, audit-other d89396b0 unchanged) | mutate 41c64701beaa3b9345e7c2b1a66b6f1ac67a2b2d`

Message: `drafts/COMMIT-MSG.txt` (d6d780da); the lead adds the attribution lines. `diff -rq ../base c1` lists only these three
files.

| file | base blob | final c1 blob | diff against the base | diff against the build |
|---|---|---|---|---|
| prioritization-board-grid.html | fce8a391 | 0949c3ed169e6d0515c587ba030a564f9abd8ae9 | `diffs/c1-prioritization-board-grid.html.diff` (26 lines, ad312042) | comment only |
| tools/export-audit/audit-recon.mjs | 529e36f7 | 08c1275e8c260b1a037aa5aa8b072c2a979a57fe | `diffs/c1-audit-recon.mjs.diff` (98 lines, 7ea62650) | prop2 + names |
| tools/export-audit/mutate.mjs.txt | cbc6defc | 41c64701beaa3b9345e7c2b1a66b6f1ac67a2b2d | `diffs/c1-mutate.mjs.txt.diff` (34 lines, b26d894e) | prop2 + comment |

`diffs/c1-all.diff` (360d2356) concatenates the three. `diffs/fr-c1build-to-c1.diff` (113 lines, 27da3fcd) is the whole fix
round against the builder's c1. The block and the entries, verbatim: `blocks/block-regtext.mjs.txt` (89 lines, b42b2694),
`blocks/entries-regtext.mjs.txt` (25 lines, 25daf656).

The board change, exactly (the code is the builder's; only the comment changed in this round):
```diff
@@ -5118,7 +5118,7 @@   (rcnBody: the RCN / EEIC panel's title field)
-      +'onchange="rcnSet('+i+',&quot;t&quot;,this.value)"></td>'
+      +'onchange="rcnSet('+i+',&quot;t&quot;,this.value,this)"></td>'
@@ -10875,7 +10875,13 @@   (rcnSet)
-  else if(field==='t') e.t=String(val||'').trim().slice(0,80);
+  else if(field==='t'){ const t=String(val||'').trim(), n=Array.from(t).length;
+    // v2.00 (U36): a title over 80 characters is refused, never cut. It was cut to its first 80 without a word, and the
+    // cut could split a character in two: 79 letters and an emoji were kept as 79 letters and half of the emoji. Counted by
+    // Unicode code point, so an emoji stored as two halves counts once; a joined emoji, a flag or a letter with a separate
+    // accent mark is several code points, and counts as several.
+    if(n>80){ codeRefusedIn(el, 'RCN / EEIC title not changed', 'The title '+inShow(t)+' is '+n+' characters; it can be at most 80. Nothing was changed'); return; }
+    e.t=t; }
```

The suite change in this round (audit-recon, inside the block; verifier B's `prop2`, verbatim):
- check **"a refused title saves nothing"**: `DIRTY=false; MS.ts=1`, 81 letters typed; expected `['base', false, 1]`;
- check **"title typed as 81 letters with spaces before them"**: expected `['base','true',true,no('A'.repeat(60),81)]`;
- CONTROL **"title typed as 80 letters with spaces around them"**: expected `['y'.repeat(80), null, true, '']`;
- header comments now say 10 of 15 checks fail on d66dd60, 5 CONTROLS; the name, the opening marker and the end marker say
  "v2.00 (U36)".

Mutation entries added (after the builder's five, before the R3 comment line):
`v200-regtext-count-untrimmed` (counts before the trim), `v200-regtext-preview-untrimmed` (quotes `inShow(val)`),
`v200-regtext-refused-but-saved` (calls `save()` on a refusal). Two entries share the find "it can be at most 80. Nothing was
changed'); return; }" (`-refused-but-kept` and `-refused-but-saved`); each is a mutant of its own, and that find matches the
board once.

**Renumbering.** "U36" is a placeholder. If the lead renumbers it, it appears in: the board comment (1 line), audit-recon (the
opening marker, the `const name` line, the end marker), the mutate comment line, and the drafts. The mutation ids
(`v200-regtext-…`) carry no number.

### Decisions, and how the commit meets the lead's principles
- **One commit, as the track asked; only U36 is fixed in code.** U37, U40, U41 and U42 each change something outside the
  registry title (the shared workbook writer, the v1.86 destination fold, the year's SI cleaning, the funds-flow export), and
  for U37 and U40 the verifier itself wrote that the fix needs the lead's decision. Their records now say what was measured,
  with severities and candidate fixes, so the lead can decide.
- **(1) Never lose a copy:** typed text is no longer thrown away unseen, and a file's title over 80 is no longer cut by an
  edit (`FR-vprobe-base` 1d: 80 after save and reopen; `FR-vprobe-c1` 1d: 100). The refused text stays in the field until the
  next redraw (item 91's design, said in "What users may see").
- **(2) Refuse rather than guess:** refused, never cut.
- **(3) Money and exports:** no figure changes; RCN-EEIC by Month prints 900 / 200 under the kept title across refusals
  (block checks), and no longer prints half an emoji.
- **(4) Words true:** "Nothing was changed" is true and now tested (a refusal saves nothing). The counting sentence was false
  for joined emoji and separate accents and is corrected in the board comment, the block comment and every draft; the status
  number's limit is stated. The records' false sentences (U37, U40, U41, truncation, "every way") are corrected.
- **(5) Smallest change:** the board diff is the builder's: three code lines and four comment lines in rcnSet, plus the
  handler argument; this round changed only the comment.
- **(6) Preserved:** no existing check, fixture or expected value was edited. `FR-SC-audit-recon-fr` recorded every check:
  all 306 base checks (verifier B's base stream, `out/VSC-audit-recon-base.checks.jsonl.from-verifier`) are present with the
  same verdict and the same observed value; the 15 extra are U36's (`out/FR-cmpchecks-audit-recon.txt`). Every existing
  mutation entry still matches the c1 board once.

### Every run of the fix round (all through `bin/run.sh`: setsid -w timeout -k 10 600; the lock was checked first and never present)
> **Superseded (fix round 2, 13 Oct):** these runs are of round 1's copy (15 checks, 8 mutants). They stand as history; the runs of the final copy are under "Fix round 2".

| label | start (ET, 13 Oct) | exit | wall s | log | result |
|---|---|---|---|---|---|
| FR-F3-c1 | 05:36:18 | 0 | 6.1 | logs/FR-F3-c1.log | ALL CHECKS PASSED, 15p/0f |
| FR-F3-base | 05:36:24 | 1 | 4.5 | logs/FR-F3-base.log | 10 failing, 5 controls pass |
| FR-M-v200-regtext-title-no-limit | 05:36:29 | 1 | 3.7 | logs/FR-M-v200-regtext-title-no-limit.log | caught, 7 fail |
| FR-M-v200-regtext-title-cut | 05:36:33 | 1 | 3.2 | logs/FR-M-v200-regtext-title-cut.log | caught, 3 fail |
| FR-M-v200-regtext-title-halves | 05:36:36 | 1 | 3.3 | logs/FR-M-v200-regtext-title-halves.log | caught, 4 fail |
| FR-M-v200-regtext-refused-but-kept | 05:36:39 | 1 | 3.4 | logs/FR-M-v200-regtext-refused-but-kept.log | caught, 7 fail |
| FR-M-v200-regtext-field-unmarked | 05:36:43 | 1 | 2.7 | logs/FR-M-v200-regtext-field-unmarked.log | caught, 1 fail |
| FR-M-v200-regtext-count-untrimmed | 05:36:45 | 1 | 2.5 | logs/FR-M-v200-regtext-count-untrimmed.log | caught, 2 fail |
| FR-M-v200-regtext-preview-untrimmed | 05:36:48 | 1 | 2.7 | logs/FR-M-v200-regtext-preview-untrimmed.log | caught, 1 fail |
| FR-M-v200-regtext-refused-but-saved | 05:36:51 | 1 | 2.6 | logs/FR-M-v200-regtext-refused-but-saved.log | caught, 1 fail |
| FR-vprobe-c1 | 05:37:16 | 0 | 5.7 | logs/FR-vprobe-c1.log | file title 100 kept through an edit, save, reopen; counting; locked view refuses; workbook 900/200 |
| FR-vdest-c1 | 05:37:21 | 0 | 4.7 | logs/FR-vdest-c1.log | U40 merge on a newer-list open (DIFFERS) |
| FR-vsi-c1 | 05:37:26 | 0 | 3.2 | logs/FR-vsi-c1.log | U41: 'at' dropped on open, lost on save |
| FR-vflow-c1 | 05:37:29 | 0 | 3.2 | logs/FR-vflow-c1.log | U42 U+FFFD in a sheet name; U37 U+000B in workbook.xml |
| FR-vprobe-base | 05:37:32 | 0 | 10.5 | logs/FR-vprobe-base.log | base: file title cut to 80 by an edit and saved so; >80 cut silently |
| FR-vdest-base | 05:37:43 | 0 | 6.0 | logs/FR-vdest-base.log | the same merge on the base |
| FR-vsi-base | 05:37:49 | 0 | 3.7 | logs/FR-vsi-base.log | the same drop on the base |
| FR-vflow-base | 05:37:53 | 0 | 2.6 | logs/FR-vflow-base.log | the same on the base |
| FR-vpaste-chromium | 05:37:55 | 0 | 1.3 | logs/FR-vpaste-chromium.log | Chromium 141.0.7390.37 keeps U+000B/0001/0007/001F on Ctrl+V; insertText keeps U+000B/0001 |
| FR-probe-c1-type | 05:37:57 | 0 | 6.9 | logs/FR-probe-c1-type.log | builder probe section 1 on the final c1: 81 and 200 refused; 79a + emoji kept whole (d83d de00) |
| FR-S-boot-same-fr | 05:38:22 | 0 | 9.2 | logs/FR-S-boot-same-fr.log | "every page, source, save and error list is identical either way" |
| FR-S-audit-fr | 05:38:31 | 0 | 10.2 | logs/FR-S-audit-fr.log | ALL CHECKS PASSED |
| FR-S-audit-ppt-fr | 05:38:42 | 0 | 4.7 | logs/FR-S-audit-ppt-fr.log | ALL CHECKS PASSED |
| FR-S-audit-other-fr | 05:38:46 | 0 | 26.9 | logs/FR-S-audit-other-fr.log | ALL CHECKS PASSED |
| FR-S-audit-recon-fr | 05:39:21 | 0 | 87.7 | logs/FR-S-audit-recon-fr.log | ALL CHECKS PASSED (the scenario-ran guard heard the U36 block) |
| FR-S-legacy-fsrc-fr | 05:40:48 | 0 | 2.8 | logs/FR-S-legacy-fsrc-fr.log | "every legacy Force setting computes exactly as before" |
| FR-S-audit-hostile-fr | 05:40:57 | 0 | 53.0 | logs/FR-S-audit-hostile-fr.log | ALL CHECKS PASSED |
| FR-S-audit-inject-fr | 05:41:50 | 0 | 10.1 | logs/FR-S-audit-inject-fr.log | ALL CHECKS PASSED |
| FR-check-fr | 05:42:00 | 0 | 3.1 | logs/FR-check-fr.log | "all checks passed" |
| FR-SC-audit-recon-fr | 05:42:44 | 0 | 83.8 | logs/FR-SC-audit-recon-fr.log | ALL CHECKS PASSED; 321 checks recorded (306 base + 15 U36), compared in `out/FR-cmpchecks-audit-recon.txt` |

Text-only runs (through `bin/bx.sh`, 600 s cap, PIDs recorded): `FR-mcount-*` (05:34:42–05:35:02), `FR-mkfocused` (05:35:17),
`FR-mkmut-*` (05:35:17–05:35:21), `FR-clone-fr` / `FR-checkout-fr` (05:35:56–57), `extract-fr` (blocks/), `FR-mark-superseded`
(05:47:49). Every one exited 0.

**The focused harness** `harness/fr/h-u36.mjs` (c9910c10cf78cd1f13a65fb1dc2945c1cf204e08) was built by `rec/L3/u14/mkfocused.py`
from the final c1 audit-recon, block "v2.00 (U36)", verbatim. Base runs use root c1 with BOARD set to `../base`'s board
(fce8a391), as the builder's did. The failing checks for the base and for each mutant are listed in `out/FR-fails.txt`:
- base (10): 81 letters; 200 letters; 80 letters and an emoji; the workbook after the refusals; a refused title saves
  nothing; 79 letters and an emoji; the workbook with that title; saved and reopened; the title field in the panel; 81
  letters with spaces before them.
- `title-no-limit` (7) and `refused-but-kept` (7): 81; 200; 80 + emoji; the workbook after the refusals; a refused title
  saves nothing; the panel field; 81 with spaces before.
- `title-cut` (3): 79 + emoji; the workbook with that title; saved and reopened.
- `title-halves` (4): 80 + emoji; 79 + emoji; the workbook with that title; saved and reopened.
- `field-unmarked` (1): the panel field.
- `count-untrimmed` (2): 81 with spaces before; the CONTROL 80 with spaces around.
- `preview-untrimmed` (1): 81 with spaces before.
- `refused-but-saved` (1): a refused title saves nothing.

**mcount** (text only, `rec/bin/mcount.py`; `out/FR-mcount-*.txt`):
- final c1 mutate on the final c1 board: 1336 entries, 1336 once; the 8 U36 ids one match each;
- base mutate on the final c1 board: 1328 entries, 1328 once (my edits break no existing find);
- final c1 mutate on the base board: 1328 once, the 8 U36 ids missing, as they should be.

**Mutants** (`mut/fr/`, built by `rec/bin/mkmut.py`, each find matched once): title-no-limit 88ef10c2, title-cut 7e0a2b5b,
title-halves 1a92be1d, refused-but-kept a2b6a6c0, field-unmarked ed2f6c13, count-untrimmed 89ffd817, preview-untrimmed
8f4074df, refused-but-saved 708fa4ca.
> **Corrected (fix round 2, 13 Oct):** the line above pairs the names, in entry order, with the blobs in file-name order, so 7 of the 8 pairs are wrong (the money verifier, round 2). The true blobs (`git hash-object mut/fr/*`): count-untrimmed 88ef10c2, field-unmarked 7e0a2b5b, preview-untrimmed 1a92be1d, refused-but-kept a2b6a6c0, refused-but-saved ed2f6c13, title-cut 89ffd817, title-halves 8f4074df, title-no-limit 708fa4ca. The runs were not affected: each was run on the mutant file of its own name.

**Scratch clone** `gc/fr`: `git clone --shared /home/user/orbit-board`, checked out at 7ee498a, with the final c1 board and
audit-recon copied over and a node_modules symlink. Its own `tools/export-audit/mutate.mjs` equals the base's text (cbc6defc)
and was never run. Nothing was committed there.

**Base suites were not re-run in this round**: the base did not change; the builder's base runs (8:35–8:39 PM ET, 12 Oct) and
verifier B's (12:44 AM–4:28 AM ET, 13 Oct) stand.

### Probe blobs (fix round)
`probe/verifier/`: vdest 77db7642, vflow cee432ab, vpaste bd5cba79 (the verifier's 1081e2df with the require path changed),
vprobe 8395b14c, vsi 84a7f571. `probe/regtext.mjs` 9c701174 (the builder's, unchanged). Helpers: `bin/suites-fr.sh`
170678a7, `bin/extract-fr.py` 845ac2eb, `bin/mark-superseded.py` 7990e70e.

### Drafts (final; for the lead)
> **Superseded (fix round 2, 13 Oct):** every draft was rewritten in fix round 2; round 1's are kept in `superseded/drafts-fr1`. See "Fix round 2".

| file | blob | what changed in this round |
|---|---|---|
| `drafts/NEXT-VERSION-entry.md` | 8f3176c4 | rewritten: U36 title, the file-title data loss, counting, "What users may see" (3 points), Test 15/10/5, 8 mutations, U37 P1, U40 data loss, U41 through a file, U42, preview limit, routes not followed |
| `drafts/UNRESOLVED-line.md` | 2702e0d2 | a NEW line (no U35 line exists to replace), now with U37 P1, U40, U41, U42 and the routes not followed |
| `drafts/LEDGER-append.md` | 8934cc9b | U35 append rewritten; rows U36–U42 (U42 new); U36–U42 free at orbit-board f86889a |
| `drafts/MATRIX-limits.md` | 7d1f9281 | rows corrected (well-formedness, truncation, destination names, SI codes) and added (counting, preview, routes) |
| `drafts/COMMIT-MSG.txt` | d6d780da | U36 title, the file-title cut, counting, 15 checks / 10 / 5, eight mutations |
| `drafts/README-tail.md` | 985e345d | the builder's, unchanged and superseded by this README |

### PIDs
`pids.txt` lines 102–199 are this round's: each timeout PID and its child, with the command, from `bin/run.sh` and
`bin/bx.sh`. The group B and C suite wrappers are there (`bx:FR-suites-B` 13090/13093, `bx:FR-suites-C` 16046/16053). Not
recorded: the group A wrapper (`setsid -w timeout -k 10 600 bin/suites-fr.sh boot-same audit audit-ppt audit-other`, 05:38:22
to 05:39:13 ET), started directly from my shell; its four runs inside are recorded. I killed nothing. At 5:48 AM ET none of
the recorded PIDs was running (`ps` found none).

### Deviations in this round
- The group A wrapper's PIDs were not recorded (above).
- A few file writes and reads ran without the 600 s bound: the heredoc writes of `bin/extract-fr.py`, `bin/suites-fr.sh`,
  `bin/mark-superseded.py` and `drafts/COMMIT-MSG.txt`, a `chmod`, `echo` lines appended to `out/*-summary.txt`, `date`
  calls, one `git hash-object` of the drafts, and one inline python edit of the NEXT-VERSION draft. None runs node or
  Chromium. Every node and Chromium run was bounded and lock-checked.
- The Read, Edit, Write and Grep tools were used for reading and editing files; they are not shell commands.

### What I did NOT do in this round
- **Fix U37, U40, U41 or U42 in code.** Reasons under Decisions; candidates in the ledger rows.
- **Change `inShow`.** The refusal's preview can still end in half an emoji (status line and tooltip only).
- **Run the full audit-import or audit-board** (the lead's). No import path changed; by reading, no existing audit-board or
  audit-import check types an RCN / EEIC title (the builder's search; verifier B's focused audit-board W1 run passed on the builder's c1, whose code is the same).
- **Import, execute or run `mutate.mjs`.** It was read as text only.
- **Edit, stage, commit or push** anything in /home/user/orbit-board or /home/user/orbit-ui (read with `git show` and `git
  log` only). `gc/fr` was never committed to.
- **Run playwright install.** The one Chromium run used /opt/pw-browsers/chromium and the copy's playwright-core, on a
  synthetic page; the board itself was not opened in Chromium.
- **Follow** a cycle file, a PMO copy or submittal, a package or a service file; open Excel, LibreOffice or a PDF.
- **Change the board** from the empty template. Synthetic data exists only at run time.



## Fix round 2 (13 Oct; started 1:29 PM ET, after the two second-round reports)

Everything above is kept. Where this round changed something, a "Superseded (fix round 2, 13 Oct)" or "Corrected (fix round
2, 13 Oct)" note now stands under the heading; no earlier line was deleted. Round 1's copy, blocks, drafts, diffs, harness and
README are kept as they were in `superseded/` (`c1-fr1`, `blocks-fr1`, `drafts-fr1`, `diffs-fr1`, `harness-fr1`,
`README-fr1.md`).

### What I kept from a stopped attempt (at the start of this round, 1:29 PM ET)
Nothing was there to keep. At 1:29 PM ET nothing of mine had changed since round 1's last write (5:50 AM ET): no file outside
the four verifier folders and `wfstate/` was newer than README.md, c1's blobs were round 1's (board 0949c3ed, audit-recon
08c1275e, mutate 41c64701), and README.md had no "Fix round 2" section. The machine had been restarted at about 9:12 AM ET
(uptime), so every PID in `pids.txt` before this round is from before that boot; PID 11656 (timeout), running at 1:34 PM ET,
is someone else's reused number and was not touched. The verifiers' folders were read, never edited.

### Resumed after the usage-limit stop (13 Oct, from 2:44 PM ET)
A usage limit stopped this round at about 2:29 PM ET. I resumed at 2:44 PM ET. Before I resumed, none of the stopped
attempt's processes was still running: `ps` found none of its recorded PIDs (12487/12489, the last audit-recon run;
14520/14523, the last probe). The lock file was not present.

**What I kept from the stopped attempt, and why.** I kept everything it had finished. I checked it again first:
- The blobs of `c1` are the ones it recorded: board abcb8bac, audit-recon b2a8b693, mutate.mjs.txt 7843cae0. `gc/fr2`
  holds the same board and audit-recon. `diff -rq ../base c1` lists only those three files.
- Every `FR2-*` log has an exit record, except `FR2-SC2-audit-recon-fr2` (see below). The runs record (`logs/runs.txt`)
  agrees with each log.
- I read the code change again. It clears only the title's own refusal, only if that refusal is still the whole line, and
  only after `save(); render();`. It touches nothing else.
- I checked the message counter (`_statN`, item 79). `setStat('')` adds one to it, as every message does. If an automatic
  save is in flight, its "✓ Saved to the shared folder automatically" line is then not written. That line would describe a
  save made before this edit, and the edit marks the board changed again, so the next tick saves it. Nothing false is said.
  The refusal itself (`codeRefusedIn`) already counts the same way.
- I checked a locked view. `cycRefuse` writes a line that begins with 🔒, so the pattern does not match and nothing is
  cleared.
- I re-read the five drafts against both must-fixes. They name the slide deck in all five places, and they state what the
  clearing does and does not do.

**What I redid.** I redid one run. `FR2-SC2-audit-recon-fr2` (started 2:21:04 PM ET) has no exit record. It was stopped with
the attempt, after 280 checks had been recorded, all passing. That is not a result. I re-ran it as `FR2-SC3-audit-recon-fr2`
(below). Its own earlier run, `FR2-SC`, was killed by the kernel's OOM killer, also before it ended (298 checks recorded,
all passing). It is not a result either.

**What I finished.** These were not done when the attempt stopped:
- The placeholders in the round's notes: the SC run, the draft blobs and the PID check.
- One reference in the ledger draft, `FR2-SC2` → `FR2-SC3`.
- This README section. It merges `fr2/readme-fr2.md` and `fr2/readme-fr2-runs.md`, the attempt's notes, which are kept as
  they were apart from the placeholders.

**One thing for the lead to know: M1 is fixed in code, and the records-only alternative is written below.** The lead's
status table (orbit-board 379a9f7, read-only) gives round 2 as "1 must / 1 must (records only)". The tests verifier offered
two fixes for M1. The minimal one changed only the records. The alternative was code, and the verifier called it "the lead's
call, because it also changes item 91's RCN / EEIC behaviour". This round took the code fix, narrowed: it clears only the
title's own refusal, so item 91's behaviour does not change (`FR2-clear-c1`, `FR2-v2stale-*`). Principle (4) asks that the
words stay true after the operation lands, and a records-only fix would leave the board saying a false sentence. If the lead
prefers records only, the commit drops:
- the three board lines after `save(); render();`;
- the check "a refused title corrected in its field";
- the CONTROL "a title kept under another message";
- entries `-refusal-left-standing` and `-clears-any-message`.

The third "What users may see" bullet then reads, in the verifier's words: "The status line keeps the refusal until the
board's next message, and a title kept afterwards brings no message of its own: after a refused title is corrected in its
field, the corrected title is kept while the line still reads "RCN / EEIC title not changed … Nothing was changed". Item
91's code refusals behave the same way." The same limit then goes into "Not covered" and into the matrix row "Typed title
over 80". The counts become 22 checks, 13 failing on the base and 9 controls, and 18 entries. I did not build or run that
variant.

### What each finding got
| finding (lens) | kind | what I did |
|---|---|---|
| **M1** (tests, must-fix): after a refused title is corrected in its field, the status line still says "title not changed … Nothing was changed" | **code** (the verifier's alternative), plus records | Three lines at the end of `rcnSet`, after `save(); render();`: if the line still shows the TITLE's refusal, it is cleared. Only that refusal (item 91's code refusals are left as they were), and only if nothing has been said since, so anything save() said stands. New check (fails on the base and on round 1's board, passes here), a new CONTROL (another message stays), two mutation entries. Records say what clears it and what does not. |
| **U37 leaves out the PPTX** (money, must-fix) | records | All five drafts now name the slide deck: the same `_xesc`, a Plan Event with U+000B written raw into `ppt/slides/slide5.xml`; a fix must cover both writers. Re-measured: `FR2-v2probe-base`, `FR2-v2probe-c1` section 4. |
| **S1** test gap: 10 of 10 wrong fixes passed (tests, should-fix) | test + mutations | The verifier's `prop/` adopted verbatim (checked to differ from round 1's c1 only by its two recorded diffs): 6 checks (3 fail on the base, 3 CONTROLS), 9 entries. All 9 caught here (`FR2-M-*`). |
| **S2** the formula CONTROL cannot see a formula (tests, should-fix) | test + mutation + records | The block comment no longer says the markup-title control shows "a workbook cell holds text, never a formula" (it says why it cannot: the codes come first). A new CONTROL types an RCN "=1+1" and an EEIC "@a1" (each a cell of its own in the Spend Plan Source), reads every part of that file from its bytes, and wants 0 `<f>`, 0 compressed parts, and the two cells as text. New entry `v200-regtext-formula-cells` (the verifier's own3 mutant) is caught by it. The matrix's formula row now cites this control and the probe, and says why round 1's citation was wrong. |
| U38: "no money moves" true only inside the board (money, should-fix) | records | The Spend Plan Source prints a file's padded, lower-case codes as stored and nothing flags them: P2 proposed for that file, P3 on the board; candidate fix written. Re-measured: `FR2-v2probe-*` section 3. |
| The slide table's 56-unit cut splits an emoji (money, minor) | records | Named beside U42 (matrix, NEXT-VERSION, ledger append). Re-measured: `FR2-v2probe-*` section 5. |
| `buildXlsx` cuts every sheet name at 31 units (money, minor) | records | Named beside U42, by code (board line 24831). |
| README:548 pairs mutant names with the wrong blobs (money, minor) | records | Correction note added under that line with the true blobs. |
| "kept whole on screen" (tests, minor) | records | The Test text now says "kept whole in the list". |
| inShow preview (tests, minor) | — | Unchanged; still stated as a limit. |

**Changed since round 1 in the lead's records (read-only, orbit-board 191daf0, 1:43 PM ET):** rows U36–U42 now exist in the
ledger; U35 holds Codex's A1 finding (a Live refresh replacing uncommitted registry input), P2, deferred past v2.00 by the
lead; U37 and U40 are release blockers with their own fix tracks (u37, u40), and U41/U42 have one (u41u42). So the ledger
draft no longer proposes rows: it gives text to append to existing rows, and the round-1 "append to U35" text is withdrawn.
The NEXT-VERSION draft states U35's limit as the lead wrote it and says that each of the U37, U40, U41 and U42 paragraphs
stands only if its own fix does not land.

### The commit, now (one commit; copy `c1`)
`1: v2.00 (U36): an RCN / EEIC title over 80 characters is refused, never cut | copy c1 | board
abcb8bace6c45c5893f9f92c49e9c3ab017bffce | suites audit-recon b2a8b693226a0c35f370e97fcfeddb8bebbce07e (audit-import
4aba2506, audit-board a7c575e5, audit-other d89396b0 unchanged) | mutate 7843cae0262bfa4cc186d92bf16ffa3574447a49`

Message: `drafts/COMMIT-MSG.txt` (fc57e928); the lead adds the attribution lines. `diff -rq ../base c1` lists only these three
files. Against the base: board −2/+11, audit-recon −0/+162, mutate −0/+61 (pure additions in both suites).

| file | base blob | c1 blob (fix round 2) | diff against the base | diff against round 1 |
|---|---|---|---|---|
| prioritization-board-grid.html | fce8a391 | abcb8bace6c45c5893f9f92c49e9c3ab017bffce | `diffs/c1-prioritization-board-grid.html.diff` (30 lines, 72ba7841) | `diffs/fr2-fr1-to-c1-prioritization-board-grid.html.diff` (12 lines, bed5a805) |
| tools/export-audit/audit-recon.mjs | 529e36f7 | b2a8b693226a0c35f370e97fcfeddb8bebbce07e | `diffs/c1-audit-recon.mjs.diff` (171 lines, 71acd39c) | `diffs/fr2-fr1-to-c1-audit-recon.mjs.diff` (109 lines, 97708959) |
| tools/export-audit/mutate.mjs.txt | cbc6defc | 7843cae0262bfa4cc186d92bf16ffa3574447a49 | `diffs/c1-mutate.mjs.txt.diff` (70 lines, 254b2847) | `diffs/fr2-fr1-to-c1-mutate.mjs.txt.diff` (45 lines, d449108e) |

`diffs/c1-all.diff` (f37c021d) concatenates the three against the base; `diffs/fr2-fr1-to-c1.diff` (98be88f2) the three
against round 1. The block and the entries, verbatim: `blocks/block-regtext.mjs.txt` (162 lines, f9cc7598),
`blocks/entries-regtext.mjs.txt` (61 lines, e9ecd11a). (`bin/extract-fr.py` prints "block lines 1": its count reads a variable
it has already reused; the file itself is the 162 lines.)

The board change in this round, exactly (rcnSet; the rest of the board diff is round 1's):
```diff
@@ -10883,6 +10883,9 @@
     if(n>80){ codeRefusedIn(el, 'RCN / EEIC title not changed', 'The title '+inShow(t)+' is '+n+' characters; it can be at most 80. Nothing was changed'); return; }
     e.t=t; }
   save(); render();
+  // v2.00 (U36): a title refusal still on the line once a value is kept here would say "not changed" of a title just
+  // changed, so it goes. Only that refusal, and only if nothing has been said since: anything save() said stands.
+  const st=document.getElementById('shareStat'); if(st && /^⚠ RCN \/ EEIC title not changed\./.test(st.textContent)) setStat('');
 }
```
Why after `save(); render();` (the verifier suggested before): placed after, the test of the line itself tells whether
anything has been said since the refusal. If save() or render() said anything (a locked view's "🔒 … the change was not
kept", a save warning), the line no longer matches and is left alone. Placed there, the prop's two entries whose find is
`    e.t=t; }\n  save(); render();` still match once, unedited.

Why only the title's refusal: M1 is new with U36 (the base had no title refusal). Item 91's code refusals have behaved the
same way since v1.99 (an RCN refused and then corrected leaves "RCN not changed" on the line; `FR2-v2stale-base` and `-c1`
show it on both boards). Widening the pattern to `RCN|EEIC` would change item 91's behaviour, which the verifier called the
lead's call; it is a one-word change, written in the NEXT-VERSION limit.

The suite change in this round (audit-recon, inside the block; blob above):
- the verifier's six checks, verbatim (`prop/`, audit-recon 8d36ef0a; see its README);
- check **"a refused title corrected in its field"**: in the panel's own field, 81 letters refused, then "good title" typed
  there; expected `[no('A'.repeat(60), 81), 'good title', 'good title', null, '']` (the refusal's words right after it; the
  title kept; the redrawn field holding it, unmarked; the line empty);
- CONTROL **"a title kept under another message"**: `setStat('✓ Saved to the shared folder automatically — 9:05 AM.')`, then
  "other title" kept; expected `['other title', '✓ Saved to the shared folder automatically — 9:05 AM.']`;
- CONTROL **'codes typed as "=1+1" and "@a1", in the Spend Plan Source'**: expected `[['=1+1', '@A1', null], [0, 0, ['=1+1',
  '@A1']]]` (both kept, the field not marked; 0 `<f>` in any part, 0 compressed parts, both cells exactly that text);
- the header comment: the clearing; why the markup-title control cannot see a formula; the new controls; "14 of its 24 checks"
  fail on d66dd60; "The 10 CONTROLS pass there and here".

Mutation entries added in this round (after the prop's nine, before the R3 comment line; made by `fr2/mk-entries.py`
41820ab2 and inserted by `fr2/insert-entries.py` 9f3de84a, text only):
- `v200-regtext-refusal-left-standing` (area rcnSet): the clearing line removed;
- `v200-regtext-clears-any-message` (rcnSet): `if(st) setStat('');`, wiping any message;
- `v200-regtext-formula-cells` (buildXlsx): a text cell beginning with = + - @ written as `<f>` (the verifier's own3 mutant,
  find and repl verbatim from `verify-tests-r2/own/own3-mutants.json`).
The first two share one find; each is a mutant of its own. In the first insertion I wrote the board's ⚠ in the find as
`⚠`, but the board holds the character itself, so mcount found those two missing; I regenerated the entries with the
character and re-inserted them into a fresh copy of the prop's mutate text (`FR2-mk-entries-2`, `FR2-insert-entries-2`).

**Renumbering.** "U36" appears in the board comment (2 places now), audit-recon (the opening marker, the `const name` line, the
end marker) and the mutate comment line. The ids `v200-regtext-…` carry no number.

### Decisions, and how the commit meets the lead's principles
- **M1 by code, not words.** The records-only fix would have described a false sentence the board says; principle (4) asks
  that the words stay true after the operation lands. The code fix is three lines, touches only the refusal this change
  introduced, and leaves item 91 as it was (principle 5 and 6). The limits that remain are written down: a service box or Add
  a combination does not clear the refusal (`FR2-clear-c1`), and item 91's code refusals stay on the line as before.
- **(1) Never lose a copy:** unchanged from round 1: typed text is not thrown away unseen, and a file's title over 80 is kept
  and saved whole (now tested: "a 100-letter title from a file, retyped in the panel" and "that file saved and reopened").
- **(2) Refuse rather than guess:** refused, never cut; the clear guesses nothing (it acts only on the exact refusal text).
- **(3) Money and exports:** no figure changes; RCN-EEIC by Month prints 900 / 200 under the kept title across refusals, and
  workbook cells that begin with = or @ are now proven text by a control that can see a formula.
- **(4) Words true:** the status line no longer says "not changed" of a title just changed (`FR2-F-c1`, `FR2-v2stale-c1`,
  `FR2-v2chrome-c1` step 5 in Chromium 141). The records' false or incomplete sentences are corrected: U37 (the slide deck),
  U38 ("no money moves" only inside the board), the formula evidence, the mutant blobs.
- **(5) Smallest change:** three board lines in this round (one code line, two comment lines).
- **(6) Preserved:** no existing check, fixture or expected value was edited; both suite diffs against the base are pure
  additions. Every one of audit-recon's 306 base checks keeps its verdict and observed value (`FR2-SC3-audit-recon-fr2`,
  compared below). Every existing mutation entry still matches the c1 board once.


### Every run of fix round 2 (node and Chromium through `bin/run.sh`: setsid -w timeout -k 10 600; the lock checked first, never present)
All on 13 Oct, Eastern. The focused harness is `harness/fr2/h-u36.mjs` (f93cc9a7), built by `rec/L3/u14/mkfocused.py` from
the final c1 audit-recon, block "v2.00 (U36)", verbatim. Base runs use root c1 with the base board (fce8a391) as BOARD; the
`-fr1` run uses round 1's board (0949c3ed, `superseded/c1-fr1`). Failing checks for the base, round 1's board and each
mutant are in `out/FR2-F-fails.txt` and `out/FR2-M-fails.txt`.

| label | start (ET) | exit | wall s | log | result |
|---|---|---|---|---|---|
| FR2-F-c1 | 13:39:16 | 0 | 19.6 | logs/FR2-F-c1.log | ALL CHECKS PASSED, 24p/0f |
| FR2-F-base | 13:39:41 | 1 | 22.5 | logs/FR2-F-base.log | 14 failing, the 10 CONTROLS pass |
| FR2-F-fr1 | 13:40:04 | 1 | 25.7 | logs/FR2-F-fr1.log | 1 failing: "a refused title corrected in its field" (the stale refusal, M1) |
| FR2-M-v200-regtext-title-no-limit | 13:41:11 | 1 | 39.9 | logs/FR2-M-v200-regtext-title-no-limit.log | caught, 11 fail |
| FR2-M-v200-regtext-title-cut | 13:41:52 | 1 | 34.8 | logs/FR2-M-v200-regtext-title-cut.log | caught, 3 fail |
| FR2-M-v200-regtext-title-halves | 13:42:27 | 1 | 25.3 | logs/FR2-M-v200-regtext-title-halves.log | caught, 4 fail |
| FR2-M-v200-regtext-refused-but-kept | 13:42:53 | 1 | 26.4 | logs/FR2-M-v200-regtext-refused-but-kept.log | caught, 11 fail |
| FR2-M-v200-regtext-field-unmarked | 13:43:19 | 1 | 28.3 | logs/FR2-M-v200-regtext-field-unmarked.log | caught, 2 fail |
| FR2-M-v200-regtext-count-untrimmed | 13:43:48 | 1 | 37.6 | logs/FR2-M-v200-regtext-count-untrimmed.log | caught, 2 fail |
| FR2-M-v200-regtext-preview-untrimmed | 13:44:26 | 1 | 40.5 | logs/FR2-M-v200-regtext-preview-untrimmed.log | caught, 1 fail |
| FR2-M-v200-regtext-refused-but-saved | 13:45:07 | 1 | 43.9 | logs/FR2-M-v200-regtext-refused-but-saved.log | caught, 1 fail |
| FR2-M-v200-regtext-kept-unsaved | 13:45:51 | 1 | 32.0 | logs/FR2-M-v200-regtext-kept-unsaved.log | caught, 2 fail |
| FR2-M-v200-regtext-kept-not-drawn | 13:46:23 | 1 | 33.0 | logs/FR2-M-v200-regtext-kept-not-drawn.log | caught, 2 fail |
| FR2-M-v200-regtext-field-maxlength | 13:47:03 | 1 | 36.6 | logs/FR2-M-v200-regtext-field-maxlength.log | caught, 1 fail |
| FR2-M-v200-regtext-count-glyphs | 13:47:40 | 1 | 38.5 | logs/FR2-M-v200-regtext-count-glyphs.log | caught, 1 fail |
| FR2-M-v200-regtext-count-normalized | 13:48:19 | 1 | 43.5 | logs/FR2-M-v200-regtext-count-normalized.log | caught, 1 fail |
| FR2-M-v200-regtext-empty-refused | 13:49:03 | 1 | 41.1 | logs/FR2-M-v200-regtext-empty-refused.log | caught, 1 fail |
| FR2-M-v200-regtext-spaces-collapsed | 13:49:44 | 1 | 40.0 | logs/FR2-M-v200-regtext-spaces-collapsed.log | caught, 1 fail |
| FR2-M-v200-regtext-file-title-shown-cut | 13:50:25 | 1 | 42.9 | logs/FR2-M-v200-regtext-file-title-shown-cut.log | caught, 1 fail |
| FR2-M-v200-regtext-long-title-retyped | 13:51:08 | 1 | 53.9 | logs/FR2-M-v200-regtext-long-title-retyped.log | caught, 2 fail |
| FR2-M-v200-regtext-refusal-left-standing | 13:52:02 | 1 | 55.0 | logs/FR2-M-v200-regtext-refusal-left-standing.log | caught, 1 fail ("a refused title corrected in its field") |
| FR2-M-v200-regtext-clears-any-message | 13:52:58 | 1 | 51.7 | logs/FR2-M-v200-regtext-clears-any-message.log | caught, 1 fail ("a title kept under another message") |
| FR2-M-v200-regtext-formula-cells | 13:53:50 | 1 | 51.1 | logs/FR2-M-v200-regtext-formula-cells.log | caught, 1 fail (the Spend Plan Source codes control) |
| FR2-v2stale-c1 | 13:55:12 | 0 | 15.3 | logs/FR2-v2stale-c1.log | title refused then "good title": kept, line `""` (round 1: the refusal stayed); RCN refused then "22222": the RCN refusal stays (item 91, unchanged) |
| FR2-v2stale-base | 13:55:27 | 0 | 14.2 | logs/FR2-v2stale-base.log | title: no refusal ever (cut), line `""`; RCN: the same as c1 |
| FR2-v2chrome-c1 | 13:55:47 | 0 | 10.4 | logs/FR2-v2chrome-c1.log | Chromium 141.0.7390.37: 81 letters refused (insertText and key by key), 79 + emoji kept whole, 80 kept; step 5 `["good title",""]`; no page errors |
| FR2-v2chrome-base | 13:55:58 | 0 | 12.0 | logs/FR2-v2chrome-base.log | base: 81 kept as 80, 79 + emoji kept as 80 units ending in a lone d83d; step 5 `["good title",""]` |
| FR2-r3formula-c1 | 13:56:17 | 0 | 19.4 | logs/FR2-r3formula-c1.log | RCN "=1+1" kept; Spend Plan Source and workbook `[0,0,true]` |
| FR2-r3formula-base | 13:56:36 | 0 | 17.0 | logs/FR2-r3formula-base.log | the same on the base |
| FR2-r3formula-mut | 13:56:53 | 0 | 18.7 | logs/FR2-r3formula-mut.log | on `mut/fr2/v200-regtext-formula-cells.html`: `[2,0,true]` and `[8,0,true]` (DIFFERS): the probe sees the mutant |
| FR2-v2probe-c1 | 13:57:19 | 0 | 49.7 | logs/FR2-v2probe-c1.log | the money verifier's probe: markup refused and drawn as text; a file's 100-character title survives edits, save, reopen; padded codes printed as stored, `codeIssues` `[]`; U+000B in slide5 (1) and sheets 2, 4, 7, 11; slide5's 56-unit cut gives U+FFFD |
| FR2-v2probe-base | 13:58:09 | 0 | 52.2 | logs/FR2-v2probe-base.log | the same export findings on the base; the markup title over 80 stored as 80 (U36's defect) |
| FR2-S-boot-same-fr2 | 13:59:55 | 0 | 54.7 | logs/FR2-S-boot-same-fr2.log | "every page, source, save and error list is identical either way" |
| FR2-S-audit-fr2 | 14:00:50 | 0 | 45.0 | logs/FR2-S-audit-fr2.log | ALL CHECKS PASSED |
| FR2-S-audit-ppt-fr2 | 14:01:35 | 0 | 26.2 | logs/FR2-S-audit-ppt-fr2.log | ALL CHECKS PASSED |
| FR2-S-audit-other-fr2 | 14:02:01 | 0 | 156.1 | logs/FR2-S-audit-other-fr2.log | ALL CHECKS PASSED |
| FR2-S-legacy-fsrc-fr2 | 14:04:43 | 0 | 15.3 | logs/FR2-S-legacy-fsrc-fr2.log | "every legacy Force setting computes exactly as before" |
| FR2-S-audit-hostile-fr2 | 14:04:59 | 0 | 267.6 | logs/FR2-S-audit-hostile-fr2.log | ALL CHECKS PASSED |
| FR2-S-audit-inject-fr2 | 14:09:26 | 0 | 96.9 | logs/FR2-S-audit-inject-fr2.log | ALL CHECKS PASSED |
| FR2-check-fr2 | 14:11:03 | 0 | 13.7 | logs/FR2-check-fr2.log | npm run check: "all checks passed" |
| FR2-SC-audit-recon-fr2 | 14:11:25 | 137 | 556.9 | logs/FR2-SC-audit-recon-fr2-killed.log (renamed after the run; `logs/runs.txt` still names it without "-killed") | **incomplete, not a result**: the kernel's memory-cgroup OOM killer killed my node (PID 4612) at about 14:20:41 (`dmesg`: "Memory cgroup out of memory: Killed process 4612 (node)"), with the shared machine at load ~38. Before it, 298 checks were recorded, all passing (`out/FR2-SC-audit-recon-fr2-killed.checks.jsonl`). Re-run as FR2-SC2 |
| FR2-SC2-audit-recon-fr2 | 14:21:04 | none | — | logs/FR2-SC2-audit-recon-fr2.log | **incomplete, not a result**: no exit record; stopped with the attempt by the usage limit at about 2:29 PM ET, after 280 checks had been recorded, all passing (`out/FR2-SC2-audit-recon-fr2.checks.jsonl`). Re-run after the resume as FR2-SC3 |
| **resumed 14:44** | | | | | |
| FR2-SC3-audit-recon-fr2 | 14:46:24 | 0 | 467.1 | logs/FR2-SC3-audit-recon-fr2.log | ALL CHECKS PASSED; 330 checks recorded, all passing: the 306 base checks and U36's 24. Compared in `out/FR2-cmpchecks-audit-recon.txt` (next lines). FR2-SC and FR2-SC2 did not finish this run; this one did |
| FR2-cmpchecks-audit-recon (text only, python3 -I, `bin/bx.sh`) | 14:54:22 | 1 | <1 | (none) | my mistake: I gave the base stream without its `.from-verifier` suffix, so the file was not found; nothing was compared |
| FR2-cmpchecks-audit-recon-2 (text only, python3 -I, `bin/bx.sh`) | 14:54:42 | 0 | <1 | out/FR2-cmpchecks-audit-recon.txt | base stream 306 checks, 306 pass; this run 330, 330 pass; 0 only in the base; 24 only here, all U36; 0 with a different verdict or observed value |
| FR2-clear-c1 | 14:23:36 | 0 | 15.0 | logs/FR2-clear-c1.log | after a refused title: a corrected title, an RCN kept and an EEIC kept clear the line; an RCN refused shows its own refusal; a service box, Add a combination and the same refusal again leave the title's refusal (all as the probe's literals want) |

Text-only runs (through `bin/bx.sh`, 600 s cap, PIDs recorded), each exit 0: `FR2-mk-entries` / `-2`, `FR2-insert-entries` /
`-2`, `FR2-mcount-c1`, `FR2-mcount-c1-ids` / `-2`, `FR2-mcount-c1-all`, `FR2-mcount-basemut-c1board`,
`FR2-mcount-c1mut-baseboard`, `FR2-mkfocused`, `FR2-mkmut-*` (20), `FR2-extract`, `FR2-clone`, `FR2-checkout`; and the two
mutant-loop wrappers `FR2-mutloop-A` (13:41:11 to about 13:46:56) and `FR2-mutloop-B` (13:47:03 to about 13:54:41), the
suite wrappers `FR2-suites-A` (13:59:55 to about 14:04:37) and `FR2-suites-B` (14:04:43 to about 14:11:17). The first
`FR2-mcount-c1` / `-ids` found the two `⚠` entries missing (above); `out/FR2-mcount-c1*.txt` now hold the final counts.

**mcount** (text only, `rec/bin/mcount.py`; `out/FR2-mcount-*.txt`):
- final c1 mutate on the final c1 board: 1348 entries, 1348 once; the 20 U36 ids one match each (`out/FR2-mcount-c1-ids.txt`);
- base mutate on the final c1 board: 1328 entries, 1328 once (no existing find broken);
- final c1 mutate on the base board: 1331 once; 17 U36 ids missing, as they should be. The other three
  (`-field-maxlength`, `-file-title-shown-cut`, `-formula-cells`) match the base board once too, because their finds are
  base text (the title field's markup and the workbook writer), which this commit does not change.

**Mutants** (`mut/fr2/`, built by `rec/bin/mkmut.py`, each find matched once; name and blob, `out/FR2-mutant-blobs.txt`):
clears-any-message dec97bcd, count-glyphs e86db3cf, count-normalized f593009d, count-untrimmed 0b1fc7db, empty-refused
658e1a6e, field-maxlength 2b655c7c, field-unmarked 2237d6f0, file-title-shown-cut 1ec7c199, formula-cells 177b39ad,
kept-not-drawn 445364b6, kept-unsaved f85a3475, long-title-retyped d97c1816, preview-untrimmed c422f33f,
refusal-left-standing dae2422d, refused-but-kept 5a147609, refused-but-saved bde40891, spaces-collapsed 600a58c8, title-cut
8b7e1969, title-halves 1b1b7b18, title-no-limit 8f2a0ab1.

**Scratch clone** `gc/fr2`: `git clone --shared /home/user/orbit-board`, checked out at 7ee498a, with the final c1 board and
audit-recon copied over and a node_modules symlink. Its own `tools/export-audit/mutate.mjs` is the base's text (cbc6defc)
and was never run. Nothing was committed there.

**Base suites were not re-run in this round**: the base did not change. The base streams used for comparison are verifier
B's (`out/VSC-audit-recon-base.checks.jsonl.from-verifier`, 7946cd78, identical to round 2's `R3S-audit-recon-base`).

### Probe and helper blobs (fix round 2)
`probe/verifier-r2/` (copied unchanged from the verifiers' folders): v2stale.mjs fd7c8e67, v2chrome.mjs 6044afab,
r3formula.mjs 1d4cf8c6 (all three from `verify-tests-r2/probe/`), v2.mjs d9fe0f7a (from `verify-money-r2/probe/`).
`probe/fr2-clear.mjs` 58e6d0df (mine). Helpers: `fr2/mk-entries.py` 41820ab2, `fr2/insert-entries.py` 9f3de84a,
`fr2/mutloop.sh` 59347d56, `fr2/entries-fr2.txt` 0ff17f59, `bin/suites-fr2.sh` a35f2b70, `bin/cmpchecks.py` 85589d91
(verifier B's, copied unchanged).

### Drafts (final; for the lead)
| file | blob | what changed in this round |
|---|---|---|
| `drafts/NEXT-VERSION-entry.md` | ca58abe9 | the status line after a refusal (what clears it, what does not, item 91 unchanged); Test 24 / 14 / 10; 20 mutations; U37 names the slide deck and says a fix must cover both writers; U38 names the Spend Plan Source (P2 proposed there); U42 names the slide table's 56-unit cut and the 31-unit sheet-name cut; U35 (Codex's A1) stated as the lead wrote it; U37/U40/U41/U42 marked as having fix tracks of their own; "kept whole in the list" |
| `drafts/UNRESOLVED-line.md` | cf15791d | still a NEW line (orbit-board 191daf0's NEXT-VERSION.md names none of U35–U42); the same corrections |
| `drafts/LEDGER-append.md` | 40b0ba60 | now APPEND text for the existing rows U36 (fixed, with this round's numbers), U37 (slide deck), U38 (Spend Plan Source, P2 proposed), U42 (slide cut, 31-unit cut); the U35 append withdrawn |
| `drafts/MATRIX-limits.md` | 728d5f0a | new row "The status line after a refused title"; formula row's evidence replaced (the old control could not see a formula); slide deck added to well-formedness, CSV / PPTX and truncation rows; Spend Plan Source in the parity row; U35 row added |
| `drafts/COMMIT-MSG.txt` | fc57e928 | the clearing; 24 / 14 / 10; 20 mutations; U37 and U40 as release blockers with their own tracks |
| `drafts/README-tail.md` | 985e345d | the builder's, unchanged and superseded by this README |

### PIDs
`pids.txt` from the line "---- Fix round 2" on: each timeout PID and its child, with the command, from `bin/run.sh` and
`bin/bx.sh`, including the wrappers `FR2-mutloop-A`, `FR2-mutloop-B`, `FR2-suites-A` and `FR2-suites-B`. The background
waits I used (a shell `until grep "# end:" …; do sleep 5; done` on the audit-recon log, and one Monitor of the same) ran no
node and are not in `pids.txt`. I killed nothing; the one process that died (PID 4612) was killed by the kernel's OOM killer.
After the resume, `pids.txt` from the line "---- Fix round 2, resumed" on: FR2-SC3 (timeout 2611, node 2613) and the two text-only comparisons through `bin/bx.sh` (16719; 17240/17243). The waits for FR2-SC3 (a shell `until grep "# end:"` loop and two Monitors reading its log and its check count) ran no node and are not in `pids.txt`. At 2:54:50 PM ET none of the PIDs recorded since the resume, nor 12487/12489, 14520/14523 or 4610/4612, was running (`ps -p` found none). I killed nothing.

### Deviations in this round
- **The first whole audit-recon run was killed by the kernel (OOM), not by me and not by its cap**; it is reported as
  incomplete and was re-run.
- A few file writes and reads ran without the 600 s bound: the heredoc writes of `fr2/mk-entries.py` and
  `fr2/insert-entries.py`, `fr2/mutloop.sh`, the `sed` that made `bin/suites-fr2.sh`, three inline python edits (the find
  character in `fr2/mk-entries.py`, two README notes, one matrix sentence, one README paragraph), `cp`/`chmod`/`ln`/`mv`,
  `git hash-object`, `diff`, `grep`, `sed -n`, `wc`, `date`, `uptime`, `free`, `dmesg`, and read-only `git log`/`grep` in
  /home/user/orbit-board. None runs node or Chromium. Every node and Chromium run was bounded and lock-checked.
- The copy step into `superseded/` and the clone ran through `setsid -w timeout -k 10 600` (the copy) or `bin/bx.sh` (the
  clone and checkout).
- The Read, Edit, Write and Grep tools were used for reading and editing files; they are not shell commands.
- **After the resume (from 2:44 PM ET):** these ran without the 600 s bound, and none of them runs node or Chromium:
  - `ls`, `cat`, `sed -n`, `grep`, `wc`, `tail`, `ps`, `uptime`, `free`, `date` and `git hash-object`;
  - read-only `git log` and `git show` in /home/user/orbit-board;
  - two `echo` lines, one appended to `pids.txt` and one to `logs/runs.txt`;
  - `cp README.md superseded/README-fr2-before-merge.md`;
  - three inline python edits: the run reference in `drafts/LEDGER-append.md`, and two to `fr2/assemble-fr2.py`;
  - one inline python edit that added these lines to README.md.
  The merge itself (`fr2/assemble-fr2.py`) and both comparisons ran bounded.
- **The first comparison after the resume named the base stream wrongly** (I left off the `.from-verifier` suffix). It
  exited 1 and compared nothing. It was re-run correctly as `FR2-cmpchecks-audit-recon-2`. Both are in the runs table.
- **The placeholders the stopped attempt left were filled after the stop:** three for the SC2 run, five draft blobs and the
  PID check, all in `fr2/readme-fr2-runs.md`. I filled them while merging. The notes themselves are left as the attempt wrote them. The merge script and its
  arguments are `fr2/assemble-fr2.py` and `fr2/assemble-args.json`. README.md as it was just before the merge is
  `superseded/README-fr2-before-merge.md`.

### What I did NOT do in this round
- **Fix U37, U38, U40, U41 or U42 in code.** U37 and U40 are release blockers with their own fix tracks, and U41/U42 have one
  (the lead's notes in the ledger at 191daf0); U38 needs a decision on normalizing, flagging or refusing a file's codes.
  Their records are corrected and their candidates written.
- **Widen the status clearing to item 91's code refusals,** or to the service box and Add a combination. Both are stated as
  limits; the first is the lead's call (it changes item 91's behaviour).
- **Change `inShow`** (the preview can still end in half an emoji; status line and tooltip only).
- **Run the full audit-import or audit-board** (the lead's). By reading: audit-board's only rcnSet calls (lines 4063, 4112,
  4145) refuse or keep RCN and EEIC values, never a title, and no check in any suite but audit-recon's U36 block reads the
  words "title not changed"; the clearing matches only those words.
- **Re-run the verifiers' own mutants** (`own2-*`, `own3-*`, round 1's 14). The nine `own2` mutants that matter are the
  prop's nine entries (caught here); `own3-formula-cells` is entry `-formula-cells` (caught); `own2-strip-controls` survives
  by design (U37's decision).
- **Import, execute or run `mutate.mjs`.** It was read as text only.
- **Edit, stage, commit or push** anything in /home/user/orbit-board or /home/user/orbit-ui (read with `git log`, `grep` and
  `sed -n` only). `gc/fr2` was never committed to.
- **Run playwright install.** Chromium was /opt/pw-browsers/chromium with the copy's playwright-core.
- **Follow** a cycle file, a PMO copy or submittal, a package or a service file; open Excel, PowerPoint, LibreOffice or a PDF.
- **Change the board** from the empty template. Synthetic data exists only at run time.
- **Build or run the records-only variant of M1** (written under "Resumed after the usage-limit stop"). It is the lead's
  choice. The commit as proposed carries the code fix.
