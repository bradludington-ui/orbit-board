# REGTEXT verify, round 3, lens A (data loss and money): verifier record

Track: REGTEXT. The commit under review is U36 ("an RCN / EEIC title over 80 characters is refused, never cut") as it stands
after the builder's fix round 2 (`../README.md`, section "Fix round 2"). This is the independent adversarial review of that
round. All times are Eastern (`TZ=America/New_York date`). I started at 4:03 PM ET on 13 Oct (`date`: 16:03:37 EDT). The last
run ended at about 4:29 PM ET, and this record was written after that.

## What I kept from an earlier attempt
None. At 4:03:37 PM ET `verify-money-r3` did not exist (`ls`: "No such file or directory"). Everything here is new in this
session, and so is `pids.txt`. The lock `AUDIT_IMPORT_RUNNING` was not present at the start, and it was not present before
any run (`bin/run.sh` checks it first). No run waited and none was skipped.

## Identities
My copies `base/` and `c1/` were made with `cp -a` (through `bin/bx.sh`, bounded) from `../../base` and `../c1`, then
`chmod -R u+w`. Both keep the node_modules symlink. `fr1/` holds only round 1's board (copied from `../superseded/c1-fr1`).

| file | base | c1 (= the builder's) |
|---|---|---|
| prioritization-board-grid.html | fce8a391bd8a248d5185e199d22190c1687eaea0 | abcb8bace6c45c5893f9f92c49e9c3ab017bffce |
| tools/export-audit/audit-recon.mjs | 529e36f7c20e635b2722ea53b6a4f44b4ed328af | b2a8b693226a0c35f370e97fcfeddb8bebbce07e |
| tools/export-audit/mutate.mjs.txt | cbc6defc6803851e847844848fc9b186daeeb268 | 7843cae0262bfa4cc186d92bf16ffa3574447a49 |
| audit-import / audit-board / audit-other | 4aba2506 / a7c575e5 / d89396b0 | unchanged |
| round 1's board (`fr1/`) | — | 0949c3ed169e6d0515c587ba030a564f9abd8ae9 |

`diff -rq base c1` lists only those three files. My diffs (`diffs/`, `diff -u base/<f> c1/<f>`):
- `prioritization-board-grid.html.diff` e15dfc6e: 2 lines removed, 11 added.
- `audit-recon.mjs.diff` dd369a9c: 0 removed, 162 added.
- `mutate.mjs.txt.diff` d2ada51b: 0 removed, 61 added.

Both suite diffs are pure additions. The new entries sit before the R3 comment line (mutate line 4349).

The change this round added (rcnSet, after `save(); render();`):
```
  const st=document.getElementById('shareStat'); if(st && /^⚠ RCN \/ EEIC title not changed\./.test(st.textContent)) setStat('');
```

## Every run
Every node and Chromium run went through `bin/run.sh`. It checks the lock first, runs the command under
`setsid -w timeout -k 10 600`, records the PIDs in `pids.txt`, and writes the exit and wall time to `logs/runs.txt`. No more
than two of my node or Chromium processes ran at once: the mutant loop (one node) plus at most one probe or harness.

| label | start (ET, 13 Oct) | exit | wall s | log | result |
|---|---|---|---|---|---|
| V3-F-c1 | 16:09:05 | 0 | 28.5 | logs/V3-F-c1.log | focused U36 block (harness/h-u36.mjs 5ad460cb, made by mkfocused.py from c1's audit-recon; identical to the builder's f93cc9a7 apart from line 1): 24/24 pass |
| V3-F-base | 16:09:34 | 1 | 33.8 | logs/V3-F-base.log | base board: 14 fail, 10 controls pass. These are the same 14 the builder lists (`out/V3-F-summary.txt`) |
| V3-M-* (20) | 16:14:03–16:25:40 | 1 each | 25.3–45.8 | logs/V3-M-*.log | every mutant is caught, with the builder's counts exactly: title-no-limit 11, title-cut 3, title-halves 4, refused-but-kept 11, field-unmarked 2, count-untrimmed 2, preview-untrimmed 1, refused-but-saved 1, kept-unsaved 2, kept-not-drawn 2, field-maxlength 1, count-glyphs 1, count-normalized 1, empty-refused 1, spaces-collapsed 1, file-title-shown-cut 1, long-title-retyped 2, refusal-left-standing 1, clears-any-message 1, formula-cells 1 (`out/V3-M-fails.txt`) |
| V3-probe-c1 | 16:15:47 | 1 | 0.7 | logs/V3-probe-c1.log | **false start, not a result:** my command ran before `bin/probe-run.mjs` was written ("Cannot find module") |
| V3-probe-c1b | 16:15:54 | 0 | 38.0 | logs/V3-probe-c1b.log | probe/v3.mjs on c1. Sections B, C and E are as expected. Section A's "anywhere in the page" test and section D's row filter were too wide; this run is superseded by v3b |
| V3-probe-a-c1 | 16:16:54 | 0 | 18.7 | logs/V3-probe-a-c1.log | probe/v3a.mjs. The 61 A's that v3 found are only in a SCRIPT element (the board's own source). Section D's extra two rows are the "WHICH REQUIREMENTS" breakout, which also prints the 80-emoji title whole |
| V3-probe-b-c1 | 16:17:36 | 0 | 42.2 | logs/V3-probe-b-c1.log | probe/v3b.mjs: every section is OK against my literals (results below) |
| V3-probe-b-fr1 | 16:18:19 | 0 | 41.3 | logs/V3-probe-b-fr1.log | round 1's board: every section is OK against my literals |
| V3-probe-b-base | 16:19:00 | 0 | 41.1 | logs/V3-probe-b-base.log | base: C and D are OK. A, B and E differ from my literals because **my base literals were wrong**: I forgot that the base keeps the cut 80 letters, and I misjudged a 31-unit slice. The observed values are U36's known defect (81 letters kept as 80, nothing said) |
| V3-P-c1 | 16:22:24 | 1 | 35.8 | logs/V3-P-c1.log | proposal harness (h-u36.mjs plus one check, ce269fdb) on c1: **exactly 1 fail**, the new check "a refused title, then an RCN kept in another row" |
| V3-P-prop | 16:22:59 | 0 | 29.6 | logs/V3-P-prop.log | the proposal board (`prop/`, 1e684114): 25/25 pass |
| V3-P-base | 16:24:50 | 1 | 45.9 | logs/V3-P-base.log | base: 15 fail (the 14 plus the new check) |
| V3-PM-v200-regtext-clears-on-any-keep | 16:26:34 | 1 | 31.4 | logs/V3-PM-…log | proposal mutant, caught: 1 fail, the new check |
| V3-PM-v200-regtext-refusal-left-standing | 16:27:05 | 1 | 30.2 | logs/V3-PM-…log | the existing entry with its find updated for the proposal, caught: "a refused title corrected in its field" |
| V3-PM-v200-regtext-clears-any-message | 16:27:36 | 1 | 33.0 | logs/V3-PM-…log | the existing entry with its find updated, caught: the new check and "a title kept under another message" |
| V3-chrome-c1 | 16:28:39 | 0 | 8.7 | logs/V3-chrome-c1.log | Chromium 141, the row-by-row flow through Tab: OK against my literal (below) |
| V3-chrome-prop | 16:28:48 | 0 | 9.4 | logs/V3-chrome-prop.log | OK against my literal |
| V3-chrome-base | 16:28:58 | 0 | 8.1 | logs/V3-chrome-base.log | OK against my literal |

**Text-only runs** (through `bin/bx.sh`, bounded with `setsid -w timeout -k 10 600`, PIDs recorded; all with python3 -I;
`mutate.mjs` was read as TEXT only and never imported or run):
- `mkfocused` (4:08:59 PM ET).
- `mcount` (`out/V3-mcount-*.txt`):
  - c1 mutate on the c1 board: 1348/1348 once.
  - base mutate on the c1 board: 1328/1328 once.
  - c1 mutate on the base board: 1331 once, with the 17 U36 ids missing, as the builder recorded.
  - prop mutate on the prop board: 1349/1349 once.
  - base mutate on the prop board: 1328/1328 once.
- `mkmut` for the 20 c1 mutants. Their blobs equal the builder's list in `../README.md` (`out/V3-mutant-blobs.txt`).
- `mkmut` for the 3 proposal mutants (`mut-prop/`): clears-on-any-keep fa8484fc, refusal-left-standing 89d3eedc,
  clears-any-message fea21a4e.
- `cmp3` (`out/V3-cmp3-audit-recon.txt`): my own comparison script, `bin/cmp3.py`, run on the builder's whole-suite stream
  `../out/FR2-SC3-audit-recon-fr2.checks.jsonl` (9d0eeec7) against verifier B's base stream (7946cd78). Results:
  - base 306 checks, all passing; c1 330 checks, all passing.
  - 0 checks only in the base. 24 only in c1, all in "v2.00 (U36)".
  - 0 checks with a different verdict or observed value.
  - I did not re-run the whole audit-recon myself (see "What I did NOT do").

## What the probes show (synthetic data built at run time; expectations are literals in each probe)
| | c1 | round 1 (fr1) | base |
|---|---|---|---|
| A. 81 letters refused in row 1's title, then an RCN kept in row 2 (jsdom, the panel's own fields) | refusal said; then **the line is empty**, row 1's field is redrawn as "base", and no run of 60 A's is left anywhere on the page outside scripts | the refusal stays on the line (60-letter preview) | 80 A's kept as the title, nothing said |
| A in Chromium 141 (85 letters put in row 1's title, then Tab 6 times to row 2's RCN, "33333", Tab) | the same: line empty, field "base", nothing left | (not run) | 80 of the 85 kept, nothing said |
| A with the proposal (`prop/`) | the refusal stays on the line, and the field is "base" | | |
| B. the same refusal, then the same row's RCN kept | line empty | the refusal stays | 80 A's kept |
| C. the refused row removed (rcnDel, confirmed) | the line still reads "⚠ RCN / EEIC title not changed." about a row that is gone | the same | nothing said |
| D. 80 emoji (80 code points, 160 UTF-16 units) | kept whole, not marked; RCN-EEIC by Month prints it whole with USAF 900 / ANG 200 (and whole in the breakout); saved and reopened, still 160 units | the same | cut to 80 units (40 emoji), nothing said |
| E. a locked view (cycle locked, then viewed): a title refused, then a title within the limit typed | refusal said; then "🔒 Saving is off …", **but the view's registry holds "view title" and the field shows it** | the same | the same (the 81 letters were cut, not refused) |

E is U10, the CYCREG track's row ("refused edits change a locked-cycle export's codes"). It is the same on the base, and this
commit neither causes nor fixes it. The cross-track review records that U10's locked-view check stays first.

## Findings
### MUST-FIX
None. I found no defect that loses a stored copy, writes over one, misstates money, or exports a wrong figure or code, and no
false word in the records.

### SHOULD-FIX: the new clearing is wider than M1 needs, and in the ordinary row-by-row flow it removes the only notice that a typed title was not kept
**What happens.** M1's three lines clear the title's refusal after any value is kept in the list: the title in any row, or an
RCN or EEIC in any row. The panel's redraw on that keep has already put the stored title back in the refused field. So once
an unrelated value is kept, the person's typed title is gone and nothing on screen says it was refused.

**Why it matters.** A person filling the list row by row hits exactly this. In Chromium 141 they paste 85 letters as row 1's
title, Tab 6 times to row 2's RCN, type it and Tab. On c1 the line is empty, row 1 reads "base" again, and the 85 letters are
nowhere (V3-chrome-c1, V3-probe-b-c1 section A). The refusal was on screen only during those six Tabs.
- Round 1's board kept the refusal on the line (V3-probe-b-fr1).
- The base kept 80 of the 85 letters.

**Against the principles.**
- Principle (1), "keep both and ask or say": the board keeps neither copy and stops saying so.
- The round-2 money review accepted the redraw-loss because "the status says so ('Nothing was changed')". This clearing
  removes exactly that.
- Principle (5): M1 needed the clear only when the refused title itself is corrected.
- Principle (4) is not broken: the drafts already say "an RCN or EEIC typed in any row" clears it.

**Minimal fix (built and run here, `prop/`, `diffs/prop-vs-c1-board.diff` f93c68a7).** Clear only when the field being kept
is the title field that the refusal marked:
```
  // v2.00 (U36): a title field its refusal marked, now being corrected where it is (read before the redraw below)
  const fixing=field==='t' && !!(el && el.getAttribute && el.getAttribute('aria-invalid')==='true');
  ...
  const st=document.getElementById('shareStat'); if(fixing && st && /^⚠ RCN \/ EEIC title not changed\./.test(st.textContent)) setStat('');
```
(Comment wording is in the diff.)

**Results of the fix.**
- All 24 existing U36 checks still pass (V3-P-prop 25/25).
- New check "a refused title, then an RCN kept in another row" (`diffs/prop-harness-vs-h-u36.diff`), expected
  `['base', '33333', 'base', <the refusal's exact words>]`. It fails on c1 (V3-P-c1, the only failure) and on the base
  (V3-P-base), and passes on the fix.

**Mutation entries (`diffs/prop-vs-c1-mutate.diff`).**
- New entry `v200-regtext-clears-on-any-keep` (find `if(fixing && st && `, repl `if(st && `): caught.
- The two M1 entries need their find updated to the new line: `-refusal-left-standing` and `-clears-any-message`. Both are
  caught (V3-PM-*).
- mcount: 1349 once, and the base entries 1328 once.

**Records if adopted.** Replace "(the title corrected in its field, or an RCN or EEIC typed in any row)" with "(the title
corrected in its own field)" in:
- the NEXT-VERSION entry, the commit message, the ledger append, and the matrix row "The status line after a refused title";
- the block comment.

In "What users may see", the refusal then stays "until that title is corrected in its field or the board says something
else". A service box, Add a combination, or a value kept anywhere else leaves it on the line.

**Not a full cure; state it either way.** The status line is not a durable record. The next message replaces the refusal,
and so does an automatic save's "✓ Saved … automatically", as it does on round 1's board. Keeping the refused text itself
across redraws would be a larger change, close to U35's pending-input.

This is the lead's call. The builder's broad clear is documented truthfully. I rate it should-fix, not must-fix, because the
board did say the refusal at the time, and the line was never durable.

### MINOR
- **A removed row's refusal stays** (probe C). After a title refusal in row 1, removing row 1 (rcnDel) leaves "RCN / EEIC title
  not changed" on the line about a combination that is gone. It is not false (the title was not changed), and it is the same
  on round 1. The matrix row says "A delete was not measured"; it is measured now (V3-probe-b-c1/-fr1 section C).
- **"never says 'not changed' of a title just changed" (NEXT-VERSION entry, commit message, ledger append) holds for rcnSet.**
  It is not a statement about the locked view. There the view's registry takes the typed title while the line says "the
  change was not kept" (probe E; U10). I suggest "the line no longer says …" in place of "never".
- **The autosave note in the builder's README is narrower than what happens, and harmless.** It says the clearing "can skip"
  an in-flight autosave's "✓ Saved … automatically" line. By code, an edit made while a folder save is under way moves
  `_saveGen` through save(). That save then ends with its own line: "✅ Saved … A change made while it was saving is not in
  the folder yet — it is saved next time." So something true is said either way.
- **The builder's mutloop wrapper and mine ran longer than 600 s as a whole.** Mine ran 16:13:59–16:26:15 under a 1800 s cap.
  Each node inside it was capped at 600 s. See Deviations.

## The change against the lead's six principles (my reading, with the runs above)
1. **Never lose a copy:** no stored copy is lost or written over.
   - A file's long title survives edits, save and reopen (block checks, re-run here).
   - An 80-emoji title is kept whole where the base cut it to 40 (probe D).
   - The new clearing makes a refused typed title vanish without a notice in the row-by-row flow (should-fix above).
2. **Refuse rather than guess:** refused, never cut. The clearing guesses nothing: it acts only on the exact refusal text.
3. **Money and exports:** no figure changes.
   - RCN-EEIC by Month prints 900 / 200 under kept, refused and 80-emoji titles (block; probe D).
   - Registry keys are `k`, never text.
   - The Spend Plan Source writes "=1+1" and "@A1" as text cells (block control; formula mutant caught).
   - CSV goes through `csvCell`'s guard (by code).
   - The export defects in the records (U37 slide deck, U38 Spend Plan Source, U42 cuts) are on the base too and have their
     own tracks.
4. **Words true:** the status line no longer says "not changed" of a corrected title. The drafts' statements I checked are
   true, apart from the "never" wording (minor).
5. **Smallest change:** three code lines and comments. The clearing is wider than M1 needed (should-fix).
6. **Preserved:** both suite diffs are pure additions.
   - Every existing mutation entry still matches once (1328/1328 on c1).
   - The 306 base audit-recon checks keep verdict and observed value (`cmp3`, on the builder's stream).
   - No existing suite reads the words "title not changed". By text: audit-board's rcnSet calls (4063/4112/4145) set RCN and
     EEIC only.

## PIDs
`pids.txt` holds 138 lines: every timeout PID and its child, each with its command, from `bin/run.sh` and `bin/bx.sh`, plus
the mutloop wrapper (PID 2670). At 4:29:29 PM ET none of the recorded PIDs was running (`ps -p` on each found none). I killed
nothing.

## Deviations
- **The mutant loop's wrapper was bounded at 1800 s, not 600 s.** It ran `setsid -w timeout -k 10 1800 bin/mutloop.sh` from
  16:13:59 to 16:26:15 ET, about 736 s. Each node run inside it went through `run.sh`, capped at 600 s. The wrapper itself
  runs no node.
- **One false start:** V3-probe-c1 ran before its runner file existed (exit 1, 0.7 s). It is in the table and is not a result.
- **My base literals in probe v3b sections A, B and E were wrong predictions**, so those runs print DIFF. The observed base
  values are reported as observed. They are the known U36 defect, and I did not edit the literals to match.
- **Not bounded:** these ran directly from my shell without `setsid -w timeout -k 10 600`. None of them runs node or Chromium:
  - read-only `ls`, `cat`, `sed`, `grep`, `head`, `tail`, `wc`, `diff`, `git hash-object`, `free`, `uptime`, `ps`, `date`;
  - read-only `git log`, `git show` and `grep` in /home/user/orbit-board;
  - the heredoc writes of my scripts and probes;
  - the inline python3 -I edits that made `probe/v3b.mjs`, `prop/prioritization-board-grid.html`, `prop/mutate.mjs.txt` and
    `harness/h-u36-prop.mjs`;
  - `cp` of round 1's board into `fr1/`;
  - `ln -s` for the harness and probe folders.
- I used one background wait (`until grep "mutloop done" …; do sleep 5; done`). It runs no node and is not in `pids.txt`.

## What I did NOT do
- Did not run the whole audit-recon. The shared machine was at load about 41 with 13.6 of 16 GB in use (4:20 PM ET), and the
  lead's 3:46 PM ET note records OOM kills of test runs. My audit-recon comparison uses the builder's whole-suite stream, which
  I did not produce.
- Did not run the full audit-import or audit-board (the lead's), or the other suites. The builder ran them on gc/fr2.
- Did not import, execute or run `mutate.mjs`: it was read as TEXT only (mcount.py, mkmut.py).
- Did not edit the builder's files.
- Did not edit, stage, commit or push anything in /home/user/orbit-board or /home/user/orbit-ui; I only read them.
- Did not run `playwright install`. Chromium was /opt/pw-browsers/chromium, with playwright-core from the copy's node_modules.
- Did not change any board from the empty template. Synthetic data exists only at run time.
- Did not follow a cycle file, a PMO copy or submittal, a package, a service file or BAE budget names.
- Did not open Excel, PowerPoint or LibreOffice.
- Did not measure what happens to the refusal when an automatic save lands. That case was judged by code only.
- Did not build the proposal's block text in suite form inside audit-recon.mjs. It exists only as the harness diff.
- Did not build or run the proposal's records changes.
