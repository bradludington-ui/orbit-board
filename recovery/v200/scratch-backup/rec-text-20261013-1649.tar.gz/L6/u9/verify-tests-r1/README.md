# U9 verification, lens B (test adequacy and regressions), round 1

Verifier's own directory: `rec/L6/u9/verify-tests-r1`. I worked only here, on my own copies. I edited no builder file and
nothing in `/home/user/orbit-board` or `/home/user/orbit-ui`, and I committed or pushed nothing. This round ran from 8:43 PM ET
on 12 Oct (the first focused run) to 12:13 AM ET on 13 Oct (the last suite run). It stopped once, from about 8:51 PM to
11:13 PM ET, when the usage limit was hit, and then resumed from the files in this directory.

## Verdict

**The product change is sound. The tests leave two holes.**

- The board change (5 lines: `pmoSharesOf` passes each office's own CLIN asks on, and `pmoPartsOf` splits whole dollars
  by them) is correct on every case I tried.
- Every run the builder reports reproduces, with the same results.
- Every literal in the U9 block re-derives exactly, and all 36 non-control checks fail on the base.
- No existing expectation changed.

The holes:

1. **Three by-office exports have no test pinning their figures:**
   - the workbook's **CE by PMO** sheet
   - the deck's **Funding by PMO** slide
   - each **PMO tab's by-portion rows**

   This commit changes their figures. A mutant that puts the review's exact defect ($0/$1/$2 at $3, 1:2:3) back on any one
   of them survives the U9 block, audit, audit-ppt and audit-recon. Five mutants do this.
2. **The stated tie rule is untested for an office that holds two CLINs.** The stated rule is "an office ranks by its FIRST
   CLIN; its weight is its CLINs' asks added up". Two mutants that break it survive everything.

How I rate them in the structured result:

- **Hole 1 is must-fix.** These are exports that carry the money this commit moves, on a MONEY track that promises
  "identical everywhere".
- **Hole 2 is should-fix.**

The proposed fix below is tests only:

- one audit-recon block (7 checks)
- 5 mutation entries

It catches all 7 survivors. All 5 of its non-control checks fail on the base, and it passes on c1. I ran it in full
audit-recon on both boards.

## Identities (git hash-object)

| file | base 7ee498a | builder c1 = my c1 | my proposal p1 (c1 + addendum) |
|---|---|---|---|
| prioritization-board-grid.html | fce8a391 | 46e522a8370f05971c8ef0558c3c666b0953b0ac | 46e522a8 (unchanged) |
| tools/export-audit/audit-recon.mjs | 529e36f7 | 19fd2a3d9fe0c64515d91a964234af430141dc1e | 12de58a584b9c9cd8a416bc2eb0d2f02c1302ec4 |
| tools/export-audit/mutate.mjs.txt | cbc6defc | 1208ae4534ccfa9508c20cf42c71acbee3c6f5c3 | 15c24186f62b096389a86c1b37cf933528a0ea8b |
| audit.mjs / audit-other / audit-board / audit-import | cc5af0be / d89396b0 / a7c575e5 / 4aba2506 | unchanged | unchanged |

- `base/` and `c1/` here are copies (cp -a, node_modules symlink). Their blobs equal `rec/L6/base` and the builder's `c1`.
- `diff -rq base c1` shows only the board, audit-recon and mutate.mjs.txt.
- Diffs: `diffs/c1-vs-base.*.diff` (the builder's change, re-made here) and `diffs/p1-vs-c1.*.diff` (my proposal).

## What I checked, and what I found

1. **Every expected value is a literal.**
   - The A/AT/B tables are hand-written literals.
   - B's totals and the "rule" CONTROLs are test-side sums of those literals.
   - Board helpers are used only for observed values.
   - `bin/lr.py` re-derives every A and B figure with exact fractions (largest remainder, ties to the earlier index). All
     agree, including STOVL 624,982 / 100,624,982 / 148,750,036 and B's asks 21/39/57.
2. **Every new non-control check fails on the base.**
   - f-base: 64 checks, 36 fail, and all 36 are non-control.
   - The 28 CONTROLs pass on both boards.
   - f-c1: 64/64.
   - The CONTROL labelling follows the existing audit-recon practice: 82 "CONTROL —" occurrences in the file.
3. **No existing expectation changed.**
   - Suites vs base: only audit-recon changed, by 202 added lines and 0 removed. Every other suite file is byte-identical.
   - mutate.mjs.txt: only 23 lines added, before the R3 line.
4. **Suites before and after.** All pass on both the base and c1:
   - boot-same, audit, audit-ppt, audit-other, audit-recon (c1 with the U9 block), legacy-fsrc, audit-hostile, audit-inject
   - `npm run check` and `money-map --check` (in my scratch clone at 7ee498a, then with c1's 3 files copied in)
5. **mcount (text only, python3 -I).**
   - base: 1328/1328 found once.
   - c1: 1335/1335 found once.
   - my p1: 1340/1340 found once.
   - None missing, duplicated or unparsed.
6. **The builder's runs, re-run on my copies.** Each gives the builder's result:
   - The builder's 7 mutants via the focused block, failing 36/36/29/13/9/1/1.
   - The 8 existing in-region entries (`pmo-residual`, `pmo-frac`, `excel-unf-vec`, `w7-office-*` ×5) through audit, base
     vs c1: identical full failure lists, md5 of each failure block equal.
   - The focused audit-board PRIME-3 harness: pass on both.
   - repro2: base 8 defect failures, c1 75/75.
   - div2: the same on both, and equal to the builder's.
   - check and money-map: pass and hold on both.
7. **My mutants.** I wrote 18 plausible wrong fixes (table below). 11 are caught by the U9 block and 7 survive. The 7
   survivors are not equivalent: each moves a figure on c1 (probe logs `pm-*`, `pmulti-*`).

| my mutant | what it does | U9 block | audit | audit-ppt | audit-recon | proposed addendum |
|---|---|---|---|---|---|---|
| vt-weights-round12 | fractions rounded to 12 places | caught (9) | | | | |
| vt-weights-scaled1e6 | fractions ×1e6 rounded | caught (12) | | | | |
| vt-weights-scaled1e9 | fractions ×1e9 rounded | caught (9) | | | | |
| vt-lanes-split-alone | each lane split on its own | caught (3) | | | | |
| vt-clins-by-number | offices by CLIN number | caught (22) | | | | |
| vt-ties-to-largest | biggest office first | caught (31) | | | | |
| vt-ties-to-last | tie to the last office | caught (33) | | | | |
| vt-matrix-own-rounding | PMO Matrix rounds frac×draw | caught (11) | | | | |
| vt-panel-own-rounding | panel rounds frac×draw | caught (12) | | | | |
| vt-placed-by-fraction | months placed by fraction | caught (16) | | | | |
| vt-apportion-ties-last | apportion ties to the later entry | caught (35) | | | | |
| **vt-cebypmo-own-rounding** | CE by PMO rounds frac×draw ($4 of $3) | **survives** | survives | survives | survives | caught (1) |
| **vt-deck-rollup-own-rounding** | deck slide rounds frac×draw ($4 of $3) | **survives** | survives | survives | survives | caught (1) |
| **vt-cebypmo-float-split** | the review's defect, on CE by PMO only | **survives** | survives | survives | survives | caught (1) |
| **vt-deck-rollup-float-split** | the review's defect, on the deck slide only | **survives** | survives | survives | survives | caught (1) |
| **vt-tab-portions-float-split** | the review's defect, on the PMO tabs' by-portion rows (MxS's tab disappears) | **survives** | survives | survives | survives | caught (1) |
| **vt-weights-first-clin** | office weight = its first CLIN's ask | **survives** | survives | — | survives (r2) | caught (1) |
| **vt-office-ranks-by-last-clin** | office ranks by its last CLIN | **survives** | survives | — | survives (r2) | caught (1) |

The last two also pass the focused audit-board PRIME-3 harness (fbm-*).

### Probe evidence (observes only)

**probe-surfaces.** The board is $3 at 1:2:3, with CLINs 0010/0002/0008 and cost elements on.

| surface | base | c1 |
|---|---|---|
| CE by PMO, Disc (MxS/AV/TSS) | 0/1/2 | 1/1/1 |
| deck Funding by PMO (MxS/AV/TSS) | $0/$1/$2 | $1/$1/$1 |
| Two-Plan BY PMO | 0/1/2 | 1/1/1 |
| PMO MxS tab | absent | present, by-portion 1 |

On board A, CE by PMO gives:

- base: 167,291,651 / 433,958,318 / 648,750,044 / 9
- c1: 167,291,654 / 433,958,320 / 648,750,041 / 7

The deck prints $167.3M on both, because fSM hides dollars at budget size.

**probe-multi.** Base and c1 agree here, and both match the Spend Plan Source.

| case | c1 and base | Spend Plan Source | first-CLIN mutant | last-CLIN mutant |
|---|---|---|---|---|
| $4 over 0010/0110/0002 | MxS 3 / AV 1 | 0010 2 + 0110 1 | 2/2 | — |
| $3 over 0002[1]/0010[2]/0102[1] | AV 2 / MxS 1 | — | — | MxS 2 / AV 1 |

The proposed board E ($3 over 0002[1], 0010[1], 0102[1], 0008[3], 0110[0]) separates all of them:

| board | AV/MxS/TSS |
|---|---|
| c1 | 1/1/1 (= the Spend Plan Source) |
| base | 1/0/2 |
| first-CLIN mutant | 1/0/2 |
| last-CLIN mutant | 1/0/2 |

## Proposed fix (tests only; nothing in the board changes)

- `proposal/block-u9-addendum.mjs.txt` (blob 0a4267b4) is inserted in audit-recon right after `// ==== end v2.00 (U9) ====`
  (`diffs/p1-vs-c1.audit-recon.diff`). It follows the house shape:
  - the async wrapper
  - `bootMark`/`bootRelease(__bm, [])`/`settleBoards`
  - the two-space `  const name = '...';`
  - the markers
- It adds 7 checks, 5 of them non-control. Every expected value is a literal:
  - **Board D** ($3 at 1:2:3, cost elements on), each 1/1/1:
    - CE by PMO, Ask/Disc portion/Mand portion
    - each PMO tab's Disc portion row
    - the Two-Plan Forecast BY PMO TOTAL (both plans)
    - the deck's Funding by PMO, as printed: '$1','$1','$0'
  - **Board E**: PMO Matrix TOTAL Disc AV 1 / MxS 1 / TSS 1. Its CONTROL is the Spend Plan Source lines 0002/0010/0008 at
    $1 each.
- `proposal/mutate-entries.txt` holds 5 entries, inserted before the R3 line. The ids are:
  - `v200-u9-cebypmo-float-split`
  - `v200-u9-deck-rollup-float-split`
  - `v200-u9-tab-portions-float-split`
  - `v200-u9-weights-first-clin`
  - `v200-u9-office-ranks-by-last-clin`

  mcount on p1 is 1340/1340 once. mkmut.py from the proposed text writes byte-identical copies of my mutants.
- Results:
  - fa-c1: 71/71.
  - fa-base: 41 fail (the 36 U9 checks and all 5 addendum non-controls); every CONTROL passes.
  - On each of the 7 survivors, the addendum fails exactly 1 check.
  - Full audit-recon on p1: c1 passes everything; the base board fails exactly 41 (36 U9 + 5 addendum) and nothing else.

## Should-fix and minor (details in the structured result)

- **NEXT-VERSION "What users may see" is incomplete.** It lists the panel, the forecast and its export, the PMO Matrix, the
  PMO tabs and the CR view. The CE by PMO sheet, the deck's Funding by PMO slide and the Two-Plan Forecast BY PMO rows also
  move. An office whose share was $0 also gains a PMO tab it did not have on the base (S1: no `PMO MxS` tab on the base).
- **Builder README table mislabel.** The "ACE / CE-by-PMO roll-up … about line 25082 … existing audit checks" row is wrong:
  - Line 25082 is the deck's Funding by PMO slide in `exportPPT`.
  - CE by PMO is in `exportExcel`, at about line 30457.
  - The ACE tie-out's Reconciliation by PMO does not read `pmoPartsOf` at all; it groups by `r.pmo`.
  - The existing audit and audit-ppt checks there only compare totals, on CLIN fixtures with no ties. They passed on the
    defective base and pass every survivor above.

## Runs

- **How each run went.** Each node run went through `bin/run.sh`:
  - `setsid -w timeout -k 10 600`, from the named directory
  - BOARD and MUT_FIRST_FAIL unset unless given explicitly
  - the AUDIT_IMPORT_RUNNING lock checked first; it was never present, and no run waited or was skipped
- **Bounded steps.** Each multi-run step was itself under `setsid -w timeout -k 10 600`, with its PID recorded.
- **Mutant runs.** Runs on a mutant set BOARD (or, for the focused harnesses, pass it to `runner.mjs`, which asserts it).
- **Exit codes.** Exit 1 on `f*-base`, `fa-base`, `fm*-`, `fam-`, `xm-`, `repro2-base` and `s-p1base-*` means the expected
  failing checks were found (the defect, or a mutant caught). It is not a crash.

Deviations, said plainly:

- **The chain2 supervisor broke the cap.** At 11:18:39 PM ET I started `chain2.sh` under a 3000 s supervisor
  (`setsid -w timeout -k 10 3000`, PID 8177). That breaks the 600 s cap. I recorded its children (8179 timeout, 8180 bash)
  and sent SIGTERM to my recorded PID 8180 at 11:19:22 PM ET. The run in progress
  (`sm-vt-cebypmo-float-split-audit-recon`, under its own 600 s cap) finished normally, exit 0. The rest was re-run as
  600 s steps. Nothing else was killed.
- **Two runs were killed from outside.** `sm-vt-weights-first-clin-audit-recon` and
  `sm-vt-office-ranks-by-last-clin-audit-recon` (11:47:48 / 11:47:51 PM ET) ended with exit 137 at about 376 s, under the
  cap. That was a SIGKILL from outside my runs. The box was at load average about 28 on 4 CPUs, with about 11.7 of 16 GB
  used by other sessions and no swap, so most likely the OOM killer. Both are **incomplete**. They were re-run one at a
  time as `*-r2` (exit 0).
- **Syntax checks outside run.sh.** Two `node --check` syntax checks (no board, no suite) ran outside run.sh, with no PID
  recorded:
  - at about 11:17 PM ET (probe-surfaces): the lock was absent at 11:13 PM and at 11:17:13 PM ET, right after
  - at about 12:05 AM ET (the addendum harness): absent at 12:04:15 AM and at 12:05:46 AM ET

  The first session (8:43 to 8:51 PM ET) has no record of any run outside run.sh.
- **Git commands in my scratch clone.** `git clone --shared --no-checkout`, `checkout --detach 7ee498a` and
  `checkout -- <3 files>` (the restore) ran under `setsid -w timeout -k 10 600`, with PIDs recorded. The clone is back at
  7ee498a, clean except for the node_modules symlink. Nothing was committed there.

At 12:13:48 AM ET none of the 254 PIDs in `pids.txt` was alive.

| # | label | start (ET) | exit | wall s | log |
|---|---|---|---|---|---|
| 1 | f-c1 | 12 Oct 20:43:42 EDT | 0 | 4.0 | logs/f-c1.log |
| 2 | f-base | 12 Oct 20:43:46 EDT | 1 | 4.1 | logs/f-base.log |
| 3 | s-c1-boot-same | 12 Oct 20:45:03 EDT | 0 | 9.2 | logs/s-c1-boot-same.log |
| 4 | s-c1-audit | 12 Oct 20:45:13 EDT | 0 | 7.3 | logs/s-c1-audit.log |
| 5 | s-c1-audit-ppt | 12 Oct 20:45:20 EDT | 0 | 3.2 | logs/s-c1-audit-ppt.log |
| 6 | s-c1-audit-other | 12 Oct 20:45:23 EDT | 0 | 35.8 | logs/s-c1-audit-other.log |
| 7 | fm-v200-u9-per-part-rounding | 12 Oct 20:46:23 EDT | 1 | 8.8 | logs/fm-v200-u9-per-part-rounding.log |
| 8 | fm-v200-u9-plan-part-by-weight | 12 Oct 20:46:32 EDT | 1 | 6.0 | logs/fm-v200-u9-plan-part-by-weight.log |
| 9 | fm-v200-u9-plan-placed-by-weight | 12 Oct 20:46:38 EDT | 1 | 6.0 | logs/fm-v200-u9-plan-placed-by-weight.log |
| 10 | fm-v200-u9-split-by-fraction | 12 Oct 20:46:44 EDT | 1 | 6.6 | logs/fm-v200-u9-split-by-fraction.log |
| 11 | fm-v200-u9-ties-by-name | 12 Oct 20:46:51 EDT | 1 | 7.8 | logs/fm-v200-u9-ties-by-name.log |
| 12 | fm-v200-u9-uncovered-weight-dropped | 12 Oct 20:46:59 EDT | 1 | 7.2 | logs/fm-v200-u9-uncovered-weight-dropped.log |
| 13 | fm-v200-u9-weights-are-fractions | 12 Oct 20:47:06 EDT | 1 | 5.6 | logs/fm-v200-u9-weights-are-fractions.log |
| 14 | fm-vt-apportion-ties-last | 12 Oct 20:47:12 EDT | 1 | 5.6 | logs/fm-vt-apportion-ties-last.log |
| 15 | fm-vt-cebypmo-own-rounding | 12 Oct 20:47:17 EDT | 0 | 4.0 | logs/fm-vt-cebypmo-own-rounding.log |
| 16 | fm-vt-clins-by-number | 12 Oct 20:47:21 EDT | 1 | 4.0 | logs/fm-vt-clins-by-number.log |
| 17 | fm-vt-deck-rollup-own-rounding | 12 Oct 20:47:25 EDT | 0 | 3.8 | logs/fm-vt-deck-rollup-own-rounding.log |
| 18 | fm-vt-lanes-split-alone | 12 Oct 20:47:29 EDT | 1 | 3.7 | logs/fm-vt-lanes-split-alone.log |
| 19 | fm-vt-matrix-own-rounding | 12 Oct 20:47:33 EDT | 1 | 3.8 | logs/fm-vt-matrix-own-rounding.log |
| 20 | fm-vt-panel-own-rounding | 12 Oct 20:47:37 EDT | 1 | 4.0 | logs/fm-vt-panel-own-rounding.log |
| 21 | fm-vt-placed-by-fraction | 12 Oct 20:47:41 EDT | 1 | 3.9 | logs/fm-vt-placed-by-fraction.log |
| 22 | fm-vt-ties-to-largest | 12 Oct 20:47:45 EDT | 1 | 3.8 | logs/fm-vt-ties-to-largest.log |
| 23 | fm-vt-ties-to-last | 12 Oct 20:47:49 EDT | 1 | 3.6 | logs/fm-vt-ties-to-last.log |
| 24 | fm-vt-weights-round12 | 12 Oct 20:47:53 EDT | 1 | 3.6 | logs/fm-vt-weights-round12.log |
| 25 | s-c1-audit-recon | 12 Oct 20:45:59 EDT | 0 | 119.9 | logs/s-c1-audit-recon.log |
| 26 | fm-vt-weights-scaled1e6 | 12 Oct 20:47:56 EDT | 1 | 3.9 | logs/fm-vt-weights-scaled1e6.log |
| 27 | s-c1-legacy-fsrc | 12 Oct 20:47:59 EDT | 0 | 2.8 | logs/s-c1-legacy-fsrc.log |
| 28 | fm-vt-weights-scaled1e9 | 12 Oct 20:48:00 EDT | 1 | 4.0 | logs/fm-vt-weights-scaled1e9.log |
| 29 | s-c1-audit-hostile | 12 Oct 20:48:02 EDT | 0 | 37.6 | logs/s-c1-audit-hostile.log |
| 30 | s-c1-audit-inject | 12 Oct 20:48:39 EDT | 0 | 7.2 | logs/s-c1-audit-inject.log |
| 31 | s-base-boot-same | 12 Oct 20:48:46 EDT | 0 | 6.5 | logs/s-base-boot-same.log |
| 32 | s-base-audit | 12 Oct 20:48:53 EDT | 0 | 5.7 | logs/s-base-audit.log |
| 33 | s-base-audit-ppt | 12 Oct 20:48:59 EDT | 0 | 2.7 | logs/s-base-audit-ppt.log |
| 34 | s-base-audit-other | 12 Oct 20:49:01 EDT | 0 | 21.8 | logs/s-base-audit-other.log |
| 35 | s-base-audit-recon | 12 Oct 20:49:23 EDT | 0 | 60.9 | logs/s-base-audit-recon.log |
| 36 | s-base-legacy-fsrc | 12 Oct 20:50:24 EDT | 0 | 1.7 | logs/s-base-legacy-fsrc.log |
| 37 | s-base-audit-hostile | 12 Oct 20:50:26 EDT | 0 | 35.7 | logs/s-base-audit-hostile.log |
| 38 | s-base-audit-inject | 12 Oct 20:51:01 EDT | 0 | 7.4 | logs/s-base-audit-inject.log |
| 39 | probe-c1 | 12 Oct 23:17:16 EDT | 0 | 2.8 | logs/probe-c1.log |
| 40 | probe-base | 12 Oct 23:17:19 EDT | 0 | 2.8 | logs/probe-base.log |
| 41 | pm-vt-cebypmo-float-split | 12 Oct 23:18:39 EDT | 0 | 3.2 | logs/pm-vt-cebypmo-float-split.log |
| 42 | fm-vt-cebypmo-float-split | 12 Oct 23:18:42 EDT | 0 | 4.5 | logs/fm-vt-cebypmo-float-split.log |
| 43 | sm-vt-cebypmo-float-split-audit | 12 Oct 23:18:47 EDT | 0 | 12.3 | logs/sm-vt-cebypmo-float-split-audit.log |
| 44 | sm-vt-cebypmo-float-split-audit-ppt | 12 Oct 23:18:59 EDT | 0 | 9.4 | logs/sm-vt-cebypmo-float-split-audit-ppt.log |
| 45 | xm-c1-pmo-residual-audit | 12 Oct 23:21:04 EDT | 1 | 29.4 | logs/xm-c1-pmo-residual-audit.log |
| 46 | xm-c1-pmo-frac-audit | 12 Oct 23:21:34 EDT | 1 | 23.5 | logs/xm-c1-pmo-frac-audit.log |
| 47 | xm-c1-excel-unf-vec-audit | 12 Oct 23:21:57 EDT | 1 | 19.7 | logs/xm-c1-excel-unf-vec-audit.log |
| 48 | xm-c1-w7-office-share-fraction-audit | 12 Oct 23:22:17 EDT | 1 | 18.3 | logs/xm-c1-w7-office-share-fraction-audit.log |
| 49 | xm-c1-w7-office-split-by-weight-audit | 12 Oct 23:22:36 EDT | 1 | 12.0 | logs/xm-c1-w7-office-split-by-weight-audit.log |
| 50 | sm-vt-cebypmo-float-split-audit-recon | 12 Oct 23:19:09 EDT | 0 | 220.8 | logs/sm-vt-cebypmo-float-split-audit-recon.log |
| 51 | xm-c1-w7-office-months-fraction-audit | 12 Oct 23:22:48 EDT | 1 | 10.9 | logs/xm-c1-w7-office-months-fraction-audit.log |
| 52 | xm-c1-w7-office-ask-whole-audit | 12 Oct 23:22:59 EDT | 1 | 11.1 | logs/xm-c1-w7-office-ask-whole-audit.log |
| 53 | xm-c1-w7-office-mcs-unfunded-only-audit | 12 Oct 23:23:10 EDT | 1 | 16.0 | logs/xm-c1-w7-office-mcs-unfunded-only-audit.log |
| 54 | xm-base-pmo-residual-audit | 12 Oct 23:23:26 EDT | 1 | 23.1 | logs/xm-base-pmo-residual-audit.log |
| 55 | xm-base-pmo-frac-audit | 12 Oct 23:23:49 EDT | 1 | 21.4 | logs/xm-base-pmo-frac-audit.log |
| 56 | xm-base-excel-unf-vec-audit | 12 Oct 23:24:10 EDT | 1 | 19.1 | logs/xm-base-excel-unf-vec-audit.log |
| 57 | xm-base-w7-office-share-fraction-audit | 12 Oct 23:24:29 EDT | 1 | 14.0 | logs/xm-base-w7-office-share-fraction-audit.log |
| 58 | xm-base-w7-office-split-by-weight-audit | 12 Oct 23:24:43 EDT | 1 | 13.0 | logs/xm-base-w7-office-split-by-weight-audit.log |
| 59 | xm-base-w7-office-months-fraction-audit | 12 Oct 23:24:56 EDT | 1 | 11.2 | logs/xm-base-w7-office-months-fraction-audit.log |
| 60 | xm-base-w7-office-ask-whole-audit | 12 Oct 23:25:08 EDT | 1 | 10.6 | logs/xm-base-w7-office-ask-whole-audit.log |
| 61 | xm-base-w7-office-mcs-unfunded-only-audit | 12 Oct 23:25:18 EDT | 1 | 14.6 | logs/xm-base-w7-office-mcs-unfunded-only-audit.log |
| 62 | pm-vt-tab-portions-float-split | 12 Oct 23:25:51 EDT | 0 | 7.0 | logs/pm-vt-tab-portions-float-split.log |
| 63 | pm-vt-deck-rollup-float-split | 12 Oct 23:25:51 EDT | 0 | 8.1 | logs/pm-vt-deck-rollup-float-split.log |
| 64 | fm-vt-tab-portions-float-split | 12 Oct 23:25:58 EDT | 0 | 12.6 | logs/fm-vt-tab-portions-float-split.log |
| 65 | fm-vt-deck-rollup-float-split | 12 Oct 23:25:59 EDT | 0 | 12.5 | logs/fm-vt-deck-rollup-float-split.log |
| 66 | sm-vt-tab-portions-float-split-audit | 12 Oct 23:26:10 EDT | 0 | 27.7 | logs/sm-vt-tab-portions-float-split-audit.log |
| 67 | sm-vt-deck-rollup-float-split-audit | 12 Oct 23:26:11 EDT | 0 | 27.7 | logs/sm-vt-deck-rollup-float-split-audit.log |
| 68 | sm-vt-tab-portions-float-split-audit-ppt | 12 Oct 23:26:38 EDT | 0 | 16.8 | logs/sm-vt-tab-portions-float-split-audit-ppt.log |
| 69 | sm-vt-deck-rollup-float-split-audit-ppt | 12 Oct 23:26:39 EDT | 0 | 17.9 | logs/sm-vt-deck-rollup-float-split-audit-ppt.log |
| 70 | sm-vt-deck-rollup-float-split-audit-recon | 12 Oct 23:26:57 EDT | 0 | 292.0 | logs/sm-vt-deck-rollup-float-split-audit-recon.log |
| 71 | sm-vt-tab-portions-float-split-audit-recon | 12 Oct 23:26:55 EDT | 0 | 297.2 | logs/sm-vt-tab-portions-float-split-audit-recon.log |
| 72 | pm-vt-deck-rollup-own-rounding | 12 Oct 23:32:08 EDT | 0 | 15.4 | logs/pm-vt-deck-rollup-own-rounding.log |
| 73 | pm-vt-cebypmo-own-rounding | 12 Oct 23:32:08 EDT | 0 | 15.7 | logs/pm-vt-cebypmo-own-rounding.log |
| 74 | fm-vt-deck-rollup-own-rounding | 12 Oct 23:32:23 EDT | 0 | 17.6 | logs/fm-vt-deck-rollup-own-rounding.log |
| 75 | fm-vt-cebypmo-own-rounding | 12 Oct 23:32:24 EDT | 0 | 20.1 | logs/fm-vt-cebypmo-own-rounding.log |
| 76 | sm-vt-deck-rollup-own-rounding-audit | 12 Oct 23:32:41 EDT | 0 | 39.6 | logs/sm-vt-deck-rollup-own-rounding-audit.log |
| 77 | sm-vt-cebypmo-own-rounding-audit | 12 Oct 23:32:44 EDT | 0 | 44.0 | logs/sm-vt-cebypmo-own-rounding-audit.log |
| 78 | sm-vt-deck-rollup-own-rounding-audit-ppt | 12 Oct 23:33:21 EDT | 0 | 21.3 | logs/sm-vt-deck-rollup-own-rounding-audit-ppt.log |
| 79 | sm-vt-cebypmo-own-rounding-audit-ppt | 12 Oct 23:33:28 EDT | 0 | 20.8 | logs/sm-vt-cebypmo-own-rounding-audit-ppt.log |
| 80 | sm-vt-deck-rollup-own-rounding-audit-recon | 12 Oct 23:33:42 EDT | 0 | 380.3 | logs/sm-vt-deck-rollup-own-rounding-audit-recon.log |
| 81 | sm-vt-cebypmo-own-rounding-audit-recon | 12 Oct 23:33:49 EDT | 0 | 386.8 | logs/sm-vt-cebypmo-own-rounding-audit-recon.log |
| 82 | check-base | 12 Oct 23:41:54 EDT | 0 | 9.8 | logs/check-base.log |
| 83 | moneymap-base | 12 Oct 23:42:04 EDT | 0 | 0.2 | logs/moneymap-base.log |
| 84 | check-c1 | 12 Oct 23:42:04 EDT | 0 | 10.4 | logs/check-c1.log |
| 85 | moneymap-c1 | 12 Oct 23:42:15 EDT | 0 | 0.5 | logs/moneymap-c1.log |
| 86 | fb-c1 | 12 Oct 23:42:40 EDT | 0 | 16.0 | logs/fb-c1.log |
| 87 | fb-base | 12 Oct 23:42:56 EDT | 0 | 17.3 | logs/fb-base.log |
| 88 | repro2-base | 12 Oct 23:43:14 EDT | 1 | 17.2 | logs/repro2-base.log |
| 89 | repro2-c1 | 12 Oct 23:43:31 EDT | 0 | 14.3 | logs/repro2-c1.log |
| 90 | div2-base | 12 Oct 23:43:45 EDT | 0 | 13.4 | logs/div2-base.log |
| 91 | div2-c1 | 12 Oct 23:43:59 EDT | 0 | 12.8 | logs/div2-c1.log |
| 92 | pmulti-c1 | 12 Oct 23:45:37 EDT | 0 | 9.8 | logs/pmulti-c1.log |
| 93 | pmulti-base | 12 Oct 23:45:47 EDT | 0 | 10.4 | logs/pmulti-base.log |
| 94 | pmulti-vt-weights-first-clin | 12 Oct 23:45:57 EDT | 0 | 10.9 | logs/pmulti-vt-weights-first-clin.log |
| 95 | pmulti-vt-office-ranks-by-last-clin | 12 Oct 23:46:08 EDT | 0 | 11.3 | logs/pmulti-vt-office-ranks-by-last-clin.log |
| 96 | fm-vt-weights-first-clin | 12 Oct 23:46:32 EDT | 0 | 18.7 | logs/fm-vt-weights-first-clin.log |
| 97 | fm-vt-office-ranks-by-last-clin | 12 Oct 23:46:32 EDT | 0 | 19.0 | logs/fm-vt-office-ranks-by-last-clin.log |
| 98 | fbm-vt-weights-first-clin | 12 Oct 23:46:51 EDT | 0 | 21.5 | logs/fbm-vt-weights-first-clin.log |
| 99 | fbm-vt-office-ranks-by-last-clin | 12 Oct 23:46:51 EDT | 0 | 21.8 | logs/fbm-vt-office-ranks-by-last-clin.log |
| 100 | sm-vt-weights-first-clin-audit | 12 Oct 23:47:13 EDT | 0 | 35.7 | logs/sm-vt-weights-first-clin-audit.log |
| 101 | sm-vt-office-ranks-by-last-clin-audit | 12 Oct 23:47:13 EDT | 0 | 37.6 | logs/sm-vt-office-ranks-by-last-clin-audit.log |
| 102 | sm-vt-weights-first-clin-audit-recon | 12 Oct 23:47:48 EDT | 137 | 376.8 | logs/sm-vt-weights-first-clin-audit-recon.log TIMED OUT = incomplete |
| 103 | sm-vt-office-ranks-by-last-clin-audit-recon | 12 Oct 23:47:51 EDT | 137 | 375.1 | logs/sm-vt-office-ranks-by-last-clin-audit-recon.log TIMED OUT = incomplete |
| 104 | sm-vt-weights-first-clin-audit-recon-r2 | 12 Oct 23:54:36 EDT | 0 | 292.5 | logs/sm-vt-weights-first-clin-audit-recon-r2.log |
| 105 | sm-vt-office-ranks-by-last-clin-audit-recon-r2 | 12 Oct 23:59:35 EDT | 0 | 193.0 | logs/sm-vt-office-ranks-by-last-clin-audit-recon-r2.log |
| 106 | ptab-c1 | 13 Oct 00:04:15 EDT | 0 | 3.4 | logs/ptab-c1.log |
| 107 | fa-c1 | 13 Oct 00:05:46 EDT | 0 | 7.7 | logs/fa-c1.log |
| 108 | fa-base | 13 Oct 00:05:53 EDT | 1 | 7.6 | logs/fa-base.log |
| 109 | fam-vt-cebypmo-own-rounding | 13 Oct 00:06:13 EDT | 1 | 9.0 | logs/fam-vt-cebypmo-own-rounding.log |
| 110 | fam-vt-deck-rollup-own-rounding | 13 Oct 00:06:22 EDT | 1 | 8.4 | logs/fam-vt-deck-rollup-own-rounding.log |
| 111 | fam-vt-cebypmo-float-split | 13 Oct 00:06:30 EDT | 1 | 10.3 | logs/fam-vt-cebypmo-float-split.log |
| 112 | fam-vt-deck-rollup-float-split | 13 Oct 00:06:40 EDT | 1 | 8.8 | logs/fam-vt-deck-rollup-float-split.log |
| 113 | fam-vt-tab-portions-float-split | 13 Oct 00:06:49 EDT | 1 | 7.8 | logs/fam-vt-tab-portions-float-split.log |
| 114 | fam-vt-weights-first-clin | 13 Oct 00:06:57 EDT | 1 | 8.1 | logs/fam-vt-weights-first-clin.log |
| 115 | fam-vt-office-ranks-by-last-clin | 13 Oct 00:07:05 EDT | 1 | 6.6 | logs/fam-vt-office-ranks-by-last-clin.log |
| 116 | s-p1-audit-recon | 13 Oct 00:07:53 EDT | 0 | 174.1 | logs/s-p1-audit-recon.log |
| 117 | s-p1base-audit-recon | 13 Oct 00:10:53 EDT | 1 | 146.6 | logs/s-p1base-audit-recon.log |

Other lines in logs/runs.txt (steps, notes):

- step suites-c1 exit=0 end=20:48:46 EDT
- step suites-base exit=0 end=20:51:09 EDT
- chain done 2026-10-12 20:51:09 EDT
- note 23:17:13 EDT: one 'node --check harness/probe-surfaces.mjs' (syntax only, no board, no suite) ran just before this line outside run.sh, with no PID recorded; the AUDIT_IMPORT_RUNNING lock was checked immediately after and was absent
- 23:19:22 EDT sent SIGTERM to my recorded PID 8180 (chain2.sh under the 3000 s supervisor); the run in progress finishes under its own 600 s cap
- step existstep-c1 exit=0 end=23:23:26 EDT
- step existstep-base exit=0 end=23:25:33 EDT
- step mut-vt-deck-rollup-float-split exit=0 end=23:31:49 EDT
- step mut-vt-tab-portions-float-split exit=0 end=23:31:52 EDT
- step mut-vt-cebypmo-own-rounding exit=0 end=23:40:16 EDT
- step mut-vt-deck-rollup-own-rounding exit=0 end=23:40:16 EDT
- step mut2-vt-weights-first-clin exit=0 end=23:54:05 EDT
- step mut2-vt-office-ranks-by-last-clin exit=0 end=23:54:06 EDT
- note 23:54:36 EDT: sm-vt-weights-first-clin-audit-recon and sm-vt-office-ranks-by-last-clin-audit-recon (23:47:48 / 23:47:51) ended exit 137 at ~376 s, under the 600 s cap: SIGKILL from outside my runs (box at load ~28 on 4 CPUs, 11.7 of 16 GB used by other sessions' node runs, no swap; most likely the kernel OOM killer). Both INCOMPLETE; re-run one at a time below.
- step recon-r2-vt-weights-first-clin exit=0 end=23:59:28 EDT
- step recon-r2-vt-office-ranks-by-last-clin exit=0 end=00:02:49 EDT
- note 00:05:39 EDT: one 'node --check harness/focused-u9-addendum.mjs' (syntax only) outside run.sh; lock absent just before (checked in the previous command at 00:04)
- note 00:05:46 EDT: correction to the line above -- the lock was last checked at 00:04:15 (ptab-c1, absent) before that syntax check, not immediately before it; checked again now: absent
- step addendum-on-survivors exit=0 end=00:07:12 EDT
- step s-p1-audit-recon exit=0 end=00:10:47 EDT
- step s-p1base-audit-recon exit=0 end=00:13:19 EDT

## Files

| path | what | blob |
|---|---|---|
| `harness/focused-u9.mjs` | the U9 block, verbatim from c1's audit-recon (`bin/mkfocused-u9.py`) | 07062d4f |
| `harness/focused-u9-addendum.mjs` | the same plus my proposed addendum block | afd9817c |
| `harness/focused-board-pmo.mjs` | the builder's audit-board harness, copied (every line verbatim in audit-board) | 70c32c5a |
| `harness/probe-surfaces.mjs`, `probe-multi.mjs`, `probe-tab.mjs` | my observe-only probes | 5f72d52c, 88055323, e77e7047 |
| `proposal/block-u9-addendum.mjs.txt`, `proposal/mutate-entries.txt` | the proposed test block and mutation entries | 0a4267b4, 07338bb8 |
| `p1/` | c1 + the proposal (board unchanged) | see Identities |
| `bin/mymut.py`, `mymut2.py`, `mymut3.py` | my 18 mutants (`mut/mine/*.html`, specs*.json) | 1c759810, a8d98e6c, 92a15cd7 |
| `bin/lr.py`, `bin/design.py` | exact re-derivation of the block's literals; choice of board E | abc5cb33, feb6fccf |
| `diffs/` | c1 vs base (3 files), p1 vs c1 (2 files) | f7ca9fde, 3313d2e0, d16322d5, a524ca04, 6c7d1eec |

## Decisions, with reasons

- **I ran all 18 mutants as text-made board copies through the focused block.** The survivors also went through the full
  suites that could plausibly catch them (audit, audit-ppt, audit-recon, and the audit-board PRIME-3 harness), so
  "survives" means every suite I may run.
- **I built and ran a proposed fix rather than only describing it.** That shows the minimal fix closes every survivor,
  fails on the base and passes on c1. The lead decides whether to take it. I edited no builder file.
- **I re-ran the multi-CLIN audit-recon runs one at a time** after the two OOM-like kills, rather than in parallel.

## What I did not do

- **The lead's suites and sweeps.** I did not run full audit-import, full audit-board, the full mutate sweep or
  validate:math; they are the lead's. I never imported or ran mutate.mjs: it was read as text only, through mcount.py and
  mkmut.py.
- **Browser runs.** I did not run verify:grid, Playwright or Chromium, since nothing on screen moves.
- **Product code.** I did not fix or change the board. The four Spend Plan Source vs per-office differences in the builder's
  new ledger row are the same on both boards (div2), and are not this lens's to judge.
- **Release notes.** I did not edit NEXT-VERSION.md or UNRESOLVED-LEDGER.md. The text changes I suggest are in the
  structured result.
- **Commits.** I made no commit anywhere and pushed nothing.
