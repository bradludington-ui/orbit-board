# U9 verify, round 1, lens A (data loss and money)

Independent adversarial check of the U9 builder's commit (`rec/L6/u9`, copy `c1`). Started 12 Oct 2026 at 8:14 PM ET.
This README was written from 8:41 PM ET (`TZ=America/New_York date`). Every run is in the table below.

I edited none of the builder's files. Nothing was committed, staged or pushed. Nothing in `/home/user/orbit-board` or
`/home/user/orbit-ui` was edited. `mutate.mjs` was read as text only, through `mcount.py` and `mkmut.py`. Full audit-import,
full audit-board and Playwright were not run.

## Verdict: sound, with issues

- **The board change is correct and minimal.** Every by-office surface and export agrees on c1, and the change
  matches an independent exact model in 3,000 of 3,000 random cases. Nothing in it can lose a copy of anyone's work.
- **One must-fix, in the drafts only.** The record handed to Brad leaves out a fully funded case in which the PMO split
  and the CLIN source workbook still part ways. In that case the mandatory lane at $3 1:2:3 shows the U9 symptom on c1.
- **Should-fix:** test gaps, and the README's list of surfaces.

## Identities

| what | blob |
|---|---|
| base board (L6/base, 7ee498a) | fce8a391bd8a248d5185e199d22190c1687eaea0 |
| c1 board (my copy `c1/`, `cp -a` of the builder's) | 46e522a8370f05971c8ef0558c3c666b0953b0ac |
| c1 audit-recon / base | 19fd2a3d9fe0c64515d91a964234af430141dc1e / 529e36f7c20e635b2722ea53b6a4f44b4ed328af |
| c1 mutate.mjs.txt / base | 1208ae4534ccfa9508c20cf42c71acbee3c6f5c3 / cbc6defc6803851e847844848fc9b186daeeb268 |
| focused harness (regenerated here by the builder's `mkfocused-u9.py`) | bae5189f0764e3a4cf45f71427b7fe5f2039a1bd (differs from the builder's 8d9c140f only in header line 1, the source path) |
| evidence probe (copied from `recovery/v200/evidence/U9-U10-repro/u9-probe.mjs`) | 7bececc80548b9deddd4db3b3cdf65e46b3de37a |
| run.sh | e0da4326315d3a474d21a21203aeab3d289d2546 |
| probe/adv-u9.mjs / sweep-u9.mjs / deck-u9.mjs / exports-u9.mjs / tie-first-clin.mjs / lr-mine.py | 35173b95 / aed19a2e / 1b6e4327 / ec7b2e17 / 1776d47b / ac7da884 (`git hash-object probe/<file>`) |
| own mutant `mut/own-office-by-last-clin.html` | 7efa761372c27bc462deb4d019218f557e06b050 |

- `diff -rq base c1` lists only the board, audit-recon.mjs and mutate.mjs.txt.
- The audit-recon diff (+202) and the mutate diff (+23) only add lines. The board diff is +13 −4.

## Runs

Each run used `run.sh`: `setsid -w timeout -k 10 600`, the AUDIT_IMPORT_RUNNING lock checked first (it was absent every
time), and PIDs recorded in `pids.txt`. All times are ET on 12 Oct 2026.

| label | start | exit | wall s | result |
|---|---|---|---|---|
| orig-probe-base | 8:18:02 PM | 1 | 11.0 | the review's own probe: 6 defect failures, 0 control failures |
| orig-probe-c1 | 8:18:13 PM | 0 | 12.1 | 60/60 |
| f-c1 (U9 block, focused) | 8:20:44 PM | 0 | 15.3 | 64/64; controls 28/28 |
| f-base | 8:21:00 PM | 1 | 14.7 | 28 passed, 36 failed, which is every non-control; controls 28/28 |
| adv-c1 / adv-base | 8:22:29 / 8:22:45 PM | 0 / 0 | 16.0 / 14.9 | see must-fix 1 (X1, X2); X3 and X4 fixed on c1 |
| sweep-c1 / sweep-base | 8:24:32 / 8:24:40 PM | 0 / 0 | 8.0 / 6.7 | 3,000 random cases against the exact model: c1 0 mismatches, base 35 |
| s-c1-boot-same | 8:25:00 PM | 0 | 27.7 | identical either way |
| s-c1-audit | 8:25:27 PM | 0 | 15.2 | ALL CHECKS PASSED |
| s-c1-audit-recon | 8:25:43 PM | 0 | 214.5 | ALL CHECKS PASSED (includes the U9 block) |
| s-base-boot-same | 8:29:17 PM | 0 | 18.8 | identical either way |
| s-base-audit-recon | 8:29:36 PM | 0 | 199.5 | ALL CHECKS PASSED |
| fm-v200-u9-split-by-fraction | 8:33:22 PM | 1 | 10.3 | caught, 36 failing |
| fm-v200-u9-ties-by-name | 8:33:32 PM | 1 | 10.8 | caught, 13 failing |
| fm-v200-u9-per-part-rounding | 8:33:43 PM | 1 | 9.9 | caught, 29 failing |
| fm-own-office-by-last-clin | 8:33:53 PM | 0 | 7.1 | **survives the U9 block, 64/64** (should-fix 2) |
| deck-base / deck-c1 | 8:35:36 / 8:35:41 PM | 1 / 1 | 5.2 / 5.2 | first try; my comparison depended on key order, so it was superseded by deck2 |
| deck2-base / deck2-c1 | 8:35:54 / 8:35:59 PM | 1 / 0 | 4.4 / 5.0 | deck "Funding by PMO": base $0/$1/$2 and $1/$3/$5; c1 $1/$1/$1 and $2/$3/$4 |
| exp-base / exp-c1 | 8:37:38 / 8:37:42 PM | 1 / 0 | 4.0 / 4.3 | deck, CE by PMO and Two-Plan Forecast BY PMO (both plans): base wrong, c1 right |
| fm-pmo-frac / fm-pmo-residual | 8:38:17 / 8:38:23 PM | 1 / 1 | 6.2 / 9.3 | existing entries, also caught by the U9 block (2 and 26 failing) |
| check-base / check-c1 | 8:38:49 / 8:38:53 PM | 0 / 0 | 4.6 / 5.4 | `npm run check`: all checks passed, in a scratch clone at 7ee498a (`gitclone/`; c1's board and audit-recon copied over) |
| tie-c1 / tie-base / tie-ownmut | 8:40:16 / 8:40:18 / 8:40:21 PM | 0 / 0 / 1 | 2.4 / 2.6 / 2.3 | first-CLIN tie rule: c1 and base MxS $1; the own mutant gives it to AV |

mcount ran as text only, with no PIDs: c1 found 1,335 of 1,335 entries exactly once, base 1,328 of 1,328
(`out/mcount-*.json`). Five of the new finds do not match the base board, as expected.

## Must-fix

**1. The drafts leave out a fully funded divergence that shows the U9 symptom on the mandatory lane.**

`probe/adv-u9.mjs`, case X1. USAF, PRIME-3 asks $6. CLINs 0010, 0002 and 0008 ask 1, 2 and 3. It draws $3
discretionary and $3 mandatory, so it is fully funded, with one CLIN per office, no added CLIN and no increments.

| | c1 (identical on base) |
|---|---|
| PMO panel and PMO Matrix, USAF Mand, MxS / AV / TSS | **$0 / $1 / $2** |
| PMO panel and PMO Matrix, USAF Disc, MxS / AV / TSS | $1 / $1 / $1 |
| office totals | 1 / 2 / 3 |
| Spend Plan Source CLIN lines | 0010 $2, 0002 $2, 0008 $2 (each lane $1/$1/$1) |

X2 shows the same pattern: $10 drawn as $5 + $5. The offices get 2 / 3 / 5 and the CLIN lines 2 / 4 / 4.

None of the four conditions the drafts give applies here: two CLINs on one office, part funded, an added CLIN, or
increments. Yet these drafts say the CLIN lines and the by-office split differ only in those conditions, or imply it:

- the README's "Decision for Brad" ("This happens where…")
- the NEXT-VERSION "Not covered" bullet
- the UNRESOLVED line
- `LEDGER-new-row.md` and `LEDGER-U9-append.md`

The NEXT-VERSION text also says "each office's whole dollars are split by its own CLIN asks". In fact the ask is split by
the CLIN asks, and then each lane by what each office still has to take (the v1.95 rule).

**Minimal fix (text only; the board is unchanged):**

1. Add this case to all five drafts, with these numbers: "a service drawn from both lanes, even in full: $6 at 1:2:3, $3
   discretionary + $3 mandatory, offices MxS 1+0 / AV 1+1 / TSS 1+2, CLIN lines 2 / 2 / 2".
2. Correct the "split by its own CLIN asks" sentence.

A Brad-level choice sits under this case. Splitting each lane by itself, as the Spend Plan Source does, makes $6 at 1:2:3
come out 2/2/2 by office. The two-stage rule keeps 1/2/3. Ask Brad; do not change it here.

## Should-fix

**2. The stated tie rule ("an office ranks by its FIRST CLIN") is not pinned by any check.**

- An ad-hoc mutant re-inserts the office on every CLIN, so the office ranks by its LAST CLIN. It passes the U9 block,
  64 of 64.
- `probe/tie-first-clin.mjs` catches it. The CLINs are 0010 MxS asking 1, 0002 AV asking 2 and 0110 MxS asking 1, with
  $1 discretionary. Expected: MxS $1, AV $0.
- c1 and base pass. The mutant gives the dollar to AV.
- Add this as a CONTROL check to the block, with a mutation entry such as `v200-u9-office-by-last-clin`.

**3. Three exports that carry PMO parts are not read by the U9 block, and the docs do not name them.**

The three exports:

- the deck's "Funding by PMO" slide (`exportPPT`, the `pmoPartsOf` call at c1 line 25091)
- the workbook's "CE by PMO" tab (`exportExcel`, around line 30457, present when cost elements are on)
- the Two-Plan Forecast's BY PMO rows

`probe/exports-u9.mjs` shows all three were wrong on base: $0/$1/$2 at $3 and $1/$3/$5 at $9. All three are right on c1.

The README's surface table calls line 25082 "the ACE / CE-by-PMO roll-up … existing audit checks". It is the deck slide.
The ACE panel (`aceBody`) does not read `pmoPartsOf`. The summary's "the ACE roll-up" names a surface that does not
carry PMO parts.

Fix:

- Add deck and CE-by-PMO cells (and the Two-Plan BY PMO rows) at $3 and $9 to the block. They fail on base and pass on c1.
- Name the deck slide and CE by PMO in "What users may see" and in the ledger append.
- Correct the README's surface table.

## Minor

- **"No total changes"** (What users may see): an office's TOTAL Disc and its forecast TOTAL do move by the dollar.
  Say "no requirement, service or board total changes".
- **The mandatory-only tie is fixed on c1 but has no literal of its own in the block** (X4: $3 mandatory at 1:2:3, base
  0/1/2, c1 1/1/1). B·AFRC reaches the mandatory lane only after the discretionary split.
- **The money-map catalogue does not cite the new block.** The builder already lists this as not done.

## How the change meets each principle (checked literally)

1. **No copy lost.** `pmoSharesOf` and `pmoPartsOf` are read-only computations. Their only readers are `forecast`'s view
   factor, `pmoPartsOf` and the workbook's SHARES lookup. None of them saves, loads or serializes the new third entry.
   boot-same is identical on both boards.
2. **Ask rather than guess.** The tie rule comes from `apportion()` and `clinSplit`, and the remaining divergences are
   escalated. **The escalation is incomplete** (must-fix 1).
3. **Money and exports match.** Every by-office surface and export I read agrees on c1: the panel, the forecast, the
   exported view, the PMO Matrix, the PMO tabs, the CR view by PMO, the deck, CE by PMO and the Two-Plan Forecast. The
   sweep matched in 3,000 of 3,000 cases. Met for the board.
4. **Every word true.** The board's comments are true. The drafts are not complete (must-fix 1, should-fix 3).
5. **Smallest change.** One line in `pmoSharesOf` and four in `pmoPartsOf`, plus comments. Met.
6. **Existing checks preserved.** The suite and mutate diffs only add lines; audit and audit-recon pass on c1; mcount
   finds every entry once. Met.

## Not done

- Full audit-import, full audit-board, the full mutate sweep, validate:math, verify:grid and Playwright (the lead's, or
  not needed).
- Only 3 of the builder's 7 new mutants were re-run (all caught, with the same counts as the builder's).
- audit-ppt, audit-other, legacy-fsrc, audit-hostile and audit-inject were not re-run (the builder's runs pass).
- No fix was made to any file. The drafts are the builder's to amend.
- The CLIN-grid-edit and renumbered-CLIN divergences were not measured. The builder's ledger row names their cause.
