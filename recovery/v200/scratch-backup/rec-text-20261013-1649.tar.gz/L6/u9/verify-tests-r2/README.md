# U9 — independent verifier, round 2, lens B (test adequacy and regressions)

Track: U9, "the PMO split is exact and identical everywhere (panel, forecast, PMO Matrix export)". The builder's result is
`rec/L6/u9/wfstate/fix_u9_r1.json`, and its directory is `rec/L6/u9`. This directory is my own work. I edited none of the
builder's files and nothing in `/home/user/orbit-board` or `/home/user/orbit-ui`. Nothing was committed or pushed.

Times are Eastern, read from `TZ=America/New_York date`.
- **Earlier attempt of this review.** It ran from 5:49 to 6:01 AM ET on 13 Oct and stopped at a usage limit; the container
  restarted at 9:11 AM ET.
- **This attempt.** It resumed at 9:32 AM ET. I reused every earlier run that finished with an exit record on the same blobs
  (re-checked: see Identities) and re-ran or added the rest.
- **This README** was finished at 10:26 AM ET.

## Verdict

**sound-with-issues.** The board change is right, and every check the builder wrote is honest:
- every expected value is a hand-written literal, and I re-derived all of them with exact fractions;
- every non-control check fails on the base, and every control passes on both boards;
- every existing check, fixture and expected value is unchanged;
- every suite I may run passes on c1 as on the base;
- all 14 of the builder's mutations are caught.

**But the tests do not hold the PMO parts on every cell that carries them.** Eight plausible mutants survive both U9 blocks.
Each moves an office's money on the panel or an export: the panel's MC column, the PMO Matrix's ★ MC short, and the MC and
Unfunded figures on the PMO tabs, CE by PMO and the deck. Every one I ran through c1's full audit-recon, audit, audit-ppt and
audit-other also passes all four (see §3). A ninth, weights rebuilt as fraction × total, survives too (S2). That is one must-fix, with a tested minimal fix (tests only) in `p1/`. The drafts' Test line
overstates coverage (should-fix).

## Identities (git hash-object)

| what | base (7ee498a) | c1 (builder, round 1) | p1 (my proposal = c1 + tests) |
|---|---|---|---|
| prioritization-board-grid.html | fce8a391 | 46e522a8 | 46e522a8 (unchanged) |
| tools/export-audit/audit-recon.mjs | 529e36f7 | 2fb4b7ad | 04f0b95a |
| tools/export-audit/mutate.mjs.txt | cbc6defc | 3f7d8311 | f9d76e42 |
| every other file | — | identical to base (`diff -rq --no-dereference`) | identical to c1 |

- **My copies.** `base/` and `c1/` match `rec/L6/base` and the builder's `c1/` file for file (`diff -r --no-dereference`,
  9:32 AM ET).
- **orbit-board HEAD.** It is now f40eded. The 14 commits since 7ee498a are records only: `git diff --stat 7ee498a f40eded`
  shows no change to the board, `tools/` or `package.json`.
- **Diffs, base to c1:**
  - `diffs/board.diff` (173e27ff): +13/−4.
  - `diffs/audit-recon.diff` (31a4f8a3): +323/−0.
  - `diffs/mutate.diff` (0a674cc0): +46/−0.
  - **No existing expectation changed:** both suite diffs only add lines. audit, audit-other, audit-board, audit-import,
    boot.mjs and package.json are byte-identical to the base.
- **Diffs, c1 to p1:**
  - `diffs/p1-vs-c1-audit-recon.diff` (d02e1e88): +65/−0.
  - `diffs/p1-vs-c1-mutate.diff` (8d0b667e): +25/−0.
- **Focused harnesses** (a suite's preamble, the named blocks and the scenario-ran guard, verbatim, built by
  `bin/mkfocused-u9-r1.py`):
  - `harness/c1/focused-u9.mjs`, c16385ba. Rebuilt today from c1's audit-recon, it is byte-identical to the earlier
    attempt's and to the builder's `harness/r1/focused-u9.mjs`.
  - `harness/m1/focused-u9-money-p1.mjs` (79d2e152), from the money verifier's p1.
  - `harness/p1/focused-u9-p1.mjs` (3f6e745e), from my p1.
  - `harness/board/focused-board-pmo.mjs` (eb8376ef), regenerated with the builder's `bin/mkfocused-board.py`. It is
    identical to the builder's 70c32c5a except for line 1, its source path.
- **Mutants.**
  - The builder's 14, rebuilt by `rec/bin/mkmut.py` from c1's mutate text, are byte-identical to the earlier attempt's
    `mut/b/*` (blobs f02c9999 … 22061919).
  - My 14 from `bin/mymut.py` (e2756fc7) are byte-identical to the earlier attempt's `mut/own/*`.
  - Two more today, from `bin/mymut2.py` (8c2d861b): vt2-panel-mc-own-rounding 505f982e and vt2-matrix-mc-own-rounding
    559d6f1d.
  - `mkmut.py` on p1's three new entries writes byte-identical copies of my mutants: matrix-mcs cc460c84, panel-mc
    505f982e, frac-times-tot d8e7c9d5.

## What I checked, and what I found

### 1. The builder's runs, re-run and compared (all agree)

| builder's claim | my run(s) | result |
|---|---|---|
| focused U9 blocks on c1: 79/79 | f-c1 (5:51 AM ET) | 79/79, exit 0 |
| on base: 44 fail = every non-control; 35 controls pass | f-base | 44 fail (36 + 8), all non-control; controls 35/35, exit 1 |
| 65 + 14 checks | count of `out/f-c1.checks.jsonl` | 65 and 14 |
| full audit-recon passes on c1 and on base | s-c1-audit-recon, s-base-audit-recon | exit 0 both, ALL CHECKS PASSED |
| c1's audit-recon on the base board fails exactly 44, all U9 | s-c1suite-baseboard-audit-recon | 44 failing: 36 in "v2.00 (U9)", 8 in "v2.00 (U9, every export)"; nothing else |
| 14 mutants caught, failing 44, 44, 35, 13, 9, 1, 1, 1, 1, 2, 1, 1, 2, 2 | bm-* (5:55–5:57 AM ET) | identical counts, each exit 1 (`out/bm-summary.txt`) |
| boot-same, audit, audit-ppt, audit-other, legacy-fsrc, audit-hostile, audit-inject pass on c1 | s2-c1-* (9:37–9:41 AM ET) | all exit 0 |
| the same on the base | s2-base-* (9:41–9:44 AM ET) | all exit 0; boot-same "identical either way" on both |
| audit-board's two PRIME-3 scenarios (focused) pass on both | fb-c1, fb-base | 33/33 both |
| npm run check passes, money map holds | check-*, moneymap-* in my scratch clone `gc/` | all checks passed on base (check-base 9:52:57 AM ET), with c1's board and audit-recon copied in (check-c1) and with p1's (check-p1), exit 0 each; money map holds on all three, 329 cells, 123 proven, 206 n/a, 0 open, report current (moneymap-*). The clone was restored with `git checkout` (gc-restore, exit 0); afterwards its board and audit-recon are fce8a391 / 529e36f7 again and the only untracked entry is my node_modules link |
| mcount 1342/1342 (c1), 1328/1328 (base) | `rec/bin/mcount.py`, text only | the same; p1 1349/1349 |

### 2. Literals, and failing on the base

- **Every expected value is a literal, or a test-side sum of literals.** No board helper supplies an expectation.
  - Examples: A's per-service table, AT, B's per-office object (now with its totals written out), DD/DM/DT, E's [1,1,1], C's
    '1.75'/'3.5'/'5.25', and the Two-Plan [[3,4],[4,5],[5,6]].
  - `FYL()` is read only to name a column header.
- **`bin/exact.py`** (7e83c1f2, exact fractions; run at 9:35 AM ET, `out/exact.txt`) re-derives boards A, B, D, E and D's
  plan A from the stated rule. They are largest remainder, ties to the earlier office, offices in first-CLIN order and
  weighed by their CLIN asks added up, two stages per service. Every literal matches.
- **All 44 non-control checks fail on the base, and all 35 controls pass on both boards.** As in round 1,
  v200-u9-plan-part-by-weight and v200-u9-plan-placed-by-weight are caught only by CONTROL checks, on board C.

### 3. My own mutants (16; at least six were required)

All were run through c1's two U9 blocks (focused, verbatim). "Survives" means 79/79 still pass.

| mutant | what it does | c1's U9 blocks | money verifier's board F | my p1 |
|---|---|---|---|---|
| vt2-ask-stage-by-fraction | the ask split by `apportion(a, fractions)`, lanes as before | caught (44) | — | caught (51) |
| vt2-gap-disables-exact | falls back to the fractions whenever any service has no CLIN | caught (36) | — | caught (36) |
| vt2-offices-by-weight-desc | the biggest office first | caught (39) | — | caught (44) |
| vt2-cr-by-fraction | the CR view places each office's fraction | caught (2) | — | caught (2) |
| vt2-oblig-ufr-own-rounding | each PMO tab's report row rounds its UFR itself | caught (1) | — | caught (1) |
| vt2-matrix-mc-own-rounding | PMO Matrix ★ MC requirement rounds itself | caught (1) | caught (1) | caught (2) |
| **vt2-panel-mc-own-rounding** | the PMO funding panel's MC column rounds itself | **survives** | **survives** | caught (1) |
| **vt2-matrix-mcs-own-rounding** | PMO Matrix ★ MC short rounds itself | **survives** | **survives** | caught (1) |
| **vt2-tab-mc-own-rounding** | each PMO tab's MC memo row rounds itself | **survives** | caught (1) | caught (1) |
| **vt2-tab-unf-own-rounding** | each PMO tab's Unfunded row rounds itself | **survives** | caught (1) | caught (1) |
| **vt2-deck-mc-own-rounding** | the deck's ★ MC req / ★ MC short round themselves | **survives** | caught (1) | caught (1) |
| **vt2-deck-unf-own-rounding** | the deck's Unfunded column rounds itself | **survives** | caught (1) | caught (1) |
| **vt2-cebypmo-mcs-own-rounding** | CE by PMO's ★ MC short rounds itself | **survives** | caught (1) | caught (1) |
| **vt2-cebypmo-unf-own-rounding** | CE by PMO's Unfunded (incl delta) rounds itself | **survives** | caught (1) | caught (1) |
| **vt2-weights-frac-times-tot** | weights rebuilt as fraction × the CLINs' total (floating point) | **survives** | **survives** | caught (2) |
| vt2-weights-rounded | weights `Math.round`ed | survives | — | survives: **equivalent** (below) |

- **vt2-weights-rounded is equivalent.** Every CLIN ask is made whole dollars at load: `applyState` runs
  `c.ask=fit(c.ask)` on every CLIN (c1 line 5701), and `fit` maps each figure through `money`, which returns `D$`.
  `CLINS` is `DATA.clins` (line 23395), so pmoSharesOf never sees a cent. My earlier probe G, which assumed CLIN asks of
  $1.50 and $0.40 survive, failed its own CONTROL on both boards for this reason. I drop it.
- **Why the others survive.** Every case the builder's blocks read with an unfunded or ★ figure splits it evenly (B: AFRC's
  $6 short at 1 : 2 : 3; D: nothing unfunded). Rounding each office's fraction on its own then gives the same dollars as
  the exact part.
- **Shown non-equivalent on c1.**
  - My probe F (`harness/c1/probe-f.mjs`, 866bcdfa; pf-c1 passes and pf-base fails 6 of 6) catches each of the six export
    mutants, 1 check each (`out/opf-summary.txt`).
  - p1's board F additions catch the panel and Matrix ★ short mutants.
  - p1's board G catches frac-times-tot.
- **Survivors through c1's FULL suites** (BOARD = the mutant: audit-recon, audit, audit-ppt, audit-other; `out/ms-summary.txt`):

| mutant | audit-recon | audit | audit-ppt | audit-other |
|---|---|---|---|---|
| vt2-panel-mc-own-rounding | exit 0, ALL CHECKS PASSED (09:42:55, 226.0 s) | exit 0, ALL CHECKS PASSED (09:46:41, 16.7 s) | exit 0, ALL CHECKS PASSED (09:46:58, 10.4 s) | exit 0, ALL CHECKS PASSED (09:47:09, 53.8 s) |
| vt2-matrix-mcs-own-rounding | exit 0, ALL CHECKS PASSED (09:48:02, 249.7 s) | exit 0, ALL CHECKS PASSED (09:52:12, 18.1 s) | exit 0, ALL CHECKS PASSED (09:52:30, 9.1 s) | exit 0, ALL CHECKS PASSED (09:52:39, 60.1 s) |
| vt2-weights-frac-times-tot | exit 0, ALL CHECKS PASSED (09:53:40, 212.5 s) | exit 0, ALL CHECKS PASSED (09:57:12, 20.4 s) | exit 0, ALL CHECKS PASSED (09:57:33, 10.4 s) | exit 0, ALL CHECKS PASSED (09:57:43, 62.7 s) |
| vt2-tab-mc-own-rounding | exit 0, ALL CHECKS PASSED (09:58:46, 235.0 s) | exit 0, ALL CHECKS PASSED (10:02:41, 20.1 s) | exit 0, ALL CHECKS PASSED (10:03:01, 8.2 s) | exit 0, ALL CHECKS PASSED (10:03:09, 57.9 s) |
| vt2-tab-unf-own-rounding | exit 0, ALL CHECKS PASSED (10:04:07, 207.7 s) | exit 0, ALL CHECKS PASSED (10:07:35, 25.5 s) | exit 0, ALL CHECKS PASSED (10:08:01, 11.5 s) | exit 0, ALL CHECKS PASSED (10:08:12, 68.4 s) |
| vt2-deck-mc-own-rounding | exit 0, ALL CHECKS PASSED (10:09:21, 222.3 s) | exit 0, ALL CHECKS PASSED (10:13:03, 24.0 s) | exit 0, ALL CHECKS PASSED (10:13:27, 8.8 s) | exit 0, ALL CHECKS PASSED (10:13:36, 66.7 s) |
| vt2-deck-unf-own-rounding | exit 0, ALL CHECKS PASSED (10:14:43, 179.1 s) | exit 0, ALL CHECKS PASSED (10:17:42, 14.7 s) | exit 0, ALL CHECKS PASSED (10:17:56, 7.5 s) | exit 0, ALL CHECKS PASSED (10:18:04, 52.2 s) |
| vt2-cebypmo-mcs-own-rounding | exit 0, ALL CHECKS PASSED (10:18:56, 185.9 s) | exit 0, ALL CHECKS PASSED (10:22:02, 16.1 s) | exit 0, ALL CHECKS PASSED (10:22:18, 5.8 s) | exit 0, ALL CHECKS PASSED (10:22:24, 35.5 s) |
| vt2-cebypmo-unf-own-rounding | exit 0, ALL CHECKS PASSED (10:23:00, 103.2 s) | exit 0, ALL CHECKS PASSED (10:24:43, 7.5 s) | exit 0, ALL CHECKS PASSED (10:24:51, 3.4 s) | exit 0, ALL CHECKS PASSED (10:24:54, 29.6 s) |

All 36 runs exit 0: no existing suite catches any of the nine. (Times ET; logs `logs/ms-<mutant>-<suite>.log`.)

### 4. Must-fix: the PMO parts are not held on every cell that carries them

**Defect.** U9's own requirement is "every surface and export agrees to the cent … checked on the panel, the forecast and
the export's cells". The builder's summary also says "Every export that carries the PMO parts is now held to the dollar".
That is not so for these cells, and this commit moves all of them:
- the PMO funding panel's MC column;
- the PMO Matrix's ★ MC short;
- each PMO tab's MC memo and Unfunded rows;
- CE by PMO's ★ MC short and Unfunded (incl delta);
- the deck's Funding by PMO Unfunded and ★ columns.

**How each case moves, base to c1.**
- On money's board F (starred; USAF $9 drawn $3 discretionary + $3 mandatory; ANG $3 undrawn; at 1 : 2 : 3; runs pp-base
  and pp-p1):
  - the panel's MC column goes from $1/$3/$5 to $2/$3/$4;
  - the Matrix's ★ MC short goes from 1/3/5 to 2/3/4;
  - CE by PMO's Unfunded goes from 0/2/4 to 1/2/3;
  - the deck's ★ MC req goes from $1/$4/$7 to $3/$4/$5.
- On my probe F (USAF $3 undrawn, ANG $9 with $3 discretionary; pf-base): every one of these cells moves.

**Reproduction.**
- Take `mut/own/vt2-panel-mc-own-rounding.html` (505f982e). It is c1 with the panel's line
  `if(S.mc[id]) SVC.forEach((s,i)=>{ a.mc+=o.mcs[i]; });` changing to round each office's fraction of (ask − discretionary).
- Both U9 blocks pass (79/79; om2, 9:39 AM ET).
- So do c1's full audit-recon, audit, audit-ppt and audit-other (ms-*, 9:42–9:47 AM ET, exit 0 each).
- Yet on board F the panel prints TSS short $5 where its part is $4.
- The other seven survivors above behave the same way in the U9 blocks. Their full-suite runs are in §3.

**Minimal fix (tests only; board unchanged; built and run in `p1/`).**
1. **Board F.** Take the money verifier's board F (`verify-money-r2/proposal/board-f.mjs.txt`, 06f09634) verbatim. It reads
   each PMO tab's MC memo and Unfunded rows, CE by PMO's Ask/★/★ short/Unfunded and the deck's Unfunded/★ columns.
2. **My two checks on board F** (`proposal/board-fg-addition.mjs.txt`, 73a9d361, first part):
   - the PMO Matrix's TOTAL Disc, TOTAL Mand, ★ MC requirement and ★ MC short, MxS/AV/TSS = [[1,1,3,2],[1,1,4,3],[1,1,5,4]];
   - the panel's row for each office as printed, [['$1','$1','—','—','$1','$1','$2'], …'$3'], …'$4']].
   - Worked by hand:
     - USAF's asks 1.5/3/4.5 → 2/3/4 (tie to MxS); Disc 3 by 2 : 3 : 4 → 1/1/1; Mand 3 by 1 : 2 : 3 → 1/1/1.
     - ANG 3 → 1/1/1, all unfunded.
     - So the offices' asks are 3/4/5 and their shorts 2/3/4.
3. **Board G** (the second part of the same file): an exact tie at budget size over CLIN asks whose fractions floating point
   cannot hold. USAF $779,153,421 over 881,836,554 / 575,398,923 / 101,071,365 gives 440,918,277 / 287,699,461.5 /
   50,535,682.5 → AV takes the tie → 440,918,277 / 287,699,462 / 50,535,682. It reads the PMO Matrix and the forecast,
   with the Spend Plan Source as a CONTROL. The base gives 287,699,461 / 50,535,683.
4. **Seven mutation entries** before the R3 line:
   - the money verifier's four (`verify-money-r2/proposal/mutate-entries.txt`, 86d847cf);
   - my three (`proposal/mutate-entries-addition.txt`, 19df6ae2): v200-u9-matrix-mcs-own-rounding,
     v200-u9-panel-mc-own-rounding and v200-u9-weights-frac-times-tot.

**Results on p1.**

| run | result |
|---|---|
| pp-p1 (9:41 AM ET) | 89/89 |
| pp-base | 51 fail = every non-control; controls 38/38 |
| p1's 21 v200-u9 entries (built by `mkmut.py` from p1's text) | every one caught; failing counts in `out/ppm-summary.txt` |
| my own mutants on p1 | every one caught, except the equivalent vt2-weights-rounded |
| s2-p1-audit-recon (9:45 AM ET, 224.1 s) | ALL CHECKS PASSED |
| p1's suite on the base board (s2-p1suite-baseboard-audit-recon) | s2-p1suite-baseboard-audit-recon (9:48:53 AM ET, exit 1, 244.0 s): exactly 51 failing, all in the two U9 blocks, none a CONTROL; nothing else fails |
| mcount on p1 (text) | 1349/1349 found once |
| npm run check / money map with p1's files | check-p1 all checks passed; moneymap-p1 holds (329 cells, 0 open) |

The seven new entries on p1, and the checks that catch each one (ppm-*):

| entry | failing check | what the mutant prints |
|---|---|---|
| v200-u9-tab-memo-float-split | F · the PMO tabs by portion | MC memo row 1/4/7 (want 3/4/5) |
| v200-u9-tab-unf-float-split | F · the PMO tabs by portion | MxS has no Unfunded row; TSS 4 (want 1/2/3) |
| v200-u9-deck-mc-float-split | F · the deck · Funding by PMO | ★ MC req $1/$4/$7 (want $3/$4/$5) |
| v200-u9-cebypmo-mcs-float-split | F · CE by PMO | ★ MC short 1/3/5 (want 2/3/4) |
| v200-u9-matrix-mcs-own-rounding | F · the PMO Matrix | ★ MC short 2/3/5 (want 2/3/4) |
| v200-u9-panel-mc-own-rounding | F · the PMO panel | TSS MC $5 (want $4) |
| v200-u9-weights-frac-times-tot | G · the PMO Matrix; G · the forecast | 287,699,461 / 50,535,683 (want 287,699,462 / 50,535,682) |

House style:
- the new checks sit inside the existing "v2.00 (U9, every export)" block (async wrapper, bootMark/bootRelease(__bm,
  [])/settleBoards, the two-space name line, the markers), as boards D and E do;
- the entries follow `{ id, area, what, find, repl }`, with ids `v200-u9-*`.

### 5. Should-fix

- **S1. The drafts overstate test coverage.** Today's runs bear out the money verifier's S2.
  - `drafts/NEXT-VERSION-U9.md`, Test: "Each is read on the panel as drawn, the forecast …, the PMO Matrix, the CE by PMO
    sheet, each office's PMO tab (its report row and its rows by portion), the Two-Plan Forecast's BY PMO rows (both
    plans), the CR view by PMO and the deck's Funding by PMO slide". In fact:
    - boards A and B are never read on CE by PMO, the tabs by portion, the Two-Plan Forecast or the deck;
    - board D is never read on the panel, the forecast or the CR view;
    - board E is read only on the PMO Matrix and the forecast;
    - no case with an uneven unfunded or ★ figure is read anywhere.
  - `drafts/LEDGER-U9-append.md`: "read on every view above".
  - With p1 taken, replace the Test bullet's last two sentences with the text under "Proposed draft text" below. Without p1,
    at least drop "Each is read on" and "read on every view above".
- **S2. Board G alone, if the lead takes only the money verifier's board F.** vt2-weights-frac-times-tot is a plausible wrong
  fix: "the weights are the fractions times the total". It survives both U9 blocks and money's board F (mf-*, 9:39 AM ET).
  It also passes c1's full audit-recon, audit, audit-ppt and audit-other (ms-vt2-weights-frac-times-tot-*, 9:53–9:57 AM ET, exit 0 each). The builder's "large values" cases are $999,999,999 at 1 : 2 : 3 and a near tie at $250,000,000, and neither can tell exact weights from rebuilt ones. Board G can: the base and this mutant both give 287,699,461 / 50,535,683 there. Board G and the entry v200-u9-weights-frac-times-tot close it.

### 6. Minor

- **CONTROL checks.** 35 of the 79 new checks (38 of p1's 89) are CONTROLs and pass on the base by design; they are
  labelled, as is house practice. Two builder mutations are caught only by C's CONTROLs.
- **Derived expectations.** Some expectations are test-side sums of literals rather than literals: B's forecast per service
  `B[g].d[i] + B[g].m[i]`, `[AT[g], AT[g]]`, and `Array(12).fill(0).concat(...)`. No board helper is involved, and all
  re-derive in `bin/exact.py`.
- **A comment line for the lead.** p1's additions carry their own explanation comments. The block header's "FAILS ON
  7ee498a" paragraph is not extended for F and G. The base figures are under Must-fix, if the lead wants that line.
- **My process deviations.**
  - One `node --check` (syntax only) went outside run.sh at about 9:41 AM ET, with the lock absent; it is recorded in
    `logs/runs.txt`.
  - My batch drivers (plain bash loops, PIDs recorded) are not themselves under `timeout`. Every node and git command inside
    them is, through run.sh (`setsid -w timeout -k 10 600`).

## Proposed draft text (if p1 is taken)

- **NEXT-VERSION, Test bullet.** Change "(14 checks)" to "(24 checks)". After "and an office holding two CLINs, which weighs
  them added up and ranks by the first" add: "; a starred requirement drawn from both lanes and short, at 1 : 2 : 3 (its
  unfunded and ★ figures are not shared evenly); and an exact tie at $779,153,421 over CLIN asks in the hundreds of
  millions". Replace from "Each is read on" to the end of the bullet with: "Boards A and B are read on the PMO funding panel
  as drawn, the forecast (each service alone, the whole portfolio and the exported view), the PMO Matrix, each office's PMO
  tab (its report row) and the CR view by PMO; board D on the PMO Matrix, the CE by PMO sheet, each PMO tab's Disc and Mand
  rows by portion, the Two-Plan Forecast's BY PMO rows (both plans) and the deck's Funding by PMO; board E on the PMO
  Matrix and the forecast; board F on each PMO tab's MC memo and Unfunded rows, the CE by PMO sheet's ★ and Unfunded
  columns, the deck's Unfunded and ★ columns, the PMO Matrix's totals and ★ columns and the panel; board G on the PMO
  Matrix and the forecast; each from the workbook's bytes, the deck's tables or the board, with the Spend Plan Source's CLIN
  lines as a control. 51 checks fail on the board before the change; every control (38) passes on both."
- **NEXT-VERSION, Mutations bullet.** Add "`-tab-memo-float-split`, `-tab-unf-float-split`, `-deck-mc-float-split`,
  `-cebypmo-mcs-float-split`, `-matrix-mcs-own-rounding`, `-panel-mc-own-rounding` and `-weights-frac-times-tot`" and the
  counts from `out/ppm-summary.txt`: each caught by the focused blocks (51, 51, 42, 13, 9, 1, 1, 2, 1, 3, 2, 1, 2, 2, 1, 1, 1, 1, 1, 1 and 2 failing, in the bullet's order).
- **LEDGER append.**
  - "Two focused blocks (79 checks; …; read on every view above): 44 fail on `fce8a391`, all pass after; every control (35)
    passes on both. Fourteen mutations caught (…)" becomes "Two focused blocks (89 checks; …, a starred requirement drawn
    from both lanes and short, and an exact tie at budget size; each read on the views NEXT-VERSION names): 51 fail on
    `fce8a391`, all pass after; every control (38) passes on both. Twenty-one mutations caught (…)".
  - "mcount 1342/1342" becomes "mcount 1349/1349".
  - "mutate `cbc6defc` → `3f7d8311` (fourteen entries …)" becomes "mutate `cbc6defc` → `f9d76e42` (twenty-one entries …)".
  - "audit-recon `529e36f7` → `2fb4b7ad`" becomes "→ `04f0b95a`".

## Decisions, with reasons

- **I built on the money verifier's board F.** I did not write a second board for the same cells. It already pins six of
  the cells; two boards for the same thing would cost the lead a merge. I added only what it misses: the Matrix ★ short
  and the panel, which both survive it, and board G. If the lead takes money's F alone, my S2 and the panel and Matrix
  survivors stay open.
- **I put the panel's whole row in one check.** It also pins TOTAL Disc and Mand on an uneven case, at no extra cost.
- **I did not pin CLIN asks with cents.** The board rounds them at load, so there is nothing to pin.
- **Must-fix rather than should-fix.** This is the same standard round 1's tests verifier applied to the uncovered exports:
  money cells this commit moves, a plausible regression passes every suite, and a written claim says otherwise.

## Every run

Each run went through `run.sh` (`setsid -w timeout -k 10 600`). The `AUDIT_IMPORT_RUNNING` lock was checked before every run
and was absent each time; no run waited or was skipped. The earlier attempt's runs (5:51–6:01 AM ET) are reused; their blobs
are re-checked above.

| # | label | start (ET) | exit | wall s | log |
|---|---|---|---|---|---|
| 1 | f-c1 | 2026-10-13 05:51:27 | 0 | 5.3 | logs/f-c1.log |
| 2 | f-base | 2026-10-13 05:51:32 | 1 | 4.8 | logs/f-base.log |
| 3 | s-c1-audit-recon | 2026-10-13 05:52:20 | 0 | 113.5 | logs/s-c1-audit-recon.log |
| 4 | bm-v200-u9-split-by-fraction | 2026-10-13 05:55:16 | 1 | 9.0 | logs/bm-v200-u9-split-by-fraction.log |
| 5 | bm-v200-u9-weights-are-fractions | 2026-10-13 05:55:25 | 1 | 10.9 | logs/bm-v200-u9-weights-are-fractions.log |
| 6 | bm-v200-u9-per-part-rounding | 2026-10-13 05:55:36 | 1 | 11.2 | logs/bm-v200-u9-per-part-rounding.log |
| 7 | bm-v200-u9-ties-by-name | 2026-10-13 05:55:47 | 1 | 11.3 | logs/bm-v200-u9-ties-by-name.log |
| 8 | bm-v200-u9-uncovered-weight-dropped | 2026-10-13 05:55:59 | 1 | 10.8 | logs/bm-v200-u9-uncovered-weight-dropped.log |
| 9 | bm-v200-u9-plan-part-by-weight | 2026-10-13 05:56:10 | 1 | 9.7 | logs/bm-v200-u9-plan-part-by-weight.log |
| 10 | bm-v200-u9-plan-placed-by-weight | 2026-10-13 05:56:20 | 1 | 10.5 | logs/bm-v200-u9-plan-placed-by-weight.log |
| 11 | bm-v200-u9-cebypmo-float-split | 2026-10-13 05:56:30 | 1 | 12.7 | logs/bm-v200-u9-cebypmo-float-split.log |
| 12 | bm-v200-u9-cebypmo-own-rounding | 2026-10-13 05:56:43 | 1 | 10.5 | logs/bm-v200-u9-cebypmo-own-rounding.log |
| 13 | bm-v200-u9-tab-portions-float-split | 2026-10-13 05:56:54 | 1 | 8.8 | logs/bm-v200-u9-tab-portions-float-split.log |
| 14 | s-base-audit-recon | 2026-10-13 05:54:36 | 0 | 148.6 | logs/s-base-audit-recon.log |
| 15 | bm-v200-u9-deck-rollup-float-split | 2026-10-13 05:57:02 | 1 | 9.7 | logs/bm-v200-u9-deck-rollup-float-split.log |
| 16 | bm-v200-u9-deck-own-rounding | 2026-10-13 05:57:12 | 1 | 13.8 | logs/bm-v200-u9-deck-own-rounding.log |
| 17 | pf-c1 | 2026-10-13 05:57:29 | 0 | 4.0 | logs/pf-c1.log |
| 18 | pf-base | 2026-10-13 05:57:33 | 1 | 4.0 | logs/pf-base.log |
| 19 | bm-v200-u9-weights-first-clin | 2026-10-13 05:57:26 | 1 | 11.2 | logs/bm-v200-u9-weights-first-clin.log |
| 20 | bm-v200-u9-office-ranks-by-last-clin | 2026-10-13 05:57:37 | 1 | 8.2 | logs/bm-v200-u9-office-ranks-by-last-clin.log |
| 21 | om-vt2-ask-stage-by-fraction | 2026-10-13 05:57:54 | 1 | 9.8 | logs/om-vt2-ask-stage-by-fraction.log |
| 22 | om-vt2-cebypmo-mcs-own-rounding | 2026-10-13 05:58:04 | 0 | 6.2 | logs/om-vt2-cebypmo-mcs-own-rounding.log |
| 23 | om-vt2-cebypmo-unf-own-rounding | 2026-10-13 05:58:10 | 0 | 6.5 | logs/om-vt2-cebypmo-unf-own-rounding.log |
| 24 | om-vt2-cr-by-fraction | 2026-10-13 05:58:17 | 1 | 9.6 | logs/om-vt2-cr-by-fraction.log |
| 25 | om-vt2-deck-mc-own-rounding | 2026-10-13 05:58:26 | 0 | 9.4 | logs/om-vt2-deck-mc-own-rounding.log |
| 26 | om-vt2-deck-unf-own-rounding | 2026-10-13 05:58:36 | 0 | 8.7 | logs/om-vt2-deck-unf-own-rounding.log |
| 27 | om-vt2-gap-disables-exact | 2026-10-13 05:58:45 | 1 | 6.5 | logs/om-vt2-gap-disables-exact.log |
| 28 | om-vt2-matrix-mcs-own-rounding | 2026-10-13 05:58:51 | 0 | 5.8 | logs/om-vt2-matrix-mcs-own-rounding.log |
| 29 | om-vt2-oblig-ufr-own-rounding | 2026-10-13 05:58:57 | 1 | 5.7 | logs/om-vt2-oblig-ufr-own-rounding.log |
| 30 | om-vt2-offices-by-weight-desc | 2026-10-13 05:59:03 | 1 | 7.5 | logs/om-vt2-offices-by-weight-desc.log |
| 31 | om-vt2-tab-mc-own-rounding | 2026-10-13 05:59:11 | 0 | 5.1 | logs/om-vt2-tab-mc-own-rounding.log |
| 32 | s-c1suite-baseboard-audit-recon | 2026-10-13 05:57:05 | 1 | 132.2 | logs/s-c1suite-baseboard-audit-recon.log |
| 33 | om-vt2-tab-unf-own-rounding | 2026-10-13 05:59:16 | 0 | 4.1 | logs/om-vt2-tab-unf-own-rounding.log |
| 34 | om-vt2-weights-frac-times-tot | 2026-10-13 05:59:20 | 0 | 10.4 | logs/om-vt2-weights-frac-times-tot.log |
| 35 | opf-vt2-ask-stage-by-fraction | 2026-10-13 05:59:30 | 1 | 7.3 | logs/opf-vt2-ask-stage-by-fraction.log |
| 36 | opf-vt2-cebypmo-mcs-own-rounding | 2026-10-13 05:59:38 | 1 | 7.2 | logs/opf-vt2-cebypmo-mcs-own-rounding.log |
| 37 | opf-vt2-cebypmo-unf-own-rounding | 2026-10-13 05:59:45 | 1 | 7.3 | logs/opf-vt2-cebypmo-unf-own-rounding.log |
| 38 | opf-vt2-cr-by-fraction | 2026-10-13 05:59:53 | 0 | 4.3 | logs/opf-vt2-cr-by-fraction.log |
| 39 | opf-vt2-deck-mc-own-rounding | 2026-10-13 05:59:57 | 1 | 4.4 | logs/opf-vt2-deck-mc-own-rounding.log |
| 40 | opf-vt2-deck-unf-own-rounding | 2026-10-13 06:00:01 | 1 | 4.2 | logs/opf-vt2-deck-unf-own-rounding.log |
| 41 | opf-vt2-gap-disables-exact | 2026-10-13 06:00:06 | 0 | 4.3 | logs/opf-vt2-gap-disables-exact.log |
| 42 | opf-vt2-matrix-mcs-own-rounding | 2026-10-13 06:00:10 | 1 | 4.5 | logs/opf-vt2-matrix-mcs-own-rounding.log |
| 43 | opf-vt2-oblig-ufr-own-rounding | 2026-10-13 06:00:15 | 1 | 4.4 | logs/opf-vt2-oblig-ufr-own-rounding.log |
| 44 | opf-vt2-offices-by-weight-desc | 2026-10-13 06:00:19 | 1 | 5.4 | logs/opf-vt2-offices-by-weight-desc.log |
| 45 | opf-vt2-tab-mc-own-rounding | 2026-10-13 06:00:25 | 1 | 5.8 | logs/opf-vt2-tab-mc-own-rounding.log |
| 46 | opf-vt2-tab-unf-own-rounding | 2026-10-13 06:00:31 | 1 | 4.5 | logs/opf-vt2-tab-unf-own-rounding.log |
| 47 | opf-vt2-weights-frac-times-tot | 2026-10-13 06:00:35 | 0 | 5.0 | logs/opf-vt2-weights-frac-times-tot.log |
| 48 | pgh-c1 | 2026-10-13 06:00:55 | 1 | 8.3 | logs/pgh-c1.log |
| 49 | pgh-base | 2026-10-13 06:01:03 | 1 | 7.0 | logs/pgh-base.log |
| 50 | om-vt2-weights-rounded | 2026-10-13 06:01:10 | 0 | 12.7 | logs/om-vt2-weights-rounded.log |
| 51 | opgh-vt2-weights-rounded | 2026-10-13 06:01:23 | 1 | 6.8 | logs/opgh-vt2-weights-rounded.log |
| 52 | opgh-vt2-weights-frac-times-tot | 2026-10-13 06:01:30 | 1 | 4.9 | logs/opgh-vt2-weights-frac-times-tot.log |
| 53 | s2-c1-boot-same | 2026-10-13 09:37:09 | 0 | 13.9 | logs/s2-c1-boot-same.log |
| 54 | s2-c1-audit | 2026-10-13 09:37:23 | 0 | 15.6 | logs/s2-c1-audit.log |
| 55 | mf-c1 | 2026-10-13 09:37:29 | 0 | 14.5 | logs/mf-c1.log |
| 56 | s2-c1-audit-ppt | 2026-10-13 09:37:38 | 0 | 8.8 | logs/s2-c1-audit-ppt.log |
| 57 | mf-base | 2026-10-13 09:37:43 | 1 | 12.7 | logs/mf-base.log |
| 58 | mf-vt2-cebypmo-mcs-own-rounding | 2026-10-13 09:37:56 | 1 | 8.5 | logs/mf-vt2-cebypmo-mcs-own-rounding.log |
| 59 | mf-vt2-cebypmo-unf-own-rounding | 2026-10-13 09:38:05 | 1 | 12.2 | logs/mf-vt2-cebypmo-unf-own-rounding.log |
| 60 | mf-vt2-deck-mc-own-rounding | 2026-10-13 09:38:17 | 1 | 13.2 | logs/mf-vt2-deck-mc-own-rounding.log |
| 61 | s2-c1-audit-other | 2026-10-13 09:37:47 | 0 | 51.1 | logs/s2-c1-audit-other.log |
| 62 | s2-c1-legacy-fsrc | 2026-10-13 09:38:38 | 0 | 4.9 | logs/s2-c1-legacy-fsrc.log |
| 63 | mf-vt2-deck-unf-own-rounding | 2026-10-13 09:38:30 | 1 | 13.5 | logs/mf-vt2-deck-unf-own-rounding.log |
| 64 | mf-vt2-matrix-mcs-own-rounding | 2026-10-13 09:38:44 | 0 | 16.7 | logs/mf-vt2-matrix-mcs-own-rounding.log |
| 65 | mf-vt2-tab-mc-own-rounding | 2026-10-13 09:39:01 | 1 | 15.3 | logs/mf-vt2-tab-mc-own-rounding.log |
| 66 | mf-vt2-tab-unf-own-rounding | 2026-10-13 09:39:16 | 1 | 17.4 | logs/mf-vt2-tab-unf-own-rounding.log |
| 67 | mf-vt2-weights-frac-times-tot | 2026-10-13 09:39:34 | 0 | 18.8 | logs/mf-vt2-weights-frac-times-tot.log |
| 68 | om2-vt2-panel-mc-own-rounding | 2026-10-13 09:39:37 | 0 | 16.4 | logs/om2-vt2-panel-mc-own-rounding.log |
| 69 | om2-vt2-matrix-mc-own-rounding | 2026-10-13 09:39:54 | 1 | 14.1 | logs/om2-vt2-matrix-mc-own-rounding.log |
| 70 | mf2-vt2-panel-mc-own-rounding | 2026-10-13 09:40:08 | 0 | 14.8 | logs/mf2-vt2-panel-mc-own-rounding.log |
| 71 | s2-c1-audit-hostile | 2026-10-13 09:38:43 | 0 | 118.3 | logs/s2-c1-audit-hostile.log |
| 72 | mf2-vt2-matrix-mc-own-rounding | 2026-10-13 09:40:23 | 1 | 20.5 | logs/mf2-vt2-matrix-mc-own-rounding.log |
| 73 | s2-c1-audit-inject | 2026-10-13 09:40:42 | 0 | 24.2 | logs/s2-c1-audit-inject.log |
| 74 | s2-base-boot-same | 2026-10-13 09:41:06 | 0 | 15.5 | logs/s2-base-boot-same.log |
| 75 | s2-base-audit | 2026-10-13 09:41:21 | 0 | 13.7 | logs/s2-base-audit.log |
| 76 | s2-base-audit-ppt | 2026-10-13 09:41:35 | 0 | 7.9 | logs/s2-base-audit-ppt.log |
| 77 | pp-p1 | 2026-10-13 09:41:38 | 0 | 14.1 | logs/pp-p1.log |
| 78 | pp-base | 2026-10-13 09:41:52 | 1 | 11.7 | logs/pp-base.log |
| 79 | ppm-v200-u9-split-by-fraction | 2026-10-13 09:42:03 | 1 | 14.3 | logs/ppm-v200-u9-split-by-fraction.log |
| 80 | ppm-v200-u9-weights-are-fractions | 2026-10-13 09:42:18 | 1 | 12.0 | logs/ppm-v200-u9-weights-are-fractions.log |
| 81 | s2-base-audit-other | 2026-10-13 09:41:43 | 0 | 47.1 | logs/s2-base-audit-other.log |
| 82 | s2-base-legacy-fsrc | 2026-10-13 09:42:30 | 0 | 4.0 | logs/s2-base-legacy-fsrc.log |
| 83 | ppm-v200-u9-per-part-rounding | 2026-10-13 09:42:30 | 1 | 11.6 | logs/ppm-v200-u9-per-part-rounding.log |
| 84 | ppm-v200-u9-ties-by-name | 2026-10-13 09:42:42 | 1 | 12.3 | logs/ppm-v200-u9-ties-by-name.log |
| 85 | ppm-v200-u9-uncovered-weight-dropped | 2026-10-13 09:42:54 | 1 | 13.5 | logs/ppm-v200-u9-uncovered-weight-dropped.log |
| 86 | ppm-v200-u9-plan-part-by-weight | 2026-10-13 09:43:08 | 1 | 15.6 | logs/ppm-v200-u9-plan-part-by-weight.log |
| 87 | ppm-v200-u9-plan-placed-by-weight | 2026-10-13 09:43:23 | 1 | 17.5 | logs/ppm-v200-u9-plan-placed-by-weight.log |
| 88 | ppm-v200-u9-cebypmo-float-split | 2026-10-13 09:43:41 | 1 | 16.6 | logs/ppm-v200-u9-cebypmo-float-split.log |
| 89 | s2-base-audit-hostile | 2026-10-13 09:42:34 | 0 | 99.6 | logs/s2-base-audit-hostile.log |
| 90 | ppm-v200-u9-cebypmo-own-rounding | 2026-10-13 09:43:58 | 1 | 20.2 | logs/ppm-v200-u9-cebypmo-own-rounding.log |
| 91 | ppm-v200-u9-tab-portions-float-split | 2026-10-13 09:44:18 | 1 | 18.4 | logs/ppm-v200-u9-tab-portions-float-split.log |
| 92 | s2-base-audit-inject | 2026-10-13 09:44:14 | 0 | 28.4 | logs/s2-base-audit-inject.log |
| 93 | fb-c1 | 2026-10-13 09:44:44 | 0 | 12.1 | logs/fb-c1.log |
| 94 | ppm-v200-u9-deck-rollup-float-split | 2026-10-13 09:44:37 | 1 | 20.3 | logs/ppm-v200-u9-deck-rollup-float-split.log |
| 95 | fb-base | 2026-10-13 09:44:56 | 0 | 12.6 | logs/fb-base.log |
| 96 | ppm-v200-u9-deck-own-rounding | 2026-10-13 09:44:57 | 1 | 19.1 | logs/ppm-v200-u9-deck-own-rounding.log |
| 97 | ppm-v200-u9-weights-first-clin | 2026-10-13 09:45:16 | 1 | 18.5 | logs/ppm-v200-u9-weights-first-clin.log |
| 98 | ppm-v200-u9-office-ranks-by-last-clin | 2026-10-13 09:45:35 | 1 | 22.6 | logs/ppm-v200-u9-office-ranks-by-last-clin.log |
| 99 | ppm-v200-u9-tab-memo-float-split | 2026-10-13 09:45:58 | 1 | 19.0 | logs/ppm-v200-u9-tab-memo-float-split.log |
| 100 | ppm-v200-u9-tab-unf-float-split | 2026-10-13 09:46:17 | 1 | 14.8 | logs/ppm-v200-u9-tab-unf-float-split.log |
| 101 | ms-vt2-panel-mc-own-rounding-audit-recon | 2026-10-13 09:42:55 | 0 | 226.0 | logs/ms-vt2-panel-mc-own-rounding-audit-recon.log |
| 102 | ppm-v200-u9-deck-mc-float-split | 2026-10-13 09:46:32 | 1 | 16.1 | logs/ppm-v200-u9-deck-mc-float-split.log |
| 103 | ms-vt2-panel-mc-own-rounding-audit | 2026-10-13 09:46:41 | 0 | 16.7 | logs/ms-vt2-panel-mc-own-rounding-audit.log |
| 104 | ppm-v200-u9-cebypmo-mcs-float-split | 2026-10-13 09:46:48 | 1 | 17.0 | logs/ppm-v200-u9-cebypmo-mcs-float-split.log |
| 105 | ms-vt2-panel-mc-own-rounding-audit-ppt | 2026-10-13 09:46:58 | 0 | 10.4 | logs/ms-vt2-panel-mc-own-rounding-audit-ppt.log |
| 106 | ppm-v200-u9-matrix-mcs-own-rounding | 2026-10-13 09:47:05 | 1 | 14.7 | logs/ppm-v200-u9-matrix-mcs-own-rounding.log |
| 107 | ppm-v200-u9-panel-mc-own-rounding | 2026-10-13 09:47:20 | 1 | 16.8 | logs/ppm-v200-u9-panel-mc-own-rounding.log |
| 108 | ppm-v200-u9-weights-frac-times-tot | 2026-10-13 09:47:37 | 1 | 13.7 | logs/ppm-v200-u9-weights-frac-times-tot.log |
| 109 | ms-vt2-panel-mc-own-rounding-audit-other | 2026-10-13 09:47:09 | 0 | 53.8 | logs/ms-vt2-panel-mc-own-rounding-audit-other.log |
| 110 | ppo-vt2-ask-stage-by-fraction | 2026-10-13 09:47:51 | 1 | 13.1 | logs/ppo-vt2-ask-stage-by-fraction.log |
| 111 | ppo-vt2-gap-disables-exact | 2026-10-13 09:48:04 | 1 | 19.1 | logs/ppo-vt2-gap-disables-exact.log |
| 112 | ppo-vt2-offices-by-weight-desc | 2026-10-13 09:48:23 | 1 | 19.1 | logs/ppo-vt2-offices-by-weight-desc.log |
| 113 | s2-p1-audit-recon | 2026-10-13 09:45:09 | 0 | 224.1 | logs/s2-p1-audit-recon.log |
| 114 | ppo-vt2-tab-unf-own-rounding | 2026-10-13 09:48:42 | 1 | 16.2 | logs/ppo-vt2-tab-unf-own-rounding.log |
| 115 | ppo-vt2-tab-mc-own-rounding | 2026-10-13 09:48:59 | 1 | 19.3 | logs/ppo-vt2-tab-mc-own-rounding.log |
| 116 | ppo-vt2-deck-unf-own-rounding | 2026-10-13 09:49:18 | 1 | 18.0 | logs/ppo-vt2-deck-unf-own-rounding.log |
| 117 | ppo-vt2-deck-mc-own-rounding | 2026-10-13 09:49:36 | 1 | 18.2 | logs/ppo-vt2-deck-mc-own-rounding.log |
| 118 | ppo-vt2-cebypmo-unf-own-rounding | 2026-10-13 09:49:55 | 1 | 18.4 | logs/ppo-vt2-cebypmo-unf-own-rounding.log |
| 119 | ppo-vt2-cebypmo-mcs-own-rounding | 2026-10-13 09:50:13 | 1 | 17.9 | logs/ppo-vt2-cebypmo-mcs-own-rounding.log |
| 120 | ppo-vt2-oblig-ufr-own-rounding | 2026-10-13 09:50:31 | 1 | 17.0 | logs/ppo-vt2-oblig-ufr-own-rounding.log |
| 121 | ppo-vt2-cr-by-fraction | 2026-10-13 09:50:48 | 1 | 19.4 | logs/ppo-vt2-cr-by-fraction.log |
| 122 | ppo-vt2-weights-rounded | 2026-10-13 09:51:08 | 0 | 21.1 | logs/ppo-vt2-weights-rounded.log |
| 123 | ppo-vt2-matrix-mc-own-rounding | 2026-10-13 09:51:29 | 1 | 21.0 | logs/ppo-vt2-matrix-mc-own-rounding.log |
| 124 | ms-vt2-matrix-mcs-own-rounding-audit-recon | 2026-10-13 09:48:02 | 0 | 249.7 | logs/ms-vt2-matrix-mcs-own-rounding-audit-recon.log |
| 125 | ms-vt2-matrix-mcs-own-rounding-audit | 2026-10-13 09:52:12 | 0 | 18.1 | logs/ms-vt2-matrix-mcs-own-rounding-audit.log |
| 126 | ms-vt2-matrix-mcs-own-rounding-audit-ppt | 2026-10-13 09:52:30 | 0 | 9.1 | logs/ms-vt2-matrix-mcs-own-rounding-audit-ppt.log |
| 127 | s2-p1suite-baseboard-audit-recon | 2026-10-13 09:48:53 | 1 | 244.0 | logs/s2-p1suite-baseboard-audit-recon.log |
| 128 | check-base | 2026-10-13 09:52:57 | 0 | 6.5 | logs/check-base.log |
| 129 | moneymap-base | 2026-10-13 09:53:03 | 0 | 0.3 | logs/moneymap-base.log |
| 130 | check-c1 | 2026-10-13 09:53:04 | 0 | 6.1 | logs/check-c1.log |
| 131 | moneymap-c1 | 2026-10-13 09:53:10 | 0 | 0.5 | logs/moneymap-c1.log |
| 132 | check-p1 | 2026-10-13 09:53:10 | 0 | 5.3 | logs/check-p1.log |
| 133 | moneymap-p1 | 2026-10-13 09:53:15 | 0 | 0.4 | logs/moneymap-p1.log |
| 134 | gc-restore | 2026-10-13 09:53:16 | 0 | 0.2 | logs/gc-restore.log |
| 135 | ms-vt2-matrix-mcs-own-rounding-audit-other | 2026-10-13 09:52:39 | 0 | 60.1 | logs/ms-vt2-matrix-mcs-own-rounding-audit-other.log |
| 136 | ms-vt2-weights-frac-times-tot-audit-recon | 2026-10-13 09:53:40 | 0 | 212.5 | logs/ms-vt2-weights-frac-times-tot-audit-recon.log |
| 137 | ms-vt2-weights-frac-times-tot-audit | 2026-10-13 09:57:12 | 0 | 20.4 | logs/ms-vt2-weights-frac-times-tot-audit.log |
| 138 | ms-vt2-weights-frac-times-tot-audit-ppt | 2026-10-13 09:57:33 | 0 | 10.4 | logs/ms-vt2-weights-frac-times-tot-audit-ppt.log |
| 139 | ms-vt2-weights-frac-times-tot-audit-other | 2026-10-13 09:57:43 | 0 | 62.7 | logs/ms-vt2-weights-frac-times-tot-audit-other.log |
| 140 | ms-vt2-tab-mc-own-rounding-audit-recon | 2026-10-13 09:58:46 | 0 | 235.0 | logs/ms-vt2-tab-mc-own-rounding-audit-recon.log |
| 141 | ms-vt2-tab-mc-own-rounding-audit | 2026-10-13 10:02:41 | 0 | 20.1 | logs/ms-vt2-tab-mc-own-rounding-audit.log |
| 142 | ms-vt2-tab-mc-own-rounding-audit-ppt | 2026-10-13 10:03:01 | 0 | 8.2 | logs/ms-vt2-tab-mc-own-rounding-audit-ppt.log |
| 143 | ms-vt2-tab-mc-own-rounding-audit-other | 2026-10-13 10:03:09 | 0 | 57.9 | logs/ms-vt2-tab-mc-own-rounding-audit-other.log |
| 144 | ms-vt2-tab-unf-own-rounding-audit-recon | 2026-10-13 10:04:07 | 0 | 207.7 | logs/ms-vt2-tab-unf-own-rounding-audit-recon.log |
| 145 | ms-vt2-tab-unf-own-rounding-audit | 2026-10-13 10:07:35 | 0 | 25.5 | logs/ms-vt2-tab-unf-own-rounding-audit.log |
| 146 | ms-vt2-tab-unf-own-rounding-audit-ppt | 2026-10-13 10:08:01 | 0 | 11.5 | logs/ms-vt2-tab-unf-own-rounding-audit-ppt.log |
| 147 | ms-vt2-tab-unf-own-rounding-audit-other | 2026-10-13 10:08:12 | 0 | 68.4 | logs/ms-vt2-tab-unf-own-rounding-audit-other.log |
| 148 | ms-vt2-deck-mc-own-rounding-audit-recon | 2026-10-13 10:09:21 | 0 | 222.3 | logs/ms-vt2-deck-mc-own-rounding-audit-recon.log |
| 149 | ms-vt2-deck-mc-own-rounding-audit | 2026-10-13 10:13:03 | 0 | 24.0 | logs/ms-vt2-deck-mc-own-rounding-audit.log |
| 150 | ms-vt2-deck-mc-own-rounding-audit-ppt | 2026-10-13 10:13:27 | 0 | 8.8 | logs/ms-vt2-deck-mc-own-rounding-audit-ppt.log |
| 151 | ms-vt2-deck-mc-own-rounding-audit-other | 2026-10-13 10:13:36 | 0 | 66.7 | logs/ms-vt2-deck-mc-own-rounding-audit-other.log |
| 152 | ms-vt2-deck-unf-own-rounding-audit-recon | 2026-10-13 10:14:43 | 0 | 179.1 | logs/ms-vt2-deck-unf-own-rounding-audit-recon.log |
| 153 | ms-vt2-deck-unf-own-rounding-audit | 2026-10-13 10:17:42 | 0 | 14.7 | logs/ms-vt2-deck-unf-own-rounding-audit.log |
| 154 | ms-vt2-deck-unf-own-rounding-audit-ppt | 2026-10-13 10:17:56 | 0 | 7.5 | logs/ms-vt2-deck-unf-own-rounding-audit-ppt.log |
| 155 | ms-vt2-deck-unf-own-rounding-audit-other | 2026-10-13 10:18:04 | 0 | 52.2 | logs/ms-vt2-deck-unf-own-rounding-audit-other.log |
| 156 | ms-vt2-cebypmo-mcs-own-rounding-audit-recon | 2026-10-13 10:18:56 | 0 | 185.9 | logs/ms-vt2-cebypmo-mcs-own-rounding-audit-recon.log |
| 157 | ms-vt2-cebypmo-mcs-own-rounding-audit | 2026-10-13 10:22:02 | 0 | 16.1 | logs/ms-vt2-cebypmo-mcs-own-rounding-audit.log |
| 158 | ms-vt2-cebypmo-mcs-own-rounding-audit-ppt | 2026-10-13 10:22:18 | 0 | 5.8 | logs/ms-vt2-cebypmo-mcs-own-rounding-audit-ppt.log |
| 159 | ms-vt2-cebypmo-mcs-own-rounding-audit-other | 2026-10-13 10:22:24 | 0 | 35.5 | logs/ms-vt2-cebypmo-mcs-own-rounding-audit-other.log |
| 160 | ms-vt2-cebypmo-unf-own-rounding-audit-recon | 2026-10-13 10:23:00 | 0 | 103.2 | logs/ms-vt2-cebypmo-unf-own-rounding-audit-recon.log |
| 161 | ms-vt2-cebypmo-unf-own-rounding-audit | 2026-10-13 10:24:43 | 0 | 7.5 | logs/ms-vt2-cebypmo-unf-own-rounding-audit.log |
| 162 | ms-vt2-cebypmo-unf-own-rounding-audit-ppt | 2026-10-13 10:24:51 | 0 | 3.4 | logs/ms-vt2-cebypmo-unf-own-rounding-audit-ppt.log |
| 163 | ms-vt2-cebypmo-unf-own-rounding-audit-other | 2026-10-13 10:24:54 | 0 | 29.6 | logs/ms-vt2-cebypmo-unf-own-rounding-audit-other.log |

163 runs.

## PIDs

`pids.txt` holds:
- every timeout PID and its child, with the command;
- this session's batch drivers.

There are 332 lines:
- 104 from the earlier attempt, before the 9:11 AM ET container restart. Those PIDs are void now and may belong to other
  processes.
- the rest from this session.

At 10:25:56 AM ET, two of the 228 PIDs recorded this session exist (`bin/alive.py`, which reads /proc only), but neither is mine any more. The numbers have been reused by other sessions' processes: 21277 (my batchB driver) is now `sleep 15`, and 21286 (mf-c1's timeout) is now another session's `timeout … bash -c SUITE_CHECKS=…`. My batchB finished at about 9:41 AM ET, and every one of its runs has an exit record in `logs/runs.txt`. I killed nothing.

## What I did not do

- I did not run full audit-import or audit-board; the lead runs those. I ran the focused audit-board PRIME-3 harness.
- I did not run the mutate sweep. mutate.mjs was read as text only, through `mcread.py`, `mkmut.py` and `mcount.py` with
  `python3 -I`.
- I did not run Playwright, verify:grid or validate:math.
- My survivors went through the four suites that read these views. They did not go through audit-board, audit-import,
  audit-hostile, audit-inject or legacy-fsrc.
- I did not re-run the builder's observe-only probes (the two-lane case X1/X2, case F, the empty office's tab). The money
  verifier re-ran them, and they bear on the money lens, not on tests.
- I did not edit the drafts, NEXT-VERSION.md or UNRESOLVED-LEDGER.md. The proposed text is above. p1 is a proposal for the
  lead, not a commit.
