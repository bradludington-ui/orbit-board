# U9 builder: the PMO split is exact and the same everywhere

Track U9 (ledger row U9, P2, MONEY). One commit is proposed; its cumulative copy is `c1/`.

- **Built** 12 Oct, 7:31 to 7:50 PM ET.
- **Fix round 1**, 13 Oct, 4:15 to 4:48 AM ET, after two independent verifiers.
- **Fix round 2**, 13 Oct, from 10:28 AM ET, after two more. This README was finished at 11:23 AM ET
  (`TZ=America/New_York date`).

Nothing was committed, staged or pushed. Nothing in `/home/user/orbit-board` or `/home/user/orbit-ui` was edited. Fix round
2 comes first below. Fix round 1 and the build's README follow, unchanged except for SUPERSEDED marks. Round 1's README is
also kept whole in `superseded/README.r1.md` (blob 13b973ae).

## Fix round 2 (13 Oct): the current result

This round started at 10:28 AM ET. Its first run started at 10:32:59 AM ET and its last at 11:15:37 AM ET (audit-hostile,
which ended at 11:19:12 AM ET). Two independent verifiers reviewed round 1:

- `verify-money-r2` (lens A, data loss and money): no must-fix, two should-fixes, three minors.
- `verify-tests-r2` (lens B, test adequacy): one must-fix, two should-fixes, minors.

This round fixes the must-fix, every should-fix, and the minors that were cheap and clearly right. **The board does not
change.** The fix is tests and text only, and it is the tests verifier's own tested minimal fix (`verify-tests-r2/p1`), which
builds on the money verifier's board F. Only its comments are put in the house voice.

**Nothing from a stopped attempt of this round was found.** I searched this directory for anything changed after round 1's
README (4:48 AM ET). Only the two verifiers' directories and `wfstate/` had changed. There was no "Fix round 2" section, no
changed copy, and no new probe, log or diff of mine. So nothing was kept from a stopped attempt; this round started fresh.

### The commit now proposed (one commit; cumulative copy `c1/`)

| file | base blob (7ee498a) | round 1's c1 (kept in `superseded/c1-r1/`) | **c1 now** |
|---|---|---|---|
| prioritization-board-grid.html | fce8a391 | 46e522a8 | **46e522a8370f05971c8ef0558c3c666b0953b0ac** (unchanged since the build) |
| tools/export-audit/audit-recon.mjs | 529e36f7 | 2fb4b7ad | **755647cc1340cd2d9ed2b8a78b58f29df4b98b34** |
| tools/export-audit/mutate.mjs (as mutate.mjs.txt) | cbc6defc | 3f7d8311 | **8fd34e940548e009efb812021792d8667c91fc54** |
| everything else | | unchanged | unchanged (`diff -rq` against base lists only these three) |

The proposed subject is unchanged: `v2.00 U9: the PMO split is exact, ties to the first office, and the same on every
by-office view`.

**Diffs:**

- `diffs/r2/c1-vs-base.diff` (blob 1246879f), by file:
  - board `c89b763d` (+13/−4), byte-identical to the build's and round 1's board diff;
  - audit-recon `d7d2abca` (+399/−0);
  - mutate `2ebd56da` (+71/−0).
- `diffs/r2/c1-vs-c1r1.diff` (blob ab7b8667), this round's own change:
  - audit-recon `4bc97964` (+76/−0);
  - mutate `2552f696` (+25/−0);
  - board: empty.
- Against base, audit-recon and mutate still only add lines.

**Against the tests verifier's p1** (`verify-tests-r2/p1`: audit-recon 04f0b95a, mutate f9d76e42), every code line is
byte-identical. Only comments differ, and the full comparison is in "Appendix: round 2 against p1" at the end of this
section:

- Two comments named who proposed the lines ("proposed by the tests verifier, round 2", "proposed by the money verifier,
  round 2"). They are rewritten in the voice of the surrounding v2.00 comments. A committed suite should say what a check
  holds, not who suggested it.
- The block header gains a paragraph for each of boards F and G, and their figures on the base. This is the tests
  verifier's minor 4.

### What the verifiers found, and what I did

| finding | from | rating | what I did |
|---|---|---|---|
| Eight cells that carry an office's PMO part are pinned by no check, and this commit moves every one: the panel's MC column, the PMO Matrix's ★ MC short, each PMO tab's MC memo and Unfunded rows, CE by PMO's ★ MC short and Unfunded, and the deck's Unfunded and ★ columns. Eight mutants survive every suite. Round 1's summary claimed "every export that carries the PMO parts is now held to the dollar" | tests (must-fix), money (S2) | must-fix | Took the tests verifier's tested fix. Board F (the money verifier's, verbatim) reads the tabs, CE by PMO and the deck. Two more checks read F on the PMO Matrix and the panel. Seven mutation entries; all 21 U9 entries are caught. **Round 1's claim was wrong and is withdrawn below.** |
| The "large values" cases cannot tell exact weights from weights rebuilt as fraction × total (mutant `vt2-weights-frac-times-tot` survives everything) | tests (S2) | should-fix | Board G (an exact tie at $779,153,421 over asks in the hundreds of millions) plus entry `v200-u9-weights-frac-times-tot`. Caught by 2 checks |
| The drafts overstate test coverage ("Each is read on …", "read on every view above") | tests (S1), money (S2) | should-fix | The Test bullet now says which board is read on which view, with 24 + 65 = 89 checks, 51 failing on the base, 38 controls and 21 mutation ids with their counts. The ledger append says "each read on the views NEXT-VERSION names" |
| "What users may see" leaves out that an office can LOSE its PMO tab (case P: $4 over CLINs asking 3 : 6 : 1 was MxS $1 / AV $2 / TSS $1, now $1 / $3 / $0, and no `PMO TSS` tab is written); and "by the dollar that moved" should be "dollars" | money (S1) | should-fix | Measured myself (`exp2-c1`, `exp2-base`, below). Both added to the draft. The ledger append now says an office can gain or lose its tab |
| The workbook's month-sheet note says "The last CLIN takes the rounding in every column", but since v1.95 `clinSplit` splits whole dollars by `apportion()` (ties to the earlier CLIN) | money (minor) | pre-existing, outside U9's diff | Confirmed by reading c1 line 30396 (base 30387) and `clinSplit`, lines 23485–23491. **Not changed here.** Ledger text is drafted for the lead under "For the lead" |
| The drafts cite UNRESOLVED-LEDGER.md as blob 1bcad628; at HEAD it is 8112ad0b | money (minor) | minor | Anchors re-read at HEAD 21b6dea and again at 68c9fe1 (11:24 AM ET): NEXT-VERSION.md is still 65265c13 (lines 777/778/792 as before); the ledger is 8112ad0b, and its U9 row (lines 20–30) still ends "Not fixed; awaiting Brad \|" |
| The money-map catalogue does not cite the new blocks | money (minor) | minor | **Not done**, as in round 1. It is a shared file every track edits, and the map holds without it (`moneymap-r2-c1`) |
| The "every export" header is not extended for F and G | tests (minor 4) | minor | Done (9 comment lines) |
| Three expectations are arrangements of literals made in the test: B's per-service forecast `B[g].d[i] + B[g].m[i]`, `[AT[g], AT[g]]`, `Array(12).fill(0).concat(...)` | tests (minor 2) | minor | **Not changed.** Every value is a hand-written literal and no board helper is involved. Only one is a sum (AFRC's d + m, 1 + 0 or 1 + 1). Both verifiers re-derived all of them exactly. Rewriting them would touch round 1's checks for no gain in what they hold (principle 5) |
| 38 of the 89 checks are CONTROLs; `plan-part-by-weight` and `plan-placed-by-weight` are caught only by C's CONTROLs | tests (minor 1) | acceptable | No change. Board C is a control by design: a modelled plan's figures do not move |

### Tests: what changed in audit-recon (block "v2.00 (U9, every export)" only)

Every line was inserted by `fix2/edit-r2.py`, which asserts that each anchor matches exactly once. Block 1, "v2.00 (U9)", is
unchanged. The block's name line, markers, wrapper, `bootMark()`/`bootRelease(__bm, [])`/`settleBoards()` and helpers are
unchanged; F and G sit inside its `try`, after board E's last check, as D and E do.

| added | lines | checks (controls) | source |
|---|---|---|---|
| Header: a paragraph each for boards F and G | 7 | — | mine (`fix2/header-fg.txt`, 2fe5ffda) |
| Header: F's and G's figures on the base, after "FAILS ON 7ee498a" | 2 | — | mine; every figure checked against `r2f-base` |
| Board F: tabs by portion, CE by PMO, deck | 1 blank + 31 | 4 (1) | `verify-money-r2/proposal/board-f.mjs.txt` (06f09634), verbatim |
| Board F on the PMO Matrix and the panel | 3 comment + 14 | 2 (0) | `verify-tests-r2/proposal/board-fg-addition.mjs.txt` (73a9d361), its first part; the 3-line comment reworded |
| Board G: the budget-size tie | 1 blank + 18 | 4 (2) | the same file, its second part, verbatim |

So "v2.00 (U9, every export)" goes from 14 checks to 24 (6 controls to 9), and the two U9 blocks from 79 to **89** (35 controls to
**38**). The inserted text is `fix2/block-fg.mjs.txt` (42326c70), made by `fix2/assemble-block.py` (bdfba58a).

| board | case | read on | expected (hand-written) | base gave (`r2f-base`) |
|---|---|---|---|---|
| F | PRIME-3 starred; CLINs 0010 / 0002 / 0008 at 1 : 2 : 3; USAF asks $9, draws $3 disc + $3 mand; ANG asks $3, draws nothing | each PMO tab: MC memo row, Unfunded row (amount, USAF, ANG) | MxS [3,2,1] [1,0,1]; AV [4,3,1] [2,1,1]; TSS [5,4,1] [3,2,1] | MxS [1,1,0] and no Unfunded row; AV [4,3,1] [2,1,1]; TSS [7,5,2] [4,2,2] |
| F | the same | CE by PMO: Ask, ★ MC requirement, ★ MC short vs Disc, Unfunded (incl delta) | 3,3,2,1; 4,4,3,2; 5,5,4,3 | 1,1,1,0; 4,4,3,2; 7,7,5,4 |
| F | the same | deck, Funding by PMO: Unfunded, ★ MC req, ★ MC short, as printed | $1 $3 $2; $2 $4 $3; $3 $5 $4 | — $1 $1; $2 $4 $3; $4 $7 $5 |
| F | the same | PMO Matrix: TOTAL Disc, TOTAL Mand, ★ MC requirement, ★ MC short | 1,1,3,2; 1,1,4,3; 1,1,5,4 | 0,1,1,1; 1,1,4,3; 2,1,7,5 |
| F | the same | PMO funding panel row as printed: USAF Disc/Mand, ANG Disc/Mand, TOTAL Disc/Mand, MC | $1 $1 — — $1 $1 $2; … $3; … $4 | MxS — $1 — — $0 $1 $1; AV … $3; TSS $2 $1 — — $2 $1 $5 |
| F | CONTROL | fixture (CLINs, lanes, starred) | passes on both | passes |
| G | USAF draws $779,153,421 discretionary over CLIN asks 881,836,554 / 575,398,923 / 101,071,365 (exactly half) | PMO Matrix USAF Disc; the forecast, whole portfolio | 440,918,277 / 287,699,462 / 50,535,682 (the AV–TSS tie is AV's) | 440,918,277 / 287,699,461 / 50,535,683 |
| G | CONTROLs | fixture; the Spend Plan Source's CLIN lines 0010 / 0002 / 0008 | 440,918,277 / 287,699,462 / 50,535,682 on both | passes |

**Hand check.** `fix2/exact-r2.py` (6c6e32ae, exact fractions, no floating point) re-derives every F and G figure from the
stated rule, and all match. Here is F's arithmetic:

- USAF's ask, $9 at 1 : 2 : 3, is 1.5 / 3 / 4.5. The tie goes to MxS, so 2 / 3 / 4.
- USAF's discretionary $3 is split by 2 : 3 : 4, so 1 / 1 / 1.
- USAF's mandatory $3 is split by what each office still has to take, 1 : 2 : 3, so 1 / 1 / 1 (tie to MxS).
- ANG's $3 is 1 / 1 / 1, all of it unfunded.

The tests verifier's `bin/exact.py` reached the same figures independently.

**Runs of the focused harness.** The harness is `harness/r2/focused-u9.mjs` (blob 31315c7f), built by round 1's
`bin/mkfocused-u9-r1.py` from c1's audit-recon. Every line after line 1 is in c1's audit-recon verbatim (checked: 0 lines
not found). Against round 1's harness, it adds 76 lines and removes none.

| run | board | checks | passed | failed | controls passed | non-controls failed |
|---|---|---|---|---|---|---|
| r2f-c1 (10:32:59 AM ET, exit 0, 7.3 s) | 46e522a8 | 89 | 89 | 0 | 38/38 | 0/51 |
| r2f-base (10:33:06 AM ET, exit 1, 9.4 s) | fce8a391 | 89 | 38 | 51 | 38/38 | **51/51** |

**Full audit-recon:**

- c1's suite on c1 (`s-r2c1-audit-recon`, 10:51:58 AM ET, exit 0, 417.3 s): ALL CHECKS PASSED.
- c1's suite on the **base board**, BOARD set (`s-r2c1suite-baseboard-audit-recon`, 10:59:02 AM ET, exit 1, 406.9 s):
  "51 FAILING CHECK(S)". Every failing scenario is one of the two U9 blocks, and none is a CONTROL.
- The base suite on the base board (`s-r2base-audit-recon`, 10:45:38 AM ET, exit 0, 370.5 s): ALL CHECKS PASSED.
- These walls are about three times round 1's because the machine was loaded (load average 24 to 34 on 4 CPUs). Every run
  finished inside its 600 s cap.

### Mutations (`fix2/mutate-entries.txt`, blob 1fb49993; 7 entries inserted after round 1's 14, before the R3 line)

The entries are the verifiers' own, byte for byte: the money verifier's 4 (`86d847cf`) and the tests verifier's 3
(`19df6ae2`). They sit under one comment in the house voice, made by `fix2/assemble-entries.py` (37955d42).

Each mutant was built from c1's mutate text by `mkmut.py`, and each find matches its board exactly once. Each is
byte-identical to the verifier's mutant of the same name. All 21 U9 mutants were run through the round-2 focused harness
(`fix2/mutloop.sh`; `out/r2fm-summary.txt`, `out/r2fm-failing.txt`).

| id | what | failing | caught by (what it printed) |
|---|---|---|---|
| v200-u9-tab-memo-float-split | each PMO tab's MC memo row splits the ask by the fractions | 1 | F · the PMO tabs by portion (MC memo 1 / 4 / 7) |
| v200-u9-tab-unf-float-split | each PMO tab's Unfunded row splits by the fractions | 1 | F · the PMO tabs by portion (MxS has no Unfunded row; TSS 4) |
| v200-u9-deck-mc-float-split | the deck's ★ MC req splits by the fractions | 1 | F · the deck ($1 / $4 / $7) |
| v200-u9-cebypmo-mcs-float-split | CE by PMO's ★ MC short splits by the fractions | 1 | F · CE by PMO (1 / 3 / 5) |
| v200-u9-matrix-mcs-own-rounding | the PMO Matrix's ★ MC short rounds each office's fraction itself | 1 | F · the PMO Matrix (TSS 5) |
| v200-u9-panel-mc-own-rounding | the panel's MC column rounds each office's fraction itself | 1 | F · the PMO panel (TSS $5) |
| v200-u9-weights-frac-times-tot | the weights are fraction × the CLINs' total, not the CLIN asks | 2 | G · the PMO Matrix, G · the forecast (287,699,461 / 50,535,683) |

**All 21, in mutate order, with this round's failing counts:**

| id | failing (round 1) | **failing now** |
|---|---|---|
| split-by-fraction | 44 | **51** |
| weights-are-fractions | 44 | **51** |
| per-part-rounding | 35 | **42** |
| ties-by-name | 13 | **13** |
| uncovered-weight-dropped | 9 | **9** |
| plan-part-by-weight | 1 | **1** |
| plan-placed-by-weight | 1 | **1** |
| cebypmo-float-split | 1 | **2** (D and F) |
| cebypmo-own-rounding | 1 | **1** |
| tab-portions-float-split | 2 | **3** (D twice and F) |
| deck-rollup-float-split | 1 | **2** (D and F) |
| deck-own-rounding | 1 | **1** |
| weights-first-clin | 2 | **2** |
| office-ranks-by-last-clin | 2 | **2** |
| the 7 new entries (above) | — | **1, 1, 1, 1, 1, 1, 2** |

Every run exits 1, so every mutant is caught. These counts are the same as the tests verifier's `ppm-*` runs on p1.

**mcount**, text only, `python3 -I`: c1 has 1349 of 1349 entries found exactly once; base has 1328 of 1328. None are missing,
multiple or unparsed (`out/r2-mcount-c1.txt`, `out/r2-mcount-base.txt`). Every existing entry still matches exactly once.

### Every place the PMO split reaches, and what reads it now (supersedes round 1's "read by" column)

| surface | where in c1 | read by (block 1: A, B, C; block 2: D–G) |
|---|---|---|
| PMO funding panel (`#pmBody`) | `pmoMatrix()` | A, B (each service, TOTAL, B's MC); **F (the whole row, MC included)** |
| forecast by PMO, in the app and exported (`exportFcView`) | `forecast()` → `pmoPartsOf` | A, B; C (control); E; **G** |
| Two-Plan Forecast, BY PMO rows (plans A and B) | `exportExcel`, `fcBlock` | D |
| PMO Matrix sheet | `exportExcel` | A, B (B: TOTAL and ★ columns); D; E; **F (TOTAL Disc/Mand, ★ MC requirement, ★ MC short); G** |
| CE by PMO sheet | `exportExcel` | D (Ask, Disc, Mand, Unfunded); **F (Ask, ★ MC requirement, ★ MC short, Unfunded)** |
| each office's PMO tab: the obligation report row | `obligBlock` | A, B |
| each office's PMO tab: rows by portion | `exportExcel`, the portions loop | D (Disc, Mand); **F (MC memo, Unfunded)** |
| CR view by PMO | `crBuckets(…,'pmo')` | A, B |
| deck, Funding by PMO slide | `exportPPT`, the PMO rollup | D (Ask, Disc, Mand, Unfunded); **F (Unfunded, ★ MC req, ★ MC short)** |

Every surface is now read on at least one case whose parts are not shared evenly, and each of the eight cells the tests
verifier found unpinned is now held by board F.

### Case P, measured here (observe only)

`probe/exports-r2.from-money-verifier.mjs` is a byte-identical copy of `verify-money-r2/probe/exports-r2.mjs` (blob
7be41f12), which I read before running it. It observes and compares; it changes nothing.

- `exp2-c1` (11:12:22 AM ET, exit 0, 15.2 s): 0 differences. On case P, the PMO Matrix, CE by PMO, the deck, the panel
  and the forecast give MxS 1 / AV 3 / TSS 0. The workbook's sheets end "PMO AV | PMO MxS", so there is no `PMO TSS` tab.
  The Spend Plan Source's CLIN lines are 0010 $1 and 0002 $3.
- `exp2-base` (11:12:38 AM ET, exit 0, 15.7 s): 11 differences, all on the by-office views. On case P the base gives
  1 / 2 / 1 and writes a `PMO TSS` tab. Its Spend Plan Source gives the same 0010 $1 and 0002 $3.
- So on the base, the by-office views gave TSS a dollar that the CLIN source file did not.
- The exact split is .4 for AV and .4 for TSS, and the tie goes to AV, the earlier office. So c1 is right, and the draft now
  says that TSS loses its tab.
- **Data loss check:** no data is lost. The tab is not written because TSS's part is $0, and the requirement's whole $4 is on
  the MxS and AV tabs, as on the CLIN lines.
- Board A's office totals move by $3, $2, −$3 and −$2 (MxS 167,291,651 → 167,291,654; AV 433,958,318 → 433,958,320; TSS
  648,750,044 → 648,750,041; PRIMES 9 → 7; `r2f-base`). So the draft now says "dollars".

### Other suites and checks, before and after (this round)

| suite / check | base (7ee498a) | c1 now |
|---|---|---|
| boot-same | identical either way (`s-r2base-boot-same`, 42.0 s) | identical either way (`s-r2c1-boot-same`, 47.1 s) |
| audit-recon (owns both U9 blocks) | ALL CHECKS PASSED (370.5 s) | ALL CHECKS PASSED (417.3 s) |
| audit, audit-ppt, audit-other (they hold the PMO exports' totals) | pass (the build's base runs; the base files have not changed) | ALL CHECKS PASSED (`s-r2c1-audit`, `-audit-ppt`, `-audit-other`) |
| legacy-fsrc, audit-inject, audit-hostile | pass (the build's base runs) | pass (`s-r2c1-legacy-fsrc`: "every legacy Force setting computes exactly as before"; `-audit-inject`, `-audit-hostile`: ALL CHECKS PASSED) |
| npm run check (scratch clone `gitclone/` at 7ee498a; c1's three files copied in, then restored) | all checks passed (`check-r2-base`) | all checks passed (`check-r2-c1`) |
| money-map --check | holds: 329 cells, 0 open, report current | the same |

- **Restore:** `git checkout --` of the three files, under `setsid -w timeout -k 10 600`, with its PID recorded. It ran at
  11:11:33 AM ET with exit 0. The clone is back at fce8a391 / 529e36f7 / cbc6defc, and `git status` lists only the
  untracked `node_modules` link it had before.
- **None of the other suites reads audit-recon or mutate.mjs** (grep: audit-other names audit-recon only in a comment). So
  this round's change cannot move them. They were re-run on c1 anyway.
- **Not re-run:**
  - the focused audit-board PRIME-3 harness and the in-region sweep. Their inputs (the board, audit-board, audit) are
    byte-identical to the build's (33/33 on both boards). The tests verifier re-ran them on these blobs at 9:44 AM ET:
    33/33 on both.
  - the base runs of audit, audit-ppt, audit-other, legacy-fsrc, audit-hostile and audit-inject. The base has not changed.

### How this round meets each decision principle

1. **Never lose any copy of anyone's work.** The board is unchanged, and its change is still a read-only computation. Before
   I changed anything, I kept round 1's copy in `superseded/c1-r1/`, its drafts in `drafts/superseded-r1/` and its README
   in `superseded/README.r1.md`. I edited none of the verifiers' files: their proposals were copied out, and their probe
   was run from my own byte-identical copy. On the board side, case P drops a tab only for an office whose part is $0, and
   no dollar or record is lost.
2. **Refuse or ask rather than guess.**
   - The two-lane and CLIN-line questions stay with Brad, as in round 1 (`drafts/LEDGER-new-row.md`, unchanged).
   - The month-sheet sentence is outside U9's diff. I confirmed it is false, but I did not change it. It goes to the lead as
     drafted ledger text, rather than being silently widened into this commit.
   - Board F has no Spend Plan Source check, as the verifiers wrote it, because USAF there draws from both lanes, which is
     the open two-lane question. On the same draw without ANG (the money verifier's case Q, `exp2-c1`), the CLIN lines are
     $2 / $2 / $2, the same as the offices' funded dollars. Board G's CLIN lines are pinned, as a CONTROL.
3. **Money and every export match the computation exactly.**
   - Every column that carries an office's part is now held to hand-written dollars, including on a case where the part is
     not shared evenly. That covers the panel's MC column, the PMO Matrix's ★ columns, the tabs' MC memo and Unfunded
     rows, CE by PMO's ★ and Unfunded columns and the deck's.
   - The weights are held at budget size, on an exact tie that fraction × total gets wrong.
   - All 21 mutants are caught, and c1's suite on the base board fails exactly the 51 non-control U9 checks.
4. **Every word the board says stays true.** The board's words do not change. Round 1's claim, "every export that carries
   the PMO parts is now held to the dollar", was not true; it is withdrawn and marked SUPERSEDED below. The drafts now say
   which board is read on which view. "What users may see" now names both ways a tab can change, and says "dollars". The
   month-sheet sentence was false before U9 and is still false. U9 does not touch it, and it is drafted for the lead.
5. **The smallest change that closes the finding.** There is no board change. The suite gains 76 lines (6 checks on board
   F, 4 on board G, 9 comment lines) inside the existing block. Mutate gains 7 entries. Every code line is the verifiers'
   tested p1, byte for byte.
6. **Every existing check, fixture and expected value is preserved.**
   - Against round 1, audit-recon and mutate only add lines (+76/−0, +25/−0).
   - Against base, they only add lines too (+399/−0, +71/−0).
   - Every other file is byte-identical.
   - No existing check's expectation changed, so there is nothing to list.

### Decisions, with reasons

- **I took p1, not a board of my own.** The must-fix names a tested minimal fix, and its literals re-derive exactly
  (`fix2/exact-r2.py`). Its mutants are the survivors, byte for byte. Writing a different board for the same cells would add
  review cost and add no coverage.
- **I took the money verifier's board F and the tests verifier's addition together.** The money verifier's F alone misses
  `panel-mc-own-rounding`, `matrix-mcs-own-rounding` and `frac-times-tot` (verify-tests-r2, `mf-*`). Here F and G catch all
  three.
- **I rewrote two comments in the house voice.** The committed suite and mutate should not carry "proposed by the … verifier,
  round 2". The code and every entry's id, area, what, find and repl are unchanged.
- **The block's name line and markers are unchanged.** The name ("… an office with two CLINs") no longer lists everything
  the block reads. But it is what the scenario-ran guard and the mutation entries' comments ("v2.00 (U9, every export) —
  ...") refer to, and the header paragraph now names F and G. Renaming it would touch round 1's lines for no change in what
  is held.
- **Month-sheet sentence: not fixed here.** It is board text outside U9's diff, identical on the base, and about the CLIN
  split, not the PMO split. Changing it would widen this commit and need its own check. So it is drafted for the lead.

### For the lead: a ledger note on the month-sheet sentence (pre-existing; not part of this commit)

Suggested text for a new row (the lead assigns its number):

> **The workbook's month sheets misstate how CLIN rows are rounded.** The note under each month sheet's PRIMES section
> (`exportExcel`; c1 line 30396, base 30387) says "The last CLIN takes the rounding in every column, so the CLIN rows add to
> the prime exactly." Since v1.95, `clinSplit` (lines 23485–23491) splits a whole-dollar amount by `apportion()`: largest
> remainder, equal remainders to the EARLIER CLIN. The last CLIN takes the remainder only for an amount that is not whole
> dollars, such as a modelled plan's. At $3 over CLINs asking 1 : 2 : 3, the first CLIN, 0010, takes the leftover dollar
> (U9 block A's Spend Plan Source CONTROL: 0010 = $1). The rows still add to the prime exactly; only the sentence is wrong.
> Found by the U9 money verifier, round 2 (13 Oct). Identical before and after U9. P3 (words), not fixed.

### Runs this round (every one through `run.sh`)

Every run used `setsid -w timeout -k 10 600`. BOARD and MUT_FIRST_FAIL were unset unless given. The AUDIT_IMPORT_RUNNING
lock was checked before every run. It was absent every time, so no run waited or was skipped. Times are ET on 13 Oct. The
logs are in `logs/`, and `logs/runs.txt` holds one line per run after "# FIX ROUND 2".

| # | label | start | exit | wall s | log |
|---|---|---|---|---|---|
| 1 | r2-syntax (`node --check` of the harness) | 10:32:59 | 0 | 0.1 | logs/r2-syntax.log |
| 2 | r2f-c1 | 10:32:59 | 0 | 7.3 | logs/r2f-c1.log |
| 3 | r2f-base | 10:33:06 | 1 | 9.4 | logs/r2f-base.log |
| 4 | r2fm-v200-u9-split-by-fraction | 10:33:53 | 1 | 13.0 | logs/r2fm-v200-u9-split-by-fraction.log |
| 5 | r2fm-v200-u9-weights-are-fractions | 10:34:06 | 1 | 12.5 | logs/r2fm-v200-u9-weights-are-fractions.log |
| 6 | r2fm-v200-u9-per-part-rounding | 10:34:19 | 1 | 12.2 | logs/r2fm-v200-u9-per-part-rounding.log |
| 7 | r2fm-v200-u9-ties-by-name | 10:34:31 | 1 | 11.0 | logs/r2fm-v200-u9-ties-by-name.log |
| 8 | r2fm-v200-u9-uncovered-weight-dropped | 10:34:43 | 1 | 10.6 | logs/r2fm-v200-u9-uncovered-weight-dropped.log |
| 9 | r2fm-v200-u9-plan-part-by-weight | 10:34:53 | 1 | 18.8 | logs/r2fm-v200-u9-plan-part-by-weight.log |
| 10 | r2fm-v200-u9-plan-placed-by-weight | 10:35:12 | 1 | 20.3 | logs/r2fm-v200-u9-plan-placed-by-weight.log |
| 11 | r2fm-v200-u9-cebypmo-float-split | 10:35:33 | 1 | 22.6 | logs/r2fm-v200-u9-cebypmo-float-split.log |
| 12 | r2fm-v200-u9-cebypmo-own-rounding | 10:35:56 | 1 | 27.5 | logs/r2fm-v200-u9-cebypmo-own-rounding.log |
| 13 | r2fm-v200-u9-tab-portions-float-split | 10:36:23 | 1 | 32.9 | logs/r2fm-v200-u9-tab-portions-float-split.log |
| 14 | r2fm-v200-u9-deck-rollup-float-split | 10:36:56 | 1 | 37.2 | logs/r2fm-v200-u9-deck-rollup-float-split.log |
| 15 | r2fm-v200-u9-deck-own-rounding | 10:37:39 | 1 | 32.8 | logs/r2fm-v200-u9-deck-own-rounding.log |
| 16 | r2fm-v200-u9-weights-first-clin | 10:38:12 | 1 | 39.4 | logs/r2fm-v200-u9-weights-first-clin.log |
| 17 | r2fm-v200-u9-office-ranks-by-last-clin | 10:38:52 | 1 | 43.0 | logs/r2fm-v200-u9-office-ranks-by-last-clin.log |
| 18 | r2fm-v200-u9-tab-memo-float-split | 10:39:35 | 1 | 40.5 | logs/r2fm-v200-u9-tab-memo-float-split.log |
| 19 | r2fm-v200-u9-tab-unf-float-split | 10:40:16 | 1 | 39.0 | logs/r2fm-v200-u9-tab-unf-float-split.log |
| 20 | r2fm-v200-u9-deck-mc-float-split | 10:40:55 | 1 | 49.6 | logs/r2fm-v200-u9-deck-mc-float-split.log |
| 21 | r2fm-v200-u9-cebypmo-mcs-float-split | 10:41:45 | 1 | 50.3 | logs/r2fm-v200-u9-cebypmo-mcs-float-split.log |
| 22 | r2fm-v200-u9-matrix-mcs-own-rounding | 10:42:36 | 1 | 43.7 | logs/r2fm-v200-u9-matrix-mcs-own-rounding.log |
| 23 | r2fm-v200-u9-panel-mc-own-rounding | 10:43:19 | 1 | 37.2 | logs/r2fm-v200-u9-panel-mc-own-rounding.log |
| 24 | r2fm-v200-u9-weights-frac-times-tot | 10:43:57 | 1 | 36.6 | logs/r2fm-v200-u9-weights-frac-times-tot.log |
| 25 | s-r2base-boot-same | 10:44:56 | 0 | 42.0 | logs/s-r2base-boot-same.log |
| 26 | s-r2base-audit-recon | 10:45:38 | 0 | 370.5 | logs/s-r2base-audit-recon.log |
| 27 | s-r2c1-audit-recon | 10:51:58 | 0 | 417.3 | logs/s-r2c1-audit-recon.log |
| 28 | s-r2c1suite-baseboard-audit-recon (BOARD = base) | 10:59:02 | 1 | 406.9 | logs/s-r2c1suite-baseboard-audit-recon.log |
| 29 | s-r2c1-boot-same | 11:06:13 | 0 | 47.1 | logs/s-r2c1-boot-same.log |
| 30 | s-r2c1-audit | 11:07:00 | 0 | 48.3 | logs/s-r2c1-audit.log |
| 31 | s-r2c1-audit-ppt | 11:07:48 | 0 | 25.3 | logs/s-r2c1-audit-ppt.log |
| 32 | s-r2c1-audit-other | 11:08:18 | 0 | 149.2 | logs/s-r2c1-audit-other.log |
| 33 | check-r2-base (`npm run check`, scratch clone) | 11:11:02 | 0 | 14.7 | logs/check-r2-base.log |
| 34 | moneymap-r2-base | 11:11:16 | 0 | 0.8 | logs/moneymap-r2-base.log |
| 35 | check-r2-c1 | 11:11:17 | 0 | 14.6 | logs/check-r2-c1.log |
| 36 | moneymap-r2-c1 | 11:11:32 | 0 | 0.7 | logs/moneymap-r2-c1.log |
| 37 | exp2-c1 (case P/Q probe, observe only) | 11:12:22 | 0 | 15.2 | logs/exp2-c1.log |
| 38 | exp2-base | 11:12:38 | 0 | 15.7 | logs/exp2-base.log |
| 39 | s-r2c1-legacy-fsrc | 11:14:24 | 0 | 19.2 | logs/s-r2c1-legacy-fsrc.log |
| 40 | s-r2c1-audit-inject | 11:14:43 | 0 | 54.3 | logs/s-r2c1-audit-inject.log |
| 41 | s-r2c1-audit-hostile | 11:15:37 | 0 | 215.2 | logs/s-r2c1-audit-hostile.log |

- **What exit 1 means.** On `r2f-base`, `r2fm-*` and `s-r2c1suite-baseboard-audit-recon`, exit 1 means failing checks were
  found, as intended: the defect, or a mutant caught. It does not mean a crash.
- **The mutant loops.** The two loops of runs 4–24 (`fix2/mutloop.sh`, 11 then 10 mutants) were each started under
  `setsid -w timeout -k 10 600`, with their PIDs recorded as `r2fm-loop-1` and `r2fm-loop-2`. Both exited 0.
- **PIDs.** `pids.txt`, from the line "# FIX ROUND 2", holds 85 PIDs:
  - the timeout PID and its child for each of the 41 runs;
  - the two loop PIDs;
  - the clone restore.
- **PID reuse.** At 11:19 AM ET none of my processes was alive. Two recorded numbers had been reused by other sessions'
  processes after my runs ended: 683, the timeout of run 6, and 3350, the node of run 11. Both of my runs had finished with
  exit records. **Nothing was killed.**
- **Python helpers.** `mkmut.py`, `mcount.py`, `mkfocused-u9-r1.py` and the `fix2/*.py` helpers are text-only Python, run
  with `python3 -I`. They start no node or Chromium process, so they record no PID, as in earlier rounds.
- **A blocked command.** One shell command of mine was refused by the session's safety check before it ran: an `rm` of my own
  `diffs/r2/*` before rewriting them. Nothing was removed. The two files there were overwritten in place instead.

### Files added this round

| path | what | blob |
|---|---|---|
| `fix2/block-fg.mjs.txt` | the inserted boards F and G, as inserted | 42326c70 |
| `fix2/header-fg.txt` | the header's F and G paragraphs | 2fe5ffda |
| `fix2/mutate-entries.txt` | the 7 entries, as inserted | 1fb49993 |
| `fix2/assemble-block.py`, `fix2/assemble-entries.py`, `fix2/edit-r2.py` | how they were put together and inserted (each anchor matched once, asserted) | bdfba58a, 37955d42, 6348ddaa |
| `fix2/exact-r2.py` | F and G re-derived with exact fractions | 6c6e32ae |
| `fix2/mutloop.sh`, `fix2/ids.txt` | the mutant loop and the 21 ids | d9fc4fb1, 57cca821 |
| `harness/r2/focused-u9.mjs` | the focused harness (verbatim from c1) | 31315c7f |
| `probe/exports-r2.from-money-verifier.mjs` | a copy of the money verifier's probe, for cases P and Q | 7be41f12 |
| `mut/r2/*.html` | the 21 mutants, disposable (blobs in `out/r2-mutant-blobs.txt`) | |
| `diffs/r2/` | the diffs | see above |
| `superseded/c1-r1/`, `superseded/README.r1.md`, `drafts/superseded-r1/` | round 1's copy, README and drafts, kept | README 13b973ae |
| `drafts/` | NEXT-VERSION and ledger append rewritten; the Unresolved line and the new row unchanged | NEXT-VERSION c5b48d46, ledger append 6c0b87ef, Unresolved line e7e9b2ae, new row ffb0f916 |

### Drafts (for the lead; nothing applied)

Anchors were re-read at orbit-board HEAD 21b6dea and again at 68c9fe1, 11:24 AM ET (records only since 7ee498a; no product or `tools/` file changed). NEXT-VERSION.md
is blob 65265c13 and UNRESOLVED-LEDGER.md is 8112ad0b.

- **`drafts/NEXT-VERSION-U9.md`** (c5b48d46): insert after U14's entry, which ends "…what "genuine stored plans" takes
  in).", at line 777, before "- **Unresolved after R1–R5 (11 Oct).**" (line 778). This round changes three parts of it:
  - "What users may see": every column that carries an office's part; an office can gain or lose its PMO tab (case P);
    "dollars".
  - "Test": 24 checks in block 2; which board is read on which view; 51 fail on the base; 38 controls.
  - "Mutations": 21 ids and their counts.
- **`drafts/UNRESOLVED-line-U9.md`** (e7e9b2ae, unchanged): replaces lines 792–793, the bullet "  - **U9 (P2): PMO split
  disagreement.**". It names the views where the split now agrees, not the tests, so nothing in it changed.
- **`drafts/LEDGER-U9-append.md`** (6c0b87ef): append to the U9 row's last column (the row runs from line 20 to line 30, which ends "Not fixed;
  awaiting Brad |"), before its closing ` |`. Fill in `<sha>` and `<time>`. Its blobs and counts are now 755647cc /
  8fd34e94, 89 checks, 51 failing, 38 controls, 21 mutations, mcount 1349/1349. "Read on every view above" became "each
  read on the views NEXT-VERSION names".
- **`drafts/LEDGER-new-row.md`** (ffb0f916, unchanged): the two-lane and CLIN-line row for Brad.
- **The month-sheet note** (above): a separate row for the lead to log. It is not part of this commit.

### What I did not do (this round)

- I did not change the board. There is no product change in this round, and none since the build.
- I did not fix the month-sheet sentence. It is drafted for the lead.
- I did not cite the new blocks in the money-map catalogue (`tools/money-map.json` and its generated `.md`).
- I did not run full audit-import or audit-board; those are the lead's. I did not re-run the focused audit-board harness or
  the in-region sweep, because their inputs are unchanged.
- I did not re-run the six other suites on the base, because the base is unchanged.
- I did not run the full mutate sweep, validate:math, verify:grid or Playwright. mutate.mjs was never imported or run; it was
  read as text only.
- I did not edit NEXT-VERSION.md or the ledger in any copy. I did not touch `/home/user/orbit-board` or `/home/user/orbit-ui`
  beyond reading them, or the verifiers' directories beyond reading and copying from them.
- I made no commit and pushed nothing.

### Appendix: round 2 against p1 (`diff verify-tests-r2/p1/… c1/…`)

```
audit-recon.mjs:
5350a5351,5357  (header: boards F and G)
> // BOARD F, the same CLINs at 1 : 2 : 3, starred: USAF asks $9 and draws $3 discretionary and $3 mandatory, ANG asks $3 and
> //   draws nothing. Its unfunded and ★ figures are not shared evenly (ANG's $3 short is .5 / 1 / 1.5), so they are read
> //   where they print: the panel's MC column, the PMO Matrix's ★ columns, each PMO tab's MC memo and Unfunded rows, CE by
> //   PMO's ★ and Unfunded columns and the deck's: asks 3 / 4 / 5, unfunded 1 / 2 / 3, ★ MC short 2 / 3 / 4.
> // BOARD G, an exact tie at budget size: USAF draws $779,153,421, exactly half of CLIN asks 881,836,554 / 575,398,923 /
> //   101,071,365, so AV's and TSS's parts both end in .5 and the dollar is AV's = 440,918,277 / 287,699,462 / 50,535,682,
> //   as the Spend Plan Source's CLIN lines give it (CONTROL). Weights rebuilt from the fractions give it to TSS.
5352a5360,5361  (header: F and G on the base)
> // F's offices asked 1 / 4 / 7 there, with unfunded 0 / 2 / 4 (no Unfunded row on MxS's tab) and ★ MC short 1 / 3 / 5,
> // and G was 440,918,277 / 287,699,461 / 50,535,683.
5474,5476c5483,5485  (the comment that named the proposer)
<     // v2.00 (U9, every export; proposed by the tests verifier, round 2): board F read on the PMO Matrix and the panel too. Its
<     // offices' ★ figures are not shared evenly ($3 of ANG at 1 : 2 : 3 is .5 / 1 / 1.5), so an office's ★ MC short rounded
<     // on its own reads MxS 2 / AV 3 / TSS 5 there, where its part is 2 / 3 / 4.
---
>     // board F on the PMO Matrix and the panel too. Its offices' ★ figures are not shared evenly ($3 of ANG at 1 : 2 : 3 is
>     // .5 / 1 / 1.5), so an office's ★ MC short rounded on its own reads MxS 2 / AV 3 / TSS 5 there, where its part is
>     // 2 / 3 / 4.
mutate.mjs.txt:
4334,4335c4334,4337  (one comment in the house voice in place of two that named the proposers)
<   // v2.00 (U9, every export; proposed by the money verifier, round 2): each PMO tab's MC memo and Unfunded rows, the deck's
<   // ★ MC req column and CE by PMO's ★ MC short carry the same parts (audit-recon "v2.00 (U9, every export) — ...", board F).
---
>   // v2.00 (U9, every export): the figures by office that are not shared evenly carry the same parts too -- each PMO tab's
>   // MC memo and Unfunded rows, CE by PMO's ★ MC short, the deck's ★ MC req, the PMO Matrix's ★ MC short and the panel's MC
>   // column -- and the offices weigh their CLIN asks themselves, not fractions times the total (audit-recon
>   // "v2.00 (U9, every export) — ...", boards F and G).
4348,4349d4349
<   // v2.00 (U9, every export; proposed by the tests verifier, round 2): the PMO Matrix's ★ MC short and the panel's MC column
<   // carry the same parts, and the offices weigh their CLIN asks themselves (audit-recon "v2.00 (U9, every export) — ...", boards F and G).
```

The full round-2 diff is `diffs/r2/c1-vs-c1r1.diff` (blob ab7b8667, +101/−0).

---

## Fix round 1 (13 Oct): earlier result — SUPERSEDED IN PART by Fix round 2

**Superseded by Fix round 2:**

- The audit-recon and mutate blobs (2fb4b7ad / 3f7d8311 are now 755647cc / 8fd34e94).
- The counts. Checks go from 79 to 89, failing on the base from 44 to 51, controls from 35 to 38, mutation entries
  from 14 to 21 and mcount from 1342 to 1349. Seven mutants' failing counts rise (see Fix round 2).
- The "read by" column of the surface table.
- The drafts' anchor for UNRESOLVED-LEDGER.md: it is now blob 8112ad0b, and NEXT-VERSION.md is still 65265c13.
- The claim, here and in the round-1 summary, that "every export that carries the PMO parts is now held to the
  dollar". **It was not true:** the panel's MC column, the PMO Matrix's ★ MC short, the PMO tabs' MC memo and
  Unfunded rows, CE by PMO's ★ MC short and Unfunded, and the deck's Unfunded and ★ columns were pinned by no check.
  Fix round 2 pins them.

Everything else below stands as written.

Written 13 Oct 2026 from 4:46 AM ET and finished at 4:48 AM ET (`TZ=America/New_York date`). This round's first run started at 4:15:31 AM ET and its
last at 4:43:57 AM ET. Two independent verifiers reviewed the build: `verify-money-r1` (lens A, data loss and money) and
`verify-tests-r1` (lens B, test adequacy). Each found one must-fix. This round fixes both must-fixes and every should-fix,
plus three of the minors. **The board does not change.** The fix is tests and text only.

**Nothing from a stopped attempt of this round was found.** The task said an earlier attempt might have been stopped at about
12:50 AM ET. I searched this directory for anything changed after 11:13 PM ET on 12 Oct. The only such files were the two
verifiers' own directories and an index refresh in `gitclone/.git`, timed 11:41 PM ET: the clone was still clean at 7ee498a.
There was no "Fix round" section, no changed copy and no new probe or log of mine. So nothing was kept from a stopped attempt;
this round started fresh at 4:15 AM ET.

### The commit now proposed (one commit; cumulative copy `c1/`)

| file | base blob (7ee498a) | build's c1 (12 Oct, kept in `superseded/c1-build/`) | **c1 now** |
|---|---|---|---|
| prioritization-board-grid.html | fce8a391 | 46e522a8 | **46e522a8370f05971c8ef0558c3c666b0953b0ac** (unchanged) |
| tools/export-audit/audit-recon.mjs | 529e36f7 | 19fd2a3d | **2fb4b7adb898f37ede4873d58a67784b215211de** |
| tools/export-audit/mutate.mjs (as mutate.mjs.txt) | cbc6defc | 1208ae45 | **3f7d8311ce034463f7ec47f43f067638f6493547** |
| everything else | | unchanged | unchanged (`diff -rq` against base lists only these three) |

Proposed subject (unchanged): `v2.00 U9: the PMO split is exact, ties to the first office, and the same on every by-office view`

Diffs:

- `diffs/r1/c1-vs-base.diff` (blob 2c17d1ef). By file: board c89b763d, identical to the build's board diff;
  audit-recon a7ae8738; mutate c709ad51.
- `diffs/r1/c1-vs-c1build.diff` (blob 36e368c2): this round's own change. By file: audit-recon 55750d44; mutate 3d6a9e24;
  board empty.
- Against base, the audit-recon and mutate diffs only add lines, 0 removed.
- The full fix-round diff is in the appendix at the end of this README.

### What the verifiers found, and what I did

| finding | from | rating | what I did |
|---|---|---|---|
| The drafts omit a fully funded case that shows $0/$1/$2 on the mandatory lane: $6 at 1:2:3 drawn $3 + $3. They also say "each office's whole dollars are split by its own CLIN asks", which is not the two-stage rule | money | must-fix | Measured it myself (`div3`). Added it to all five texts with its numbers. Corrected the sentence. Stated the choice Brad faces. **The board is unchanged.** See "The two-lane case" |
| Three exports that carry PMO parts are pinned by no test: CE by PMO, the deck's Funding by PMO and the PMO tabs by portion. The Two-Plan Forecast's BY PMO rows were not read either. Five mutants survived every suite | tests (must-fix) and money (should-fix) | must-fix | New block "v2.00 (U9, every export)", board D. Literals at $3, at $9 and on the mandatory lane, read on all four exports and the PMO Matrix. Five mutation entries, each caught |
| The tie rule "an office ranks by its first CLIN; its weight is its CLINs' asks added up" is pinned by no check. Mutants for last-CLIN ranking and first-CLIN weight survived | money and tests | should-fix | Board E, from the tests verifier's design: AV holds two CLINs, MxS holds two, and the PMO Matrix and the forecast must read 1/1/1. Two entries. The money verifier's own last-CLIN mutant is caught too. I did not pin the money verifier's case F as a CONTROL; see Decisions |
| The README's surface table is wrong in two rows, and the summary names "the ACE roll-up" | tests | should-fix | Corrected below. The build's table is kept and marked SUPERSEDED |
| "What users may see" is incomplete, and an office whose share was $0 had no PMO tab | tests | should-fix | Every moving view is named. The tab was measured myself (`tabz`): base has no `PMO MxS` tab, c1 has it |
| "No total changes" is not true of an office's totals | money | minor | Now "an office's own totals move by the dollars that moved; no requirement, service or board total changes" |
| The mandatory-only tie has no literal of its own | money | minor | Board D's AFRC is $3, every dollar mandatory, at 1:2:3. It is read on the PMO Matrix, CE by PMO, the PMO tabs' Mand portion row and the deck. It gives 1/1/1, and 0/1/2 on the base |
| Board B's expected totals are sums worked in the test | tests | minor (its text was cut off in the relay) | B's office totals are now written out as literals (`dT`, `mT`, `fT`, `uT`). A new CONTROL ties them to the per-service literals. Details under "Changed in the build's block" |
| The money-map catalogue does not cite the new blocks | money | minor | **Not done.** It is a shared file every track touches (`tools/money-map.json` plus the generated `.md`). The map holds without it (`moneymap-r1-c1`). Left to the lead |
| Two build mutants are caught only by CONTROL checks (plan-part-by-weight, plan-placed-by-weight) | tests | minor, "acceptable" | No change. Board C is a CONTROL by design: those figures did not move |

### The two-lane case (the money must-fix), measured here

`probe/divergence3.mjs` (blob 9513af5f) is the build's divergence probe plus X1 and X2. It observes only. Runs `div3-base` and
`div3-c1` started at 4:15 AM ET, both exit 0, and the outputs are identical on both boards:

| case | by-office (panel, forecast, PMO Matrix), Disc + Mand | Spend Plan Source CLIN lines |
|---|---|---|
| X1: $6 at 1:2:3 over 0010 / 0002 / 0008, drawn $3 discretionary + $3 mandatory (fully funded, one CLIN per office) | MxS 1+0, AV 1+1, TSS 1+2: totals 1/2/3, so the mandatory lane reads 0/1/2 | 0010 $2, 0002 $2, 0008 $2, two $1 lines each. CLIN 0010 asks $1 |
| X2: $10 at 1:2:3, $5 + $5 | MxS 1+1, AV 2+1, TSS 2+3: totals 2/3/5 | 0010 $2, 0002 $4, 0008 $4 |
| D1 to D4 (the build's) | unchanged from `div2` | unchanged |

**Why this is not the U9 defect.** The board splits the ask exactly: $6 at 1:2:3 is 1/2/3. The discretionary $3 is split by
those parts, with the tie to MxS, giving 1/1/1. The mandatory $3 is then what each office still has to take, 0/1/2. That is
the v1.95 two-stage rule, unchanged and exact. The Spend Plan Source splits each lane by the CLINs on its own, 1/1/1 and
1/1/1. Under that rule CLIN 0010, which asks $1, carries $2.

**Brad's choice:**

- **Per lane, as the Spend Plan Source does.** By office, $6 comes out 2/2/2, and an office or a CLIN can carry more than its
  share of the ask.
- **The two-stage rule, as the by-office views do.** By office it stays 1/2/3, and no office carries more than its share. A
  lane can read $0/$1/$2.

I did not change either (principle 2). The drafts now say this with the numbers.

### Tests: what changed in audit-recon

**New block** `// ==== v2.00 (U9, every export): …` / `// ==== end v2.00 (U9, every export) ====`, inserted after the U9
block (`fix1/block-u9-exports.mjs.txt`, blob 58b6f635, 116 lines).

- **House shape:** the async wrapper, `bootMark()` / `bootRelease(__bm, [])` / `settleBoards()`, the two-space
  `  const name = '…';` line and the two markers. "v2.00 (R1)" and "v2.00 (R1, Brad's decisions of 11 Oct)" are the
  precedent for a track with two blocks.
- **Why a separate block:** the U9 block's three boards are released before D and E boot. Under load the verifier saw two
  audit-recon runs killed from outside, most likely for memory.
- **Every expected figure is a hand-written literal.** Board helpers give only observed values.

| board | case | read on | expected | base gave |
|---|---|---|---|---|
| D (CLINs 0010 / 0002 / 0008 at 1:2:3 on every service; cost elements on) | USAF $3 disc, ANG $9 disc, AFRC $3 **mandatory only** | PMO Matrix, each service Disc and Mand | MxS [1,0] [2,0] [0,1]; AV [1,0] [3,0] [0,1]; TSS [1,0] [4,0] [0,1] | MxS [0,0] [1,0] [0,0]; AV [1,0] [3,0] [0,1]; TSS [2,0] [5,0] [0,2] |
| D | the same | CE by PMO: Ask, Disc portion, Mand portion, Unfunded | MxS 4/3/1/0, AV 5/4/1/0, TSS 6/5/1/0 | 1/1/0/0, 5/4/1/0, 9/7/2/0 |
| D | the same | each PMO tab, PRIME-3's Disc portion row (amount, USAF, ANG, AFRC) | MxS 3,1,2,0; AV 4,1,3,0; TSS 5,1,4,0 | 1,0,1,0; 4,1,3,0; 7,2,5,0 |
| D | the same | each PMO tab, the Mand portion row | 1,0,0,1 each | MxS no row; AV 1,0,0,1; TSS 2,0,0,2 |
| D | the same | Two-Plan Forecast BY PMO TOTAL, whole dollars, plans A and B | MxS 3,4; AV 4,5; TSS 5,6 | 1,1; 4,5; 7,9 |
| D | the same | deck, Funding by PMO: Ask, Discretionary, Mandatory, Unfunded, as printed | $4 $3 $1 —; $5 $4 $1 —; $6 $5 $1 — | $1 $1 $0 —; $5 $4 $1 —; $9 $7 $2 — |
| D | CONTROLs | fixture; the rule (literals add up); workbook with CE by PMO and three PMO tabs; Spend Plan Source 0010 $4, 0002 $5, 0008 $6 | pass on both | pass |
| E (USAF $3 over 0002 [1], 0010 [1], 0102 [1], 0008 [3], 0110 [0]) | AV weighs 2, MxS 1, TSS 3; ranked AV, MxS, TSS by first CLIN; the MxS/TSS tie is MxS's | PMO Matrix USAF Disc; the forecast | AV 1 / MxS 1 / TSS 1 | 1 / 0 / 2 |
| E | CONTROLs | fixture (all five CLINs, in order); Spend Plan Source 0002, 0010, 0008 at $1 each | pass on both | pass |

#### Changed in the build's own (uncommitted) U9 block

This is the "Board B totals" minor, done with `fix1/edit-b-totals.py`. Each replacement had to match exactly once.

- `B` gains `dT`, `mT`, `fT` and `uT` per office:
  - TSS 20 / 1 / 21 / 0
  - AV 37 / 1 / 38 / 1
  - MxS 54 / 1 / 55 / 2
  - PRIMES 7 / 0 / 7 / 0
- Six expected expressions read those literals instead of `sum(B[g].d)` and `sum(B[g].m)`. The compared values are the
  same numbers.
- One CONTROL is added: "B · the rule — each office's totals, as written, are its parts added up…".
- So the block is now 65 checks (29 controls).
- These lines exist only in this commit, not in the base, so no committed check, fixture or expected value changed.

#### Runs of the focused harness

The harness is `harness/r1/focused-u9.mjs` (blob c16385ba). It was built by `bin/mkfocused-u9-r1.py`, which is
`mkfocused-u9.py` plus the two-line `w5Dol` helper the new block reads. Every line but line 1 (the header naming the source)
is in c1's audit-recon verbatim (checked).

| run | board | checks | passed | failed | controls passed | non-controls failed |
|---|---|---|---|---|---|---|
| r1f-base (4:21:58 AM ET, exit 1, 12.2 s) | fce8a391 | 79 | 35 | 44 | 35/35 | **44/44** |
| r1f-c1 (4:21:36 AM ET, exit 0, 14.1 s) | 46e522a8 | 79 | 79 | 0 | 35/35 | 0/44 |

**Full audit-recon:**

- With c1's suite on c1: ALL CHECKS PASSED (`s-r1c1-audit-recon`, 129.8 s).
- With c1's suite on the **base board**, BOARD set (`s-r1c1suite-baseboard-audit-recon`, exit 1, 284.9 s): **exactly 44
  failing checks.** All are in the two U9 blocks; nothing else in audit-recon fails.

### Mutations (`fix1/mutate-entries.txt`, blob d4e01c6f; 7 entries inserted after the build's 7, before the R3 line)

Each mutant was built from c1's mutate text by `mkmut.py`, and each find matches exactly once. Each was run through the
focused harness (`fix1/mutloop.sh`, `out/r1fm-summary.txt`). The build's 7 were re-run on the new harness too.

| id | what | failing checks | caught by |
|---|---|---|---|
| v200-u9-cebypmo-float-split | CE by PMO splits each lane itself by the fractions | 1 | D · CE by PMO |
| v200-u9-cebypmo-own-rounding | CE by PMO rounds fraction × draw ($4 of $3) | 1 | D · CE by PMO (TSS Disc 7) |
| v200-u9-tab-portions-float-split | the PMO tabs' portion rows split by the fractions | 2 | D · the PMO tabs by portion, Disc and Mand |
| v200-u9-deck-rollup-float-split | the deck's Funding by PMO splits by the fractions | 1 | D · the deck |
| v200-u9-deck-own-rounding | the deck rounds fraction × draw | 1 | D · the deck (TSS $7) |
| v200-u9-weights-first-clin | an office weighs its first CLIN only | 2 | E · the PMO Matrix, E · the forecast |
| v200-u9-office-ranks-by-last-clin | an office ranks by its last CLIN | 2 | E · the PMO Matrix, E · the forecast |
| (the build's) split-by-fraction, weights-are-fractions, per-part-rounding, ties-by-name, uncovered-weight-dropped, plan-part-by-weight, plan-placed-by-weight | | 44, 44, 35, 13, 9, 1, 1 | as before, plus the new block where it moves |

- **The new mutants match the verifiers' survivors byte for byte.** Their blobs are 0ab4aa64, 63a6899c, 9bb76ffd, ba6255d5,
  46174ea3, 56cf57f4 and 22061919. The `weights-first-clin` entry repeats `pmoSharesOf`'s own CLIN-number
  rule, which names PRIME-3 itself.
- **The money verifier's own last-CLIN mutant** (`verify-money-r1/mut/own-office-by-last-clin.html`, blob 7efa7613) is
  caught by E, with 2 failing (`r1fm-vm-own-office-by-last-clin`).
- **mcount**, text only, `python3 -I`: c1 has 1342 of 1342 entries found exactly once; base has 1328 of 1328. None are
  missing, multiple or unparsed (`out/r1-mcount-*.txt`).

### Every place the PMO split reaches (corrected; supersedes the build's surface table)

| surface | where in c1 | read by |
|---|---|---|
| PMO funding panel (`#pmBody`) | `pmoMatrix()` | U9 block A, B |
| forecast by PMO, in the app and exported (`exportFcView`) | `forecast()` → `pmoPartsOf` | U9 block A, B, C; E |
| Two-Plan Forecast, BY PMO rows (plans A and B) | `exportExcel`, `fcBlock` → `forecast(fcFrom(plan))` (about line 29903) | **D (new)** |
| PMO Matrix sheet | `exportExcel`, the PMO x service matrix | U9 block A, B; D, E |
| CE by PMO sheet (cost elements on) | `exportExcel`, about line 30457 | **D (new)** |
| each office's PMO tab: the obligation report row | `obligBlock` | U9 block A, B |
| each office's PMO tab: rows by portion (Disc, MC memo, Mand) | `exportExcel`, the portions loop, about line 30638 | **D (new)**, Disc and Mand. The MC memo row is not read |
| CR view by PMO | `crBuckets(…,'pmo')` | U9 block A, B |
| deck, Funding by PMO slide | `exportPPT`, the PMO rollup, about line 25091 | **D (new)** |

**Corrected from the build's table:**

- Line 25082 is the deck's Funding by PMO slide, not "the ACE / CE-by-PMO roll-up".
- The ACE tie-out's Reconciliation by PMO (about line 29423) groups by each requirement's own office (`r.pmo`) and never
  reads `pmoPartsOf`. I read it here. The build summary's "the ACE roll-up" was wrong.
- The existing audit and audit-ppt checks on these exports compare totals only, and they pass on the base.

### Other suites and checks, before and after (this round)

| suite | base (7ee498a) | c1 now |
|---|---|---|
| boot-same | identical either way (`s-r1base-boot-same`) | identical either way |
| audit-recon | ALL CHECKS PASSED (164.7 s) | ALL CHECKS PASSED (129.8 s), both U9 blocks |
| audit, audit-ppt, audit-other, legacy-fsrc, audit-hostile, audit-inject | pass (the build's base runs, 12 Oct; the base files have not changed) | pass (`s-r1c1-*`, this round) |
| npm run check (scratch clone at 7ee498a; c1's three files copied in, then restored with `git checkout --`) | all checks passed | all checks passed |
| money-map --check | holds, 329 cells, 0 open, report current | the same |

The focused audit-board PRIME-3 harness and the sweep of the 8 existing in-region mutation entries were not re-run. Their
inputs, the board and the suites they read (audit-board and audit), are byte-identical to the build's, so the build's results
(33/33 on both boards; caught exactly as on base) still hold.

### How this round meets each decision principle

1. **Never lose a copy of anyone's work.** The board is unchanged, and its change is still a read-only computation. Nothing
   of mine was overwritten without a kept copy: the build's c1 is in `superseded/c1-build/`, its drafts are in
   `drafts/superseded-build/` and its README is in `superseded/README.build.md`. I edited none of the verifiers' files.
2. **Refuse or ask rather than guess.**
   - The two-lane case is measured and handed to Brad, with both readings. It is not "fixed" either way.
   - I did not pin the money verifier's tie case F in the suite. Measured (`tief-*`): the by-office split gives MxS the
     dollar, but the Spend Plan Source's CLIN line 0002 gives it to AV. Pinning F would freeze one side of the open D1
     question.
   - Board E pins the same first-CLIN rule where both sides agree, and E's CONTROL proves that agreement.
3. **Money and every export match the computation exactly.**
   - Every export that carries PMO parts is now held to hand-written dollars: the four new ones and the five already read.
     **SUPERSEDED: not every column was; see Fix round 2.**
   - That includes the mandatory lane's own tie, and an office holding two CLINs.
   - The copy's suite fails exactly those 44 checks on the base board, and nothing else.
4. **Every word the board says stays true.** The board's words do not change. The drafts and this README are corrected:
   - X1 and X2 are added.
   - The two-stage rule is stated.
   - Every moving view is named.
   - "No total changes" is narrowed.
   - The ACE claim is removed.
5. **The smallest change.** There is no board change. The suite change is one 116-line block, one CONTROL, and B's literal
   totals. The mutate change is 7 entries.
6. **Every existing check, fixture and expected value preserved.**
   - Against base, audit-recon and mutate only add lines.
   - Every other suite file is byte-identical.
   - Every suite passes on c1 as on base.
   - The only lines edited are in this commit's own uncommitted U9 block (B's totals), listed above.

### Decisions, with reasons

- **The tests verifier's addendum was adapted, not taken whole.** I kept its board E design and its five mutants, which are
  byte-identical, and I widened board D:
  - $9 is in, as the money verifier asked.
  - The mandatory lane is in, as the money verifier's minor asked.
  - The Mand portion row is read.
  - The deck's Unfunded column is read.
  - The PMO Matrix is read on D.
  - The Two-Plan Forecast is read through the suite's own `w5Dol`, which refuses a figure that is not whole dollars, rather
    than `Math.round`.
  - The two own-rounding survivors became entries too: the task names per-part rounding.
- **The block is named "v2.00 (U9, every export)", not "addendum".** That name says what it covers in the committed suite.
- **No board change for X1.** Both verifiers rated the product change sound, and the money verifier said to ask, not change.
  The two-stage rule is v1.95's, and existing checks (W7 F4) rely on it.

### Runs this round (every one through `run.sh`)

Each run used `setsid -w timeout -k 10 600`. BOARD and MUT_FIRST_FAIL were unset unless given. The AUDIT_IMPORT_RUNNING lock
was checked before each run. It was absent every time, so no run waited or was skipped. Times are ET on 13 Oct.

| # | label | start | exit | wall s | log |
|---|---|---|---|---|---|
| 1 | div3-base | 04:15:31 | 0 | 3.1 | logs/div3-base.log |
| 2 | div3-c1 | 04:15:34 | 0 | 3.7 | logs/div3-c1.log |
| 3 | r1-syntax (`node --check` of the harness) | 04:21:35 | 0 | 0.2 | logs/r1-syntax.log |
| 4 | r1f-c1 | 04:21:36 | 0 | 14.1 | logs/r1f-c1.log |
| 5 | r1f-base | 04:21:58 | 1 | 12.2 | logs/r1f-base.log |
| 6 | r1fm-v200-u9-cebypmo-float-split | 04:23:32 | 1 | 10.0 | logs/r1fm-v200-u9-cebypmo-float-split.log |
| 7 | r1fm-v200-u9-cebypmo-own-rounding | 04:23:42 | 1 | 8.7 | logs/r1fm-v200-u9-cebypmo-own-rounding.log |
| 8 | r1fm-v200-u9-deck-own-rounding | 04:23:51 | 1 | 11.5 | logs/r1fm-v200-u9-deck-own-rounding.log |
| 9 | r1fm-v200-u9-deck-rollup-float-split | 04:24:02 | 1 | 13.6 | logs/r1fm-v200-u9-deck-rollup-float-split.log |
| 10 | r1fm-v200-u9-office-ranks-by-last-clin | 04:24:16 | 1 | 17.6 | logs/r1fm-v200-u9-office-ranks-by-last-clin.log |
| 11 | r1fm-v200-u9-per-part-rounding | 04:24:34 | 1 | 15.5 | logs/r1fm-v200-u9-per-part-rounding.log |
| 12 | r1fm-v200-u9-plan-part-by-weight | 04:24:49 | 1 | 13.1 | logs/r1fm-v200-u9-plan-part-by-weight.log |
| 13 | r1fm-v200-u9-plan-placed-by-weight | 04:25:03 | 1 | 13.5 | logs/r1fm-v200-u9-plan-placed-by-weight.log |
| 14 | r1fm-v200-u9-split-by-fraction | 04:25:16 | 1 | 14.4 | logs/r1fm-v200-u9-split-by-fraction.log |
| 15 | r1fm-v200-u9-tab-portions-float-split | 04:25:31 | 1 | 13.3 | logs/r1fm-v200-u9-tab-portions-float-split.log |
| 16 | r1fm-v200-u9-ties-by-name | 04:25:44 | 1 | 14.0 | logs/r1fm-v200-u9-ties-by-name.log |
| 17 | r1fm-v200-u9-uncovered-weight-dropped | 04:25:58 | 1 | 12.4 | logs/r1fm-v200-u9-uncovered-weight-dropped.log |
| 18 | r1fm-v200-u9-weights-are-fractions | 04:26:11 | 1 | 11.5 | logs/r1fm-v200-u9-weights-are-fractions.log |
| 19 | r1fm-v200-u9-weights-first-clin | 04:26:23 | 1 | 12.9 | logs/r1fm-v200-u9-weights-first-clin.log |
| 20 | s-r1c1-boot-same | 04:27:33 | 0 | 20.6 | logs/s-r1c1-boot-same.log |
| 21 | s-r1c1-audit | 04:27:54 | 0 | 19.9 | logs/s-r1c1-audit.log |
| 22 | s-r1c1-audit-ppt | 04:28:14 | 0 | 7.2 | logs/s-r1c1-audit-ppt.log |
| 23 | s-r1c1-audit-other | 04:28:21 | 0 | 34.8 | logs/s-r1c1-audit-other.log |
| 24 | s-r1c1-audit-recon | 04:29:01 | 0 | 129.8 | logs/s-r1c1-audit-recon.log |
| 25 | s-r1c1-legacy-fsrc | 04:31:16 | 0 | 6.1 | logs/s-r1c1-legacy-fsrc.log |
| 26 | s-r1c1-audit-hostile | 04:31:22 | 0 | 78.8 | logs/s-r1c1-audit-hostile.log |
| 27 | s-r1c1-audit-inject | 04:32:41 | 0 | 17.2 | logs/s-r1c1-audit-inject.log |
| 28 | s-r1base-boot-same | 04:33:05 | 0 | 14.8 | logs/s-r1base-boot-same.log |
| 29 | s-r1base-audit-recon | 04:33:19 | 0 | 164.7 | logs/s-r1base-audit-recon.log |
| 30 | s-r1c1suite-baseboard-audit-recon (BOARD = base) | 04:36:08 | 1 | 284.9 | logs/s-r1c1suite-baseboard-audit-recon.log |
| 31 | check-r1-base | 04:41:11 | 0 | 12.3 | logs/check-r1-base.log |
| 32 | moneymap-r1-base | 04:41:23 | 0 | 0.7 | logs/moneymap-r1-base.log |
| 33 | check-r1-c1 | 04:41:24 | 0 | 11.7 | logs/check-r1-c1.log |
| 34 | moneymap-r1-c1 | 04:41:36 | 0 | 0.5 | logs/moneymap-r1-c1.log |
| 35 | r1fm-vm-own-office-by-last-clin (the money verifier's mutant) | 04:42:00 | 1 | 30.8 | logs/r1fm-vm-own-office-by-last-clin.log |
| 36 | tief-c1 | 04:42:41 | 0 | 9.3 | logs/tief-c1.log |
| 37 | tief-base | 04:42:51 | 0 | 7.8 | logs/tief-base.log |
| 38 | tabz-base | 04:43:49 | 0 | 7.3 | logs/tabz-base.log |
| 39 | tabz-c1 | 04:43:57 | 0 | 7.0 | logs/tabz-c1.log |

Exit 1 on `r1f-base`, `r1fm-*` and `s-r1c1suite-baseboard-audit-recon` means failing checks were found, as intended: the
defect, or a mutant caught. It does not mean a crash.

- **Restore:** the scratch clone was restored by `git checkout --` of the three files, under `setsid -w timeout -k 10 600`,
  with its PID recorded. It ran at 4:41:42 AM ET, exit 0, and the clone is clean at 7ee498a again.
- **PIDs:** `pids.txt` from the line `# FIX ROUND 1` holds 79 PIDs: the timeout PID and its child for each of the 39 runs,
  plus the restore. At 4:45:30 AM ET none was alive. Nothing was killed.
- **A script that never ran:** I wrote a background chain script (`fix1/chain-r1.sh`) and deleted it unrun. Its one line,
  "chain-r1 launched", was removed from `logs/runs.txt`. The suites were run instead one call at a time, so that every
  command stayed under its own 600 s cap.
- **Python helpers:** `mkmut.py`, `mcount.py`, the insert helpers and `mkfocused-u9-r1.py` are text-only Python, run with
  `python3 -I`. They start no node or Chromium process, so they record no PID, as in the build.

### Files added this round

| path | what | blob |
|---|---|---|
| `fix1/block-u9-exports.mjs.txt` | the new block, as inserted | 58b6f635 |
| `fix1/mutate-entries.txt` | the 7 new entries, as inserted | d4e01c6f |
| `fix1/edit-b-totals.py` | B's literal totals (one match each, asserted) | 73814c38 |
| `fix1/mutloop.sh` | the mutant loop | b3a20ef8 |
| `bin/mkfocused-u9-r1.py`, `harness/r1/focused-u9.mjs` | the harness builder and the harness | 2168af7b, c16385ba |
| `probe/divergence3.mjs`, `probe/tie-f.mjs`, `probe/tabs-zero.mjs` | observe-only probes: X1/X2, case F, the $0 office's tab | 9513af5f, 23d3e44e, 76ce1808 |
| `mut/r1/*.html` | the 14 mutants, disposable | blobs above |
| `diffs/r1/` | the diffs | blobs above |
| `drafts/` | the four drafts, rewritten; the build's are in `drafts/superseded-build/` | NEXT-VERSION 10074445, Unresolved line e7e9b2ae, ledger append 0e561ad6, new row ffb0f916 |
| `superseded/c1-build/`, `superseded/README.build.md` | the build's copy and README, kept | 8b777c54 (README) |

### Drafts (for the lead; nothing applied)

They are anchored as before. HEAD is now cadc4aa (records only), and NEXT-VERSION.md is still blob 65265c13 and
UNRESOLVED-LEDGER.md still 1bcad628.

- **`drafts/NEXT-VERSION-U9.md`:** insert after U14's entry, which ends "…what "genuine stored plans" takes in).", at line
  777, before "- **Unresolved after R1–R5 (11 Oct).**".
- **`drafts/UNRESOLVED-line-U9.md`:** replaces lines 792–793, the bullet "  - **U9 (P2): PMO split disagreement.**". Keep
  "Both U9 and U10 were reproduced …" unless U10's track replaces it.
- **`drafts/LEDGER-U9-append.md`:** append to the U9 row's last column (from line 20), before its closing ` |`. Fill in
  `<sha>` and `<time>`.
- **`drafts/LEDGER-new-row.md`:** the new row, now with X1, X2 and case F, and Brad's choice spelled out. The lead assigns
  its number.

### What I did not do (this round)

- I did not change the board. There is no product change in this round.
- I did not run full audit-import or audit-board; those are the lead's. I did not re-run the focused audit-board harness or
  the in-region sweep, because their inputs are unchanged.
- I did not run the full mutate sweep, validate:math, verify:grid or Playwright. mutate.mjs was never imported or run; it was
  read as text only.
- I did not cite the new blocks in the money-map catalogue (see the table above).
- I did not edit NEXT-VERSION.md or the ledger in any copy. I did not touch `/home/user/orbit-board` or `/home/user/orbit-ui`
  beyond reading them, or the verifiers' directories beyond reading them.
- I made no commit and pushed nothing.

---

# The build (12 Oct): earlier results, kept

Everything below is the build's README as it was at 7:50 PM ET on 12 Oct. Where Fix round 1 supersedes it, it says so.


Track U9 (ledger row U9, P2, MONEY). The relayed user request was "How much longer". This README was written 12 Oct 2026,
from 7:48 PM ET; finished at 7:50 PM ET (`TZ=America/New_York date`). The earlier builder for this track was stopped at about 6:16 PM ET by a usage
limit. This attempt resumed from that work at 7:31 PM ET.

## Result (build, 12 Oct) — SUPERSEDED IN PART by Fix round 1: the audit-recon and mutate blobs, the check, control and mutation counts, and "every by-office surface" (it holds for a service drawn from one lane; see the two-lane case)

**One commit is proposed.** Its cumulative copy is `c1/` (base `../base` plus this commit). Nothing was committed, staged or
pushed, and nothing in `/home/user/orbit-board` or `/home/user/orbit-ui` was edited.

| file | base blob (7ee498a) | c1 blob |
|---|---|---|
| prioritization-board-grid.html | fce8a391bd8a248d5185e199d22190c1687eaea0 | **46e522a8370f05971c8ef0558c3c666b0953b0ac** |
| tools/export-audit/audit-recon.mjs | 529e36f7c20e635b2722ea53b6a4f44b4ed328af | **19fd2a3d9fe0c64515d91a964234af430141dc1e** |
| tools/export-audit/mutate.mjs (as mutate.mjs.txt) | cbc6defc6803851e847844848fc9b186daeeb268 | **1208ae4534ccfa9508c20cf42c71acbee3c6f5c3** |
| everything else (audit, audit-other, audit-board, audit-import, boot.mjs, package.json, NEXT-VERSION.md, the shim) | unchanged | unchanged (`diff -rq` lists only the three files above) |

Proposed subject: `v2.00 U9: the PMO split is exact, ties to the first office, and the same on every by-office view`

- **Before (base fce8a391):** at $3 split 1:2:3 (MxS, AV, TSS), the PMO funding panel, the forecast and the PMO Matrix give
  $0/$1/$2. At $9 they give $1/$3/$5. Measured again here (`repro2-base`: 67 passed, 8 failed, every failure a defect check
  and none a control).
- **After (c1 46e522a8):** $1/$1/$1 and $2/$3/$4 on every by-office surface, the same as exact largest remainder and the
  CLIN source workbook (`repro2-c1`: 75 passed, 0 failed).
- **New suite block:** audit-recon `v2.00 (U9)`, 64 checks. On the base board 36 fail, and those 36 are exactly the
  non-control checks. All 28 controls pass on both boards. On c1 all 64 pass.
- **Mutations:** 7 new entries, each caught (36, 36, 29, 13, 9, 1 and 1 failing checks). The 8 existing entries whose find
  lies in the changed region are caught on c1 by the same suite and the same first check as on base. mcount (text):
  1335/1335 once on c1 and 1328/1328 on base.
- **Other suites on c1, all as on base:** boot-same, audit, audit-ppt, audit-other, audit-recon, legacy-fsrc, audit-hostile
  and audit-inject pass. `npm run check` passes and `money-map --check` holds. A focused audit-board harness, built verbatim
  from the two scenarios that split PRIME-3 between offices, passes 33/33 on both boards.

## What I kept from the earlier attempt, and what I re-ran

- **Kept after re-checking:**
  - **The board change.** The c1 board is the earlier builder's (mtime 6:03 PM ET, blob 46e522a8). I read the diff line by
    line against the base (`diffs/c1-vs-base.board.diff`) and checked every reader of `pmoSharesOf` (see "Every place").
  - **The 7 mutation entries.** I rebuilt each mutant from the c1 text with `mkmut.py`. Each blob is identical to the
    earlier builder's mutant.
  - **The block's expected literals.** I re-derived every literal in exact Python integers (`check/lr.py`). All of them
    agree.
  - **The focused-harness builder.** I regenerated the harness from c1's suite and confirmed it is verbatim: only the header
    line naming the source path differs.
  - **These earlier logs, each finished with an exit record:**
    - the base suites: boot-same, audit, audit-ppt, audit-other, audit-recon and legacy-fsrc, at 6:14 to 6:16 PM ET
    - the base reproduction `repro-base`
    - the divergence probes
- **Changed:** the U9 block. I added each office's PMO tab (an export that carries PMO parts) and the CR view by PMO, one
  check per board each, and updated the block's comments to match. The block went from 60 to 64 checks. I added the tab
  checks per office first, but B's AV row is the same on the base board, so they are folded into one check per board, like
  the block's other checks.
- **Re-run:**
  - on the final blobs: the focused harness on base and c1, all 7 mutants, the c1 suites and mcount
  - `s-base-audit-hostile`, whose log had no exit record (re-run as `s-base2-audit-hostile`)
  - `audit-inject` on base, which the earlier builder never ran
  - the reproduction and divergence probes, on both boards
- **New in this attempt:**
  - sweeps of the 8 existing in-region mutation entries, on c1 and on base
  - a focused audit-board harness
  - `npm run check` and `money-map --check` in a scratch clone
  - the drafts and this README
- **Superseded:** the earlier builder's `f-*` and `fm-*` runs were on the 60-check block. They are kept as history in
  `logs/` and `out/`. `diffs/c1-vs-base.earlier-before-resume.diff` is the earlier diff. The earlier harness is kept as
  `harness/c1/focused-u9.earlier-3cab7a90.mjs`.

## The finding, reproduced on the base

Fixture (the review's): USAF, O&M FY27, PRIME-3 marked PRIME, $3 discretionary. CLINs 0010, 0002 and 0008 ask 1, 2 and 3,
which the board's CLIN-number rule makes MxS, AV and TSS.

`probe/repro-u9.mjs` copies the evidence probe and adds hand-written literals and the on-screen panel as a fourth surface.
It reports:

- **base:** $0/$1/$2 at $3 and $1/$3/$5 at $9, on the PMO parts, the forecast, the PMO panel and the PMO Matrix export
  (8 failures)
- **base, controls:** the Spend Plan Source's CLIN lines read $1/$1/$1 and $2/$3/$4; the non-tie controls ($5, $7 and others)
  pass; every total balances
- **c1:** every check passes

**Cause.** `pmoSharesOf` gives each office a FRACTION of each service: `v/tot[i]`, in floating point. `pmoPartsOf` passed those
fractions to `apportion()` as the weights for whole dollars. `apportion()` reads each weight exactly as the double it is, and
1/6 = 0.1666…6 and 2/6 = 0.333…3 are not exactly 1 : 2 : 3. So the tied remainders were not equal, and the tie went to TSS.

## Every place the PMO split is computed or exported

There is one computation: `pmoSharesOf` (the shares) feeding `pmoPartsOf` (whole dollars, through `pmoSplit` and
`apportion`). Every by-office figure reads `pmoPartsOf`:

| surface | where in the board | how it is covered |
|---|---|---|
| PMO funding panel (`#pmBody`) | `pmoMatrix()` | block, every cell |
| forecast by PMO, in the app and exported (`exportFcView`) | `forecast()` → `bump()` → `o.land` | block |
| Two-Plan Forecast sheet, BY PMO | `forecast(fcFrom(plan))` | the same code (not a separate check) — SUPERSEDED: now read by Fix round 1's board D |
| PMO Matrix sheet | the workbook builder, at the "PMO x service matrix" | block, every cell |
| PMO tabs, by portion and the obligation report | `obligBlock`, the portions loop | block, each office's report row — SUPERSEDED, an overclaim: the block read only the report row; the rows by portion are now read by board D |
| CR view by PMO | `crBuckets(…,'pmo')` | block |
| the ACE / CE-by-PMO roll-up | the roll-up at about line 25082 | the same code (existing audit checks) — SUPERSEDED, WRONG: line 25082 is the deck's Funding by PMO slide; CE by PMO is in exportExcel (about line 30457); the ACE tie-out does not read pmoPartsOf; the existing checks compare totals only. See Fix round 1's surface table |

The other readers of `pmoSharesOf` read only the office name (`SHARES[id]` in the workbook builder) or the fraction as a
which-services factor (`forecast`'s `vf`, `pmoMatrix`'s count). The third entry is invisible to them. No Help or other
user-facing text describes the split rule (grep of the board).

## The rule, and its tie rule

The CLIN source workbook is the Spend Plan Source. It splits by `srcRowsOf` → `clinSplit(pid, i, amt)` → `apportion(amt, per)`.
`apportion()` (v1.99 item 85) works exactly in BigInt:

- floor every share
- hand the leftover dollars to the largest remainders, using the sort
  `(a.r<b.r)? 1 : (a.r>b.r)? -1 : (a.i-b.i)`
- **equal remainders go to the earlier index**, which for `clinSplit` means the earlier CLIN in the CLIN list

The PMO split now uses the same `apportion()` over integer weights. Each weight is the office's own CLIN asks on that service,
added up (`bag[g][i]`). The offices are in `pmoSharesOf`'s order, `Object.keys(bag)`: insertion order, so **an office ranks
by its first CLIN in the list**. The requirement's own office comes last when it holds no CLIN.

Block B proves the order: the CLIN list puts 0008 (TSS) first, so the tie goes to TSS, where the office list and the
alphabet would not put it.

## The change (board)

`diffs/c1-vs-base.board.diff`, exact:

```diff
@@ -11434,6 +11434,12 @@
       if(row) gap.forEach((v,i)=>{ if(v) row[1][i]=1; });
       else out.push([own, gap]);
     }
+    // v2.00 (U9): AND THE WEIGHTS THEMSELVES, third: each office's own CLIN asks on a service the CLINs cover, and on one
+    // they do not, its fraction (1 for the requirement's own office, 0 for the rest). apportion() splits by these; the
+    // fractions only scale an amount that is not whole dollars. Split by the fractions, a tie went to the wrong office:
+    // 1/6, 2/6 and 3/6 in floating point are not exactly 1 : 2 : 3, so $3 at 1 : 2 : 3 was $0/$1/$2 on the panel, the
+    // forecast and the PMO Matrix, where the exact rule -- and the CLIN source workbook -- gives $1/$1/$1.
+    out.forEach(r=>r.push(r[1].map((f,i)=>(tot[i]>0 && bag[r[0]])? bag[r[0]][i] : f)));
     return out.length? out : [[grpOf(it),null]];
@@ -11463,16 +11469,19 @@ function pmoPartsOf(it, p){
-  const wOf=i=> sh.map(function(x){ return x[1]? (+x[1][i]||0) : 1; });
+  // v2.00 (U9): wOf is what apportion() splits by -- the offices' own CLIN asks (pmoSharesOf's third entry), exact --
+  // and fOf the fraction an amount that is not whole dollars is scaled by
+  const wOf=i=> sh.map(function(x){ return x[2]? (+x[2][i]||0) : x[1]? (+x[1][i]||0) : 1; });
+  const fOf=i=> sh.map(function(x){ return x[1]? (+x[1][i]||0) : 1; });
-    const a=+((it.ask||[])[i])||0, d=lane(i,'d'), m=lane(i,'m'), w=wOf(i);
+    const a=+((it.ask||[])[i])||0, d=lane(i,'d'), m=lane(i,'m'), w=wOf(i), fr=fOf(i);
-    } else P.forEach(function(o,k){ const f=one? 1 : w[k];
+    } else P.forEach(function(o,k){ const f=one? 1 : fr[k];
@@ -11484,7 +11493,7 @@
-      return (memo[key]=w.map(function(f){ return landSvc(aw, i, d, m, literal, f); }));
+      return (memo[key]=fOf(i).map(function(f){ return landSvc(aw, i, d, m, literal, f); }));
```

What changed, by case:

- **A service no CLIN covers:** the weight is the old fraction (1 for the requirement's own office, 0 for the others), so
  nothing changes there.
- **An amount that is not whole dollars** (a modelled plan): it is still scaled and placed by the fraction (`fOf`), as
  before.
- **Whole dollars:** the only figures that move are those where the fractions' rounding decided a tie or a near tie.

## How the change meets each decision principle (build; see Fix round 1 for the round's own)

1. **Never lose any copy of anyone's work.** Nothing is saved, loaded or overwritten differently. The change is in a read-only
   computation.
2. **Refuse or ask rather than guess.** The tie rule is not invented. It is the CLIN source workbook's, read from
   `apportion()` and `clinSplit`. The cases where the by-office split and the Spend Plan Source still differ (below) are
   measured and handed to Brad, not "fixed" by a guess.
3. **Money and every export match the computation exactly.** [SUPERSEDED in part: CE by PMO, the PMO tabs by portion, the Two-Plan Forecast and the deck were not checked at the build; Fix round 1 checks them.] The panel, the forecast (in the app and exported), the PMO Matrix,
   the PMO tabs and the CR view by PMO now agree to the dollar, with hand-written literals, at $3, $9, $999,999,999,
   $250,000,000 and four offices. Every part still adds up to its total; the block's "the rule" controls show it.
4. **Every word stays true.** No user-facing text describes the split. The two comments added are true of the new code, and
   the v1.95 comment above `pmoSplit` ("apportion() -- the board's one spreading rule") is now true without exception.
5. **The smallest change.** One line in `pmoSharesOf` and four in `pmoPartsOf`. No surface's code changed.
6. **Every existing check, fixture and expected value preserved.** No existing check, fixture or expected value was edited.
   Every allowed suite passes unchanged on c1, and so do the two audit-board PRIME-3 scenarios (focused, verbatim). Full
   audit-board and audit-import are the lead's. The 8 existing mutation entries in the region are caught exactly as on base.

## Tests: the audit-recon block `v2.00 (U9)` (build: 64 checks; Fix round 1 makes it 65 and adds the 14-check block "v2.00 (U9, every export)")

The block is in `diffs/c1-vs-base.audit-recon.diff` (also `work/block-u9.mjs.txt`). It follows the v2.00 blocks:

- `await (async () => {` … `})();`
- `bootMark()` / `bootRelease(__bm, [])` / `settleBoards()`, as U14's block does
- the two-space `  const name = '…';` line
- the `// ==== v2.00 (U9) …` and `// ==== end v2.00 (U9) ====` markers

It is placed after U14's block. audit-recon owns this because its v1.95 W7 F4 block ("an office's share of a CLIN-split
requirement is whole dollars, the same on every surface") reads the PMO Matrix, the PMO tabs, the forecast and the CR view by
PMO cell by cell, and it holds the `w5Chk` and `w6Book` helpers. audit.mjs checks only that PMO rows add up, which held with
the defect. audit-other has no PMO checks.

Every expected value is a hand-written literal, re-derived in `check/lr.py`:

| board | case | expected | base gave |
|---|---|---|---|
| A (CLINs 0010, 0002, 0008, 0001: MxS, AV, TSS, PRIMES) | USAF $3 at 1:2:3 | 1/1/1/0 | 0/1/2 |
| A | ANG $9 at 1:2:3 | 2/3/4/0 | 1/3/5 |
| A | AFRC $999,999,999 at 1:2:3 | 166,666,667 / 333,333,333 / 499,999,999 | 166,666,666 / 333,333,333 / 500,000,000 |
| A | STOVL $250,000,000 at 1,499,958 : 241,499,956 : 357,000,087 (remainders 299,375,018 / 299,375,019 / 1,249,964; not a tie) | 624,982 / 100,624,982 / 148,750,036 | 624,983 / 100,624,981 / 148,750,036 |
| A | USMC-C $3 at 1:1:1:3 (four offices) | 1/1/0/1 | 1/0/0/2 |
| A | USN $3 at 1:0:2:3 (a zero share) | 1/0/1/1 | 0/0/1/2 |
| A | CV $5, no CLIN covers it | 0/0/0/5 (CONTROL) | the same |
| B (CLINs 0008, 0002, 0010: TSS, AV, MxS; starred) | USAF $3 at 1:2:3 | 1/1/1 (the tie is TSS's) | 0/1/2 |
| B | ANG $5 | 1/2/2 (CONTROL) | the same |
| B | AFRC $9 asked, $3 discretionary, $3 mandatory, $3 unfunded | disc 1/1/1, mand 1/1/1, unf 0/1/2 | disc 0/1/2 |
| B | STOVL $7, uncovered | PRIMES (CONTROL) | the same |
| B | USMC-C $100 | 17/33/50 (CONTROL) | the same |
| C | a modelled plan's $10.50 at 1:2:3 | $1.75 / $3.50 / $5.25, placed and as parts (CONTROL) | the same |

Each case is read:

- on the panel as drawn
- in the forecast: each service alone, the whole portfolio and the exported view
- in the PMO Matrix, read back from the workbook's bytes
- in each office's PMO tab
- in the CR view by PMO
- as a control, in the Spend Plan Source's CLIN lines

Runs (focused harness `harness/c1/focused-u9.mjs`, blob 8d9c140f, built verbatim by `bin/mkfocused-u9.py`, run by
`bin/runner.mjs`):

| run | board | checks | passed | failed | controls passed | non-controls failed |
|---|---|---|---|---|---|---|
| f3-base | fce8a391 | 64 | 28 | 36 | 28/28 | 36/36 |
| f3-c1 | 46e522a8 | 64 | 64 | 0 | 28/28 | 0/36 |

## Mutations (`diffs/c1-vs-base.mutate.diff`) (build: 7 entries; Fix round 1 adds 7 and re-runs all 14 on the new harness)

The 7 entries are inserted before the R3 line. Each find matches its board exactly once (mcount). Each mutant was built by
`mkmut.py` from c1's text and run through the focused harness (`out/fm3-summary.txt`):

| id | failing checks | caught by |
|---|---|---|
| v200-u9-split-by-fraction | 36 | every defect check |
| v200-u9-weights-are-fractions | 36 | every defect check |
| v200-u9-per-part-rounding | 29 | the panel, the PMO Matrix, the forecast and the tabs; 3 controls |
| v200-u9-ties-by-name | 13 | all of B; C's order |
| v200-u9-uncovered-weight-dropped | 9 | the CV controls and every office total |
| v200-u9-plan-part-by-weight | 1 | C · each office's part of a modelled plan (CONTROL) |
| v200-u9-plan-placed-by-weight | 1 | C · the forecast of a modelled plan (CONTROL) |

**Existing entries whose find is in the changed region** (`bin/finds-in-region.py`): `pmo-residual`, `pmo-frac`,
`excel-unf-vec`, `w7-office-share-fraction`, `w7-office-split-by-weight`, `w7-office-months-fraction`, `w7-office-ask-whole`
and `w7-office-mcs-unfunded-only`.

`mutsweep.sh` swept each through the allowed suites in mutate.mjs's order (board and import are the lead's). On c1 each is
caught by `audit` with the same first failing check as on base (`out/sweep-c1.txt` and `out/sweep-base.txt` are identical).

`pmo-frac` (the fractions scaled by 1/1.1) is still caught on c1 through audit's "AV: MC subtotal == share" check. Its
expectation reads the fractions; the parts never depended on their scale.

## Other suites, before and after

| suite | base | c1 |
|---|---|---|
| boot-same | pass (s-base, 9.5 s) | pass (9.3 s) |
| audit | ALL CHECKS PASSED | ALL CHECKS PASSED |
| audit-ppt | ALL CHECKS PASSED | ALL CHECKS PASSED |
| audit-other | ALL CHECKS PASSED | ALL CHECKS PASSED |
| audit-recon | ALL CHECKS PASSED (89 s) | ALL CHECKS PASSED (103 s), with the U9 block |
| legacy-fsrc | pass | pass |
| audit-hostile | ALL CHECKS PASSED (s-base2) | ALL CHECKS PASSED |
| audit-inject | ALL CHECKS PASSED (s-base2) | ALL CHECKS PASSED |
| npm run check (scratch clone at 7ee498a; c1's three files copied over) | all checks passed | all checks passed |
| money-map --check | holds, 0 open, report current | the same |
| audit-board: "v1.93 — the forecast by PMO…" and "v1.94 — CR half-months by PMO…", focused and verbatim (`bin/mkfocused-board.py`) | 33/33 | 33/33 |

## Not covered: still open, measured, for Brad (proposed new ledger row) — SUPERSEDED IN PART: this list was incomplete; it left out a fully funded service drawn from both lanes (X1, X2). See Fix round 1's "The two-lane case" and the rewritten `drafts/LEDGER-new-row.md`

After U9, the by-office split and the CLIN source workbook use the same exact rule, but they do not split the same amounts:

- **The Spend Plan Source** splits each lane, and each dated line, by CLIN on its own. It uses the working CLIN list and the
  CLIN grid (`clinList`, `clinVec`).
- **The by-office split** works from the requirement's ask, then splits each lane by what each office still has to take. It
  uses the CLINs as shipped (`DATA.clins`).

`probe/divergence.mjs` is observe-only (USAF, PRIME-3 alone). It gives identical results on fce8a391 and 46e522a8 (`div2-*`),
so U9 neither causes nor changes any of these:

| case | by-office (panel, forecast, PMO Matrix) | Spend Plan Source CLIN lines, by office |
|---|---|---|
| D1: two CLINs on one office, $2 at 1:1:1 over 0010, 0110, 0002 | MxS 1, AV 1 | MxS 2, AV 0 |
| D2: part funded, $50 of $100 at 1:2:3 | 9 / 16 / 25 | 8 / 17 / 25 |
| D3: CLIN 0008 at 3 added on the board beside shipped 0010 at 1 and 0002 at 2, $6 | MxS 2, AV 4, no TSS | MxS 1, AV 2, TSS 3 |
| D4: increments of $1 (Dec) and $2 (Mar) at 1:1:1 | 1 / 1 / 1 | 2 / 1 / 0 |

Every total balances. Which figure is an office's money where they differ, and whether the by-office split should read the
CLIN list as edited, is Brad's decision. No fix is proposed. The proposed row is `drafts/LEDGER-new-row.md`.

## Drafts (for the lead; nothing applied) — SUPERSEDED: rewritten in Fix round 1; the build's texts are in `drafts/superseded-build/`

Anchored on HEAD 60336a0: NEXT-VERSION.md blob 65265c13 (the same as the base) and UNRESOLVED-LEDGER.md blob 1bcad628.

- **NEXT-VERSION.md, under v2.00:** insert `drafts/NEXT-VERSION-U9.md` after U14's entry. That is after its "Not covered"
  bullet ending "…what "genuine stored plans" takes in).", at line 777, and before "- **Unresolved after R1–R5 (11 Oct).**".
- **"Unresolved after R1–R5":** replace the two lines at 792–793 (the bullet starting "  - **U9 (P2): PMO split
  disagreement.**") with `drafts/UNRESOLVED-line-U9.md`.
  - Keep the line "Both U9 and U10 were reproduced …" unless U10's track replaces it.
- **UNRESOLVED-LEDGER.md, U9 row** (lines 20–30): append `drafts/LEDGER-U9-append.md` to the last column, before its closing
  ` |`. Fill in `<sha>` and `<time>` when committed.
- **UNRESOLVED-LEDGER.md, new row:** `drafts/LEDGER-new-row.md`. The lead assigns its number.

## Runs (build, 12 Oct)

Every run went through `run.sh`:

- `setsid -w timeout -k 10 600`, from the named directory
- `BOARD` and `MUT_FIRST_FAIL` unset unless set explicitly
- the AUDIT_IMPORT_RUNNING lock checked before each run; it was never present, and no run waited or was skipped

PIDs are in `pids.txt`: the timeout PID and its child for each run, and each chain step's PID. `chain.sh` launched the
background chain at 7:40 PM ET. A pids.txt note at 7:39:27 PM ET was written before the script was rewritten into its
final form; that earlier version never ran. `chain.sh` is orchestration only: each of its steps was itself under `setsid -w timeout -k 10 600`,
with its PID recorded.

After the last run, at 7:47 PM ET, none of the 166 PIDs recorded was alive. Nothing was killed, by me or by a timeout.

One `node --check` (a syntax check of c1's audit-recon.mjs, no suite) ran at about 7:37 PM ET outside `run.sh`. The lock was
absent at 7:31 and again at 7:37:17 PM ET.

Rows 1 to 25 below are the earlier builder's (6:00 to 6:16 PM ET), and the rest are this attempt's. `step` lines and
`chain done` are in `logs/runs.txt`.

| # | label | start (ET) | exit | wall s | log |
|---|---|---|---|---|---|
| 1 | sim1 | 18:00:25 EDT | 0 | 0.1 | logs/sim1.log |
| 2 | sweep1 | 18:00:50 EDT | 0 | 0.7 | logs/sweep1.log |
| 3 | repro-base | 18:02:56 EDT | 1 | 4.5 | logs/repro-base.log |
| 4 | repro-c1 | 18:03:56 EDT | 0 | 3.5 | logs/repro-c1.log |
| 5 | f-c1 | 18:10:10 EDT | 1 | 2.6 | logs/f-c1.log |
| 6 | f-c1-r2 | 18:10:44 EDT | 0 | 3.2 | logs/f-c1-r2.log |
| 7 | f-base | 18:10:51 EDT | 1 | 3.4 | logs/f-base.log |
| 8 | f-c1-r3 | 18:12:03 EDT | 0 | 3.7 | logs/f-c1-r3.log |
| 9 | f-base-r3 | 18:12:07 EDT | 1 | 3.5 | logs/f-base-r3.log |
| 10 | fm-v200-u9-split-by-fraction | 18:12:54 EDT | 1 | 3.3 | logs/fm-v200-u9-split-by-fraction.log |
| 11 | fm-v200-u9-weights-are-fractions | 18:12:57 EDT | 1 | 3.4 | logs/fm-v200-u9-weights-are-fractions.log |
| 12 | fm-v200-u9-per-part-rounding | 18:13:01 EDT | 1 | 3.8 | logs/fm-v200-u9-per-part-rounding.log |
| 13 | fm-v200-u9-ties-by-name | 18:13:04 EDT | 1 | 3.3 | logs/fm-v200-u9-ties-by-name.log |
| 14 | fm-v200-u9-uncovered-weight-dropped | 18:13:08 EDT | 1 | 2.9 | logs/fm-v200-u9-uncovered-weight-dropped.log |
| 15 | fm-v200-u9-plan-part-by-weight | 18:13:11 EDT | 1 | 2.8 | logs/fm-v200-u9-plan-part-by-weight.log |
| 16 | fm-v200-u9-plan-placed-by-weight | 18:13:14 EDT | 1 | 2.6 | logs/fm-v200-u9-plan-placed-by-weight.log |
| 17 | s-base-boot-same | 18:14:07 EDT | 0 | 9.5 | logs/s-base-boot-same.log |
| 18 | s-base-audit | 18:14:16 EDT | 0 | 8.0 | logs/s-base-audit.log |
| 19 | s-base-audit-ppt | 18:14:24 EDT | 0 | 5.1 | logs/s-base-audit-ppt.log |
| 20 | s-base-audit-other | 18:14:29 EDT | 0 | 33.2 | logs/s-base-audit-other.log |
| 21 | div-c1 | 18:15:15 EDT | 0 | 4.2 | logs/div-c1.log |
| 22 | div-c1-r2 | 18:15:37 EDT | 0 | 4.8 | logs/div-c1-r2.log |
| 23 | div-base | 18:15:42 EDT | 0 | 5.3 | logs/div-base.log |
| 24 | s-base-audit-recon | 18:15:02 EDT | 0 | 89.2 | logs/s-base-audit-recon.log |
| 25 | s-base-legacy-fsrc | 18:16:32 EDT | 0 | 3.5 | logs/s-base-legacy-fsrc.log |
| 26 | tabs-c1 | 19:36:16 EDT | 0 | 1.5 | logs/tabs-c1.log |
| 27 | f2-c1 | 19:37:23 EDT | 0 | 2.2 | logs/f2-c1.log |
| 28 | f2-base | 19:37:26 EDT | 1 | 2.3 | logs/f2-base.log |
| 29 | f3-c1 | 19:37:47 EDT | 0 | 2.4 | logs/f3-c1.log |
| 30 | f3-base | 19:37:49 EDT | 1 | 2.2 | logs/f3-base.log |
| 31 | fm3-v200-u9-split-by-fraction | 19:38:59 EDT | 1 | 2.4 | logs/fm3-v200-u9-split-by-fraction.log |
| 32 | fm3-v200-u9-weights-are-fractions | 19:39:01 EDT | 1 | 2.4 | logs/fm3-v200-u9-weights-are-fractions.log |
| 33 | fm3-v200-u9-per-part-rounding | 19:39:03 EDT | 1 | 2.3 | logs/fm3-v200-u9-per-part-rounding.log |
| 34 | fm3-v200-u9-ties-by-name | 19:39:06 EDT | 1 | 2.4 | logs/fm3-v200-u9-ties-by-name.log |
| 35 | fm3-v200-u9-uncovered-weight-dropped | 19:39:08 EDT | 1 | 2.3 | logs/fm3-v200-u9-uncovered-weight-dropped.log |
| 36 | fm3-v200-u9-plan-part-by-weight | 19:39:11 EDT | 1 | 2.4 | logs/fm3-v200-u9-plan-part-by-weight.log |
| 37 | fm3-v200-u9-plan-placed-by-weight | 19:39:13 EDT | 1 | 2.4 | logs/fm3-v200-u9-plan-placed-by-weight.log |
| 38 | s-base2-audit-hostile | 19:40:07 EDT | 0 | 41.5 | logs/s-base2-audit-hostile.log |
| 39 | s-base2-audit-inject | 19:40:48 EDT | 0 | 10.1 | logs/s-base2-audit-inject.log |
| 40 | s-c1-boot-same | 19:40:58 EDT | 0 | 9.3 | logs/s-c1-boot-same.log |
| 41 | s-c1-audit | 19:41:08 EDT | 0 | 8.9 | logs/s-c1-audit.log |
| 42 | s-c1-audit-ppt | 19:41:17 EDT | 0 | 4.0 | logs/s-c1-audit-ppt.log |
| 43 | s-c1-audit-other | 19:41:21 EDT | 0 | 24.7 | logs/s-c1-audit-other.log |
| 44 | s-c1-audit-recon | 19:41:45 EDT | 0 | 102.9 | logs/s-c1-audit-recon.log |
| 45 | s-c1-legacy-fsrc | 19:43:28 EDT | 0 | 3.6 | logs/s-c1-legacy-fsrc.log |
| 46 | s-c1-audit-hostile | 19:43:32 EDT | 0 | 54.4 | logs/s-c1-audit-hostile.log |
| 47 | s-c1-audit-inject | 19:44:26 EDT | 0 | 10.5 | logs/s-c1-audit-inject.log |
| 48 | x-c1-pmo-residual-audit | 19:44:37 EDT | 1 | 3.6 | logs/x-c1-pmo-residual-audit.log |
| 49 | x-c1-pmo-frac-audit | 19:44:41 EDT | 1 | 3.5 | logs/x-c1-pmo-frac-audit.log |
| 50 | x-c1-excel-unf-vec-audit | 19:44:45 EDT | 1 | 3.3 | logs/x-c1-excel-unf-vec-audit.log |
| 51 | x-c1-w7-office-share-fraction-audit | 19:44:48 EDT | 1 | 8.9 | logs/x-c1-w7-office-share-fraction-audit.log |
| 52 | x-c1-w7-office-split-by-weight-audit | 19:44:57 EDT | 1 | 11.8 | logs/x-c1-w7-office-split-by-weight-audit.log |
| 53 | x-c1-w7-office-months-fraction-audit | 19:45:10 EDT | 1 | 11.7 | logs/x-c1-w7-office-months-fraction-audit.log |
| 54 | x-c1-w7-office-ask-whole-audit | 19:45:22 EDT | 1 | 3.8 | logs/x-c1-w7-office-ask-whole-audit.log |
| 55 | x-c1-w7-office-mcs-unfunded-only-audit | 19:45:26 EDT | 1 | 3.3 | logs/x-c1-w7-office-mcs-unfunded-only-audit.log |
| 56 | x-base-pmo-residual-audit | 19:45:29 EDT | 1 | 4.3 | logs/x-base-pmo-residual-audit.log |
| 57 | x-base-pmo-frac-audit | 19:45:34 EDT | 1 | 4.0 | logs/x-base-pmo-frac-audit.log |
| 58 | x-base-excel-unf-vec-audit | 19:45:38 EDT | 1 | 3.7 | logs/x-base-excel-unf-vec-audit.log |
| 59 | x-base-w7-office-share-fraction-audit | 19:45:42 EDT | 1 | 9.5 | logs/x-base-w7-office-share-fraction-audit.log |
| 60 | x-base-w7-office-split-by-weight-audit | 19:45:52 EDT | 1 | 10.1 | logs/x-base-w7-office-split-by-weight-audit.log |
| 61 | x-base-w7-office-months-fraction-audit | 19:46:02 EDT | 1 | 11.1 | logs/x-base-w7-office-months-fraction-audit.log |
| 62 | x-base-w7-office-ask-whole-audit | 19:46:14 EDT | 1 | 3.9 | logs/x-base-w7-office-ask-whole-audit.log |
| 63 | x-base-w7-office-mcs-unfunded-only-audit | 19:46:18 EDT | 1 | 4.1 | logs/x-base-w7-office-mcs-unfunded-only-audit.log |
| 64 | fb-c1 | 19:46:31 EDT | 0 | 9.2 | logs/fb-c1.log |
| 65 | fb-base | 19:46:40 EDT | 0 | 10.6 | logs/fb-base.log |
| 66 | repro2-base | 19:46:51 EDT | 1 | 9.2 | logs/repro2-base.log |
| 67 | repro2-c1 | 19:47:00 EDT | 0 | 9.3 | logs/repro2-c1.log |
| 68 | div2-base | 19:47:10 EDT | 0 | 7.5 | logs/div2-base.log |
| 69 | div2-c1 | 19:47:17 EDT | 0 | 7.3 | logs/div2-c1.log |
| 70 | check-base | 19:47:32 EDT | 0 | 6.1 | logs/check-base.log |
| 71 | moneymap-base | 19:47:38 EDT | 0 | 0.3 | logs/moneymap-base.log |
| 72 | check-c1 | 19:47:38 EDT | 0 | 5.3 | logs/check-c1.log |
| 73 | moneymap-c1 | 19:47:44 EDT | 0 | 0.1 | logs/moneymap-c1.log |

Exit 1 on `repro*-base`, `f*-base`, `fm*-*` and `x-*` means failing checks were found, as intended (the defect, or a
mutant caught). It does not mean a crash.

## Files (build)

| path | what | blob |
|---|---|---|
| `c1/` | the cumulative copy (base + this commit; `node_modules` is a symlink) | see the table at the top |
| `diffs/c1-vs-base.diff` | all three files | f4a61cf7 |
| `diffs/c1-vs-base.board.diff`, `.audit-recon.diff`, `.mutate.diff` | per file | c89b763d, 47e09dee, b600a9e7 |
| `harness/c1/focused-u9.mjs` | the focused audit-recon harness | 8d9c140f |
| `harness/board/focused-board-pmo.mjs` | the focused audit-board harness (two scenarios, verbatim) | 70c32c5a |
| `probe/repro-u9.mjs`, `probe/divergence.mjs`, `probe/tabs.mjs` | the reproduction, the divergence probe, and the tab-layout look (observe-only) | 7d549ce1, 71ce62ec, 18dbe1fe |
| `check/lr.py` | an independent re-working of every literal (Python, exact) | c67ae567 |
| `mut/new/*.html` | the 7 mutants (disposable) | |
| `drafts/` | NEXT-VERSION, Unresolved line, ledger append, new ledger row | |

## What I did not do (build)

- I did not run full audit-import or audit-board. Those are the lead's. Only the two audit-board PRIME-3 scenarios ran,
  focused and verbatim.
- I did not run the full mutate sweep or `validate:math`. mutate.mjs was never imported or run; it was read as text only.
- I did not run verify:grid or Playwright. This change moves nothing on screen.
- I did not update the money-map catalogue to cite the new block. `money-map --check` holds without it.
- I did not change the Spend Plan Source, `clinSplit`, `pmoSplit`, or the cases D1–D4.
- I did not edit NEXT-VERSION.md or the ledger in the copy. The drafts are separate, as U14's were.
- I made no commits anywhere. The scratch clone `gitclone/` was restored to 7ee498a after `npm run check`.

## Appendix: the full Fix round 1 diff (`diffs/r1/c1-vs-c1build.diff`, blob 36e368c2; the board's is empty)

```diff
--- a/tools/export-audit/audit-recon.mjs
+++ b/tools/export-audit/audit-recon.mjs
@@ -5267,41 +5267,46 @@
     // ---- BOARD B: the CLIN list decides a tie, and every lane
     const SB = ['USAF', 'ANG', 'AFRC', 'STOVL', 'USMC-C'], BA = [3, 5, 9, 7, 100], BD = [3, 5, 3, 7, 100], BM = [0, 0, 3, 0, 0];
     const OB = ['TSS', 'AV', 'MxS', 'PRIMES'];
-    const B = { TSS: { d: [1, 1, 1, 0, 17], m: [0, 0, 1, 0, 0], ask: 21, short: 1 }, AV: { d: [1, 2, 1, 0, 33], m: [0, 0, 1, 0, 0], ask: 39, short: 2 },
-                MxS: { d: [1, 2, 1, 0, 50], m: [0, 0, 1, 0, 0], ask: 57, short: 3 }, PRIMES: { d: [0, 0, 0, 7, 0], m: [0, 0, 0, 0, 0], ask: 7, short: 0 } };
+    // and each office's totals, written out: discretionary, mandatory, funded, unfunded
+    const B = { TSS: { d: [1, 1, 1, 0, 17], m: [0, 0, 1, 0, 0], ask: 21, short: 1, dT: 20, mT: 1, fT: 21, uT: 0 },
+                AV: { d: [1, 2, 1, 0, 33], m: [0, 0, 1, 0, 0], ask: 39, short: 2, dT: 37, mT: 1, fT: 38, uT: 1 },
+                MxS: { d: [1, 2, 1, 0, 50], m: [0, 0, 1, 0, 0], ask: 57, short: 3, dT: 54, mT: 1, fT: 55, uT: 2 },
+                PRIMES: { d: [0, 0, 0, 7, 0], m: [0, 0, 0, 0, 0], ask: 7, short: 0, dT: 7, mT: 0, fT: 7, uT: 0 } };
     const CTL_B = ['ANG', 'STOVL', 'USMC-C'];
     const XB = prime(SB, BA, BD, BM, [['0008', [1, 1, 1, 0, 1]], ['0002', [2, 2, 2, 0, 2]], ['0010', [3, 3, 3, 0, 3]]], true);
     w5Chk(name, 'B · fixture', 'CONTROL — PRIME-3, starred, with CLINs 0008, 0002, 0010 in that order; AFRC draws $3 discretionary and $3 mandatory of $9',
       fixture(XB), J([true, BD, BM, ['0008', '0002', '0010']]));
     w5Chk(name, 'B · the rule', 'CONTROL — each service’s parts, as written, add up to its discretionary and its mandatory',
       J(SB.map((s, i) => [sum(OB.map(g => B[g].d[i])), sum(OB.map(g => B[g].m[i]))])), J(SB.map((s, i) => [BD[i], BM[i]])));
+    w5Chk(name, 'B · the rule', 'CONTROL — each office’s totals, as written, are its parts added up; funded and unfunded make its ask, and its short is its ask less Disc',
+      J(OB.map(g => [sum(B[g].d), sum(B[g].m), B[g].dT + B[g].mT, B[g].fT + B[g].uT, B[g].ask - B[g].dT])), J(OB.map(g => [B[g].dT, B[g].mT, B[g].fT, B[g].ask, B[g].short])));
     const pB = panel(XB);
     SB.forEach((s, i) => w5Chk(name, 'B · the PMO panel · ' + s, (CTL_B.includes(s) ? 'CONTROL — ' : '') + 'TSS / AV / MxS / PRIMES, Disc and Mand, as printed',
       J(OB.map(g => pB[g] ? pB[g].slice(2 * i, 2 * i + 2) : null)), J(OB.map(g => [pr(B[g].d[i]), pr(B[g].m[i])]))));
     w5Chk(name, 'B · the PMO panel · TOTAL', 'each office’s TOTAL Disc, TOTAL Mand and MC, as printed',
-      J(OB.map(g => pB[g] ? pB[g].slice(2 * SB.length) : null)), J(OB.map(g => [prT(sum(B[g].d)), prT(sum(B[g].m)), pr(B[g].short)])));
+      J(OB.map(g => pB[g] ? pB[g].slice(2 * SB.length) : null)), J(OB.map(g => [prT(B[g].dT), prT(B[g].mT), pr(B[g].short)])));
     SB.forEach((s, i) => { const F = fcSvc(XB, i);
       w5Chk(name, 'B · the forecast · ' + s + ' alone', (CTL_B.includes(s) ? 'CONTROL — ' : '') + 'TSS / AV / MxS / PRIMES', J(OB.map(g => F[g] || 0)), J(OB.map(g => B[g].d[i] + B[g].m[i]))); });
     const fB = fcAll(XB);
     w5Chk(name, 'B · the forecast · whole portfolio', 'each office’s TOTAL, all of it UNSCHEDULED', J(OB.map(g => fB[g] || null)),
-      J(OB.map(g => [sum(B[g].d) + sum(B[g].m), sum(B[g].d) + sum(B[g].m)])));
+      J(OB.map(g => [B[g].fT, B[g].fT])));
     const eB = await fcBook(XB);
     w5Chk(name, 'B · the exported forecast', 'CONTROL — the view builds and reads back', eB.err, 'ok');
     w5Chk(name, 'B · the exported forecast', 'each office\u2019s months, UNSCHEDULED and TOTAL: TSS / AV / MxS / PRIMES', J(OB.map(g => eB.row(g))),
-      J(OB.map(g => Array(12).fill(0).concat([sum(B[g].d) + sum(B[g].m), sum(B[g].d) + sum(B[g].m)]))));
+      J(OB.map(g => Array(12).fill(0).concat([B[g].fT, B[g].fT]))));
     const mB = await matrix(XB);
     w5Chk(name, 'B · the PMO Matrix', 'CONTROL — the workbook builds and reads back', mB.err, 'ok');
     SB.forEach((s, i) => w5Chk(name, 'B · the PMO Matrix · ' + s, (CTL_B.includes(s) ? 'CONTROL — ' : '') + 'TSS / AV / MxS / PRIMES, ' + s + ' Disc and ' + s + ' Mand',
       J(OB.map(g => [mB.cell(g, s + ' Disc'), mB.cell(g, s + ' Mand')])), J(OB.map(g => [B[g].d[i], B[g].m[i]]))));
     w5Chk(name, 'B · the PMO Matrix · TOTAL and MC', 'each office’s TOTAL Disc, TOTAL Mand, ★ MC requirement and ★ MC short',
       J(OB.map(g => ['TOTAL Disc', 'TOTAL Mand', '★ MC requirement (memo)', '★ MC short vs Disc'].map(c => mB.cell(g, c)))),
-      J(OB.map(g => [sum(B[g].d), sum(B[g].m), B[g].ask, B[g].short])));
+      J(OB.map(g => [B[g].dT, B[g].mT, B[g].ask, B[g].short])));
     const FYB = XB.ev('FYL()'), colsB = [FYB + ' Ask', 'Disc allocated', 'UFR (Unfunded Requirement)'].concat(SB.map(s => s + ' Disc'), SB.map(s => s + ' Mand'));
     w5Chk(name, 'B · the PMO tabs', 'each office’s tab, TSS / AV / MxS / PRIMES: PRIME-3’s ' + FYB + ' Ask, Disc allocated, UFR, then each service’s Disc and Mand',
-      J(OB.map(g => mB.tab(g, colsB))), J(OB.map(g => [B[g].ask, sum(B[g].d), B[g].ask - sum(B[g].d) - sum(B[g].m)].concat(B[g].d, B[g].m))));
+      J(OB.map(g => mB.tab(g, colsB))), J(OB.map(g => [B[g].ask, B[g].dT, B[g].uT].concat(B[g].d, B[g].m))));
     const cB = crPmo(XB);
     w5Chk(name, 'B · the CR view by PMO', 'each office’s dollars in a window, and with no date: TSS / AV / MxS / PRIMES', J(OB.map(g => cB[g] || null)),
-      J(OB.map(g => [0, sum(B[g].d) + sum(B[g].m)])));
+      J(OB.map(g => [0, B[g].fT])));
     const sB = await source(XB);
     w5Chk(name, 'B · the Spend Plan Source', 'CONTROL — the file builds and reads back', sB.err, 'ok');
     w5Chk(name, 'B · the Spend Plan Source', 'CONTROL — its CLIN lines carry each office’s dollars, both lanes: 0008 TSS, 0002 AV, 0010 MxS; the uncovered STOVL on no CLIN',
@@ -5325,6 +5330,122 @@
   await settleBoards();
 })();
 // ==== end v2.00 (U9) ====
+// ==== v2.00 (U9, every export): CE by PMO, the PMO tabs by portion, the Two-Plan Forecast and the deck carry the same parts; an office that holds two CLINs ====
+// The block above reads the panel, the forecast, the PMO Matrix, each PMO tab's report row and the CR view. Four more exports
+// carry each office's part, from the same pmoPartsOf: the workbook's CE by PMO sheet, each office's PMO tab by portion, the
+// Two-Plan Forecast's BY PMO rows and the deck's Funding by PMO slide. They are held here to the same hand-worked dollars,
+// with the mandatory lane's own tie. And the rest of the tie rule: an office that holds more than one CLIN weighs its CLINs'
+// asks added up and ranks by its FIRST CLIN in the list.
+// BOARD D, CLINs 0010 / 0002 / 0008 (MxS, AV, TSS) asking 1 : 2 : 3 on every service, cost elements on (Airframe PGSE):
+//   USAF  $3 discretionary: .5 / 1 / 1.5, the tied dollar to MxS                                            = 1/1/1
+//   ANG   $9 discretionary: 1.5 / 3 / 4.5, MxS                                                               = 2/3/4
+//   AFRC  $3, every dollar mandatory (no discretionary there): the same tie, on the mandatory lane          = 1/1/1
+//   So MxS asks 4 (3 discretionary + 1 mandatory), AV 5 (4 + 1), TSS 6 (5 + 1), and nothing is unfunded. The Two-Plan
+//   Forecast's plan A (discretionary only) funds USAF and ANG, 3 / 4 / 5; plan B (both pots) all three, 4 / 5 / 6.
+//   CONTROL: the Spend Plan Source's CLIN lines. Each service here is drawn from one lane, so they agree with the offices:
+//   0010 $4, 0002 $5, 0008 $6.
+// BOARD E, USAF $3 discretionary over CLINs 0002 [1], 0010 [1], 0102 [1], 0008 [3], 0110 [0]: AV holds 0002 and 0102, MxS
+//   0010 and 0110, so the offices weigh AV 2 : MxS 1 : TSS 3 and rank AV, MxS, TSS: 1 / .5 / 1.5, the tie of MxS and TSS
+//   is MxS's = AV 1 / MxS 1 / TSS 1, as the Spend Plan Source's CLIN lines give it (CONTROL: 0002, 0010 and 0008 a dollar
+//   each). An office weighed by its first CLIN alone (AV 1), or ranked by its last (TSS before MxS), gives 1 / 0 / 2.
+// FAILS ON 7ee498a (board fce8a391), except the CONTROLs: the offices were split by their fractions, so D was 0/1/2, 1/3/5
+// and, on the mandatory lane, 0/1/2 -- MxS asking 1, AV 5, TSS 9 -- on every one of these exports, and E was 1 / 0 / 2.
+await (async () => {
+  const name = 'v2.00 (U9, every export) — CE by PMO, the PMO tabs by portion, the Two-Plan Forecast and the deck carry the same parts; an office with two CLINs';
+  const { bootMark, bootRelease, settleBoards } = await import('./boot.mjs');
+  const __bm = bootMark();
+  try {
+    const J = JSON.stringify;
+    // PRIME-3 alone, office PRIMES; its CLINs [number, ask by service] in the order given; cost elements on or not
+    const prime = (svcs, ask, disc, mand, clins, ce) => {
+      const X = boot();
+      seed(X.ev, { services: svcs, items: [it('PRIME-3', 'PRIMES', ask)], disc, mand, order: ['PRIME-3'], mc: {} });
+      X.ev(`BASE_ITEMS.length=0; DATA.items.forEach(function(i){ BASE_ITEMS.push(i); BASE_ASK[i.id]=i.ask.slice(); });
+        if(!DATA.clins) DATA.clins=CLINS;
+        CLINS['PRIME-3']=${J(clins.map(([clin, a]) => ({ clin, desc: 'CLIN ' + clin, ccar: '', ask: a })))};
+        DATA.clins['PRIME-3']=CLINS['PRIME-3'];
+        S.ptype={'PRIME-3':'PRIME'};
+        ${ce ? "DATA.costElems=true; S.costElem={'PRIME-3':'Airframe PGSE'};" : ''}
+        MS.years[MS.cur]=S; applyState(S); save(); render(); 'ok'`);
+      return X;
+    };
+    const fixture = X => X.ev(`(function(){ var T=tiers()['PRIME-3']; return JSON.stringify([clinApplies('PRIME-3'), T.d, T.m,
+      clinList('PRIME-3').map(function(c){ return c.clin; })]); })()`);
+    // the Spend Plan Source, read back from its bytes: dollars by CLIN number, the lines that carry any
+    const source = async X => { const sb = JSON.parse(await w6Book(X.w, 'exportSrc'));
+      const sh = Object.keys(sb).filter(k => !k.startsWith('__')).map(k => sb[k]).find(rs => (rs || []).length > 1) || [];
+      const hd = (sh[0] || []).map(c => String(c ?? '').trim()), cA = hd.indexOf('Amount'), cC = hd.indexOf('CLINs'), o = {};
+      sh.slice(1).forEach(r => { const k = String(r[cC] ?? '').trim() || 'no CLIN'; if (num(r[cA])) o[k] = (o[k] || 0) + num(r[cA]); });
+      return { err: sb.__err || (cA < 0 || cC < 0 ? 'no Amount or CLINs column' : 'ok'), by: o }; };
+    const sum = a => a.reduce((x, y) => x + y, 0);
+    const ct = c => String((c && typeof c === 'object') ? (c.t ?? c.v ?? '') : (c ?? '')).trim();
+
+    // ---- BOARD D: the four exports, at $3, at $9 and on the mandatory lane
+    const SD = ['USAF', 'ANG', 'AFRC'], OD = ['MxS', 'AV', 'TSS'];
+    // each office's discretionary and mandatory, service by service, and its totals: ask, discretionary, mandatory
+    const DD = { MxS: [1, 2, 0], AV: [1, 3, 0], TSS: [1, 4, 0] }, DM = { MxS: [0, 0, 1], AV: [0, 0, 1], TSS: [0, 0, 1] };
+    const DT = { MxS: [4, 3, 1], AV: [5, 4, 1], TSS: [6, 5, 1] };
+    const XD = prime(SD, [3, 9, 3], [3, 9, 0], [0, 0, 3], [['0010', [1, 1, 1]], ['0002', [2, 2, 2]], ['0008', [3, 3, 3]]], true);
+    w5Chk(name, 'D · fixture', 'CONTROL — PRIME-3, with CLINs 0010, 0002, 0008, draws USAF $3 and ANG $9 discretionary and AFRC $3 mandatory',
+      fixture(XD), J([true, [3, 9, 0], [0, 0, 3], ['0010', '0002', '0008']]));
+    w5Chk(name, 'D · the rule', 'CONTROL — each service’s parts, as written, add up to its discretionary and its mandatory; each office’s to its totals',
+      J([SD.map((s, i) => [sum(OD.map(g => DD[g][i])), sum(OD.map(g => DM[g][i]))]), OD.map(g => [sum(DD[g]) + sum(DM[g]), sum(DD[g]), sum(DM[g])])]),
+      J([[[3, 0], [9, 0], [0, 3]], OD.map(g => DT[g])]));
+    const bk = JSON.parse(await w6Book(XD.w, 'exportExcel')), FY = XD.ev('FYL()');
+    w5Chk(name, 'D · the workbook', 'CONTROL — it builds and reads back, with a CE by PMO sheet and a PMO tab for each office',
+      J([bk.__err || 'ok', !!bk['CE by PMO']].concat(OD.map(g => !!bk['PMO ' + g]))), J(['ok', true, true, true, true]));
+    const pm = bk['PMO Matrix'] || [], h = w6Hdrs(pm, 'PMO', 'TOTAL Disc')[0];
+    const cell = (g, col) => { const r = pm.find((x, j) => j > h && w6Lbl(x) === g), c = w6Col(pm, h, col); return !r ? 'no row ' + g : c < 0 ? 'no column ' + col : num(r[c]); };
+    w5Chk(name, 'D · the PMO Matrix', 'MxS / AV / TSS: USAF, ANG and AFRC, Disc and Mand (AFRC’s tie is on the mandatory lane)',
+      J(OD.map(g => SD.map(s => [cell(g, s + ' Disc'), cell(g, s + ' Mand')]))), J(OD.map(g => SD.map((s, i) => [DD[g][i], DM[g][i]]))));
+    const ce = bk['CE by PMO'] || [], ch = w6Hdrs(ce, 'PMO / Cost Element', 'Disc portion')[0];
+    w5Chk(name, 'D · CE by PMO', 'MxS / AV / TSS: ' + FY + ' Ask, Disc portion, Mand portion and Unfunded (incl delta)',
+      J(OD.map(g => { const r = ce.find((x, j) => j > ch && w6Lbl(x) === g);
+        return r ? [FY + ' Ask', 'Disc portion', 'Mand portion', 'Unfunded (incl delta)'].map(c => num(r[w6Col(ce, ch, c)])) : null; })),
+      J(OD.map(g => DT[g].concat([0]))));
+    // each office's own PMO tab: PRIME-3's row under a portion's header -- the amount, then each service
+    const tabRow = (g, lbl) => { const rows = bk['PMO ' + g] || [], th = w6Hdrs(rows, 'Rank', lbl)[0];
+      const r = th === undefined ? null : rows.slice(th + 1).find(x => (x || []).includes('Req PRIME-3'));
+      return !rows.length ? 'no tab PMO ' + g : !r ? 'no PRIME-3 row under ' + lbl : [lbl].concat(SD).map(c => num(r[w6Col(rows, th, c)])); };
+    w5Chk(name, 'D · the PMO tabs by portion', 'MxS / AV / TSS: PRIME-3’s Disc portion row, the amount then USAF, ANG and AFRC',
+      J(OD.map(g => tabRow(g, 'Disc portion'))), J(OD.map(g => [DT[g][1]].concat(DD[g]))));
+    w5Chk(name, 'D · the PMO tabs by portion', 'MxS / AV / TSS: PRIME-3’s Mand portion row, the amount then USAF, ANG and AFRC',
+      J(OD.map(g => tabRow(g, 'Mand portion'))), J(OD.map(g => [DT[g][2]].concat(DM[g]))));
+    const tp = bk[Object.keys(bk).find(k => / Two-Plan Forecast$/.test(k))] || [];
+    w5Chk(name, 'D · the Two-Plan Forecast · BY PMO', 'MxS / AV / TSS: TOTAL, in whole dollars, plan A (discretionary only) then plan B (both pots)',
+      J(OD.map(g => tp.filter(r => w6Lbl(r) === g).map(r => w5Dol(num(r[r.length - 1]))))), J([[3, 4], [4, 5], [5, 6]]));
+    // the deck: the tables exportPPT builds, captured as rows instead of the XML they turn into
+    XD.ev(`globalThis.__u9t=[]; if(!globalThis.__u9oT) globalThis.__u9oT=_pTbl; if(!globalThis.__u9oB) globalThis.__u9oB=buildPptx;
+      _pTbl=function(){ var a=arguments; globalThis.__u9t.push(a[a.length-1]); return ''; }; buildPptx=function(){ return new Uint8Array(0); };
+      try{ exportPPT(); } finally { _pTbl=globalThis.__u9oT; buildPptx=globalThis.__u9oB; } 'ok'`);
+    const pt = JSON.parse(XD.ev('JSON.stringify(globalThis.__u9t)')).find(t => { const h0 = ((t || [])[0] || []).map(ct); return h0[0] === 'PMO' && h0.includes('★ MC req'); }) || [];
+    const at = k => ((pt[0] || []).map(ct)).indexOf(k);
+    w5Chk(name, 'D · the deck · Funding by PMO', 'MxS / AV / TSS: ' + FY + ' Ask, Discretionary, Mandatory and Unfunded, as printed',
+      J(OD.map(g => { const r = pt.find(x => ct((x || [])[0]) === g); return r ? [FY + ' Ask', 'Discretionary', 'Mandatory', 'Unfunded'].map(k => ct(r[at(k)])) : null; })),
+      J([['$4', '$3', '$1', '—'], ['$5', '$4', '$1', '—'], ['$6', '$5', '$1', '—']]));
+    const sD = await source(XD);
+    w5Chk(name, 'D · the Spend Plan Source', 'CONTROL — its CLIN lines, one lane a service: 0010 MxS, 0002 AV, 0008 TSS', J([sD.err, sD.by]), J(['ok', { '0010': 4, '0002': 5, '0008': 6 }]));
+
+    // ---- BOARD E: an office that holds two CLINs weighs them added up and ranks by the first
+    const OE = ['AV', 'MxS', 'TSS'];
+    const XE = prime(['USAF'], [3], [3], [0], [['0002', [1]], ['0010', [1]], ['0102', [1]], ['0008', [3]], ['0110', [0]]], false);
+    w5Chk(name, 'E · fixture', 'CONTROL — PRIME-3 draws its $3, discretionary, with CLINs 0002, 0010, 0102, 0008, 0110 in that order',
+      fixture(XE), J([true, [3], [0], ['0002', '0010', '0102', '0008', '0110']]));
+    const be = JSON.parse(await w6Book(XE.w, 'exportExcel')), pe = be['PMO Matrix'] || [], he = w6Hdrs(pe, 'PMO', 'TOTAL Disc')[0];
+    w5Chk(name, 'E · the PMO Matrix', 'AV / MxS / TSS, USAF Disc: AV’s two CLINs weigh 2, MxS’s 1 (its 0110 asks nothing), TSS’s 3; the tie of MxS and TSS is MxS’s, its first CLIN (0010) before 0008',
+      J(OE.map(g => { const r = pe.find((x, j) => j > he && w6Lbl(x) === g); return r ? num(r[w6Col(pe, he, 'USAF Disc')]) : null; })), J([1, 1, 1]));
+    const fE = JSON.parse(XE.ev(`(function(){ var F=forecast().byPMO, o={}; Object.keys(F).forEach(function(g){ o[g]=F[g].tot; }); return JSON.stringify(o); })()`));
+    w5Chk(name, 'E · the forecast', 'AV / MxS / TSS, the whole portfolio', J(OE.map(g => fE[g] || 0)), J([1, 1, 1]));
+    const sE = await source(XE);
+    w5Chk(name, 'E · the Spend Plan Source', 'CONTROL — its CLIN lines: 0002 AV, 0010 MxS and 0008 TSS a dollar each; 0102 and 0110 nothing',
+      J([sE.err, sE.by]), J(['ok', { '0002': 1, '0010': 1, '0008': 1 }]));
+  } catch (e) {
+    failures.push({ scenario: name, where: 'harness', what: 'the block threw: ' + String((e && e.message) || e).slice(0, 160), got: 'threw', want: 'ran' });
+  }
+  bootRelease(__bm, []);
+  await settleBoards();
+})();
+// ==== end v2.00 (U9, every export) ====
 
 {
   const src = _selfRead(_selfPath(import.meta.url), 'utf8');
--- a/tools/export-audit/mutate.mjs.txt
+++ b/tools/export-audit/mutate.mjs.txt
@@ -4308,6 +4308,29 @@
   { id: "v200-u9-plan-placed-by-weight", area: "pmoPartsOf", what: "a modelled plan's dollars that are not whole are placed by each office's CLIN asks, not its fraction: the forecast of $10.50 at 1 : 2 : 3 is $10.50 / $21 / $31.50",
     find: "      return (memo[key]=fOf(i).map(function(f){ return landSvc(aw, i, d, m, literal, f); }));",
     repl: "      return (memo[key]=w.map(function(f){ return landSvc(aw, i, d, m, literal, f); }));" },
+  // v2.00 (U9, every export): CE by PMO, the PMO tabs by portion and the deck carry the same parts as every other by-office
+  // view, and an office holding two CLINs weighs them added up and ranks by the first (audit-recon "v2.00 (U9, every export) — ...").
+  { id: "v200-u9-cebypmo-float-split", area: "exportExcel (CE by PMO)", what: "the CE by PMO sheet splits each lane itself by the offices' fractions: $3 at 1 : 2 : 3 is $0/$1/$2 there while every other by-office view says $1/$1/$1",
+    find: "        const g=o.g, tot=k=>o[k].reduce((x,y)=>x+y,0);",
+    repl: "        const g=o.g, tot=k=>{ if(!o.frac) return o[k].reduce((x,y)=>x+y,0); const sh=pmoSharesOf(it), K=sh.findIndex(r=>r[0]===o.g);\n          const V={ask:it.ask, d:p.d, m:p.m, u:SVC.map((s,i)=>Math.max(0,(+it.ask[i]||0)-(p.d[i]||0)-(p.m[i]||0))), mcs:SVC.map((s,i)=>Math.max(0,(+it.ask[i]||0)-(p.d[i]||0)))}[k];\n          return SVC.reduce((x,s,i)=>x+apportion(+V[i]||0, sh.map(r=>r[1]? r[1][i] : 1))[K],0); };" },
+  { id: "v200-u9-cebypmo-own-rounding", area: "exportExcel (CE by PMO)", what: "the CE by PMO sheet rounds each office's fraction of the discretionary draw itself: $3 at 1 : 2 : 3 is $1/$1/$2 there, $4 of a $3 requirement",
+    find: "        const dv =tot('d');",
+    repl: "        const dv =o.frac? SVC.reduce((x,s,i)=>x+Math.round((p.d[i]||0)*o.frac[i]),0) : tot('d');" },
+  { id: "v200-u9-tab-portions-float-split", area: "exportExcel (PMO tabs, by portion)", what: "each PMO tab's by-portion rows split each portion by the offices' fractions: $3 at 1 : 2 : 3 is MxS $0 / AV $1 / TSS $2 there (and an office left with $0 gets no tab)",
+    find: "        const v=o[PART[t]].slice();",
+    repl: "        const v=o.frac? SVC.map(function(s,i){ var sh=SHARES[id], K=sh.findIndex(function(r){ return r[0]===g; }), q=T[id];\n          var V={d:q.d, m:q.m, ask:it.ask, u:SVC.map(function(x,j){ return Math.max(0,(+it.ask[j]||0)-(q.d[j]||0)-(q.m[j]||0)); })}[PART[t]];\n          return apportion(+V[i]||0, sh.map(function(r){ return r[1]? r[1][i] : 1; }))[K]; }) : o[PART[t]].slice();" },
+  { id: "v200-u9-deck-rollup-float-split", area: "exportPPT (Funding by PMO)", what: "the deck's Funding by PMO slide splits each lane itself by the offices' fractions: $3 at 1 : 2 : 3 prints $0/$1/$2",
+    find: "          a.ask+=o.ask[i]; a.d+=o.d[i]; a.m+=o.m[i]; a.u+=o.u[i];",
+    repl: "          const F=(k,v)=>{ if(!o.frac) return o[k][i]; const sh=pmoSharesOf(it), K=sh.findIndex(r=>r[0]===o.g); return apportion(+v||0, sh.map(r=>r[1]? r[1][i] : 1))[K]; };\n          a.ask+=F('ask', it.ask[i]); a.d+=F('d', p.d[i]); a.m+=F('m', p.m[i]); a.u+=F('u', Math.max(0,(+it.ask[i]||0)-(p.d[i]||0)-(p.m[i]||0)));" },
+  { id: "v200-u9-deck-own-rounding", area: "exportPPT (Funding by PMO)", what: "the deck's Funding by PMO slide rounds each office's fraction of the discretionary draw itself: $3 at 1 : 2 : 3 prints $1/$1/$2, $4 of a $3 requirement",
+    find: "          a.ask+=o.ask[i]; a.d+=o.d[i]; a.m+=o.m[i]; a.u+=o.u[i];",
+    repl: "          a.ask+=o.ask[i]; a.d+=(o.frac? Math.round((p.d[i]||0)*o.frac[i]) : o.d[i]); a.m+=o.m[i]; a.u+=o.u[i];" },
+  { id: "v200-u9-weights-first-clin", area: "pmoSharesOf", what: "an office weighs its first CLIN's ask, not its CLINs' asks added up: AV holding 0002 [1] and 0102 [1] weighs 1, and $3 goes AV 1 / MxS 0 / TSS 2",
+    find: "    out.forEach(r=>r.push(r[1].map((f,i)=>(tot[i]>0 && bag[r[0]])? bag[r[0]][i] : f)));",
+    repl: "    const first={}; DATA.clins['PRIME-3'].forEach(c=>{ const s=(''+c.clin).replace(/\\D/g,'');\n      const g=/10$/.test(s)?'MxS':(/8$/.test(s)?'TSS':(/2$/.test(s)?'AV':'PRIMES')); if(!first[g]) first[g]=c.ask; });\n    out.forEach(r=>r.push(r[1].map((f,i)=>(tot[i]>0 && bag[r[0]])? (+first[r[0]][i]||0) : f)));" },
+  { id: "v200-u9-office-ranks-by-last-clin", area: "pmoSharesOf", what: "an office ranks by its last CLIN in the list, not its first: the tie of MxS (0010, then 0110 last) and TSS (0008) goes to TSS",
+    find: "      if(!bag[g]) bag[g]=SVC.map(_=>0);",
+    repl: "      { const prev=bag[g]||SVC.map(_=>0); delete bag[g]; bag[g]=prev; }" },
   // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.
   { id: "v200-r3-landed-view-unsaid", area: "_driveStorePushRun", what: "a folder save that lands while a locked view is on screen says “🔒 Not kept — PB27 is a locked view. ✅ Saved …” again, naming no plan (or, quiet, leaves persist's refusal on screen)",
     find: "  if(CYCVIEW){ _cycRefusedAt=0; setStat('✅ <b>Saved the working plan</b> of '+esc(APPN_LBL[ap]||ap)+' FY'+(fy%100)+' to the shared folder — '\n    +Math.round(body.length/1024)+' KB, built before '+blLbl(CYCVIEW)+' was put on screen. '+blLbl(CYCVIEW)+' is a locked view: nothing in it '\n    +'is saved. Everyone sees the working plan on their next refresh.'+penNote+lateNote); render(); return true; }\n",
```
