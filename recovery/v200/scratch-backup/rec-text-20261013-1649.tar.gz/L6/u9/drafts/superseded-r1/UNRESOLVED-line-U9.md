  - **U9 (P2): built as its own commit** (the lead's decision under Brad's go of 12 Oct, about 5:30 PM ET): the PMO split
    is exact and ties to the office whose first CLIN comes first, the same on the panel, the forecast and its export, the
    Two-Plan Forecast, the PMO Matrix, the CE by PMO sheet, the PMO tabs, the CR view by PMO and the deck (above); at $3
    split 1:2:3, drawn from one lane, each now gives $1/$1/$1, as exact largest-remainder arithmetic and the CLIN source
    workbook do. Still open in the ledger, for Brad: the Spend Plan Source's CLIN lines, added up by office, and the
    by-office split part ways where a service draws from both lanes (even in full: $6 at 1:2:3 as $3 + $3 gives offices
    1/2/3, CLIN lines 2/2/2), an office holds two CLINs, a service is part funded, a CLIN was added on the board, or an
    award comes in increments.
