  - **U9 (P2): built as its own commit** (the lead's decision under Brad's go of 12 Oct, about 5:30 PM ET): the PMO split
    is exact and ties to the office whose first CLIN comes first, the same on the panel, the forecast, the PMO Matrix, the
    PMO tabs and the CR view by PMO (above); at $3 split 1:2:3 each now gives $1/$1/$1, as exact largest-remainder
    arithmetic and the CLIN source workbook do. Still open in the ledger: the Spend Plan Source's CLIN lines, added up by
    office, and the by-office split part ways where an office holds two CLINs, a service is part funded, a CLIN was added on
    the board, or an award comes in increments.
