- **U9 — the PMO split is exact, ties to the first office, and the same on every by-office view** (Brad, 12 Oct, about
  5:30 PM ET: "Don't wait for me. Let's keep pressing throughout to get this next version published."; the lead set U9 among
  the release blockers to fix). A CLIN-split prime (PRIME-3) is shared, service by service, across the offices that own its
  CLINs. Each office's whole dollars were split by its FRACTION of the service (its CLINs' asks over all the CLINs' asks,
  divided in floating point), and 1/6, 2/6 and 3/6 are not exactly 1 : 2 : 3: a tie went to the last office and a near tie
  could go to the wrong one. $3 at 1 : 2 : 3 (MxS, AV, TSS) was $0/$1/$2 on the PMO funding panel, the forecast, the PMO
  Matrix and every other by-office view, where exact largest remainder and the CLIN source workbook (the Spend Plan Source)
  give $1/$1/$1; $9 was $1/$3/$5, not $2/$3/$4. The totals balanced, so nothing called it. Now each office's whole dollars
  are split by its own CLIN asks, exactly, with `apportion()` -- the board's one spreading rule, and the one the Spend Plan
  Source splits a prime's CLINs by: floor every share, then a dollar each to the largest remainders, EQUAL REMAINDERS TO THE
  OFFICE WHOSE FIRST CLIN COMES FIRST IN THE CLIN LIST. A service no CLIN covers stays with the requirement's own office, and
  an amount that is not whole dollars (a modelled plan's) is still each office's fraction of it, both as before.
  - **What users may see:** on a CLIN-split prime, a dollar can move from one office to another where the offices' shares
    tie or nearly tie ($3 at 1 : 2 : 3 is now $1/$1/$1). Every by-office view moves together: the PMO funding panel, the
    forecast and its export, the PMO Matrix, each office's PMO tab and the CR view by PMO. No total changes.
  - **Test:** audit-recon "v2.00 (U9) — the PMO split is exact, ties to the first office, and the same on the panel, the
    forecast and the PMO Matrix" (64 checks), every expected dollar a hand-written literal: $3 at 1 : 2 : 3 and $9 (the
    review's), $999,999,999 (a tie at budget size), $250,000,000 over weights a remainder apart (not a tie), $3 over four
    offices at 1 : 1 : 1 : 3, $3 with one office's share zero, and a service no CLIN covers; a second board whose CLIN list
    puts TSS first, so a tie goes to TSS where the office list and the alphabet would not, with mandatory and unfunded dollars
    and a starred requirement; and a modelled plan's $10.50 kept to the cent. Each is read on the panel as drawn, the forecast
    (each service alone, the whole portfolio and the exported view), the PMO Matrix, each office's PMO tab and the CR view by
    PMO from the workbook's bytes and the board, and the Spend Plan Source's CLIN lines as a control. 36 checks fail on the
    board before the change; every control (28) passes on both.
  - **Mutations:** `v200-u9-split-by-fraction`, `-weights-are-fractions`, `-per-part-rounding`, `-ties-by-name`,
    `-uncovered-weight-dropped`, `-plan-part-by-weight` and `-plan-placed-by-weight`; each caught by the focused block (36,
    36, 29, 13, 9, 1 and 1 failing; full-suite sensitivity runs in the final-tree queue).
  - **Not covered:** the Spend Plan Source still splits each lane, and each dated line, by CLIN on its own, from the CLIN
    list and grid as edited on the board, while the by-office split works from the ask, from the CLINs as shipped. So the
    Spend Plan Source's CLIN lines, added up by office, can differ from an office's part where an office holds two CLINs, a
    service is only part funded, a CLIN was added on the board, or an award comes in increments (measured on the boards
    before and after this change, the same on both; not changed here, and listed for Brad in the ledger).
