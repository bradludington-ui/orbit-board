- **U43 — the PMO funding panel and the CR view by PMO carry every office the money reaches** (found by U9's round-3 money
  review, 13 Oct; the lead, 1:28 PM ET: "fix in the same views as U9 (use `pmoKeys`, as every other by-office view
  does)"). Both views listed only the offices on the PMO list (`GROUPS`), while every other by-office view lists them by
  `pmoKeys`: the list's offices in its order, then any other office that holds dollars. So an office the CLINs name that is
  not on the list (PRIMES, when nothing is homed to it), or one taken off the list while a CLIN still names it, had no row
  in either view, and its dollars were missing from the panel's TOTAL and from the CR view's: PRIME-3 drawing $6 over
  CLINs 0010 / 0002 / 0001 at 1 : 2 : 3 showed MxS $1 and AV $2 and a TOTAL of $3, while the PMO Matrix and the forecast
  showed PRIMES's $3. Now both list their offices by `pmoKeys`, and the panel's TOTAL is what the board draws.
  - **What users may see:** in the PMO funding panel and the CR cash view by PMO, a row for an office that holds dollars
    but is not on the PMO list, after the list's offices, and both views' TOTAL rows counting its dollars. In the panel, an office the CLINs name whose part is $0 now has a row too ("—" and $0 TOTALs), as
    the PMO Matrix already lists it and as an office on the list already had. No other view and no export changes: the PMO
    Matrix, the forecast, the PMO tabs, CE by PMO and the deck already listed every office.
  - **Test:** audit-recon "v2.00 (U43) — the PMO funding panel and the CR view by PMO carry every office the money
    reaches, and the panel TOTAL is the draw" (12 checks), every figure a hand-written literal: board P, PRIMES named by
    CLIN 0001 and not on the list, starred and drawn from both lanes, on the panel's rows and TOTAL, the CR view by PMO and
    its TOTAL against By Service; board Q, TSS taken off the list by its own Remove (pmoDel, the confirm answered yes)
    while CLIN 0008 names it, on the panel and the CR view; the PMO Matrix and the forecast as controls. Every split is
    exact, so the figures do not depend on U9. 6 checks fail on the board before the change, and on the U9 board; every
    control (6) passes on all three.
  - **Mutations:** `v200-u43-panel-rows-list-only`, `-panel-total-list-only` and `-cr-list-only`; each caught by the
    focused block (2, 2 and 3 failing).
  - **Not covered:** the CR view still prints "—" for a cell under $5,000, as before.
