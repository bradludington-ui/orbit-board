# U9, round 3, lens B (test adequacy and regressions): independent adversarial verification

Track U9: the PMO split is exact and the same everywhere (panel, forecast, PMO Matrix export). The builder's result is
`rec/L6/u9/wfstate/fix_u9_r2.json`; its directory is `rec/L6/u9`. This directory is my own work.

- Started 1:24 PM ET on 13 Oct 2026 (`TZ=America/New_York date`). The folder `verify-tests-r3` did not exist, so there was
  no earlier attempt of this review to reuse; every run below is this session's.
- Nothing was edited, staged, committed or pushed in `/home/user/orbit-board` or `/home/user/orbit-ui`. No builder or
  verifier file was edited. `tools/export-audit/mutate.mjs` was only read as TEXT (`rec/bin/mkmut.py`, `rec/bin/mcount.py`,
  `python3 -I`); in my copies it is `mutate.mjs.txt` and it was never imported, run or `node --check`ed.
- The board files stay the empty template; every board is synthetic and built at run time.

## Result (README finished 3:44 PM ET on 13 Oct 2026)

**Verdict: sound with issues -- one must-fix, in the tests only (M1, §5). The board change itself holds on every run I may make.**

- Every builder claim I could re-run reproduces on the same blobs (§1).
- No existing expectation changed: against the base, audit-recon and mutate only add lines (§2).
- Every new expected value is a hand-written literal. Every non-control check fails on the base, and every control passes on
  both boards (§3).
- Ten mutants of my own, each a plausible wrong fix: eight are caught. **Two survive every check I may run:** the offices'
  fractions rounded to 14 places, and rounded to 10. Each moves a dollar between offices on ordinary boards ($7 over CLIN asks
  3 : 7 : 4; $651 over 213 : 235 : 854). This is M1.
- M1 comes with a tested fix, `p1/`: board H (+28 lines in the existing block) and two mutation entries. With it, both
  survivors are caught and p1's full audit-recon passes on c1.
- Every other suite I may run gives the same verdict on c1 as on the base (§6).
- **Resumed session.** The first attempt (from 1:24 PM ET) was stopped by the usage limit at about 2:29 PM ET. I resumed at
  2:44 PM ET. None of its processes was still running, and every blob was unchanged. Every run of the first attempt that
  has an exit record is reused, and the rest were re-run: base audit-recon, base audit-hostile, the full audit-recon
  sensitivity runs on the two survivors, and p1's full audit-recon.

## Identities (git hash-object)

| file | base (`rec/L6/base` = 7ee498a) | c1 (builder, round 2) | p1 (mine = c1 + board H + 2 entries) |
|---|---|---|---|
| prioritization-board-grid.html | fce8a391 | 46e522a8370f05971c8ef0558c3c666b0953b0ac | 46e522a8 (unchanged) |
| tools/export-audit/audit-recon.mjs | 529e36f7 | 755647cc1340cd2d9ed2b8a78b58f29df4b98b34 | 4cfe7d28735af8a36d4616d1ff8766fc5b438224 |
| tools/export-audit/mutate.mjs(.txt) | cbc6defc | 8fd34e940548e009efb812021792d8667c91fc54 | 885a9bf9cc006de4da0b0ddb7f500f3224a2466c |
| every other file | | identical to base (`diff -rq --no-dereference`) | identical to c1 |

- `base/` and `c1/` here are `cp -a` copies (node_modules symlink kept, `chmod u+w`), byte-identical to `rec/L6/base` and
  `rec/L6/u9/c1` (`diff -r --no-dereference`, 1:26 PM ET).
- orbit-board HEAD at 2:13 PM ET is 191daf0 (records only): `git diff --stat 7ee498a HEAD -- prioritization-board-grid.html
  tools package.json` is empty, and HEAD's board / audit-recon / mutate are fce8a391 / 529e36f7 / cbc6defc.
- Diffs, base to c1 (`diffs/`): board `c1-vs-base.prioritization-board-grid.html.diff` (173e27ff, +13/−4), audit-recon
  `c1-vs-base.audit-recon.mjs.diff` (fa48da69, +399/−0 counting blank lines; 392 non-blank), mutate
  `c1-vs-base.mutate.mjs.txt.diff` (06012fbc, +71/−0).
- Diffs, c1 to p1: `p1-vs-c1.audit-recon.diff` (b3129de9, +28/−0), `p1-vs-c1.mutate.diff` (756fdbc2, +8/−0).

## 1. The builder's runs, re-run and compared

Every builder claim I could re-run was re-run on the same blobs. All agree.

| builder's claim | my run(s) | result |
|---|---|---|
| focused U9 blocks on c1: 89/89 | `f-c1` (1:27:46 PM ET, exit 0, 18.0 s) | 89/89; 38/38 controls |
| on the base: 51 fail, every non-control; 38 controls pass | `f-base` (1:28:04 PM ET, exit 1, 21.0 s) | 51 fail (all 51 non-controls), 38/38 controls pass |
| the harness is verbatim from c1's audit-recon | rebuilt with the builder's `mkfocused-u9-r1.py` from my c1 copy | blob 31315c7f, byte-identical to the builder's `harness/r2/focused-u9.mjs`; every line after line 1 is in c1's audit-recon (0 not found) |
| check-by-check results | `out/f-c1.checks.jsonl`, `out/f-base.checks.jsonl` against the builder's `out/r2f-*.checks.jsonl` | identical row for row, observed values included |
| 21 mutants caught, failing 51, 51, 42, 13, 9, 1, 1, 2, 1, 3, 2, 1, 2, 2, 1, 1, 1, 1, 1, 1, 2 | `bm-*` (1:30:01 to 1:36:44 PM ET; three bounded loops, PIDs recorded) | the same 21 counts, each exit 1 (`out/bm-summary.txt`); every mutant built by `rec/bin/mkmut.py` from c1's mutate TEXT is byte-identical to the builder's `mut/r2/*` (`out/mutant-blobs-b.txt`) |
| mcount: c1 1349/1349, base 1328/1328 | `rec/bin/mcount.py`, text only, `python3 -I` | the same; no entry missing, multiple or unparsed (`out/mcount-c1.txt`, `out/mcount-base.txt`) |
| entries sit before the R3 line | grep | c1 lines 4290–4356; the R3 line is 4359 |
| boot-same "identical either way" before and after | `s-base-boot-same` (1:43:14 PM ET, exit 0, 41.0 s), `s-c1-boot-same` (1:43:55 PM ET, exit 0, 53.6 s) | both "every page, source, save and error list is identical either way" |
| the audit-board PRIME-3 scenarios (focused, verbatim) pass on both | `fb-c1` (2:01:21 PM ET, exit 0, 26.4 s), `fb-base` (2:01:48 PM ET, exit 0, 31.2 s); harness rebuilt with the builder's `mkfocused-board.py` (92dafb85; identical to the builder's after line 1; 0 lines not in c1's audit-board) | 33/33 on both |
| npm run check passes and the money map holds, before and after | my scratch clone `gc/` (`git clone --shared`, detached at 7ee498a; never committed): `check-base`, `moneymap-base`, then c1's board and audit-recon copied in: `check-c1`, `moneymap-c1` (2:14:23 to 2:14:56 PM ET, all exit 0) | "all checks passed" on both; "money map holds — 329 cells: 123 proven, 206 n/a, 0 open; the report is current" on both. Restored with `git checkout --` (bounded, PID recorded, exit 0): fce8a391 / 529e36f7 again, only `?? node_modules` untracked. mutate.mjs was not copied in (neither tool reads it) |
| full audit-recon passes on c1 | `s-c1-audit-recon-2` (2:12:33 PM ET, exit 0, 593.0 s) | ALL CHECKS PASSED. (My first attempt, `s-c1-audit-recon`, 2:01:03 PM ET, was OOM-killed by the shared memory cgroup at 593.9 s, exit 137 — dmesg: "Memory cgroup out of memory: Killed process 26002 (node)", my recorded PID — so it was re-run, not counted.) |

## 2. Suites against the base: no existing expectation changed

- audit-recon: one hunk, `@@ -5123,6 +5123,405 @@`, lines only added (the two U9 blocks and their markers, after
  "// ==== end v2.00 (U14) ====" and before the scenario-ran guard). No line of the base removed or changed.
- mutate.mjs.txt: one hunk, `@@ -4285,6 +4285,77 @@`, lines only added: 21 entries and their comments, before the line
  "  // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan." (base line 4288,
  c1 line 4359).
- audit, audit-other, audit-board, audit-import, audit-ppt, audit-hostile, audit-inject, legacy-fsrc, boot-same, boot.mjs,
  package.json: byte-identical to base.
- **So there is no changed existing expectation to list.**

## 3. Literals, and failing on the base

- **Every expected value in both blocks is a hand-written literal**, or a test-side arrangement of literals (A's per-service
  table and `AT`; B's per-office object; `DD`/`DM`/`DT`; E's `[1, 1, 1]`; F's and G's arrays; C's `'1.75'`/`'3.5'`/`'5.25'`;
  the Two-Plan `[[3, 4], [4, 5], [5, 6]]`). Board helpers are read only for OBSERVED values (`pmoPartsOf` in C's control,
  `FYL()` only to name a column). `pr`/`prT` are the test's own formatters.
- **My own oracle** (`bin/oracle.py`, c288bbb9; exact integers; written from the stated rule, not from the builder's
  `exact-r2.py`; `out/oracle.txt`) re-derives every literal of boards A, B, D (and its Two-Plan totals), E, F (tabs, CE by
  PMO, Matrix, panel) and G. All match. G is a true exact tie (2 × 779,153,421 = 1,558,306,842, the CLIN asks' sum);
  STOVL's remainders are 299,375,018 / 299,375,019 / 1,249,964 over 600,000,001, one apart, as the header says.
- **Every non-control check fails on the base and every CONTROL passes on both**: focused runs f-c1 (89/89) and f-base
  (51 fail, all 51 non-controls; 38/38 controls pass). My `out/f-*.checks.jsonl` are row-for-row identical, values included,
  to the builder's `out/r2f-*.checks.jsonl`.
- No check can pass vacuously: a missing row, column, tab, sheet or deck table yields `null`, `'no row …'`, `'no column …'`
  or `''`, none of which equals its literal.

## 4. My own mutants (10, each a plausible wrong fix of the finding)

Built by `bin/mymut.py` (27cfa159) as find/repl on c1's board; each find matches exactly once (`out/mutant-blobs-own.txt`).
Run through c1's two U9 blocks (the focused harness, verbatim). "Survives" = 89/89 pass.

| mutant | the wrong fix | c1's U9 blocks | caught by |
|---|---|---|---|
| vt3-ties-to-last | exact weights, a tie to the LAST office | caught (48) | A, B, D, … |
| vt3-ties-to-biggest | exact weights, a tie to the office with the bigger weight | caught (46) | A, B, D, … |
| vt3-clins-sorted | offices ranked by their CLIN numbers sorted, not the CLIN list's order | caught (35, 1 control) | A, E |
| vt3-last-takes-rounding | each office's ask rounded on its own, the last office takes the rest | caught (21) | A (USMC-C, STOVL), B |
| vt3-frac-fixed12 | weights = fractions rounded to 12 places | caught (11) | A's STOVL and G only |
| vt3-frac-per-billion | weights = round(fraction × 1e9) | caught (11) | A's STOVL and G only |
| vt3-per-lane-exact | each lane split by the CLIN asks on its own (the Spend Plan Source's way), no ask stage | caught (8) | B's AFRC, F |
| vt3-land-to-rounded-fraction | placements (forecast, CR view, tabs' months) split toward each office's rounded fraction, not its part | caught (5) | A's STOVL, G (forecast only) |
| **vt3-frac-fixed14** | weights = fractions rounded to **14** places | **survives (89/89)** | — |
| **vt3-frac-fixed10** | weights = fractions rounded to **10** places | **survives (89/89)** | — |

- Runs `om-*`, 1:37:42 to 1:41:20 PM ET, two bounded loops (`out/om-summary.txt`, failing checks per mutant in
  `out/om-<id>.checks.jsonl`).
- **Why I looked at the rounded-fraction family.** It is the most natural wrong fix of the finding's stated cause ("1/6, 2/6
  and 3/6 in floating point are not exactly 1 : 2 : 3"): keep the fractions, round the noise away. Before building
  mutants I emulated it (`bin/variants.py`, fdf10380: `pmoPartsOf`'s two stages over the doubles JS would hold, exact
  arithmetic after that; `out/variants.txt`) against boards A, B, D, E, F, G. Its prediction — toFixed(10), toFixed(14),
  round(frac × 1e10)/1e10 and round(frac × 1e14) pass all six boards; toFixed(12), round(frac × 1e9) and the rest do
  not — was then confirmed on the real board for the four I built (fixed10 and fixed14 survive; fixed12 and per-billion
  are caught, by A's STOVL and G only).
- `round(frac × tot)` also passes every board, but it is not a wrong fix: for CLIN totals below about 4.5e15 the product
  is within half a dollar of the CLIN asks, so it rounds back to them exactly (equivalent; not counted).
- **The survivors are not equivalent.** `bin/search.py` (38d82eb0; `out/search.txt`) finds, and the real board confirms
  (p1 runs below):
  - fractions to 14 places: **$7 over CLIN asks 3 : 7 : 4** — exact 1.5 / 3.5 / 2, the tie is MxS's = 2 / 3 / 2; the
    mutant gives **1 / 4 / 2** (3/14 rounds down, 4/14 rounds up).
  - fractions to 10 places: **$651 over 213 : 235 : 854** — exact 106.5 / 117.5 / 427 = 107 / 117 / 427; the mutant gives
    **106 / 118 / 427**.
  - and one case that every rounded-fraction rule tried (toFixed(1..17), round(frac × 1e1..1e17) with and without the
    divide-back, fraction × total, the base's own fractions) gets wrong: **$93,622,850 over 52,761,234 : 86,085,305 :
    48,399,161** (exactly half the asks; AV's and TSS's parts end in .5; the tie is AV's) = 26,380,617 / 43,042,653 /
    24,199,580; every variant gives 26,380,617 / 43,042,652 / 24,199,581 or worse (`out/boardh.txt`, `bin/boardh.py`
    6e01b591).

## 5. Must-fix M1: two plausible wrong fixes of the tie rule survive every check

**Defect (tests).** U9's rule is "one exact apportionment … the parts always sum exactly … every surface and export
agrees to the cent", with mutations that "break the tie rule" caught. Two plausible wrong fixes of exactly that rule —
the offices' fractions rounded to 14 places, or to 10 — pass all 89 U9 checks and every other suite and focused harness
I may run, yet each moves a dollar from one office to another on ordinary boards (the $7 and $651 cases above), on the
panel, the forecast and its export, the PMO Matrix, the PMO tabs, CE by PMO, the CR view and the deck alike (they all
read `pmoPartsOf`). The blocks hold the exact rule against the base's fractions and against fraction × total, but only two
inputs (A's STOVL near tie and G's budget-size tie) stand between the suite and the whole rounded-fraction family, and
which digits they happen to catch is luck.

**Reproduction.**
- `mut/own/vt3-frac-fixed14.html` (e7baef1f) is c1 with one line changed:
  `  const wOf=i=> sh.map(function(x){ return x[1]? +(+x[1][i]||0).toFixed(14) : 1; });` (and `vt3-frac-fixed10`,
  a3ba9b9c, the same with 10).
- Both U9 blocks: 89/89 pass on each (`om-vt3-frac-fixed14`, `om-vt3-frac-fixed10`, 1:38 PM ET, exit 0).
- c1's audit, audit-ppt and audit-other with BOARD = each mutant: ALL CHECKS PASSED, exit 0 (`ms-*`, 1:50–2:00 PM ET);
  audit-board's PRIME-3 scenarios (focused, verbatim): 33/33 on each (`fb-vt3-*`, 2:02 PM ET).
  - **c1's full audit-recon** (the suite that owns both U9 blocks, every block of it) with BOARD = `vt3-frac-fixed10`:
    **ALL CHECKS PASSED**, exit 0 (`ms-vt3-frac-fixed10-audit-recon`, 2:54:59 PM ET, 515.5 s).
  - With BOARD = `vt3-frac-fixed14`: **ALL CHECKS PASSED**, exit 0 (`ms-vt3-frac-fixed14-audit-recon-4`, 3:34:24 PM ET, 563.8 s). The three earlier attempts of the same run did not finish, and none is a result: `-audit-recon` (2:51:44 PM ET) and `-3` (3:14:08 PM ET) were killed by the shared memory cgroup (exit 137; dmesg names my recorded PIDs 12854 and 7279), and `-2` (3:03:47 PM ET) hit the 600 s cap under load 40 (exit 124).
  - **So the two survivors pass every suite and focused harness I may run: the whole of audit-recon, audit, audit-ppt,
    audit-other and audit-board's PRIME-3 scenarios.**
- `BOARD` is honoured by these suites: the same audit run with BOARD pointing at a missing file exits 1 at once
  (`sanity-audit-missing-board`).
- On the real board the mutants print what the emulation says: fixed14 USAF 1 / 4 / 2 for $7 at 3 : 7 : 4, fixed10 ANG
  106 / 118 / 427 for $651 at 213 : 235 : 854 (`pm-*` logs below).

**Minimal fix (tests only; board unchanged; built and run in `p1/`).**
1. **Board H** at the end of "v2.00 (U9, every export)", after board G's last check and inside the same `try`
   (`proposal/board-h.mjs.txt`, b7d69529; 1 blank + 23 lines): CLINs 0010 / 0002 / 0008 asking USAF 3 : 7 : 4, ANG
   213 : 235 : 854, AFRC 52,761,234 : 86,085,305 : 48,399,161; PRIME-3 draws USAF $7, ANG $651, AFRC $93,622,850,
   discretionary. Four checks:
   - `H · fixture` (CONTROL);
   - `H · the PMO Matrix`, USAF / ANG / AFRC Disc by office = `[[2, 107, 26380617], [3, 117, 43042653], [2, 427, 24199580]]`;
   - `H · the forecast`, whole portfolio = `[26380726, 43042773, 24200009]`;
   - `H · the Spend Plan Source` (CONTROL): `{ '0010': 26380726, '0002': 43042773, '0008': 24200009 }`.
   Every figure is a hand-written literal, re-derived by `bin/oracle.py`'s rule in `bin/boardh.py`.
2. **Header**: three lines for board H after G's paragraph, and one after "and G was …" giving H's figures on the base
   (`proposal/header-h.txt` ccb92669, `proposal/header-h-base.txt` 40098bf4).
3. **Two mutation entries** before the R3 line (`proposal/mutate-entries-h.txt`, ac22f37b):
   `v200-u9-weights-fixed14` and `v200-u9-weights-fixed10` (find = the c1 `wOf` line, shared with
   `v200-u9-split-by-fraction`, as several U9 entries already share a find).
- Inserted by `bin/mkp1.py` (e34dbb38), which asserts each anchor matches exactly once; p1 only adds lines to c1
  (`diffs/p1-vs-c1.audit-recon.diff` +28/−0, `diffs/p1-vs-c1.mutate.diff` +8/−0).

**Results on p1** (focused harness `harness/p1/focused-u9-p1.mjs`, 61d5614f, built the same way from p1's audit-recon):

| run | result |
|---|---|
| `p1f-c1` (1:46:33 PM ET, exit 0, 44.9 s) | 93/93; controls 40/40 |
| `p1f-base` (1:47:18 PM ET, exit 1, 44.2 s) | 53 fail = every non-control (the 51 + `H · the PMO Matrix` + `H · the forecast`); 40/40 controls pass. Base gave `[[1,107,26380617],[4,117,43042652],[2,427,24199581]]` and `[26380725,43042773,24200010]` |
| `pm-v200-u9-weights-fixed14` (1:48:15 PM ET, exit 1, 56.5 s) | caught, 2 failing: H · the PMO Matrix (got `[[1,107,26380617],[4,117,43042652],[2,427,24199581]]`), H · the forecast (got `[26380725,43042773,24200010]`) |
| `pm-v200-u9-weights-fixed10` (1:49:12 PM ET, exit 1, 48.8 s) | caught, 2 failing: H · the PMO Matrix (got `[[2,106,26380617],[3,118,43042652],[2,427,24199581]]`), H · the forecast |
| mutants from p1's mutate TEXT (`mkmut.py`) | byte-identical to my `vt3-frac-fixed14` / `vt3-frac-fixed10` |
| mcount on p1 (text) | 1351 / 1351 once; none missing, multiple or unparsed (`out/mcount-p1.txt`) |
| `s-p1-audit-recon` (3:24:17 PM ET, exit 0, 598.5 s) | p1's **full** audit-recon on the c1 board: ALL CHECKS PASSED. Board H adds no failure anywhere in the suite |

Adding checks at the end of the block's `try` cannot uncatch any mutant (a check only adds failures; a throw is recorded
as a failure), so the 21 builder entries and my 8 caught mutants stay caught on p1.

**If the lead takes p1, the drafts change by these counts only** (the wording is the builder's):
- NEXT-VERSION Test bullet: "(24 checks)" → "(28 checks)"; after "… which weights rebuilt from the fractions get wrong" add
  "; and exact ties whose fractions do not end ($7 at 3 : 7 : 4, $651 at 213 : 235 : 854, $93,622,850 over CLIN asks in
  the tens of millions), which fractions rounded to any number of places get wrong"; add "board H (those ties) on the
  PMO Matrix and the forecast;" after board G's; "51 checks fail … every control (38)" → "53 … (40)".
- Mutations: add `-weights-fixed14` and `-weights-fixed10`, "(… 1, 1 and 2 failing" → "(… 1, 1, 2, 2 and 2 failing".
- Ledger append: "Two focused blocks (89 checks; …" → "(93 checks; …, and exact ties whose fractions do not end"; "51
  fail … every control (38)" → "53 … (40)"; "Twenty-one mutations caught (…, 2 failing)" → "Twenty-three … (…, 2, 2, 2
  failing)"; "mcount 1349/1349" → "1351/1351"; the audit-recon / mutate blobs → p1's (4cfe7d28 / 885a9bf9).

## 6. Other suites on the final copy, and against the base

Final copy = c1 (the builder's). If the lead takes p1, only audit-recon and mutate change, and p1's full audit-recon is
above. "Same" means the same verdict line.

| suite | base (fce8a391 / 529e36f7) | c1 (46e522a8 / 755647cc) | same? |
|---|---|---|---|
| audit-recon (owns U9), full | `s-base-audit-recon-3` 2:47:00 PM ET, exit 0, 468.0 s: ALL CHECKS PASSED | `s-c1-audit-recon-2` 2:12:33 PM ET, exit 0, 593.0 s: ALL CHECKS PASSED | yes |
| audit | `s-base-audit` 2:04:49 PM ET, exit 0, 46.1 s | `s-c1-audit` 2:03:23 PM ET, exit 0, 46.7 s | yes (ALL CHECKS PASSED) |
| audit-ppt | `s-base-audit-ppt` 2:05:36 PM ET, exit 0, 23.7 s | `s-c1-audit-ppt` 2:04:10 PM ET, exit 0, 24.2 s | yes |
| audit-other | `s-base-audit-other` 2:09:06 PM ET, exit 0, 189.9 s | `s-c1-audit-other` 2:06:22 PM ET, exit 0, 163.5 s | yes |
| legacy-fsrc | `s-base-legacy-fsrc` 2:05:59 PM ET, exit 0, 17.6 s | `s-c1-legacy-fsrc` 2:04:34 PM ET, exit 0, 15.3 s | yes ("every legacy Force setting computes exactly as before") |
| audit-inject | `s-base-audit-inject` 2:16:24 PM ET, exit 0, 61.1 s | `s-c1-audit-inject` 2:15:16 PM ET, exit 0, 67.4 s | yes (44 findings, 4 guards, all clear) |
| audit-hostile | `s-base-audit-hostile` 2:47:01 PM ET, exit 0, 277.1 s | `s-c1-audit-hostile` 2:23:47 PM ET, exit 0, 348.5 s | yes |
| boot-same | `s-base-boot-same` 1:43:14 PM ET, exit 0, 41.0 s | `s-c1-boot-same` 1:43:55 PM ET, exit 0, 53.6 s | yes ("identical either way") |
| npm run check (`tools/check.mjs`), scratch clone `gc/` | `check-base` 2:14:23 PM ET, exit 0 | `check-c1` 2:14:38 PM ET, exit 0 | yes ("all checks passed") |
| money map (`money-map.mjs --check`) | `moneymap-base` 2:14:37 PM ET, exit 0 | `moneymap-c1` 2:14:56 PM ET, exit 0 | yes (329 cells, 0 open) |
| audit-board PRIME-3 scenarios (focused, verbatim) | `fb-base` 2:01:48 PM ET, exit 0: 33/33 | `fb-c1` 2:01:21 PM ET, exit 0: 33/33 | yes |
| U9 blocks (focused, verbatim) | `f-base` 1:28:04 PM ET, exit 1: 51 fail (every non-control) | `f-c1` 1:27:46 PM ET, exit 0: 89/89 | as intended |

- audit-import and audit-board in full were not run; the lead runs those. audit-import does not read the PMO split: it has
  no `pmoPartsOf`, `pmoSharesOf`, `byPMO`, PMO Matrix or CLIN fixture (grep). audit-board's PRIME-3 scenarios were run
  focused (above).
- The c1 suite on the base board, in full, was not re-run by me. The builder's `s-r2c1suite-baseboard-audit-recon` and the
  money verifier's round-3 run both give exactly 51 failing, all in the U9 blocks. My focused `f-base` gives the same 51.

## 7. How the lead's principles bear on what I found

1. **Never lose a copy.** Not engaged by the tests; the board change writes nothing to state (lens A's ground).
2. **Refuse or ask rather than guess.** The suites cannot today tell the exact rule from "fractions rounded to 10 or 14
   places", so a future edit could guess wrong silently. Board H removes that.
3. **Money and every export match the computation exactly.** Held for every case the blocks read; not held against the
   rounded-fraction family (M1) until board H is in.
4. **Every word true.** The builder's README says the weights are "held at budget size, on an exact tie that
   fraction × total gets wrong" (true) — but its summary also reads as if the exact rule is pinned; it is pinned against
   fraction × total and fractions, not against fractions rounded to 10 or 14 places. Drafts are corrected below if H goes in.
5. **Smallest change.** p1 is tests only: +28 lines in the existing block, +8 lines (2 entries) in mutate. Board unchanged.
6. **Every existing check preserved.** p1 only adds lines to c1 (and c1 only adds to base).

## 8. Runs (every node run through `run.sh`: `setsid -w timeout -k 10 600`, the lock checked before each, PIDs in `pids.txt`)

Every row of `logs/runs.txt`, in the order recorded (times are when each run started, ET). A note row is a line I wrote
there. A run with exit 124 or 137 hit its cap or was killed by the shared memory cgroup. Each was re-run and none
is counted as a result.

| label | start (ET) | exit | wall s | log | note |
|---|---|---|---|---|---|
| R3 runs (from Tue Oct 13 13:27:46 EDT 2026) | | | | | |
| `f-c1` | 2026-10-13 13:27:46 EDT | 0 | 18.0 | `logs/f-c1.log` |  |
| `f-base` | 2026-10-13 13:28:04 EDT | 1 | 21.0 | `logs/f-base.log` |  |
| `bm-v200-u9-split-by-fraction` | 2026-10-13 13:30:01 EDT | 1 | 18.9 | `logs/bm-v200-u9-split-by-fraction.log` |  |
| `bm-v200-u9-weights-are-fractions` | 2026-10-13 13:30:20 EDT | 1 | 16.2 | `logs/bm-v200-u9-weights-are-fractions.log` |  |
| `bm-v200-u9-per-part-rounding` | 2026-10-13 13:30:37 EDT | 1 | 13.4 | `logs/bm-v200-u9-per-part-rounding.log` |  |
| `bm-v200-u9-ties-by-name` | 2026-10-13 13:30:50 EDT | 1 | 13.9 | `logs/bm-v200-u9-ties-by-name.log` |  |
| `bm-v200-u9-uncovered-weight-dropped` | 2026-10-13 13:31:04 EDT | 1 | 10.9 | `logs/bm-v200-u9-uncovered-weight-dropped.log` |  |
| `bm-v200-u9-plan-part-by-weight` | 2026-10-13 13:31:15 EDT | 1 | 11.8 | `logs/bm-v200-u9-plan-part-by-weight.log` |  |
| `bm-v200-u9-plan-placed-by-weight` | 2026-10-13 13:31:27 EDT | 1 | 19.8 | `logs/bm-v200-u9-plan-placed-by-weight.log` |  |
| `bm-v200-u9-cebypmo-float-split` | 2026-10-13 13:31:52 EDT | 1 | 17.2 | `logs/bm-v200-u9-cebypmo-float-split.log` |  |
| `bm-v200-u9-cebypmo-own-rounding` | 2026-10-13 13:32:09 EDT | 1 | 22.7 | `logs/bm-v200-u9-cebypmo-own-rounding.log` |  |
| `bm-v200-u9-tab-portions-float-split` | 2026-10-13 13:32:32 EDT | 1 | 24.2 | `logs/bm-v200-u9-tab-portions-float-split.log` |  |
| `bm-v200-u9-deck-rollup-float-split` | 2026-10-13 13:32:56 EDT | 1 | 21.3 | `logs/bm-v200-u9-deck-rollup-float-split.log` |  |
| `bm-v200-u9-deck-own-rounding` | 2026-10-13 13:33:17 EDT | 1 | 22.0 | `logs/bm-v200-u9-deck-own-rounding.log` |  |
| `bm-v200-u9-weights-first-clin` | 2026-10-13 13:33:40 EDT | 1 | 20.7 | `logs/bm-v200-u9-weights-first-clin.log` |  |
| `bm-v200-u9-office-ranks-by-last-clin` | 2026-10-13 13:34:01 EDT | 1 | 23.3 | `logs/bm-v200-u9-office-ranks-by-last-clin.log` |  |
| `bm-v200-u9-tab-memo-float-split` | 2026-10-13 13:34:29 EDT | 1 | 23.9 | `logs/bm-v200-u9-tab-memo-float-split.log` |  |
| `bm-v200-u9-tab-unf-float-split` | 2026-10-13 13:34:53 EDT | 1 | 20.5 | `logs/bm-v200-u9-tab-unf-float-split.log` |  |
| `bm-v200-u9-deck-mc-float-split` | 2026-10-13 13:35:14 EDT | 1 | 16.9 | `logs/bm-v200-u9-deck-mc-float-split.log` |  |
| `bm-v200-u9-cebypmo-mcs-float-split` | 2026-10-13 13:35:31 EDT | 1 | 23.5 | `logs/bm-v200-u9-cebypmo-mcs-float-split.log` |  |
| `bm-v200-u9-matrix-mcs-own-rounding` | 2026-10-13 13:35:54 EDT | 1 | 25.7 | `logs/bm-v200-u9-matrix-mcs-own-rounding.log` |  |
| `bm-v200-u9-panel-mc-own-rounding` | 2026-10-13 13:36:20 EDT | 1 | 24.0 | `logs/bm-v200-u9-panel-mc-own-rounding.log` |  |
| `bm-v200-u9-weights-frac-times-tot` | 2026-10-13 13:36:44 EDT | 1 | 21.5 | `logs/bm-v200-u9-weights-frac-times-tot.log` |  |
| `om-vt3-clins-sorted` | 2026-10-13 13:37:42 EDT | 1 | 23.1 | `logs/om-vt3-clins-sorted.log` |  |
| `om-vt3-frac-fixed10` | 2026-10-13 13:38:05 EDT | 0 | 13.6 | `logs/om-vt3-frac-fixed10.log` |  |
| `om-vt3-frac-fixed12` | 2026-10-13 13:38:19 EDT | 1 | 15.0 | `logs/om-vt3-frac-fixed12.log` |  |
| `om-vt3-frac-fixed14` | 2026-10-13 13:38:34 EDT | 0 | 20.4 | `logs/om-vt3-frac-fixed14.log` |  |
| `om-vt3-frac-per-billion` | 2026-10-13 13:38:54 EDT | 1 | 22.9 | `logs/om-vt3-frac-per-billion.log` |  |
| `om-vt3-land-to-rounded-fraction` | 2026-10-13 13:39:22 EDT | 1 | 23.4 | `logs/om-vt3-land-to-rounded-fraction.log` |  |
| `om-vt3-last-takes-rounding` | 2026-10-13 13:39:46 EDT | 1 | 26.0 | `logs/om-vt3-last-takes-rounding.log` |  |
| `om-vt3-per-lane-exact` | 2026-10-13 13:40:12 EDT | 1 | 30.7 | `logs/om-vt3-per-lane-exact.log` |  |
| `om-vt3-ties-to-biggest` | 2026-10-13 13:40:43 EDT | 1 | 36.5 | `logs/om-vt3-ties-to-biggest.log` |  |
| `om-vt3-ties-to-last` | 2026-10-13 13:41:20 EDT | 1 | 37.8 | `logs/om-vt3-ties-to-last.log` |  |
| `s-base-boot-same` | 2026-10-13 13:43:14 EDT | 0 | 41.0 | `logs/s-base-boot-same.log` |  |
| `s-c1-boot-same` | 2026-10-13 13:43:55 EDT | 0 | 53.6 | `logs/s-c1-boot-same.log` |  |
| `p1f-c1` | 2026-10-13 13:46:33 EDT | 0 | 44.9 | `logs/p1f-c1.log` |  |
| `p1f-base` | 2026-10-13 13:47:18 EDT | 1 | 44.2 | `logs/p1f-base.log` |  |
| `pm-v200-u9-weights-fixed14` | 2026-10-13 13:48:15 EDT | 1 | 56.5 | `logs/pm-v200-u9-weights-fixed14.log` |  |
| `pm-v200-u9-weights-fixed10` | 2026-10-13 13:49:12 EDT | 1 | 48.8 | `logs/pm-v200-u9-weights-fixed10.log` |  |
| `ms-vt3-frac-fixed14-audit` | 2026-10-13 13:50:36 EDT | 0 | 67.9 | `logs/ms-vt3-frac-fixed14-audit.log` |  |
| `ms-vt3-frac-fixed14-audit-ppt` | 2026-10-13 13:51:44 EDT | 0 | 39.3 | `logs/ms-vt3-frac-fixed14-audit-ppt.log` |  |
| `ms-vt3-frac-fixed10-audit` | 2026-10-13 13:52:24 EDT | 0 | 65.4 | `logs/ms-vt3-frac-fixed10-audit.log` |  |
| `ms-vt3-frac-fixed10-audit-ppt` | 2026-10-13 13:53:29 EDT | 0 | 36.0 | `logs/ms-vt3-frac-fixed10-audit-ppt.log` |  |
| `sanity-audit-missing-board` | 2026-10-13 13:54:21 EDT | 1 | 4.4 | `logs/sanity-audit-missing-board.log` |  |
| `s-base-audit-recon` | 2026-10-13 13:44:58 EDT | 124 | 601.9 | `logs/s-base-audit-recon.log` | TIMED OUT = incomplete |
| `ms-vt3-frac-fixed14-audit-other` | 2026-10-13 13:54:26 EDT | 0 | 197.4 | `logs/ms-vt3-frac-fixed14-audit-other.log` |  |
| `ms-vt3-frac-fixed10-audit-other` | 2026-10-13 13:57:44 EDT | 0 | 182.1 | `logs/ms-vt3-frac-fixed10-audit-other.log` |  |
| `fb-c1` | 2026-10-13 14:01:21 EDT | 0 | 26.4 | `logs/fb-c1.log` |  |
| `fb-base` | 2026-10-13 14:01:48 EDT | 0 | 31.2 | `logs/fb-base.log` |  |
| `fb-vt3-frac-fixed14` | 2026-10-13 14:02:19 EDT | 0 | 27.3 | `logs/fb-vt3-frac-fixed14.log` |  |
| `fb-vt3-frac-fixed10` | 2026-10-13 14:02:47 EDT | 0 | 28.3 | `logs/fb-vt3-frac-fixed10.log` |  |
| `s-c1-audit` | 2026-10-13 14:03:23 EDT | 0 | 46.7 | `logs/s-c1-audit.log` |  |
| `s-c1-audit-ppt` | 2026-10-13 14:04:10 EDT | 0 | 24.2 | `logs/s-c1-audit-ppt.log` |  |
| `s-c1-legacy-fsrc` | 2026-10-13 14:04:34 EDT | 0 | 15.3 | `logs/s-c1-legacy-fsrc.log` |  |
| `s-base-audit` | 2026-10-13 14:04:49 EDT | 0 | 46.1 | `logs/s-base-audit.log` |  |
| `s-base-audit-ppt` | 2026-10-13 14:05:36 EDT | 0 | 23.7 | `logs/s-base-audit-ppt.log` |  |
| `s-base-legacy-fsrc` | 2026-10-13 14:05:59 EDT | 0 | 17.6 | `logs/s-base-legacy-fsrc.log` |  |
| `s-c1-audit-other` | 2026-10-13 14:06:22 EDT | 0 | 163.5 | `logs/s-c1-audit-other.log` |  |
| `s-c1-audit-recon` | 2026-10-13 14:01:03 EDT | 137 | 593.9 | `logs/s-c1-audit-recon.log` | TIMED OUT = incomplete |
| `s-base-audit-other` | 2026-10-13 14:09:06 EDT | 0 | 189.9 | `logs/s-base-audit-other.log` |  |
| `check-base` | 2026-10-13 14:14:23 EDT | 0 | 14.4 | `logs/check-base.log` |  |
| `moneymap-base` | 2026-10-13 14:14:37 EDT | 0 | 0.7 | `logs/moneymap-base.log` |  |
| `check-c1` | 2026-10-13 14:14:38 EDT | 0 | 17.5 | `logs/check-c1.log` |  |
| `moneymap-c1` | 2026-10-13 14:14:56 EDT | 0 | 0.9 | `logs/moneymap-c1.log` |  |
| `s-c1-audit-inject` | 2026-10-13 14:15:16 EDT | 0 | 67.4 | `logs/s-c1-audit-inject.log` |  |
| `s-base-audit-inject` | 2026-10-13 14:16:24 EDT | 0 | 61.1 | `logs/s-base-audit-inject.log` |  |
| `s-c1-audit-recon-2` | 2026-10-13 14:12:33 EDT | 0 | 593.0 | `logs/s-c1-audit-recon-2.log` |  |
| `s-c1-audit-hostile` | 2026-10-13 14:23:47 EDT | 0 | 348.5 | `logs/s-c1-audit-hostile.log` |  |
| RESUME (from Tue Oct 13 14:46:46 EDT 2026): s-base-audit-recon-2 (2:22:40 PM ET) has no exit record (stopped by the usage limit); re-run | | | | | |
| `s-base-audit-hostile` | 2026-10-13 14:47:01 EDT | 0 | 277.1 | `logs/s-base-audit-hostile.log` |  |
| `s-base-audit-recon-3` | 2026-10-13 14:47:00 EDT | 0 | 468.0 | `logs/s-base-audit-recon-3.log` |  |
| `ms-vt3-frac-fixed14-audit-recon` | 2026-10-13 14:51:44 EDT | 137 | 439.8 | `logs/ms-vt3-frac-fixed14-audit-recon.log` | TIMED OUT = incomplete |
| ms-vt3-frac-fixed14-audit-recon (2:51:44 PM ET) exit 137 at 439.8 s: dmesg 'Memory cgroup out of memory: Killed process 12854 (node)' (my recorded PID) -- killed by the shared memory cgroup, not a result; re-run alone | | | | | |
| `ms-vt3-frac-fixed10-audit-recon` | 2026-10-13 14:54:59 EDT | 0 | 515.5 | `logs/ms-vt3-frac-fixed10-audit-recon.log` |  |
| `ms-vt3-frac-fixed14-audit-recon-2` | 2026-10-13 15:03:47 EDT | 124 | 600.8 | `logs/ms-vt3-frac-fixed14-audit-recon-2.log` | TIMED OUT = incomplete |
| `ms-vt3-frac-fixed14-audit-recon-3` | 2026-10-13 15:14:08 EDT | 137 | 580.6 | `logs/ms-vt3-frac-fixed14-audit-recon-3.log` | TIMED OUT = incomplete |
| ms-vt3-frac-fixed14-audit-recon-2 (3:03:47 PM ET) hit the 600 s cap under load 40+ (exit 124); -3 (3:14:08 PM ET) was killed at 580.6 s by the shared memory cgroup (dmesg: 'Memory cgroup out of memory: Killed process 7279 (node)', my recorded PID): neither is a result | | | | | |
| `s-p1-audit-recon` | 2026-10-13 15:24:17 EDT | 0 | 598.5 | `logs/s-p1-audit-recon.log` |  |
| `ms-vt3-frac-fixed14-audit-recon-4` | 2026-10-13 15:34:24 EDT | 0 | 563.8 | `logs/ms-vt3-frac-fixed14-audit-recon-4.log` |  |

- Loops: `bin/mutloop.sh` ran the builder's 21 mutants (`bm-*`) and my own 10 (`om-*`), at most two node processes at a
  time; their PIDs are in `pids.txt` with each run.
- `pids.txt` has every timeout PID and its node child, with the command, plus the git commands in `gc/`. No process of mine
  was alive when I finished. Nothing was killed by me. The OOM kills in the table were made by the kernel's memory cgroup,
  which is shared with the other agents; dmesg names each PID, and each is a PID I recorded.
- The AUDIT_IMPORT_RUNNING lock was absent before every run, so no run waited or was skipped.

## 9. What I did not do

- I did not edit anything in `/home/user/orbit-board` or `/home/user/orbit-ui`, and nothing was staged, committed or pushed.
  The scratch clone `gc/` was restored with `git checkout --` and never committed.
- `mutate.mjs` was never imported, run or `node --check`ed. It was read as TEXT only (`rec/bin/mkmut.py` and `rec/bin/mcount.py`, run with
  `python3 -I`).
- I did not run full audit-import or full audit-board (the lead's). I did not run the full mutate sweep, validate:math,
  verify:grid or Playwright: the change has no browser surface beyond what the jsdom suites read.
- I did not re-run c1's whole audit-recon on the base board. The builder's run and the money verifier's both did, and my
  focused run agrees with them (§6).
- I did not edit the builder's drafts. The count changes p1 implies are listed in §5.
- I did not judge the money verifier's draft must-fix (that U9 moves CLIN-line partings both ways). That is lens A's ground,
  and it touches only drafted text.
- My surviving-mutant search covered the rounded-fraction family and fraction x total (`bin/search.py`, `bin/variants.py`).
  There could be other wrong fixes I did not think of. Board H closes that whole family, not every conceivable one.
