# U9, round 3, lens A (data loss and money): independent adversarial verification

Started 12:25 PM ET on 13 Oct 2026; this README was written from 1:22 PM ET (`TZ=America/New_York date`). Nothing earlier of
this review existed (the folder `verify-money-r3` did not exist), so nothing was reused; every run below is this session's.
Nothing was edited, staged, committed or pushed in `/home/user/orbit-board` or `/home/user/orbit-ui`; no builder or
verifier file was edited. `tools/export-audit/mutate.mjs` was only read as TEXT (`mkmut.py`, `mcount.py`, `python3 -I`).

## Verdict: sound-with-issues — one must-fix, and it is in the drafted words, not the board or the suite

The board change is correct for every whole-dollar case I could build: an independent oracle (integer largest remainder,
ties to the earlier office, the v1.95 two stages) agrees with `pmoPartsOf` in all 1,313 random cases on c1 and disagrees in
19 on the base; every surface reads the same parts (panel, forecast and its export, CR view, PMO Matrix, CE by PMO, PMO
tabs including their month columns, deck); nothing is written to state, so no copy of anyone's work can be lost. All 21
`v200-u9-*` mutants are caught with the builder's counts; audit-recon, boot-same, audit, audit-ppt, audit-other,
legacy-fsrc, audit-inject, audit-hostile, `npm run check` and the money map pass.

The must-fix: the drafts say the partings between the by-office split and the Spend Plan Source's CLIN lines are "not
changed here" / "not caused or changed by U9". That is false. U9 moves them both ways: it takes some cases OUT of line
with the CLIN lines that agreed before (case PF, part funded, one lane, one CLIN per office, no awards; case R10,
incremental awards). Brad's open decision ("which figure is the office's money") would be made on a false premise.

## Identities

| file | base (rec/L6/base = 7ee498a) | c1 (builder's, round 2) |
|---|---|---|
| prioritization-board-grid.html | fce8a391 | 46e522a8370f05971c8ef0558c3c666b0953b0ac |
| tools/export-audit/audit-recon.mjs | 529e36f7 | 755647cc1340cd2d9ed2b8a78b58f29df4b98b34 |
| tools/export-audit/mutate.mjs(.txt) | cbc6defc | 8fd34e940548e009efb812021792d8667c91fc54 |
| every other file | identical (`diff -rq` lists only these three) | |

- My copies: `base/` and `c1/` (cp -a, node_modules symlink kept, chmod u+w), byte-identical to rec/L6/base and rec/L6/u9/c1.
- `diffs/c1-vs-base.diff` (blob ddac181c): board +13/−4, audit-recon +399/−0, mutate +71/−0 (add-only, as claimed).
- The lead's Codex snapshot `recovery/v200/codex-handoff/inputs/u9-snapshot-20261013-1202/SNAPSHOT.txt` names the same three
  blobs; its NEXT-VERSION-U9.md is the builder's c5b48d46.
- orbit-board HEAD is f3f4b3d: no product file changed since 7ee498a; NEXT-VERSION.md is still 65265c13 (lines 777, 778 and
  792 as the drafts say); UNRESOLVED-LEDGER.md is now **c9dfc9ee** (the drafts say 8112ad0b; rows U36–U42 were added; the U9
  row, line 20, is unchanged).

## What I read

The board diff; `pmoSharesOf`, `pmoSplit`, `pmoPartsOf`, `apportion`/`apExact`, `landSvc`, `monSpreadOf`, `forecast`
(`vf`, `bump`), `crBuckets`, `pmoMatrix` (the panel), the deck's PMO rollup, `exportExcel`'s PMO Matrix, CE by PMO,
SHARES/PMO tabs (portions and `obligBlock`), the Two-Plan `fcBlock`, `exportFcView`, `clinList`/`clinVec`/`clinSplit`,
`srcRowsOf`, `basisSvcOf`, award normalisation (`awdNorm`, the PMO-submittal door `pmoNorm`), `pmoSync`/`pmoDel`, the
priority drill's FUNDED BY PMO AND BAND. Both U9 blocks in audit-recon, the 21 entries, the builder's README (rounds 1–2), both
round-2 verifier results, all four drafts.

## Findings

### MUST-FIX M1 — the drafts say U9 does not change where the by-office split and the CLIN lines part ways; it does

Where the drafts say it:
- `drafts/NEXT-VERSION-U9.md` line 59 (Not covered): "Measured on the boards before and after this change, the same on both;
  not changed here, and listed for Brad in the ledger …".
- `drafts/LEDGER-new-row.md`: "Measured on `fce8a391` and on the U9 board `46e522a8`: identical on both, so not caused or
  changed by U9".
- `drafts/LEDGER-U9-append.md`: "**Still open, measured on both boards, not changed (proposed as a new row, for Brad):**".
- `drafts/NEXT-VERSION-U9.md` "What users may see" names only the case where a move brings an office INTO line with the
  CLIN lines (case P: "as the Spend Plan Source's CLIN lines already were").

Reproduction (synthetic, both boards, observe only):
- **PF** (`probe/r3d.mjs`, runs r3d-c1 / r3d-base, 12:47 PM ET): USAF asks $5 and draws $4 discretionary; one CLIN per
  office, no award dates, CLINs in this order 0010 [3] (MxS), 0008 [1] (TSS), 0002 [6] (AV).
  - Spend Plan Source CLIN lines, both boards: 0010 $1, 0008 $1, 0002 $2 (the lane on its own over the CLINs: 1.2/.4/2.4 →
    1/0/2, the spare dollar to the .4 tie, 0008 earlier).
  - Base: by office MxS $1 / AV $2 / TSS $1 — the SAME as the CLIN lines; a PMO TSS tab is written.
  - c1: MxS $2 / AV $2 / TSS $0 on the PMO Matrix, the panel and the forecast; no PMO TSS tab — while CLIN 0008 still
    carries TSS's $1 on the Spend Plan Source. (By the stated two-stage rule: ask $5 at 3:1:6 = 1.5/.5/3 → 1/0/3 + MxS
    on the .5 tie → 2/0/3; then $4 by 2:0:3 → 1.6/0/2.4 → 2/0/2. c1 is right by its rule.)
- **R10** (`probe/r3.mjs`, runs r3v2-c1 / r3v2-base, 1:19 PM ET): $3 discretionary at 1:2:3 (0010/0002/0008), incremental
  awards $2 (Dec 26) and $1 (Mar 27). CLIN lines, both boards: 0002 Dec $1; 0008 Dec $1 + Mar $1. Base by office: MxS $0 /
  AV $1 (Dec) / TSS $2 (Dec + Mar) — the same as the CLIN lines. c1: MxS $1 (Dec) / AV $1 (Dec) / TSS $1 (Mar), on the
  forecast, its export, the CR view by PMO, the PMO tabs' month columns and the PMO Matrix.
- **Sweep** (`probe/r3c.mjs`, runs r3c2-c1 / r3c2-base, 12:46 PM ET; 3,000 random one-service cases, one CLIN per office,
  no awards; its CONTROL reads the real Spend Plan Source and agrees with the oracle on both boards). Offices equal to the
  CLIN lines:

  | case kind | base | c1 | U9 brings into line | U9 takes out of line |
  |---|---|---|---|---|
  | one lane, fully funded | 995 / 1009 | 1009 / 1009 | 14 | 0 |
  | one lane, part funded | 812 / 976 | 810 / 976 | 1 | 3 |
  | both lanes | 661 / 1015 | 662 / 1015 | 5 | 4 |

Why it must be fixed before commit: lens A, "say something false"; principle 4 (every word true) and principle 2 (ask
rather than guess — the ask to Brad must carry true facts). The board and suite need no change.

Minimal fix (text only; the lead applies it):
1. NEXT-VERSION-U9.md, Not covered: replace "Measured on the boards before and after this change, the same on both; not
   changed here, and listed for Brad in the ledger: which figure is an office's money where they differ." with:
   "The cases above measure the same before and after this change, but this change moves others both ways: where it moves
   an office's dollar it can bring the office into line with its CLIN lines or take it out of line. $4 drawn of a $5 ask
   over CLINs 0010 [3] / 0008 [1] / 0002 [6] was MxS $1 / AV $2 / TSS $1, the same as its CLIN lines, and is now $2 / $2 /
   $0, so no PMO TSS tab is written while CLIN 0008 still carries $1 on the Spend Plan Source; $3 at 1 : 2 : 3 awarded $2
   in December and $1 in March was $0 / $1 / $2, the same as its CLIN lines, and is now $1 / $1 / $1. In 3,000 random
   one-service cases with one CLIN per office, every one drawn from one lane in full now agrees (14 did not), 6 more come
   into line and 7 go out of line. Listed for Brad in the ledger: which figure is an office's money where they differ."
2. NEXT-VERSION-U9.md, What users may see: after "… so no PMO TSS tab is written." add: "Where a service is only part funded
   or its award comes in increments, the move can also go against the Spend Plan Source's CLIN lines, which do not change
   (see Not covered)."
3. LEDGER-new-row.md: replace "Measured on `fce8a391` and on the U9 board `46e522a8`: identical on both, so not caused or
   changed by U9" with "The cases above measure the same on `fce8a391` and on the U9 board `46e522a8`; U9 moves other cases
   both ways (U9 money verifier, round 3: $4 of a $5 ask over 0010 [3] / 0008 [1] / 0002 [6] was offices = CLIN lines
   1/2/1, now offices 2/2/0 against CLIN lines 1/2/1; $3 at 1:2:3 awarded $2 Dec + $1 Mar was 0/1/2 = CLIN lines, now
   1/1/1; every one-lane, fully funded case with one CLIN per office now agrees)".
4. LEDGER-U9-append.md: replace "**Still open, measured on both boards, not changed (proposed as a new row, for Brad):**"
   with "**Still open (proposed as a new row, for Brad); the cases listed measure the same on both boards, and U9 moves
   others both ways (part funded: $4 of $5 over 0010 [3] / 0008 [1] / 0002 [6], offices 1/2/1 = CLIN lines before, 2/2/0
   after):**".

### SHOULD-FIX S1 — where a placement is not whole dollars the office parts stay fractions, and the drafts say otherwise

- **R12** (`probe/r3b.mjs`, r3b-c1 / r3b-base, 12:42 PM ET): $3 discretionary at 1:2:3, incremental awards $2 (Dec) and $2
  (Mar) — they total $4, so the Two-Plan Forecast's modelled plans take them as a shape (k = 3/4, $1.50 + $1.50, not whole)
  and `landAll` falls back to the fractions. Two-Plan Forecast BY PMO TOTAL, PLAN A and PLAN B, both boards: MxS $0.50 /
  AV $1.00 / TSS $1.50 (cell values, $M × 1e6). The funded forecast and the PMO Matrix on c1: $1 / $1 / $1 (base $0/$1/$2).
- **R3** (`probe/r3.mjs`): an award held as one lump figure (v = $4, no figures by service, on a three-service board — the
  form the PMO-submittal door `pmoNorm` → `awdNorm({door:true})` keeps; state set directly in the probe). The funded
  forecast's office TOTALs are $0.50 / $1.00 / $1.50 (months $0.22 / $0.44 / $0.67 in Dec) against the PMO Matrix's
  $1 / $1 / $1 on c1 ($0 / $1 / $2 on the base). Same in kind on both boards; not caused by U9.
- The drafts: "Every by-office view moves together … the Two-Plan Forecast's BY PMO rows …" (What users may see) and "an
  amount that is not whole dollars (a modelled plan's) is still each office's fraction of it" (the amount here IS whole —
  only its placement is not).
- Minimal fix (text): in What users may see write "the Two-Plan Forecast's BY PMO rows (where its plans place whole
  dollars)"; in Not covered add "Where a placement is not whole dollars — a modelled plan's awards taken as a shape (the
  Two-Plan Forecast, whenever the awards do not add up to the plan's amount) or an award held as one lump figure — each
  office still takes its fraction of every placement, as before, so its months and total there are fractions and can
  differ from its whole-dollar part on the PMO Matrix: $3 at 1 : 2 : 3 awarded $2 in December and $2 in March is $1 / $1 /
  $1 on the PMO Matrix and $0.50 / $1.00 / $1.50 on the Two-Plan Forecast's BY PMO rows, the same before and after this
  change." A board fix (scale each office's placement by its exact part — o.d[i]/d and o.m[i]/m — instead of its fraction,
  so its months still add up to its whole part) is possible but widens U9; for the lead to log or decide.

### SHOULD-FIX S2 — pre-existing: the panel and the CR view by PMO drop an office the CLINs name when it is not on the PMO list

- **R1** (`probe/r3.mjs`): PRIME-3 homed to MxS, CLINs 0010 [1] / 0002 [2] / 0001 [3]; nothing homes PRIMES, so GROUPS has no
  PRIMES. $3 → MxS 1 / AV 1 / PRIMES 1 (c1). The PMO Matrix and the forecast show PRIMES $1; the panel has no PRIMES row and
  its TOTAL row reads **$2** for a $3 draw (base: $1); the CR view by PMO has no PRIMES row.
- **R1b** (`probe/r3b.mjs`): PRIME-3 homed to PRIMES; TSS (homed by nothing) removed from the list the way `pmoDel` does
  after its confirm (`pmoSave`). Panel: MxS $1, AV $1, no TSS row, TOTAL **$2** of $3 (base $1); CR view by PMO: no TSS; PMO
  Matrix and forecast: TSS $1.
- Cause: `pmoMatrix` (c1 lines 24530/24533) and `crBuckets(…,'pmo')` (line 11569) list `GROUPS.filter(...)`, where every
  other by-office view uses `pmoKeys()` ("Iterating GROUPS alone drops those rows and their dollars with them", line 22052).
  Identical in kind on the base; not caused by U9, but it makes "the same on the panel" untrue in that state, and the
  draft's "no requirement, service or board total changes" untrue for the panel's TOTAL row ($1 → $2 in R1 and R1b).
- Minimal fix: (a) drafts — qualify that sentence: "(the PMO funding panel's TOTAL row and the CR view by PMO count only
  the offices on the PMO list, before and after this change, so they can move by a dollar that moves into or out of an
  office not on it)"; (b) board, as its own ledger row (not widened into U9): `pmoKeys(byG)` for the panel's rows and its
  TOTAL, `pmoKeys(bags)` in `crBuckets`.

### Minor

- m1: draft anchor — UNRESOLVED-LEDGER.md is c9dfc9ee at HEAD f3f4b3d (drafts say 8112ad0b); the U9 row (line 20) is
  unchanged, so the append still applies.
- m2: no U9 board has an award date, so the month cells of a tie case (R10) are read by no U9 check. The mechanism (months
  follow each office's whole part) is held elsewhere: my mutant `vm3-months-by-weight` (each dated piece split by the
  weights on its own; blob c4456ed5) passes both U9 blocks, the focused audit-board PRIME-3 harness and audit-other, but
  full audit-recon catches it (9 failing, all in "W7 — F4"). R10 could be added as a check if the lead wants U9's own tie
  pinned by month.
- m3: the priority drill's "FUNDED BY PMO AND BAND" and its per-PMO tabs group by the requirement's own office (`grpOf`), so
  PRIME-3 is not split there; the builder's surface table names only the ACE tie-out as such a view. Pre-existing, by design.
- m4: in the panel and CE by PMO an office whose part is $0 still shows the requirement in its count (case P: TSS, 1, all
  "—"/0) while it gets no PMO tab. Pre-existing pattern; U9 only changes which office it is.

### Checked and found sound

- Data loss: U9 writes no state (`pmoSharesOf` returns one more array; SHARES and pmoPartsOf are local); a tab that is not
  written (P, PF) holds no record of its own — every dollar is on the other offices' tabs.
- Office not a CLIN office, with a service no CLIN covers (R2, PRIME-3 homed to PSM): exact and identical on the panel,
  forecast (whole and by service), CR view, PMO Matrix, CE by PMO and tabs; c1 1/1/1 + PSM 2, base 0/1/2 + 2.
- Dated awards (R10): forecast months, its export, the CR half-month windows and the PMO tabs' month columns all add to each
  office's whole part on c1.
- PMO lens (R11, case P): forecast(null,{pmo}) roll-up and by-service totals are 1/3/0.
- Sweep of `pmoPartsOf` against an independent oracle (r3v2): 1,313 cases, c1 0 differences and every part sums to the
  requirement; base 19 differences.
- Principles: (1) nothing written, nothing lost; (2) the two-stage question stays with Brad, but see M1; (3) whole-dollar
  money matches the computation on every surface; the fraction fallbacks (S1) are pre-existing; (4) board words unchanged,
  drafts need M1/S1/S2; (5) +13/−4 board lines; (6) audit-recon and mutate add-only (+399/−0, +71/−0), no expectation edited.

## Runs (every one through `run.sh`: `setsid -w timeout -k 10 600`, lock checked first; the lock was never present)

| label | start (ET, 13 Oct) | exit | wall s | result |
|---|---|---|---|---|
| f-c1 | 12:32:25 | 0 | 30.0 | focused U9 harness (blob 31315c7f = builder's), 89/89 |
| f-base | 12:33:00 | 1 | 30.2 | 51 FAILING, none a CONTROL |
| r3-c1 / r3-base | 12:38:05 / 12:38:42 | 0 / 0 | 30.5 / 27.0 | first run of probe/r3.mjs (weak PRNG in its sweep; superseded by r3v2, cases identical) |
| r3b-c1 / r3b-base | 12:42:12 / 12:42:31 | 0 / 0 | 18.2 / 15.5 | R12, R1b (S1, S2) |
| r3c-c1 / r3c-base | 12:45:26 / 12:45:37 | 0 / 0 | 11.2 / 12.4 | sweep with a weak PRNG (only odd asks): superseded |
| r3c2-c1 / r3c2-base | 12:46:22 / 12:46:35 | 0 / 0 | 12.8 / 14.7 | divergence sweep (M1 table); CONTROL agrees on both |
| r3d-c1 / r3d-base | 12:47:46 / 12:47:58 | 0 / 0 | 11.7 / 11.1 | PF (M1) |
| fm-v200-u9-* ×21 | 12:49:11 – 13:00:48 | 1 each | 20.0–44.7 | all caught: 51, 51, 42, 13, 9, 1, 1, 2, 1, 3, 2, 1, 2, 2, 1, 1, 1, 1, 1, 1, 2 failing (mutant blobs = builder's) |
| s-c1-audit-recon | 12:49:20 | 0 | 501.4 | ALL CHECKS PASSED |
| s-base-audit-recon | 12:57:50 | 0 | 307.9 | ALL CHECKS PASSED |
| s-c1-boot-same / s-base-boot-same | 13:03:11 | 0 / 0 | 39.5 / 39.9 | identical either way, both |
| fo-vm3-months-by-weight | 13:04:18 | 0 | 27.6 | my mutant passes both U9 blocks (89/89) |
| po-vm3-months-by-weight | 13:04:18 | 0 | 27.6 | probe on it: R10 months wrong (MxS 0 against Matrix 1) |
| fb-c1 / fb-vm3-months-by-weight | 13:04:58 | 0 / 0 | 17.9 / 18.7 | focused audit-board PRIME-3 harness (= builder's): passes both |
| sm-vm3-audit-other | 13:05:23 | 0 | 125.6 | survives |
| sm-vm3-audit-recon | 13:05:23 | 1 | 407.8 | caught: 9 failing, all "W7 — F4" |
| gc-clone / gc-checkout | 13:12:28 / 13:12:30 | 0 / 0 | 2.5 / 0.9 | scratch clone `gc/` (git clone --shared) at 7ee498a |
| check-base / moneymap-base | 13:12:37 / 13:12:48 | 0 / 0 | 11.5 / 0.5 | all checks passed; money map holds, 329 cells, 0 open |
| check-c1 / moneymap-c1 | 13:12:49 / 13:13:00 | 0 / 0 | 11.4 / 0.6 | the same, with c1's three files copied in |
| gc-restore | 13:13:10 | 0 | 0.3 | clone back at the base files (only the node_modules link untracked) |
| s-c1suite-baseboard-audit-recon | 13:13:10 | 1 | 344.9 | 51 FAILING, all in the two U9 blocks, no CONTROL |
| s-c1-audit / -audit-ppt / -audit-other | 13:13:19 / 13:13:54 / 13:14:09 | 0 | 34.8 / 15.3 / 98.1 | ALL CHECKS PASSED |
| s-c1-legacy-fsrc / -audit-inject / -audit-hostile | 13:19:15 / 13:19:24 / 13:19:51 | 0 | 8.6 / 26.8 / 124.7 | pass |
| r3v2-c1 / r3v2-base | 13:19:31 / 13:19:50 | 0 / 0 | 18.4 / 19.3 | probe/r3.mjs as it stands: sweep 1,313 cases, c1 0 / base 19 differences |

Logs: `logs/<label>.log`; the one-line records in `logs/runs.txt`. mcount (text only, `python3 -I`): c1 1349/1349 found once,
base 1328/1328 (`out/mcount-*.txt`).

## Files

- `probe/r3.mjs` (4b6883c6), `probe/r3b.mjs` (d7d23424), `probe/r3c.mjs` (4e45b244), `probe/r3d.mjs` (dcf5ae9a): observe only.
- `harness/c1/focused-u9.mjs` (31315c7f, regenerated by `bin/mkfocused-u9-r1.py`, the builder's generator, byte-identical to
  the builder's harness); `harness/board/focused-board-pmo.mjs` (92dafb85, by `bin/mkfocused-board.py`, identical to the
  builder's after its header line).
- `mut/u9/*.html` (21, by mkmut.py; blobs equal the builder's), `mut/own/vm3-months-by-weight.html` (c4456ed5).
- `run.sh` (4ff9dfbb), `mutloop.sh` (a8e64371), `pids.txt`, `diffs/c1-vs-base.diff`, `out/`.

## PIDs

120 lines in `pids.txt` (each run's `timeout` and child, the mutant loop's own two). None of mine was alive at 1:22 PM ET.
Two recorded numbers (21870, 21873, from fm-v200-u9-cebypmo-float-split, which finished at 12:54 PM ET) were later reused by
another session's processes; I killed nothing.

## What I did not do

- Did not run the full audit-import or audit-board, the mutate sweep, validate:math, verify:grid or any Chromium run.
- Did not re-run audit, audit-ppt, audit-other, legacy-fsrc, audit-inject or audit-hostile on the base (unchanged files).
- Did not propose or build a board change: M1 is text; S1's and S2's board fixes are for the lead to log or decide.
- Did not test CLIN asks with cents or as text arriving before the first fit (CLINS is in the temporal dead zone on the first
  `applyState`): pre-existing, outside U9.
- Did not edit any draft; the replacement texts above are for the lead.
