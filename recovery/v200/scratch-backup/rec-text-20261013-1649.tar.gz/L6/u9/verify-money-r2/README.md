# U9 verify, round 2, lens A (data loss and money)

Independent adversarial check of the U9 builder's fix round 1 (`rec/L6/u9`, copy `c1`, README finished 4:48 AM ET).
My directory is `rec/L6/u9/verify-money-r2`. The runs went from 5:25 AM ET to 5:46 AM ET on 13 Oct 2026 (the directory was
made at 5:20 AM ET). This README was written from 5:46 AM ET and finished at 5:48 AM ET (`TZ=America/New_York date`).

The relayed request for this run was "I hit my usage limit while you were working, but it has reset now. Please continue
from where you left off." I found no earlier attempt of this round: `verify-money-r2` did not exist when I started (5:20 AM
ET), so the round started fresh.

I edited none of the builder's files and nothing in `/home/user/orbit-board` or `/home/user/orbit-ui`. Nothing was committed,
staged or pushed. `mutate.mjs` was read as text only (`mcount.py`, `mkmut.py`, `python3 -I`). Full audit-import, full
audit-board and Playwright were not run.

## Verdict: sound, with issues

- **The board is right.** On every by-office surface and export I read, c1 matches hand-written exact figures. That
  includes two new cases the builder's blocks do not use: an office losing its only dollar, and a starred requirement drawn
  from both lanes and left short. The figures read are the panel, the forecast, the PMO Matrix, CE by PMO, every PMO tab
  row, the deck, and the Spend Plan Source as a control.
- **Nothing can lose a copy of anyone's work.** The change is a read-only computation. boot-same is identical on both
  boards.
- **Every claim in the fix round that I could re-run reproduces:**
  - 79/79 checks on c1.
  - 44 fail on the base, which is every non-control check; all 35 controls pass.
  - All 14 mutants are caught, with the builder's counts.
  - mcount finds 1342 of 1342 entries exactly once.
  - Every drafted number (X1, X2, D1–D4, case F) is right.
  - c1's suite on the base board fails exactly 44 checks, and nothing else.
- **No must-fix.**
- **Two should-fixes** (details below):
  - The drafts' "What users may see" leaves out that an office can lose its PMO tab.
  - The drafts overstate what the tests read. Four exported memo and unfunded cells that this commit moves are pinned by no
    check, and two plausible mutants survive every suite I ran. A tested addendum is in `proposal/`.

## Identities (`git hash-object`)

| file | base (rec/L6/base, 7ee498a) | c1 (my `cp -a` of the builder's) | p1 (my proposal = c1 + addendum) |
|---|---|---|---|
| prioritization-board-grid.html | fce8a391bd8a248d5185e199d22190c1687eaea0 | 46e522a8370f05971c8ef0558c3c666b0953b0ac | 46e522a8 (unchanged) |
| tools/export-audit/audit-recon.mjs | 529e36f7c20e635b2722ea53b6a4f44b4ed328af | 2fb4b7adb898f37ede4873d58a67784b215211de | b19d2e4fe2fa380d41c086ddca4cfec3a295edbf |
| tools/export-audit/mutate.mjs.txt | cbc6defc6803851e847844848fc9b186daeeb268 | 3f7d8311ce034463f7ec47f43f067638f6493547 | 8b86b17af7d13bea45a97e6606c5925b982e9bc0 |
| audit.mjs / audit-other / audit-board / audit-import / boot.mjs | cc5af0be / d89396b0 / a7c575e5 / 4aba2506 / 9c4f49ad | identical | identical |

- `diff -rq base c1` lists only the three files above. All c1 blobs equal the builder's claims.
- The build's superseded copy (`../superseded/c1-build`) has the same board, 46e522a8. Its audit-recon and mutate blobs are
  19fd2a3d and 1208ae45.
- Diffs:

| diff | blob | lines |
|---|---|---|
| `diffs/board.diff` (c1 vs base) | 173e27ff | +13 −4 (the build's change, unchanged) |
| `diffs/audit-recon.diff` (c1 vs base) | 31a4f8a3 | +318 −0 |
| `diffs/mutate.diff` (c1 vs base) | 0a674cc0 | +46 −0, before the R3 line |
| `diffs/audit-recon-vs-build.diff` | 669f9b10 | +127 −8. The 8 removed lines are in the build's own uncommitted U9 block (B's literal totals) |
| `diffs/mutate-vs-build.diff` | 675c241e | +23 −0 |
| `diffs/p1-vs-c1.audit-recon.diff` (my proposal) | 567635df | +31 −0 |
| `diffs/p1-vs-c1.mutate.diff` (my proposal) | 241d53d4 | +14 −0 |

- My tools:

| file | blob | note |
|---|---|---|
| `run.sh` | 110bbcfd | `verify-money-r1/run.sh` with U changed |
| `bin/mkfocused-u9-r1.py` | 2168af7b | the builder's |
| `bin/runner.mjs` | f851f139 | the builder's |
| `bin/tally.py` | cf67b0d8 | the builder's |
| `bin/lr2.py` | 243599e1 | |
| `bin/mkown.py` | e1c2840d | |
| `probe/exports-r2.mjs` | 7be41f12 | |
| `probe/frac-clin.mjs` | 7c0d32f6 | |
| `probe/divergence3.mjs` | 9513af5f | copy of the builder's |
| `probe/tie-f.mjs` | 23d3e44e | copy of the builder's |
| `proposal/board-f.mjs.txt` | 06f09634 | |
| `proposal/mutate-entries.txt` | 86d847cf | |
| `harness/f/focused-u9.mjs` | c16385ba | byte-identical to the builder's `harness/r1/focused-u9.mjs`; every line after the header is verbatim in c1's audit-recon (checked) |
| `harness/p1/focused-u9.mjs` | 5a167d78 | |

## Runs

Each node run went through `run.sh`:

- one `setsid -w timeout -k 10 600` per run
- the AUDIT_IMPORT_RUNNING lock checked first (absent every time, so no run waited or was skipped)
- BOARD and MUT_FIRST_FAIL unset unless given
- the timeout PID and its child recorded in `pids.txt`

The three git commands in my scratch clone (clone, checkout, restore) each ran under `setsid -w timeout -k 10 600`, with the
PID recorded.

At 5:46:25 AM ET none of the 127 recorded PIDs was alive. Nothing was killed.

Exit 1 on `f-base`, `fm-*`, `pf-base`, `pfo-*` and `s-*suite-baseboard-*` means the expected failing checks were found. It is
not a crash.

All times are ET on 13 Oct 2026.

| label | start | exit | wall s | result | log |
|---|---|---|---|---|---|
| f-c1 (both U9 blocks, focused) | 5:25:39 AM | 0 | 15.0 | 79/79; controls 35/35 | logs/f-c1.log |
| f-base | 5:25:54 AM | 1 | 16.9 | 44 fail = every non-control; controls 35/35 | logs/f-base.log |
| fm-v200-u9-* (14 runs) | 5:26:54 to 5:29:16 AM | 1 each | 6.0–15.3 | all caught; failing checks below | logs/fm-*.log, out/fm-summary.txt |
| s-c1-audit-recon | 5:30:01 AM | 0 | 188.1 | ALL CHECKS PASSED | logs/s-c1-audit-recon.log |
| exp-c1 | 5:31:25 AM | 0 | 10.5 | P and Q: all 15 comparisons AGREE | logs/exp-c1.log |
| exp-base | 5:31:36 AM | 0 | 9.8 | 11 DIFFER (the defect), controls agree | logs/exp-base.log |
| fo-vm2-* (my 4 mutants, focused) | 5:32:20 to 5:33:01 AM | 0 each | 8.0–9.8 | **all 4 pass 79/79 (survive)** | logs/fo-*.log |
| po-vm2-* (my mutants, probe) | 5:32:30 to 5:33:09 AM | 0 each | 3.5–4.6 | deck-mc and tab-mc each move a figure on Q; ce-mcs and tab-unf are equal to c1 on Q (separated by board F) | logs/po-*.log |
| s-c1suite-baseboard-audit-recon (BOARD = base) | 5:33:50 AM | 1 | 157.2 | 44 FAILING, all in the two U9 blocks (36 + 8); nothing else | logs/s-c1suite-baseboard-audit-recon.log |
| div3-c1 / div3-base | 5:34:01 / 5:34:08 AM | 0 / 0 | 7.2 / 8.0 | outputs byte-identical; X1, X2, D1–D4 as drafted | logs/div3-*.log, out/div3-*.json |
| tief-c1 / tief-base | 5:34:30 / 5:34:37 AM | 0 / 0 | 6.8 / 5.8 | case F: offices MxS $1; CLIN line 0002 (AV) $1; same on both | logs/tief-*.log |
| frac-c1 / frac-base / frac2-c1 | 5:36:03 / 5:36:06 / 5:36:19 AM | 0 | 3.6–3.9 | CLIN asks with cents are rounded to whole dollars at load (0.3 → 0), so office weights are always whole; my float-sum hypothesis is refuted | logs/frac*.log |
| s-c1-boot-same / s-base-boot-same | 5:37:01 / 5:37:08 AM | 0 / 0 | 7.4 / 7.2 | identical either way | logs/s-*-boot-same.log |
| s-base-audit-recon | 5:37:19 AM | 0 | 86.8 | ALL CHECKS PASSED | logs/s-base-audit-recon.log |
| pf-p1 (my proposal, focused, c1 board) | 5:38:33 AM | 0 | 7.4 | 83/83; controls 36/36 | logs/pf-p1.log |
| pf-base | 5:38:40 AM | 1 | 6.8 | 47 fail = every non-control; controls 36/36 | logs/pf-base.log |
| pfo-vm2-* (my 4 mutants vs the proposal) | 5:38:54 to 5:39:11 AM | 1 each | 5.0–6.2 | each caught, 1 failing check (F) | logs/pfo-*.log, out/pown-summary.txt |
| sm-vm2-*-audit, sm-vm2-*-audit-ppt (BOARD = mutant) | 5:39:25 to 5:40:14 AM | 0 each | 3.8–10.8 | all 4 survive audit and audit-ppt | logs/sm-*.log |
| sm-vm2-deck-mc-float-split-audit-recon | 5:40:35 AM | 0 | 85.8 | **survives** (ALL CHECKS PASSED) | logs/sm-vm2-deck-mc-float-split-audit-recon.log |
| sm-vm2-tab-mc-float-split-audit-recon | 5:42:12 AM | 0 | 88.9 | **survives** (ALL CHECKS PASSED) | logs/sm-vm2-tab-mc-float-split-audit-recon.log |
| check-base / moneymap-base | 5:42:30 / 5:42:34 AM | 0 / 0 | 3.8 / 0.2 | all checks passed; money map holds, 329 cells, 0 open | logs/check-base.log, logs/moneymap-base.log |
| check-c1 / moneymap-c1 | 5:42:34 / 5:42:38 AM | 0 / 0 | 4.1 / 0.2 | the same | logs/check-c1.log, logs/moneymap-c1.log |
| check-p1 / moneymap-p1 | 5:42:38 / 5:42:42 AM | 0 / 0 | 3.5 / 0.2 | the same | logs/check-p1.log, logs/moneymap-p1.log |
| s-p1-audit-recon | 5:43:49 AM | 0 | 70.7 | ALL CHECKS PASSED | logs/s-p1-audit-recon.log |
| s-p1suite-baseboard-audit-recon (BOARD = base) | 5:45:05 AM | 1 | 71.1 | 47 FAILING (36 + 11), no control, nothing else | logs/s-p1suite-baseboard-audit-recon.log |

Notes on the runs:

- **The check and money-map runs** used my scratch clone `gitclone/`:
  - `git clone --shared --no-checkout` of `/home/user/orbit-board` at 5:42 AM ET, then a detached checkout of 7ee498a.
  - I copied in c1's files, then p1's, and restored with `git checkout --` (exit 0). The clone is clean at 7ee498a again,
    except for the node_modules symlink.
  - The commands were `node tools/check.mjs prioritization-board-grid.html` and `node tools/money-map.mjs --check`.
- **Some runs overlapped:**
  - the check runs with `sm-vm2-tab-mc-…-audit-recon`
  - the `pf-*` runs with `s-base-audit-recon`
  - the `fo-*`/`po-*` runs with `s-c1-audit-recon`

  None was killed and every one finished with an exit record.

Mutant counts (focused, `out/fm-summary.txt`). They equal the builder's:

| entry | failing | entry | failing |
|---|---|---|---|
| split-by-fraction | 44 | cebypmo-float-split | 1 |
| weights-are-fractions | 44 | cebypmo-own-rounding | 1 |
| per-part-rounding | 35 | tab-portions-float-split | 2 |
| ties-by-name | 13 | deck-rollup-float-split | 1 |
| uncovered-weight-dropped | 9 | deck-own-rounding | 1 |
| plan-part-by-weight | 1 | weights-first-clin | 2 |
| plan-placed-by-weight | 1 | office-ranks-by-last-clin | 2 |

The 14 mutants were built by `mkmut.py` from c1's text, and each blob equals the builder's `mut/r1/*.html`. The 7 new ones
are also byte-identical to the tests verifier's survivors (`verify-tests-r1/mut/mine/vt-*.html`).

mcount (text only):

- base: 1328 of 1328 found once
- c1: 1342 of 1342
- p1: 1346 of 1346
- none missing, multiple or unparsed (`out/mcount-*.txt`)

## What I checked

1. **Every reader of `pmoSharesOf` and `pmoPartsOf` in c1.** I grepped and read each one:
   - the forecast's view factor (line 11346)
   - `pmoMatrix`
   - `crBuckets`
   - the deck roll-up (25091)
   - the PMO Matrix sheet (29787)
   - CE by PMO (30457)
   - `SHARES` (30507, which reads only the office name)
   - `obligBlock` (30562)
   - the portions loop (30638)

   Each reads the office's whole-dollar part. Nothing stores the new third entry, saves it or serializes it.
2. **New cases, on every surface, against hand-written literals** (`probe/exports-r2.mjs`):
   - **P: $4 at 3 : 6 : 1, discretionary.**
     - c1 gives MxS 1 / AV 3 / TSS 0 on the panel, the forecast, the PMO Matrix, CE by PMO and the deck. The Spend Plan
       Source agrees: 0010 $1, 0002 $3.
     - **No `PMO TSS` tab is written.**
     - The base gave 1/2/1 everywhere and wrote a `PMO TSS` tab, while its own Spend Plan Source gave 0008 nothing.
   - **Q: starred, $9 asked, $3 + $3 drawn, at 1 : 2 : 3.** On c1:
     - PMO Matrix: Disc 1/1/1, Mand 1/1/1, ★ MC requirement 2/3/4, ★ MC short 1/2/3
     - each tab's MC memo row: 2/3/4
     - each tab's Unfunded row: MxS none, AV 1, TSS 2
     - CE by PMO: 2/1/2/1/1/0, 3/1/3/2/1/1, 4/1/4/3/1/2
     - deck: Ask $2/$3/$4, ★ MC req $2/$3/$4, ★ MC short $1/$2/$3
     - panel MC: $1/$2/$3
     - Spend Plan Source: 0010, 0002 and 0008 at $2 each

     All agree with the literals. The base differs in 11 places.
3. **The drafts' numbers:**
   - X1: offices 1+0 / 1+1 / 1+2, CLIN lines 2/2/2.
   - X2: offices 2/3/5, CLIN lines 2/4/4.
   - D1: MxS 1 / AV 1 vs MxS 2 / AV 0.
   - D2: 9/16/25 vs 8/17/25.
   - D3: MxS 2 / AV 4, no TSS, vs 1/2/3.
   - D4: 1/1/1 vs 2/1/0.
   - F: MxS $1 vs AV's 0002 $1.

   All are re-measured here, and are byte-identical on both boards.
4. **Whether office weights can be inexact.** CLIN asks are rounded to whole dollars when the board loads (`frac2-c1`: 0.3
   becomes 0), so an office's summed CLIN asks are safe integers and `apportion()` reads them exactly. Refuted; nothing to
   report.
5. **Draft anchors at the current HEAD** (f86889a, records only):
   - NEXT-VERSION.md is still 65265c13. Line 777 ends U14's entry, 778 is "Unresolved after R1–R5", and 792 is the U9
     bullet.
   - UNRESOLVED-LEDGER.md is now 8112ad0b, not the 1bcad628 the builder names. c8a8603 changed the UI-S row. The U9 row
     (line 20) is unchanged, so the append anchor still holds.

## Must-fix

None.

## Should-fix

**S1. "What users may see" leaves out that an office can lose its PMO tab.**

- **Reproduction** (`probe/exports-r2.mjs`, case P, `logs/exp-*.log`): USAF $4 discretionary over 0010 [3], 0002 [6],
  0008 [1].
  - Base: MxS $1 / AV $2 / TSS $1, and the workbook has `PMO TSS`.
  - c1: $1 / $3 / $0 on every view, and the sheet list ends `PMO AV | PMO MxS`.
- c1 is right: exact largest remainder ties AV and TSS at .4 and gives the dollar to AV, as the Spend Plan Source does.
- The drafts name only the opposite case: "(an office whose share was $0 now has its tab)".
- My model (`bin/lr2.py`, exact fractions, base = float fractions read exactly) finds 154 (case, office) pairs where an
  office had dollars on the base and has none on the exact rule, over 2–4 offices, weights 0–6 and $1–$12.
- **Minimal fix** (`drafts/NEXT-VERSION-U9.md`, What users may see): replace "(an office whose share was $0 now has its
  tab)" with "(an office whose share was $0 now has its tab, and one whose only dollar moves to another office no longer
  gets one: $4 over CLINs asking 3 : 6 : 1 was MxS $1 / AV $2 / TSS $1 and is now $1 / $3 / $0, as the Spend Plan Source's
  CLIN lines already were, so no PMO TSS tab is written)".
- In the same paragraph, "move by the dollar that moved" should be "move by the dollars that moved". Board A's MxS total
  moves by $3: 167,291,651 → 167,291,654.

**S2. The drafts overstate what the tests read, and four exported cells this commit moves are pinned by no check.**

- **The overstatement.** The NEXT-VERSION Test bullet says "Each is read on the panel as drawn, the forecast …, the PMO
  Matrix, the CE by PMO sheet, each office's PMO tab (its report row and its rows by portion), the Two-Plan Forecast's BY
  PMO rows (both plans), the CR view by PMO and the deck's Funding by PMO slide". The ledger append says "read on every
  view above". In fact:
  - The cases on boards A, B and C are not read on CE by PMO, the tabs' rows by portion, the Two-Plan Forecast or the deck.
  - D is not read on the panel, the forecast or the CR view.
  - E is read only on the PMO Matrix and the forecast.
  - Of the rows by portion, only Disc and Mand are read. The MC memo row and the Unfunded row are not, and neither are the
    deck's ★ MC req / ★ MC short or CE by PMO's ★ columns.
- **Reproduction of the gap.** My mutants (`bin/mkown.py`) each split one of those cells by the floating-point fractions
  again:
  - `vm2-tab-mc-float-split` (the PMO tabs' MC memo row): survives the two U9 blocks (79/79), audit, audit-ppt and full
    audit-recon. On case Q it prints MxS 1 / AV 3 / TSS 5 where c1 prints 2/3/4.
  - `vm2-deck-mc-float-split` (the deck's ★ MC req): the same, $1/$3/$5 vs $2/$3/$4.
  - `vm2-tab-unf-float-split` and `vm2-ce-mcs-float-split`: survive the U9 blocks, audit and audit-ppt.
- **Minimal fix (tests only; tested in `p1/`):**
  - Insert `proposal/board-f.mjs.txt` (31 lines) into "v2.00 (U9, every export)" after board E's last check. Board F is
    starred, with USAF $9 drawn $3 + $3 and ANG $3 undrawn, at 1 : 2 : 3. It adds 4 checks, 1 of them a CONTROL, and every
    expected value is a hand-written literal:
    - tabs, MC memo and Unfunded rows: [[3,2,1],[1,0,1]], [[4,3,1],[2,1,1]], [[5,4,1],[3,2,1]]
    - CE by PMO Ask/★/★ short/Unfunded: 3/3/2/1, 4/4/3/2, 5/5/4/3
    - deck Unfunded/★ MC req/★ MC short: $1/$3/$2, $2/$4/$3, $3/$5/$4
  - Insert the 4 entries in `proposal/mutate-entries.txt` before the R3 line:
    - `v200-u9-tab-memo-float-split`
    - `v200-u9-tab-unf-float-split`
    - `v200-u9-deck-mc-float-split`
    - `v200-u9-cebypmo-mcs-float-split`

    Built by `mkmut.py` from p1's text, each is byte-identical to my mutant.
  - Results:
    - c1 board: 83/83.
    - Base: 47 fail, every non-control; controls 36/36.
    - Each of the 4 mutants: caught, 1 failing.
    - Full audit-recon: p1 passes; p1's suite on the base board fails exactly 47.
    - mcount: 1346/1346.
    - npm run check and the money map: pass and hold.
  - Then correct the Test sentence to say which cases are read where. If the addendum is not taken, say instead "its report
    row and its Disc and Mand rows by portion" and drop "Each is read on" / "read on every view above".

## Minor

- **A pre-existing export sentence is false; it is not U9's change.** The workbook's month sheets (`exportExcel`, c1 lines
  30393–30396) say "The last CLIN takes the rounding in every column, so the CLIN rows add to the prime exactly."
  - Since v1.95, `clinSplit` (23485–23491) splits whole dollars by `apportion()`: largest remainder, ties to the EARLIER
    CLIN.
  - At $3 over 1 : 2 : 3 the first CLIN, 0010, takes the leftover dollar (U9 block A's Spend Plan Source CONTROL shows
    0010 = $1).
  - It is identical on the base. For the lead to log separately; it is outside U9's diff.
- **A stale blob in the drafts' anchor.** The builder cites UNRESOLVED-LEDGER.md as 1bcad628; at HEAD f86889a it is
  8112ad0b. The U9 row is unchanged.
- **The money-map catalogue does not cite the new blocks.** The builder already lists this as not done. The map holds
  without it, on c1 and on p1.

## How the change meets each decision principle (checked literally)

1. **Never lose a copy.**
   - The change is read-only arithmetic in `pmoSharesOf`/`pmoPartsOf`, with no save, load or serialize path.
   - boot-same is identical on both boards.
   - The builder kept the build's copy, README and drafts (`superseded/`). The fix round edited only lines that are not in
     the base.
   - Met.
2. **Ask rather than guess.**
   - The tie rule is `apportion()`'s, with an office ranked by its first CLIN.
   - Every place the by-office split and the Spend Plan Source still differ (X1, X2, D1–D4, F) is measured and handed to
     Brad as a new row, not decided.
   - Met.
3. **Money and exports match exactly.**
   - Every surface and export agrees with exact literals on c1, including two cases new to this round (P, Q).
   - The tests pin most of it. S2 lists the four cells they do not.
   - Met for the board.
4. **Every word true.**
   - The board's words do not change. Every user-facing sentence about the by-office split stays true. The one false
     sentence I found is pre-existing and outside U9 (minor).
   - The drafts are not fully true: S1 and S2.
5. **Smallest change.** The board's diff is +13 −4, unchanged since the build. Met.
6. **Every existing check, fixture and expected value preserved.**
   - Against the base, audit-recon and mutate only add lines (+318/+46). Every other suite file is byte-identical.
   - mcount finds every base entry once on c1.
   - Met.

## What I did not do

- I did not run full audit-import, full audit-board, the full mutate sweep, validate:math, verify:grid or Playwright.
- I did not re-run audit, audit-ppt, audit-other, legacy-fsrc, audit-hostile or audit-inject on c1 or the base. Those files
  are byte-identical to the builder's runs. audit and audit-ppt ran only on my four mutants.
- I did not re-run the focused audit-board PRIME-3 harness. The board and audit-board are unchanged since the build.
- I edited no builder file and no draft. The proposal is in `proposal/` and `p1/` for the builder or the lead.
- I committed and pushed nothing, and did not touch `/home/user/orbit-board` or `/home/user/orbit-ui` beyond reading them
  and making a `--shared` clone in my directory.
