# U40 — independent adversarial verification, lens A (data loss and money), round 1

Verifier's directory: `rec/L6/u40/verify-money-r1/` (paths below are relative to it). 13 Oct 2026, all times Eastern;
this review began at 3:58 PM ET (no earlier attempt of this review existed: the directory was new) and this README was
written after the last run, which ended at 4:22:46 PM ET. Nothing was committed, staged or pushed anywhere;
`/home/user/orbit-board` and `/home/user/orbit-ui` were only read; the builder's files were only read (everything I ran
used my own copies under `copies/`). Every populated board existed only in memory during a run.

## Verdict

**sound-with-issues — one must-fix before commit.** The change does what the finding needs: on every read-in route I and
the builder tried, the file's "Alpha Depot" and "ALPHA DEPOT" stay two, R1's $900 and R2's $300 stay on their own
destinations (funds flow and the Funds Flow workbook read back from its bytes), a typed matching name is refused with
nothing written, and it composes with U10 (c4) without conflict. But the new notice says something false about a list
that holds one key twice — the lead's own note on U44 (3:46 PM ET) asks U40 for exactly this — and it does so on every
opening of such a board, in the destinations panel and after a full import. A two-line fix is given and verified below.

## 1. Identities (checked first, text only)

| file | base (`rec/L6/base`) | c1 (`rec/L6/u40/c1`) |
|---|---|---|
| board | `fce8a391` | `278bf731` |
| audit-import | `4aba2506` | `de59f3ce` |
| mutate.mjs.txt | `cbc6defc` | `c117c384` |

- `copies/base` and `copies/c1` are `cp -a` of those (node_modules symlink kept), blobs as above.
- `diff -rq copies/base copies/c1`: only the three files differ.
- The board and mutate diffs re-derived (`out/board.diff`, `out/mut.diff`) are byte-identical to the builder's
  `diffs/c1-vs-base.*.diff` (after the two header lines). audit-import: a pure insertion of 193 lines after line 7799,
  equal to `block-u40.mjs.txt` (`out/ai.diff`).
- The focused harness rebuilt here from c1's audit-import with the builder's `bin/mkfocused-u40.py` (read first; it is
  `rec/L2/u2impl/mkfocused-u2.py` with several ranges): `harness/c1/focused-u40.mjs`, blob `4087f9c5` = the builder's.
- mcount (text only, `rec/bin/mcount.py`, `python3 -I`): base 1,328 / 1,328 once; c1 **1,343 / 1,343 once**, 0 missing,
  0 multiple, 0 unparsed (`logs/mcount-base.json`, `logs/mcount-c1.json`).
- The three mutants I re-ran were remade with `rec/bin/mkmut.py` from c1's mutate text: each `"matches": 1`, and each blob
  equals the board the builder's M2 run booted (626a14a9, cf4af2b2, f58d6e4d).

## 2. Must-fix

### M1. The notice calls ONE destination "two destinations kept apart" when the list holds its key twice (false words, every opening)

The lead's note on ledger row U44 (13 Oct, 3:46 PM ET): *"Note for U40: its new notice must not pair two entries that
share one key."* c1's `destNotice` pairs entries by index (`i!==j`), not by key. The builder finished at about 3:52 PM ET;
nothing in c1 or its drafts addresses the note.

**Reproduction** (`probes/vmoney2.mjs`, route V1/V1b; synthetic; expected values typed): a board whose list holds
`dA "Alpha Depot"` twice (the U44 file shape) with R1 on dA. Saved, then (a) opened in a fresh browser, (b) brought in
with Import a full board (`fullImportText`) and reopened.

- c1 (`logs/P2-vmoney2-c1.log`, also `logs/P1-vmoney-c1.log`): the opening line reads "📦 Opened with the saved board state
  — … ⚠ Destinations with matching names are kept apart: Alpha Depot [dA] · Alpha Depot [dA]. Each keeps its own
  requirements and money; rename one so they can be told apart." The same in the destinations panel, and after the full
  import ("⬅ Full board imported … The destination list — 11. ⚠ Destinations with matching names are kept apart: Alpha
  Depot [dA] · Alpha Depot [dA]. …"). It is one destination; nothing is kept apart; "rename one" would rename half of one
  destination. With a real pair beside it (dC "ALPHA DEPOT"), dA is listed twice: "Alpha Depot [dA] · Alpha Depot [dA] ·
  ALPHA DEPOT [dC]".
- The refusal has the same fault: re-casing the second dA entry says "“ALPHA DEPOT” matches “Alpha Depot”, another
  destination on the list" — it is the same destination.
- Base (`logs/P2-vmoney2-base.log`): says nothing (no notice exists there).
- The list itself is carried as the file holds it on both boards (CONTROL lines hold), so this is words, not money; the
  money printed twice for such a list is U44's own finding.

**Minimal fix** (verified; `copies/c1fix`, board `b516671f`; the exact diff is `out/c1fix-vs-c1.board.diff`, blob
`06328c88`):

```diff
-  const o=(field==='n' && destNamed(v))? L.filter(function(x){ return x!==e && destName(x.n)===destName(v); })[0] : null;
+  const o=(field==='n' && destNamed(v))? L.filter(function(x){ return x!==e && x.k!==e.k && destName(x.n)===destName(v); })[0] : null;
...
-  const L=DESTDB.ents||[], D=L.filter(function(e,i){ return destNamed(e.n) && L.some(function(x,j){ return i!==j && destName(x.n)===destName(e.n); }); });
+  const L=DESTDB.ents||[], D=L.filter(function(e,i){ return destNamed(e.n) && !L.slice(0,i).some(function(x){ return x.k===e.k; })
+    && L.some(function(x){ return x.k!==e.k && destName(x.n)===destName(e.n); }); });
```

(The `destNotice` line is the must-fix; the `flowSetEnt` line only stops the refusal calling the same key "another
destination" — it then lets the second copy of dA be re-spelled, as the base did, which is U44's ground. The builder may
take the notice line alone.)

Results on c1fix: every V1/V1b claim holds (`logs/P2-vmoney2-c1fix.log`: notice empty for the repeated key; with dC beside
it "Alpha Depot [dA] · ALPHA DEPOT [dC]", dA once); the builder's focused harness **106/106** (`logs/VF-c1fix.log`); c1's
1,343 mutation entries still each match once on c1fix (mcount, text only).

**Test and mutations to add** (my proposal; the builder writes them in the block's style). A check "a list holding one key
twice beside a real pair: the notice names dC and names dA once" — fails on the base (nothing said: 0), fails on c1 (dA
twice: 2), passes on c1fix (1) — plus a CONTROL "one key twice alone is never called kept apart" (holds on the base
because it says nothing; fails on c1). Two mutation entries, both matching c1fix exactly once (`proposed-entries.mjs.txt`;
mcount 2/2 once on c1fix) and both caught by those checks:

| id | what | run | caught by |
|---|---|---|---|
| `v200-u40-apart-pairs-one-key` | pairs by index again (`j!==i`) | PM-v200-u40-apart-pairs-one-key, exit 0 (probe) | the four V1 "not kept apart" claims DIFFER |
| `v200-u40-apart-key-twice` | names each key as often as the list holds it | PM-v200-u40-apart-key-twice, exit 0 (probe) | V1b "dA named once" DIFFERS (got 2) |

(The probe always exits 0; its verdict is the CLAIM lines and the TALLY.)

## 3. Should-fix

### S1. A pair whose second key the newer list deleted comes back as TWO destinations: the plan and its locked cycle name different ones for R2

Route V2 (`probes/vmoney2.mjs`): the file's pair (U40-A "Alpha Depot" R1 $900, U40-B "ALPHA DEPOT" R2 $300, two years, a
locked PB27), opened where a second person's newer list holds Bravo Yard and has U40-B in its `gone` list (they deleted it;
R2 still uses it, so it comes back under a new key, as v1.86 does). Each reading of the same list in that one opening —
the plan, then the locked cycle store — refuses the name (the list holds it twice) and makes **another** new key:

- c1 (`logs/P2-vmoney2-c1.log`): list after opening `…, dmv…15nib=ALPHA DEPOT, …, dmv…5e14q=ALPHA DEPOT`; R2's key
  `{"plan":"dmv7457o15nib","next":"dmv7457o15nib","cycle":"dmv7457o5e14q"}`; saved there and reopened fresh, the split is
  kept. The notice lists three destinations kept apart. Money is right ($900 / $300, $1,200).
- Base: R2 merged into Alpha Depot everywhere ($1,200 on U40-A) — the U40 defect itself. A base board with a NON-matching
  name brings the key back once (the second reading finds the first by name), so the split is new with c1.

Not money and nothing is lost, but one destination becomes two that nobody made, the working plan and its locked cycle
disagree about R2's destination, and the notice then asks the person to rename one of two copies of one place.
**Fix (verified):** remember, for the session, the key a v1.86 entry came back under, and reuse it on the next reading
(`copies/c1fix2`, board `1eeebc7d`; diff against c1fix `out/c1fix2-vs-c1fix.board.diff`, blob `3c6e843e`, 8 lines:
`_destBack` beside `_destMerges`; in `destFold`'s new-key branch, `const back=v186? destHas(_destBack[k]||'') : null; if(back
&& !taken(back.k)) hit=back; else { …as now…; if(v186 && k!==String(e.k)) _destBack[String(e.k)]=k; }`). On c1fix2: all
13 claims hold (`logs/P3-vmoney2-c1fix2.log`: one "ALPHA DEPOT", plan/next/cycle on one key, stable after save and
reopen); the focused harness 106/106 (`logs/VF-c1fix2.log`); c1's 1,343 entries match once. **Or**, if the lead prefers
the smaller commit, name it in the entry's "Not covered".

### S2. The drafts' title says more than the board does

"two destinations whose names match stay two" (commit subject and NEXT-VERSION heading). Route V3: the file holds only
"ALPHA DEPOT" (U40-B, R2 $300) and the second person's newer list its own "Alpha Depot" (U40-C): R2 goes to U40-C (plan,
next year, cycle) — the v1.86 rule for one name on two lists, which c1 keeps on purpose and now says: the opening line
reads "… Merged by name (the same name, ignoring case and spaces): ALPHA DEPOT [U40-B, O&M] → Alpha Depot [U40-C]." and
the panel lists it (`logs/P2-vmoney2-c1.log`; base says nothing). Saved there and reopened, nothing says it again (the
draft's "Not covered" names this). That matches v1.86's can't-fail ("only exact name matches … are [merged], and each
merge is listed"), but two destinations whose names match did not stay two. Suggest the heading say "two destinations of
one list whose names match stay two" (or similar), so the line stays true. Also add S1 (if not fixed) and M1's U44
interplay to "Not covered"/the ledger text.

## 4. Minor

- **m1 (pre-existing, made more frequent):** where three destinations are kept (the newer list's own "Alpha Depot" beside
  the file's pair) the Funds Flow summary sheet has two rows with the identical label "Alpha Depot" ($0 and $900) beside
  "ALPHA DEPOT" ($300); the sheets are "Alpha Depot", "Alpha Depot 2", "ALPHA DEPOT 3". Every figure is right
  (`logs/P1-vmoney-c1.log`, V4), but a reader cannot tell the two "Alpha Depot" rows apart without the board; the notice
  asks for a rename. Could print the key when names collide.
- **m2:** `destFold`'s "the board holds the name twice" counts entries, not keys, so a repeated key (U44) makes an incoming
  same-named entry stay apart rather than merge — conservative and said; U44's ground.
- **m3:** `_destMerges` keeps the names and keys as they were when the merge was made; after a later rename, delete or reset
  in the same session the panel still prints them (read, not run; it is a record of what happened, so it stays true as
  history).

## 5. What was re-run, and what it showed

- **Focused harness (builder's, rebuilt here, blob 4087f9c5):** c1 **106/106** (v1.86 ×3 48, U40 58); base exit 1 with
  **43 U40 checks failing and the 15 CONTROLs + 48 v1.86 passing** — exactly the builder's F5-c1/F4-base.
- **Mutants (3 of the builder's 15, remade):** each exit 1, only U40 checks failing, none of the 48 v1.86 checks:
  `incoming-pair-merged` 7 failing (the newer-list-holds-Alpha-Depot route: notice, funds flow, workbook…),
  `typed-duplicate-kept` 9, `opening-replaces` 5 — the builder's counts.
- **U40 beside U10 (the overlap the lead named):** U10's diffs/ now hold c4 (board `f726ecfc`, audit-recon `6d0f396a`, mutate
  `8f51d4bb`, written 3:02 PM ET), so I composed with c4 independently: `git merge-file` of the boards (c1 / base / U10 c4)
  **0 conflicts**, result `1fe875ac` = the builder's `xc4` byte for byte; the mutate texts 1 add/add conflict at the R3
  anchor, keeping both (U40's then U10's) = the builder's `ca1e4585`; audit-recon taken from U10 c4; mcount 1,383 / 1,383
  once. On that composition: U40's harness **106/106**, U10 c4's harness (blob 03410810) **111/111** (11, 27, 9, 27, 9,
  28), the builder's compose probe (read first; blob 92474534) **10/10**: in PB27's view U10's "🔒 Changing a destination is
  off while PB27 is on screen." speaks and no U40 line is said; on the working plan U40's refusal word for word; a name of
  its own stored. Only overlap: `flowSetEnt`, U10's `cycBlock` line first, U40's check after it. **They compose; no
  conflict.** (c2 composition is the builder's; not re-run.)
- **Every route the lead listed:** typing, opening fresh, a newer cached list, full import, an appropriation taken
  (`consTakeApply`), shared folder (`applyStore`), PMO submittal, locked cycles, both hops and the Funds Flow detail sheets
  — the builder's block covers each and passes here; I added a repeated key (M1), a deleted key (S1), one name on two lists
  (S2) and three same-named destinations in the export (m1). Read only: `cycTake` copies a cycle's keys unread (both
  boards; c1 helps because the plan's two keys now exist), `importStores` → `cycTake` the same, exports read destinations by
  key (`flowCalc`, `exportFlow`, bulk setters, pickers), so no export groups by name.

## 6. The six decision principles, literally, on c1

1. **No copy lost:** holds on every route run (both destinations, both hops, years, cycle). S2's merge by name is v1.86's
   rule, said once.
2. **Refuse or ask rather than guess:** holds (typed refusal; ambiguity kept apart). S1: not a guess, but a duplicate.
3. **Money and exports exact:** holds — $900 / $300 / $1,200 on every route, workbook sheets separate (m1 labels only).
4. **Every word true:** **fails on M1** (repeated key: "kept apart … each keeps its own requirements and money; rename one",
   and "another destination"). True elsewhere (V3's merge line matches what happened).
5. **Smallest change:** about 49 board lines; the M1 fix adds one.
6. **Existing checks preserved:** the three v1.86 destination scenarios 48/48 on c1, c1fix, c1fix2 and xc4; every existing
   mutation entry still matches once (c1, c1fix, c1fix2, xc4). Other suites: the builder's runs, not repeated by me.

## 7. Every run (each through `run.sh`: `setsid -w timeout -k 10 600`, lock checked first — never set during this review)

| label | start (ET, 13 Oct) | exit | wall s | log | result |
|---|---|---|---|---|---|
| VF-base | 16:05:30 | 1 | 93.6 | logs/VF-base.log | base: v1.86 48 pass; U40 43 fail, 15 CONTROL pass |
| VF-c1 | 16:05:30 | 0 | 100.6 | logs/VF-c1.log | 106/106 |
| P1-vmoney-c1 | 16:07:49 | 0 | 28.9 | logs/P1-vmoney-c1.log | first probe: V1 false notice; V2 split; its 2 CONTROL lines wrong (my expectation left out the 8 seeded destinations; same on base) — corrected in vmoney2 |
| P1-vmoney-base | 16:07:49 | 0 | 34.6 | logs/P1-vmoney-base.log | base: the merge reproduced (V2 $1,200, V4 one sheet) |
| VX-u40-on-xc4 | 16:10:27 | 0 | 92.3 | logs/VX-u40-on-xc4.log | 106/106 on c1 + U10 c4 |
| VX-u10c4-on-xc4 | 16:10:27 | 0 | 248.5 | logs/VX-u10c4-on-xc4.log | 111/111 |
| P2-vmoney2-c1fix | 16:12:17 | 0 | 83.1 | logs/P2-vmoney2-c1fix.log | CLAIM 11 hold, 2 differ (S1 only) |
| P2-vmoney2-c1 | 16:13:41 | 0 | 49.0 | logs/P2-vmoney2-c1.log | CLAIM 6 hold, 7 differ (M1 ×5, S1 ×2) |
| C1-compose-xc4 | 16:14:55 | 0 | 16.6 | logs/C1-compose-xc4.log | 10/10 |
| VF-c1fix | 16:14:55 | 0 | 116.4 | logs/VF-c1fix.log | 106/106 |
| VM-v200-u40-incoming-pair-merged | 16:15:28 | 1 | 122.9 | logs/VM-…incoming-pair-merged.log | caught: 7 U40 checks |
| P3-vmoney2-c1fix2 | 16:17:01 | 0 | 57.5 | logs/P3-vmoney2-c1fix2.log | CLAIM 13/13 |
| VM-v200-u40-typed-duplicate-kept | 16:17:31 | 1 | 134.1 | logs/VM-…typed-duplicate-kept.log | caught: 9 |
| VF-c1fix2 | 16:18:09 | 0 | 118.0 | logs/VF-c1fix2.log | 106/106 |
| VM-v200-u40-opening-replaces | 16:19:45 | 1 | 104.1 | logs/VM-…opening-replaces.log | caught: 5 |
| PM-v200-u40-apart-pairs-one-key | 16:20:17 | 0 | 48.4 | logs/PM-…pairs-one-key.log | caught (V1 ×4 differ) |
| PM-v200-u40-apart-key-twice | 16:21:06 | 0 | 46.4 | logs/PM-…key-twice.log | caught (V1b differs) |
| P2-vmoney2-base | 16:21:59 | 0 | 47.6 | logs/P2-vmoney2-base.log | CLAIM 5 hold, 8 differ (the U40 defect; V1 holds vacuously) |

Text-only helpers, each under `setsid -w timeout -k 10 <120–600>`, run in the foreground (no PID recorded): mcount on base,
c1 (16:08:12), xc4 (16:09:53), c1fix, c1fix2, the two proposed entries; mkmut for five mutants; `git merge-file` ×2
(16:09). Never more than two node processes of mine at once (checked against the start/end times above).

Probe claims across the boards (vmoney2):

| claim | base | c1 | c1fix | c1fix2 |
|---|---|---|---|---|
| V1 repeated key not called "kept apart" (×4) | hold (nothing said) | **differ** | hold | hold |
| V1b real pair named / dA named once | differ / differ (0) | hold / **differ (2)** | hold / hold | hold / hold |
| V2 R2 off Alpha Depot; one destination for R2; one ALPHA DEPOT; money | differ; hold; differ; differ | hold; **differ**; **differ**; hold | hold; differ; differ; hold | all hold |
| V3 merge named on opening / in panel | differ / differ | hold / hold | hold / hold | hold / hold |
| V4 $900 and $300 on separate summary rows | differ | hold | hold | hold |

### PIDs (all mine; `pids.txt`; nothing else was ever signalled — I killed nothing)

27172/27175 VF-c1 · 27194/27196 VF-base · 28682/28684 P1-vmoney-c1 · 28701/28703 P1-vmoney-base · 31288/31290 VX-u40-on-xc4 ·
31313/31315 VX-u10c4-on-xc4 · 803/805 P2-vmoney2-c1fix · 2042/2044 P2-vmoney2-c1 · 3953/3955 VF-c1fix · 4029/4031
C1-compose-xc4 · 4594/4596 VM-incoming-pair-merged · 6238/6240 P3-vmoney2-c1fix2 · 6781/6783 VM-typed-duplicate-kept ·
7247/7248 VF-c1fix2 · 8651/8653 VM-opening-replaces · 9161/9163 PM-apart-pairs-one-key · 9829/9832 PM-apart-key-twice ·
10636/10643 P2-vmoney2-base (timeout PID / node PID).

## 8. Files here, with blobs (`git hash-object`)

| file | blob | what |
|---|---|---|
| run.sh | bf5884c7 | bounded runner (the builder's, re-pointed to this directory) |
| runner.mjs | f851f139 | the builder's runner, unchanged (asserts and prints the board it boots) |
| probes/vmoney.mjs | a6996f13 | first probe (two CONTROL expectations wrong, see P1) |
| probes/vmoney2.mjs | 3fef6203 | the probe the findings rest on |
| probes/compose-builder.mjs | 92474534 | the builder's compose probe, copied after reading |
| harness/c1/focused-u40.mjs | 4087f9c5 | rebuilt here, = the builder's |
| harness/xc4/focused-u10.mjs | 03410810 | U10 c4's harness, copied |
| copies/c1fix/…board | b516671f | c1 + the M1 fix |
| copies/c1fix2/…board | 1eeebc7d | c1fix + the S1 fix |
| copies/xc4/…board, mutate, audit-recon | 1fe875ac, ca1e4585, 6d0f396a | c1 + U10 c4 |
| out/c1fix-vs-c1.board.diff | 06328c88 | the M1 fix |
| out/c1fix2-vs-c1fix.board.diff | 3c6e843e | the S1 fix |
| proposed-entries.mjs.txt | — | two proposed mutation entries (wrapped copy in out/) |
| mut/*.html, *.make.json | — | the five mutants run, with their mkmut records |

## 9. Not done (plainly)

- The full audit-import and audit-board suites (the lead's alone); the other suites (boot-same, audit, audit-ppt,
  audit-other, legacy-fsrc, audit-hostile, audit-inject, audit-recon, npm run check) were **not** re-run by me — the
  builder's records are the only evidence for them.
- 12 of the builder's 15 mutants were not re-run (3 were, all caught as recorded). The S1 fix has no test block or
  mutation entries written — only my probe and the focused harness.
- mutate.mjs was never imported, executed or run (text only). No Chromium, no playwright install. Codex's scripts were not
  run. Composition with U10 c2 was not re-run (the builder's).
- Not tested: two real machines, a real shared folder, Excel opening the workbook (read back with the board's `xlsxRead`),
  how the notice looks on screen, the PMO-copy route with a repeated key, and a merge listed and then renamed (m3, read
  only).
- Some quick read-only shell commands (cat, grep, diff, cp, git hash-object) ran without the setsid/timeout wrapper or a
  PID line.
