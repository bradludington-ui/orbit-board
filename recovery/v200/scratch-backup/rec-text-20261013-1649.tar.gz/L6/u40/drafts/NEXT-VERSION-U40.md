<!-- Draft for NEXT-VERSION.md, under v2.00, after the U14 entry and before "Unresolved after R1–R5". The lead commits. -->
- **U40 — two destinations whose names match stay two; a requirement never loses its destination** (the lead, 13 Oct,
  12:02 PM ET: a release blocker, data loss; built on Brad's "Don't wait for me. Let's keep pressing throughout to get this
  next version published." of 12 Oct). Two destinations are one when their names match, ignoring case and spaces, yet typing
  kept "ALPHA DEPOT" beside "Alpha Depot", each with its own requirements. Opened in a browser whose own destination list was
  newer (a second person's), the file's list was read into that one by name: its second entry matched the first, which the
  same reading had just added, and the two became one. R2's $300 moved to Alpha Depot in the year on screen, the next year,
  on both hops and in the locked cycle; the funds flow and its workbook put R1's $900 and R2's $300 on one sheet; the
  opening line said only that the file had opened; and a save kept the merge. The same reading ran for a list saved before
  v1.86 (in any browser), an appropriation taken from another file, a shared-folder load and a PMO submittal, and a map an
  older board kept could send both entries to one destination without reading a name at all. Now a typed name another
  destination has is refused and nothing changes. One reading never puts two entries of its list into one destination,
  through a kept map or by name, and a name is not trusted to choose where the list itself, or the board's, holds it twice,
  or where it names another entry of the same list: the entry keeps its own key. The destinations panel and the opening line
  name the destinations kept apart and list every merge made by name (v1.86 promised "each merge is listed"). Starting point:
  Codex's batch A3 proposal, adopted after review, with one more guard (a name may not choose a destination the same
  reading already gave another entry) and its wording changed. Predates v2.00 (v1.86).
  - **What users may see:** a name another destination already has, typed into the destinations panel, is refused. The
    field keeps what was typed, marked in red, with a tooltip; the line reads "⚠ Destination name not changed. “ALPHA
    DEPOT” matches “Alpha Depot”, another destination on the list (names are compared ignoring case and spaces). This one
    keeps the name “Bravo Yard”; give it a name of its own. Nothing was changed." A board whose list holds two such names
    says so on opening, after its usual line, and in the destinations panel until one is renamed: "⚠ Destinations with
    matching names are kept apart: Alpha Depot [U40-A] · ALPHA DEPOT [U40-B]. Each keeps its own requirements and money;
    rename one so they can be told apart." (in brackets, each destination's key). A merge by name, the v1.86 rule for one
    name on two lists, is listed in the panel and on opening: "Merged by name (the same name, ignoring case and spaces):
    RAYTHEON [x1, Full Fund] → Raytheon [d…]." Where a second person's list already has a destination of that name, the
    file's two are kept beside it and all three are named. The Funds Flow workbook gives each its own sheet ("Alpha Depot",
    "ALPHA DEPOT 2"), as it always did for two destinations.
  - **Test:** audit-import "v2.00 (U40) — two destinations whose names match stay two, and every merge by name is said"
    (58 checks). Typing: two spellings, the panel's own field, and the correction. The file, with both hops, two years and a
    locked cycle: opened fresh, where a newer list holds Bravo Yard or an Alpha Depot of its own, and each saved there and
    reopened (destinations by name, the funds flow, the Funds Flow workbook read back, the panel, the opening line). A list
    saved before v1.86. An appropriation taken from the file, a shared-folder load, a PMO submittal and a full import.
    destFold read directly: a key of the same list, a name the board holds twice, an older board's map, a name a destination
    took on since, and one name on another list (merged, the same way twice, and listed). Dollars are typed: R1 $900, R2
    $300, $1,200. 43 checks fail on the board before the change; the 15 controls pass on both. The three v1.86 destination
    scenarios (48 checks) pass unchanged.
  - **Mutations:** `v200-u40-typed-duplicate-kept`, `-refusal-field-unmarked`, `-refusal-names-itself`,
    `-incoming-pair-merged`, `-ambiguous-local-first`, `-same-list-key-consumed`, `-map-collapse-followed`,
    `-name-into-taken`, `-claim-unrecorded`, `-merge-unlisted`, `-merge-from-slug`, `-apart-unsaid`,
    `-editor-notice-gone`, `-opening-unsaid` and `-opening-replaces`; each caught by the focused block (full-suite
    sensitivity runs in the final-tree queue).
  - **Not covered:** a later message replaces the opening line (the panel keeps the notice); a merge is listed for the
    session it was made in, not saved in the file; a file already saved with the merge cannot be split again (its two
    entries are gone); boards before this one (v1.86 to v2.00 as it stood) still merge such a pair when they read it; where
    such a board already merged a pair and stored its map, the readers that use the stored map without reading the list
    again (a PMO submittal from a copy published before v1.86, which carries no list; a locked-cycle store from before
    v1.86; the "in use elsewhere" count) still follow it -- the board's own requirement was already moved by that board; a
    typed name of any length, untrimmed (the ledger's 5,000 characters); a locked cycle taken from a file (`cycTake`)
    keeps its keys as they were and is not read through a list (this change keeps keys; it does not re-point them); and
    Chromium, and two real machines.
