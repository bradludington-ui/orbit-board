# U40 — two destinations the board calls the same name never merge unasked; a requirement never loses its destination

Builder track, ORBIT v2.00 release, 13 Oct 2026 (all times Eastern). Directory: `rec/L6/u40/` (paths below are relative to
it). **One proposed commit.** Nothing was committed, staged or pushed anywhere; `/home/user/orbit-board` and
`/home/user/orbit-ui` were only read (two scratch clones, `gc-base/` and `gc-c1/`, were made from orbit-board with
`git clone --shared` for the suites that need git; nothing was committed in them). The board file stays the empty template:
every populated board in this work existed only in memory during a run.

## 0. Second start (13 Oct, from 2:44 PM ET): what was kept, what was re-run, what is new

The first builder of this track was stopped by a usage limit at about 2:29 PM ET (13 Oct); the lead checked at 2:44 PM ET
that none of its processes was running. This builder started at 2:44 PM ET, read everything in the directory first, and
continued from it. PIDs in `pids.txt` from before 2:44 PM ET belong to the first builder; nothing recorded there was
touched (a PID alive now belongs to another agent after PID reuse).

**Re-checked before anything was relied on (text only, no node):**

- Blobs of every copy (`c1/`, `x10/`, `codex/applied/`, the base) recomputed with `git hash-object`: as section 1 states.
- `c1/` against the base: only the board, audit-import and the mutate text differ (`diff -rq`); every other file `cmp`-equal
  (NEXT-VERSION.md, package.json, the shim, boot.mjs, audit-recon/board/other). The three stored diffs in `diffs/` were
  re-derived and are byte-identical. The board's `pubState` payload is unchanged (4 bytes, the empty template).
- c1's audit-import REBUILT from the base + `block-u40.mjs.txt` (`bin/insert-block.py`): byte-identical to c1's
  (`verify2/audit-import.mjs`). The focused harness REBUILT from it with `bin/mkfocused-u40.py`: byte-identical to
  `harness/c1/focused-u40.mjs` (blob `4087f9c5`). `bin/mkfocused-u40.py` diffed against `rec/L2/u2impl/mkfocused-u2.py`:
  only the several-ranges change, the `!` end and the header text, as its comment says.
- All 15 mutants REMADE from c1's mutate text with `rec/bin/mkmut.py` (`verify2/mut/`): each `"matches": 1`, and each blob
  equals the board the M2 run actually booted (the blob is printed in each log's IDS line).
- mcount (text only) re-run: base 1,328 / 1,328 once; c1 1,343 / 1,343 once; x10 1,360 / 1,360 once; 0 missing, 0
  multiple, 0 unparsed (`logs/mcount2-*.json`).
- x10 rebuilt independently (`x10check/`: c1 + U10 c2's two diffs with `patch`): byte-identical board and audit-recon.
- Every earlier run with an exit record was checked against its log (board blob, harness blob, `# end` line): F4-base,
  F4-codex, F5-c1, all 15 M2 mutant runs, X2-u10-on-x10, P4-repro-base, P4-repro-c1, C1-compose-c1, S-boot-same-c1. Their
  check files were re-tallied (`out/*.checks.jsonl`): F5-c1 106/106; F4-base 48 + 15 pass, 43 fail, every pass a CONTROL and
  every failure a U40 check; F4-codex 44 + 48 pass, 14 fail; every M2 mutant exit 1 with U40 checks failing, none threw.

**Kept from the first builder (sound, checked as above):** the design and c1 (board `278bf731`, audit-import `de59f3ce`,
mutate text `c117c384`), the block and the 15 entries, the harness, F4/F5 and the 15 M2 mutant runs, P2–P4, X2, the r1
record, x10 and its two harnesses, the drafts (updated in this start: section 13).

**Unfinished when the first builder stopped, and RE-RUN in this start** (`post3.sh`, two lanes, new labels so no earlier
log is overwritten): `S-audit-c1` (log has no end: replaced by `S-audit-c1b`) and `C1-compose-x10` (no end: replaced by
`C2-compose-x10`; `C1-compose-c1` was also re-run as `C2-compose-c1`, because the probe's "left the view" expectation was
corrected after that run). **Never started, and run in this start:** the U40 focused harness on x10 (`X3-u40-on-x10`; the
first builder's planned `X1`), every other suite on the base and on c1 (`S-*-base`, `S-*-c1b`, `npm run check` included),
and, informational only, the composition with U10's newest copy c4 (`post4.sh`: `xc4/`, section 7). Two of this start's suite runs were themselves interrupted (their lane wrapper's cap) and two capped at 600 s under load; all four were re-run (`post5.sh`, `post6.sh`; sections 10, 14).

**New in this start:** `post3.sh`, `post4.sh`, `post5.sh`, `post6.sh`, `verify2/` (the rebuilt files, the remade mutants, U10 c4's diffs, and `merge3/`: U40 and U10 merged as git would, section 7), `x10check/`,
`xc4/` + `harness/xc4/`, `logs/mcount2-*.json`, section 7's c4 paragraph, the README's sections 0 and 10–11 filled, and the
drafts' composition sentences. `gc-c1/tools/export-audit/mutate.mjs` now holds c1's mutate text (copied, never run), so the
clone is the commit's tree exactly. A note line the first minutes of this start wrote into `pids.txt` was given a leading
`#` (it began with a number that could be read as a PID); `bin/tables.py` now skips `#` lines.

## 1. The proposed commit

**Subject:** `v2.00 (U40): two destinations whose names match stay two; a typed name another destination has is refused; every merge by name is said`

Cumulative copy `c1/` = base (`rec/L6/base`, orbit-board `7ee498a`, product `d66dd60`) + this commit.

| file | base blob | c1 blob |
|---|---|---|
| `prioritization-board-grid.html` | `fce8a391bd8a248d5185e199d22190c1687eaea0` | `278bf731db8dab7fe7007b06226a46cdaba097ef` |
| `tools/export-audit/audit-import.mjs` | `4aba2506a7ea3bd367fb74436172b188bb4fc887` | `de59f3ce0abf974234308cc20adc8998f4d24966` |
| `tools/export-audit/mutate.mjs.txt` (text of `mutate.mjs`) | `cbc6defc6803851e847844848fc9b186daeeb268` | `c117c38453d9951e286b2806d5aa20b1afefc041` |
| every other file in the copy | unchanged | unchanged (checked file by file with `cmp`) |

Diffs: `diffs/c1-vs-base.prioritization-board-grid.html.diff` (120 lines), `diffs/c1-vs-base.audit-import.mjs.diff`
(202 lines), `diffs/c1-vs-base.mutate.mjs.txt.diff` (56 lines), all three in `diffs/c1-vs-base.all.diff`. They are
reproduced in full in section 15. In the real tree `mutate.mjs.txt` is `tools/export-audit/mutate.mjs`.

## 2. The finding, reproduced on the base first

Own probe `probes/repro.mjs` (blob in section 12), synthetic data, every expected value a typed literal; each line is a
CONTROL (should hold on every board) or a DEFECT check (the U40 claim). Fixture: R1 $900 and R2 $300 (USAF, O&M FY27);
destinations U40-A "Alpha Depot" and U40-B "ALPHA DEPOT" (as a base board lets them be typed); R1 → U40-A then U40-B,
R2 → U40-B then U40-A (both hops); the year on screen, the next year, and a locked PB27; the funds flow by destination.

| run | board | result |
|---|---|---|
| P2-repro-base (13:25:45, exit 0, 19.5 s) | base `fce8a391` | **8 controls pass; all 15 DEFECT checks differ** |
| P3-repro-codex (13:26:10, exit 0, 18.9 s) | Codex A3 `2419366b` | 8 controls pass; 12 DEFECT pass; the 3 that differ were the probe's own wrong expectation (see below) |

What the base does (P2, literal values): typing "ALPHA DEPOT" beside "Alpha Depot" is accepted. Opened in a fresh browser
the file keeps both (control). Opened where a second person's destination list is newer (it holds "Bravo Yard"):
`{"cur":"Alpha Depot > Alpha Depot | Alpha Depot > Alpha Depot", "other": same, "cycle": same, "sameKey":true,
"alpha":["Alpha Depot"]}` against the file's two; the funds flow `{"Alpha Depot [U40-A]":1200}` where it was 900 and 300;
the Funds Flow workbook `{"Alpha Depot":["Req R1 900","Req R2 300"]}` (one sheet) where it was two; the status line only
"📦 Opened with the saved board state — last saved by unknown … Make changes and 💾 Save to pass it on." (its clock is
jsdom's UTC); saved there and reopened fresh, the merge is kept. With a newer list holding its own "Alpha Depot" (U40-C),
both requirements land on U40-C ($1,200). The same merge, by the same `destFold`, happens for a list saved before v1.86 in
a FRESH browser (`["Alpha Depot","Alpha Depot",false]`), an appropriation taken from the file (`consTakeApply`, read
after its reload), a shared-folder load (`applyStore`) and a PMO submittal (`destPkgIn`). A full import replaces the
board's list with the file's and keeps both (control). Logs: `logs/P1-repro-base.log` (first attempt: route D booted the
wrong way and threw; corrected in P2), `logs/P2-repro-base.log`, `logs/P3-repro-codex.log`.

The 3 lines P3 shows as differing were the probe's expectation for the "newer list holds its own Alpha Depot" route: the
probe expected two Alpha names and sheets "Alpha Depot"/"ALPHA DEPOT 2", but a correct board keeps the second person's
Alpha Depot too, so there are three Alpha names and the sheets are "Alpha Depot 2"/"ALPHA DEPOT 3". The probe was corrected
(route-specific W2/S2) and re-run on the base and c1 (probe text blob `2413f6b5`, the text both P4 runs ran):

| run | board | start (ET) | exit | wall s | result |
|---|---|---|---|---|---|
| P4-repro-base | base `fce8a391` | 14:23:43 | 0 | 54.4 | 8 CONTROL hold; **all 15 DEFECT lines differ** (`TALLY {"CONTROL":[8,0],"DEFECT":[0,15]}`) |
| P4-repro-c1 | c1 `278bf731` | 14:28:03 | 0 | 104.1 | 8 CONTROL hold; **all 15 DEFECT lines hold** (`TALLY {"CONTROL":[8,0],"DEFECT":[15,0]}`) |

(The probe always exits 0; its verdict is the TALLY line. Logs `logs/P4-repro-base.log`, `logs/P4-repro-c1.log`.)

## 3. Review of Codex's proposal (batch A3), and what was adopted

Read before anything ran: `codex/report.md`, `codex/proposal.diff`, the three per-file diffs, `codex/probes/*` and the
logs. Codex's scripts were not run (not `runner.py`, not its probes); its applied copy `codex/applied/` was used only as a
variant board for my own probe and harness. Identities checked: board `2419366b`, audit-import `f68e4a54`, mutate text
`5a4d934a`; `codex/prioritization-board-grid.html.diff` applies cleanly to the base and gives `2419366b`.

Adopted (the design is Codex's): `flowSetEnt` refuses a typed name whose `destName` matches another destination's, before
any write, through the existing `codeRefusedIn` (the field keeps what was typed, marked); `destFold` keeps the board key
each entry of the list was read into (`claimed`) and does not follow a kept map into a key another entry took; a name is
not used to choose when the incoming list holds that name twice, when the board holds it twice, or (a v1.86 list) when it
names a destination whose key is another entry of the same list; `destJoin` records each key read into another by name
(`_destMerges`, this session only, no saved field); `destNotice` says what is kept apart and what was merged, in the
destinations panel and appended to the opening line.

Changed after review, with reasons:

1. **One more guard: a name may not choose a destination this same reading already gave another entry** (`taken()` is
   checked on the name path as well as the map path). Without it a list whose first entry was read, through an older
   board's map, into a destination since renamed to the second entry's name, and whose second entry's own destination is
   gone here while its requirements still use it, puts both requirements on one destination. Codex's board does exactly
   that: harness check "(6) a name a destination took on since" fails on `2419366b` (`out/F4-codex.checks.jsonl`) and
   passes on c1. Principle (1).
2. **The words.** The refusal names the destination the typed name matches ("“ALPHA DEPOT” matches “Alpha Depot”,
   another destination on the list …") and ends with the board's usual "Nothing was changed" (codeTake's wording),
   instead of "Not saved: another destination has that name … Stored name: …". The notice says "kept apart … Each keeps
   its own requirements and money; rename one so they can be told apart" instead of "Requirements still point at their
   own keys"; a merge names the list it came from by its appropriation's name (`appnName`, "Full Fund"), where Codex
   printed the internal slug ("ff") or "an imported list" (`from` is never empty). Principle (4).
3. **The panel's name field keeps its `onchange` text exactly as it was** (`flowSetEnt(i,"n",this.value)`); Codex added
   a fourth argument (`…,this.value,this)`) to reach the field. U10's new audit-recon block finds a destination's name
   field by that exact text (`on(e,'onchange')==='flowSetEnt('+i+',"n",this.value)'`), so with the fourth argument
   U10's checks could not find the field. My first build (r1, board `00096819`, kept in `r1/`) had Codex's fourth argument;
   it was revised before any final run: `flowSetEnt` now finds its own field
   (`#entBody input[onchange='flowSetEnt(i,"n",this.value)']`) to mark it. The panel's HTML is unchanged, and U10's diff
   now applies to c1 with `patch` alone (section 7). Principle (5) and (6).
4. **The opening line** no longer starts with a stray space when there was no line before it; `destNotice()` is worked
   out once per panel draw.
5. **The test block is my own** (section 5): Codex's checks hard-coded FY2027/FY2028 and a hand-made locked cycle; mine
   lock the cycle with `cycLock()` and read years from `MS.cur`, cover the four other read-in routes and the extra guard,
   compare the Funds Flow workbook's sheets to typed literals, and label every control. Codex's 10 mutation entries were
   replaced by 15 of my own (section 6).

Reviewed and kept as Codex had it, with the reasoning checked: an ordinary unambiguous name on another appropriation's list
still merges (the v1.86 rule), now listed; where a second person's list already has a destination of that name, the
file's two are kept beside it rather than one merged into it (the list holds that name twice, so the name cannot choose);
a merge is listed for the session, not saved in the file.

## 4. The change (what each part does)

- `var _destReady=…, _destMerges=[];` — the session's record of merges by name.
- `destJoin` — records `{k, n, to, name, from}` when a key is read into ANOTHER destination by name (once per key, target and
  list). Unchanged otherwise.
- `destFold` — `claimed` (an `Object.create(null)` map: board key → the source key read into it) and `taken(k)`; a map hit
  another entry took falls through to the name path; a name hit is dropped when `taken`, when the list holds that name on
  another key, when the board holds it twice, or (v1.86 list) when it is another entry's key in the same list. A dropped
  entry is kept under its own key (a v1.86 list's key when free; otherwise a new key, as before).
- `flowSetEnt(i, field, v)` — refuses `field==='n'` with a `destNamed` value matching another destination's `destName`;
  marks the panel's own field for entry `i` (found by its unchanged `onchange` text; none when the panel is closed) through
  `codeRefusedIn(el, …)`; returns before any write.
- `destNotice()` — the two sentences; `flowEntEditor` shows them under the table; the opening appends them to the line it
  just set (never in its place).

No saved field, no change to `flowCalc`, `exportFlow`, `destRemap`, `destMigrate`, `destPkgIn` or the import paths.

## 5. The test block and the focused harness

audit-import block "v2.00 (U40) — two destinations whose names match stay two, and every merge by name is said", after the
U13 block, in the v2.00 shape (async wrapper, `bootMark()`, the two-space `const name = '…';` line, `bootRelease(__bm,
keepBoards())`, `settleBoards()`, `// ==== v2.00 (U40): …` / `// ==== end v2.00 (U40) ====`). Text: `block-u40.mjs.txt`
(193 lines). 58 checks: 43 U40 checks and 15 labelled CONTROL. Dollars typed: R1 $900, R2 $300, $1,200.

(1) typing "ALPHA DEPOT" and "  alpha   depot  " beside "Alpha Depot" (refused; list, requirements, `_saveGen`,
`_sideGen`, DIRTY, `_baseDirty` and browser storage unchanged; the line word for word); the panel's own field through its
change handler (value kept, `aria-invalid`, tooltip word for word, focus kept) and its correction (stored, mark and tooltip
gone: control); a re-spelling of its own name, a kind, terms and two unnamed placeholders (control). (2) the file, opened
fresh (names, money and workbook: controls; the opening line kept and extended, the panel). (3) opened where a newer list
holds Bravo Yard, or an Alpha Depot of its own; each saved there and reopened fresh — destinations by name on both hops in
the year on screen, the next year and the locked cycle, two keys, the funds flow by key, the Funds Flow workbook read back
(`{"Alpha Depot":["Req R1 900"],"ALPHA DEPOT 2":["Req R2 300"]}`; with the local Alpha Depot `"Alpha Depot 2"`/`"ALPHA
DEPOT 3"`), the panel and the opening line. (4) a list saved before v1.86 (`v186AsV185`), fresh; reopened unsaved (same
keys: control); saved and reopened. (5) O&M taken from the file (`consTakeApply`, then reopened from storage), a
shared-folder load (`applyStore`), a PMO submittal (`destPkgIn`), a full import (control). (6) `destFold` read directly: a
key of the same list, a name the board holds twice, an older board's map (both entries to U40-C; plus money and save/reopen),
a name a destination took on since, and one name on another list (merged the same way twice, terms combined: control; and
listed with "Full Fund").

Focused harness `harness/c1/focused-u40.mjs` (blob `4087f9c5`), built by `bin/mkfocused-u40.py` (adapted from
`rec/L2/u2impl/mkfocused-u2.py`: several ranges, an end line left out with `!`; otherwise unchanged) VERBATIM from c1's
audit-import: the three v1.86 destination blocks (lines 2640–2845: "the four lists become one", "added once …", "a PMO copy
reads the board list …") and the U40 block, with the suite's imports, failure list, keepBoards, SEEN/chk, the top-level
helpers they use (MINE, V185, asBooted, base, it, v10It, v184Publish, v184Submit, v185It) and the scenario-ran guard. Run by
`runner.mjs` (copied from U10's, unchanged; it asserts the board it boots and prints its blob). `SUITE_CHECKS` records every
check (`out/<label>.checks.jsonl`; `bin/tally.py` counts them).

| run (start ET) | board | v1.86 ×3 (48) | U40 (58) | exit | wall s |
|---|---|---|---|---|---|
| F4-c1 (13:41:02) | c1 r1 `00096819` (first build; superseded) | 48 pass | 58 pass | 0 | 108.5 |
| **F5-c1 (14:08:41)** | **c1 `278bf731` (final)** | **48 pass** | **58 pass** | **0** | **158.0** |
| F4-base (13:42:57) | base `fce8a391` | 48 pass | **43 fail, 15 pass** — every failure a U40 check, every pass a CONTROL (checked by script) | 1 | 102.3 |
| F4-codex (13:44:44) | Codex `2419366b` | 48 pass | 14 fail (13 wording checks; 1 the extra guard), 44 pass | 1 | 129.4 |
| X3-u40-on-x10 (14:53:17, second start) | x10 `c4ae3fc2` (c1 + U10 c2) | 48 pass | 58 pass | 0 | 101.1 |
| X4-u40-on-xc4 (15:16:41, second start) | xc4 `1fe875ac` (c1 + U10 c4, informational) | 48 pass | 58 pass | 0 | 122.4 |

Earlier runs of the harness while the block was being written (superseded, kept): F1-c1 (fixture replaced the list object,
so the next reading folded the seeded list back in; the U40 block ran before the v1.86 range that defines `v186AsV185`),
F2-c1/F2-base (on the base the typing step left no Bravo Yard field and the block threw), F3-base. Each fix is in the block
text, never in an expectation.

## 6. Mutation entries

15 entries, ids `v200-u40-*`, inserted in the `mutate.mjs` TEXT right before "  // v2.00 (R3, Brad 11 Oct): a save that
lands under a locked view says it saved the working plan." with a two-line `// v2.00 (U40): …` comment (text:
`entries-u40.mjs.txt`, written by `bin/entries-u40.py`, which asserts each find matches the c1 board once). Counted as text
only with `rec/bin/mcount.py` (`python3 -I`): base 1,328 entries, 1,328 once; **c1 1,343 entries, 1,343 once, 0 missing, 0
multiple, 0 unparsed**; x10 (c1 + U10 c2) 1,360, 1,360 once; for reference U10 c2 1,345 once and Codex's copy 1,338 once
(`logs/mcount-*.json`). No existing entry needed a change. Each mutant was made with `rec/bin/mkmut.py` (text only; each
`mut/c1/<id>.make.json` records `"matches": 1`) and run through the focused harness (`mutruns.sh`, two lanes).

The 15 mutants were made from c1's mutate TEXT and run through the focused harness by the first builder (`M2-*`, 14:08–14:28
PM ET, two lanes). In this start every mutant was REMADE from the same text with `mkmut.py` (`verify2/mut/`): each matches
once, and each blob equals the board its M2 run booted (section 0). Every mutant: exit 1, 106 checks run, only U40 checks
fail, the block never threw, and the 48 v1.86 checks pass. The failing checks, per mutant (from `out/M2-<id>.checks.jsonl`;
the first three named, `bin/muttab.py M2`; all of them: `python3 -I bin/mutfails.py M2 mut/ids.txt`):

| mutant | start (ET) | exit | wall s | failing checks | which (where — claim) |
|---|---|---|---|---|---|
| `v200-u40-typed-duplicate-kept` | 14:11:19 | 1 | 112.0 | 9 | (1) typed “ALPHA DEPOT” — refused: the destination keeps the name Bravo Yard; (1) typed “ALPHA DEPOT” — nothing else changed: the list, the requirements, the change counts, t; (1) typed “ALPHA DEPOT” — and nothing was written to browser storage; … and 6 more |
| `v200-u40-refusal-field-unmarked` | 14:13:11 | 1 | 109.9 | 1 | (1) the panel field — refused: Bravo Yard kept; the field keeps what was typed, marked inval |
| `v200-u40-refusal-names-itself` | 14:15:01 | 1 | 123.6 | 3 | (1) typed “ALPHA DEPOT” — and the board says so, word for word; (1) typed “  alpha   depot  ” — and the board says so, word for word; (1) the panel field — refused: Bravo Yard kept; the field keeps what was typed, marked inval |
| `v200-u40-incoming-pair-merged` | 14:17:05 | 1 | 138.5 | 7 | (3) opened where a newer list holds Alpha Depot — and it goes on to name the destinations kept apart; (3) opened where a newer list holds Alpha Depot — the funds flow: R1’s $900 on Alpha Depot, R2’s $300 on ALPHA DEPOT, $1; (3) opened where a newer list holds Alpha Depot — the Funds Flow workbook: R1’s $900 and R2’s $300 on two sheets, one ea; … and 4 more |
| `v200-u40-ambiguous-local-first` | 14:19:23 | 1 | 140.8 | 1 | (6) a name the board holds twice — no first one is picked: the incoming destination is kept on its own ke |
| `v200-u40-same-list-key-consumed` | 14:21:44 | 1 | 108.8 | 1 | (6) a key of the same list — a name never claims the destination another entry of the same list IS  |
| `v200-u40-map-collapse-followed` | 14:23:33 | 1 | 114.9 | 3 | (6) an older board’s map — a map that sends both entries of a list to one destination is not foll; (6) an older board’s map — the funds flow: $900 and $300 on two destinations, $1,200 in all; (6) an older board’s map — saved and reopened: R1 on Alpha Depot, R2 on ALPHA DEPOT, two keys |
| `v200-u40-name-into-taken` | 14:25:28 | 1 | 154.9 | 1 | (6) a name a destination took on since — x1 was read into a destination since renamed Bravo Yard; x2 (Bravo Yar |
| `v200-u40-claim-unrecorded` | 14:08:41 | 1 | 160.4 | 4 | (6) an older board’s map — a map that sends both entries of a list to one destination is not foll; (6) an older board’s map — the funds flow: $900 and $300 on two destinations, $1,200 in all; (6) an older board’s map — saved and reopened: R1 on Alpha Depot, R2 on ALPHA DEPOT, two keys; … and 1 more |
| `v200-u40-merge-unlisted` | 14:11:22 | 1 | 118.7 | 1 | (6) one name on another list — and the merge is listed in the destinations panel, with the list it ca |
| `v200-u40-merge-from-slug` | 14:13:20 | 1 | 109.5 | 1 | (6) one name on another list — and the merge is listed in the destinations panel, with the list it ca |
| `v200-u40-apart-unsaid` | 14:15:10 | 1 | 132.4 | 9 | (2) a fresh browser — the opening line is kept, and names the two kept apart; (2) a fresh browser — the destinations panel names the destinations kept apart; (3) opened where a newer list holds Bravo Yard — and it goes on to name the destinations kept apart; … and 6 more |
| `v200-u40-editor-notice-gone` | 14:17:22 | 1 | 132.4 | 6 | (2) a fresh browser — the destinations panel names the destinations kept apart; (3) opened where a newer list holds Bravo Yard — the destinations panel names the destinations kept apart; (3) opened where a newer list holds Bravo Yard, saved there and reopened — the destinations panel names the destinations kept apart; … and 3 more |
| `v200-u40-opening-unsaid` | 14:19:35 | 1 | 138.7 | 4 | (2) a fresh browser — the opening line is kept, and names the two kept apart; (3) opened where a newer list holds Bravo Yard — and it goes on to name the destinations kept apart; (3) opened where a newer list holds Alpha Depot — and it goes on to name the destinations kept apart; … and 1 more |
| `v200-u40-opening-replaces` | 14:21:54 | 1 | 109.2 | 5 | (2) a fresh browser — the opening line is kept, and names the two kept apart; (3) opened where a newer list holds Bravo Yard — CONTROL: the opening line is still the board’s own; (3) opened where a newer list holds Bravo Yard — and it goes on to name the destinations kept apart; … and 2 more |

The superseded first build's runs of the same 15 ids (`M1-*`, against board r1 `00096819`) are kept in `logs/` and
`r1/mutants-M1-r1.txt`; they are not the result.

## 7. U40 beside U10 (the overlap the lead named)

U10's latest copy in its `diffs/` (`rec/L6/u10/c2`, board `cfc9e14f`, audit-recon `2c4c466a`, mutate text `3a408399`) adds `cycBlock`
refusals to `flowSetEnt`, `flowAddEnt`, `flowDelEnt` and `flowResetEnts`. Scratch copy `x10/` = c1 + U10 c2's three diffs
against the base (`rec/L6/u10/diffs/c2-vs-base.*.diff`): all 11 board hunks and the audit-recon hunk apply to c1 with
`patch` (offsets only); U10's one mutate hunk shares the R3 anchor with U40's entries, so its 57 added lines were inserted
before the same anchor, after U40's. Checked: the set of lines x10 changes against c1 equals the set U10 c2 changes against
the base (board and mutate text); x10's audit-recon is byte-identical to U10 c2's. x10 blobs: board `c4ae3fc2`,
audit-recon `2c4c466a`, mutate text `ab6c1814`, audit-import `de59f3ce` (c1's); mcount 1,360 entries, 1,360 once
(1,328 + U40's 15 + U10's 17). The resulting `flowSetEnt` head, U10's refusal first:

```
function flowSetEnt(i, field, v){
  // v2.00 (U10): THE DESTINATION LIST IS EVERY APPROPRIATION'S, ... (U10's three comment lines, unchanged)
  if(cycBlock('Changing a destination')){ render(); return; }
  const L=flowEnts(), e=L[i]; if(!e) return;
  // v2.00 (U40): A NAME ANOTHER DESTINATION HAS IS REFUSED, ...
```

**The conflict found, and removed.** The first build (r1) changed the name field's `onchange` to `…,this.value,this)`
(Codex's way of reaching the field). U10's audit-recon block (the shared lists, `fireDest('name', …)`) finds the field by the
exact text `flowSetEnt(i,"n",this.value)`; on an r1-based composition its "Lockheed Martin renamed RENAMED DEST" door and
its "Depot Z" control would have found no field (read from U10's block, not run against r1). The patch also did not apply (U10's hunk has the old signature as context).
c1 was revised (section 3, item 3) so that the field's text is unchanged; both problems are gone.

**The runs on the composition** (probe `probes/compose.mjs`, blob `92474534` -- its "left the view" expectation was
corrected from `null` to `""` after C1-compose-c1, so both copies were probed again in this start with the same text):

| run | copy | start (ET) | exit | wall s | result |
|---|---|---|---|---|---|
| C2-compose-x10 | x10 = c1 + U10 c2 | 14:53:00 | 0 | 17.7 | **10 of 10 hold** (`TALLY ok=10 differs=0`) |
| C2-compose-c1 | c1 alone (reference: U10 absent) | 14:52:46 | 0 | 13.4 | 3 hold, 7 differ -- exactly U10's own finding, not U40's: in PB27's view U40 still refuses the matching name (the list is unchanged), but a name of its own and "+ add" are kept in the view, so the later lines see "Charlie Yard" and "New destination" |
| X3-u40-on-x10 | x10 | 14:53:17 | 0 | 101.1 | U40's focused harness (blob `4087f9c5`): **106 of 106** (v1.86 ×3 48, U40 58) |
| X2-u10-on-x10 (first builder) | x10 | 14:24:54 | 0 | 186.5 | U10 c2's focused harness (blob `318d7998`): **74 of 74** |

**Order of the refusals and their words.** U10's `cycBlock('Changing a destination')` is the first statement of
`flowSetEnt`; U40's name check comes after it. In a locked cycle's view every change to a destination is refused by U10
first -- the line reads "🔒 Changing a destination is off while PB27 is on screen. …", the list is unchanged, and U40's
line is not said beside it (probe lines 2–6; U10's code then calls `render()`, which puts the stored name back in the
panel -- read, not probed). On the working plan U10 lets the edit through and U40 decides:
a name another destination has is refused with U40's line word for word, the field keeps what was typed (marked), and a
name of its own is stored (probe lines 8–10). `flowAddEnt`, `flowDelEnt` and the reset are U10's alone (U40 does not
touch them). **They compose; they do not conflict.** Each block passes on the composition unchanged.

**U10's newest copy, c4 (informational).** U10's track moved on after its `diffs/` were written: `rec/L6/u10/c4` (board
`f726ecfc`, audit-recon `6d0f396a`, mutate text `8f51d4bb`; in review; its own run F8-u10-on-c4, started 2:31:59 PM ET, exit 0).
Its 20 board hunks against the base were applied to c1 with `patch` (`xc4/`; hunk 11, `flowSetEnt`, with fuzz 2, landing
exactly as on x10: U10's refusal first, then U40's), its audit-recon taken as it is, and its one mutate hunk's 130 added
lines inserted before the R3 anchor after U40's. Of c4's 20 board hunks, the only one inside a function U40 changes is
U10's refusal at the head of `flowSetEnt` (none in `destJoin`, `destFold`, `destNotice`/`flowEntEditor`, the `_destMerges`
line or the opening; checked by hunk position). xc4: board `1fe875ac`, mutate text `ca1e4585`; mcount 1,383 entries, 1,383
once (1,328 + U40's 15 + c4's 40; c4 alone 1,368 once).

| run | copy | start (ET) | exit | wall s | result |
|---|---|---|---|---|---|
| C3-compose-xc4 | xc4 | 15:16:22 | 0 | 18.9 | **10 of 10 hold** |
| X4-u40-on-xc4 | xc4 | 15:16:41 | 0 | 122.4 | U40's focused harness (blob `4087f9c5`): **106 of 106** |
| X5-u10c4-on-xc4 | xc4 | 15:18:43 | 0 | 253.6 | U10 c4's focused harness (blob `03410810`): **111 of 111** (its six scenarios: 11, 27, 9, 27, 9, 28) |

So U40 composes with U10's newest copy exactly as with c2: same order, same words, both blocks pass unchanged. This is
for information only -- c4 is not in U10's `diffs/` yet, and its review is not finished.

**As git would merge it (text only, no commit anywhere).** The L9 dry run (`rec/L9/dryrun/README.md`, conflict C3) stopped
U40 at `flowSetEnt` against U10 -- but it used Codex's applied copy as a stand-in for U40, whose fourth argument changed
the function's first line. c1 keeps that line, so: `git merge-file --diff3 <c1 file> <base file> <U10 file>`
(`verify2/merge3/`) merges the **board with 0 conflicts** for U10 c2 and for U10 c4, and the result is **byte-identical to
x10 / xc4**; the **mutate text has 1 conflict each, add/add at the R3 anchor** (empty base side), and keeping both sides
(U40's entries, then U10's) gives x10's / xc4's mutate text byte for byte (checked by script). audit-import (U40's) and
audit-recon (U10's) are each changed by one track only.

## 8. Every route that renames a destination or reads a list in

| route | where | base | c1 |
|---|---|---|---|
| typing a name (panel field, `flowSetEnt`) | block (1); P2 A | matching name kept | refused, field marked, nothing written |
| opening a saved file, fresh browser | block (2); P2 B0 | kept (control) | kept, and said |
| opening against a newer list (second person) | block (3); P2 B1 | **merged**; R2's $300 to Alpha Depot | kept; said |
| … whose list has its own same-named destination | block (3); P2 B1 | **merged into it**, $1,200 | all three kept, named |
| saving there, reopening elsewhere | block (3); P2 B2 | merge kept | both kept |
| a list saved before v1.86, any browser | block (4); P2 C | **merged** | kept, said |
| import: one appropriation taken (`consTakeApply`) | block (5); P2 D | **merged** (the cycle that came with it then names a key the board lacks) | kept, cycle resolves |
| import: full board (`fullImportText`) | block (5); P2 E | file's list replaces the board's: kept (control) | same |
| import: several boards (`importBoards`) | read | the one on screen through `applyStore`, the rest folded on opening: the same `destFold` | covered by the `applyStore` and opening routes |
| shared folder / wholesale load (`applyStore`) | block (5); P2 G | **merged** | kept |
| PMO submittal (`destPkgIn`) | block (5); P2 F | **merged** | kept |
| locked cycle (CYCDB folded on opening, `destCycStates`) | block (3) `where` | **re-pointed and stored** | unchanged |
| a locked cycle taken from a file (`cycTake`) | read | copied as it is, keys not read through any list (before and after) | unchanged by this commit; noted in "Not covered" |
| both hops (`to`, `end`) | block (2)–(5) | both moved | both kept |
| an older board's map (`DESTDB.lmap`) sending two entries to one key | block (6) | followed | not followed for the second |
| Funds Flow export (detail sheets) | block (2)(3), workbook read back with the board's own `xlsxRead` | one sheet, R1 and R2 | "Alpha Depot" R1 900, "ALPHA DEPOT 2" R2 300 |
| reset to the seeded list (`flowResetEnts`), seeding an empty list | read | seeded names are distinct | unchanged |

## 9. Decision principles

1. *Never lose any copy of anyone's work; when two copies conflict keep both and say.* Both destinations, and the
   requirements and money on each, are kept on every read-in route; where the file's two meet a second person's own
   destination of that name, all three are kept and named.
2. *Refuse or ask rather than guess.* A typed matching name is refused; a name is not trusted to choose between two (in the
   list or on the board), nor to take a destination this reading gave another entry, nor one that is another entry of the
   same list. The board keeps them apart and says so instead of picking.
3. *Money and every export match the computation exactly.* `flowCalc` and `exportFlow` are untouched; the block checks the
   funds flow by key ($900, $300, $1,200 typed) and the exported workbook's sheets read back from its bytes.
4. *Every word stays true, after the operation too.* "Nothing was changed" is checked against a snapshot of the list, the
   requirements, the change counts, the unsaved marks and browser storage; "each keeps its own requirements and money" is
   checked by name, key and dollars; the opening line keeps the board's own line in front (control); a merge names its list
   by the appropriation's name.
5. *The smallest change.* Four functions and one opening statement; one new session variable; no saved field; the existing
   `codeRefusedIn`, `destName`, `appnName` and `esc` are reused.
6. *Every existing check, fixture and expected value preserved.* No existing check, fixture or expectation was edited. The
   three v1.86 destination scenarios pass unchanged (48/48) on base, c1, Codex's board and x10; every existing mutation
   entry still matches once; the other suites compare as in section 10. No existing expectation is known to need a change;
   the one visible difference other suites could meet is extra text after the opening line when a board opens with
   destinations kept apart or merged by name (every `shareStat` read in the suites was looked at: all are regex tests for
   other words, which the appended text leaves true).

## 10. The other suites and `npm run check`, base against c1

From the two scratch clones (`gc-base`: orbit-board `7ee498a`, detached; `gc-c1`: the same with c1's board, audit-import and
mutate text copied over -- `git status` shows exactly those three modified; nothing committed), `BOARD` unset, through
`suites.sh` → `run.sh`, one suite at a time per lane and at most two lanes. `check` is what `npm run check` runs (`node
tools/check.mjs prioritization-board-grid.html`). Not run here: `audit-import.mjs` and `audit-board.mjs` (the lead's
alone). A cell with NO EXIT RECORD is an interrupted run kept as a record (section 0), never a result; each was re-run.

**Every suite gives the same outcome on the base and on c1.** boot-same: every page, source, save and error list identical
either way, on both. audit, audit-ppt, audit-other, audit-hostile, audit-inject and audit-recon: ALL CHECKS PASSED on both.
legacy-fsrc: the same `ok` line on both. `npm run check`: 26 `ok` lines and no FAIL on both; the two outputs differ only in
the board's size lines (31,672 → 31,721 lines; "main script parses" 29,650 → 29,699 lines: the 49 lines the commit adds).
These suites print failures and a final verdict, not per-check counts, so check counts were not compared. Runs that are not
results: `S-audit-c1` (first builder, stopped by the usage limit), `S-audit-hostile-base` and `S-audit-recon-c1b` (their lane
wrapper's cap, section 14), and `S-audit-recon-base2` / `S-audit-recon-c1c` (exit 124: each hit run.sh's 600 s cap while the
two ran side by side under a load average near 40 -- re-run one at a time as `-c1d` and `-base3`, which passed in 536 s and
383 s). The table (`bin/suitetab2.py`), every attempt listed:

| suite | base `fce8a391` (clone `gc-base`) | c1 `278bf731` (clone `gc-c1`) |
|---|---|---|
| boot-same | S-boot-same-base: start 14:54:59, exit 0, 44.5 s; `every page, source, save and error list is identical either way` | S-boot-same-c1: start 14:28:01, exit 0, 98.5 s; `every page, source, save and error list is identical either way`<br>S-boot-same-c1b: start 14:52:47, exit 0, 45.7 s; `every page, source, save and error list is identical either way` |
| audit | S-audit-base: start 14:55:43, exit 0, 48.6 s; `ALL CHECKS PASSED` | S-audit-c1: start 14:29:40, NO EXIT RECORD; last line `(no output)`<br>S-audit-c1b: start 14:53:33, exit 0, 41.8 s; `ALL CHECKS PASSED` |
| audit-ppt | S-audit-ppt-base: start 14:56:32, exit 0, 21.2 s; `ALL CHECKS PASSED` | S-audit-ppt-c1b: start 14:54:15, exit 0, 23.7 s; `ALL CHECKS PASSED` |
| audit-other | S-audit-other-base: start 14:56:53, exit 0, 144.7 s; `ALL CHECKS PASSED` | S-audit-other-c1b: start 14:54:39, exit 0, 142.5 s; `ALL CHECKS PASSED` |
| legacy-fsrc | S-legacy-fsrc-base: start 14:59:18, exit 0, 15.1 s; `ok   legacy fsrc 'ufr' still honoured — all unfunded (d 0 · m 0 · u 60)` | S-legacy-fsrc-c1b: start 14:57:01, exit 0, 15.1 s; `ok   legacy fsrc 'ufr' still honoured — all unfunded (d 0 · m 0 · u 60)` |
| audit-hostile | S-audit-hostile-base: start 14:59:34, NO EXIT RECORD; last line `ALL CHECKS PASSED`<br>S-audit-hostile-base2: start 15:15:49, exit 0, 285.6 s; `ALL CHECKS PASSED` | S-audit-hostile-c1b: start 14:57:17, exit 0, 259.4 s; `ALL CHECKS PASSED` |
| audit-inject | S-audit-inject-base2: start 15:20:34, exit 0, 50.7 s; `ALL CHECKS PASSED` | S-audit-inject-c1b: start 15:01:36, exit 0, 57.2 s; `ALL CHECKS PASSED` |
| audit-recon | S-audit-recon-base2: start 15:21:25, exit 124, 600.8 s; `[exportSrc] 4 sheet(s), 0 breakout row(s) across 0 block(s)`<br>S-audit-recon-base3: start 15:42:23, exit 0, 383.1 s; `ALL CHECKS PASSED` | S-audit-recon-c1b: start 15:02:34, NO EXIT RECORD; last line `[exportSrc] 4 sheet(s), 0 breakout row(s) across 0 block(s)`<br>S-audit-recon-c1c: start 15:22:57, exit 124, 600.6 s; `[exportSrc] 4 sheet(s), 0 breakout row(s) across 0 block(s)`<br>S-audit-recon-c1d: start 15:33:26, exit 0, 536.4 s; `ALL CHECKS PASSED` |
| check | S-check-base2: start 15:31:26, exit 0, 16.0 s; `26 ok lines, 0 FAIL lines` | S-check-c1c: start 15:15:49, exit 0, 32.3 s; `26 ok lines, 0 FAIL lines` |

## 11. Every run, and every PID

Every node run of both starts went through `run.sh` (bounded `setsid -w timeout -k 10 600`, its own process group, the
`AUDIT_IMPORT_RUNNING` lock checked before it starts -- it was never set when checked in this start -- the timeout PID and
its child written to `pids.txt`, the start/exit/wall line to `logs/runs.txt`). The table is `logs/runs.txt` as written
(`bin/tables.py`; times Eastern, 13 Oct). Four runs have a log but no line here, because the shell that would have written
the line was ended first: `C1-compose-x10` and `S-audit-c1` (first builder, stopped by the usage limit at about 2:29 PM ET;
re-run as `C2-compose-x10` and `S-audit-c1b`), and `S-audit-hostile-base` and `S-audit-recon-c1b` (this start: their lane
wrapper hit its own 600 s cap, section 0 and 14; re-run as `S-audit-hostile-base2` and `S-audit-recon-c1c`, which then hit the 600 s cap under load and was run once more as
`S-audit-recon-c1d`). None of the four is counted as a result, nor is either exit-124 run.

| label | start (ET, 13 Oct) | exit | wall s | log |
|---|---|---|---|---|
| P1-repro-base | 13:25:16 | 1 | 17.7 | `logs/P1-repro-base.log` |
| P2-repro-base | 13:25:45 | 0 | 19.5 | `logs/P2-repro-base.log` |
| P3-repro-codex | 13:26:10 | 0 | 18.9 | `logs/P3-repro-codex.log` |
| F1-c1 | 13:35:38 | 1 | 52.2 | `logs/F1-c1.log` |
| F2-c1 | 13:37:18 | 0 | 60.3 | `logs/F2-c1.log` |
| F2-base | 13:38:28 | 1 | 36.2 | `logs/F2-base.log` |
| F3-base | 13:39:21 | 1 | 77.6 | `logs/F3-base.log` |
| F4-c1 | 13:41:02 | 0 | 108.5 | `logs/F4-c1.log` |
| F4-base | 13:42:57 | 1 | 102.3 | `logs/F4-base.log` |
| F4-codex | 13:44:44 | 1 | 129.4 | `logs/F4-codex.log` |
| M1-v200-u40-claim-unrecorded | 13:49:30 | 1 | 151.3 | `logs/M1-v200-u40-claim-unrecorded.log` |
| M1-v200-u40-typed-duplicate-kept | 13:49:30 | 1 | 152.0 | `logs/M1-v200-u40-typed-duplicate-kept.log` |
| M1-v200-u40-merge-unlisted | 13:52:01 | 1 | 167.6 | `logs/M1-v200-u40-merge-unlisted.log` |
| M1-v200-u40-refusal-field-unmarked | 13:52:02 | 1 | 171.5 | `logs/M1-v200-u40-refusal-field-unmarked.log` |
| M1-v200-u40-merge-from-slug | 13:54:49 | 1 | 144.2 | `logs/M1-v200-u40-merge-from-slug.log` |
| M1-v200-u40-refusal-names-itself | 13:54:54 | 1 | 156.6 | `logs/M1-v200-u40-refusal-names-itself.log` |
| M1-v200-u40-apart-unsaid | 13:57:13 | 1 | 144.0 | `logs/M1-v200-u40-apart-unsaid.log` |
| M1-v200-u40-incoming-pair-merged | 13:57:30 | 1 | 144.6 | `logs/M1-v200-u40-incoming-pair-merged.log` |
| M1-v200-u40-editor-notice-gone | 13:59:38 | 1 | 122.3 | `logs/M1-v200-u40-editor-notice-gone.log` |
| M1-v200-u40-ambiguous-local-first | 13:59:55 | 1 | 121.7 | `logs/M1-v200-u40-ambiguous-local-first.log` |
| M1-v200-u40-opening-unsaid | 14:01:40 | 1 | 127.4 | `logs/M1-v200-u40-opening-unsaid.log` |
| M1-v200-u40-same-list-key-consumed | 14:01:57 | 1 | 123.1 | `logs/M1-v200-u40-same-list-key-consumed.log` |
| M1-v200-u40-opening-replaces | 14:03:47 | 1 | 113.0 | `logs/M1-v200-u40-opening-replaces.log` |
| M1-v200-u40-map-collapse-followed | 14:04:00 | 1 | 111.9 | `logs/M1-v200-u40-map-collapse-followed.log` |
| M1-v200-u40-name-into-taken | 14:05:52 | 1 | 126.1 | `logs/M1-v200-u40-name-into-taken.log` |
| F5-c1 | 14:08:41 | 0 | 158.0 | `logs/F5-c1.log` |
| M2-v200-u40-claim-unrecorded | 14:08:41 | 1 | 160.4 | `logs/M2-v200-u40-claim-unrecorded.log` |
| M2-v200-u40-typed-duplicate-kept | 14:11:19 | 1 | 112.0 | `logs/M2-v200-u40-typed-duplicate-kept.log` |
| M2-v200-u40-merge-unlisted | 14:11:22 | 1 | 118.7 | `logs/M2-v200-u40-merge-unlisted.log` |
| M2-v200-u40-refusal-field-unmarked | 14:13:11 | 1 | 109.9 | `logs/M2-v200-u40-refusal-field-unmarked.log` |
| M2-v200-u40-merge-from-slug | 14:13:20 | 1 | 109.5 | `logs/M2-v200-u40-merge-from-slug.log` |
| M2-v200-u40-refusal-names-itself | 14:15:01 | 1 | 123.6 | `logs/M2-v200-u40-refusal-names-itself.log` |
| M2-v200-u40-apart-unsaid | 14:15:10 | 1 | 132.4 | `logs/M2-v200-u40-apart-unsaid.log` |
| M2-v200-u40-incoming-pair-merged | 14:17:05 | 1 | 138.5 | `logs/M2-v200-u40-incoming-pair-merged.log` |
| M2-v200-u40-editor-notice-gone | 14:17:22 | 1 | 132.4 | `logs/M2-v200-u40-editor-notice-gone.log` |
| M2-v200-u40-ambiguous-local-first | 14:19:23 | 1 | 140.8 | `logs/M2-v200-u40-ambiguous-local-first.log` |
| M2-v200-u40-opening-unsaid | 14:19:35 | 1 | 138.7 | `logs/M2-v200-u40-opening-unsaid.log` |
| M2-v200-u40-same-list-key-consumed | 14:21:44 | 1 | 108.8 | `logs/M2-v200-u40-same-list-key-consumed.log` |
| M2-v200-u40-opening-replaces | 14:21:54 | 1 | 109.2 | `logs/M2-v200-u40-opening-replaces.log` |
| P4-repro-base | 14:23:43 | 0 | 54.4 | `logs/P4-repro-base.log` |
| C1-compose-c1 | 14:24:37 | 0 | 17.0 | `logs/C1-compose-c1.log` |
| M2-v200-u40-map-collapse-followed | 14:23:33 | 1 | 114.9 | `logs/M2-v200-u40-map-collapse-followed.log` |
| X2-u10-on-x10 | 14:24:54 | 0 | 186.5 | `logs/X2-u10-on-x10.log` |
| M2-v200-u40-name-into-taken | 14:25:28 | 1 | 154.9 | `logs/M2-v200-u40-name-into-taken.log` |
| S-boot-same-c1 | 14:28:01 | 0 | 98.5 | `logs/S-boot-same-c1.log` |
| P4-repro-c1 | 14:28:03 | 0 | 104.1 | `logs/P4-repro-c1.log` |
| C2-compose-c1 | 14:52:46 | 0 | 13.4 | `logs/C2-compose-c1.log` |
| C2-compose-x10 | 14:53:00 | 0 | 17.7 | `logs/C2-compose-x10.log` |
| S-boot-same-c1b | 14:52:47 | 0 | 45.7 | `logs/S-boot-same-c1b.log` |
| S-audit-c1b | 14:53:33 | 0 | 41.8 | `logs/S-audit-c1b.log` |
| S-audit-ppt-c1b | 14:54:15 | 0 | 23.7 | `logs/S-audit-ppt-c1b.log` |
| X3-u40-on-x10 | 14:53:17 | 0 | 101.1 | `logs/X3-u40-on-x10.log` |
| S-boot-same-base | 14:54:59 | 0 | 44.5 | `logs/S-boot-same-base.log` |
| S-audit-base | 14:55:43 | 0 | 48.6 | `logs/S-audit-base.log` |
| S-audit-ppt-base | 14:56:32 | 0 | 21.2 | `logs/S-audit-ppt-base.log` |
| S-audit-other-c1b | 14:54:39 | 0 | 142.5 | `logs/S-audit-other-c1b.log` |
| S-legacy-fsrc-c1b | 14:57:01 | 0 | 15.1 | `logs/S-legacy-fsrc-c1b.log` |
| S-audit-other-base | 14:56:53 | 0 | 144.7 | `logs/S-audit-other-base.log` |
| S-legacy-fsrc-base | 14:59:18 | 0 | 15.1 | `logs/S-legacy-fsrc-base.log` |
| S-audit-hostile-c1b | 14:57:17 | 0 | 259.4 | `logs/S-audit-hostile-c1b.log` |
| S-audit-inject-c1b | 15:01:36 | 0 | 57.2 | `logs/S-audit-inject-c1b.log` |
| S-check-c1c | 15:15:49 | 0 | 32.3 | `logs/S-check-c1c.log` |
| C3-compose-xc4 | 15:16:22 | 0 | 18.9 | `logs/C3-compose-xc4.log` |
| X4-u40-on-xc4 | 15:16:41 | 0 | 122.4 | `logs/X4-u40-on-xc4.log` |
| S-audit-hostile-base2 | 15:15:49 | 0 | 285.6 | `logs/S-audit-hostile-base2.log` |
| S-audit-inject-base2 | 15:20:34 | 0 | 50.7 | `logs/S-audit-inject-base2.log` |
| X5-u10c4-on-xc4 | 15:18:43 | 0 | 253.6 | `logs/X5-u10c4-on-xc4.log` |
| S-audit-recon-base2 | 15:21:25 | 124 | 600.8 | `logs/S-audit-recon-base2.log` | TIMED OUT = incomplete
| S-check-base2 | 15:31:26 | 0 | 16.0 | `logs/S-check-base2.log` |
| S-audit-recon-c1c | 15:22:57 | 124 | 600.6 | `logs/S-audit-recon-c1c.log` | TIMED OUT = incomplete
| S-audit-recon-c1d | 15:33:26 | 0 | 536.4 | `logs/S-audit-recon-c1d.log` |
| S-audit-recon-base3 | 15:42:23 | 0 | 383.1 | `logs/S-audit-recon-base3.log` |

### PIDs

`pids.txt` lists every PID this track recorded, with the time, the process and the label (the command itself is in the
file after ` :: `). Lines up to `C1-compose-x10` (2:29 PM ET) are the first builder's; lines from 2:51 PM ET are this
start's. Lines beginning `#` are notes. This start's lane shells: `bx:post3-lane1`/`bx:post3-lane2` (timeout 14069 / 14115,
lane 14070 / 14119; ended by their own cap at about 3:02:46 PM ET), `post5.sh A`/`B` (tool shells 9243 / 9251, lane
scripts 9245 / 9257, printed in `logs/post5-lane*.txt`), and `post6.sh` (tool shell 27803, script 27805, `logs/post6.txt`). No process was ever killed by this builder, by PID or otherwise;
at 3:49 PM ET none of this start's 108 recorded PIDs was running (checked by PID with `ps`; a PID found alive with
another command would have belonged to another agent after PID reuse, and none was).

| pid | recorded (ET) | process | label |
|---|---|---|---|
| 3352 | 13:25:16 | timeout | P1-repro-base |
| 3354 | 13:25:16 | node | P1-repro-base |
| 3646 | 13:25:45 | timeout | P2-repro-base |
| 3649 | 13:25:45 | node | P2-repro-base |
| 3869 | 13:26:10 | timeout | P3-repro-codex |
| 3872 | 13:26:10 | node | P3-repro-codex |
| 18265 | 13:35:13 | timeout | bx:mkfocused-c1 |
| 18267 | 13:35:13 | python3 | bx:mkfocused-c1 |
| 18891 | 13:35:31 | timeout | bx:mkfocused-c1 |
| 18907 | 13:35:31 | python3 | bx:mkfocused-c1 |
| 19122 | 13:35:38 | timeout | F1-c1 |
| 19124 | 13:35:38 | node | F1-c1 |
| 20610 | 13:37:17 | timeout | bx:rebuild-c1 |
| 20612 | 13:37:17 | rebuild-c1.sh | bx:rebuild-c1 |
| 20661 | 13:37:18 | timeout | F2-c1 |
| 20664 | 13:37:18 | node | F2-c1 |
| 22463 | 13:38:29 | timeout | F2-base |
| 22466 | 13:38:29 | node | F2-base |
| 24051 | 13:39:20 | timeout | bx:rebuild-c1 |
| 24053 | 13:39:20 | rebuild-c1.sh | bx:rebuild-c1 |
| 24075 | 13:39:21 | timeout | F3-base |
| 24077 | 13:39:21 | node | F3-base |
| 28626 | 13:41:00 | timeout | bx:rebuild-c1 |
| 28629 | 13:41:00 | rebuild-c1.sh | bx:rebuild-c1 |
| 28939 | 13:41:02 | timeout | F4-c1 |
| 28941 | 13:41:02 | node | F4-c1 |
| 1023 | 13:42:57 | timeout | F4-base |
| 1025 | 13:42:57 | node | F4-base |
| 3637 | 13:44:44 | timeout | F4-codex |
| 3639 | 13:44:45 | node | F4-codex |
| 7775 | 13:47:45 | timeout | bx:entries |
| 7777 | 13:47:45 | python3 | bx:entries |
| 8009 | 13:47:58 | timeout | bx:mcount-base |
| 8014 | 13:47:58 | python3 | bx:mcount-base |
| 8815 | 13:48:20 | timeout | bx:mcount-c1 |
| 8817 | 13:48:20 | python3 | bx:mcount-c1 |
| 9804 | 13:48:57 | timeout | bx:mkmut-v200-u40-typed-duplicate-kept |
| 9807 | 13:48:57 | python3 | bx:mkmut-v200-u40-typed-duplicate-kept |
| 9879 | 13:48:58 | timeout | bx:mkmut-v200-u40-refusal-field-unmarked |
| 9882 | 13:48:58 | python3 | bx:mkmut-v200-u40-refusal-field-unmarked |
| 9916 | 13:48:58 | timeout | bx:mkmut-v200-u40-refusal-names-itself |
| 9935 | 13:48:58 | python3 | bx:mkmut-v200-u40-refusal-names-itself |
| 9992 | 13:48:59 | timeout | bx:mkmut-v200-u40-incoming-pair-merged |
| 9994 | 13:49:00 | python3 | bx:mkmut-v200-u40-incoming-pair-merged |
| 10030 | 13:49:00 | timeout | bx:mkmut-v200-u40-ambiguous-local-first |
| 10032 | 13:49:01 | python3 | bx:mkmut-v200-u40-ambiguous-local-first |
| 10054 | 13:49:02 | timeout | bx:mkmut-v200-u40-same-list-key-consumed |
| 10056 | 13:49:02 | python3 | bx:mkmut-v200-u40-same-list-key-consumed |
| 10107 | 13:49:03 | timeout | bx:mkmut-v200-u40-map-collapse-followed |
| 10113 | 13:49:03 | python3 | bx:mkmut-v200-u40-map-collapse-followed |
| 10160 | 13:49:04 | timeout | bx:mkmut-v200-u40-name-into-taken |
| 10162 | 13:49:04 | python3 | bx:mkmut-v200-u40-name-into-taken |
| 10228 | 13:49:05 | timeout | bx:mkmut-v200-u40-claim-unrecorded |
| 10240 | 13:49:05 | python3 | bx:mkmut-v200-u40-claim-unrecorded |
| 10327 | 13:49:07 | timeout | bx:mkmut-v200-u40-merge-unlisted |
| 10332 | 13:49:07 | gone | bx:mkmut-v200-u40-merge-unlisted |
| 10359 | 13:49:07 | timeout | bx:mkmut-v200-u40-merge-from-slug |
| 10361 | 13:49:07 | python3 | bx:mkmut-v200-u40-merge-from-slug |
| 10409 | 13:49:08 | timeout | bx:mkmut-v200-u40-apart-unsaid |
| 10411 | 13:49:08 | python3 | bx:mkmut-v200-u40-apart-unsaid |
| 10451 | 13:49:10 | timeout | bx:mkmut-v200-u40-editor-notice-gone |
| 10453 | 13:49:10 | python3 | bx:mkmut-v200-u40-editor-notice-gone |
| 10508 | 13:49:11 | timeout | bx:mkmut-v200-u40-opening-unsaid |
| 10511 | 13:49:11 | python3 | bx:mkmut-v200-u40-opening-unsaid |
| 10585 | 13:49:12 | timeout | bx:mkmut-v200-u40-opening-replaces |
| 10588 | 13:49:12 | python3 | bx:mkmut-v200-u40-opening-replaces |
| 11138 | 13:49:30 | timeout | M1-v200-u40-typed-duplicate-kept |
| 11139 | 13:49:30 | node | M1-v200-u40-typed-duplicate-kept |
| 11175 | 13:49:30 | timeout | M1-v200-u40-claim-unrecorded |
| 11177 | 13:49:30 | node | M1-v200-u40-claim-unrecorded |
| 13189 | 13:50:37 | timeout | bx:mkfocused-x10 |
| 13191 | 13:50:37 | python3 | bx:mkfocused-x10 |
| 15155 | 13:52:02 | timeout | M1-v200-u40-refusal-field-unmarked |
| 15123 | 13:52:02 | timeout | M1-v200-u40-merge-unlisted |
| 15131 | 13:52:02 | node | M1-v200-u40-merge-unlisted |
| 15158 | 13:52:02 | node | M1-v200-u40-refusal-field-unmarked |
| 17543 | 13:54:25 | timeout | bx:clone-gc-base |
| 17545 | 13:54:25 | git | bx:clone-gc-base |
| 17828 | 13:54:43 | timeout | bx:clone-gc-c1 |
| 17830 | 13:54:43 | git | bx:clone-gc-c1 |
| 17976 | 13:54:49 | timeout | M1-v200-u40-merge-from-slug |
| 17978 | 13:54:49 | node | M1-v200-u40-merge-from-slug |
| 18147 | 13:54:54 | timeout | M1-v200-u40-refusal-names-itself |
| 18149 | 13:54:54 | node | M1-v200-u40-refusal-names-itself |
| 21944 | 13:57:14 | timeout | M1-v200-u40-apart-unsaid |
| 21947 | 13:57:14 | node | M1-v200-u40-apart-unsaid |
| 22351 | 13:57:30 | timeout | M1-v200-u40-incoming-pair-merged |
| 22356 | 13:57:30 | node | M1-v200-u40-incoming-pair-merged |
| 23764 | 13:58:42 | timeout | bx:mcount-x10 |
| 23767 | 13:58:42 | python3 | bx:mcount-x10 |
| 24255 | 13:59:09 | timeout | bx:mcount-u10c2 |
| 24257 | 13:59:09 | python3 | bx:mcount-u10c2 |
| 24803 | 13:59:34 | timeout | bx:mcount-codex |
| 24805 | 13:59:34 | python3 | bx:mcount-codex |
| 24877 | 13:59:38 | timeout | M1-v200-u40-editor-notice-gone |
| 24880 | 13:59:38 | node | M1-v200-u40-editor-notice-gone |
| 25198 | 13:59:55 | timeout | M1-v200-u40-ambiguous-local-first |
| 25201 | 13:59:55 | node | M1-v200-u40-ambiguous-local-first |
| 26870 | 14:01:40 | timeout | M1-v200-u40-opening-unsaid |
| 26872 | 14:01:40 | node | M1-v200-u40-opening-unsaid |
| 27355 | 14:01:57 | timeout | M1-v200-u40-same-list-key-consumed |
| 27357 | 14:01:57 | node | M1-v200-u40-same-list-key-consumed |
| 29382 | 14:03:48 | timeout | M1-v200-u40-opening-replaces |
| 29385 | 14:03:48 | node | M1-v200-u40-opening-replaces |
| 29544 | 14:04:00 | timeout | M1-v200-u40-map-collapse-followed |
| 29547 | 14:04:00 | node | M1-v200-u40-map-collapse-followed |
| 32179 | 14:05:52 | timeout | M1-v200-u40-name-into-taken |
| 32181 | 14:05:53 | node | M1-v200-u40-name-into-taken |
| 26262 | 14:06:01 | bash | post-lane (recorded on stopping: superseded before any run started) |
| 26263 | 14:06:01 | bash | post-lane (recorded on stopping: superseded before any run started) |
| 26271 | 14:06:01 | bash | post-lane (recorded on stopping: superseded before any run started) |
| 26272 | 14:06:01 | bash | post-lane (recorded on stopping: superseded before any run started) |
| 798 | 14:06:56 | timeout | bx:entries2 |
| 801 | 14:06:57 | python3 | bx:entries2 |
| 849 | 14:06:58 | timeout | bx:mcount-c1b |
| 851 | 14:06:58 | python3 | bx:mcount-c1b |
| 1400 | 14:07:36 | timeout | bx:mcount-x10b |
| 1402 | 14:07:36 | python3 | bx:mcount-x10b |
| 1997 | 14:08:08 | timeout | bx:mkmut2-v200-u40-typed-duplicate-kept |
| 1999 | 14:08:08 | python3 | bx:mkmut2-v200-u40-typed-duplicate-kept |
| 2012 | 14:08:08 | timeout | bx:mkmut2-v200-u40-refusal-field-unmarked |
| 2014 | 14:08:09 | python3 | bx:mkmut2-v200-u40-refusal-field-unmarked |
| 2029 | 14:08:09 | timeout | bx:mkmut2-v200-u40-refusal-names-itself |
| 2031 | 14:08:09 | python3 | bx:mkmut2-v200-u40-refusal-names-itself |
| 2040 | 14:08:10 | timeout | bx:mkmut2-v200-u40-incoming-pair-merged |
| 2043 | 14:08:10 | python3 | bx:mkmut2-v200-u40-incoming-pair-merged |
| 2056 | 14:08:11 | timeout | bx:mkmut2-v200-u40-ambiguous-local-first |
| 2058 | 14:08:11 | python3 | bx:mkmut2-v200-u40-ambiguous-local-first |
| 2073 | 14:08:11 | timeout | bx:mkmut2-v200-u40-same-list-key-consumed |
| 2081 | 14:08:12 | python3 | bx:mkmut2-v200-u40-same-list-key-consumed |
| 2102 | 14:08:13 | timeout | bx:mkmut2-v200-u40-map-collapse-followed |
| 2104 | 14:08:13 | python3 | bx:mkmut2-v200-u40-map-collapse-followed |
| 2118 | 14:08:13 | timeout | bx:mkmut2-v200-u40-name-into-taken |
| 2120 | 14:08:14 | python3 | bx:mkmut2-v200-u40-name-into-taken |
| 2144 | 14:08:15 | timeout | bx:mkmut2-v200-u40-claim-unrecorded |
| 2146 | 14:08:15 | python3 | bx:mkmut2-v200-u40-claim-unrecorded |
| 2155 | 14:08:16 | timeout | bx:mkmut2-v200-u40-merge-unlisted |
| 2157 | 14:08:16 | python3 | bx:mkmut2-v200-u40-merge-unlisted |
| 2177 | 14:08:17 | timeout | bx:mkmut2-v200-u40-merge-from-slug |
| 2180 | 14:08:17 | python3 | bx:mkmut2-v200-u40-merge-from-slug |
| 2212 | 14:08:18 | timeout | bx:mkmut2-v200-u40-apart-unsaid |
| 2214 | 14:08:18 | python3 | bx:mkmut2-v200-u40-apart-unsaid |
| 2226 | 14:08:19 | timeout | bx:mkmut2-v200-u40-editor-notice-gone |
| 2228 | 14:08:19 | python3 | bx:mkmut2-v200-u40-editor-notice-gone |
| 2242 | 14:08:20 | timeout | bx:mkmut2-v200-u40-opening-unsaid |
| 2244 | 14:08:20 | python3 | bx:mkmut2-v200-u40-opening-unsaid |
| 2260 | 14:08:21 | timeout | bx:mkmut2-v200-u40-opening-replaces |
| 2263 | 14:08:21 | python3 | bx:mkmut2-v200-u40-opening-replaces |
| 2423 | 14:08:41 | timeout | F5-c1 |
| 2425 | 14:08:41 | node | F5-c1 |
| 2452 | 14:08:41 | timeout | M2-v200-u40-claim-unrecorded |
| 2455 | 14:08:41 | node | M2-v200-u40-claim-unrecorded |
| 4522 | 14:11:19 | timeout | M2-v200-u40-typed-duplicate-kept |
| 4529 | 14:11:19 | node | M2-v200-u40-typed-duplicate-kept |
| 4554 | 14:11:22 | timeout | M2-v200-u40-merge-unlisted |
| 4556 | 14:11:22 | node | M2-v200-u40-merge-unlisted |
| 6501 | 14:13:11 | timeout | M2-v200-u40-refusal-field-unmarked |
| 6503 | 14:13:11 | node | M2-v200-u40-refusal-field-unmarked |
| 6738 | 14:13:21 | timeout | M2-v200-u40-merge-from-slug |
| 6740 | 14:13:21 | node | M2-v200-u40-merge-from-slug |
| 8357 | 14:15:01 | timeout | M2-v200-u40-refusal-names-itself |
| 8359 | 14:15:01 | node | M2-v200-u40-refusal-names-itself |
| 8440 | 14:15:10 | timeout | M2-v200-u40-apart-unsaid |
| 8443 | 14:15:10 | node | M2-v200-u40-apart-unsaid |
| 9761 | 14:17:05 | timeout | M2-v200-u40-incoming-pair-merged |
| 9763 | 14:17:05 | node | M2-v200-u40-incoming-pair-merged |
| 10067 | 14:17:23 | timeout | M2-v200-u40-editor-notice-gone |
| 10069 | 14:17:23 | node | M2-v200-u40-editor-notice-gone |
| 11571 | 14:19:23 | timeout | M2-v200-u40-ambiguous-local-first |
| 11573 | 14:19:24 | node | M2-v200-u40-ambiguous-local-first |
| 11711 | 14:19:35 | timeout | M2-v200-u40-opening-unsaid |
| 11713 | 14:19:35 | node | M2-v200-u40-opening-unsaid |
| 13278 | 14:21:44 | timeout | M2-v200-u40-same-list-key-consumed |
| 13280 | 14:21:44 | node | M2-v200-u40-same-list-key-consumed |
| 13386 | 14:21:54 | timeout | M2-v200-u40-opening-replaces |
| 13388 | 14:21:54 | node | M2-v200-u40-opening-replaces |
| 14453 | 14:23:33 | timeout | M2-v200-u40-map-collapse-followed |
| 14455 | 14:23:33 | node | M2-v200-u40-map-collapse-followed |
| 14631 | 14:23:43 | timeout | P4-repro-base |
| 14634 | 14:23:43 | node | P4-repro-base |
| 15335 | 14:24:38 | timeout | C1-compose-c1 |
| 15338 | 14:24:38 | node | C1-compose-c1 |
| 15760 | 14:24:54 | timeout | X2-u10-on-x10 |
| 15762 | 14:24:55 | node | X2-u10-on-x10 |
| 16093 | 14:25:28 | timeout | M2-v200-u40-name-into-taken |
| 16095 | 14:25:28 | node | M2-v200-u40-name-into-taken |
| 17956 | 14:28:01 | timeout | S-boot-same-c1 |
| 17959 | 14:28:01 | node | S-boot-same-c1 |
| 18038 | 14:28:03 | timeout | P4-repro-c1 |
| 18041 | 14:28:03 | node | P4-repro-c1 |
| 18843 | 14:29:40 | timeout | S-audit-c1 |
| 18845 | 14:29:40 | node | S-audit-c1 |
| 18889 | 14:29:47 | timeout | C1-compose-x10 |
| 18891 | 14:29:47 | node | C1-compose-x10 |
| 12022 | 14:51:13 | timeout | bx:mkmut2-v200-u40-typed-duplicate-kept |
| 12024 | 14:51:13 | python3 | bx:mkmut2-v200-u40-typed-duplicate-kept |
| 12051 | 14:51:14 | timeout | bx:mkmut2-v200-u40-refusal-field-unmarked |
| 12053 | 14:51:14 | python3 | bx:mkmut2-v200-u40-refusal-field-unmarked |
| 12072 | 14:51:15 | timeout | bx:mkmut2-v200-u40-refusal-names-itself |
| 12075 | 14:51:16 | python3 | bx:mkmut2-v200-u40-refusal-names-itself |
| 12114 | 14:51:16 | timeout | bx:mkmut2-v200-u40-incoming-pair-merged |
| 12115 | 14:51:17 | python3 | bx:mkmut2-v200-u40-incoming-pair-merged |
| 12147 | 14:51:18 | timeout | bx:mkmut2-v200-u40-ambiguous-local-first |
| 12150 | 14:51:18 | python3 | bx:mkmut2-v200-u40-ambiguous-local-first |
| 12200 | 14:51:19 | timeout | bx:mkmut2-v200-u40-same-list-key-consumed |
| 12204 | 14:51:19 | python3 | bx:mkmut2-v200-u40-same-list-key-consumed |
| 12241 | 14:51:21 | timeout | bx:mkmut2-v200-u40-map-collapse-followed |
| 12243 | 14:51:21 | python3 | bx:mkmut2-v200-u40-map-collapse-followed |
| 12269 | 14:51:22 | timeout | bx:mkmut2-v200-u40-name-into-taken |
| 12271 | 14:51:22 | python3 | bx:mkmut2-v200-u40-name-into-taken |
| 12311 | 14:51:23 | timeout | bx:mkmut2-v200-u40-claim-unrecorded |
| 12314 | 14:51:23 | python3 | bx:mkmut2-v200-u40-claim-unrecorded |
| 12396 | 14:51:24 | timeout | bx:mkmut2-v200-u40-merge-unlisted |
| 12398 | 14:51:24 | python3 | bx:mkmut2-v200-u40-merge-unlisted |
| 12423 | 14:51:25 | timeout | bx:mkmut2-v200-u40-merge-from-slug |
| 12425 | 14:51:25 | python3 | bx:mkmut2-v200-u40-merge-from-slug |
| 12459 | 14:51:26 | timeout | bx:mkmut2-v200-u40-apart-unsaid |
| 12462 | 14:51:26 | python3 | bx:mkmut2-v200-u40-apart-unsaid |
| 12505 | 14:51:27 | timeout | bx:mkmut2-v200-u40-editor-notice-gone |
| 12507 | 14:51:27 | python3 | bx:mkmut2-v200-u40-editor-notice-gone |
| 12545 | 14:51:28 | timeout | bx:mkmut2-v200-u40-opening-unsaid |
| 12548 | 14:51:28 | python3 | bx:mkmut2-v200-u40-opening-unsaid |
| 12573 | 14:51:29 | timeout | bx:mkmut2-v200-u40-opening-replaces |
| 12576 | 14:51:30 | python3 | bx:mkmut2-v200-u40-opening-replaces |
| 12717 | 14:51:36 | timeout | bx:mcount2-base |
| 12719 | 14:51:36 | python3 | bx:mcount2-base |
| 12975 | 14:51:50 | timeout | bx:mcount2-c1 |
| 12977 | 14:51:50 | python3 | bx:mcount2-c1 |
| 13146 | 14:52:04 | timeout | bx:mcount2-x10 |
| 13149 | 14:52:05 | python3 | bx:mcount2-x10 |
| 14076 | 14:52:46 | timeout | C2-compose-c1 |
| 14069 | 14:52:46 | timeout | bx:post3-lane1 |
| 14070 | 14:52:46 | post3.sh | bx:post3-lane1 |
| 14078 | 14:52:46 | node | C2-compose-c1 |
| 14115 | 14:52:47 | timeout | bx:post3-lane2 |
| 14119 | 14:52:47 | post3.sh | bx:post3-lane2 |
| 14136 | 14:52:47 | timeout | S-boot-same-c1b |
| 14141 | 14:52:47 | node | S-boot-same-c1b |
| 14492 | 14:53:00 | timeout | C2-compose-x10 |
| 14495 | 14:53:00 | node | C2-compose-x10 |
| 15057 | 14:53:18 | timeout | X3-u40-on-x10 |
| 15059 | 14:53:18 | node | X3-u40-on-x10 |
| 15517 | 14:53:33 | timeout | S-audit-c1b |
| 15520 | 14:53:33 | node | S-audit-c1b |
| 16381 | 14:54:06 | timeout | bx:mcount-xc4 |
| 16383 | 14:54:06 | python3 | bx:mcount-xc4 |
| 16491 | 14:54:15 | timeout | S-audit-ppt-c1b |
| 16493 | 14:54:15 | node | S-audit-ppt-c1b |
| 16658 | 14:54:18 | timeout | bx:mcount-u10c4 |
| 16659 | 14:54:18 | python3 | bx:mcount-u10c4 |
| 17177 | 14:54:39 | timeout | S-audit-other-c1b |
| 17179 | 14:54:39 | node | S-audit-other-c1b |
| 17486 | 14:54:59 | timeout | S-boot-same-base |
| 17490 | 14:54:59 | node | S-boot-same-base |
| 18460 | 14:55:43 | timeout | S-audit-base |
| 18462 | 14:55:43 | node | S-audit-base |
| 19501 | 14:56:32 | timeout | S-audit-ppt-base |
| 19503 | 14:56:32 | node | S-audit-ppt-base |
| 19978 | 14:56:53 | timeout | S-audit-other-base |
| 19980 | 14:56:53 | node | S-audit-other-base |
| 20176 | 14:57:02 | timeout | S-legacy-fsrc-c1b |
| 20178 | 14:57:02 | node | S-legacy-fsrc-c1b |
| 20600 | 14:57:17 | timeout | S-audit-hostile-c1b |
| 20603 | 14:57:17 | node | S-audit-hostile-c1b |
| 23848 | 14:59:18 | timeout | S-legacy-fsrc-base |
| 23851 | 14:59:18 | node | S-legacy-fsrc-base |
| 24164 | 14:59:34 | timeout | S-audit-hostile-base |
| 24166 | 14:59:34 | node | S-audit-hostile-base |
| 26475 | 15:01:36 | timeout | S-audit-inject-c1b |
| 26478 | 15:01:36 | node | S-audit-inject-c1b |
| 27857 | 15:02:34 | timeout | S-audit-recon-c1b |
| 27860 | 15:02:34 | node | S-audit-recon-c1b |
| 9243 | 15:15:49 | bash | lane-A-shell |
| 9251 | 15:15:49 | bash | lane-B-shell |
| 9253 | 15:15:49 | timeout | S-audit-hostile-base2 |
| 9256 | 15:15:49 | node | S-audit-hostile-base2 |
| 9280 | 15:15:49 | timeout | S-check-c1c |
| 9282 | 15:15:49 | node | S-check-c1c |
| 9741 | 15:16:22 | timeout | C3-compose-xc4 |
| 9743 | 15:16:22 | node | C3-compose-xc4 |
| 9593 | 15:16:32 | gone | bx:suitetab2 |
| 10202 | 15:16:41 | timeout | X4-u40-on-xc4 |
| 10204 | 15:16:41 | node | X4-u40-on-xc4 |
| 10325 | 15:17:04 | gone | bx:suitetab2 |
| 11071 | 15:17:24 | gone | bx:suitetab2 |
| 13260 | 15:18:43 | timeout | X5-u10c4-on-xc4 |
| 13262 | 15:18:43 | node | X5-u10c4-on-xc4 |
| 15675 | 15:20:35 | timeout | S-audit-inject-base2 |
| 15678 | 15:20:35 | node | S-audit-inject-base2 |
| 16518 | 15:21:25 | timeout | S-audit-recon-base2 |
| 16521 | 15:21:25 | node | S-audit-recon-base2 |
| 17838 | 15:22:57 | timeout | S-audit-recon-c1c |
| 17840 | 15:22:57 | node | S-audit-recon-c1c |
| 25352 | 15:31:26 | timeout | S-check-base2 |
| 25354 | 15:31:26 | node | S-check-base2 |
| 27803 | 15:33:26 | bash | post6-shell |
| 27813 | 15:33:26 | timeout | S-audit-recon-c1d |
| 27818 | 15:33:26 | node | S-audit-recon-c1d |
| 27923 | 15:33:32 | timeout | bx:suitetab2 |
| 27925 | 15:33:32 | gone | bx:suitetab2 |
| 4051 | 15:42:23 | timeout | S-audit-recon-base3 |
| 4053 | 15:42:23 | node | S-audit-recon-base3 |
| 11750 | 15:49:48 | timeout | bx:readme2 |
| 11753 | 15:49:48 | python3 | bx:readme2 |
| 12377 | 15:50:20 | timeout | bx:readme2 |
| 12386 | 15:50:20 | python3 | bx:readme2 |
| 12567 | 15:50:31 | timeout | bx:readme2 |
| 12569 | 15:50:32 | python3 | bx:readme2 |
| 12746 | 15:50:47 | timeout | bx:readme2 |
| 12748 | 15:50:47 | python3 | bx:readme2 |
| 12821 | 15:50:52 | timeout | bx:readme2 |
| 12823 | 15:50:53 | python3 | bx:readme2 |
| 12979 | 15:51:03 | timeout | bx:readme2 |
| 12981 | 15:51:03 | python3 | bx:readme2 |
| 13503 | 15:51:27 | timeout | bx:readme2 |

## 12. What is in this directory, with blobs (`git hash-object`)

| path | blob | what |
|---|---|---|
| `c1/` | board `278bf731`, audit-import `de59f3ce`, mutate text `c117c384` | **the cumulative copy (base + the commit)**; `node_modules` symlink kept |
| `r1/` | board `00096819`, its 15 mutants (`mut-c1-r1/`), their results (`mutants-M1-r1.txt`), the r1 composition copy (`x10-r1/`) | the first build, superseded (section 3, item 3) |
| `x10/` | board `c4ae3fc2`, audit-import `de59f3ce`, audit-recon `2c4c466a`, mutate text `ab6c1814` | c1 + U10 c2, for the overlap only (not a proposed commit) |
| `x10check/` | board and audit-recon only | x10 rebuilt in this start from c1 + U10 c2's diffs: byte-identical to x10's |
| `xc4/` | board `1fe875ac`, audit-recon `6d0f396a` (U10 c4's), mutate text `ca1e4585`, audit-import `de59f3ce` | c1 + U10's newest copy c4, informational (section 7) |
| `block-u40.mjs.txt` | `dafca280` | the audit-import block as inserted |
| `entries-u40.mjs.txt` | `7788cd56` | the 15 mutation entries as inserted |
| `probes/repro.mjs` | `2413f6b5` | the reproduction probe (P2/P3 ran its first text; the one later change is the route-specific W2/S2 expectation, section 2; P4 ran this text) |
| `probes/compose.mjs` | `92474534` | U40 beside U10: which refusal speaks in a locked view (C1-compose-c1 ran an earlier text whose "left the view" line expected `null`; C2/C3 ran this one) |
| `harness/c1/focused-u40.mjs` = `harness/x10/focused-u40.mjs` = `harness/xc4/focused-u40.mjs` | `4087f9c5` | focused harness (v1.86 ×3 + U40), verbatim from c1's audit-import; rebuilt in this start byte for byte |
| `harness/x10/focused-u10.mjs` | `318d7998` | U10 c2's focused harness (copied from `rec/L6/u10/harness/c2/`, built from audit-recon `2c4c466a`, which x10 has byte for byte) |
| `harness/xc4/focused-u10.mjs` | `03410810` | U10 c4's focused harness (copied from `rec/L6/u10/harness/c4/`; the blob U10's own F8-u10-on-c4 ran), beside a `boot.mjs` link to xc4's |
| `run.sh` / `bx.sh` | `5f67fba1` / `83bca5d5` | U10's wrappers with the directory changed: bounded `setsid -w timeout -k 10 600`, own process group, the lock rule, PIDs to `pids.txt`, every run to `logs/runs.txt` (unchanged in this start) |
| `runner.mjs` | `f851f139` | from `rec/L2/u2impl`, unchanged: asserts and prints the board's blob |
| `mutruns.sh`, `post2.sh`, `suites.sh` | `e3597694`, `29c0122b`, `426d500a` | the first builder's mutant lanes, final-run lanes and suite runner (`post.sh`, its first form, was stopped before it ran anything, when r1 was superseded; removed) |
| `post3.sh`, `post4.sh`, `post5.sh`, `post6.sh` | `e1a5a501`, `ca99ad69`, `64a48f24`, `8aca852d` | this start's lanes: the unfinished and never-started runs; the c4 composition; the runs post3's lanes lost; audit-recon again, one at a time |
| `bin/mkfocused-u40.py` | `6019a8b1` | adapted from `rec/L2/u2impl/mkfocused-u2.py` (several ranges; `!` end) |
| `bin/insert-block.py`, `bin/insert-before.py`, `bin/entries-u40.py`, `bin/rebuild-c1.sh` | `9f64de7d`, `09a5b5be`, `ff3f29e2`, `52e39574` | text insertion; entries as text (each find asserted once on c1) |
| `bin/tally.py`, `bin/mutfails.py`, `bin/muttab.py`, `bin/tables.py`, `bin/suitetab.py`, `bin/suitetab2.py` | `e0b04411`, `6f6098ea`, `4d494ca8`, `107b21e4`, `3ff73c9c`, `a55ed326` | read-only summaries of `out/*.checks.jsonl`, logs, `runs.txt`, `pids.txt` (`tables.py` now skips `#` note lines; `suitetab2.py` reads both starts' suite logs) |
| `bin/readme2.py` | `ac83786a` | builds this README from the first builder's (`verify2/README.first-builder.md`, blob `65beef25`) and this start's parts in `verify2/` |
| `drafts/NEXT-VERSION-U40.md`, `drafts/unresolved-and-ledger-U40.md` | `2bb57f7d`, `b351b54b` | the drafts (section 13); the first builder's texts are kept as `verify2/*.first-builder.md` (`1545b507`, `ab56ea5c`) |
| `verify2/` | | the three-way merges with U10 (`merge3/`, `git merge-file`, section 7); this start's rebuilds (`audit-import.mjs`, `focused-u40.mjs`, `mut/` with 15 remade mutants and their `.make.json`), the re-derived diffs, U10 c4's diffs against the base, the README parts |
| `diffs/` | | c1 against the base, per file and together (re-derived in this start: byte-identical); c1 against r1; x10 against c1 |
| `mut/c1/` | | the 15 mutant boards and their `.make.json` (each `"matches": 1`) |
| `out/` | | every check of every focused run (`SUITE_CHECKS`) and the suite summary |
| `logs/` | | every run's log (`# start`, `# end`, exit, wall), `runs.txt`, mcount JSON (`mcount-*` first builder, `mcount2-*` this start), lane outputs |
| `gc-base/`, `gc-c1/` | | scratch clones of orbit-board at `7ee498a` (detached); `gc-c1` has c1's board, audit-import and mutate text (as `mutate.mjs`, never run) copied in; nothing committed |
| `codex/` | | Codex's A3 material as handed over; not modified, and none of its scripts run |
| `focused/` | | empty (made by the first builder, never used) |

## 13. Drafts for the lead

`drafts/NEXT-VERSION-U40.md` (the entry under v2.00, after U14: what was wrong, what changes, What users may see, Test,
Mutations, Not covered) and `drafts/unresolved-and-ledger-U40.md` (a NEW line for "Unresolved after R1–R5": there is no U40
line at 7ee498a or at orbit-board HEAD `379a9f7`, read after 2:52 PM ET; and the text to append to the U40 row of
`UNRESOLVED-LEDGER.md`, with `<sha>`/`<time>` placeholders). Changed in this start: "Not covered" names the readers that
follow a map an older board stored without reading the list again; the ledger text now carries the composition results
(U10 c2, and U10 c4 for information) where the first builder left a placeholder; the HEAD named is the current one.

## 14. Not done, and limits (plainly)

- **Not run:** the full `audit-import.mjs` and `audit-board.mjs` (the lead's alone); the full mutation sweep; `mutate.mjs`
  itself (never imported, executed or run — read as text only, through `rec/bin/mcount.py`/`mkmut.py`/`mcread.py`);
  Chromium (no browser check was needed for this change, and none was run); `playwright install`; `validate:math`;
  Codex's `runner.py` and probes.
- **Not covered by the change** (also in the draft): a file already saved with the merge cannot be split again (its two
  entries are gone, and nothing in it says which requirement was where); boards before this one (v1.86 up to v2.00 as it
  stood) still merge such a pair when they read it, so a pair kept apart here can still be merged by someone on an older
  board — which is why the notice asks for a rename; where such a board already merged a pair and stored its map
  (`DESTDB.lmap`), the readers that use the stored map without reading the list again — `destPkgIn` for a PMO copy
  published before v1.86 (no list in the package), the locked-cycle store from before v1.86 in `destMigrate`, and the
  "in use elsewhere" count (`flowEntUseMap`) — still follow it (the board's own requirement was already moved by that
  board; `destFold` corrects the map whenever the list itself is read again); a merge is listed for the session it was made
  in only (no saved field), and a later status message replaces the opening line (the panel keeps saying it); a merge made
  after opening (a PMO submittal, a shared-folder load) is listed in the panel, not on that action's own line; a typed name
  of any length is still kept, untrimmed (the ledger's 5,000 characters — not a data-loss route, left alone as the smallest
  change); a locked cycle taken from a file by `cycTake` is copied with its keys as they are and never read through a list
  — a separate, pre-existing gap this change neither causes nor closes (U40 only makes the plan's keys stay, so in the
  tested case the cycle's keys now resolve). When the opening line was itself a warning, the combined line (warning + the
  notice) is written to the diagnostics log a second time (`setStat` → `diagNote` for a line starting ⚠); every word of
  it stays true, so it was left as it is.
- **Not verified:** two real machines, a real shared folder, Excel/LibreOffice opening the workbook (the sheets were read
  back with the board's own `xlsxRead`), and the visual look of the red field mark and the notice.
- **Rule notes, first builder:** two short node invocations ran outside `run.sh` and were not recorded in `pids.txt`: `node
  --check` of c1's audit-import (about 1:34 PM ET; the lock file was absent when checked moments later, at 13:34:38) and
  `node --version` (about 1:57 PM ET; lock absent when checked at 13:57:16). Every other node run went through `run.sh`.
- **Rule notes, this start:** every node run went through `run.sh`. Quick read-only shell commands (`ls`, `cat`, `grep`,
  `sed -n`, `head`/`tail`, `cmp`, `diff`, `git hash-object`, `git status`/`log` in the scratch clones and a read of
  orbit-board's log, `ps`, `dmesg`, `free`), two `patch` applications into `x10check/` and `xc4/`, and a few `python3 -I`
  text reads/tallies of this directory's logs and files were run directly from the shell, without the `setsid -w timeout`
  wrapper and without a PID line; each was a single short command (none ran for more than a few seconds) and none was a node
  or Chromium process. The text helpers that wrote anything of record (`mkmut.py` ×15, `mcount.py` ×5, `suitetab2.py`, `readme2.py`) ran
  through `bx.sh` (PID lines in `pids.txt`); the later text commands (`git merge-file` ×4 into `verify2/merge3/`, the
  draft and README-part edits) ran under `setsid -w timeout -k 10 600` without a PID line. **One mistake, said plainly:** this start first launched its two lanes through `bx.sh`, whose 600 s cap
  then applied to the whole lane; at about 3:02:46 PM ET the cap ended both lane scripts. Two runs lost their exit record:
  `S-audit-hostile-base` (its node had printed ALL CHECKS PASSED at 3:04:38 PM ET) and `S-audit-recon-c1b` (stopped
  writing at 3:02:56 PM ET and was gone by 3:14 PM ET; why it stopped is not established — the kernel log still held only
  five out-of-memory kills, none of this track's PIDs). Neither is counted; both were re-run (`post5.sh`, lanes started as
  ordinary background shells, every run inside still bounded by `run.sh`).
- **The U10 overlap** was composed with U10's c2, the latest copy in its `diffs/`, and, for information, with its newest
  copy c4 (still in review). A later U10 copy should be composed again the same way (apply its diffs against the base to
  c1 with `patch`, insert its entries before the R3 anchor after U40's, run both focused harnesses and `probes/compose.mjs`).

## 15. The exact diffs (c1 against the base)

### `diffs/c1-vs-base.prioritization-board-grid.html.diff`

````diff
--- a/prioritization-board-grid.html
+++ b/prioritization-board-grid.html
@@ -2370,7 +2370,7 @@
   return d;
 })();
 // var, not let: flowEnts() can be asked for before the lines that would declare these have run
-var _destReady=false, _destOthers=false, _destBusy=false, _destOpening=false;
+var _destReady=false, _destOthers=false, _destBusy=false, _destOpening=false, _destMerges=[];
 // WHAT A FULL IMPORT BROUGHT (v1.86). The import reloads the board to open what it wrote, so the
 // report it owes is kept across the reload and said on the first render after it.
 var _impRep=(function(){ try{ const r=localStorage.getItem('prio27impRep'); if(r) localStorage.removeItem('prio27impRep'); return r; }catch(e){ return null; } })(), _impSaid=false;
@@ -14893,6 +14893,9 @@
 }
 // Match terms are combined; a different KIND is kept as the board has it and named for the owner.
 function destJoin(hit, e, from){
+  // v2.00 (U40): a key read into another destination by its NAME is a merge, and each one is listed (destNotice)
+  if(hit.k!==String(e.k) && !_destMerges.some(function(m){ return m.k===String(e.k) && m.to===hit.k && m.from===from; }))
+    _destMerges.push({k:String(e.k), n:String(e.n||''), to:hit.k, name:String(hit.n||''), from:from});
   const toks=flowToks(hit.t);
   flowToks(e.t).forEach(function(t){ if(!toks.some(function(x){ return x.toUpperCase()===t.toUpperCase(); })) toks.push(t); });
   hit.t=toks.join(', ');
@@ -14913,6 +14916,7 @@
 // only while something still points at it.
 function destFold(list, from, v186, refs){
   const al=Object.create(null);
+  const claimed=Object.create(null);   // v2.00 (U40): the board key each entry of this list was read into
   let fresh=false;
   // v1.99 (item 95): `fresh` says a key had to change; `touched` says anything the destination list holds changed -- a
   // destination added under its own key, a joined name, a map entry or the list's signature -- so it is stored and
@@ -14933,9 +14937,22 @@
       hit=destHas(lm[e.k]);
       if(!hit && !used) return;          // read before, and deleted here since
     }
+    // v2.00 (U40): TWO ENTRIES OF ONE LIST ARE TWO DESTINATIONS, whatever their names. "Alpha Depot" and "ALPHA DEPOT",
+    // typed side by side, each with its own requirements, were read into ONE when the list met a newer one: the second
+    // matched, by name, the first that the same reading had just added, and its requirements and money moved with nothing
+    // said. One reading never puts two of its entries into one board key -- not through a map an older board kept, not by
+    // name -- and a name is not trusted to choose where the list itself, or the board's, holds that name twice, or where
+    // the destination it names is another entry's key in this same list. The entry is kept under its own key instead,
+    // and destNotice names both.
+    const taken=function(k){ return Object.prototype.hasOwnProperty.call(claimed, k) && claimed[k]!==String(e.k); };
+    if(hit && taken(hit.k)){ hit=null; first=true; }
     if(hit){ if(v186 && hit.k!==e.k){ destJoin(hit, e, from); touched=true; } }
     else {
       hit=destByName(e.n);
+      if(hit && (taken(hit.k)
+        || list.some(function(x){ return x && x.k!==e.k && destNamed(x.n) && destName(x.n)===destName(e.n); })
+        || DESTDB.ents.filter(function(x){ return destName(x.n)===destName(e.n); }).length>1
+        || (v186 && list.some(function(x){ return x && x.k===hit.k && x.k!==e.k; })))) hit=null;
       if(hit){ if(first){ destJoin(hit, e, from); touched=true; } }
       else {
         if(!used && !destNamed(e.n)) return;       // an unnamed placeholder nobody uses is not carried
@@ -14946,6 +14963,7 @@
         DESTDB.ents.push(hit);
       }
     }
+    claimed[hit.k]=String(e.k);
     if(lm && lm[e.k]!==hit.k){ lm[e.k]=hit.k; touched=true; if(hit.k!==e.k) fresh=true; }
     if(hit.k!==e.k) al[e.k]=hit.k;
   });
@@ -15114,6 +15132,16 @@
 function flowEntUseElseTxt(U){ return Object.keys(U).map(function(w){ return w+' ('+U[w]+')'; }).join(', '); }
 function flowSetEnt(i, field, v){
   const L=flowEnts(), e=L[i]; if(!e) return;
+  // v2.00 (U40): A NAME ANOTHER DESTINATION HAS IS REFUSED, before anything changes. Two destinations are one when their
+  // names match, ignoring case and spaces (destName), yet "ALPHA DEPOT" could be typed beside "Alpha Depot" -- and a
+  // board that read the two by name put both destinations' requirements on one. The panel's field keeps what was typed, marked.
+  const o=(field==='n' && destNamed(v))? L.filter(function(x){ return x!==e && destName(x.n)===destName(v); })[0] : null;
+  if(o){
+    const el=document.querySelector('#entBody input[onchange=\'flowSetEnt('+i+',"n",this.value)\']');
+    codeRefusedIn(el, 'Destination name not changed', inShow(v)+' matches '+inShow(o.n)+', another destination on the list '
+      +'(names are compared ignoring case and spaces). This one keeps the name '+inShow(e.n)+'; give it a name of its own. Nothing was changed');
+    return;
+  }
   if(field==='kind'){ e.kind=(v==='prime'?'prime':(v==='gov'?'gov':'other'));
     DESTDB.conflicts=DESTDB.conflicts.filter(function(c){ return c.k!==e.k; }); }
   else e[field]=String(v==null?'':v);
@@ -15705,6 +15733,19 @@
 // The registry, editable. Match terms are optional: they let the chart recognise a destination in
 // the source file's own text, which is how a plan event with no requirement behind it can still be
 // placed. A destination with no terms is only ever reached by logging it on a requirement.
+// v2.00 (U40): WHAT THE LIST HOLDS UNDER ONE NAME, AND WHAT WAS MERGED BY NAME. Destinations whose names match (ignoring
+// case and spaces) but whose keys differ are kept apart -- each keeps its requirements -- and are named here so they can be
+// renamed apart. Every destination a reading in this session put into another by its name is listed (v1.86: "each merge
+// is listed"). Said in this panel and on opening.
+function destNotice(){
+  const L=DESTDB.ents||[], D=L.filter(function(e,i){ return destNamed(e.n) && L.some(function(x,j){ return i!==j && destName(x.n)===destName(e.n); }); });
+  let h=D.length? '⚠ <b>Destinations with matching names are kept apart:</b> '
+    +D.map(function(e){ return esc(e.n)+' ['+esc(e.k)+']'; }).join(' · ')
+    +'. Each keeps its own requirements and money; rename one so they can be told apart.' : '';
+  if(_destMerges.length) h+=(h? ' ' : '')+'<b>Merged by name</b> (the same name, ignoring case and spaces): '+_destMerges.map(function(m){
+    return esc(m.n)+' ['+esc(m.k)+', '+esc(appnName(m.from))+'] → '+esc(m.name)+' ['+esc(m.to)+']'; }).join(' · ')+'.';
+  return h;
+}
 function flowEntEditor(){
   const L=flowEnts();
   const cf=(DESTDB.conflicts||[]).filter(function(c){ return flowEnt(c.k); });
@@ -15741,7 +15782,9 @@
       +(used||(uT?'':'—'))+(uT? (used?' · ':'')+esc(uT) : '')+'</td>'
       +'<td><button class="qb" style="color:var(--red)" onclick="flowDelEnt('+i+')" title="remove">✕</button></td></tr>';
   });
+  const dn=destNotice();     // v2.00 (U40)
   h+='</table>'
+    +(dn? '<div style="font-size:9.5px;color:var(--amber);margin-top:6px">'+dn+'</div>' : '')
     +(cf.length? '<div style="font-size:9.5px;color:var(--amber);margin-top:6px">\u26a0 Named with a different kind on another appropriation: '
       +cf.map(function(c){ const e=flowEnt(c.k); return esc(e.n)+' ('+esc(c.from==='import'? 'an imported file' : appnName(c.from))+' had '
         +esc({prime:'Contractor', gov:'Government activity', other:'Other'}[c.kind]||c.kind)+')'; }).join(' \u00b7 ')
@@ -31583,6 +31626,12 @@
       +(PMODE&&PMODE.ts? ' on '+esc(new Date(PMODE.ts).toLocaleDateString()):'')
       +'. Your work is kept in this browser, against this copy. <b>\u2709 Submit input</b> sends your office\u2019s changes to the portfolio team.'
     : '📦 Opened with the saved board state — last saved'+(PUB.by? ' by <b>'+esc(PUB.by)+'</b>':'')+' '+fmtTs(PUB.ts)+'. Make changes and 💾 Save to pass it on.'); _statQuiet=false; }
+// v2.00 (U40): opening says what destNotice says -- after the line above, never in place of it (an import's report or a
+// warning about this browser's copy stays). The destinations panel keeps saying it after later messages.
+if(destNotice()){
+  const de=document.getElementById('shareStat');
+  _statQuiet=false; setStat((de && de.innerHTML? de.innerHTML+' ' : '')+destNotice());
+}
 function loadShared(cb){
   // file:// (shared drive / synced folder): fetch is blocked, but XHR works when
   // the board is opened via the provided launcher (--allow-file-access-from-files)
````

### `diffs/c1-vs-base.mutate.mjs.txt.diff`

````diff
--- a/tools/export-audit/mutate.mjs.txt
+++ b/tools/export-audit/mutate.mjs.txt
@@ -4285,6 +4285,53 @@
   { id: "v200-u14-notice-plural-it", area: "flowHtml", what: "the panel's notice says \"keeps it\" however many saved years the board cannot answer for: FY24 and FY26 \"stay in the saved selection\", and switching a year \"keeps it\"",
     find: "switching a year on or off keeps '+(F.unavail.length===1?'it':'them')+'.</div>'",
     repl: "switching a year on or off keeps it.</div>'" },
+  // v2.00 (U40): a typed name another destination has is refused; one reading never puts two entries of its list into one
+  // destination; what is kept apart under one name, and every merge by name, is said.
+  { id: "v200-u40-typed-duplicate-kept", area: "flowSetEnt", what: "a typed name another destination has is stored: “ALPHA DEPOT” is kept beside “Alpha Depot”, and a board that reads the list by name merges the two",
+    find: "const o=(field==='n' && destNamed(v))? L.filter(",
+    repl: "const o=(false)? L.filter(" },
+  { id: "v200-u40-refusal-field-unmarked", area: "flowSetEnt", what: "a refused name leaves its field unmarked: what was typed stays there, not marked invalid, with no tooltip saying it was not kept",
+    find: "codeRefusedIn(el, 'Destination name not changed',",
+    repl: "codeRefusedIn(null, 'Destination name not changed'," },
+  { id: "v200-u40-refusal-names-itself", area: "flowSetEnt", what: "the refusal names the destination being renamed as the one it matches: “ALPHA DEPOT” matches “Bravo Yard”",
+    find: "inShow(v)+' matches '+inShow(o.n)+', another destination on the list '",
+    repl: "inShow(v)+' matches '+inShow(e.n)+', another destination on the list '" },
+  { id: "v200-u40-incoming-pair-merged", area: "destFold", what: "a list holding two matching names lets the first be read into a destination of the same name here: R1 moves to the newer list's own Alpha Depot",
+    find: "        || list.some(function(x){ return x && x.k!==e.k && destNamed(x.n) && destName(x.n)===destName(e.n); })\n",
+    repl: "        || false\n" },
+  { id: "v200-u40-ambiguous-local-first", area: "destFold", what: "a name the board holds twice picks the first: an incoming “alpha depot” is put into U40-A",
+    find: "        || DESTDB.ents.filter(function(x){ return destName(x.n)===destName(e.n); }).length>1\n",
+    repl: "        || false\n" },
+  { id: "v200-u40-same-list-key-consumed", area: "destFold", what: "a name claims the destination another entry of the same list is: U40-A, by name, into U40-B, and both requirements on one",
+    find: "        || (v186 && list.some(function(x){ return x && x.k===hit.k && x.k!==e.k; })))) hit=null;",
+    repl: "        || false)) hit=null;" },
+  { id: "v200-u40-map-collapse-followed", area: "destFold", what: "an older board's map that sends both entries of a list to one destination is followed: R2 lands on R1's",
+    find: "    if(hit && taken(hit.k)){ hit=null; first=true; }",
+    repl: "    if(false){ hit=null; first=true; }" },
+  { id: "v200-u40-name-into-taken", area: "destFold", what: "a name may choose a destination this same reading already put another entry into: x2 (Bravo Yard) into x1's destination since renamed Bravo Yard",
+    find: "      if(hit && (taken(hit.k)\n",
+    repl: "      if(hit && (false\n" },
+  { id: "v200-u40-claim-unrecorded", area: "destFold", what: "the destination each entry was read into is not recorded, so neither a map nor a name is stopped from putting two entries into one",
+    find: "    claimed[hit.k]=String(e.k);\n",
+    repl: "" },
+  { id: "v200-u40-merge-unlisted", area: "destJoin", what: "a destination read into another by name is not listed: the merge happens with nothing said",
+    find: "  if(hit.k!==String(e.k) && !_destMerges.some(",
+    repl: "  if(false && !_destMerges.some(" },
+  { id: "v200-u40-merge-from-slug", area: "destNotice", what: "a merge names the list it came from by its internal slug: “ff” rather than Full Fund",
+    find: "esc(appnName(m.from))",
+    repl: "esc(m.from)" },
+  { id: "v200-u40-apart-unsaid", area: "destNotice", what: "destinations kept apart under matching names are not named: the panel and the opening say nothing of Alpha Depot and ALPHA DEPOT",
+    find: "  let h=D.length? '⚠ <b>Destinations with matching names are kept apart:</b> '",
+    repl: "  let h=false? '⚠ <b>Destinations with matching names are kept apart:</b> '" },
+  { id: "v200-u40-editor-notice-gone", area: "flowEntEditor", what: "the destinations panel leaves out what destNotice says",
+    find: "    +(dn? '<div style=\"font-size:9.5px;color:var(--amber);margin-top:6px\">'+dn+'</div>' : '')\n",
+    repl: "" },
+  { id: "v200-u40-opening-unsaid", area: "opening", what: "opening says nothing of destinations kept apart (or merged by name): the line says only that the file opened",
+    find: "if(destNotice()){\n  const de=document.getElementById('shareStat');",
+    repl: "if(false){\n  const de=document.getElementById('shareStat');" },
+  { id: "v200-u40-opening-replaces", area: "opening", what: "opening's notice takes the place of the opening line: “Opened with the saved board state” (or an import's report) is gone",
+    find: "setStat((de && de.innerHTML? de.innerHTML+' ' : '')+destNotice());",
+    repl: "setStat(destNotice());" },
   // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.
   { id: "v200-r3-landed-view-unsaid", area: "_driveStorePushRun", what: "a folder save that lands while a locked view is on screen says “🔒 Not kept — PB27 is a locked view. ✅ Saved …” again, naming no plan (or, quiet, leaves persist's refusal on screen)",
     find: "  if(CYCVIEW){ _cycRefusedAt=0; setStat('✅ <b>Saved the working plan</b> of '+esc(APPN_LBL[ap]||ap)+' FY'+(fy%100)+' to the shared folder — '\n    +Math.round(body.length/1024)+' KB, built before '+blLbl(CYCVIEW)+' was put on screen. '+blLbl(CYCVIEW)+' is a locked view: nothing in it '\n    +'is saved. Everyone sees the working plan on their next refresh.'+penNote+lateNote); render(); return true; }\n",
````

### `diffs/c1-vs-base.audit-import.mjs.diff`

````diff
--- a/tools/export-audit/audit-import.mjs
+++ b/tools/export-audit/audit-import.mjs
@@ -7797,6 +7797,199 @@
   await settleBoards();
 })();
 // ==== end v2.00 (U13) ====
+// ==== v2.00 (U40): two destinations whose names match stay two, and every merge by name is said ====
+// Two destinations are one when their names match, ignoring case and spaces (destName) -- yet "ALPHA DEPOT" could be typed
+// beside "Alpha Depot", each with its own requirements. Opened in a browser whose own destination list was newer (a second
+// person's), the file's list was read into that one BY NAME: its second entry matched the first, which the same reading had
+// just added, and the two became one. R2's $300 moved to Alpha Depot -- the year on screen, the next year, both hops, the
+// locked cycle, the funds flow and its workbook -- the opening line said only that the file had opened, and a save kept the
+// merge. The same reading runs for a list saved before v1.86 (in any browser), a plan taken from another file, a load from
+// the shared folder and a PMO submittal, and an older board's map could send both to one key without reading a name. Now a
+// typed name another destination has is refused and nothing changes; one reading never puts two entries of its list into
+// one destination; a name is not trusted where the list or the board holds it twice, or where it names another entry of
+// the same list; and the destinations panel and the opening line name the destinations kept apart and every merge made by
+// name. Expected dollars are typed: R1 $900, R2 $300, $1,200 in all. CONTROLS (they held before): a fresh browser kept both;
+// a full import replaces the board's list with the file's; an unambiguous name on another list still merges (v1.86), the
+// same way twice; a different name, a kind, match terms and an unnamed placeholder still save.
+await (async () => {   // a function, not a bare block: see settleBoards() in boot.mjs
+  const __bm = bootMark();
+  const name = 'v2.00 (U40) — two destinations whose names match stay two, and every merge by name is said';
+  try {
+  const J = JSON.stringify;
+  const SC = { services: ['USAF', 'ANG', 'AFRC'], items: [v10It('R1', 'AV', [900, 0, 0]), v10It('R2', 'AV', [300, 0, 0])],
+    disc: [5000, 5000, 5000], mand: [0, 0, 0], order: ['R1', 'R2'] };
+  const make = () => { const B = boot(); seed(B.ev, SC); asBooted(B.ev, SC); B.ev(`applyState(S); save(); 'ok'`); return B; };
+  const PAIR = [{ k: 'U40-A', n: 'Alpha Depot', kind: 'gov', t: '' }, { k: 'U40-B', n: 'ALPHA DEPOT', kind: 'gov', t: '' }];
+  // the board's list made exactly these, IN PLACE: the plan and the cycle store hold the same list, so nothing is read in again
+  const LIST = l => `DESTDB.ents.splice(0, DESTDB.ents.length); ${J(l)}.forEach(function(e){ DESTDB.ents.push(e); });`;
+  const lsOf = B => JSON.parse(B.ev(`(function(){ var o={}; for(var i=0;i<localStorage.length;i++){ var k=localStorage.key(i); o[k]=localStorage.getItem(k); } return JSON.stringify(o); })()`));
+  const stat = B => B.ev(`(document.getElementById('shareStat')||{}).textContent||''`);
+  const nm = `function(k){ var e=flowEnts().filter(function(x){ return x.k===k; })[0]; return e? e.n : '(none: '+k+')'; }`;
+  // R1 and R2 by destination NAME, both hops, in the year on screen, the next saved year and the locked cycle; and two keys
+  const where = B => JSON.parse(B.ev(`(function(){ var n=${nm};
+    var one=function(st){ var D=(st&&st.dest)||{}; return ['R1','R2'].map(function(id){ var d=D[id]||{}; return id+': '+n(d.to)+' > '+n(d.end); }).join(' | '); };
+    var c=CYCDB.cycles['PB|'+MS.cur];
+    return JSON.stringify([one(S), one(MS.years[MS.cur+1]), c? one(c.years[MS.cur]) : '(no locked cycle)', S.dest.R1.to!==S.dest.R2.to]); })()`));
+  const ROW = 'R1: Alpha Depot > ALPHA DEPOT | R2: ALPHA DEPOT > Alpha Depot';
+  const WHERE = [ROW, ROW, ROW, true];
+  // the year on screen alone, first hop: [R1's destination, R2's, two keys]
+  const here = B => B.ev(`(function(){ var n=${nm}; return JSON.stringify([n(S.dest.R1.to), n(S.dest.R2.to), S.dest.R1.to!==S.dest.R2.to]); })()`);
+  const HERE = J(['Alpha Depot', 'ALPHA DEPOT', true]);
+  // the funds flow by destination: {key: [name, dollars]} for every destination holding money, and the total
+  const money = B => B.ev(`(function(){ var f=flowCalc(), n=${nm}, o={};
+    Object.keys(f.ext.by).sort().forEach(function(k){ if(f.ext.by[k].v) o[k]=[n(k), f.ext.by[k].v]; }); return JSON.stringify([o, f.tot]); })()`);
+  const FLOW = J([{ 'U40-A': ['Alpha Depot', 900], 'U40-B': ['ALPHA DEPOT', 300] }, 1200]);
+  // the Funds Flow workbook as exported, read back: each Alpha sheet's requirement rows, '<requirement> <amount>'
+  const sheets = async B => { const b = JSON.parse(await B.w.eval(`(async function(){ var cap=null, _B=window.Blob;
+      window.Blob=function(p,o){ if(p&&p[0]&&p[0].byteLength) cap=p[0]; return new _B(p,o); };
+      try{ exportFlow(); } finally{ window.Blob=_B; } if(!cap) throw Error('no workbook was made');
+      return JSON.stringify(await xlsxRead(cap.buffer.slice(cap.byteOffset, cap.byteOffset+cap.byteLength))); })()`));
+    const o = {}; Object.keys(b).forEach(n => { const r = b[n].filter(x => /^Req R\d$/.test(String(x[0]))).map(x => x[0] + ' ' + x[5]);
+      if (r.length && /alpha/i.test(n)) o[n] = r; }); return J(o); };
+  // what the destinations panel says of matching names, and of merges by name ('(nothing)' when it says nothing)
+  const said = (B, re) => { const m = B.ev('flowEntEditor()').match(re); return m ? m[1] : '(nothing)'; };
+  const APART = /⚠ <b>Destinations with matching names are kept apart:<\/b> ([^<]*)/;
+  const MERGED = /<b>Merged by name<\/b> \(the same name, ignoring case and spaces\): ([^<]*)/;
+  const PAIRSAID = 'Alpha Depot [U40-A] · ALPHA DEPOT [U40-B]. Each keeps its own requirements and money; rename one so they can be told apart.';
+
+  // ---- (1) TYPING. "ALPHA DEPOT" and "  alpha   depot  " beside "Alpha Depot": refused, nothing changing anywhere ----
+  const T = make();
+  T.ev(`(function(){ ${LIST([{ k: 'U40-A', n: 'Alpha Depot', kind: 'other', t: '' }, { k: 'U40-B', n: 'Bravo Yard', kind: 'other', t: '' }])}
+    var C=flowCfg(); C.ents=DESTDB.ents; C.dv=1; S.dest={R1:{to:'U40-A',end:''},R2:{to:'U40-B',end:''}}; persistDest(); save(); return 'ok'; })()`);
+  const tState = () => T.ev(`JSON.stringify([DESTDB.ents, S.dest, _saveGen, _sideGen, DIRTY, _baseDirty])`);
+  for (const [raw, shown] of [['ALPHA DEPOT', '“ALPHA DEPOT”'], ['  alpha   depot  ', '“  alpha   depot  ”']]) {
+    const sc = '(1) typed ' + shown;
+    const s0 = tState(), l0 = J(lsOf(T));
+    T.ev(`flowSetEnt(1, 'n', ${J(raw)}); 'ok'`);
+    chk(name, sc, 'refused: the destination keeps the name Bravo Yard', T.ev('DESTDB.ents[1].n'), 'Bravo Yard');
+    chk(name, sc, 'nothing else changed: the list, the requirements, the change counts, the unsaved marks', tState(), s0);
+    chk(name, sc, 'and nothing was written to browser storage', J(lsOf(T)), l0);
+    chk(name, sc, 'and the board says so, word for word', stat(T), '⚠ Destination name not changed. ' + shown + ' matches “Alpha Depot”, another destination on the list '
+      + '(names are compared ignoring case and spaces). This one keeps the name “Bravo Yard”; give it a name of its own. Nothing was changed.');
+  }
+  // the panel's own field, through its change handler (Bravo Yard put back first, on a board that took a typed name)
+  T.ev(`(function(){ flowSetEnt(1, 'n', 'Bravo Yard'); entOpen=true; render();
+    var el=[].slice.call(document.querySelectorAll('#entBody input')).filter(function(x){ return /^flowSetEnt\\(\\d+,"n",/.test(x.getAttribute('onchange')||'') && x.value==='Bravo Yard'; })[0];
+    if(!el) throw Error('the name field of Bravo Yard is not in the panel');
+    el.focus(); el.value='ALPHA DEPOT'; el.dispatchEvent(new Event('change', {bubbles:true})); globalThis.__u40el=el; return 'ok'; })()`);
+  chk(name, '(1) the panel field', 'refused: Bravo Yard kept; the field keeps what was typed, marked invalid, its tooltip says why, focus stays',
+    T.ev(`JSON.stringify([DESTDB.ents[1].n, __u40el.value, __u40el.getAttribute('aria-invalid'), __u40el.title, document.activeElement===__u40el])`),
+    J(['Bravo Yard', 'ALPHA DEPOT', 'true', '“ALPHA DEPOT” matches “Alpha Depot”, another destination on the list (names are compared ignoring case and spaces). '
+      + 'This one keeps the name “Bravo Yard”; give it a name of its own. Nothing was changed', true]));
+  T.ev(`(function(){ __u40el.value='Charlie Yard'; __u40el.dispatchEvent(new Event('change', {bubbles:true}));
+    globalThis.__u40ok=[].slice.call(document.querySelectorAll('#entBody input')).filter(function(x){ return x.value==='Charlie Yard'; })[0]; return 'ok'; })()`);
+  chk(name, '(1) the panel field', 'CONTROL: a name of its own is stored, and the field redrawn without the mark or the tooltip',
+    T.ev(`JSON.stringify([DESTDB.ents[1].n, !!__u40ok && __u40ok.getAttribute('aria-invalid'), !!__u40ok && __u40ok.title])`), J(['Charlie Yard', null, '']));
+  T.ev(`flowSetEnt(0, 'n', 'ALPHA DEPOT'); flowSetEnt(1, 'kind', 'gov'); flowSetEnt(1, 't', 'CHARLIE'); flowAddEnt(); flowAddEnt(); 'ok'`);
+  chk(name, '(1) controls', 'CONTROL: a destination re-spelled in its own name, a kind, match terms and two unnamed placeholders all save',
+    T.ev(`JSON.stringify([DESTDB.ents[0].n, DESTDB.ents[1].kind, DESTDB.ents[1].t, DESTDB.ents.filter(function(e){ return e.n==='New destination'; }).length])`),
+    J(['ALPHA DEPOT', 'gov', 'CHARLIE', 2]));
+
+  // ---- (2) THE FILE: the pair as an earlier board saved it -- both hops, two years, a locked cycle, the flow by destination ----
+  const X = make();
+  X.ev(`(function(){ ${LIST(PAIR)} var C=flowCfg(); C.ents=DESTDB.ents; C.dv=1; C.axis='dest'; C.fys=[MS.cur]; C.aps=['om'];
+    S.dest={R1:{to:'U40-A',end:'U40-B'}, R2:{to:'U40-B',end:'U40-A'}}; MS.years[MS.cur]=S; MS.years[MS.cur+1]=JSON.parse(JSON.stringify(S));
+    persistDest(); save(); blCyc='PB'; blYr=MS.cur; cycLock(); save(); return 'ok'; })()`);
+  const html = X.ev('buildSavedHtml()');
+  const PUBRE = /<script type="application\/json" id="pubState">([\s\S]*?)<\/script>/;
+  const SHEETS = J({ 'Alpha Depot': ['Req R1 900'], 'ALPHA DEPOT 2': ['Req R2 300'] });
+  // everything a reading must leave as the file had it, and say; `c` marks a reading that kept it before as well (a control)
+  const all = async (B, at, sheetsWant, apart, c = '') => {
+    chk(name, at, c + 'R1 and R2 keep their own destinations, both hops, in the year on screen, the next year and the locked cycle, on two keys', J(where(B)), J(WHERE));
+    chk(name, at, c + 'the funds flow: R1’s $900 on Alpha Depot, R2’s $300 on ALPHA DEPOT, $1,200 in all', money(B), FLOW);
+    chk(name, at, c + 'the Funds Flow workbook: R1’s $900 and R2’s $300 on two sheets, one each', await sheets(B), sheetsWant);
+    chk(name, at, 'the destinations panel names the destinations kept apart', said(B, APART), apart);
+  };
+  chk(name, '(2) the file', 'CONTROL: the fixture holds the pair, on the keys it was given', J(JSON.parse(html.match(PUBRE)[1]).destDb.ents.map(e => e.k + ':' + e.n)), J(['U40-A:Alpha Depot', 'U40-B:ALPHA DEPOT']));
+  { const F = boot({ html });
+    chk(name, '(2) a fresh browser', 'the opening line is kept, and names the two kept apart', [stat(F).startsWith('📦 Opened with the saved board state'), stat(F).endsWith(' ⚠ Destinations with matching names are kept apart: ' + PAIRSAID)].join(','), 'true,true');
+    await all(F, '(2) a fresh browser', SHEETS, PAIRSAID, 'CONTROL: '); }
+  // ---- (3) A SECOND PERSON'S NEWER LIST, holding neither key: Bravo Yard alone, or an Alpha Depot of its own ----
+  for (const [own, sheetsWant, apart] of [
+    ['Bravo Yard', SHEETS, PAIRSAID],
+    ['Alpha Depot', J({ 'Alpha Depot 2': ['Req R1 900'], 'ALPHA DEPOT 3': ['Req R2 300'] }), 'Alpha Depot [U40-C] · ' + PAIRSAID]]) {
+    const at = '(3) opened where a newer list holds ' + own;
+    const db = { ts: Date.now() + 60000, ents: [{ k: 'U40-C', n: own, kind: 'other', t: '' }], lmap: {}, lsig: {}, conflicts: [], gone: [] };
+    const B = boot({ html, ls: { prio27destdb: J(db) } });
+    chk(name, at, 'CONTROL: the opening line is still the board’s own', stat(B).startsWith('📦 Opened with the saved board state'), true);
+    chk(name, at, 'and it goes on to name the destinations kept apart', stat(B).endsWith(' ⚠ Destinations with matching names are kept apart: ' + apart), true);
+    chk(name, at, 'CONTROL: the newer list’s own destination is kept, on its own key', B.ev(`JSON.stringify(flowEnts().filter(function(e){ return e.k==='U40-C'; }).map(function(e){ return e.n; }))`), J([own]));
+    await all(B, at, sheetsWant, apart);
+    const B2 = boot({ html: B.ev('buildSavedHtml()') });
+    await all(B2, at + ', saved there and reopened', sheetsWant, apart);
+  }
+
+  // ---- (4) A LIST SAVED BEFORE v1.86 holding the pair (no board list; the plan's own, unmarked), in a browser that never held it ----
+  { const Lg = make();
+    Lg.ev(`(function(){ _destReady=false; MS.flow={ents:[{k:'x1',n:'Alpha Depot',kind:'other',t:''},{k:'x2',n:'ALPHA DEPOT',kind:'other',t:''}]};
+      S.dest={R1:{to:'x1',end:''},R2:{to:'x2',end:''}}; MS.years[MS.cur]=S; save(); return 'ok'; })()`);
+    const lh = v186AsV185(Lg.ev('buildSavedHtml()'));
+    const LJ = JSON.parse(lh.match(PUBRE)[1]);
+    chk(name, '(4) before v1.86', 'CONTROL: the fixture is what v1.85 wrote (no board list, an unmarked plan list of two)', J([!!LJ.destDb, !!LJ.appns.om.flow.dv, LJ.appns.om.flow.ents.length]), J([false, false, 2]));
+    const C = boot({ html: lh });
+    chk(name, '(4) before v1.86', 'R1 on Alpha Depot, R2 on ALPHA DEPOT, two keys', here(C), HERE);
+    chk(name, '(4) before v1.86', 'the opening line names the two kept apart', /⚠ Destinations with matching names are kept apart: Alpha Depot \[d[0-9a-z]+\] · ALPHA DEPOT \[d[0-9a-z]+\]\. Each keeps/.test(stat(C)), true);
+    const C2 = boot({ html: lh, ls: lsOf(C) });
+    chk(name, '(4) before v1.86', 'CONTROL: reopened before it is saved, the same keys again', C2.ev(`JSON.stringify([S.dest.R1.to, S.dest.R2.to])`), C.ev(`JSON.stringify([S.dest.R1.to, S.dest.R2.to])`));
+    chk(name, '(4) before v1.86', 'saved and reopened: R1 on Alpha Depot, R2 on ALPHA DEPOT', here(boot({ html: C.ev('buildSavedHtml()') })), HERE); }
+
+  // ---- (5) THE OTHER WAYS A LIST IS READ IN: a plan taken from the file, a shared-folder load, a PMO submittal; a full import ----
+  const takeIn = () => { const Y = make(); Y.ev(`flowAddEnt(); flowSetEnt(flowEnts().length-1, 'n', 'Bravo Yard'); 'ok'`); return Y; };
+  { const Y = takeIn();
+    Y.ev(`(function(){ window.confirm=function(){ return true; }; window.alert=function(){}; var txt=${J(html)};
+      consTakeApply(JSON.parse(txt.match(/<script type="application\\/json" id="pubState">([\\s\\S]*?)<\\/script>/)[1]), txt, 'x.html', ['om'], false); return 'ok'; })()`);
+    const Y2 = boot({ ls: lsOf(Y) });
+    chk(name, '(5) O&M taken from the file', 'R1 and R2 keep their destinations, both hops, every year and the locked cycle that came with it', J(where(Y2)), J(WHERE));
+    chk(name, '(5) O&M taken from the file', 'the funds flow', money(Y2), FLOW); }
+  { const Y = takeIn();
+    chk(name, '(5) a shared-folder load', 'it loads; R1 on Alpha Depot, R2 on ALPHA DEPOT, two keys',
+      J([Y.ev(`applyStore(${J(JSON.parse(html.match(PUBRE)[1]).appns.om)})!==false`), here(Y)]), J([true, HERE])); }
+  { const Y = takeIn();
+    chk(name, '(5) a PMO submittal', 'R1 on Alpha Depot, R2 on ALPHA DEPOT, two keys', Y.ev(`(function(){ var n=${nm};
+      var p={ap:'om', dest:${J(PAIR)}, items:{R1:{dest:{to:'U40-A',end:''}}, R2:{dest:{to:'U40-B',end:''}}}, base:{}, added:[]}; destPkgIn(p);
+      return JSON.stringify([n(p.items.R1.dest.to), n(p.items.R2.dest.to), p.items.R1.dest.to!==p.items.R2.dest.to]); })()`), HERE); }
+  { const Y = takeIn();
+    const ok = Y.ev(`(function(){ window.confirm=function(){ return true; }; window.alert=function(){}; return fullImportText(${J(html)}, 'x.html'); })()`);
+    const Y2 = boot({ ls: lsOf(Y) });
+    chk(name, '(5) a full import', 'CONTROL: it runs, and the file’s list replaces the board’s: nothing moved', J([ok, where(Y2)]), J([true, WHERE])); }
+
+  // ---- (6) ONE READING, ITS LIST AND THE BOARD'S: what a name may and may not decide (destFold read directly) ----
+  { const K = make();
+    chk(name, '(6) a key of the same list', 'a name never claims the destination another entry of the same list IS (U40-B, renamed here): both kept, nothing re-pointed',
+      K.ev(`(function(){ ${LIST([{ k: 'U40-B', n: 'Alpha Depot', kind: 'other', t: '' }])}
+        var al=destFold([{k:'U40-A',n:'Alpha Depot',kind:'other',t:''},{k:'U40-B',n:'Bravo Yard',kind:'other',t:''}], 'om', true, {'U40-A':1,'U40-B':1});
+        return JSON.stringify([al, DESTDB.ents.map(function(e){ return e.k; }).sort()]); })()`), J([{}, ['U40-A', 'U40-B']])); }
+  { const A = make();
+    chk(name, '(6) a name the board holds twice', 'no first one is picked: the incoming destination is kept on its own key',
+      A.ev(`(function(){ ${LIST(PAIR)} var al=destFold([{k:'U40-C',n:'alpha depot',kind:'other',t:''}], 'ff', true, {'U40-C':1});
+        return JSON.stringify([al, DESTDB.ents.map(function(e){ return e.k; })]); })()`), J([{}, ['U40-A', 'U40-B', 'U40-C']])); }
+  { const M = make();
+    chk(name, '(6) an older board’s map', 'a map that sends both entries of a list to one destination is not followed for the second: R1 on Alpha Depot, R2 on ALPHA DEPOT, two keys',
+      M.ev(`(function(){ ${LIST([{ k: 'U40-C', n: 'Alpha Depot', kind: 'other', t: '' }])} var q=${J(PAIR)}; DESTDB.lmap[destSig(q)]={'U40-A':'U40-C','U40-B':'U40-C'};
+        S.dest={R1:{to:'U40-A',end:''},R2:{to:'U40-B',end:''}}; destRemap([S], destFold(q, 'om', false, {'U40-A':1,'U40-B':1}));
+        var C=flowCfg(); C.ents=DESTDB.ents; C.dv=1; C.axis='dest'; C.fys=[MS.cur]; C.aps=['om']; persistDest(); save(); return 'ok'; })()`) === 'ok' ? here(M) : '(threw)', HERE);
+    chk(name, '(6) an older board’s map', 'the funds flow: $900 and $300 on two destinations, $1,200 in all',
+      M.ev(`(function(){ var f=flowCalc(); return JSON.stringify([f.ext.by[S.dest.R1.to].v, f.ext.by[S.dest.R2.to].v, f.tot]); })()`), J([900, 300, 1200]));
+    chk(name, '(6) an older board’s map', 'saved and reopened: R1 on Alpha Depot, R2 on ALPHA DEPOT, two keys', here(boot({ html: M.ev('buildSavedHtml()') })), HERE); }
+  { const G = make();
+    chk(name, '(6) a name a destination took on since', 'x1 was read into a destination since renamed Bravo Yard; x2 (Bravo Yard, its destination gone here, still used) is not put into it',
+      G.ev(`(function(){ ${LIST([{ k: 'U40-D', n: 'Bravo Yard', kind: 'other', t: '' }])} var q=[{k:'x1',n:'Alpha Depot',kind:'other',t:''},{k:'x2',n:'Bravo Yard',kind:'other',t:''}];
+        DESTDB.lmap[destSig(q)]={x1:'U40-D', x2:'U40-GONE'}; var al=destFold(q, 'om', false, {x1:1, x2:1});
+        return JSON.stringify([al.x1, al.x2!=='U40-D', DESTDB.ents.length]); })()`), J(['U40-D', true, 2])); }
+  { const L = make();
+    L.ev(`(function(){ ${LIST([{ k: 'U40-A', n: 'Alpha Depot', kind: 'other', t: 'OLD' }])} var q=[{k:'x1',n:'ALPHA  DEPOT',kind:'other',t:'NEW'}];
+      globalThis.__u40maps=JSON.stringify([destFold(q, 'ff', false, {x1:1}), destFold(q, 'ff', false, {x1:1})]); return 'ok'; })()`);
+    chk(name, '(6) one name on another list', 'CONTROL: still merged by name (v1.86), the same way twice: one destination, both lists’ match terms',
+      L.ev(`JSON.stringify([JSON.parse(__u40maps), DESTDB.ents.length, DESTDB.ents[0].t])`), J([[{ x1: 'U40-A' }, { x1: 'U40-A' }], 1, 'OLD, NEW']));
+    chk(name, '(6) one name on another list', 'and the merge is listed in the destinations panel, with the list it came from', said(L, MERGED), 'ALPHA  DEPOT [x1, Full Fund] → Alpha Depot [U40-A].');
+    chk(name, '(6) one name on another list', 'CONTROL: no destination is named as kept apart', said(L, APART), '(nothing)'); }
+  } catch (e) {
+    failures.push({ scenario: name, where: 'harness', what: 'the block threw: ' + String((e && e.stack) || e).slice(0, 300), got: 'threw', want: 'ran' });
+  }
+  bootRelease(__bm, keepBoards());
+  await settleBoards();
+})();
+// ==== end v2.00 (U40) ====
 
 await (async () => {   // a function, not a bare block: see settleBoards() in boot.mjs
   const __bm = bootMark();
````
