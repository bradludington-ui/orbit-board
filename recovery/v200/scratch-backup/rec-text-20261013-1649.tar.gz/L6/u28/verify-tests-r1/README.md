# U28 verifier, round 1, lens B (test adequacy and regressions)

Directory: `rec/L6/u28/verify-tests-r1`. The paths below are relative to it unless they say otherwise. An earlier
attempt at this review began at 12:44 AM ET on 13 Oct and stopped at the usage limit at about 12:49 AM ET. It had only
copied files: `run.sh`, `fc-nosegoe.sh`, `w/probe/*`, `basecopy/` and the `base` symlink. It ran nothing. This attempt
began at 4:51 AM ET on 13 Oct. Its last run ended at 5:57:28 AM ET, and this README was written after 5:58 AM ET.

I worked read-only on the board, the tools, the builder's files and both repositories. I edited, staged, committed and
pushed nothing. I never imported or ran `mutate.mjs` and never ran `playwright install`. I did not run the full
audit-import or audit-board.

## Verdict: sound, with issues

Every run the builder reports reproduces. That covers all 27 of them, L1-L4 and p01-p19. The check lines are identical
and so is every number the probes print. The root cause is right: `/etc/fonts/conf.d/56-prefer-inter.conf` (no
package owns it, mtime 2026-10-03 05:35:22 UTC) sends 'Segoe UI' to Inter, Chromium draws the money in Inter-Bold, and
without that one line layout-fits passes 54/54 on the base. The run method does not blind layout-fits to real
regressions at Arial's widths: board mutants BM1-BM4 are all caught under FONTCONFIG_FILE. The pre-check `font-env.mjs`
catches 6 of the 7 wrong environments I built.

The issues:

1. **Must-fix (text only):** the ledger draft treats the font bypass as decided. It says "verify:grid is to be run here
   as `FONTCONFIG_FILE=...`", and it points to two scratch files. That choice is still open: the lead's own status
   (`scratchpad/status-tail.md`, "For Brad to decide") lists it as Brad's decision. Only 1 of the 14 verify:grid tools
   has ever been run under the variable.
2. **Should-fix (test adequacy):** under the proposed run method, layout-fits measures at Arial's widths only. A change
   that *clips* the money passes it, 54/54: mutant BM5, ellipsis on the money cells. Yet at the +6% stand-in that
   change visibly truncates Brief's figure to "$123,456,…". The builder's own clip probe `visual.mjs` reports "clipped
   by nothing" for BM5, exactly as it does for the base, because it never examines the cell itself.

## Re-runs of the builder's runs (same commands, my own outputs; one at a time; lock checked before each one; it was never present)

| mine | builder's | start ET (13 Oct) | exit | wall s | result vs builder |
|---|---|---|---|---|---|
| V01-font-env-asis | p17 | 04:55:17 | 1 | 5.1 | identical: Inter (Inter-Bold) 87.64 px vs Arial 76.47 |
| V02-font-env-nosegoe (my fcA) | p18 | 04:55:22 | 0 | 2.9 | identical: Liberation Sans 76.47 = Arial |
| V03/V04 stand-in templates 106/103 | p10 | 04:56:00 | 0/0 | 0.3/0.2 | byte-identical to builder's `out/base/tpl/*` |
| V05 L1 as is | L1 | 04:56:00 | 1 | 177.8 | **Chromium "Target crashed"** (machine memory pressure), incomplete |
| V06 L2 nosegoe | L2 | 04:58:58 | 1 | 210.0 | **"Target crashed"**, incomplete |
| V07 L3 +6% | L3 | 05:02:28 | 1 | 86.3 | **page-load TimeoutError**, incomplete |
| V08 L4 +3% | L4 | 05:03:54 | 0 | 267.5 | identical: 54 ok |
| V09 L3b +6% under nosegoe | (new) | 05:08:22 | 1 | 112.9 | **"Target crashed"**, incomplete |
| V05b L1 as is | L1 | 05:10:15 | 1 | 214.3 | 48 ok + the same 6 FAIL lines; only H's selTint detail differs (200,207,217 vs 199,206,216; it changes between runs, and no check depends on it) |
| V06b L2 nosegoe | L2 | 05:13:50 | 0 | 206.2 | identical: 54 ok |
| V07b L3 +6% | L3 | 05:17:16 | 1 | 186.3 | identical: 52 ok, FAIL J harbor brief + parchment brief, 180 widths each |
| V09b L3b +6% under nosegoe | (new) | 05:20:22 | 1 | 183.3 | identical to L3 (the stand-in is unaffected by the variable) |
| V20 p01 build | p01 | 05:23:26 | 0 | 2.2 | the same file apart from the save timestamps (`ts`, journal `t`) |
| V21 p02 variants | p02 | 05:23:28 | 0 | 0.3 | as V20 |
| V22 p03 measure as is | p03 | 05:23:28 | 0 | 129.9 | identical log (every number, every font line) |
| V23 p12 measure nosegoe | p12 | 05:25:38 | 0 | 85.4 | identical |
| V24 p05 +6% | p05 | 05:27:04 | 0 | 137.2 | identical; standinProblem null |
| V25 p05 +3% | p05 | 05:29:21 | 0 | 137.8 | identical; standinProblem null |
| V26/V27 p06/p07 visual | p06/p07 | 05:31:39/05:31:48 | 0/0 | 8.8/8.0 | identical |
| V28 visual nosegoe | p08 (nointer) | 05:31:56 | 0 | 8.8 | identical to p08 |
| V29 measure under E8 (whole Inter file left out) | p04 | 05:32:05 | 0 | 78.2 | identical on rank, fund, brief (I ran 3 of the 5 modes) |
| V30-V32 liberation / standin100 / dejavu | p09 | 05:33:23-05:36:03 | 0 | 75.5/84.9/72.1 | identical on rank, fund, brief (3 of 5 modes) |
| V33 p11 build from the +6% template | p11 | 05:37:15 | 0 | 1.4 | the same file apart from timestamps; `segoe-standin` present |
| V34/V35 UI build, variants (8783a2d board 5e9e5a5e) | p13/p14 | 05:37:17/05:37:18 | 0/0 | 1.4/0.3 | the board is byte-identical to the builder's `out/ui-board.html` |
| V36/V37 UI as is / +6% | p15/p16 | 05:37:19/05:38:33 | 0/0 | 74.5/74.5 | identical: 0 J fails, least room 2.86 px |
| V38 p19 +6% under nosegoe | p19 | 05:39:48 | 0 | 27.4 | identical |

The four incomplete runs (V05, V06, V07, V09) failed for reasons outside the board. The machine was loaded by other
agents (load average 28 on 4 CPUs, 2.3 GB free, no swap at 5:01 AM ET). Each was run again in full: V05b, V06b, V07b,
V09b.

Other checks:
- **Base identity** (git hash-object): board fce8a391, audit-import 4aba2506, audit-recon 529e36f7, audit-board
  a7c575e5, audit-other d89396b0, mutate.mjs.txt cbc6defc, layout-fits abfe1386, font-standin fd27b0f1, as stated.
  orbit-board HEAD is now cadc4aa (claude/v200-fixes-wip), and its board is still fce8a39. claude/v200-ui is now dd15956,
  but its board (5e9e5a5) and layout-fits (2ee2103) match 8783a2d's.
- **V10 mcount**, 4:56 AM ET, exit 0: base mutate.mjs.txt (text only) against the base board gives 1328 entries,
  1328 matched once, none missing, multiple or unparsed.
- **Suites vs base:** the builder proposes no commit and has no c1/ (its `diffs/` is empty), so no suite, fixture or
  expected value changed. The final copy is the base, byte for byte, so running the suites on it again would only
  repeat the base.
- **Builder's "verbatim" claims:** checked by text comparison. `probe/build.mjs` holds layout-fits lines 44-58 and
  64-75 verbatim, and `probe/measure.mjs` holds J's `measure()` (lines 296-316) verbatim apart from two spaces of indent.
- **The L2 config:** L2 ran on `probe/fc-nosegoe/` (generated 8:16 PM ET), before `fc-nosegoe.sh` was saved
  (8:37 PM ET). Its files are content-identical to the script's output (`out/fc-check`, and my `out/fcA`), so L2
  evidences the delivered script.
- **No env override:** none of the 14 verify:grid scripts passes `env` to `chromium.launch`, and package.json does not
  either, so FONTCONFIG_FILE reaches every tool.
- **The board's fonts:** the only font stacks are `'Segoe UI',Arial,sans-serif`, the monospace stacks (DejaVu Sans
  Mono both ways) and the flow SVG's `Inter, Segoe UI, ...` (Inter is named, so the bypass does not change it).
  `.row .num` and `.row .amt` have no `overflow` (lines 1123, 1125), so the base cell never clips. The screenshots agree
  (`out/p/base/shots/standin106-brief-940.png`: "$123,456,789" whole).

## Mutants (13 in all; each a plausible wrong version of the change or a regression the method must still catch)

Environment mutants of `fc-nosegoe.sh` (`mut/mkenv.sh`, `out/env/*`) against the builder's pre-check `font-env.mjs`:

| id | what | caught? | run (start ET, exit, wall s) |
|---|---|---|---|
| E1 | alias line not left out | yes, by the script's own guard ("the Segoe UI alias is still there", exit 1) | V11 mkenv 04:59:07 |
| E1b | E1 with that guard removed too | yes, by font-env (Inter-Bold 87.64) | V40 05:40:15, 1, 1.8 |
| E2 | include not redirected (fonts.conf copied), its guard removed: reads /etc/fonts/conf.d | yes (Inter) | V40 05:40:17, 1, 1.5 |
| E3 | 'Segoe UI' sent to DejaVu Sans instead | yes (DejaVu 96.48) | V40 05:40:18, 1, 1.3 |
| E4 | FONTCONFIG_FILE names a missing file (typo) | yes (fontconfig falls back to the container's config: Inter) | V40 05:40:25, 1, 1.4 |
| E5 | image also sends Arial to Inter | yes (both Inter; the family test catches it) | V40 05:40:20, 1, 1.2 |
| E6 | Liberation Sans rejected (no Arial twin) | yes (Arial falls to Liberation Serif 68.75) | V40 05:40:21, 1, 1.1 |
| **E7** | 'Segoe UI' still Inter for weights below bold | **no: font-env exit 0**. My `fontwho.mjs` shows regular 'Segoe UI' text in Inter-Regular (255.47 px vs Liberation 237) | V40 05:40:22, 0, 1.1; V41-fontwho-E7 05:40:29, 0, 1.4 |
| E8 (control) | whole 56-prefer-inter.conf left out | passes, correctly (equivalent for this board) | V40 05:40:23, 0, 1.4 |

Board mutants (`mut/mkboard.py`; each find matched the base once; diffs below) through the base's own
`tools/layout-fits.mjs --board` under the proposed `FONTCONFIG_FILE`:

| id | change (in `@media (max-width:940px)`) | layout-fits under FONTCONFIG_FILE | run (start ET, exit, wall s) |
|---|---|---|---|
| BM1 | Brief money columns 92 to 86 px | caught: FAIL J harbor/parchment brief, 180 widths each | V42 05:40:30, 1, 170.4 |
| BM2 | Rank money column 80 to 74 px | caught: FAIL J harbor/parchment rank, 180 widths | V42 05:43:21, 1, 158.7 |
| BM3 | Fund money columns 80 to 74 px | caught: FAIL J harbor/parchment fund, 180 widths | V42 05:45:59, 1, 145.8 |
| BM4 | Brief title column fixed at 260 px (not a font change) | caught: FAIL J brief, 130 widths ("R001 amt past the row") | V42 05:48:25, 1, 162.1 |
| **BM5** | "hide it": `.row .amt,.row .num{overflow:hidden;text-overflow:ellipsis}` | **not caught: 54 ok, "The layout holds"** | V42 05:51:07, 0, 167.4 |
| BM5 as is | the same, in the container as it is | 6 FAIL, identical to the base, so it is not told apart | V43 05:53:55, 1, 187.4 |
| BM5 at +6% | V44 build (05:57:02, 0, 2.9), V45 variants (05:57:05, 0, 0.2), V46 visual (05:57:05, 0, 7.4), V47 measure (05:57:13, 0, 15.2) | visual.mjs prints "overrun 1.97px; clipped by nothing", identical to the base, while the screenshot `out/m/shots/BM5-standin106-brief-940.png` shows "$123,456,…" (base: "$123,456,789") | |

Mutant diffs against the base (line 1226-1229):
```
BM1 1229: ...minmax(110px,1fr) 100px 92px 92px 92px 92px}  ->  ... 100px 86px 86px 86px 86px}
BM2 1227: ...minmax(110px,1fr) 110px 80px 88px 26px 26px}   ->  ... 110px 74px 88px 26px 26px}
BM3 1228: ...minmax(100px,1fr) 80px 80px 80px 80px 88px ... ->  ... 74px 74px 74px 74px 88px ...
BM4 1229: ...40px minmax(110px,1fr) 100px 92px ...           ->  ...40px 260px 100px 92px ...
BM5 +1227:   .row .amt,.row .num{overflow:hidden;text-overflow:ellipsis}
```

Other robustness runs:
- **V15** (5:03:05 AM ET, exit 1): `fc-nosegoe.sh` on a simulated machine whose conf.d has no 56-prefer-inter.conf
  (`mut/fc-cleanmachine.sh`). It fails closed, but with a false reason: "fc-nosegoe: the Segoe UI alias is still there".

## Findings

**Must-fix 1 (text only; the ledger draft).** Builder README, "Draft: text to append to UNRESOLVED-LEDGER.md row
U28", reads: "verify:grid is to be run here as `FONTCONFIG_FILE=<dir>/fonts.conf npm run verify:grid` after
`rec/L6/u28/fc-nosegoe.sh <dir>` and `probe/font-env.mjs` says OK."
- (a) That records as settled a choice the lead lists as Brad's: `status-tail.md`, "For Brad to decide ... U28:
  whether the final validation's verify:grid runs with the container's font setting bypassed".
- (b) Only layout-fits has ever run under the variable. The builder's notDone says so, and so do my logs. The other 13
  tools are unvalidated, which the builder's own summary asks the lead to check first.
- (c) `probe/font-env.mjs` imports `../../base/tools/chrome.mjs`, which works only in this scratch layout.

Minimal fix: replace that sentence with: "Proposed, not adopted (Brad's decision): run verify:grid here as
FONTCONFIG_FILE=<dir>/fonts.conf, where <dir> holds the container's fontconfig with the one 'Segoe UI' -> Inter alias
line of /etc/fonts/conf.d/56-prefer-inter.conf left out (scratch script rec/L6/u28/fc-nosegoe.sh). Before it is
adopted, the lead runs all 14 tools both ways and compares; so far only layout-fits has run under it (54/54 on
7ee498a)."

**Should-fix 1 (test adequacy of the run method).** Under FONTCONFIG_FILE, layout-fits has no Segoe margin. A change
that clips money cells passes it: BM5 scores 54/54, while at the +6% stand-in Brief shows "$123,456,…". J's rule
(`scrollWidth > clientWidth + 1`) cannot tell a harmless overrun from a clip in any font. Whenever verify:grid runs
under the variable, also run L3 (`layout-fits --board <withStandin(board,106)>`) and record its two known Brief
failures against the open +6% decision. Then a new +6% failure, or a "fix" that clips, cannot pass unseen. Add this
to the ledger draft beside the run method.

**Should-fix 2 (wording).** The summary's "A real browser does not cut the figure" is stronger than the evidence. Real
Segoe UI was never measured, and at the project's own Windows margin (+6%) J fails Brief. Suggested wording: "Not
clipped in any font measured, up to the +6% Segoe stand-in, where Brief's figure overruns its box by 1.97 px into an
empty gap; real Segoe UI was not measured." A second open point, which I did not measure: the stand-in declares only
400 and 700 faces, so `font-weight:750` (`.row .num`) takes the 700 face. Real Segoe UI on Windows also has a Black
(900) face. Under CSS weight matching, 750 picks the heavier face first, so whether Edge draws these figures in Bold or
in Black is not established by anything here.

**Should-fix 3 (pre-check coverage).** `font-env.mjs` tests only weight 750. E7 passes it while regular-weight
'Segoe UI' text is drawn in Inter. Minimal fix: add a 400-weight span to the same test and require both.

**Minor:**
- `fc-nosegoe.sh` on a machine without the Inter file exits 1 with a false reason (V15). Minimal fix: when
  `$D/conf.d/56-prefer-inter.conf` is absent, say so (nothing to leave out) instead of "still there".
- By reading, not run: `fc-nosegoe.sh` does not refuse a non-empty `<dir>`. A pre-existing symlink at
  `<dir>/conf.d/56-prefer-inter.conf` is written through. With `<dir>` = /etc/fonts, the script would truncate
  /etc/fonts/fonts.conf (`sed ... /etc/fonts/fonts.conf > /etc/fonts/fonts.conf`). Minimal fix: refuse unless `<dir>`
  is new or empty and not under /etc.
- `probe/visual.mjs`'s clip test starts at `c.parentElement` and never examines the cell. The base conclusion holds,
  because the base cells have no overflow and the screenshots show the figure whole. As tool output, though, "clipped
  by nothing" is not evidence (BM5).
- H's selTint detail varies between runs (as-is runs 200,207,217; the others 199,206,216, in the builder's runs and
  mine). No check depends on it.

## What I did not do

- I did not run the other 13 verify:grid tools, either way. The track allows only layout-fits (and font-standin when
  relevant), and font-standin is a module, not a tool.
- I did not run p09 and p04 in the review and compare modes: I ran rank, fund and brief, the modes the finding
  concerns. p04's own config (`probe/fc-nointer`) was replaced by my E8, which leaves out the same whole file.
- I did not measure real Segoe UI or a Windows or Mac browser, and I downloaded nothing.
- I wrote no suite block, mutation entry or c1/, because the builder proposes no commit. My mutants are scratch boards
  and configs, never mutate.mjs entries.
- PIDs: every node and Chromium run went through `run.sh`, which recorded its `timeout` and child: 106 lines for 53
  runs, all ended when checked at 5:58 AM ET. Five short commands that started neither node nor Chromium were not
  recorded: the first `fc-nosegoe.sh` into `out/fcA`, V10 mcount, V11 mkenv, V12 mkboard and V15 fc-cleanmachine. Each
  ran under `setsid -w timeout -k 10` and ended in under a second. Nor were the PIDs of the background wrapper shells
  (`drive1.sh`, `chain.sh`) recorded. I killed nothing.

## Files and blobs (git hash-object)

run.sh 8b11b025 · rr.sh 9e1f133f · drive1.sh 089e2b5c · drive2.sh aee34804 · drive3.sh feef8e69 · chain.sh d1aaf793 ·
fc-nosegoe.sh 8a5d382f (copy of the builder's) · mut/mkenv.sh c936e46a · mut/mkboard.py e815b1a5 ·
mut/fc-cleanmachine.sh 6cdb070f · w/probe/fontwho.mjs 61127d55 (mine) · w/probe/{font-env c679f1ba, measure 98a69755,
visual 7e3ad1c1, build 4364ba46, variants 0c0bca71, standin-template f6149f86} (the builder's, unchanged) ·
mut/boards BM1 4337335c, BM2 b1e042a9, BM3 9d933bbb, BM4 7d38625f, BM5 a66b351f · out/tpl/standin106-template
b038b559, standin103-template 27e42a10 · out/ui-board-8783a2d.html 5e9e5a5e. Logs: `logs/` (runs.txt has every run).
