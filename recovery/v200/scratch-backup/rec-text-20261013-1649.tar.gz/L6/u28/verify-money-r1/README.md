# U28 verifier, round 1, lens A (data loss and money)

This directory is `rec/L6/u28/verify-money-r1`. Work began at 12:17 AM ET on 13 Oct 2026, and this README was written at 12:43 AM ET.
I worked read-only on the board, the tools, the builder's files and both repositories. I edited, staged, committed and pushed nothing.
I made no copy of the board in a cumulative (c1) state, because the builder proposes no commit.

## Verdict: sound, with issues

I re-measured the builder's root cause and numbers myself, with my own probes, and they hold:

- `/etc/fonts/conf.d/56-prefer-inter.conf` is owned by no package and is dated 3 Oct at 05:35:22 UTC. That is a minute before `fonts-inter`
  4.0+ds-1 was installed (05:36:26) and seven minutes before Chromium 1194 (05:42:17). It aliases 'Segoe UI' to Inter.
- Chromium (CDP) draws R019's money in Inter-Bold as the container stands, and in Liberation Sans Bold under the builder's `fc-nosegoe` config.
- The figure is 87.64 / 101.66 px in Inter, 76.47 / 88.70 px in Liberation Sans, 78.67 / 91.28 px at the +3% stand-in and 80.97 / 93.97 px at +6%.
  The boxes are 80 and 92 px at 761-940.
- At +6%, J's rule fails Brief only, at 761-940. No money figure on the page is clipped by an ancestor in any of the four fonts.
- In Inter, the last 1.64 px is covered by the "Unfunded" label in Rank and by the allocation input in Fund (v16). The builder said so too.
- layout-fits under `fc-nosegoe` gives 54 ok and 0 FAIL on base fce8a391 (v14).
- `font-env.mjs` exits 1 as the container stands and 0 under `fc-nosegoe` (v10, v11).

The issues are in how far the "a real browser does not cut it" answer reaches, and in how sturdy the procedure is. They are not in the measurements.

### Must fix: a nine-digit figure in the same row that nobody measured

R019's Fund allocation box shows its ask, "$123,456,789", as a placeholder. At 761-940 that text gets 74 px of content (an 88-px column, less 12 px of padding and 2 px of border).

- **Arial leaves 0.59 px.** In Arial's widths the placeholder is 73.41 px (v04). The UI branch's board 5e9e5a5e is the same (v18).
- **No font setting reaches the box.** It is an `<input>` with no `font-family` rule, so it draws in the browser's form-control font. Its computed family here is `Arial`, not the board's stack. So neither the stand-in nor `FONTCONFIG_FILE` changes it (v12).
- **Macs and iPads do not use Arial here.** Windows Chrome and Edge draw form controls in Arial. Mac and iPad browsers draw them in the system font, so the builder's reason ("a Mac or iPad has Arial") does not cover this figure.
- **J cannot see it.** J's input rule reads `scrollWidth`, which ignores placeholder text. I gave that one input a 14.6%-wider font (Inter). The box then shows "$123,456,78" (`out/shots/alloc-900-Inter-placeholder.png`), and J still says it fits: scrollWidth 86, clientWidth 86 (v13).

The ledger's own rule for U28 is P2 if a real browser cuts a money figure. So the "real browser" question is not settled.

**Smallest fix (text only):**
1. Limit "a real browser does not cut it" to the grid cells J measured.
2. Add a "Not covered" line: the allocation box shows the same figure in the browser's form-control font, with 0.59 px to spare in Arial; Mac and iPad use the system font, which was not measured; J cannot see placeholder overflow.
3. Open it as its own row, P2 until measured.

### Should fix

1. **A relative `<dir>` fails silently.** `fc-nosegoe.sh relfc` exits 0 and prints "40 files in conf.d". But the relative `<include>` does not resolve, so fontconfig loads no conf.d at all. 'Segoe UI' and Arial then draw in FreeSerif Bold, where the figure is 76 px, and J would pass in a serif font.
   - `font-env.mjs` does catch it (v15, exit 1).
   - Fix: resolve the directory (`D=$(realpath -m "$1")`) or refuse a relative one. Make the runner refuse verify:grid unless `font-env.mjs` exits 0.
2. **The procedure is checked on 1 of the 14 verify:grid tools.** The ledger draft says "verify:grid is to be run here as ...". It should say that only layout-fits has been run this way, until the lead has run all of verify:grid once each way.
3. **The gate would depend on scratchpad files.** `fc-nosegoe.sh` and `probe/font-env.mjs` live in the session scratchpad, and `font-env.mjs` imports `../../base/tools/chrome.mjs`. Commit self-contained copies under `recovery/v200/evidence/` and cite those paths.
4. **The Windows model only checks Arial's widths for J.** Under this procedure, J measures in Arial's widths, which is what a Mac or iPad shows in the grid cells. Brad's users are on Windows (the font stack, item 57's Windows Edge review, and CLAUDE.md's "the Windows font"). By the project's own +6% Windows margin, J fails Brief.
   - The builder said this plainly, and leaving the decision to Brad is right.
   - The ledger should keep it as an open item, not as a footnote to "P3, container-only".
5. **Windows font weights are not modelled.** `.num` uses weight 750 and `.amt` uses 650. Segoe UI on Windows has Semibold 600, Bold 700 and Black 900, but the stand-in has only 400 and 700. A browser that follows CSS's weight-matching rule for installed families picks the nearest heavier weight for 750, which is Black (Firefox matches this way, I believe). This was not measured; name it under "Not covered".

### Minor

- **The dash cells are not Inter-Bold.** "Inter-Bold for every money cell" is not quite right: the "—" cells (`.amt.z`, weight 500) draw in Inter Medium (CDP).
- **The UI branch head has moved.** It is now dd15956, a docs-only change after 8783a2d. The board blob is still 5e9e5a5e.
- **"Gap" is wrong for Brief's last column.** The NEXT-VERSION draft says Brief's figure "runs 2 px past its column into the empty gap". For the last column (Unfunded) it runs into the row's 10-px right padding. If a NEXT-VERSION entry is added, give it the U13/U1/U14 shape, with a "Not covered" line naming real Segoe UI, Mac/iPad, weight 750 and the allocation box.
- **The +6% fix needs 93 px for J, 94 px to stay inside the box.** At +6% the figure is 93.97 px, so J's 1-px rule already passes at 93 px. Fitting inside the box needs 94 px, with 0.03 px to spare.

## Decision principles, checked against what the builder delivered (no commit)

1. **Never lose work:** nothing changes on the board. `fc-nosegoe.sh` writes only to `<dir>`. Pointed at its own source (simulated on a copy of /etc/fonts, `sim/`), `ln` refuses with "same file" and `set -e` stops before anything is overwritten.
2. **Refuse or ask rather than guess:** this is where the builder falls short. "A real browser does not cut the figure" is stated as fact, while real Segoe UI, Mac/iPad and the allocation box were never measured (must-fix).
3. **Money and exports match the computation:** no export or figure changes. The display risk is the allocation box (must-fix).
4. **Every word stays true:** the measurements are true. The scope of the summary sentence and the success line of `fc-nosegoe.sh` with a relative directory are not (must-fix, should-fix 1).
5. **Smallest change:** met. There is no board or tool change.
6. **Checks preserved:** met. No check, fixture or expected value is edited. The procedure only restores the font the tools were written for.

## Runs

Each run below was bounded with `setsid -w timeout -k 10 600` through `run.sh`. The lock was checked before every run and was never present.
`logs/runs.txt` lists them all; logs are in `logs/`.

| label | start (ET, 13 Oct) | exit | wall s | result |
|---|---|---|---|---|
| v01-build-base | 00:25:42 | 0 | 2.1 | populated base board (layout-fits lines 44-58, 64-75 copied by sed) |
| v02-variants-base | 00:25:44 | 0 | 0.3 | the board as is, and at the +3% and +6% stand-in (base `withStandin`) |
| v03-money-base-asis | 00:25:53 | 0 | 17.9 | first pass of the money probe; superseded by v06 because of a room-calculation bug |
| v04-alloc-base-asis | 00:27:59 | 0 | 6.0 | allocation box: 73.41 px in 74, room 0.59; drawn in UA `Arial` / Liberation Sans Bold |
| v05-money-base-nosegoe | 00:29:13 | 0 | 22.6 | superseded by v07 (same bug) |
| v06-money-base-asis-r | 00:29:52 | 0 | 23.0 | Inter-Bold; least room -7.64 (Rank, Fund) and -9.66 (Brief); 0 clipped; 0 page money cut |
| v07-money-base-nosegoe-r | 00:30:15 | 0 | 24.0 | Liberation Sans Bold; least room 3.53 and 3.30; J rule fails 0 |
| v08-money-base-standin106 | 00:30:45 | 0 | 25.9 | stand-in ok; least room -0.97 and -1.97; J fails Brief at 761-940 only; 0 clipped |
| v09-money-base-standin103 | 00:31:11 | 0 | 22.5 | stand-in ok; least room 1.33 and 0.72; J fails 0 |
| v10-fontenv-default | 00:31:42 | 1 | 2.8 | builder's pre-check: Inter-Bold, 87.64 px, "NOT Arial's widths" (expected) |
| v11-fontenv-nosegoe | 00:31:45 | 0 | 3.2 | builder's pre-check under my `fc/fonts.conf`: Liberation Sans, 76.47 px, OK |
| v12-alloc-base-standin106 | 00:31:48 | 0 | 6.9 | allocation box is the same under the stand-in (73.41 in 74) |
| v13-alloc-blind-base | 00:32:20 | 0 | 6.0 | J's input rule says "fits" for a placeholder cut by 10.13 px (Inter) and 18.63 px (DejaVu) |
| v14-layoutfits-base-nosegoe | 00:33:32 | 0 | 226.8 | layout-fits, base copy (fce8a391), `FONTCONFIG_FILE=fc/fonts.conf`: 54 ok, 0 FAIL |
| v15-fontenv-relative-dir | 00:38:04 | 1 | 3.4 | relative-directory config: FreeSerif Bold, caught by the pre-check |
| v16-cover-base-asis | 00:38:45 | 0 | 5.8 | Inter at 761: Rank overlaps the "Unfunded" label; Fund's figure is under the INPUT |
| v17-build-ui | 00:41:17 | 0 | 4.0 | populated UI-branch board (5e9e5a5e) |
| v18-alloc-ui-asis | 00:41:21 | 0 | 6.2 | UI branch: the same 0.59 px room where the box is shown |

The money probe's "covered" counts (v03-v09) are not valid: R019 was off screen, and `elementFromPoint` returns null there. v16 scrolls the row into view and is the valid cover test. The "clipped" and "page money cut" results come from rectangles and do not depend on scrolling.

Other bounded commands, all foreground with `setsid -w timeout`, whose PIDs were not captured:

- `fc-nosegoe.sh` into `fc/`, `sim/relfc` and `sim/etc-fonts` (a copy, using a sed-renamed copy of the script);
- `fc-match` lookups;
- `curl` for the Selawik README text (nothing saved) and HEAD-style probes of font paths (all 404, saved to /dev/null);
- `npm view` for Selawik packages (all 404).

No font or file was downloaded.

## PIDs

`pids.txt` has 36 lines: each run's `timeout` and its child, with the command. All had ended when I checked at 12:41 AM ET. Nothing was killed.

The builder's `pids.txt` has 54 lines. One of its numbers (20370) is in use again by an unrelated process that started at 04:35 UTC on 13 Oct (a regtext run). The number was reused; that process is not the builder's.

## Files (git hash-object)

| file | blob | what it is |
|---|---|---|
| run.sh | 76fad337 | runner, bounded and lock-checked |
| probe/build.mjs | 683157db | populated board |
| probe/variants.mjs | 81120c3c | the board as is, +3% and +6% |
| probe/money.mjs | cf474b8f | every money cell: room, J rule, clip, page-wide cut figures, CDP font |
| probe/alloc.mjs | fe4f1fbf | the allocation box |
| probe/alloc-blind.mjs | 4297c9ca | J's blind spot on placeholders |
| probe/cover.mjs | 8307c61e | what covers the overrun in Inter |
| fc/fonts.conf | d05f2c5b | made by the builder's `fc-nosegoe.sh` |
| fc/conf.d/56-prefer-inter.conf | 5b097855 | the same file without the 'Segoe UI' line |

Outputs: `out/base/*.html` (asis 30a4f273, standin103 57b9bf2b, standin106 ae333ffb), `out/ui/asis.html` (b5fd3c2a), the `m-*.json` files, and `out/shots/`.

Inputs I confirmed:

- base board fce8a391;
- layout-fits abfe1386 (the same as the builder's);
- font-standin fd27b0f1;
- UI branch dd15956, with board 5e9e5a5e, layout-fits 2ee21034 and font-standin fd27b0f1;
- the builder's file blobs, which match its README table.

## What I did not do

- Measure real Segoe UI, SF Pro (the Mac/iPad system font), or any Windows or Mac browser. Selawik (Microsoft's open-source replacement for Segoe UI) could not be found through the proxy or npm.
- Run any verify:grid tool except layout-fits, or run audit-import, audit-board, mutate.mjs or `playwright install`.
- Make any copy, diff, suite block or mutation. There is no commit to verify.
- Run layout-fits as the container stands, or with the stand-in (the builder's L1 and L3). Those results are confirmed by my v06 and v08 probes at 13 sampled widths, not by a full re-run.

## Continuation (after the usage-limit pause)

Resumed at 4:51 AM ET on 13 Oct 2026. I ran no new node or Chromium run. I re-checked by reading only:

- the base blobs are unchanged (board fce8a391, layout-fits abfe1386, font-standin fd27b0f1);
- the builder's files are unchanged (fc-nosegoe.sh 8a5d382f, font-env.mjs c679f1ba, README a14a416f), and so are my probes and `fc/fonts.conf` (blobs as above);
- `/etc/fonts/conf.d/56-prefer-inter.conf` is unchanged, and `claude/v200-ui` is still dd15956;
- the allocation box markup (base line 25625, `placeholder="${fM(askTot(it))}"`) and its CSS (lines 554 and 1138, with no font-family).

The verdict and findings above stand. Nothing was killed, edited, staged, committed or pushed.
