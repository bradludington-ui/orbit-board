# U28 verify -- money lens (A), round 2

Independent adversarial verifier, round 2, lens A (data loss and money), for the U28 builder's fix round
(`rec/L6/u28`, README last written 9:31 AM ET on 13 Oct; result `wfstate/fix_u28_r1.json`). Work only in this
directory; read-only on the builder's files, /home/user/orbit-board and /home/user/orbit-ui. Nothing was staged,
committed or pushed anywhere.

Times are Eastern. This attempt resumed at 1:33 PM ET on 13 Oct (an earlier attempt of this same review ran 10:36-10:42 AM
ET and was stopped by the lead). README last written at 2:31 PM ET on 13 Oct; see "Runs" for every start time.

## Verdict: UNSOUND as a record -- one must-fix (money), with a verified one-rule fix

The builder's answer says a real browser does not cut the nine-digit figure in the grid cells, and its NEXT-VERSION
draft tells users "nothing changes ... In the fonts measured the figure is whole in every grid cell". That is false on
the board under review (7ee498a, board fce8a391). A user who picks **Setup > Appearance > Density: Presentation** (a
menu item, `uiSetDensity`, board lines 26189 and 3788) and works in **Rank** or **Fund** at a 761-940 px window sees
R019's "$123,456,789" run 8.7 px past its 80-px column, **2.7 px under the next cell**, in Arial's own widths -- no Inter,
no stand-in. In Rank the last "9" runs under the lane meter and "Unfunded" label; in Fund the Unfunded figure's last
"9" runs under the allocation box (`elementFromPoint` 0.5 px inside the text's right end returns the INPUT). Screenshots:
`out/shots2/arial-harbor-fund-presentation-761.png`, `...-rank-presentation-761.png`, `...-900.png`, and parchment.

Why nobody saw it: layout-fits section J opens each mode at the browser's default density only (its init script sets
`spmtTheme` and `spmtMode`, never `spmtDensity`; base tools/layout-fits.mjs lines 317-319). Brief is always
Presentation (`uiDensityNow`, board line 3776), so J measures 14.5-px figures in Brief's 92-px columns, but never in
Rank's and Fund's 80-px ones. The board's own comment (lines 1221-1224) says each 761-940 column "is sized to ... a
nine-digit figure (76.5px at the row's money size, 88.7 in Brief's)": Rank and Fund were sized for 76.5 px only.

This is a genuine layout defect a real browser shows (deliverable (b)), not container-only. It is not caused by the
container's Inter alias and is independent of the builder's six J failures, which stay container-only as the builder
says. The builder's gate method (54/54 under the setting) and its +6% pass both report "fits" while the figure is cut,
because neither opens the Presentation density in Rank or Fund.

## Measurements (all under the builder's own gate: `ev/fc-gate.sh out/fc -- ...`, font-env OK at every weight)

`probe/density.mjs` opens the populated board exactly as layout-fits does (`probe/build.mjs` = layout-fits lines 44-77
verbatim), sets `spmtTheme`, `spmtMode` and `spmtDensity`, steps the window one pixel at a time and runs J's own
`measure()` (layout-fits lines 296-316, identical modulo indent: checked with diff), plus per-cell text ranges for R019.

| board / font | mode @ density | J fails (widths) | R019 figure | room in cell | runs into next cell |
|---|---|---|---|---|---|
| base fce8a391, Arial widths | Rank @ Presentation, harbor and parchment | 180 (761-940) | 88.70 px at 14.5 px | -8.7 px | 2.7 px, under the lane cell ("ll unf") |
| base, Arial widths | Fund @ Presentation, harbor and parchment | 180 (761-940) | 88.70 px (Ask and Unfunded) | -8.7 px | 2.7 px; Unfunded under the allocation INPUT |
| base, Arial widths | Review, Compare @ Presentation, both themes | 0 | fits | -- | -- |
| base, +6% stand-in | Rank @ Presentation, 1100-761 | 180 (761-940) | 93.97 px | -13.97 px | 7.97 px under the lane cell |
| base, +6% stand-in | Fund @ Presentation, 1100-761 | 340 (all) | 93.97 px | -13.97 at 761-940; -3.97 at 941-1100 | 7.97 px under the allocation box at 761-940 |
| base, +6% | Review, Compare @ Presentation | 0 | -- | -- | -- |
| **c1** (fix), Arial widths | Rank, Fund @ Presentation, both themes | **0** | 76.47 px at 12.5 px (761-940) | fits | none |
| **c1**, +6% stand-in | Rank @ Presentation, 1100-761 | **0** | 80.97 px | -0.97 (as Comfortable today; J's 1-px rule) | none |
| **c1**, +6% stand-in | Fund @ Presentation, 1100-761 | 160 (941-1100 only) | 93.97 px in 90-px columns | -3.97 | none (8-px gap) |
| claude/v200-ui 7df816c (board fb3ccbbd), Arial widths | Rank, Fund @ Presentation, harbor | 0 | Rank 14.5 px in its own 92-px list; Fund 11.5 px | -- | -- |

Compact (12 px) is smaller than Comfortable (12.5 px) in the same columns, so it cannot be cut where Comfortable is
whole; it was not re-run in this attempt (the stopped attempt's r04 showed 0 in harbor but has no exit record).

## The minimal fix (c1/ = base + this; diffs/c1-board.diff)

```css
  /* v2.00 (U28): Rank's and Fund's 80px money columns hold a nine-digit figure at the row's money size, not at the
     Presentation density's 14.5px (88.7px): it ran under the lane meter and the allocation box. Here those two modes
     keep the row's money size; Brief's columns are sized for the larger one. */
  :root[data-density="presentation"][data-mode="rank"],:root[data-density="presentation"][data-mode="fund"]{--num:12.5px}
```

inside the existing `@media (max-width:940px){...}` block (after board line 1229). Specificity (0,3,0) beats
`html[data-density="presentation"]` (0,1,1). `--num` sizes only `.row .num`, `.row .amt` and `.row .rank b` (lines
1100, 1123, 1125). Board blob 41c3840b. Widening the columns instead does not fit Fund at 761 px (four money columns
+48 px against a 100-px title minimum); that is a design choice for Brad.

The check that would have caught it (c1/tools/layout-fits.mjs, blob 15b1f34c; `diffs/c1-layout-fits.diff`): J's loop
also opens Rank and Fund at the Presentation density, as four new checks named
`J · <theme> rank|fund at the presentation density: every width 761-1023 fits`. The ten existing J check names are
unchanged.

Evidence for c1:
- r09: the J measure at Presentation, Rank and Fund, both themes, 263 widths each: 0 fails (base r05a/r05b: 180 each).
- r11: unchanged layout-fits on c1 through the gate: 54 ok, 0 FAIL, the same 54 names as the builder's f22 on base;
  only H's `selTint` detail differs (a known run-to-run variation).
- r12: unchanged layout-fits on c1 with the +6% stand-in through the gate: 52 ok, the same two FAILs (J harbor brief,
  J parchment brief, 180 widths) as the builder's f24, identical lines except H's `selTint`.
- r16, r16c: the extended layout-fits on the BASE board: `FAIL J · harbor rank at the presentation density` and
  `FAIL J · harbor fund at the presentation density` (180 widths each), then the run was killed by the machine's
  memory cgroup (dmesg: oom-kill of chrome) in the parchment half. See "Runs".
- **r20 (base) and r21b (c1): the four new checks alone** (`c1/tools/focused-Jpres.mjs`, blob 66c9ee32: layout-fits
  lines 1-93 and c1's J loop verbatim, the pair list cut to the two new pairs, the drawer and phone sub-checks left
  out). Base: `FAIL` x4 (harbor/parchment x rank/fund at the presentation density, 180 widths each, "4 layout
  check(s) failed", exit 1). c1: `ok` x4 (263 widths each), "The layout holds", exit 0. r21 (c1, first try) passed 3
  and was OOM-killed on the fourth; r21b re-ran it whole.
- r19 (c1, the full focused J): the four existing harbor checks ok, then OOM-killed; not relied on.
- The other 13 verify:grid tools: not run. None of them sets `spmtDensity` (grep: only layout-fits names density),
  so the new selector can only match in Rank or Fund at the Presentation density, which none of them opens.
- Merge with claude/v200-ui: `git merge-file` of c1's board and the UI head's board (7df816c, fb3ccbbd) over their
  merge base 4a6f7c7 (board 4d273c06): 0 conflicts, and the merged board differs from the merge without the fix by
  exactly the four added lines (out/merge/merged-base.html 097b76d8, merged-c1.html 4b05397d). The UI branch already
  holds the figure in its own 761-940 lists (r15b), so on that branch the rule is redundant but harmless (it sets
  Rank's money to 12.5 px in its 92-px column when the window is 940 px or less).

## What the drafts must say instead (for the lead)

- Draft 1 / 3 / 4: J's six failures stay "this container only, P3". Add: **a real browser does cut the figure at the
  Presentation density**: Rank and Fund, 761-940 px, both themes, in Arial's widths (8.7 px past an 80-px column, 2.7 px
  under the lane cell or the allocation box), worse in a Segoe-like font (7.97 px under at +6%). J never opened that
  density. Either the fix above ships (with the four J checks), or v2.00 relies on claude/v200-ui's own 761-940 lists
  (they hold it: r15b) and the four J checks go onto that branch.
- Draft 3 "What users may see": not "nothing changes". With the fix: "At the Presentation density, in Rank and Fund,
  a window 761-940 px wide draws the row's money at the Comfortable size (12.5 px), so a nine-digit figure is whole;
  wider windows and Brief are unchanged." Test: "layout-fits J opens Rank and Fund at the Presentation density too
  (four checks; they fail on 7ee498a at 180 widths each)." Not covered: Fund at the Presentation density at 941-1100 px
  in a Segoe-like font (93.97 px in 90-px columns at +6%; into the gap, nothing covers it).

## Should-fix

- `evidence-u28/standin-template.mjs` writes its output over any existing file, including its own input, without
  asking. r13: run with the same path as input and output on a copy of the board template, it replaced fce8a391 with
  b038b559 (the stand-in inside the template); r13b, a second run, put a second stand-in in. The drafts tell the lead to
  run it before layout-fits; one slip (`... prioritization-board-grid.html prioritization-board-grid.html`) writes a
  fake 'Segoe UI' face into the board that ships. Fix: `writeFileSync(OUT, ..., { flag: 'wx' })` and refuse when
  `resolve(OUT) === resolve(IN)`.
- Draft 1's +6% pass: "Today that run fails exactly J harbor brief and J parchment brief ... any other failure is new"
  says nothing about FEWER failures. layout-fits never calls `standinProblem()`, so a template where the stand-in did
  not apply (e.g. a non-numeric scale: the script writes "+NaN%" and the face is drawn at 100%) passes 54/54 and reads
  as good news. Say that the pass is valid only with exactly those two failures (or have the template script check the
  scale is a number).
- Once J opens Rank and Fund at the Presentation density, the +6% pass gains a known failure: Fund at 941-1023 px
  (93.97 px in 90-px columns; it runs into the 8-px gap, nothing covers it), the same class as Brief's. Draft 1's
  "Open for Brad (2)" should list it with Brief's.

## Minor

- Draft 1 cites the UI branch head as dd15956 (board 5e9e5a5e). It moved to 7df816c (board fb3ccbbd) at 12:13 PM ET on
  13 Oct, after the builder wrote it; the lead should cite the head current when committing.
- Draft 1: "Under the setting alone, J measures Arial's widths only, which is what a Mac or iPad shows in these
  cells" -- true only at the default density; a Mac or iPad at the Presentation density shows the cut above.

## Decision principles, for the fix proposed here

1. Never lose a copy: CSS only; no data, save or export path is touched.
2. Refuse or ask rather than guess: the money size is not guessed; it is the size the columns were already sized for
   (the board's own comment). Wider columns are left to Brad.
3. Money matches: the figure is the same string; it is now drawn whole.
4. Every word stays true: the board's comment "each column is sized to what it holds" becomes true for Presentation.
   The drafts must drop "whole in every grid cell" (see must-fix).
5. Smallest change: one rule in an existing media block; one loop extension in J.
6. Existing checks preserved: the 54 existing layout-fits check names are unchanged (r11); four checks are added. No
   expected value is edited.

## Runs (each through run.sh: `setsid -w timeout -k 10 600`, lock checked first -- never present)

| label | start (ET, 13 Oct) | exit | wall s | result |
|---|---|---|---|---|
| r01-build-populated (stopped attempt, reused: same blobs) | 10:36:21 AM | 0 | 7.1 | out/populated.html ab926530 |
| r02-fcnosegoe (stopped attempt, reused) | 10:36:29 AM | 0 | 0.5 | out/fc, 40 files |
| r03 (stopped attempt; earlier density.mjs, not relied on) | 10:36:53 AM | 0 | 46.7 | superseded by r05a |
| r04 (stopped attempt; no exit record) | 10:38:00 AM | -- | -- | not relied on |
| r05a-gate-harbor-rankfund-pres | 1:37:22 PM | 0 | 41.0 | Rank, Fund @ Presentation: 180 fails each |
| r05b-gate-parchment-rankfund-pres | 1:38:23 PM | 0 | 38.9 | same in parchment |
| r05c-gate-both-reviewcompare-pres | 1:39:08 PM | 0 | 67.1 | Review, Compare @ Presentation: 0 |
| r06a / r06b standin templates of the populated base | 1:40:32 / 1:40:33 PM | 0 / 0 | 0.6 / 0.4 | +6% / +3% copies |
| r07-gate-s106-harbor-pres-1100 | 1:40:41 PM | 0 | 115.6 | +6%: Rank 180, Fund 340, Review/Compare 0 |
| r08 / r08b build populated c1 / its +6% copy | 1:43:53 / 1:44:01 PM | 0 / 0 | 8.3 / 0.5 | |
| r09-gate-c1-both-rankfund-pres | 1:44:08 PM | 0 | 116.7 | c1: 0 fails, both themes |
| r10-gate-c1-s106-harbor-rankfund-pres-1100 | 1:46:16 PM | 0 | 72.3 | c1 +6%: Rank 0; Fund 160 (941-1100 only) |
| r11-gate-layoutfits-c1 | 1:47:44 PM | 0 | 373.5 | 54 ok, same names as f22 |
| r12a / r12 layout-fits c1 at +6% | 1:54:14 / 1:54:15 PM | 0 / 1 | 0.6 / 378.2 | 52 ok + the two known Brief FAILs (= f24) |
| r13 / r13b standin-template, out = in | 2:00:50 / 2:00:51 PM | 0 / 0 | 0.6 / 1.1 | input overwritten; second stand-in stacked |
| r14 build populated UI 7df816c | 2:01:35 PM | 0 | 13.5 | |
| r15 UI probe (run outside a repo root) | 2:01:49 PM | 3 | 4.3 | gate REFUSED, correctly; re-run as r15b |
| r15b-gate-ui-harbor-rankfund-pres | 2:02:02 PM | 0 | 65.1 | UI branch: 0 fails |
| r16 / r16b / r16c extended layout-fits on base | 2:04:20 / 2:09:15 / 2:11:07 PM | 1 / 1 / 1 | 281.4 / 90.7 / 305.6 | harbor's two new checks FAIL, then OOM-killed |
| r18 / r18b focused J on base | 2:16:41 / 2:19:00 PM | 1 / 1 | 92.6 / 81.7 | OOM-killed after 1 check |
| r19 focused J on c1 | 2:21:38 PM | 1 | 103.3 | 4 checks ok, then OOM-killed |
| r20-gate-Jpres-on-base | 2:23:51 PM | 1 | 91.5 | the 4 new checks FAIL (180 widths each) |
| r21 / r21b the 4 new checks on c1 | 2:25:28 / 2:27:39 PM | 1 / 0 | 124.4 / 149.5 | r21 OOM-killed on the 4th; r21b: 4 ok |

Expected non-zero exits: r12 (the two known +6% Brief failures), r15 (the gate refusing a run outside a repository
root), r20 (the base fails the new checks). r16-r16c, r18, r18b, r19, r21 were Chromium or node processes killed by the
container's memory cgroup under the shared machine's load (dmesg "Memory cgroup out of memory: Killed process ...
(chrome)"), not results of the change; each one's finished checks agree with r20/r21b.
/etc/fonts/fonts.conf and 56-prefer-inter.conf md5 unchanged (9632eb1c..., c73e41c1...) at 2:30 PM ET.

## PIDs

pids.txt: each run's `timeout` and its child, with the command. None was running at the end of this attempt; nothing
was killed by me.

## Files (git hash-object)

| file | blob |
|---|---|
| probe/build.mjs | b88bc37d |
| probe/density.mjs | 75ee31ef |
| run.sh | dd507103 |
| ev/* (copies of the builder's evidence-u28, identical blobs) | fc-gate b6c79d01, fc-nosegoe 3c63a124, font-env e51716dd, standin-template f7723d3f |
| out/populated.html (base, r01) | ab926530 |
| out/populated-c1.html (r08) | 3c59da9e |
| out/populated-s106.html / -c1-s106.html | 81b56afe / c88b2394 |
| out/populated-ui.html (UI 7df816c, r14) | faaeba4d |
| c1/prioritization-board-grid.html | 41c3840b |
| c1/tools/layout-fits.mjs | 15b1f34c |
| c1/tools/focused-J.mjs (layout-fits lines 1-93 + J block + tail, verbatim) | 09ed7236 |
| c1/tools/focused-Jpres.mjs (focused-J cut to the four new checks) | 66c9ee32 |
| diffs/c1-board.diff, diffs/c1-layout-fits.diff | the proposed commit |
| out/fc/fonts.conf (r02) | 3904c9b0 |

## What I did not do

- No full audit-import or audit-board; no mutate.mjs run (there is no CSS mutation surface in mutate.mjs: it drives
  jsdom suites, which have no layout; "base = fix removed" is the mutant, and it fails the new J checks).
- The other 13 verify:grid tools were not run on c1 (reason above).
- Real Segoe UI / Edge / Safari not measured.
- No NEXT-VERSION / ledger text was committed; drafts for the lead are in the structured result.
