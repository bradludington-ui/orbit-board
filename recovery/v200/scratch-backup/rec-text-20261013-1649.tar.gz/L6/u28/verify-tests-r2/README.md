# U28 verifier, round 2, lens B (test adequacy and regressions)

Directory: `rec/L6/u28/verify-tests-r2` (paths below are relative to it unless they say otherwise; `U` = `rec/L6/u28`,
the builder's directory; `B` = `rec/L6/base`, read-only). This review covers the builder's fix round
(`U/wfstate/fix_u28_r1.json`, `U/README.md` "Fix round", last written 9:31 AM ET on 13 Oct).

**Resuming.** An earlier attempt of this review ran from 10:33 to 10:46 AM ET on 13 Oct (runs g01-g42 in
`logs/runs.txt`). Every one of its runs finished with an exit record. The files it ran (the builder's `evidence-u28/*`,
`probe/visual.mjs`, `probe/alloc-standin.mjs`, the base board fce8a391, layout-fits abfe1386) have the same blobs now, so
I reused those runs. Its prepared but unrun mutants (`mut/scripts/SM1-SM10`, `mut/boards/VM1-VM3`, `env/E9`, `env/E10`)
were run in this attempt. This attempt began at 1:33 PM ET on 13 Oct. Its last run ended at 2:03:07 PM ET. The lock
`AUDIT_IMPORT_RUNNING` was absent before every run. None of my recorded processes was still running at 2:03 PM ET.
Three recorded PID numbers had since been reused by other agents' processes, each with a different command and start
time. I killed nothing.

Read-only throughout. I edited, staged, committed and pushed nothing in /home/user/orbit-board or /home/user/orbit-ui,
and never touched the builder's files. I never imported or ran `mutate.mjs` and never ran `playwright install`. I did
not run the full audit-import or audit-board. /etc/fonts/fonts.conf and 56-prefer-inter.conf have the same md5 as
before the first run (`fr/etc-before.md5`).

## Verdict: sound, with issues (one must-fix)

The builder proposes no board, tool or suite change. So there is no c1 copy, suite block or mutation entry to test.
The things under test are the run method and its scripts (`fc-nosegoe.sh`, `fc-gate.sh`, `font-env.mjs`,
`standin-template.mjs`), the corrected probe `visual.mjs`, and the drafts' claims about what they catch.

- **Every builder run reproduces.** I re-ran f01-f34 and f36 as g01-g36 (f35 ran from the builder's scratch clone).
  Each log is identical to the builder's, once paths and timings are normalised. The one exception is H's `selTint`
  detail in g22 and g24, which varies from run to run (a known minor; no check reads it). The +6% template is
  byte-identical (md5 75089e04...).
- **Must-fix (the gate's coverage, and the drafts' words about it):** `font-env.mjs` checks weights 400-750 only, but the
  board draws text at 800 and 900 too. On the populated board, counted once per mode over the five modes, 307 visible
  text elements are at 800 and 5 at 900. They include money: the posture strip's figures (`.pplanes .n`
  "$19,920,000 BA", `.pp .v` "$240,051,789") and the inspector's big figure (`.insp-f.big .fv` "$6,682,500"). Environment mutant E11 sends 'Segoe UI' to Inter at weight 800 and above only. The delivered
  gate passes it and runs layout-fits, which says "The layout holds" (k01). Yet the board's weight-800 money is drawn in
  Inter ExtraBold, 11-14% wider than in Arial (h23: 97.17 px against 85.09). That is the U28 failure itself, at the
  board's main heavy weight. Draft 1 says the gate "refuses unless font-env.mjs finds Arial's widths at every weight
  the board draws", and font-env prints "OK ... at every weight it uses". Both are false on today's board.
- **Should-fix:** (1) The +6% pass records known failures only by name and width count. Mutant VM4 (Brief's money
  columns at 761-940 cut from 92 to 88 px) passes the Arial pass 54/54, and at +6% its FAIL lines are byte-identical to
  the base's. Yet Brief's figure now runs 5.97 px past its box (base: 1.97 px). (2) `font-env.mjs`'s expected width is
  observed, not a literal: Arial's width on the same machine. In E9 (no Liberation Sans Bold), every bold line draws in
  synthetic-bold Liberation Sans Regular. Words there are 236.23 px against real Arial Bold's 251.45 (6% narrower), and
  the gate still says OK. (3) Two script mutants (SM5, SM7) survive every scenario the builder recorded.
- **Not caught, as the builder already says:** VM1 (money cells clip with an ellipsis) and VM2 (the allocation box's text
  at 13 px, which cuts the placeholder by 5.53 px in Arial). The drafts disclose both. VM3 (Rank's money column 80->79
  px) is caught by the +6% pass, with new FAILs for J rank in both themes.

## 1. Re-runs of the builder's fix-round runs (earlier attempt, reused: same blobs)

| mine | builder | start (ET, 13 Oct) | exit | wall s | compared with the builder's log |
|---|---|---|---|---|---|
| g01-g07 fc-nosegoe (abs, relative, non-empty, symlink, /etc, /etc sub, clean machine) | f01-f07 | 10:33:20-10:33:25 | 0,0,2,2,2,2,3 | 0.0-4.3 | identical |
| g10-g12 font-env as is / fc / fcrel | f10-f12 | 10:33:45-10:33:52 | 1,0,0 | 3.2-3.6 | identical |
| g13 r0 font-env on E7, g14 new on E7 | f13, f14 | 10:33:55, 10:33:58 | 0, 1 | 2.2, 2.1 | identical |
| g15 E1b, E2, E3, E5, E6, E8, E4 | f15 | 10:34:00-10:34:15 | 1,1,1,1,1,0,1 | 2.2-2.7 | identical |
| g20, g21, g21b gate | f20, f21, f21b | 10:34:17-10:34:20 | 3, 3, 0 | 2.9, 0.1, 2.8 | identical |
| g22 gate + layout-fits base | f22 | 10:34:55 | 0 | 277.2 | 54 ok; only H's selTint detail differs |
| g23 +6% template | f23 | 10:39:32 | 0 | 0.6 | byte-identical template |
| g24 gate + layout-fits +6% | f24 | 10:39:33 | 1 | 336.5 | the same 2 FAIL lines; only selTint differs |
| g27-g31 visual (base as is, +6%, no Inter, BM5 new, BM5 r0) | f27-f31 | 10:45:09-10:45:55 | 0 each | 10.5-12.1 | identical |
| g32-g34 allocation box (+3%, +6%, as is under fc) | f32-f34 | 10:46:07-10:46:26 | 0 each | 9.7-10.7 | identical |
| g36 font-env outside a repository root | f36 | 10:34:23 | 2 | 1.5 | identical |
| g40 mcount, base mutate.mjs.txt (text) vs base board | -- | 10:35:24 | 0 | 4.1 | 1328 entries, 1328 once, none missing or multiple |

## 2. Literal, base-fail and suite audit

- **No suite, fixture or expectation changed.** The builder's `diffs/` is empty and there is no c1. The base blobs are as
  stated: board fce8a391, audit-import 4aba2506, mutate.mjs.txt cbc6defc, layout-fits abfe1386, font-standin fd27b0f1,
  chrome.mjs d0fbdb8a. With no new mutation entries, mcount (g40) on the base is the whole mcount: 1328/1328 once.
  There is no final copy apart from the base, so no suite has a final-vs-base comparison to make.
- **New checks fail on the base, as they should.** The gate's check (font-env) exits 1 on the container as it is
  (g10). The +6% pass fails with its two known FAILs (g24).
- **Expected values.** The +6% pass's expectation is a hand-written list: J harbor brief and J parchment brief, 180
  widths each. But it holds names and counts only, not the overrun (should-fix 1). font-env's expected width is
  **observed**: `Math.abs(sw - aw) < 0.01`, where `aw` is the same machine's Arial span. That breaks the rule that
  expected values are hand-written literals, and E9 shows the result (should-fix 2).

## 3. My mutants (each a plausible wrong change), and whether the delivered checks catch them

### 3a. Script mutants against the builder's own scenarios (diffs: `mut/scripts/*/` vs `ev/`)

| id | the wrong change | run (ET) | result | caught by a builder scenario? |
|---|---|---|---|---|
| SM1 | fc-gate.sh prints REFUSED but runs anyway (`exit 3` dropped) | h10 13:40:57 | exit 0, "RAN" on E7 | **yes**, f20 expects 3 |
| SM2 | fc-gate.sh execs the command without FONTCONFIG_FILE | h11 13:41:03 | "RAN ... under undefined" | **yes**, f21b's printed setting (and f22 would give 48/54) |
| SM3 | fc-gate.sh runs font-env without the setting | h12 13:41:11 | exit 3 on the right config | **yes**, f21b expects 0 |
| SM4 | font-env checks 750 only (the r0 blind spot) | h13 13:41:16 | exit 0 on E7 | **yes**, f14 expects 1 |
| SM5 | font-env checks 400 and 750 only | h14 13:41:23-13:41:59 | exit 1 on E7, E1b, E2, E3, E4, E5, E6 (same as the delivered) | **no**; only my E10 (Inter at 600-699) tells it apart: h14b exit 0 vs h02 exit 1 |
| SM6 | font-env compares widths only, not fonts | h15 13:42:11 | exit 0 on E5 (both Inter) | **yes**, f15-E5 expects 1 |
| SM7 | font-env's family test loosened to `/^(Liberation\|Arial)/` | h16 13:42:23 | exit 1 on E6 (same as the delivered) | **no**; only my E14 (Arial bound to Liberation Serif) tells it apart: h21 exit 0 vs h20 exit 1 |
| SM8 | font-env skips the family test on the Arial line | h17 13:42:30-36 | exit 1 on E5, E6 | equivalent here (no second metric twin of Arial is installed) |
| SM9 | fc-nosegoe.sh without `realpath` | h18/h18b 13:42:41 | relative include; font-env exit 1 (FreeSerif) | **yes**, f12 expects 0 (not run against /etc paths, deliberately) |
| SM10 | standin-template.mjs defaults to +0% | h19 13:42:48 | template md5 647d78d5... | **yes**, f23's byte comparison (and f24 would give 54/54) |

### 3b. Environment mutants against the delivered font-env / gate (`mut/mkenv*.sh`; nothing in /etc written)

| id | the setting | run (ET) | delivered font-env | what Chromium actually draws |
|---|---|---|---|---|
| E9 | fc-nosegoe output + Liberation Sans Bold rejected | h01 13:40:04 | **exit 0, "OK"** | every bold line in LiberationSans (Regular, synthetic bold): words 236.23 px vs Arial Bold 251.45 |
| E10 | + 'Segoe UI' -> Inter at 600-699 | h02 13:40:09 | exit 1 (caught) | Inter SemiBold / Bold at 600, 650 |
| E11 | + 'Segoe UI' -> Inter at >= 800 | h03 13:40:14 | **exit 0, "OK"** | Inter ExtraBold at 800: money 87.59 px vs 76.47 |
| E13 | + every Liberation Sans face rejected | h20 13:44:04 | exit 1 (caught) | 'Segoe UI' in Inter, Arial in Liberation Serif |
| E14 | + Arial bound (strong) to Liberation Serif | h20 13:44:16 | exit 1 (caught) | both in Liberation Serif, 68.75 px |

**k01 (13:40:19, exit 0, 304.6 s):** `fc-gate.sh env/E11 -- node tools/layout-fits.mjs` on the base. The gate printed
"font-env OK" and ran layout-fits: 54 ok, "The layout holds". **h23 (13:47:14, exit 0, 15.3 s)** `probe/weights.mjs` on
the builder's populated base board under E11. The posture's "$19,920,000 BA" (800, 12.5 px) draws in Inter ExtraBold at
100.81 px, against 91.05 in Liberation Sans Bold under the right config (h22c). The inspector's "$6,682,500" (800, 17 px)
is 97.17 px against 85.09. h22c (13:46:50, exit 0) counts the weights of visible text elements across all five modes:
400: 518, 500: 68, 600: 285, 650: 141, 700: 466, 750: 95, **800: 307, 900: 5**.

**Candidate fixes** (`mut/fx/*/font-env.mjs`, each a one-line or two-line change to the delivered font-env):

| id | change | right config | as is | E7 | E9 | E10 | E11 |
|---|---|---|---|---|---|---|---|
| FX1 | WEIGHTS += 800 | h05 exit 0 | -- | -- | -- | -- | h04 exit 1 |
| FX2 | FX1 + hand-written Arial widths (money 76.47; words 236.23 below 600, 251.45 from 600) | h07 exit 0 | h08 exit 1 | h09 exit 1 | h06 exit 1 | h09c exit 1 | h09b exit 1 |
| FX3 | WEIGHTS += 800, 900 | h30 exit 0 | h32 exit 1 | h33 exit 1 | -- | -- | h31 exit 1 |

### 3c. Board mutants through the proposed run method's two passes (gate + layout-fits; gate + layout-fits at +6%)

| id | the wrong change (`mut/mkboard*.py`; each find matches the base once) | Arial pass | +6% pass | caught? |
|---|---|---|---|---|
| VM1 | `.row .amt,.row .num{overflow:hidden;text-overflow:ellipsis}` in the 940 block (r1's BM5) | 54/54 (r1 V42) | k05 exit 1, FAIL lines byte-identical to g24 | no (disclosed by the builder) |
| VM2 | allocation box text 12 -> 13 px | k06 exit 0, 54/54 | -- | no; h29 shows the placeholder cut by 5.53 px at 761-940, "J-rule ok" (disclosed in Draft 2) |
| VM3 | Rank's money column at 761-940 80 -> 79 px | -- (76.47 px fits 79) | k04 exit 1: new FAILs J harbor rank and J parchment rank (180 widths) | **yes** |
| VM4 | Brief's four money columns at 761-940 92 -> 88 px | k03 exit 0, 54/54 | k02 exit 1, FAIL lines byte-identical to g24 | **no**; h26: 5.97 px past the box at +6% (base 1.97), h27: 0.70 px past it in Arial |

## 4. Findings

### Must-fix

**MF1. font-env.mjs (and so fc-gate.sh) does not check weights 800 and 900, though the board draws visible text at
them (312 element-renders over the five modes, h22c), money among them. The drafts and the script say it checks "every weight the board draws".**
Reproduction: `bash mut/mkenv2.sh` (E11), then from the repository root
`FONTCONFIG_FILE=env/E11/fonts.conf node U/evidence-u28/font-env.mjs`. It exits 0 with "OK: the board is drawn in
Arial's widths here, at every weight it uses" (h03). `fc-gate.sh env/E11 -- node tools/layout-fits.mjs` runs and passes
54/54 (k01). `probe/weights.mjs` under E11 shows the board's weight-800 money in Inter ExtraBold (h23). This is the U28
failure mode, 'Segoe UI' drawn in Inter, at the weight of 162 of the board's CSS rules. The gate exists to refuse it.
Minimal fix: in `evidence-u28/font-env.mjs` line 18, `const WEIGHTS = [400, 500, 600, 650, 700, 750, 800, 900];`. Then
re-run f10-f15 and f20-f22. FX3 (one-line diff, blob a034d348) exits 0 on the right config (h30) and exits 1 as the
container is (h32), on E7 (h33) and on E11 (h31). Also correct the header comment (line 3: "at 400 ... 750") and add
E11 to Draft 3's list of wrong settings tried.

### Should-fix

- **SF1. The +6% pass cannot see the known overrun grow.** Draft 1 says: "Today that run fails exactly J harbor brief
  and J parchment brief, 180 widths each; any other failure is new". J's FAIL line holds no amount ("e.g. 940px:
  row-R019 ... cut in its cell"). So VM4 (Brief 92 -> 88 px) passes both passes unseen (k03 54/54; k02 FAIL lines
  identical to g24), while Brief's figure runs 5.97 px past its box at +6% and 0.70 px in Arial (h26, h27). Fix (text):
  say so in Draft 1. Each time, also record `probe/visual.mjs`'s Brief overrun at +6% (1.97 px today) and treat any
  larger figure as new. Or name this gap under Draft 3's "Not covered".
- **SF2. font-env's expected width is the same machine's Arial, not a literal.** In E9, Liberation Sans Bold is
  missing. Every weight from 600 up draws synthetic-bold Regular, and its words are 6% narrower than Arial Bold, yet it
  passes (h01). Fix: FX2's added line
  `const ARIAL = { money: () => 76.47, words: w => (w < 600 ? 236.23 : 251.45) };` and
  `&& Math.abs(sw - ARIAL[k](w)) < 0.01` in `ok`. It catches E9 (h06) and E7, E10, E11, and passes the right config
  (h07).
- **SF3. Two script mutants survive the builder's recorded scenarios.** SM5 (weights 400 and 750 only) and SM7 (family
  regex loosened) give the same exits as the delivered script on E1b-E7 (h14, h16). Add E10 (Inter at 600-699) and E14
  (Arial bound to Liberation Serif) to the recorded environment mutants. The delivered font-env already catches both
  (h02, h20-E14), so the record would pin those two properties.

### Minor

- `claude/v200-ui` has moved. Its head is now 7df816c (board fb3ccbbd), not dd15956. The difference is 5 lines of
  handler arguments ("UI-C1 ... jsa()") with no CSS. The measurements still hold, but Draft 1's "at its head dd15956" is
  stale. Say "at dd15956".
- SM8 (no family test on the Arial line) is equivalent on this machine: no second metric twin of Arial is installed.
- The board's 5 weight-900 elements: CSS sets no 900, so these come from `bolder` (b/strong) inside heavy parents.
  FX3 covers them.
- My process. The earlier attempt sequenced g22-g34 in `chain1.sh` under an outer `setsid -w timeout -k 10 3000`, and I
  started quick1 under an outer 600 and k01-k06 under an outer 620. In every case the command itself ran under run.sh's
  `setsid -w timeout -k 10 600`; the outer bound only sequences or wraps the lock wait. h22b failed at once on a syntax
  error in my probe (exit 1, 0.5 s) and was re-run as h22c.

## 5. Every run of this attempt (each via run.sh: `setsid -w timeout -k 10 600`; logs in `logs/<label>.log`)

| label | start (ET, 13 Oct) | exit | wall s |
|---|---|---|---|
| g43-mkenv-E11 | 13:38:35 | 0 | 1.3 |
| g44-mkboard-VM4 | 13:39:07 | 0 | 0.4 |
| g45-standin106-VM1 / VM3 / VM4 | 13:40:04-13:40:05 | 0 / 0 / 0 | 0.5 / 0.4 / 0.3 |
| h01-fontenv-E9 | 13:40:04 | 0 | 4.5 |
| h02-fontenv-E10 | 13:40:09 | 1 | 5.5 |
| h03-fontenv-E11 | 13:40:14 | 0 | 4.6 |
| h04-FX1-E11 | 13:40:19 | 1 | 4.3 |
| h05-FX1-fc | 13:40:23 | 0 | 4.5 |
| h06-FX2-E9 | 13:40:28 | 1 | 4.7 |
| h07-FX2-fc | 13:40:32 | 0 | 4.7 |
| h08-FX2-asis | 13:40:37 | 1 | 5.6 |
| h09-FX2-E7 / h09b-FX2-E11 / h09c-FX2-E10 | 13:40:43 / 13:40:47 / 13:40:51 | 1 / 1 / 1 | 4.3 / 4.3 / 5.7 |
| h10-SM1-f20-gate-E7 | 13:40:57 | 0 | 5.9 |
| h11-SM2-f21b-gate-fc | 13:41:03 | 0 | 7.2 |
| h12-SM3-f21b-gate-fc | 13:41:11 | 3 | 5.7 |
| h13-SM4-f14-E7 | 13:41:16 | 0 | 6.5 |
| h14-SM5 on E7, E1b, E2, E3, E5, E6, E4 | 13:41:23-13:41:59 | 1 each | 5.4-6.5 |
| h14b-SM5-E10 | 13:42:06 | 0 | 5.3 |
| h15-SM6 on E5 / E6 | 13:42:11 / 13:42:17 | 0 / 1 | 5.6 / 6.0 |
| h16-SM7-f15-E6 | 13:42:23 | 1 | 6.3 |
| h17-SM8 on E5 / E6 | 13:42:30 / 13:42:36 | 1 / 1 | 6.3 / 5.2 |
| h18-SM9-f02-relative / h18b-SM9-f12-fontenv | 13:42:41 / 13:42:43 | 0 / 1 | 1.3 / 5.1 |
| h19-SM10-f23-template | 13:42:48 | 0 | 0.4 |
| g46-mkenv-E13 / g47-mkenv-E14 | 13:43:22 / 13:43:54 | 0 / 0 | 1.3 / 1.8 |
| h20-fontenv-E13 / h21-SM7-E13 | 13:44:04 / 13:44:10 | 1 / 1 | 6.2 / 6.1 |
| h20-fontenv-E14 / h21-SM7-E14 | 13:44:16 / 13:44:23 | 1 / 0 | 6.9 / 7.1 |
| k01-gateE11-layoutfits-base | 13:40:19 | 0 | 304.6 |
| h22-weights-fc | 13:46:10 | 0 | 14.4 |
| h22b-weights-fc (my syntax error) | 13:46:38 | 1 | 0.5 |
| h22c-weights-fc | 13:46:50 | 0 | 16.7 |
| h23-weights-E11 | 13:47:14 | 0 | 15.3 |
| h24-build-VM4 / h25-standin106-VM4-populated | 13:47:44 / 13:47:53 | 0 / 0 | 9.6 / 0.5 |
| h26-visual-VM4-standin106 / h27-visual-VM4-asis-fc | 13:47:54 / 13:48:09 | 0 / 0 | 14.6 / 13.9 |
| k02-gate-layoutfits-VM4-standin106 | 13:44:46 | 1 | 338.5 |
| k03-gate-layoutfits-VM4 | 13:48:38 | 0 | 384.5 |
| k04-gate-layoutfits-VM3-standin106 | 13:50:37 | 1 | 398.6 |
| k05-gate-layoutfits-VM1-standin106 | 13:55:10 | 1 | 359.1 |
| k06-gate-layoutfits-VM2 | 13:57:25 | 0 | 341.1 |
| h28-build-VM2 / h29-alloc-VM2-fc | 14:01:22 / 14:01:30 | 0 / 0 | 8.5 / 11.8 |
| h30-FX3-fc / h31-FX3-E11 / h32-FX3-asis / h33-FX3-E7 | 14:01:42-14:02:04 | 0 / 1 / 1 / 1 | 7.0 / 6.9 / 7.9 / 7.5 |

Exit codes that are the expected result, not faults: 1 from font-env catching a wrong font; 3 from the gate refusing;
1 from layout-fits reporting FAILs on a mutant or at +6%. No run timed out. At most two node/Chromium runs were mine at
any time: the k runs one or two at a time, the h runs one after another beside them. The load average was 20-34 on 4
CPUs.

**PIDs:** `pids.txt`, 207 lines. Lines 1-79 are the earlier attempt's (10:33-10:46 AM ET); the rest are this attempt's.
Each run's `timeout` PID and its child are recorded; "gone" marks a child that ended before it could be recorded.

## 6. Files (git hash-object)

| file | blob |
|---|---|
| run.sh | 81173ff20ccbb2e7b6d2b11b08525091bb010088 |
| chain1.sh (earlier attempt) | 867d8d7f5da8c34b2663c0ca13e6291bcedb4c17 |
| quick1.sh | 43519e005d049059403594d6200e72fcbbea2b6f |
| mut/mkboard.py (VM1-VM3) / mut/mkboard2.py (VM4) | a78f398d... / 670d1e60... |
| mut/mkenv.sh (E9, E10) / mkenv2.sh (E11) / mkenv3.sh (E13) / mkenv4.sh (E14) | 136fe728... / f9b60f1f... / 537a1a07... / dd05460d... |
| probe/weights.mjs | 01eb922279db812fac5a26919db6999fa427f465 |
| mut/fx/FX1, FX2, FX3 font-env.mjs | b21718f6..., d3e3416d..., a034d348... |
| mut/boards/VM1, VM2, VM3, VM4 .html | a66b351f..., 74ad202b..., d9ddcc2d..., 749abd5f... |
| mut/scripts SM1 fc-gate / SM2 fc-gate / SM3 fc-gate | b40369b7..., bfaefd73..., 623bcb89... |
| SM4 / SM5 / SM6 / SM7 / SM8 font-env | 311519fe..., f388542b..., 2102e180..., e0fee66a..., 9af02f16... |
| SM9 fc-nosegoe / SM10 standin-template | c581bec6..., 8ca97b99... |
| ev/* (copies of the builder's evidence-u28/*) | identical to 3c63a124 (fc-nosegoe), b6c79d01 (fc-gate), e51716dd (font-env), f7723d3f (standin-template) |

## 7. What I did not do

- I did not run the other 13 verify:grid tools, under the setting or otherwise. So I do not know what E11 changes in
  toolbar-fits or the drop-down checks, which measure weight-800 labels. Like the builder, I ran layout-fits only.
- I did not run SM9 against /etc paths, since without `realpath` it could write there. Its /etc refusal was checked by
  reading.
- I wrote no suite block or mutation entry, and edited no builder file. The fixes above are proposals for the builder;
  FX1-FX3 live only in my `mut/fx/`.
- No real Segoe UI, Windows, Mac or iPad measurement; nothing downloaded.
- No other jsdom suite and no npm run check. Nothing in the board, tools or suites changed, so they would only re-test
  the base against itself.
