# U28 -- is the nine-digit money figure cut at 761-1023 px in a real browser, or only in this container?

Builder for ORBIT v2.00 release track U28. Directory: `rec/L6/u28` (all paths below are relative to it). Work began 7:51
PM ET on 12 Oct 2026; the build's README was last written at 8:40 PM ET. Fix round 1 began at 9:13 AM ET on 13 Oct
(README written by 9:31 AM ET); fix round 2 began at 2:31 PM ET and last wrote this README at 4:32 PM ET. Nothing was
edited, staged, committed or pushed in orbit-board or orbit-ui. **Read Fix round 2 first**: it proposes one commit (c1)
and supersedes fix round 1's answer, its "no board change" and its drafts. Those are kept below and marked where
superseded.

## Fix round 2 (13 Oct 2026, from 2:31 PM ET)

Two verifiers reviewed fix round 1 (`verify-money-r2/README.md`, `verify-tests-r2/README.md`; read here as input, never
changed). The money lens found the record **unsound**: one must-fix, a real cut at the Presentation density, with a
verified one-rule fix. The tests lens found it **sound with issues**: one must-fix (the gate skipped weights 800 and
900) and three should-fixes. This round closes both must-fixes and every should-fix and minor that was cheap and clearly
right. **It now proposes one commit, c1** (`c1/`, `diffs/c1-*.diff`): one CSS rule in the board, four J checks in
layout-fits, and a three-line comment in mutate.mjs. The run-method scripts in `evidence-u28/` are corrected again. The
drafts are rewritten.

**Resuming:** no earlier attempt of this fix round had started. When this round began at 2:31 PM ET, nothing in this
directory was newer than fix round 1's README (9:31 AM ET), except the verifiers' own folders and `wfstate/`. README.md
had no "Fix round 2" section. Nothing was kept from a stopped attempt. The lock `AUDIT_IMPORT_RUNNING` was absent before
every run (run.sh checks it), and none of my earlier recorded processes was running.

### The answer, corrected again (supersedes fix round 1's "The answer, corrected", which supersedes the build's)

- **J's six recorded failures: container-only, P3, no board change for them.** This is unchanged. The image's
  `/etc/fonts/conf.d/56-prefer-inter.conf` sends 'Segoe UI' to Inter, and Chromium follows it.
- **But a real browser did cut the figure, at the Presentation density (money verifier r2's must-fix; reproduced
  here).** layout-fits J opens every mode at the default density only: its init script sets `spmtTheme` and `spmtMode`,
  never `spmtDensity` (base tools/layout-fits.mjs:317-319). Presentation is a menu choice (Setup › Appearance, board
  lines 26187-26199; `uiSetDensity`, line 3788), and it sets the row's money to 14.5 px (line 941). In Rank and Fund at
  761-940 px the money columns are 80 px (lines 1227-1228). The board's own comment (lines 1221-1224) says those columns
  were sized for a nine-digit figure at the row's money size, 76.5 px, not 88.7. So "$123,456,789" is 88.70 px in an
  80-px column, in Arial's own widths. That is not the container: it runs through the gate, with no Inter and no
  stand-in. q40 (2:50 PM ET, through the gate, on the base board populated as layout-fits builds it) reproduces the
  money verifier's r05a/r05b exactly. In both themes, J's own `measure()` fails at 180 widths (761-940) in Rank and in
  Fund. R019's figure has -8.7 px of room and runs 2.7 px into the next cell. In Rank, `elementFromPoint` 0.5 px inside
  the figure's right end returns the lane's "Unfunded" label (`ll unf`). In Fund it returns the allocation INPUT for the
  Unfunded figure; the Ask figure runs into the next (dash) cell's box but not its text. The shot
  `out/fr2/shots/base-harbor-fund-presentation-900.png` shows the last "9" under the allocation box. This is deliverable
  **(b), a genuine defect**. Fund at 941-1023 px holds it (88.70 px in 90 px), and Review and Compare at the
  Presentation density fit (money verifier r05c).
- **The fix, c1:** inside the existing `@media (max-width:940px)` block, Rank and Fund keep the row's money size (12.5
  px) at the Presentation density. The rule's text is the money verifier's, word for word; the board blob is 41c3840b,
  the same as their c1. q41 (2:52 PM ET) runs the same measure on the populated c1 board: 0 J failures at all 263
  widths, in Rank and Fund, in both themes. R019's figure never runs past its cell, and nothing runs into the next cell.
  The probe measures room at the right-aligned text's end, so a figure that fits reads 0; on the base it read -8.7. The
  shot `out/fr2/shots/c1-harbor-fund-presentation-900.png` shows the Unfunded figure whole beside the allocation box.
  The four new J checks FAIL on the base (q46, 180 widths each, exit 1) and pass on c1 (q47, 263 widths each, exit 0).
- **Whether a real browser cuts the figure in the grid cells, with c1:** in Arial's widths (a Mac or iPad), no. It is
  whole at every width 761-1023 in all five themes at the Presentation density, and at Compact and Comfortable. In the
  Segoe stand-in, c1 at the Presentation density, 1100-761 px, both themes (q44 at +3%, q45 at +6%):
  - Rank's figure fits at +3%. At +6% it runs 0.97 px past its 80-px box, within J's 1-px rule, as Comfortable does
    today.
  - Fund's Unfunded figure runs past its 90-px box at 941-1100 px: 1.28 px at +3% and 3.97 px at +6%. It runs into the
    8-px gap before the allocation box, and no run reaches the next cell's box.
  - J's rule passes the +3% figure but fails the +6% one (160 widths to 1100, 83 of them inside J's 761-1023).
  - Brief at +6% runs 1.97 px past its box, as in round 1. Real Segoe UI was not measured.
- **Fund's allocation box:** unchanged from fix round 1, its own row (Draft 2), P2 until measured. Its CSS is a fixed
  650 12px, so neither the density nor c1 changes it.

### Fixes, each with the finding it closes

| # | finding (verifier r2) | what changed | shown by |
|---|---|---|---|
| G1 | must-fix (money): "whole in every grid cell" and "nothing changes" are false; at the Presentation density Rank and Fund cut the figure at 761-940 px in Arial's widths | **c1**: one CSS rule (the verifier's, verbatim), four J checks, a comment in mutate.mjs; drafts rewritten (Draft A for NEXT-VERSION; Drafts 1 and 4); the build's and round 1's sentences marked superseded | q40, q46, q47, q50c-r2, q41, q42, q43b, q48, q55b |
| G2 | must-fix (tests): font-env checked 400-750 only; E11 ('Segoe UI' to Inter at 800 and up) passed the gate, and layout-fits then said "The layout holds" | `WEIGHTS` += 800, 900; header comment corrected; E11 added to the recorded wrong settings | q16-E11 (exit 1), q20 (the gate REFUSES E11, layout-fits not run), q13a (round 1's font-env on E11: exit 0, missed) |
| G3 | should-fix (tests): font-env's expected width was this machine's own Arial, not a literal (E9 passed) | Arial's widths written in as figures (76.47; 236.23 below 600, 251.45 from 600), checked beside the same-machine comparison | q16-E9 (exit 1, 6 words lines BAD), q13b (round 1's: exit 0), q11 (exit 0 on the right setting) |
| G4 | should-fix (tests): SM5 and SM7 survive every recorded scenario | E10 (Inter at 600-699) and E14 (Arial bound to Liberation Serif) recorded, with E9, E11, E13 (`fr2/mkenv.sh`) | q16 (exit 1 each) |
| G5 | should-fix (money): standin-template.mjs overwrote any file, its own input included (r13: the board template became b038b559, a stand-in inside it) | writes a new file only (`flag: 'wx'`); refuses <out> = <board> and an existing <out> or link; exit 2, nothing written | q23a-q23d; q23g (round 1's: overwrote a copy, b038b559) |
| G6 | should-fix (money): a non-numeric scale gave "+NaN%" and a face drawn at 100%; fewer FAILs would read as good news | refuses a scale that is not a number from 100 to 150; Draft 1 says the +6% pass counts only with exactly its known FAILs, and fewer is not good news | q23e, q23f; q23h (round 1's: "+NaN%", `size-adjust:NaN%`) |
| G7 | should-fix (money): with J at the Presentation density the +6% pass gains Fund at 941-1023 | listed in Draft 1's "Open for Brad (2)" with Brief's; measured | q52c, q56a, q56b, q45 |
| G8 | should-fix (tests): the +6% pass cannot see the known overrun grow (VM4) | Draft 1 says so and gives today's overruns (1.97 and 3.97 px) to compare against | text |
| G9 | minors: UI head moved to 7df816c (board fb3ccbbd); Compact not re-measured; E11 into Draft 3's list | UI head cited as 7df816c (5 handler lines, no CSS since dd15956); Compact measured; E9-E14 in the drafts | q43b; text |

Not changed, with reasons: the tests verifier's SM8 is equivalent on this machine (no second metric twin of Arial is
installed). VM1 (an ellipsis on the money cells) and VM2 (the allocation box at 13 px) are still not caught. Both were
disclosed already, and the drafts keep saying so. The verifiers' OOM kills and process notes needed no change.

### The proposed commit c1 (base 7ee498a; one commit; `c1/` is base + it)

| file | base blob | c1 blob | diff |
|---|---|---|---|
| prioritization-board-grid.html | fce8a391 | 41c3840b (= the money verifier's c1) | `diffs/c1-board.diff` (+4 lines, in the `max-width:940px` block, after line 1229) |
| tools/layout-fits.mjs | abfe1386 | e8ee9892 | `diffs/c1-layout-fits.diff` (header +2; J loop) |
| tools/export-audit/mutate.mjs (here mutate.mjs.txt) | cbc6defc | 6d366fde | `diffs/c1-mutate.diff` (+3 comment lines before the R3 line) |

The CSS: `:root[data-density="presentation"][data-mode="rank"],:root[data-density="presentation"][data-mode="fund"]{--num:12.5px}`
inside `@media (max-width:940px)`. Its specificity (0,3,0) beats `html[data-density="presentation"]` (0,1,1). `--num`
sizes only `.row .num`, `.row .amt` and `.row .rank b` (lines 1100, 1123, 1125). Density is this browser's setting,
never saved into the file (board comment, lines 935-937). So nothing saved, exported or computed changes.

**Test lines edited (principle 6: file:line, old, new, why).** No expected value is edited. J's rule (`measure()`, base
lines 296-316) is unchanged.
- tools/layout-fits.mjs header, after base line 26 (c1 lines 27-28): a two-line note added. J's promise text now says
  that Rank and Fund are also opened at the Presentation density.
- base line 317, the J loop header (c1 lines 319-322). Old: 2 themes × 5 modes at the default density, 10 checks. New:
  the same 10, plus `['rank','presentation']` and `['fund','presentation']`, 14 checks. Why: J never opened the density
  where the figure is cut.
- base line 319, the init script (c1 lines 324-325). Old: it set spmtTheme and spmtMode. New: it also sets spmtDensity
  when the pair names one. The 10 old pairs name none, so they open exactly as before.
- base line 331, the check's name (c1 line 337). Old: "J · <theme> <mode>: every width 761-1023 fits". New: the same for
  the 10 old pairs, and " at the presentation density" added for the 4 new ones. The 54 old names are unchanged,
  compared name by name below.
- tools/export-audit/mutate.mjs, before base line 4288 (c1 lines 4288-4290): a comment only. mcount stays 1328 of 1328
  entries matching once, on the base and on c1 (q01, q02).

**Mutations.** None in mutate.mjs, because jsdom has no layout; the v1.95 W5 precedent is a comment saying why, and c1
adds one. Instead, browser mutants go through the focused harness (`fr2/h/tools/focused-jpres.mjs`, built by
`fr2/mkfocused.py`). It holds layout-fits lines 1-95 and J's measure and loop verbatim. Only the pair list is filtered
to the four new checks, and the theme list can be narrowed by THEMES. Results:

| board (`fr2/mkmut.py`; each find matches c1 once) | the four new checks | run |
|---|---|---|
| base 7ee498a (no rule) | 4 FAIL, 180 widths each (761-940) | q46, exit 1, 71.5 s |
| c1 | 4 ok, 263 widths each | q47, exit 0, 76.8 s |
| VMa: the rule for Rank only (d94c390f) | harbor rank ok; **harbor fund FAIL**, 180 widths | q48, exit 1, 55.7 s |
| VMb: the rule for Fund only (6ce61d12) | **harbor rank FAIL**, 180 widths; harbor fund ok | q48, exit 1, 56.9 s |
| VMc: the rule at 13.5 px (e6a7d2d3) | **harbor rank and harbor fund FAIL**, 180 widths each | q48, exit 1, 58.7 s |

The mutants ran in harbor only (THEMES=harbor), because the theme changes no size (no `data-theme` rule sets a font,
size, width or gap). By construction, J cannot catch one class of mutant: the rule moved out of the 940-px block, so the
money is smaller at every width at the Presentation density. J checks fit, not size, so that is named under "Not
covered" in Draft A rather than run.

**How c1 meets each decision principle**
1. *Never lose a copy:* CSS only. No data, save, export or computation path is touched, and density is never saved into
   the file.
2. *Refuse or ask rather than guess:* the size kept is the one these columns were built for, per the board's own comment
   (lines 1221-1224). Wider columns would be a design choice: four money columns +48 px do not fit Fund at 761 px
   against its 100-px title minimum (money verifier r2). That choice, and the +6% question, stay with Brad.
3. *Money matches the computation:* the same string, from the same computation, is now drawn whole.
4. *Every word stays true after it lands:* the board's comment "Each column is sized to what it holds ... layout-fits J
   holds every width, 761 to 1023" becomes true at the Presentation density as well. layout-fits' header says what J
   covers. The menu still says Presentation is "larger type, for a room". It is, except for the money in Rank and Fund
   at 940 px and narrower, which Draft A's "What users may see" states. The drafts drop "whole in every grid cell" and
   "nothing changes".
5. *Smallest change:* one rule in an existing media block, two pairs in J's loop, and a comment.
6. *Every existing check, fixture and expected value preserved:* the 54 existing layout-fits names and results hold on
   c1 (below), and the other 13 verify:grid tools give the same output on the base and on c1 (below). mcount is
   unchanged, and no fixture is touched.

### Merge with claude/v200-ui (scratch clone `fr2/clone`, `git clone --shared` of orbit-board; nothing committed there)

`git merge-tree` (git 2.43) takes only commits with `--write-tree`. So c1's files were staged in the scratch clone's
index on 7ee498a, `git write-tree` gave tree bc29c0cf, and the trivial-merge form `git merge-tree 4a6f7c7 <tree>
7df816c` was run. 4a6f7c7 is the merge base of 7ee498a and the UI head. The output has **no conflict markers**
(`out/fr2/merge/mt-c1.txt`; the same for 7ee498a itself, `mt-base.txt`). Three files change on both sides: the board,
layout-fits.mjs and mutate.mjs. Each was merged three ways with `git merge-file` (UI 7df816c, base 4a6f7c7, c1), and **0
conflicts** each. The merged files differ from the merge of 7ee498a without c1 by exactly c1's lines: board +4 (merged
4b05397d against 097b76d8, the same blobs as the money verifier's), layout-fits 12 lines (merged 1d454272 against
2ee21034), mutate +3 (c1f6019b against 1e5660a3). On that branch the rule is redundant. Its own `ui-e940` lists give
Rank 92-px money columns, and Fund 84 px at 11.5 px set directly on `#list .row .num/.amt`, which the variable does not
reach. So the rule only draws Rank's money at 12.5 px instead of 14.5 at the Presentation density when the window is 940
px or less. The four new J checks on the merged board: q55b, 4 ok, 263 widths each, exit 0 (q55, the first try, lost the
browser after 3 ok).

### What the runs show (every browser run through `evidence-u28/fc-gate.sh fr/fc`, the new font-env first)

**layout-fits on c1, whole.** q50c-r2 (3:23 PM ET, exit 0, 450.1 s) ran c1's layout-fits on c1 and gave **58 ok, 0 FAIL,
"The layout holds"**. Its 54 old check names and results are round 1's f22 on the base, line for line, and the 4 new
ones are ok (`fr2/names-f22.txt` against `fr2/names-q50c-r2.txt`). Four earlier attempts lost the browser to the memory
limit part-way: q50 (42 ok), q50b (42 ok), q50c (47 ok), all with 0 FAIL.

**The four new checks: they fail before the change and pass after it.**
- On the base board: q46, 4 FAIL, 180 widths each (761-940), exit 1.
- On c1: q47, 4 ok, 263 widths each, exit 0; and inside q50c-r2.
- On the c1 board merged into claude/v200-ui: q55b (3:44 PM ET, built from the merged layout-fits by the same script), 4
  ok, 263 widths each, exit 0. q55 at 3:14 PM had 3 ok before the browser was killed.

**The +6% stand-in pass on c1** (the pass Draft 1 asks to run beside the setting): first in pieces, because the memory
limit killed the browser in the first four whole attempts (q52, q52b, -r2, -r3). Sections A-I: 41 ok, 0 FAIL in q52b-r3,
the same as round 1's f24 on the base. Section J's fourteen width checks: q56a (harbor) and q56b (parchment), with
`fr2/h/tools/focused-jall.mjs`, J's loop verbatim with every pair. Each fails exactly two checks:
  - `J · <theme> brief`: 180 widths, the same FAIL lines as f24, byte for byte.
  - `J · <theme> fund at the presentation density`: 83 widths, 941-1023 px ("e.g. 1023px"). The other ten are ok, Rank
    at the Presentation density included. These are the four known failures Draft 1 records. Then the whole pass ran
    once more, with memory freer, and ended whole: q52c (4:23 PM ET, exit 1, 371.4 s). It gave **54 ok and exactly those
    four FAILs**, "4 layout check(s) failed", with the same 58 names as q50c-r2.

**The unchanged base pass again** (round 1's f22, now through the new font-env): the whole run lost its browser three
times (q51, q51b, q51b-r2: 19, 45 and 46 ok, 0 FAIL). It then ran in two verbatim halves of the base's own layout-fits
(`fr2/mksplit.py`). q57a has the lines up to section J: 41 ok, exit 0, 163.0 s. q57b has section J whole: 13 ok, exit 0,
229.9 s. Together they give 54 ok, the same names and results as round 1's f22, line for line (`fr2/names-q57.txt`).

**The +3% stand-in, section J on c1** (q58a harbor, q58b parchment, the J-all harness): 7 ok each, exit 0. J's 1-px rule
passes Fund's 1.28-px overrun at 941-1023 at the Presentation density, and Brief's figure fits. A-I at +3% were 41 ok in
q53 before its browser was killed.

**The density probe** (`probe/density.mjs`, J's own `measure()` at every width, and R019's cells):

| run | board | modes, density, themes, widths | J fails | R019's figure |
|---|---|---|---|---|
| q40 | base | Rank, Fund · Presentation · harbor, parchment · 1023-761 | 180 each | 8.7 px past its 80-px box at 761-940, 2.7 px into the next cell (Rank: the "Unfunded" label; Fund: the allocation INPUT) |
| q41 | c1 | the same | **0** | inside its box at every width; nothing reaches the next cell |
| q42 | c1 | Rank, Fund · Presentation · Midnight, Navy, Blueprint · 1023-761 | **0** each | the same |
| q43 / q43b | c1 | Rank, Fund · Compact · harbor, parchment | 0 each (q43b, 3:46 PM ET; q43 had 3 of 4 at 0 before the browser was killed) | 12 px figure inside its box |
| q44 | c1 +3% | Rank, Fund · Presentation · both · 1100-761 | 0 | Rank fits; Fund's Unfunded 1.28 px past its 90-px box at 941-1100, inside the 8-px gap |
| q45 | c1 +6% | the same | Rank 0; **Fund 160** (941-1100) | Rank 0.97 px past at 761-940 (12.5 px; J's 1-px rule passes it); Fund's Unfunded 3.97 px past at 941-1100, inside the gap |

**The other 13 verify:grid tools, base against c1, each through the gate** (`fr2/cmptools.sh`; the normalised logs take
out the header, paths, temp dirs, timings and clock times):

| tool | runs (base / c1) | exit; ok lines; FAIL lines | normalised logs |
|---|---|---|---|
| chrome | q6-chrome-base / q6-chrome-c1 | exit 0 / 0; ok lines 21 / 21; FAIL lines 0 / 0 | identical |
| controls | q6-controls-base / q6-controls-c1 | exit 0 / 0; ok lines 16 / 16; FAIL lines 0 / 0 | identical |
| inspector | q6-inspector-base / q6-inspector-c1 | exit 0 / 0; ok lines 23 / 23; FAIL lines 0 / 0 | identical |
| toolbar | q6-toolbar-base / q6-toolbar-c1 | exit 0 / 0; ok lines 36 / 36; FAIL lines 0 / 0 | identical |
| editors | q6-editors-base / q6-editors-c1 | exit 0 / 0; ok lines 38 / 38; FAIL lines 0 / 0 | identical |
| colours | q8-colours-base / q8-colours-c1 | exit 0 / 0; ok lines 66 / 66; FAIL lines 0 / 0 | identical |
| menus | q8-menus-base / q8-menus-c1 | exit 0 / 0; ok lines 83 / 83; FAIL lines 0 / 0 | identical |
| panels | q8-panels-base / q8-panels-c1 | exit 0 / 0; ok lines 231 / 231; FAIL lines 0 / 0 | identical |
| frames | q8-frames-base / q8-frames-c1 | exit 0 / 0; ok lines 32 / 32; FAIL lines 0 / 0 | identical |
| hostile | q8-hostile-base / q8-hostile-c1 | exit 0 / 0; ok lines 20 / 20; FAIL lines 0 / 0 | identical |
| keys | q8-keys-base / q8-keys-c1 | exit 0 / 0; ok lines 95 / 95; FAIL lines 0 / 0 | identical |
| dropdowns | q8-dropdowns-base / q8-dropdowns-c1-r2 | exit 0 / 0; ok lines 16 / 16; FAIL lines 0 / 0 | identical |
| dialogs | q8-dialogs-base / q8-dialogs-c1 | exit 0 / 0; ok lines 16 / 16; FAIL lines 0 / 0 | identical |

All 13 tools exit 0 on both boards under the setting, and their output is the same line for line. That includes
dropdowns-visible's and editors-reachable's own +6% stand-in passes. q6 is chainC (2:45-2:50 PM ET) and q8 is chainG
(3:51-4:11 PM ET). colours' q6 pair was not used because q6-colours-base lost its browser (a navigation timeout).
dropdowns' first c1 attempt lost its browser and its -r2 ended whole. No other verify:grid tool sets `spmtDensity`
(grep), so none of them can open the Presentation density in Rank or Fund, where the rule applies.

**npm run check:** `tools/check.mjs` needs a git work tree (its ignore rule asks `git check-ignore`). Run in the copies
(q7-check-base, q7-check-c1, exit 1 each), it fails only those two checks, "could not ask git", on both. Run in scratch
clones of orbit-board at 7ee498a, one as is and one with c1's three files over it (`fr2/clone-base`, `fr2/clone`), it
passes on both: q7b, "all checks passed", exit 0. The two logs differ only in the line count (31672 against 31676).

### The run-method scripts (evidence-u28/, for `recovery/v200/evidence/L6-u28/`; a proposal, not adopted)

| file | round 1 blob | now | diff |
|---|---|---|---|
| font-env.mjs | e51716dd (`superseded/font-env.r1.mjs`) | d3fb1295 | `fr2/font-env.r2.diff` |
| standin-template.mjs | f7723d3f (`superseded/standin-template.r1.mjs`) | c0d188cc | `fr2/standin-template.r2.diff` |
| fc-nosegoe.sh, fc-gate.sh | 3c63a124, b6c79d01 | unchanged | -- |

**font-env.mjs** now checks 400, 500, 600, 650, 700, 750, 800 and 900. Each line must be drawn in Liberation Sans or
Arial, at this machine's Arial width, and at Arial's width written into the script as a figure: 76.47 px for the money
at every weight, and 236.23 px for the words below 600 or 251.45 px from 600. Every font-env run of round 1 was re-run
with it (q10-q15). The new environment mutants were run against it and against round 1's script (q13, q16):

| setting | what Chromium draws | round 1's font-env | now |
|---|---|---|---|
| the container as it is | Inter, every weight | exit 1 | q10 exit 1, 16 of 16 BAD |
| fc-nosegoe (the right setting); its relative-dir variant | Liberation Sans | exit 0 | q11, q12 exit 0, 16 of 16 ok |
| E7 ('Segoe UI' still Inter below bold; tests verifier r1) | Inter at 400-650 | exit 1 | q14 exit 1, 8 BAD |
| E1b, E2, E3, E4, E5, E6 (tests verifier r1) | as recorded in round 1 | exit 1 each | q15 exit 1 each, 16 BAD each |
| E8 (an equivalent control) | Liberation Sans | exit 0 | q15 exit 0 |
| E9 Liberation Sans Bold rejected | synthetic-bold Regular: words 236.23 px at 600-900 | **q13b exit 0, missed** | q16 exit 1, 6 BAD (the words at 600-900; the money's digits keep their width) |
| E10 'Segoe UI' to Inter at 600-699 | Inter SemiBold/Bold at 600, 650 | exit 1 | q16 exit 1, 4 BAD |
| E11 'Segoe UI' to Inter at 800 and up | Inter ExtraBold 87.59 px at 800, Inter Black 87.56 px at 900 | **q13a exit 0, missed** | q16 exit 1, 4 BAD |
| E13 every Liberation Sans face rejected | 'Segoe UI', Arial, sans-serif in Inter (the stack falls to sans-serif); Arial alone in Liberation Serif | exit 1 (verifier h20) | q16 exit 1, 16 BAD |
| E14 Arial bound to Liberation Serif | Liberation Serif for both | exit 1 (verifier h20) | q16 exit 1, 16 BAD |

**fc-gate.sh** (unchanged, but it runs the new font-env): q20 REFUSES E11, exit 3, and layout-fits is not run. In the
tests verifier's k01 it ran layout-fits and said "The layout holds". q20b refuses E7 and q21 a missing config (exit 3).
q21b runs the command under the right setting (exit 0).

**standin-template.mjs**, run from a repository root:
- q23a writes the +6% template of the base, md5 75089e04, byte-identical to round 1's f23.
- It refuses, with exit 2 and nothing written: an output that exists (q23b); the board itself as the output (q23c, on a
  copy, whose blob stays fce8a391); a link to the board (q23d); the scales "abc" (q23e) and "6" (q23f).
- Round 1's script, on a copy, overwrote it (q23g: b038b559, one stand-in inside, the money verifier's r13 again) and
  wrote "+NaN%" with `size-adjust:NaN%` (q23h).
- q24a, q24b, q31a and q31b write the +6% and +3% templates of c1 and of the populated c1 board.

### Drafts of fix round 2 (replace every earlier draft; the lead commits, with <sha>/<time> filled in)

The proposed commit is c1 (`c1/`, `diffs/c1-*.diff`). The drafts assume it lands. If the lead instead relies on
claude/v200-ui's own 761-940 px columns, Draft 1's "fixed by <sha>" becomes "fixed on claude/v200-ui; v2.00 depends on
that merge", and the four J checks go onto that branch (they merge cleanly there, below).

#### Draft A: NEXT-VERSION.md entry under v2.00, for commit c1 (the U13/U1/U14 shape)

- **U28 — at the Presentation density, Rank and Fund cut a nine-digit figure at 761-940 px** (found by the U28 money
  review, 13 Oct; built on Brad's "keep pressing", 12 Oct, about 5:30 PM ET). In a window 761-940 px wide, Rank's and
  Fund's money columns are 80 px, sized for a nine-digit figure at the row's money size (12.5 px; "$123,456,789" is 76.5
  px). At the Presentation density (Setup › Appearance) the row's money is 14.5 px and that figure is 88.7 px. It ran
  8.7 px past its column and 2.7 px under the next cell: the lane meter and its "Unfunded" label in Rank, the allocation
  box in Fund. That happened in Arial's own widths, in both themes J checks; the themes change no size. layout-fits J
  checked 761-1023 px only at the default density, so nothing saw it. Now, at 940 px and narrower, Rank and Fund keep
  the row's money size at the Presentation density. Brief's columns are sized for the larger figure and are unchanged.
  Predates v2.00 (v1.91 sized these columns).
  - **What users may see:** at the Presentation density, in Rank and Fund, in a window 761-940 px wide, the money is
    drawn at 12.5 px (the Comfortable size) while the rest of the row stays larger, and a nine-digit figure is whole.
    Wider windows, Brief, Review, Compare and the other densities are unchanged.
  - **Test:** layout-fits J also opens Rank and Fund at the Presentation density: four checks, "J · harbor|parchment
    rank|fund at the presentation density: every width 761-1023 fits". All four fail on the board before the change (180
    widths each) and pass after it (263 widths each). The ten existing J checks keep their names and results.
  - **Mutations:** none in mutate.mjs, because jsdom has no layout. A comment there says so, as v1.95's W5 did. The four
    checks catch the board without the rule, the rule for Rank only, the rule for Fund only, and the rule at 13.5 px.
  - **Not covered:** a Segoe-like font at the Presentation density. At the project's +6% stand-in, Fund's figure runs
    3.97 px past its 90-px columns at 941-1023 px, into the 8-px gap where nothing covers it, and the +6% pass fails J
    there. At +3% it is 1.28 px past its box, which J's 1-px rule passes. The check measures fit, not size, so a rule
    that kept the smaller size at every width would also pass. Compact is measured whole but not checked by J. On
    claude/v200-ui the rule is redundant, because that branch's own 761-940 columns hold the figure.

#### Draft 1: text to append to UNRESOLVED-LEDGER.md row U28 (replaces the earlier rounds' drafts)

Investigated <time> ET (U28 builder and fix rounds 1-2, `rec/L6/u28`; recorded at <sha>). **Two findings.** **(a)
Section J's six recorded failures come from this container, not the board.** This image's
`/etc/fonts/conf.d/56-prefer-inter.conf` (no package owns it; dated 3 Oct, 05:35 UTC) resolves 'Segoe UI' to Inter.
Chromium draws the rows' `'Segoe UI', Arial, sans-serif` in Inter: Inter Bold for the money figures (650, 750), Inter
Medium for the dash cells (500). "$123,456,789" is 87.64 px at 12.5 px in Rank's and Fund's 80-px boxes at 761-940 px,
and 101.66 px at 14.5 px in Brief's 92-px boxes. That is 14.6% wider than Arial's widths (76.47 and 88.70 px). With only
that alias line left out, layout-fits passes 54 of 54 on 7ee498a. Severity P3 (container-only); no board change for
these six. **(b) A real browser did cut the figure, at the Presentation density: fixed by <sha>.** layout-fits J opened
every mode at the default density only. At Setup › Appearance › Presentation, the row's money is 14.5 px. In Rank and
Fund at 761-940 px, "$123,456,789" (88.70 px in Arial's widths) ran 8.7 px past its 80-px column and 2.7 px under the
next cell: the lane meter and "Unfunded" label in Rank, the allocation box in Fund. That held in both themes J checks
and at 180 widths each. A Mac or iPad (Arial) shows it. A wider, Segoe-like font shows it worse: at the project's +6%
stand-in it ran 7.97 px under the next cell (U28 money review, r07). <sha> keeps the row's money size (12.5 px) for Rank
and Fund at the Presentation density at 940 px and narrower. layout-fits J now opens both modes at that density, four
checks that fail before the change and pass after it. Measured whole after the change in all five themes, and at
Compact. Review and Compare at the Presentation density fitted already. P2 while open; closed by <sha>. **Whether a real
browser cuts the figure in the grid cells, after <sha>:** in Arial's widths it is whole at every width 761-1023 px, in
every mode and density measured. In the Segoe stand-in, at +6%, Brief's figure runs 1.97 px past its 92-px box at
761-940 px. At the Presentation density, Fund's runs 3.97 px past its 90-px boxes at 941-1023 px, and J fails that at 83
widths, as the stand-in pass shows. Both run into an empty gap, and nothing covers them; Brief's Unfunded, the last
column, runs into the row's 10-px padding. At +3%, Fund's runs 1.28 px past its 90-px boxes at 941-1100 px at the
Presentation density, which J's rule passes, and Brief's fits with 0.72 px to spare. Not measured: real Segoe UI, and
which Segoe face Edge draws for weight 750 (Bold 700 or Black 900). The same figure in Fund's allocation box is its own
row, <new id> (P2 until measured). **Open for Brad:** (1) **The run method: proposed, not adopted.** verify:grid would
run here with FONTCONFIG_FILE=<dir>/fonts.conf, the container's fontconfig with one line left out (the 'Segoe UI' ->
Inter alias), written by `recovery/v200/evidence/L6-u28/fc-nosegoe.sh <dir>`. The run goes only through
`recovery/v200/evidence/L6-u28/fc-gate.sh <dir> -- npm run verify:grid`. The gate refuses unless `font-env.mjs` finds
'Segoe UI' and Arial drawn in Liberation Sans or Arial at 400, 500, 600, 650, 700, 750, 800 and 900, at Arial's widths
written into it as figures. font-env exits 1 as the container is and on each of the twelve wrong settings tried (E1b-E7,
E9, E10, E11, E13, E14). It exits 0 on the right setting and on an equivalent one (E8). Under it, on 7ee498a with <sha>,
layout-fits passes 58 of 58, and the other 13 tools give the same output on the base and on <sha>, all exit 0. Before
the method is adopted, the lead runs all 14 tools both ways and compares. (2) **Whether J must hold at the +6%
stand-in**, as the drop-down and editor checks do. Every time (1) is run, also run `fc-gate.sh <dir> -- node
tools/layout-fits.mjs --board <the +6% template from standin-template.mjs>`. Today, with <sha>, that pass fails exactly
four checks: J harbor brief and J parchment brief (180 widths each), and J harbor fund and J parchment fund at the
presentation density (83 widths each, 941-1023 px). The pass counts only when it shows exactly those four. Another FAIL
is new. Fewer FAILs mean the stand-in may not have been drawn, so check the template before reading it as good news. A
FAIL line gives no amount, so a narrower column that lets the figure run further (the tests verifier's VM4: 5.97 px
instead of 1.97) prints the same line. The overrun is measured beside it each time: 1.97 px (Brief) and 3.97 px (Fund at
the Presentation density) today, and a larger figure is new. Keeping the +6% figure inside its box needs 94-px columns:
Brief's four at 761-940 px, and Fund's four at 941-1100 px at the Presentation density. Not built.

#### Draft 2: new UNRESOLVED-LEDGER.md row (unchanged from fix round 1 but for the UI citation; "<new id>" in Draft 1)

As fix round 1's Draft 2, with "claude/v200-ui 5e9e5a5e (the same 0.59 px)" read as "claude/v200-ui at 8783a2d/dd15956,
board 5e9e5a5e (the same 0.59 px); its head 7df816c (board fb3ccbbd, 12:13 PM ET on 13 Oct) changes five handler
arguments and no CSS". The allocation box's CSS is a fixed 12 px, so the Presentation density does not change it, and c1
does not touch it.

#### Draft 4: new line for "Unresolved after R1-R5" (U28 has no line there to replace)

  - **U28: built as its own commit** (<sha>): at the Presentation density, Rank and Fund keep the row's money size at
    940 px and narrower, so a nine-digit figure is whole there (above). verify:grid's six layout-fits J failures in this
    container are the container's doing ('Segoe UI' drawn in Inter): P3, no board change. Open for Brad: whether
    verify:grid runs here with that alias left out (the gate now checks every weight the board draws), and whether J
    must hold at the +6% Segoe stand-in (Brief's columns at 761-940 px and Fund's at 941-1100 px at the Presentation
    density would need 94 px). **<new id> (P2 until measured):** Fund's allocation box shows the nine-digit ask in the
    browser's form-control font, with 0.59 px to spare in Arial's widths at 761-940 px, and no check sees a cut
    placeholder.

### Runs of fix round 2 (each through `run.sh`: `setsid -w timeout -k 10 600`, lock checked first -- never present)

| label | start (ET, 13 Oct) | exit | wall s | log |
|---|---|---|---|---|
| q01-mcount-base | 14:43:28 EDT | 0 | 5.3 | logs/q01-mcount-base.log |
| q02-mcount-c1 | 14:43:33 EDT | 0 | 5.4 | logs/q02-mcount-c1.log |
| q03-mkenv | 14:43:39 EDT | 0 | 5.0 | logs/q03-mkenv.log |
| q10-fontenv-asis | 14:43:44 EDT | 1 | 3.5 | logs/q10-fontenv-asis.log |
| q11-fontenv-fc | 14:43:47 EDT | 0 | 3.4 | logs/q11-fontenv-fc.log |
| q12-fontenv-fcrel | 14:43:51 EDT | 0 | 3.5 | logs/q12-fontenv-fcrel.log |
| q13a-fontenv-r1-E11 | 14:43:54 EDT | 0 | 3.8 | logs/q13a-fontenv-r1-E11.log |
| q13b-fontenv-r1-E9 | 14:43:58 EDT | 0 | 3.3 | logs/q13b-fontenv-r1-E9.log |
| q14-fontenv-E7 | 14:44:01 EDT | 1 | 3.3 | logs/q14-fontenv-E7.log |
| q15-fontenv-E1b | 14:44:05 EDT | 1 | 3.5 | logs/q15-fontenv-E1b.log |
| q15-fontenv-E2 | 14:44:08 EDT | 1 | 3.0 | logs/q15-fontenv-E2.log |
| q15-fontenv-E3 | 14:44:11 EDT | 1 | 4.4 | logs/q15-fontenv-E3.log |
| q15-fontenv-E5 | 14:44:16 EDT | 1 | 3.8 | logs/q15-fontenv-E5.log |
| q15-fontenv-E6 | 14:44:20 EDT | 1 | 2.9 | logs/q15-fontenv-E6.log |
| q15-fontenv-E8 | 14:44:23 EDT | 0 | 3.1 | logs/q15-fontenv-E8.log |
| q15-fontenv-E4 | 14:44:26 EDT | 1 | 4.1 | logs/q15-fontenv-E4.log |
| q16-fontenv-E9 | 14:44:30 EDT | 1 | 3.8 | logs/q16-fontenv-E9.log |
| q16-fontenv-E10 | 14:44:34 EDT | 1 | 4.1 | logs/q16-fontenv-E10.log |
| q16-fontenv-E11 | 14:44:38 EDT | 1 | 3.7 | logs/q16-fontenv-E11.log |
| q16-fontenv-E13 | 14:44:42 EDT | 1 | 3.9 | logs/q16-fontenv-E13.log |
| q16-fontenv-E14 | 14:44:45 EDT | 1 | 3.3 | logs/q16-fontenv-E14.log |
| q20-gate-refuses-E11-layoutfits | 14:44:49 EDT | 3 | 3.6 | logs/q20-gate-refuses-E11-layoutfits.log |
| q20b-gate-refuses-E7 | 14:44:52 EDT | 3 | 3.8 | logs/q20b-gate-refuses-E7.log |
| q21-gate-refuses-nofile | 14:44:56 EDT | 3 | 10.2 | logs/q21-gate-refuses-nofile.log |
| q21b-gate-runs-trivial | 14:45:06 EDT | 0 | 4.3 | logs/q21b-gate-runs-trivial.log |
| q23a-standin-base-106 | 14:45:11 EDT | 0 | 0.3 | logs/q23a-standin-base-106.log |
| q23b-standin-refuses-existing | 14:45:11 EDT | 2 | 0.5 | logs/q23b-standin-refuses-existing.log |
| q23c-standin-refuses-same-path | 14:45:12 EDT | 2 | 0.2 | logs/q23c-standin-refuses-same-path.log |
| q23d-standin-refuses-link | 14:45:12 EDT | 2 | 0.5 | logs/q23d-standin-refuses-link.log |
| q23e-standin-refuses-scale-abc | 14:45:13 EDT | 2 | 0.4 | logs/q23e-standin-refuses-scale-abc.log |
| q23f-standin-refuses-scale-6 | 14:45:13 EDT | 2 | 0.3 | logs/q23f-standin-refuses-scale-6.log |
| q23g-standin-r1-same-path | 14:45:14 EDT | 0 | 0.3 | logs/q23g-standin-r1-same-path.log |
| q23h-standin-r1-scale-abc | 14:45:14 EDT | 0 | 0.4 | logs/q23h-standin-r1-scale-abc.log |
| q24a-standin-c1-106 | 14:45:14 EDT | 0 | 0.4 | logs/q24a-standin-c1-106.log |
| q24b-standin-c1-103 | 14:45:15 EDT | 0 | 0.3 | logs/q24b-standin-c1-103.log |
| q30-build-c1 | 14:45:15 EDT | 0 | 4.5 | logs/q30-build-c1.log |
| q31a-standin-pop-c1-106 | 14:45:20 EDT | 0 | 0.4 | logs/q31a-standin-pop-c1-106.log |
| q31b-standin-pop-c1-103 | 14:45:20 EDT | 0 | 0.3 | logs/q31b-standin-pop-c1-103.log |
| q6-chrome-base | 14:45:27 EDT | 0 | 3.8 | logs/q6-chrome-base.log |
| q6-chrome-c1 | 14:45:31 EDT | 0 | 3.8 | logs/q6-chrome-c1.log |
| q6-controls-base | 14:45:35 EDT | 0 | 9.3 | logs/q6-controls-base.log |
| q6-controls-c1 | 14:45:44 EDT | 0 | 10.7 | logs/q6-controls-c1.log |
| q6-inspector-base | 14:45:55 EDT | 0 | 9.5 | logs/q6-inspector-base.log |
| q6-inspector-c1 | 14:46:05 EDT | 0 | 11.4 | logs/q6-inspector-c1.log |
| q46-focusedJ-base | 14:45:27 EDT | 1 | 71.5 | logs/q46-focusedJ-base.log |
| q6-toolbar-base | 14:46:16 EDT | 0 | 37.7 | logs/q6-toolbar-base.log |
| q6-toolbar-c1 | 14:46:54 EDT | 0 | 42.8 | logs/q6-toolbar-c1.log |
| q47-focusedJ-c1 | 14:46:39 EDT | 0 | 76.8 | logs/q47-focusedJ-c1.log |
| q6-editors-base | 14:47:37 EDT | 0 | 66.0 | logs/q6-editors-base.log |
| q6-editors-c1 | 14:48:43 EDT | 0 | 61.4 | logs/q6-editors-c1.log |
| q6-colours-base | 14:49:44 EDT | 1 | 64.0 | logs/q6-colours-base.log |
| q50-layoutfits-c1 | 14:47:56 EDT | 1 | 172.7 | logs/q50-layoutfits-c1.log |
| q6-colours-c1 | 14:50:48 EDT | 0 | 44.9 | logs/q6-colours-c1.log |
| q40-density-base-pres | 14:50:48 EDT | 0 | 102.3 | logs/q40-density-base-pres.log |
| q41-density-c1-pres | 14:52:31 EDT | 0 | 89.9 | logs/q41-density-c1-pres.log |
| q48-focusedJ-VMa-rank-only | 14:54:01 EDT | 1 | 55.7 | logs/q48-focusedJ-VMa-rank-only.log |
| q48-focusedJ-VMb-fund-only | 14:54:56 EDT | 1 | 56.9 | logs/q48-focusedJ-VMb-fund-only.log |
| q48-focusedJ-VMc-13.5px | 14:55:53 EDT | 1 | 58.7 | logs/q48-focusedJ-VMc-13.5px.log |
| q52-layoutfits-c1-standin106 | 14:56:52 EDT | 1 | 120.8 | logs/q52-layoutfits-c1-standin106.log |
| q51-layoutfits-base | 14:58:53 EDT | 1 | 82.3 | logs/q51-layoutfits-base.log |
| q53-layoutfits-c1-standin103 | 15:00:15 EDT | 1 | 196.4 | logs/q53-layoutfits-c1-standin103.log |
| q42-density-c1-pres-3themes | 15:03:32 EDT | 0 | 146.4 | logs/q42-density-c1-pres-3themes.log |
| q43-density-c1-compact | 15:05:58 EDT | 1 | 232.4 | logs/q43-density-c1-compact.log |
| q44-density-c1s103-pres | 15:09:51 EDT | 0 | 123.2 | logs/q44-density-c1s103-pres.log |
| q45-density-c1s106-pres | 15:11:54 EDT | 0 | 139.7 | logs/q45-density-c1s106-pres.log |
| q55-focusedJ-merged | 15:14:14 EDT | 1 | 124.6 | logs/q55-focusedJ-merged.log |
| q50b-layoutfits-c1 | 15:16:24 EDT | 1 | 153.2 | logs/q50b-layoutfits-c1.log |
| q50c-layoutfits-c1 | 15:19:08 EDT | 1 | 275.9 | logs/q50c-layoutfits-c1.log |
| q50c-layoutfits-c1-r2 | 15:23:59 EDT | 0 | 450.1 | logs/q50c-layoutfits-c1-r2.log |
| q52b-layoutfits-c1-standin106 | 15:31:30 EDT | 1 | 32.1 | logs/q52b-layoutfits-c1-standin106.log |
| q52b-layoutfits-c1-standin106-r2 | 15:32:02 EDT | 1 | 56.0 | logs/q52b-layoutfits-c1-standin106-r2.log |
| q52b-layoutfits-c1-standin106-r3 | 15:32:58 EDT | 1 | 206.4 | logs/q52b-layoutfits-c1-standin106-r3.log |
| q51b-layoutfits-base | 15:36:25 EDT | 1 | 251.6 | logs/q51b-layoutfits-base.log |
| q51b-layoutfits-base-r2 | 15:40:51 EDT | 1 | 226.8 | logs/q51b-layoutfits-base-r2.log |
| q55b-focusedJ-merged | 15:44:56 EDT | 0 | 78.6 | logs/q55b-focusedJ-merged.log |
| q43b-density-c1-compact | 15:46:15 EDT | 0 | 80.6 | logs/q43b-density-c1-compact.log |
| q56a-Jall-c1-standin106-harbor | 15:47:35 EDT | 1 | 121.1 | logs/q56a-Jall-c1-standin106-harbor.log |
| q56b-Jall-c1-standin106-parchment | 15:49:36 EDT | 1 | 127.2 | logs/q56b-Jall-c1-standin106-parchment.log |
| q8-colours-base | 15:51:44 EDT | 0 | 29.4 | logs/q8-colours-base.log |
| q8-colours-c1 | 15:52:13 EDT | 0 | 28.9 | logs/q8-colours-c1.log |
| q8-menus-base | 15:52:42 EDT | 0 | 18.3 | logs/q8-menus-base.log |
| q8-menus-c1 | 15:53:00 EDT | 0 | 19.5 | logs/q8-menus-c1.log |
| q8-panels-base | 15:53:20 EDT | 0 | 38.5 | logs/q8-panels-base.log |
| q8-panels-c1 | 15:53:59 EDT | 0 | 33.8 | logs/q8-panels-c1.log |
| q8-frames-base | 15:54:33 EDT | 0 | 17.3 | logs/q8-frames-base.log |
| q8-frames-c1 | 15:54:50 EDT | 0 | 21.5 | logs/q8-frames-c1.log |
| q8-hostile-base | 15:55:42 EDT | 0 | 81.0 | logs/q8-hostile-base.log |
| q8-hostile-c1 | 15:57:03 EDT | 0 | 78.9 | logs/q8-hostile-c1.log |
| q8-keys-base | 15:58:22 EDT | 0 | 64.3 | logs/q8-keys-base.log |
| q8-keys-c1 | 15:59:26 EDT | 0 | 65.9 | logs/q8-keys-c1.log |
| q8-dropdowns-base | 16:00:32 EDT | 0 | 155.5 | logs/q8-dropdowns-base.log |
| q8-dropdowns-c1 | 16:03:07 EDT | 1 | 98.4 | logs/q8-dropdowns-c1.log |
| q8-dropdowns-c1-r2 | 16:04:46 EDT | 0 | 152.0 | logs/q8-dropdowns-c1-r2.log |
| q8-dialogs-base | 16:08:03 EDT | 0 | 110.0 | logs/q8-dialogs-base.log |
| q8-dialogs-c1 | 16:09:53 EDT | 0 | 108.7 | logs/q8-dialogs-c1.log |
| q7-check-base | 16:11:42 EDT | 1 | 11.6 | logs/q7-check-base.log |
| q7-check-c1 | 16:11:54 EDT | 1 | 11.1 | logs/q7-check-c1.log |
| q57a-split1-base | 16:12:05 EDT | 0 | 163.0 | logs/q57a-split1-base.log |
| q7b-check-base-clone | 16:15:16 EDT | 0 | 16.4 | logs/q7b-check-base-clone.log |
| q7b-check-c1-clone | 16:15:33 EDT | 0 | 17.3 | logs/q7b-check-c1-clone.log |
| q57b-split2-base | 16:14:48 EDT | 0 | 229.9 | logs/q57b-split2-base.log |
| q58a-Jall-c1-standin103-harbor | 16:18:38 EDT | 0 | 156.3 | logs/q58a-Jall-c1-standin103-harbor.log |
| q58b-Jall-c1-standin103-parchment | 16:21:14 EDT | 0 | 142.6 | logs/q58b-Jall-c1-standin103-parchment.log |
| q52c-layoutfits-c1-standin106 | 16:23:40 EDT | 1 | 371.4 | logs/q52c-layoutfits-c1-standin106.log |

Expected non-zero exits, none a fault of the change:
- font-env catching a wrong font, exit 1: q10, q14, q15 (all but E8), q16.
- The gate refusing, exit 3: q20, q20b, q21.
- standin-template refusing, exit 2: q23b-q23f.
- The new checks or the +6% pass failing as recorded, exit 1: q46 (the base), q48 (the mutants), q56a and q56b.
- npm run check in the copies, which are not git work trees, exit 1: q7-check-base and q7-check-c1. They pass in scratch
  clones (q7b).

**Browser lost to the memory limit** (exit 1 with "Target crashed" / "Page crashed" in the log, or a navigation timeout;
dmesg "Memory cgroup out of memory: Killed process ... (chrome)" at those times). These are not results, and each was
re-run: q50, q50b, q50c (then q50c-r2 whole), q51, q51b, q51b-r2 (the base pass, then q57a/q57b in halves, 54 ok), q52,
q52b, -r2, -r3 (then the pieces q52b-r3 A-I, q56a, q56b, then whole as q52c), q53 (then q58a/q58b for J; A-I 41 ok in
q53), q43 (then q43b), q55 (then q55b), and q6-colours-base (then q8-colours-base/c1). Every check that finished before
a kill agrees with the runs that ended whole. No run hit its 600-s cap.

**PIDs:** every run's `timeout` and its child are in `pids.txt`, from line 126 on (round 1 ends at line 125), with each
chain's own bash and its outer processes. The chain stops are recorded there with their reasons: C at 14:51, E and E2
before they ran anything, D during q50b, F during q51b-r2. In each case it was my own recorded chain bash, given
SIGTERM; the run under way finished under its own bound. Two corrections are noted there: 26740 (chain A), 32385 (B) and
32388 (C), recorded as "timeout", are the background subshells that started those chains. Chains D-H were recorded by
pgrep, each process under its real name.

### Files of fix round 2 (git hash-object)

| file | blob | what |
|---|---|---|
| c1/prioritization-board-grid.html | 41c3840b8435f65af004cad0f7331acf3a934504 | the proposed commit's board (= the money verifier's c1) |
| c1/tools/layout-fits.mjs | e8ee989239a2f99dd3b35f6471fe72edd8609def | the proposed commit's layout-fits |
| c1/tools/export-audit/mutate.mjs.txt | 6d366fdeb9e4336bf2043422bc2be6ce16595b2f | the proposed commit's mutate.mjs (as text) |
| diffs/c1-board.diff, c1-layout-fits.diff, c1-mutate.diff, c1-files-changed.txt | -- | c1 against the base, `diff -u` |
| evidence-u28/font-env.mjs | d3fb12950eaf553604fe8c5fde848ad7db15d039 | G2, G3 (round 1's: `superseded/font-env.r1.mjs`, e51716dd) |
| evidence-u28/standin-template.mjs | c0d188cc52a2cd121cde7af1bbdae2b5ead462ac | G5, G6 (round 1's: `superseded/standin-template.r1.mjs`, f7723d3f) |
| evidence-u28/fc-gate.sh, fc-nosegoe.sh | b6c79d01..., 3c63a124... | unchanged |
| fr2/font-env.r2.diff, fr2/standin-template.r2.diff | -- | the two scripts against round 1's |
| fr2/mkenv.sh | 8c7d69600e357abf39c33af6c339c0c86da85ab2 | E9, E10, E11, E13, E14 (the tests verifier's rules, my paths) |
| fr2/mkfocused.py, mkfocused-all.py, mksplit.py | e46e46d8, 94aebe49, 8716df96 | focused and split harnesses, built verbatim |
| fr2/h/tools/focused-jall.mjs; fr2/hs, fr2/hsb tools/layout-fits-part1/2.mjs | 492f961d; c1 122ed25e/5f9a50c4, base 778ec0f1/73ab5e63 | J's fourteen width checks; layout-fits in two halves |
| fr2/h/tools/focused-jpres.mjs | c0092859ac5f3ada15e67a708e0e6726e9874ef0 | the four new J checks alone (from c1's layout-fits) |
| fr2/hm/tools/focused-jpres-merged.mjs | 2bbc68d681fb352490c18ecfdf65e80d825ed7a2 | the same, from the merged layout-fits |
| fr2/mkmut.py; fr2/mut/VMa, VMb, VMc | ef2ab974...; d94c390f, 6ce61d12, e6a7d2d3 | the rule's wrong versions |
| probe/density.mjs | 190482df489945936220380983b8dfba8d379609 | the money verifier r2's probe (75ee31ef), copied with one comment line |
| fr2/chainA.sh ... chainH.sh | A 1b515853, B 21b884c6, C 493408dd, D c43cf5bc, E f9f9d4a4, E2 b4aad12f, F 3657b2c8, G b00cefb1, H 47ed3fe5 | the run chains |
| fr2/cmptools.sh, names.sh, runs-table.py, assemble.py | 6c3eb674, 38daa7a6, e15a9cb6, 972a217a | comparison, table and README scripts |
| out/fr2/populated-c1.html, -s103, -s106 | de11541c, c2db8bcf, 8f7cf872 | the populated c1 board and its stand-in copies |
| out/fr2/tpl/c1-standin106.html, c1-standin103.html, base-standin106.html | bba54432, a2c7d062, (md5 75089e04) | stand-in templates |
| out/fr2/merge/ | merged-c1 board 4b05397d, layout-fits 1d454272, mutate c1f6019b | the three-way merges with 7df816c |

### What I did not do (fix round 2)

- I did not commit, stage or push anything, anywhere. orbit-board and orbit-ui are untouched, and the scratch clone
  `fr2/clone` has c1's three files staged in its index only, to make the tree that `git merge-tree` needs. Nothing was
  committed there.
- I did not run the full audit-import or audit-board, mutate.mjs or playwright install. mutate.mjs was read as text
  (mcount.py).
- No jsdom suite was run on c1: audit, audit-ppt, audit-other, audit-recon, audit-hostile, audit-inject, legacy-fsrc and
  boot-same. c1's board change is one CSS rule that jsdom does not lay out, and a grep finds no suite that reads
  `max-width:940`, `--num`, `data-density` or `rowcols`, so the suites would re-test the base against itself. npm run
  check ran on both (in scratch clones: all checks passed on both).
- No mutation entry was added. A layout rule has nothing a jsdom suite can see, so I followed the v1.95 W5 precedent and
  added a comment instead. The browser mutants VMa-VMc stand in for entries.
- I did not widen any column, and I did not keep the smaller money at 941-1100 px. The +6% (and +3%) overruns in Brief
  and in Fund at the Presentation density are left to Brad, with today's figures.
- Real Segoe UI was not measured, nor Edge on Windows, Safari on a Mac or an iPad.
- The memory limit: the container's shared memory cgroup killed the browser in many runs (dmesg "Memory cgroup out of
  memory: Killed process ... (chrome)"; load 30-41 on 4 CPUs). Those are environment failures, not results; each was
  re-run, and every check that finished before a kill agrees with the runs that ended whole. Chains C, D, E, E2 and F
  were stopped by me (SIGTERM to my own recorded chain bash PIDs, between runs or letting the run under way finish). I
  did this to keep one browser at a time and move the rest to chains that wait for free memory. Each stop is recorded in
  `pids.txt` with its reason.

## Fix round (13 Oct 2026, from 9:13 AM ET)

*[Fix round 2: superseded where it says there is no board change, no commit and no c1; in its answer (the figure is whole in every grid cell); and in its drafts. See Fix round 2 above.]*

Two verifiers each found one must-fix, both text-only (`wfstate/verify_u28_r1_money.json`, `verify_u28_r1_tests.json`).
This round closes both must-fixes and every should-fix and minor that was cheap and clearly right. It still proposes
**no board change and no commit**: the board, the tools and every suite are untouched, so there are no copies (c1/...),
suite blocks or mutation entries. What changed is the answer's wording, the drafts, a new ledger row, and the
run-method scripts the drafts cite. Those scripts are hardened, made self-contained and gated, and they now live in
`evidence-u28/` for the lead to commit as `recovery/v200/evidence/L6-u28/`.

**Resuming:** no earlier attempt of this fix round had started. Nothing in this directory was newer than the build
(8:40 PM ET, 12 Oct) except the two verifiers' own folders (`verify-money-r1/`, `verify-tests-r1/`, read here as
input, never changed), and README.md had no Fix round section. So nothing was kept from a stopped attempt; every step
below ran in this round. The container restarted at 9:11 AM ET. Before the first run, the lock was absent and no
earlier process of mine was running.

### The answer, corrected (supersedes "A real browser does not cut it" and "(a) container-only" in the build's Answer below)

*[SUPERSEDED by Fix round 2: "no font measured clips it" in the grid cells held only at the default density. At the Presentation density, Rank and Fund cut the figure at 761-940 px in Arial's own widths; c1 fixes it.]*

- **J's six failures: container-only, P3, no board change.** This is unchanged, but it now covers only the grid
  money cells J measures. Root cause: the image's `/etc/fonts/conf.d/56-prefer-inter.conf` alias sends 'Segoe UI' to
  Inter. Inter Bold draws the money figures (weights 650 and 750) and Inter Medium the dash cells (`.amt.z`,
  weight 500).
- **Whether a real browser cuts it (F1, money must-fix):** in the grid cells, no font measured clips it, up to the
  +6% Segoe stand-in. At +6% Brief's figure overruns its box by 1.97 px: into the empty 6-px column gap, or for
  Unfunded, the last column, into the row's 10-px right padding. Nothing covers it. **Real Segoe UI was not measured.**
  Nor was which Segoe face Edge picks for weight 750 (F7).
- **The same figure in Fund's allocation box: not settled, a new row, P2 until measured (F2, money must-fix).** R019's
  allocation box shows the ask "$123,456,789" as its placeholder (board line 25625). Its CSS (lines 554, 1138-1139)
  names no font-family, so the browser's form-control font draws it. Here that is Arial: 73.41 px in a 74-px box at
  761-940 px, 0.59 px to spare (the money verifier's v04; f32-f34 here give the same, and f34 also under the setting). Drawn in the Segoe stand-in instead, set on that one input (f32, f33), it is **cut at 761-940 px in both
  themes**: 75.61 px at +3% (1.61 px cut; the last "9" is visibly clipped, `out/fr/shots/alloc-standin103-segoe-900.png`)
  and 77.72 px at +6% (3.72 px cut). J's rule still says "ok" (scrollWidth 86 = clientWidth 86). At 941-1023 px (90 px
  of content) it fits in every font measured. At 761-940 any form-control font more than 0.8% wider than Arial for
  these glyphs cuts it (74 / 73.41 = 1.008). So whether a user sees the figure cut depends on their browser's
  form-control font. Which font Edge on
  Windows, or Safari or Chrome on a Mac or iPad, gives this box was not measured. J cannot see a cut placeholder
  (v13), so the drafts open it as its own row.

### Fixes, each with the finding it closes

| # | finding (verifier) | what changed | shown by |
|---|---|---|---|
| F1 | must-fix (money): "a real browser does not cut the money figure" claims more than was measured | Limited to the grid money cells J measured, in the fonts measured; "P3, container-only" limited to J's six failures; the README's earlier sentences marked superseded | text (Answer above; Drafts 1, 3, 4) |
| F2 | must-fix (money): the allocation box was never measured, and J is blind to it | A "Not covered" line in every draft, and a new ledger row (Draft 2), P2 until measured; one more bounded probe at the Segoe stand-in | f32, f33, f34 |
| F3 | must-fix (tests): the ledger draft recorded the run method as settled, a choice the lead lists as Brad's | Draft 1 says "proposed, not adopted (Brad's decision)", that the lead runs all 14 tools both ways first, and that so far only layout-fits has run under it | text (Draft 1) |
| F4 | should-fix (money) + minor (tests): fc-nosegoe.sh with a relative <dir> wrote a broken config and said success; it wrote through a symlink left in <dir>; <dir>=/etc/fonts would truncate fonts.conf; without the Inter file it gave a false reason | `<dir>` is made absolute; refused unless new or empty, not under /etc, plain characters; no 56-prefer-inter.conf: says there is nothing to leave out (exit 3); symlinks made without -f; the include check matches the whole line | f01-f07 |
| F5 | should-fix (money): the procedure ran verify:grid even if font-env failed | New `fc-gate.sh <dir> -- <cmd>`: runs the command under the setting only after font-env.mjs exits 0, else REFUSED (exit 3) and the command is not run | f20, f21, f21b, f22, f24 |
| F6 | should-fix (tests): font-env.mjs tested weight 750 only (E7, 'Segoe UI' still Inter below bold, passed) | Checks weights 400, 500, 600, 650, 700 and 750, a money line and a line of words at each; both 'Segoe UI' and Arial must be Liberation Sans or Arial, at Arial's width | f10-f15 (E7: r0 exit 0, new exit 1) |
| F7 | should-fixes (money, tests): +6% Brief must be an open item, not a footnote; the L3 pass must run beside the setting; weight 750 vs Segoe Black not modelled | Draft 1's "Open for Brad" (1) and (2): the +6% layout-fits pass is run every time, with exactly two known failures recorded; Segoe's face for 750 under "Not covered" | f24; text |
| F8 | should-fix (money): the scripts lived in a scratchpad, and font-env imported ../../base/tools/chrome.mjs | `evidence-u28/` holds self-contained copies (they use `tools/chrome.mjs` and `tools/font-standin.mjs` from the repository root they run in), for `recovery/v200/evidence/L6-u28/` | f35 (from that path in a scratch clone) |
| F9 | minors (money): "Inter-Bold for every money cell"; UI head moved to dd15956; NEXT-VERSION draft's "gap" for the last column and its shape; "94 px" vs J's rule | The dash cells are Inter Medium; UI board cited at 8783a2d and dd15956 (same blob 5e9e5a5e); Unfunded runs into the row's padding; Draft 3 in the U13/U1/U14 shape; 93 px passes J's 1-px rule, 94 px keeps the figure inside its box | text |
| F10 | minor (tests): probe/visual.mjs's clip test skipped the cell's own overflow | The test starts at the cell itself, and the left edge is strict (`< left + border - 0.01`) | f27-f31 (BM5: r0 "clipped by nothing", new "clipped by the cell") |

Not changed, with reasons: the tests verifier's other minors (L2 used the config written before the script was saved;
the H check's `selTint` differing between runs; Chromium crashes under load) needed no change. f22 re-ran L2 with the
fixed script's config, which is content-identical to L2's (compared below).

### What the runs show

- **fc-nosegoe.sh (f01-f07):** an absolute and a relative `<dir>` both write a config with an absolute include (f01,
  f02). It refuses a non-empty `<dir>` (f03) and a `<dir>` holding a left-over symlink (f04), exit 2. It refuses
  /etc/fonts and a path that resolves under /etc (f05, f06), exit 2; md5 of /etc/fonts/fonts.conf and
  56-prefer-inter.conf unchanged. On a simulated machine without the Inter file it says there is nothing to leave
  out, exit 3 (f07). f01's config is the builder's L2 config to the byte, except the conf.d path: the same 40 files,
  resolving to the same contents. It differs from the machine's only by the one alias line.
- **font-env.mjs (f10-f15):** as the container is, exit 1, 12 of 12 lines BAD (Inter Regular, Medium, SemiBold, Bold).
  Under the new config, exit 0, 12 of 12 ok. Under the relative-dir config (formerly FreeSerif), exit 0. E7 (the old
  version's blind spot): the old version passed it (f13, exit 0), the new one fails it with 8 of 12 BAD, at weights
  400-650 (f14, exit 1). The other environment mutants E1b, E2, E3, E4, E5 and E6 still fail (exit 1). The
  equivalent control E8 still passes (exit 0).
- **fc-gate.sh (f20-f22, f24):** it refuses E7 (exit 3) and a missing config (exit 3), and the command does not run.
  With the right config it runs the command under the setting (f21b). **f22 = L2 again, through the gate:** layout-fits
  on the base gives 54 ok and 0 FAIL, "The layout holds", the same 54 check names as L2. **f24 = L3 again, through the gate:** layout-fits on the board with the +6% stand-in, under the
  setting, gives 52 ok and exit 1, with exactly the two known failures (J harbor brief and J parchment brief, 180
  widths each). Its FAIL lines are identical to L3's, in full. This is the pass Draft 1 asks to run beside
  verify:grid every time.
- **visual.mjs (f27-f31):** on the base as is, at +6%, and with no Inter alias (f27-f29), every measured line is identical to p06-p08
  (25 lines each, "clipped by nothing" in all), so the base conclusion stands. On the tests verifier's BM5 mutant
  (money cells at 761-940 px clip with an ellipsis), at +6%, the fixed probe (f30) reports "clipped by num/amt hidden"
  on 20 of 25 lines. Those are all the overrunning ones; the five at 1023 px fit. The old probe (f31) says
  "clipped by nothing" on all 25.
- **The allocation box (f32-f34):** in the browser's form-control font (Arial here; CDP: Liberation Sans Bold), the figure is 73.41 px in
  74 px at 761-940 (0.59 px to spare) and in 90 px at 941-1023, in both themes. That holds as the container is, at the
  stand-in boards and under the setting (f32-f34), as in the money verifier's v04 and v12. With the Segoe stand-in set
  on the input, it is cut by 1.61 px (+3%) and 3.72 px (+6%) at 761-940, and J's rule says "ok" every time. f34's
  lines with 'Segoe UI' set on the input draw Liberation Serif (under the setting nothing provides 'Segoe UI'), so
  they measure nothing and are not used.

### How each decision principle is met

1. *Never lose any copy:* nothing touches data or the board. fc-nosegoe.sh writes only into a new or empty directory
   it names, never into /etc (f05, f06, md5 check), and no longer writes through a link.
2. *Refuse or ask rather than guess:* the gate refuses unless the font is Arial's widths at every weight. The run
   method and the +6% question are left to Brad. The allocation box stays open at P2, because a CSS change would
   guess at fonts no one here has measured.
3. *Money and exports match the computation:* no computation is touched. The drafts now say exactly where the figure
   was measured whole (grid cells, fonts measured) and where it is not settled (the allocation box).
4. *Every word stays true:* "a real browser does not cut it" is narrowed to what was measured. The run method is
   called a proposal. "Inter-Bold for every money cell" is corrected.
5. *Smallest change:* no board or tool change. Two scripts hardened and one made self-contained, one gate and one
   probe added, one probe corrected, text rewritten.
6. *Every existing check, fixture and expected value preserved:* none was edited. layout-fits.mjs (abfe1386),
   font-standin.mjs (fd27b0f1), the board (fce8a391) and every suite are as they were. No expectation changed, so
   there is no file:line to list.

### Drafts (replace the builder's; the lead commits, with <sha>/<time> filled in)

*[SUPERSEDED by Fix round 2's drafts (Draft A, Drafts 1, 2 and 4). Draft 3 below said "What users may see: nothing changes", which was false at the Presentation density.]*

#### Draft 1: text to append to UNRESOLVED-LEDGER.md row U28 (replaces the builder's draft)

Investigated <time> ET (U28 builder and fix round, `rec/L6/u28`, read-only on the board; recorded at <sha>).
**Section J's six failures come from this container, not the board.** They are the grid's money cells as J measures
them. This image's `/etc/fonts/conf.d/56-prefer-inter.conf` (no package owns it; dated 3 Oct, 05:35 UTC) resolves
'Segoe UI' to Inter, and Chromium draws the rows' `'Segoe UI', Arial, sans-serif` in Inter: Inter Bold for the money
figures (weights 650 and 750), Inter Medium for the dash cells (500). "$123,456,789" is 87.64 px at 12.5 px in Rank's
and Fund's 80-px boxes at 761-940 px, and 101.66 px at 14.5 px in Brief's 92-px boxes. That is 14.6% wider than in
Arial's widths (76.47 and 88.70 px). With only that alias line left out, Chromium draws Liberation Sans (Arial's
widths), and layout-fits passes 54 of 54 on 7ee498a. As the container is, 48 pass and the six J checks fail as
recorded. **Whether a real browser cuts it:** in the grid cells it is not clipped in any font measured, up to the
project's +6% Segoe stand-in. It fits with 3.53 / 3.30 px to spare (Rank-Fund / Brief) in Arial's widths, and with
1.33 / 0.72 px at +3%. At +6% Brief's figure runs 1.97 px past its box (Rank's and Fund's 0.97 px, within J's 1-px
rule). It runs into the empty 6-px column gap, or for Unfunded, the last column, into the row's 10-px right padding;
nothing clips or covers it. J's 1-px rule still fails
Brief there, at 180 widths in each theme. Not measured: real Segoe UI, and which Segoe face Edge draws for the cells'
weight 750 (Bold 700 or Black 900; CSS weight matching tries the heavier face first). `claude/v200-ui` (board
5e9e5a5e, the same at 8783a2d and at its head dd15956) fits at every width, even in Inter. **Severity: P3
(container-only) for J's six failures; no board change.** The same figure also shows in Fund's allocation box, where
J cannot see it; that is now its own row, <new id>, P2 until measured.
**Open for Brad:** (1) **The run method: proposed, not adopted.** verify:grid would run here with
FONTCONFIG_FILE=<dir>/fonts.conf. <dir> holds the container's fontconfig with one line left out: the 'Segoe UI' ->
Inter alias in /etc/fonts/conf.d/56-prefer-inter.conf. `recovery/v200/evidence/L6-u28/fc-nosegoe.sh <dir>` writes it.
The run goes only through `recovery/v200/evidence/L6-u28/fc-gate.sh <dir> -- npm run verify:grid`, which refuses
unless `font-env.mjs` finds Arial's widths at every weight the board draws. Before it is adopted, the lead runs all 14
tools both ways and compares. So far only layout-fits has run under it (54/54 on 7ee498a). Every time it is run, also
run `fc-gate.sh <dir> -- node tools/layout-fits.mjs --board <standin-template.mjs output, +6%>` and record the result
against (2). Today that run fails exactly J harbor brief and J parchment brief, 180 widths each; any other failure is
new. Under the setting alone, J measures Arial's widths only, which is what a Mac or iPad shows in these cells. That
pass does not tell a money cell that clips (overflow hidden) from one that overruns. (2) **Whether J must hold at the
+6% stand-in**, as the drop-down and editor checks do. Today it does not, in Brief at 761-940 px: 93.97 px of figure
in a 92-px box. J's 1-px rule would pass with 93-px columns; keeping the figure inside its box needs 94 px (0.03 px to
spare). Not built.

#### Draft 2: new UNRESOLVED-LEDGER.md row (the lead assigns its number; "<new id>" in Draft 1)

| <new id> | **Fund's allocation box shows the nine-digit ask in the browser's form-control font, with 0.59 px to spare in Arial's widths at 761-940 px, and no check can see it cut.** R019's box shows its ask as a placeholder: `placeholder="${fM(askTot(it))}"`, which is "$123,456,789" (board fce8a391, line 25625). Its CSS (lines 554 and 1138-1139: 650 12px, tabular figures, right-aligned) names no font-family, so the browser's form-control font draws it. Here Chromium gives it Arial (computed "Arial"; CDP: Liberation Sans Bold): 73.41 px in a 74-px box at 761-940, 90 px at 941-1023. Neither the 'Segoe UI' setting nor the Segoe stand-in reaches it, and any form-control font more than 0.8% wider than Arial for these glyphs cuts it. Drawn in the project's Segoe stand-in instead, set on that one input, it is cut at 761-940 px in both themes: 75.61 px at +3% (1.61 px cut; the last "9" is clipped) and 77.72 px at +6% (3.72 px cut). J's rule says "ok" in both. A font 14.6% wider (Inter, set on that one input) shows "$123,456,78" (money verifier v13). layout-fits J cannot see a cut placeholder, because its input rule reads scrollWidth, which ignores placeholder text: in v13 it reported 'fits' while 10.13 px were cut. | U28 money verifier, 13 Oct, 12:27-12:41 AM ET (`rec/L6/u28/verify-money-r1`: v04, v12, v13, v18); U28 fix round, 13 Oct (f32-f34; shots `rec/L6/u28/out/fr/shots/alloc-*-900.png`) | Measured in this container's Chromium on fce8a391 (7ee498a) and on claude/v200-ui 5e9e5a5e (the same 0.59 px). NOT measured: the form-control font of Edge on Windows, or of Safari or Chrome on a Mac or iPad | Open, **P2 provisional until measured** (a real browser may cut a money figure). For Brad; not built: room for the figure at 761-940 px in the widest form-control font a user's browser uses, or the ask shown outside the box; and a layout check that measures placeholders |

#### Draft 3: NEXT-VERSION.md entry under v2.00 (optional: no board change; the U13/U1/U14 shape)

- **U28 -- verify:grid's layout-fits section J fails in this container only; no board change** (the lead's runner
  smoke, 12 Oct). In this container, layout-fits section J reports row R019's "$123,456,789" cut in Rank, Fund and
  Brief at 761-1023 px, in both themes, at every commit back to v1.91. The container's font setting causes it:
  `/etc/fonts/conf.d/56-prefer-inter.conf` sends 'Segoe UI' to Inter, which is 14.6% wider than Arial for these
  figures, and no user's browser draws Inter for it. Nothing in the board changes. Proposed, not adopted (Brad's
  decision): verify:grid runs here with that one alias left out, through a gate that refuses unless the board is drawn
  in Arial's widths at every weight, plus a second layout-fits pass in the Segoe stand-in at +6%.
  - **What users may see:** nothing changes. In the fonts measured the figure is whole in every grid cell. At the +6%
    stand-in, Brief's figure runs 2 px past its column into the empty gap (in Unfunded, into the row's right
    padding).
  - **Test:** none added to the suites. layout-fits gives 48 of 54 as the container is, 54 of 54 with the alias left
    out, and 52 of 54 at +6% (J harbor brief and J parchment brief). `font-env.mjs` exits 1 as the container is and
    on each of seven wrong settings tried. It exits 0 on the right setting and on an equivalent one.
  - **Mutations:** none (no board change).
  - **Not covered:** real Segoe UI (no Windows here); which Segoe face Edge picks for weight 750 (Bold or Black); the
    form-control font of Edge, Mac and iPad browsers for Fund's allocation box (its own row, P2); J does not tell a
    money cell that clips from one that overruns; the other 13 verify:grid tools under the setting.

#### Draft 4: optional new line for "Unresolved after R1-R5" (U28 has no line there to replace)

  - **U28 (P3, this container only): verify:grid's layout-fits J fails here** because the container draws 'Segoe UI'
    in Inter; no board change. Open for Brad: whether verify:grid runs here with that alias left out, and whether J
    must hold at the +6% Segoe stand-in (Brief's columns at 761-940 px would need 94 px). **<new id> (P2 until
    measured):** Fund's allocation box shows the nine-digit ask in the browser's form-control font, with 0.59 px to
    spare in Arial's widths at 761-940 px, and no check sees a cut placeholder.

### Runs of the fix round (each through `run.sh`: `setsid -w timeout -k 10 600`, lock checked first -- never present)

| label | start (ET) | exit | wall s | log |
|---|---|---|---|---|
| f01-fcnosegoe-abs | 2026-10-13 09:19:22 EDT | 0 | 0.5 | logs/f01-fcnosegoe-abs.log |
| f02-fcnosegoe-relative | 2026-10-13 09:19:22 EDT | 0 | 0.5 | logs/f02-fcnosegoe-relative.log |
| f03-fcnosegoe-nonempty | 2026-10-13 09:19:23 EDT | 2 | 2.8 | logs/f03-fcnosegoe-nonempty.log |
| f04-fcnosegoe-symlink-left | 2026-10-13 09:19:25 EDT | 2 | 0.1 | logs/f04-fcnosegoe-symlink-left.log |
| f05-fcnosegoe-etc | 2026-10-13 09:19:26 EDT | 2 | 3.3 | logs/f05-fcnosegoe-etc.log |
| f06-fcnosegoe-etc-sub | 2026-10-13 09:19:29 EDT | 2 | 0.1 | logs/f06-fcnosegoe-etc-sub.log |
| f07-fcnosegoe-cleanmachine | 2026-10-13 09:19:29 EDT | 3 | 3.8 | logs/f07-fcnosegoe-cleanmachine.log |
| f10-fontenv-asis | 2026-10-13 09:19:51 EDT | 1 | 2.5 | logs/f10-fontenv-asis.log |
| f11-fontenv-fc | 2026-10-13 09:19:54 EDT | 0 | 1.2 | logs/f11-fontenv-fc.log |
| f12-fontenv-fcrel | 2026-10-13 09:19:55 EDT | 0 | 1.1 | logs/f12-fontenv-fcrel.log |
| f13-fontenv-r0-E7 | 2026-10-13 09:19:56 EDT | 0 | 1.0 | logs/f13-fontenv-r0-E7.log |
| f14-fontenv-E7 | 2026-10-13 09:19:57 EDT | 1 | 1.1 | logs/f14-fontenv-E7.log |
| f15-fontenv-E1b | 2026-10-13 09:19:58 EDT | 1 | 1.2 | logs/f15-fontenv-E1b.log |
| f15-fontenv-E2 | 2026-10-13 09:20:00 EDT | 1 | 1.4 | logs/f15-fontenv-E2.log |
| f15-fontenv-E3 | 2026-10-13 09:20:01 EDT | 1 | 1.2 | logs/f15-fontenv-E3.log |
| f15-fontenv-E5 | 2026-10-13 09:20:02 EDT | 1 | 1.3 | logs/f15-fontenv-E5.log |
| f15-fontenv-E6 | 2026-10-13 09:20:03 EDT | 1 | 1.4 | logs/f15-fontenv-E6.log |
| f15-fontenv-E8 | 2026-10-13 09:20:05 EDT | 0 | 1.3 | logs/f15-fontenv-E8.log |
| f15-fontenv-E4 | 2026-10-13 09:20:06 EDT | 1 | 1.3 | logs/f15-fontenv-E4.log |
| f20-gate-refuses-E7 | 2026-10-13 09:20:22 EDT | 3 | 1.0 | logs/f20-gate-refuses-E7.log |
| f21-gate-refuses-nofile | 2026-10-13 09:20:23 EDT | 3 | 0.0 | logs/f21-gate-refuses-nofile.log |
| f21b-gate-runs-trivial | 2026-10-13 09:20:23 EDT | 0 | 1.1 | logs/f21b-gate-runs-trivial.log |
| f22-gate-layoutfits-base | 2026-10-13 09:20:52 EDT | 0 | 148.6 | logs/f22-gate-layoutfits-base.log |
| f23-standin-template-106 | 2026-10-13 09:23:20 EDT | 0 | 0.1 | logs/f23-standin-template-106.log |
| f24-gate-layoutfits-standin106 | 2026-10-13 09:23:20 EDT | 1 | 204.5 | logs/f24-gate-layoutfits-standin106.log |
| f27-visual-base-asis | 2026-10-13 09:26:45 EDT | 0 | 9.6 | logs/f27-visual-base-asis.log |
| f28-visual-base-standin106 | 2026-10-13 09:26:54 EDT | 0 | 10.0 | logs/f28-visual-base-standin106.log |
| f29-visual-base-nointer | 2026-10-13 09:27:04 EDT | 0 | 9.6 | logs/f29-visual-base-nointer.log |
| f30-visual-BM5-standin106 | 2026-10-13 09:27:14 EDT | 0 | 9.5 | logs/f30-visual-BM5-standin106.log |
| f31-visual-r0-BM5-standin106 | 2026-10-13 09:27:24 EDT | 0 | 10.5 | logs/f31-visual-r0-BM5-standin106.log |
| f32-alloc-base-standin103 | 2026-10-13 09:27:34 EDT | 0 | 10.4 | logs/f32-alloc-base-standin103.log |
| f33-alloc-base-standin106 | 2026-10-13 09:27:45 EDT | 0 | 7.1 | logs/f33-alloc-base-standin106.log |
| f34-alloc-base-asis-fc | 2026-10-13 09:27:52 EDT | 0 | 6.1 | logs/f34-alloc-base-asis-fc.log |
| f35a-clone-fcnosegoe | 2026-10-13 09:28:49 EDT | 0 | 0.6 | logs/f35a-clone-fcnosegoe.log |
| f35b-clone-gate-standin | 2026-10-13 09:28:49 EDT | 0 | 3.4 | logs/f35b-clone-gate-standin.log |
| f36-fontenv-not-repo-root | 2026-10-13 09:29:00 EDT | 2 | 1.2 | logs/f36-fontenv-not-repo-root.log |

Expected exits, none a fault: f03-f06 exit 2 and f07 exit 3 (fc-nosegoe.sh refusing), f10 and f14-f15 exit 1 (font-env
catching a wrong font; f15-E8 is the control and exits 0), f20-f21 exit 3 (the gate refusing), f24 exit 1 (the two known
+6% failures), and f36 exit 2 (font-env run outside a repository root). No run timed out or was skipped. f22-f34
ran one after another from `fr/chain.sh`, which records its own PID. The chain's outer bound was `timeout -k 10 3600`,
not 600, because it only sequences: each run inside it is bounded at 600 s by run.sh. f35a/f35b ran in a scratch clone
(`fr/clone`, `git clone --shared` of orbit-board at f40eded, board fce8a391 and layout-fits abfe1386 as in the base), with
`evidence-u28/` copied to `recovery/v200/evidence/L6-u28/` and a node_modules link. Nothing was committed there; its
status shows only those two untracked paths.

**PIDs:** `pids.txt` lines 55-125 (71 lines) belong to this round. They cover 36 runs, each `timeout` with its child,
plus the chain's bash and its outer `timeout`. For f03, f05 and f07 the child ended before it could be recorded, so only
their `timeout` is listed. At 9:29 AM ET none of the 125 recorded PIDs was running. Nothing was killed.

### Files of the fix round (git hash-object)

| file | blob | what |
|---|---|---|
| evidence-u28/fc-nosegoe.sh | 3c63a12454d5f5e58fc50ac536fdd8f79c6c331a | F4; replaces fc-nosegoe.sh (8a5d382f, now `superseded/fc-nosegoe.r0.sh`); diff `fr/fc-nosegoe.diff` |
| evidence-u28/fc-gate.sh | b6c79d01dc5cd14142ab4331fb53b68469c919c1 | F5, new |
| evidence-u28/font-env.mjs | e51716ddb97a647861ed7c605e89c398e96d7c2c | F6, F8; replaces probe/font-env.mjs (c679f1ba, now `superseded/font-env.r0.mjs`); diff `fr/font-env.diff` |
| evidence-u28/standin-template.mjs | f7723d3f08bdf30c0c64d719a263d1da0a11a885 | F8; self-contained form of probe/standin-template.mjs (f6149f86, kept as the builder's) |
| probe/visual.mjs | 2a7a60033b442217b75cf88d2b7bcd4e94521fe4 | F10; was 7e3ad1c1 (`superseded/visual.r0.mjs`); diff `fr/visual.diff` |
| probe/alloc-standin.mjs | fab3a9eacebcbad216ef677530f995d36c56ca0e | F2, new (the money verifier's alloc.mjs, adapted) |
| fr/chain.sh | d8faf5622490cf0897b4911e52ce74239dc7060a | the long runs, one after another |
| fr/runs-table.py | 75e813ac35a824f62b64ef470a3ed66b88576b38 | the table above, from logs/runs.txt |
| superseded/README.build.md | a14a416f549986c673cd7a6df5c488981aec4272 | this README as the builder left it |

Inputs, read-only and unchanged: base board fce8a391, tools/layout-fits.mjs abfe1386, tools/font-standin.mjs fd27b0f1,
tools/chrome.mjs d0fbdb8a; /etc/fonts/fonts.conf and 56-prefer-inter.conf (md5 checked before and after f01-f07); the
verifiers' `out/env/E*` configs and `out/m/BM5v/standin106.html` (verify-tests-r1); `out/base/*.html` (the builder's).
Outputs: `fr/fc`, `fr/fcrel`, `fr/fc35` (configs), `out/fr/tpl` (stand-in templates), `out/fr/shots` (visual and
allocation-box shots, `visual-*.json`).

**For the lead to commit (proposal, not adopted; Brad's decision):** copy `evidence-u28/` to
`recovery/v200/evidence/L6-u28/`, the four files with the blobs above. The drafts cite those paths. f35 ran them from
there.

### What I did not do (fix round)

- No board, tool, suite or fixture change; no c1/ copy, no diffs/ entry, no suite block, no mutation entry, no mcount, no
  focused harness, no other suite, no npm run check. Each belongs to a proposed commit, and there is none: the
  must-fixes were text, and the allocation box is left open rather than given a CSS change that would guess at fonts
  nobody here has measured.
- The other 13 verify:grid tools were not run under the setting or the gate (the task allows only layout-fits); the
  drafts say so.
- Real Segoe UI, Edge on Windows, and Safari or Chrome on a Mac or iPad were not measured. So it is not known which
  font draws the allocation box for a user, or which Segoe face draws weight 750. Nothing was downloaded.
- No placeholder check was added to layout-fits (that is a tool change for Brad); Draft 2 names it as an option.
- Did not run the full audit-import or audit-board, mutate.mjs, or playwright install. Nothing was edited, staged,
  committed or pushed in /home/user/orbit-board or /home/user/orbit-ui. The scratch clone `fr/clone` is mine and
  uncommitted.

## Answer

- **Root cause: this container's font settings, not the board.** This image carries
  `/etc/fonts/conf.d/56-prefer-inter.conf` (owned by no package -- `dpkg -S` finds none; dated 3 Oct 05:35:22 UTC, a
  minute before the image's `fonts-inter` 4.0+ds-1 and seven before its Chromium 1194). One of its lines,
  `<alias><family>Segoe UI</family><prefer><family>Inter</family></prefer></alias>`, makes 'Segoe UI' resolve to
  Inter (`fc-match 'Segoe UI'` = Inter-Regular.otf), and Chromium accepts it: every cell in the board's
  `'Segoe UI', Arial, sans-serif` is drawn in **Inter** (CDP `CSS.getPlatformFontsForNode`: Inter-Bold, installed, at
  1023, 940 and 761 px, in every mode and both themes). *[Fix round, F8: the money figures (weights 650, 750) are
  Inter Bold; the dash cells (`.amt.z`, weight 500) are Inter Medium.]* `document.fonts` holds no face at all (the board declares
  none); the computed style is `750 12.5px "Segoe UI", Arial, sans-serif` (Brief: 14.5 px, its presentation density).
  In Inter Bold with tabular figures "$123,456,789" is **87.64 px** at 12.5 px and **101.66 px** at 14.5 px -- 14.6%
  wider than in Arial's widths (76.47 and 88.70 px). Rank's and Fund's money boxes are 80 px at 761-940 and Brief's
  are 92 px (100 px for Brief's Unfunded at 941-1023), so the six J checks fail exactly as the ledger recorded.
- **A real browser does not cut it.** *[SUPERSEDED by the Fix round, F1: too broad. It holds only for the grid money
  cells J measures, in the fonts measured; the same figure in Fund's allocation box is a separate open item, P2.]* No user's browser draws Inter for 'Segoe UI': Windows has Segoe UI, a Mac or
  iPad has Arial. In Arial's widths (Liberation Sans, its metric twin) the figure fits with 3.53 px (Rank, Fund) and
  3.30 px (Brief) to spare at 761-940. In the project's own Segoe model (tools/font-standin.mjs: Liberation Sans with
  Segoe UI's height and size-adjust) it fits at +3% (least room 1.33 and 0.72 px). At +6% -- twice what reproduced
  Edge's measured failures in v1.95 item 57 -- it runs 0.97 px (Rank, Fund) and 1.97 px (Brief) past its box into
  the empty 6-px column gap or the row's padding: nothing clips it and nothing covers it (shots `out/base/shots/`),
  but J's 1-px rule counts Brief's as cut (180 widths, each theme). Segoe UI itself could not be measured here (no
  Windows, no download); how real Segoe UI compares with +6% in Brief is not established.
- **So: (a) container-only. Shape: none -- no board change, no commit.** *[Narrowed by the Fix round, F1: container-only
  for J's six recorded failures; the allocation box is a new P2 row.]* Even in Inter nothing clips the figure: it
  runs 7.64 / 9.66 px past its box, and in Rank and Fund its last 1.64 px runs under the next control (the
  "Unfunded" chip, the allocation box) -- crowded, still readable (`out/base/shots/asis-rank-761.png`).
- **The UI branch already fits, even in Inter.** `claude/v200-ui` (8783a2d, board 5e9e5a5e) sizes these columns for
  itself: least room 2.86 px in Inter and 9.44 px at the +6% stand-in, 0 J failures in Rank, Fund and Brief, both
  themes (probe runs p15, p16). With no board change proposed there is nothing to merge; the base's 940-px block is
  identical on that branch (lines 1200-1236, the 1400/1100/940/760 blocks).

## Measurements (base fce8a391, populated exactly as layout-fits builds it; harbor shown, parchment identical)

Per font: the R019 figure's drawn width (a Range over its text), the least room left in its box over 761-1023, and
the widths J's own `measure()` fails. Controls: every other money cell of R019 and R001, and the Review and Compare
modes -- none cut in any font except where noted. Full table: `out/base/table-harbor.txt`, `table-parchment.txt`.

| font drawn (how) | figure 12.5 / 14.5 px | least room Rank, Fund / Brief | J widths failed Rank, Fund, Brief | controls cut |
|---|---|---|---|---|
| Inter Bold (container as it is) | 87.64 / 101.66 | -7.64 / -9.66 | 180, 180, 263 | 0 |
| Liberation Sans Bold (FONTCONFIG_FILE without the 'Segoe UI' alias) | 76.47 / 88.70 | 3.53 / 3.30 | 0, 0, 0 | 0 |
| Liberation Sans Bold (no Inter alias at all) | 76.47 / 88.70 | 3.53 / 3.30 | 0, 0, 0 | 0 |
| Liberation Sans declared as 'Segoe UI' | 76.47 / 88.70 | 3.53 / 3.30 | 0, 0, 0 | 0 |
| Segoe stand-in +0% | 76.47 / 88.70 | 3.53 / 3.30 | 0, 0, 0 | 0 |
| Segoe stand-in +3% | 78.67 / 91.28 | 1.33 / 0.72 | 0, 0, 0 | 0 |
| Segoe stand-in +6% | 80.97 / 93.97 | -0.97 / -1.97 | 0, 0, 180 | 0 |
| DejaVu Sans Bold declared as 'Segoe UI' | 96.48 / 111.92 | -16.48 / -19.92 | 180, 263, 263 | 0 |

Every stand-in run passed the base tool's own `standinProblem()` (the stand-in is the font drawn, Segoe's height);
CDP names Liberation Sans for it. The least room is at 761-940 (boxes 80 and 92 px); at 941-1023 Rank's and Fund's
boxes are 90-100 px (the figure fits there in every font but DejaVu). DejaVu is shown only as a bound: no user's browser falls to it before Arial.

## layout-fits itself, on the base (the only verify:grid tool run, one at a time)

| run | how | result |
|---|---|---|
| L1 | as the container is | exit 1: 48 ok, the six recorded FAILs (J harbor/parchment rank, fund 180 widths; brief 263) |
| L2 | `FONTCONFIG_FILE=<fc-nosegoe>/fonts.conf` | exit 0: 54 ok, "The layout holds" |
| L3 | `--board` = the board with the Segoe stand-in +6% (withStandin) | exit 1: 52 ok, J harbor brief and parchment brief, 180 widths each |
| L4 | `--board` = the board with the Segoe stand-in +3% | exit 0: 54 ok |

The stand-in survives the populated save (p11: `id="segoe-standin"` and `size-adjust:106%` in the built file).

## (a) How verify:grid must be run here to measure what Brad's users see

*[SUPERSEDED by the Fix round, F3-F6: this is a proposal, not adopted (Brad's decision). Use the hardened copies in
`evidence-u28/`, and only through `fc-gate.sh`. The `fc-nosegoe.sh` and `probe/font-env.mjs` named below moved to
`superseded/`.]*

1. Once per container: `fc-nosegoe.sh <dir>` writes `<dir>/fonts.conf` -- the image's own fontconfig, every file of
   `/etc/fonts/conf.d`, with only the one 'Segoe UI' -> Inter alias line left out. Nothing in /etc changes; every
   other alias (sans-serif, system-ui ... -> Inter) stays.
2. Before trusting a run: `FONTCONFIG_FILE=<dir>/fonts.conf node probe/font-env.mjs` must say OK (exit 0): Chromium
   draws 'Segoe UI', Arial, sans-serif in Liberation Sans, 76.47 px for the figure, the same as Arial. As the container
   is, it exits 1 naming Inter-Bold, 87.64 px (p17, p18).
3. `FONTCONFIG_FILE=<dir>/fonts.conf npm run verify:grid`. No tool gives Chromium an environment of its own: all 14
   launch it with the default one (checked: no `env:` in any `chromium.launch`), so the variable reaches
   every tool. The Segoe stand-in passes of dropdowns-visible and editors-reachable are unchanged by it: the stand-in
   is a declared web font (p19: the same 80.97 / 93.97 px under the variable).

Why this does not weaken a tool: no tool, check, threshold or fixture changes. The tools' own headers say their
first pass measures in Liberation Sans (Arial's widths) -- what a Mac or iPad shows -- and two of them add a Segoe
stand-in pass at +6% for Windows. This image made that first pass Inter, a font no user has for 'Segoe UI'. Said
plainly: Inter is wider than Arial, so since this image a first pass here was harsher on width than designed; the
Windows margin stays covered only where it was before (dropdowns-visible, editors-reachable). layout-fits has no
stand-in pass.

## Decisions, with reasons

- No board change (shape none): the figure is not cut in any font a user's browser draws (Arial: 3.3 px room;
  Segoe model +3%: 0.72 px; +6%: past its box by 1.97 px into an empty gap, nothing clipping or covering it).
  Principle 5 (smallest change) and 2 (refuse or ask rather than guess Segoe's real widths).
- No tool change: the task asked how to run the tools, not to change them; adding a +6% stand-in pass to layout-fits
  would fail Brief today (L3), which is a decision for Brad, not a finding to fix silently.
- The environment fix leaves out one alias line only, not the whole Inter file, so nothing else on the page moves.
- **For Brad (not built):** whether layout-fits J should hold at the +6% stand-in like the drop-down and editor
  checks. If yes, Brief's four money columns at 761-940 (`:root[data-mode="brief"]` in the `max-width:940px` block,
  92 px) need at least 94 px to hold the +6% figure inside its box (93.97 px); the UI branch's own layout already
  does (9.44 px room at +6%). Not built, not measured on the base, no merge checked.

## Draft: text to append to UNRESOLVED-LEDGER.md row U28

*[SUPERSEDED by the Fix round's drafts below.]*

Investigated <time> ET (U28 builder, `rec/L6/u28`, read-only on the board; recorded at <sha>): **container-only.**
This image's `/etc/fonts/conf.d/56-prefer-inter.conf` (no package owns it; dated 3 Oct, 05:35 UTC) resolves
'Segoe UI' to Inter, and Chromium draws the rows' money in Inter Bold: "$123,456,789" is 87.64 px at 12.5 px in an
80-px box (Rank, Fund, 761-940) and 101.66 px at 14.5 px in Brief's 92-px box, 14.6% wider than in Arial's widths
(76.47, 88.70). With that one alias line left out (FONTCONFIG_FILE; nothing in /etc or the tools changed) Chromium
draws Liberation Sans and layout-fits passes 54 of 54 on 7ee498a; as the container is, 48 pass and the six J checks
fail as recorded. In the Segoe stand-in the figure fits at +3% (least room 0.72 px, Brief); at +6% Brief's runs
1.97 px past its box into the empty column gap (nothing clips or covers it) and J fails Brief at 180 widths in each
theme. No user's browser draws Inter for 'Segoe UI'; real Segoe UI was not measured. `claude/v200-ui` (8783a2d)
fits at every width even in Inter. Severity: P3 (container-only); no board change. verify:grid is to be run here as
`FONTCONFIG_FILE=<dir>/fonts.conf npm run verify:grid` after `rec/L6/u28/fc-nosegoe.sh <dir>` and
`probe/font-env.mjs` says OK. Open for Brad: whether J should hold at the +6% stand-in (Brief would need 94-px money
columns at 761-940).

## Draft: NEXT-VERSION.md (optional; U28 has no line in "Unresolved after R1-R5" to replace)

*[SUPERSEDED by the Fix round's drafts below.]*

  - **U28 (P3, this container only):** verify:grid's layout-fits section J fails here because the container draws
    'Segoe UI' in Inter, 14.6% wider than Arial for these figures; no user's browser does. In Arial's widths and in
    a Segoe-like stand-in at +3% every width 761-1023 fits; at +6% Brief's nine-digit figure runs 2 px past its
    column into the empty gap. verify:grid runs here with that one font alias left out. No board change.

## Runs (each `setsid -w timeout -k 10 600`, via `run.sh`; lock checked before every one -- never present)

| label | start (ET) | exit | wall s | log |
|---|---|---|---|---|
| p01-build-base | 12 Oct 19:56:23 ET | 0 | 3.3 | logs/p01-build-base.log |
| p02-variants-base | 12 Oct 19:56:26 ET | 0 | 0.3 | logs/p02-variants-base.log |
| p03-measure-base-asis | 12 Oct 19:56:31 ET | 0 | 136.8 | logs/p03-measure-base-asis.log |
| p04-measure-base-nointer | 12 Oct 19:58:56 ET | 0 | 133.1 | logs/p04-measure-base-nointer.log |
| p05-measure-base-standin106 | 12 Oct 20:01:17 ET | 0 | 134.1 | logs/p05-measure-base-standin106.log |
| p05-measure-base-standin103 | 12 Oct 20:03:31 ET | 0 | 133.7 | logs/p05-measure-base-standin103.log |
| p06-visual-base-asis | 12 Oct 20:06:50 ET | 0 | 8.1 | logs/p06-visual-base-asis.log |
| p07-visual-base-standin106 | 12 Oct 20:07:16 ET | 0 | 7.8 | logs/p07-visual-base-standin106.log |
| p08-visual-base-nointer | 12 Oct 20:07:24 ET | 0 | 8.0 | logs/p08-visual-base-nointer.log |
| p09-measure-base-standin100 | 12 Oct 20:09:07 ET | 0 | 129.0 | logs/p09-measure-base-standin100.log |
| p09-measure-base-liberation | 12 Oct 20:11:16 ET | 0 | 139.2 | logs/p09-measure-base-liberation.log |
| p09-measure-base-dejavu | 12 Oct 20:13:35 ET | 0 | 142.3 | logs/p09-measure-base-dejavu.log |
| p10-tpl-standin103 | 12 Oct 20:16:09 ET | 0 | 0.2 | logs/p10-tpl-standin103.log |
| p10-tpl-standin106 | 12 Oct 20:16:10 ET | 0 | 0.3 | logs/p10-tpl-standin106.log |
| p11-build-from-standin106-template | 12 Oct 20:16:10 ET | 0 | 4.6 | logs/p11-build-from-standin106-template.log |
| p12-measure-base-nosegoe | 12 Oct 20:16:32 ET | 0 | 91.0 | logs/p12-measure-base-nosegoe.log |
| L1-layout-fits-base-default | 12 Oct 20:18:10 ET | 1 | 239.6 | logs/L1-layout-fits-base-default.log |
| L2-layout-fits-base-nosegoe | 12 Oct 20:22:14 ET | 0 | 206.1 | logs/L2-layout-fits-base-nosegoe.log |
| L3-layout-fits-base-standin106 | 12 Oct 20:25:45 ET | 1 | 204.9 | logs/L3-layout-fits-base-standin106.log |
| L4-layout-fits-base-standin103 | 12 Oct 20:29:16 ET | 0 | 204.7 | logs/L4-layout-fits-base-standin103.log |
| p13-build-ui | 12 Oct 20:33:29 ET | 0 | 5.3 | logs/p13-build-ui.log |
| p14-variants-ui | 12 Oct 20:33:35 ET | 0 | 0.6 | logs/p14-variants-ui.log |
| p15-measure-ui-asis | 12 Oct 20:33:40 ET | 0 | 76.6 | logs/p15-measure-ui-asis.log |
| p16-measure-ui-standin106 | 12 Oct 20:35:10 ET | 0 | 74.3 | logs/p16-measure-ui-standin106.log |
| p17-font-env-default | 12 Oct 20:38:11 ET | 1 | 2.2 | logs/p17-font-env-default.log |
| p18-font-env-nosegoe | 12 Oct 20:38:13 ET | 0 | 2.1 | logs/p18-font-env-nosegoe.log |
| p19-measure-base-standin106-nosegoe | 12 Oct 20:38:22 ET | 0 | 28.3 | logs/p19-measure-base-standin106-nosegoe.log |

Exit 1 in L1, L3 and p17 is the finding being measured, not a fault. No run timed out or was skipped. PIDs: every
run's `timeout` and its child are in `pids.txt` (54 lines, 27 runs); all had ended when checked at the end. Nothing
was killed.

## Files and blobs (git hash-object)

| file | blob | what |
|---|---|---|
| run.sh | 69128ac0 | bounded runner (copied from rec/L6/u9/run.sh, only U changed) |
| fc-nosegoe.sh | 8a5d382f | writes the fontconfig without the 'Segoe UI' alias *[fix round: moved to superseded/fc-nosegoe.r0.sh; use evidence-u28/fc-nosegoe.sh]* |
| probe/build.mjs | 4364ba46 | the populated board, layout-fits lines 44-58 and 64-75 copied verbatim by sed |
| probe/variants.mjs | 0c0bca71 | the same board in each font (stand-ins by the base's own withStandin) |
| probe/measure.mjs | 98a69755 | J's measure() (layout-fits 296-316, verbatim but two spaces less indent) + cell widths + CDP fonts |
| probe/visual.mjs | 7e3ad1c1 | clip / overlap test and row screenshots *[fix round: now 2a7a6003, F10]* |
| probe/standin-template.mjs | f6149f86 | the board template with the stand-in, for layout-fits --board |
| probe/font-env.mjs | c679f1ba | the pre-check: which font Chromium draws here *[fix round: moved to superseded/font-env.r0.mjs; use evidence-u28/font-env.mjs]* |
| probe/table.py | 789d6b35 | the table above, from the probe's JSON |

Inputs (read-only): base board fce8a391, tools/layout-fits.mjs abfe1386 (the same blob the ledger's evidence ran),
tools/font-standin.mjs fd27b0f1 (identical on claude/v200-ui), claude/v200-ui board 5e9e5a5e and its layout-fits
2ee21034 (J's measure() identical to the base's). Chromium 141.0.7390.37 (/opt/pw-browsers/chromium -> chromium-1194),
playwright-core 1.63.0. Outputs: `out/base/` (populated board, font variants, m-*.json, tables, 48 shots),
`out/ui/` (the UI branch's populated board, variants, m-*.json).

## What I did not do

- No board, suite or tool change; so no copies (c1/...), diffs, suite blocks, mutation entries, focused harnesses,
  mutants, mcount, other suites or npm run check -- each applies to a proposed commit and there is none.
- Ran no verify:grid tool but layout-fits (as instructed). The other 13 have **not** been run under
  `FONTCONFIG_FILE`; the lead should run verify:grid once each way and compare before adopting it.
- Did not measure real Segoe UI (not installed; nothing downloaded) or any Windows/Mac browser.
- Did not run the full audit-import or audit-board, mutate.mjs, or playwright install.
- Resuming: this directory did not exist when I started (7:51 PM ET), so there was nothing from an earlier attempt
  to keep or re-run; everything here is from this run.
- orbit-ui shows `ui-concept/CHUNK3.md` modified (00:33 UTC) and an untracked node_modules: neither is mine.
