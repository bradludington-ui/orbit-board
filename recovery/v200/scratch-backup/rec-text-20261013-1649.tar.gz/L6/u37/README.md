# U37 — no export writes a character XML 1.0 forbids (every workbook, the slide deck, the chart image): refused, and the place named

Builder's record for ORBIT v2.00 release track **U37** (ledger row U37, P1, a release blocker by the lead's decision of
13 Oct, 12:02 PM ET). **One commit is proposed. Nothing is committed, staged or pushed anywhere, and nothing in
`/home/user/orbit-board` or `/home/user/orbit-ui` was edited** (both were read only: the ledger row, the running notes, a
`git clone --shared` for scratch runs). All times are Eastern (`TZ=America/New_York date`). The board stays the empty
template; every run builds its synthetic data at run time.

This is the **third** builder on this track (the second start, 13 Oct). It started at 2:44 PM ET on 13 Oct, from the
directory the earlier builder left when a usage limit stopped it at about 2:29 PM ET (see "Resuming" below).

**Status (written 3:55 PM ET, 13 Oct; every run below has finished, the last ended at 3:53:39 PM ET):** one commit proposed, on
the copy `c1/`. Every route that writes XML for a person -- the 16 `buildXlsx` workbook routes, the slide deck
(`buildPptx` → exportPPT) and the funds-flow chart's Save as image -- now refuses a character XML 1.0 forbids before any
byte, Blob, download, word of success or change of state, and says where it is. The U37 block: **84 of 84 pass on `c1`,
60 fail on the base** (the 24 that pass on both are the controls and the no-page-error check); **35 of 35 new mutants caught**; mutation text counts
1,328/1,328 on the base and 1,363/1,363 on `c1` and on `c1` + U41/U42; every other suite, `npm run check` and the whole
audit-recon exit 0 on `c1` as on the base, with the same output (timings and the board's own line count aside); every
export on ordinary data is byte-identical to the base's (17 routes). One cost the lead should weigh is in decision 2: a
`_x000b_` spelling imported from a LibreOffice-written workbook now refuses the workbook routes that carry it (two in the probe: exportFlow and exportRlgPlan). Nothing
is committed, staged or pushed.

## The proposed commit

**1: `v2.00 (U37): no export writes a character XML 1.0 forbids -- refused before a byte, the place named`**

| | |
|---|---|
| Copy | `c1/` = base `7ee498a` (product `d66dd60`, U14) + this commit (`cp -a` of `../base`, node_modules symlink kept) |
| Board `prioritization-board-grid.html` | `d75ea5ed52ea3d51211a00e04426b10d9d00d4e1` (base `fce8a391…`) |
| `tools/export-audit/audit-recon.mjs` | `2e61a21d070c24049aa9aa79f14be40d8fa51dd0` (base `529e36f7…`) |
| `tools/export-audit/mutate.mjs` (kept here as `mutate.mjs.txt`) | `efd83f430f82092147e3fe0bee7429c0472976df` (base `cbc6defc…`) |
| Other files | byte-identical to the base (`diff -rq ../base c1`: only these three differ) |
| Diffs against the base | `diffs/c1-prioritization-board-grid.html.diff`, `diffs/c1-audit-recon.mjs.diff`, `diffs/c1-mutate.mjs.txt.diff`, all three in `diffs/c1.diff` |
| Diffs against the earlier attempt's copy | `diffs/prev-c1-to-c1-*.diff` (what this builder changed in `prev/c1`) |

Suggested commit message body (the lead's to adjust):

```
v2.00 (U37): no export writes a character XML 1.0 forbids -- refused before a byte, the place named

_xesc escaped & < > " only, so U+0000-U+0008, U+000B, U+000C, U+000E-U+001F, U+FFFE and U+FFFF went into
a workbook part or a slide as they were, and the part was not well-formed XML (an ordinary paste keeps
several of them). Every workbook (buildXlsx: each sheet name as written, each text cell) and the deck
(buildPptx: each slide) are now checked before a byte is made; such a character, or in a workbook a
literal _xHHHH_ (a spreadsheet reads it as the character it spells), refuses the export, and the alert
and the status line name the sheet and cell, or the slide, its title and the text. All 16 workbook routes
and exportPPT return on the refusal, before a Blob, a download, their own word or the IDS ORG; the open IDS
box drops an earlier prompt problem. The funds-flow chart's Save as image, an SVG read back as an XML
image, is refused before its Blob the same way. Nothing is cleaned or cut; an export without such text is
byte for byte what it was. From Codex's A2 refusal, after review, extended to the deck and the chart image.

audit-recon "v2.00 (U37)": 84 checks, 60 fail on 7ee498a (the 24 that pass on both are the controls and the no-page-error check). 35 mutations.
```

## What was wrong, measured on the base (`7ee498a`)

The one text writer both exports use, `_xesc` (`function _xesc(s){return (''+s).replace(/&/g,'&amp;')...replace(/"/g,'&quot;');}`),
escapes `& < > "` and nothing else. So U+0000–U+0008, U+000B, U+000C, U+000E–U+001F, U+FFFE and U+FFFF went into a
workbook part, or a slide, as they were, and that part was not well-formed XML. Evidence (all synthetic, all on the base
board `fce8a391`):

- **Every workbook route writes it raw.** `logs/P-repro-base.log` (earlier attempt, kept): each of the 31 characters in a
  cell is written raw into `xl/worksheets/sheet1.xml`; a sheet name `Ctl<U+000B>` goes raw into `xl/workbook.xml`. A Plan
  Event typed through the board's own prompt (`editTitle`) as `Plan<U+000B>event`, with an RCN title holding U+0001 and
  U+000B: exportExcel writes it into Decision Bands, CR Cash Needs, RCN-EEIC by Month, Funded - Discretionary and PMO AV;
  exportCSV into 1-N by Band and AV; exportSrc into O&M Raw Data; exportPPT into `ppt/slides/slide5.xml`; a destination
  named `Ctl<U+000B>` puts it into three sheets of exportFlow's workbook. `logs/P-where2-base.log`: the first such cell per
  route (Decision Bands H18, 1-N by Band E5, O&M Raw Data D2, Funds Flow A40, the IDS workbook's Missing data and anomalies
  C24) -- the places the new block expects to be named.
- **The parts do not parse.** `logs/X-xmlcheck-base.log` (Python's expat over every part): 5 sheets of the Excel export, 2
  of the Priority drill, 1 of the Spend Plan Source, 3 of the Funds Flow workbook and slide 5 of the deck are "not
  well-formed (invalid token)"; a lone U+D800 is written by the encoder as U+FFFD and parses.
- **LibreOffice 24.2 loses data without a word.** `logs/LO-csv-base.log`, `logs/LO-3-base.log`, `probe/lo-base*/`: a
  one-sheet workbook whose B1 holds `a<U+000B>b` converts to `900` -- the sheet cut off at that cell; the Spend Plan Source
  row loses everything from the Title on; the deck's slide 5 keeps its header and "1 AV" and loses the rest of the Mission
  Critical table, its TOTAL row and its MC SHORT row.
- **The slide deck too** (the gap the lead named): `logs/P-repro-base.log` "R exportPPT … ppt/slides/slide5.xml 000B".
- **The funds-flow chart image** (found here): flowPng serialises the drawn chart (`el.outerHTML`) into an SVG Blob and loads
  it as an image, which is an XML document. In Chromium (`logs/P3-png-base.log`, 3:18 PM ET): with a drawn text holding
  U+000B nothing downloads and the board says only "⚠ Could not render the chart to an image."; the CONTROL chart
  downloads its PNG. In jsdom the chart, its panel open, draws a destination named `Ctl<U+000B>` as typed, twice (a label
  read aloud and the drawn name; `logs/P3-chart-base-r2.log`).
- **How it gets there:** Chromium 141 keeps U+000B, U+0001, U+0007 and U+001F pasted into a text field (the regtext
  track's `FR-vpaste-chromium.log`, cited by the ledger row); and a workbook another program saved can carry the escape
  spelling: **LibreOffice saves a U+000B in a cell as `_x000b_`** (`logs/LO-cr-xlsx.log`, `logs/LO-src-xlsx-r2.log`,
  `probe3/out/`), which the board's reader keeps as written (below).
- **A literal `_xHHHH_`** in a workbook cell is read by a spreadsheet as the character it spells: LibreOffice shows
  `_x0041_ and _x000B_` as "A and <U+000B>" (`probe/lo-base/L-literal.csv`), `_x00e9_` as "é"; `_X0041_`, `_x41_`,
  `_x0041`, `x0041_` stay as written (`probe/lo-base2/L2-spellings.csv`). The deck shows `_x0041_ deck` as typed
  (`probe/lo-base2/L3-literal.txt`).

## Every place the board writes XML or another structured file for a person (inventory)

Read from the base source (grep of `_xesc(`, `_zipStore(`, `buildXlsx(`, `buildPptx(`, `<?xml`, `.download=`, `new Blob(`):

| Writer | What it makes | XML? | In this commit | How it is checked |
|---|---|---|---|---|
| `buildXlsx` (16 callers: exportRlgPlan, pmoReport, crExport, exportIdsReq, exportFlow, exportExView, exportSrc, exportPlans, exportFydpPlan, exportCycCompare, exportReprog, exportFcView, exportCSV, exportAceTieout, exportExcel, exportCoa) | .xlsx | yes | `_xlsxRefused` before any part; each caller returns on `null` | test: D section (all 16, made on ordinary data, then stopped by a stand-in refusal); C section (real refusals on exportExcel, exportCSV, exportSrc, exportFlow, exportIdsReq) |
| `buildPptx` (1 caller: exportPPT) | .pptx | yes | `_pptxRefused` over the built slides; exportPPT returns on `null` | test: B1 (real, slide 5), D (stand-in), B2 CONTROL |
| `flowPng` (Save as image) | .png, drawn from the chart's SVG read back as an XML image | the SVG is | checked before its Blob | test: C7 (real: the chart draws the destination), D CONTROL; Chromium probe |
| `_zipStore` | the zip container | — | — | read: called only by buildXlsx and buildPptx |
| `_stylesXml` number formats and fills | `xl/styles.xml` | yes | not checked | read: every `fmt` is a board constant (`SRC_XTRA`, `IDS_XTRA`, `'0'`…); every fill is a constant or a band colour, which the band import holds to `/^#[0-9a-fA-F]{6}$/` and no editor types freely |
| `TPL_PARTS` (the deck template) | pptx parts | yes | not checked | constants (base64 in the board, hash in `tools/tpl-parts.sha256`) |
| exportProposedOrder, Exec Funding Synopsis | .csv | no | unchanged | read: `csvCell` quotes every cell; CSV has no forbidden character |
| board files, PMO copy, kept-aside work, packages, band ladder, diagnostics | .html, .json, .txt | no | unchanged | read: state goes in as `JSON.stringify` (which escapes U+0000–U+001F) |

## The change (board, `diffs/c1-prioritization-board-grid.html.diff`)

1. **`XML_BADCH`, `_xmlBad`, `_xmlShow`, `_xmlRefuse`, `_xlsxRefused`** (before `buildXlsx`): every sheet name as it is
   written (its first 31 characters) and every text cell is checked before a byte is made. A forbidden character -- or,
   in a workbook, a literal `_xHHHH_` -- refuses: an alert and the status line say what was refused, where (the name of
   sheet N, or sheet “…”, cell X9), what it holds, and the text around it with each forbidden character spelled out
   (`[U+000B]`). `buildXlsx` returns `null`.
2. **`_pptxRefused`** (before `buildPptx`): each built slide is searched; the slide number, its title (its first `<a:t>`)
   and the text run that holds the character are named. `buildPptx` returns `null`.
3. **Each of the 17 callers** returns on `null` before its Blob, its download and its own word (`if(!bytes) return;`).
   exportIdsReq returns `false`, before the ORG typed into the prompt is kept, and clears an earlier prompt problem from
   the open IDS box and redraws it (`idsLast=null; if(idsOpen) idsBody();`).
4. **`flowPng`**: the serialised chart is checked before its Blob; refused naming the drawn text that holds the character
   (a leaf's text first, then a label read aloud -- never the markup around it).

The words, for example: "Excel workbook not exported: sheet “Decision Bands”, cell H18 holds character U+000B, which
ORBIT cannot write into a workbook without damaging it. It reads “Plan[U+000B]event”. No file was made, and the text on the
board is unchanged. Change that text where it was entered — on the board, or in the file it was imported from — and
export again." Status line: "⚠ **Excel workbook not exported** — sheet “Decision Bands”, cell H18 holds character
U+000B, … It reads “Plan[U+000B]event”. No file was made; the text on the board is unchanged."

## Decisions, with reasons (and how each meets the lead's principles)

1. **Refuse, not escape** (Codex's A2 choice, which the lead accepted "unless you find evidence against it"). The OOXML
   `_xHHHH_` escape would let a workbook carry U+000B, but the board's own reader (`xlsxRead` → `_xunesc`) keeps
   `_xHHHH_` as written, and the board can read its own workbooks back (its Spend Plan Source export has the tabs and header the CCaR QPE
   import reads), so
   escaping would change what the board reads back from its own files; changing the reader would change how every
   workbook it already reads is read. No evidence was found against refusing a forbidden character: nothing is lost (the
   text stays on the board, nothing is written), and the base's files lose data silently (LibreOffice above). The deck has
   no reader in the board; it follows the same rule.
   *Principles:* (1) no copy of anyone's work is touched -- the refusal changes nothing (checked: MS, S, DIRTY and every
   browser-storage key byte-identical across each refusal; the IDS ORG not kept); (2) it refuses and says so rather than
   guessing a repair; (3) no file can now differ from the board; (4) the words were checked for truth (item 6); (5) one check
   per writer and one guard line per caller; (6) no existing check, fixture or expected value was edited -- the block and the
   entries are appended.
2. **A literal `_xHHHH_` refuses a workbook too** (as Codex). Evidence for: LibreOffice reads `_x0041_` as "A" and
   `_x000B_` as U+000B, so the cell would not say what the board says (principle 3). **Evidence weighed against, and what
   was changed because of it:** LibreOffice saves a U+000B in a cell as `_x000b_` (`logs/LO-cr-xlsx.log`; the OOXML escape for a
   character XML cannot hold -- Excel itself was not run); the board's reader keeps that spelling as written, so text imported
   from such a workbook (a CCaR QPE through importSrc) carries it, and the board has no editor for imported execution rows.
   `probe3/imp.mjs` imports a LibreOffice-written Spend Plan Source whose title held U+000B: the board holds
   "Engine_x000b_spares", and of the 14 routes run after that import, two carry the title: on the base, exportFlow (OGC Detail A2, and A2 of `xl/worksheets/sheet5.xml`) and exportRlgPlan (Funding plan E9) write it as it is -- a spreadsheet then shows U+000B where the board shows `_x000b_` -- and on `c1` both are refused, naming that cell and the text; ten make their files as before, and two make none on either board for reasons of their own (no cycle picked, no estimate imported) (`logs/P3-imp-base.log`, `logs/P3-imp-c1.log`). So the refusal stays (the file would otherwise say something the board does
   not), but the advice no longer says "Change that text on the board" -- it says "Change that text where it was entered —
   on the board, or in the file it was imported from — and export again" (principle 4). This is a real cost the lead should
   see: an office whose source workbook carries such a spelling cannot export the routes that carry that text until the
   source is corrected and imported again. The reader is not changed here (it would change how every workbook already
   imported reads; outside U37); "Not covered" says so.
3. **Half of a two-part character (a lone surrogate) is NOT refused** -- unlike Codex, and unlike the finding's text
   ("also … lone surrogates"). Evidence: the encoder writes U+FFFD in its place, which XML allows (`logs/X-xmlcheck-base.log`:
   `W-cell-D800.xlsx` parses), and the board's own cuts make one out of a whole emoji. With Codex's patch applied
   (`codex/applied/`), `logs/P-repro-codex2.log` C1–C2: **the Excel export is refused** for a requirement titled with 43
   letters and a rocket (CR Cash Needs cuts titles at 44), and **the Priority drill is refused** for a PMO named with 30
   letters and a rocket (its sheet name is cut at 31) -- ordinary text the person did not get wrong. The deck cuts at 56
   (C3). Refusing would block those exports; not refusing writes U+FFFD where the board's cut left half an emoji, which is
   what the board itself shows there. U42's track fixes the funds-flow sheet-name cut; the others are said in "Not covered".
   The IDS prompt's own `IDS_BADCH` still refuses a lone surrogate typed into the IDS reason (unchanged).
4. **TAB, LF and CR are left as they were** (Codex's `_xlXml` wrote them as `&#9;`, `&#10;`, `&#13;`). They are allowed
   by XML, so they are not U37; writing references would change the bytes of every export that holds a line break
   (`logs/P3-same-*.log` shows c1's files byte-identical to the base's on ordinary data, a TAB in a title included). A
   standards reader turning a cell's CR into LF, and a TAB or LF in a sheet name into a space, is said in "Not covered".
   A7 (a CONTROL) and `v200-u37-cr-refused` hold that a carriage return is not refused.
5. **A sheet name is checked as it is written** (its first 31 characters, as `buildXlsx` writes `s.name.slice(0,31)`),
   not whole (Codex checked the whole name): a character past the 31st never reaches the file. A3b (CONTROL) and
   `v200-u37-name-past-31`.
6. **The words.** The earlier attempt said "which a workbook cannot hold"; a workbook can hold U+000B (as `_x000B_`), so
   that was not true. Now: "which ORBIT cannot write into a workbook (a deck) without damaging it", and for the chart
   "which ORBIT cannot draw into an image". The advice names the imported file (item 2). Each refusal names the place a
   person can find: the sheet and cell (the cells the base actually wrote, read off its own files), or the slide number,
   its title and the text, or the chart's drawn text; the text is quoted with each forbidden character spelled `[U+000B]`.
   Naming the requirement or field was not added: `buildXlsx` sees only rows, and a column's header is not reliably one row
   above (not cheap and true).
7. **The IDS box.** The earlier attempt returned `false` from exportIdsReq on the refusal without touching `idsLast`, so an
   open IDS box kept saying "Not made yet. • give the reason for this export …" after the reason was given and the real
   reason was U+000B (principle 4, "after the operation lands"). Now `idsLast=null; if(idsOpen) idsBody();` before
   returning. C6 and `v200-u37-ids-stale-note`; the earlier attempt's board fails C6 (`logs/F3-prev-c1.log`).
8. **The chart image is in this commit** although its file is a PNG: its route writes the chart as SVG (XML) into a Blob
   and asks the browser to read it back; the base made that Blob and said only "Could not render the chart to an image"
   (Chromium, measured). The lead asked for every export route to refuse before any Blob and name the place. 11 lines, 4 of them comment.
9. **Number formats and fills are not checked** (Codex checked formats): each is a board constant or a band colour held
   to `#RRGGBB` (read; table above). Checking them would be code for a case no person can reach.
10. **Every caller is guarded, by test where reachable.** All 16 `buildXlsx` routes and exportPPT are run on ordinary data
    (each makes its file) and then with the writer's check standing in as a refusal (each stops: no Blob, no download, no
    word after the refusal, nothing changed); each guard has its own mutation. Real refusals are driven through exportExcel,
    exportCSV, exportSrc, exportFlow, exportIdsReq, exportPPT and flowPng. That nothing else reaches `_zipStore` is by
    reading.

## Resuming: what was kept from the earlier attempt, and what was re-run

The earlier builder on this track worked from about 1:29 PM ET (its first recorded run) until the usage limit at about
2:29 PM ET on 13 Oct; its last recorded run started 2:20:54 PM ET. (An entry in the brief speaks of a stop at about
6:16 PM ET on 12 Oct; nothing in this directory is from 12 Oct -- `c1/`'s directory dates come from `cp -a` of `../base`.)
The lead checked at 2:44 PM ET that none of its processes was running; this builder killed nothing and touched no PID in
`pids.txt` (live PIDs there belong to other agents after reuse).

**Read and kept (sound):**
- Its review of Codex's A2 (`codex/` -- read as text; none of Codex's scripts was run, its runner.py included) and its
  design: `XML_BADCH`, `_xmlBad`, `_xmlShow`, `_xmlRefuse`, `_xlsxRefused` (names as written, text cells), `_pptxRefused`,
  the 17 guards, the IDS ORG kept only after the file exists. Its board (`prev/c1`, blob `1434000c`) was checked against the
  base hunk by hunk: base + exactly those hunks, nothing else changed (`diff -rq`: three files). The new `c1` board is built
  from it by `bin3/board3.py` and `bin3/board3b.py` (each edit asserted to match once); `diffs/prev-c1-to-c1-*.diff` show
  every line this builder changed.
- Its suite block (79 checks) and its 29 mutation entries, as the starting point (`bin3/block3.py`, `bin3/block3b.py`,
  `bin3/block3c.py`, `bin3/mkentries3.py` show every change).
- Its probes and logs **on the base**, all complete with an exit record: `P-repro-base`, `P-repro-codex2` (Codex's applied
  board), `X-xmlcheck-base`, `LO-csv-base`, `P-lit-base`, `LO-2-base`, `LO-3-base`, `P-reach-base`, `P-reach2-base`,
  `P-domp`, `P-where-base`, `P-where2-base`. The base did not change, so they still stand; their scripts (`probe/*.mjs`,
  `probe/xmlcheck.py`) were read before being relied on.
- Its **base** suite runs in `work/clone-base` (HEAD `7ee498a`, every tracked file unmodified, checked): `S-base-boot-same`,
  `S-base-audit`, `S-base-audit-ppt`, `S-base-audit-other`, `S-base-legacy-fsrc`, `S-base-audit-hostile`,
  `S-base-audit-inject-r2`, `S-base-check-r2` -- each exit 0 with its end record. They are the base side of the suite
  comparison below.

**Not relied on, re-run, or superseded:**
- `S-base-audit-inject` (no end record; its `-r2` is complete) and `S-base-audit-recon-r2` (hit the 600 s cap under load,
  exit 124) -- base audit-recon re-run here (`S3-base-audit-recon`).
- Every run on the earlier `c1` (focused `F1-*`, the 29 mutants `M-c1-*`, `P-same-c1`, all `S-c1-*`): superseded, because
  this builder changed the board, the block and the entries. The earlier copy, harness, mutants, diffs and drafts are kept
  in `prev/` for reference only; their logs stay in `logs/` and `out/` under their own labels.
- `P-repro-codex` (exit 1, its own probe's bug, re-run by it as `-codex2`).

**What this builder changed in the earlier attempt's work, and why:**
1. The words "which a workbook/deck cannot hold" → "which ORBIT cannot write into a workbook/deck without damaging it"
   (not true as written: a workbook can hold U+000B as `_x000B_`).
2. The advice "Change that text on the board" → "where it was entered — on the board, or in the file it was imported from"
   (imported execution rows have no editor on the board; LibreOffice-written workbooks carry `_x000b_`; measured).
3. exportIdsReq's refusal left an earlier prompt problem in the open IDS box as the reason (found by reading `idsLast`;
   measured: the earlier board fails the new C6 check).
4. The funds-flow chart image (flowPng), which the earlier attempt left as "Not covered", is refused and named.
5. New checks: A3b and A7 (CONTROLs), C6 (the IDS box), C7 and a D CONTROL (the chart image); new entries
   `-ids-stale-note`, `-name-past-31`, `-cr-refused`, `-advice-board-only`, `-png-unchecked`, `-png-markup`; the two IDS
   entries' finds follow the new guard line.

## Tests: the audit-recon block

`tools/export-audit/audit-recon.mjs`, block `// ==== v2.00 (U37): no export writes a character XML 1.0 forbids; it is refused
before a byte, and says where ====` … `// ==== end v2.00 (U37) ====`, appended after the U14 block and before the scenario-ran
guard, in the existing v2.00 blocks' frame (async wrapper, `bootMark()` / `bootRelease(__bm, [])` / `settleBoards()` as
audit-recon's v2.00 blocks write it, the two-space `  const name = '…';` line, `w5Chk` so `SUITE_CHECKS` records each
check). Scenario: "v2.00 (U37) — no export writes a character XML 1.0 forbids; it is refused before a byte, and says
where". **84 checks**, in five parts (the header comment in the block says each):

- **A, the writer** (38): each of the 31 characters in a cell (no workbook, `_zipStore` never reached, the sheet, cell and
  character named, nothing changed); the words, whole (alert and status line); a sheet name; a literal `_xHHHH_` in a cell
  and a sheet name. CONTROLS: escape-like spellings a spreadsheet reads as written (`_X0041_`, `_x41_` …); ordinary text
  with `& < > "`, é, —, an emoji, a TAB, a line break and half an emoji, made and read back by the board (the half as
  U+FFFD); a sheet name whose U+000B lies past the 31st character; a carriage return.
- **B, the deck** (2): a Mission Critical Plan Event typed through the board's own prompt as `Plan<U+000B>event` -- no
  deck, slide 5, its title and the text named, the Plan Event as typed; CONTROL: `_x0041_ deck` makes the deck, every part
  parses, slide 5 carries it as typed.
- **C, where a person meets it** (7): exportExcel, exportCSV and exportSrc name Decision Bands H18, 1-N by Band E5 and O&M
  Raw Data D2 (where the base wrote the character, read off its own files); exportFlow names Funds Flow A40; the IDS export
  names Missing data and anomalies C24 and keeps ORG 21; from the open IDS box, a first try with no reason is refused by
  the prompt, the second (reason given) is refused here and the box no longer gives the missing reason; the funds-flow
  chart, its panel open, draws the destination as typed and Save as image is refused before its Blob, naming “Ctl[U+000B]”.
- **D, every caller** (36): the 16 workbook routes and the deck, each on ordinary data (CONTROL: one zip, one Blob, one
  download, nothing alerted), then with `_xlsxRefused` / `_pptxRefused` standing in as a refusal (each route: the writer
  asked once, no zip, no Blob, no download, the status line left as it was -- no word after the refusal -- MS, S, DIRTY and
  browser storage unchanged); the IDS ORG typed into the refused route not kept; the chart image's CONTROL.
- **E**: no page error on any of the four boards.

Every expected value is a hand-written literal (the cell names were read off the base's own files, `logs/P-where2-base.log`;
the messages are written out whole). Board functions are used only to drive the routes and to observe.

**Fail before, pass after** (focused harness `harness/tools/export-audit/focus-u37.mjs`, blob `e17d93b8…`, made by
`bin/mkfocused.py` from the suite file -- the block is a verbatim substring of it, checked -- and run by `bin/runner.mjs`
with the board given explicitly):

| Run | Board | Result |
|---|---|---|
| `F3-c1-final` | `c1` (`d75ea5ed`) | **84 of 84 pass**, exit 0 |
| `F3-base-final` | base (`fce8a391`) | **60 fail**, 24 pass, exit 1. The 24 that pass on both: A3b, A5, A6, A7 and B2 (CONTROLs), the 17 D CONTROLs (16 routes and the deck), the chart image's D CONTROL, and E. Every other check fails. |
| `F3-prev-c1` | the earlier attempt's board (`1434000c`) | 41 fail, exit 1: the words (A1 ×31, A2, A3, B1, C ×5), the chart image (C7) and the IDS box (C6: its ninth value -- the box still gives the missing reason -- is `true`) |
| `F3-compose42` | `c1` + U41/U42's board patch (`cee6f9a7`) | 84 of 84 pass, exit 0 |

(The harness blob the 35 mutants ran with, `17ced092`, differs from `e17d93b8` only in two comment lines of the block's
header (`bin3/block3c.py`; the earlier harness is kept as `work/focus-u37-17ced092.mjs`) -- no code line.)

## Mutations

35 entries `{ id, area, what, find, repl }`, inserted in the mutate.mjs TEXT before the line "  // v2.00 (R3, Brad 11 Oct):
a save that lands under a locked view says it saved the working plan." (`bin3/mkentries3.py`, which asserts each find
matches the board once before writing). Counts, text only (`rec/bin/mcount.py`, `python3 -I`): **base 1,328 of 1,328 once
(`MC-base`); `c1` 1,363 of 1,363 once (`MC-c1-r2`)** -- every existing entry still matches exactly once, and each of the 35
new ones matches once. Each mutant was made by `rec/bin/mkmut.py` (text only; it writes a mutant only when the find
matches once) and run through the focused block (`bin3/muts3.sh`, labels `M4-*`, two lanes). **All 35 caught**: exit 1,
84 checks recorded each, none threw, none "never ran"; each fails only U37 checks:

| Entry | Area | Failing checks on the mutant (the U37 block) | Run (start ET, wall) |
|---|---|---|---|
| `v200-u37-xlsx-unchecked` | buildXlsx | 57 of 84: A1 · U+0000 in a cell; A1 · U+0001 in a cell; A1 · U+0002 in a cell; … 54 more | 15:20:49, 37.6s |
| `v200-u37-pptx-unchecked` | buildPptx | 2 of 84: B1 · the deck, a Mission Critical Plan Event holding U+000B; D · exportPPT() refused | 15:20:49, 37.4s |
| `v200-u37-name-unchecked` | _xlsxRefused | 2 of 84: A3 · a sheet name; A4 · a literal _xHHHH_ | 15:21:27, 47.2s |
| `v200-u37-cell-unchecked` | _xlsxRefused | 39 of 84: A1 · U+0000 in a cell; A1 · U+0001 in a cell; A1 · U+0002 in a cell; … 36 more | 15:21:27, 45.5s |
| `v200-u37-literal-unchecked` | _xmlBad | 1 of 84: A4 · a literal _xHHHH_ | 15:22:14, 43.8s |
| `v200-u37-nonchars-allowed` | XML_BADCH | 2 of 84: A1 · U+FFFE in a cell; A1 · U+FFFF in a cell | 15:22:12, 39.9s |
| `v200-u37-vt-allowed` | XML_BADCH | 11 of 84: A1 · U+000B in a cell; A2 · the words; A3 · a sheet name; … 8 more | 15:22:58, 70.2s |
| `v200-u37-wrong-cell` | _xlsxRefused | 39 of 84: A1 · U+0000 in a cell; A1 · U+0001 in a cell; A1 · U+0002 in a cell; … 36 more | 15:22:52, 71.8s |
| `v200-u37-show-raw` | _xmlShow | 41 of 84: A1 · U+0000 in a cell; A1 · U+0001 in a cell; A1 · U+0002 in a cell; … 38 more | 15:24:08, 41.7s |
| `v200-u37-stat-silent` | _xmlRefuse | 2 of 84: A2 · the words; B1 · the deck, a Mission Critical Plan Event holding U+000B | 15:24:04, 40.9s |
| `v200-u37-wrong-slide` | _pptxRefused | 1 of 84: B1 · the deck, a Mission Critical Plan Event holding U+000B | 15:24:50, 44.0s |
| `v200-u37-ids-org-kept` | exportIdsReq | 4 of 84: C · exportIdsReq(), a Plan Event not uploaded, a new ORG 44 typed; C · exportIdsReq() from the open IDS box, the reason given on the second try; D · exportIdsReq refused; D · the IDS ORG | 15:24:45, 45.6s |
| `v200-u37-ids-stale-note` | exportIdsReq | 1 of 84: C · exportIdsReq() from the open IDS box, the reason given on the second try | 15:25:34, 53.2s |
| `v200-u37-name-past-31` | _xlsxRefused | 1 of 84: A3b · CONTROL a sheet name whose character lies past the 31 written | 15:25:31, 53.9s |
| `v200-u37-cr-refused` | XML_BADCH | 1 of 84: A7 · CONTROL a carriage return | 15:26:28, 51.3s |
| `v200-u37-advice-board-only` | _xmlRefuse | 2 of 84: A2 · the words; B1 · the deck, a Mission Critical Plan Event holding U+000B | 15:26:25, 47.9s |
| `v200-u37-png-unchecked` | flowPng | 1 of 84: C · flowPng(), the funds-flow chart drawing Ctl<U+000B> | 15:27:19, 49.8s |
| `v200-u37-png-markup` | flowPng | 1 of 84: C · flowPng(), the funds-flow chart drawing Ctl<U+000B> | 15:27:13, 52.5s |
| `v200-u37-guard-exportrlgplan` | exportRlgPlan | 1 of 84: D · exportRlgPlan() refused | 15:28:09, 46.5s |
| `v200-u37-guard-pmoreport` | pmoReport | 1 of 84: D · pmoReport() refused | 15:28:05, 44.8s |
| `v200-u37-guard-crexport` | crExport | 1 of 84: D · crExport() refused | 15:28:55, 45.5s |
| `v200-u37-guard-exportidsreq` | exportIdsReq | 4 of 84: C · exportIdsReq(), a Plan Event not uploaded, a new ORG 44 typed; C · exportIdsReq() from the open IDS box, the reason given on the second try; D · exportIdsReq refused; D · the IDS ORG | 15:28:50, 46.0s |
| `v200-u37-guard-exportflow` | exportFlow | 2 of 84: C · exportFlow(), a destination named Ctl<U+000B>; D · exportFlow() refused | 15:29:41, 42.8s |
| `v200-u37-guard-exportexview` | exportExView | 1 of 84: D · exportExView() refused | 15:29:36, 41.7s |
| `v200-u37-guard-exportsrc` | exportSrc | 2 of 84: C · exportSrc(), the Plan Event Plan<U+000B>event; D · exportSrc() refused | 15:30:24, 40.7s |
| `v200-u37-guard-exportplans` | exportPlans | 1 of 84: D · exportPlans() refused | 15:30:18, 40.8s |
| `v200-u37-guard-exportfydpplan` | exportFydpPlan | 1 of 84: D · exportFydpPlan() refused | 15:31:05, 41.6s |
| `v200-u37-guard-exportcyccompare` | exportCycCompare | 1 of 84: D · exportCycCompare() refused | 15:30:59, 39.3s |
| `v200-u37-guard-exportreprog` | exportReprog | 1 of 84: D · exportReprog() refused | 15:31:46, 43.7s |
| `v200-u37-guard-exportfcview` | exportFcView | 1 of 84: D · exportFcView() refused | 15:31:38, 43.0s |
| `v200-u37-guard-exportcsv` | exportCSV | 2 of 84: C · exportCSV(), the Plan Event Plan<U+000B>event; D · exportCSV() refused | 15:32:30, 50.9s |
| `v200-u37-guard-exportacetieout` | exportAceTieout | 1 of 84: D · exportAceTieout() refused | 15:32:21, 51.2s |
| `v200-u37-guard-exportexcel` | exportExcel | 2 of 84: C · exportExcel(), the Plan Event Plan<U+000B>event; D · exportExcel() refused | 15:33:21, 36.5s |
| `v200-u37-guard-exportcoa` | exportCoa | 1 of 84: D · exportCoa() refused | 15:33:13, 36.9s |
| `v200-u37-guard-exportppt` | exportPPT | 2 of 84: B1 · the deck, a Mission Critical Plan Event holding U+000B; D · exportPPT() refused | 15:33:58, 32.9s |

An earlier round of 33 of these (`M3-*`, on the board `606c4192` before the chart image was added) was also all caught; it
is superseded by `M4-*` and kept in `work/out3-606c4192/`.

## Other suites, `npm run check`, mcount, preservation

Run from two scratch clones of `/home/user/orbit-board` (`git clone --shared`, HEAD `7ee498a`, nothing committed in
either): `work/clone-base` (every tracked file unmodified) and `work/clone3-c1` (the same HEAD with `c1`'s three files
copied in: board `d75ea5ed…`, audit-recon `2e61a21d…`, and `tools/export-audit/mutate.mjs` = the text `efd83f43…`, which
no suite run here reads). `git status` in `clone3-c1` shows exactly those three files modified. Each suite was run the way
`package.json` runs it (`node tools/export-audit/<suite>.mjs`; `npm run check` is `node tools/check.mjs
prioritization-board-grid.html`), one at a time through `bin/r.sh`, in two lanes (`bin3/suites3.sh`). The base side is
the earlier attempt's base runs where they are complete (kept, see "Resuming"), and `S3-base-audit-recon` from this
builder.

| Suite | Base: run, exit, wall | `c1`: run, exit, wall | Output compared (timings masked) |
|---|---|---|---|
| boot-same | `S-base-boot-same`, 0, 50.5 s | `S3-c1-boot-same`, 0, 34.2 s | identical ("every page, source, save and error list is identical either way") |
| audit | `S-base-audit`, 0, 43.5 s | `S3-c1-audit`, 0, 31.3 s | identical ("ALL CHECKS PASSED") |
| audit-ppt | `S-base-audit-ppt`, 0, 23.9 s | `S3-c1-audit-ppt`, 0, 16.4 s | identical ("ALL CHECKS PASSED") |
| audit-other | `S-base-audit-other`, 0, 154.5 s | `S3-c1-audit-other`, 0, 105.6 s | identical ("ALL CHECKS PASSED") |
| legacy-fsrc | `S-base-legacy-fsrc`, 0, 16.6 s | `S3-c1-legacy-fsrc`, 0, 11.0 s | identical ("every legacy Force setting computes exactly as before") |
| audit-hostile | `S-base-audit-hostile`, 0, 305.0 s | `S3-c1-audit-hostile`, 0, 166.9 s | identical ("ALL CHECKS PASSED") |
| audit-inject | `S-base-audit-inject-r2`, 0, 56.5 s | `S3-c1-audit-inject`, 0, 44.0 s | identical |
| `npm run check` | `S-base-check-r2`, 0, 15.4 s | `S3-c1-check`, 0, 9.6 s | "all checks passed" both; the only lines that differ are the board's size (31,672 → 31,767 lines, 3.57 → 3.58 MB) and "main script parses (29650 → 29745 lines)" -- the 95 lines this commit adds |
| audit-recon (whole) | `S3-base-audit-recon`, 0, 487.2 s | `S3-c1-audit-recon`, 0, 506.2 s | identical ("ALL CHECKS PASSED") |

The whole audit-recon on `c1` includes the U37 block: the suite's own last check fails any scenario whose `  const name =
'…'` line is in the file but never ran ("this scenario never ran"), so "ALL CHECKS PASSED" there means the U37 scenario ran
in the whole suite and its 84 checks passed with every other block's. audit-import and audit-board were not run (the lead's;
see "Not done").

**Mutation text counts** (`rec/bin/mcount.py`, `python3 -I`, text only; each entry's `find` against the board):

| Run | Text / board | Result |
|---|---|---|
| `MC-base` | base `mutate.mjs.txt` / base board | 1,328 entries, 1,328 match once; none missing, none multiple, none unparsed |
| `MC-c1-r2` | `c1` text `efd83f43` / `c1` board `d75ea5ed` | 1,363 entries, 1,363 match once (the 35 new each once) |
| `MC-compose42` | `c1` text / `c1` + U41/U42 board `cee6f9a7` | 1,363 entries, 1,363 match once |

(`MC-c1`, 1,361 of 1,361, counted the entries before the two chart entries were added; superseded by `MC-c1-r2`.)

**Preservation and probes on the final boards:**

- `P3-same-base` / `P3-same-c1` (`probe/same.mjs`, the clock frozen, ordinary synthetic data -- a TAB in a title included):
  all 17 routes (the 16 workbook routes, crExport as O&M, and exportPPT) make a file on both boards, and the sha1 and byte
  length of every file are **identical** on the base and on `c1` (e.g. exportExcel `d32807bb…` 112,740 bytes, exportPPT
  `6090cc5a…` 1,319,665 bytes); no page error on either.
- `P3-png-base` / `P3-png-c1` (Chromium, `probe/png.mjs`): the CONTROL chart saves its PNG on both ("⬇ Saved a 2560×1804
  PNG"); with the drawn text holding U+000B the base downloads nothing and says "⚠ Could not render the chart to an
  image."; `c1` downloads nothing and says "⚠ Chart image not exported — the chart holds character U+000B, which ORBIT
  cannot draw into an image, in the text “Ctl[U+000B]” …". No page error.
- `P3-chart-base-r2` / `P3-chart-c1-r3` (jsdom, `probe3/chart.mjs`): with the panel open the chart draws the destination
  as typed (two U+000B in the SVG); the base makes one Blob and its status line keeps the earlier word, `c1` makes none and names “Ctl[U+000B]”.
- `P3-imp-base` / `P3-imp-c1` (`probe3/imp.mjs`): the LibreOffice-written Spend Plan Source import (decision 2) -- the
  board holds "Engine_x000b_spares"; on the base exportFlow and exportRlgPlan write it, on `c1` both are refused naming
  OGC Detail A2 and Funding plan E9; the other twelve routes behave the same on both.
- `F3-compose42`: the U37 block on `c1` + U41/U42's board patch, 84 of 84.

## How this composes with other tracks

**U41/U42 (sheet names, `tabName`; `rec/L6/u41u42/codex`, read only).** Codex's U41/U42 board patch
(`prioritization-board-grid.html.diff`) applies cleanly on top of this `c1` (`git apply --check`, then `git apply`, in
`work/compose42/final`; no hunk overlaps this commit's, and this commit's exportFlow guard is still there after it).
The composed board is `work/compose42/final/prioritization-board-grid.html`, blob `cee6f9a78185287fcfe831adc4b16a1400490d22`:
all 1,363 finds of this commit's mutate text match it exactly once (text count, `MC-compose42`), and the U37 focused block on it:
84 of 84 pass (`F3-compose42`, `logs/F3-compose42.log`). How the two checks compose: `_xlsxRefused` runs inside `buildXlsx`, on each sheet name exactly as it will
be written (its first 31 characters), after whatever `tabName` returned -- so it holds for any `tabName`. U42's `tabName`
strips whitespace at the edges with `\s`, which in JavaScript includes U+000B and U+000C: a destination named `Ctl<U+000B>`
gets the sheet name `Ctl` there (the base's `.trim()` already did that), so the name never reaches the U37 check; a
forbidden character inside the name (U+0001, or U+000B mid-name) still does, and is refused and named. The destination's
own text in the Funds Flow cells is refused either way (C4 names Funds Flow A40). U42 also stops cutting a sheet name
inside an emoji (`.replace(/[\uD800-\uDBFF]$/,'')`), which removes one of the board's cuts that item 3 above leans on; the
cuts at 44 (CR Cash Needs) and 56 (the deck) and the PMO sheet names at 31 (Priority drill) remain. If U42's sheet-name cut
ever changes from `slice(0,31)` in `buildXlsx` itself, `_xlsxRefused`'s `slice(0,31)` must change with it (one line,
`v200-u37-name-past-31` guards it). In `mutate.mjs` both tracks insert their entries before the same R3 line: a merge
keeps both blocks, in either order.

**The registry-text track (`rec/L6/regtext`, in review; read only, not edited).** It records U37 as an open P1 with limits:
its NEXT-VERSION "Not covered" paragraph ("U37 (P1, a release blocker; fix track u37 under way on 13 Oct; this paragraph
stands only if that fix does not land)"), its "Unresolved" sub-bullet, its ledger note (the slide deck), its matrix row
("Workbook and slide-deck well-formedness … Not well-formed"), and its commit message ("U37 … stay open here"). This commit
supersedes those: `drafts/NEXT-VERSION-entry.md` and `drafts/UNRESOLVED-line.md` say what replaces each paragraph if the
registry-text commit lands first; its ledger note stays as evidence, and `drafts/LEDGER-append.md` closes the row.

**U40 (destinations).** U40's patch changes the functions next to `flowSetEnt`; this commit does not touch them. The U37
block makes a destination with `flowAddEnt` / `flowSetEnt` / `flowSetAxis`, which U40's refusals could change (a name
the board's rule calls the same as another); `Ctl<U+000B>` is the only typed destination on that board, so no merge
rule applies. Not run on a composed board here.

## Drafts for the lead

- `drafts/NEXT-VERSION-entry.md` — the U37 bullet under v2.00 (what was wrong, what changes, What users may see, Test,
  Mutations, Not covered), and what replaces the registry-text entry's U37 paragraph if that lands first.
- `drafts/UNRESOLVED-line.md` — A: a new line for "Unresolved after R1–R5"; B: the replacement for the registry-text
  draft's U37 sub-bullet.
- `drafts/LEDGER-append.md` — the text to append to the U37 row's Status cell (`<sha>`/`<time>` placeholders).
- The earlier attempt's drafts are kept, superseded, in `prev/drafts/`.

## Every run

Every run went through `bin/r.sh` (the lock check on `scratchpad/AUDIT_IMPORT_RUNNING` -- the lock was never there when a
run started, so no run waited or was skipped; `setsid -w timeout -k 10 600`; PID and command into `pids.txt`; one line into
`runs.tsv` when it ends). Each log starts with its label, command, directory and start time and ends with its end time,
exit and wall seconds. Times are Eastern, 13 Oct.

**This builder's runs** (`python3 -I bin3/runtable.py runs.tsv '2026-10-13 14:45'`), in the order they ended:

| Label | Start (ET) | Exit | Wall s | Log |
|---|---|---|---|---|
| LO-cr-xlsx | 2026-10-13 14:51:41 | 0 | 5.8 | logs/LO-cr-xlsx.log |
| MC-base | 2026-10-13 15:00:22 | 0 | 12.3 | logs/MC-base.log |
| MC-c1 | 2026-10-13 15:00:35 | 0 | 24.6 | logs/MC-c1.log |
| F3-base | 2026-10-13 15:01:32 | 1 | 3.0 | logs/F3-base.log |
| F3-c1 | 2026-10-13 15:01:32 | 1 | 3.5 | logs/F3-c1.log |
| F3-base-r2 | 2026-10-13 15:01:46 | 1 | 37.1 | logs/F3-base-r2.log |
| F3-c1-r2 | 2026-10-13 15:01:46 | 0 | 37.3 | logs/F3-c1-r2.log |
| M3-v200-u37-pptx-unchecked | 2026-10-13 15:03:15 | 1 | 49.4 | logs/M3-v200-u37-pptx-unchecked.log |
| M3-v200-u37-xlsx-unchecked | 2026-10-13 15:03:15 | 1 | 50.3 | logs/M3-v200-u37-xlsx-unchecked.log |
| LO-src-xlsx | 2026-10-13 15:04:04 | 0 | 7.9 | logs/LO-src-xlsx.log |
| M3-v200-u37-name-unchecked | 2026-10-13 15:04:06 | 1 | 34.9 | logs/M3-v200-u37-name-unchecked.log |
| M3-v200-u37-cell-unchecked | 2026-10-13 15:04:05 | 1 | 36.8 | logs/M3-v200-u37-cell-unchecked.log |
| LO-src-xlsx-r2 | 2026-10-13 15:04:42 | 0 | 5.4 | logs/LO-src-xlsx-r2.log |
| M3-v200-u37-literal-unchecked | 2026-10-13 15:04:41 | 1 | 35.7 | logs/M3-v200-u37-literal-unchecked.log |
| M3-v200-u37-nonchars-allowed | 2026-10-13 15:04:42 | 1 | 36.0 | logs/M3-v200-u37-nonchars-allowed.log |
| M3-v200-u37-vt-allowed | 2026-10-13 15:05:16 | 1 | 42.1 | logs/M3-v200-u37-vt-allowed.log |
| M3-v200-u37-wrong-cell | 2026-10-13 15:05:18 | 1 | 41.5 | logs/M3-v200-u37-wrong-cell.log |
| M3-v200-u37-show-raw | 2026-10-13 15:05:59 | 1 | 39.6 | logs/M3-v200-u37-show-raw.log |
| M3-v200-u37-stat-silent | 2026-10-13 15:05:59 | 1 | 45.8 | logs/M3-v200-u37-stat-silent.log |
| M3-v200-u37-wrong-slide | 2026-10-13 15:06:38 | 1 | 45.1 | logs/M3-v200-u37-wrong-slide.log |
| M3-v200-u37-ids-org-kept | 2026-10-13 15:06:45 | 1 | 42.4 | logs/M3-v200-u37-ids-org-kept.log |
| M3-v200-u37-ids-stale-note | 2026-10-13 15:07:23 | 1 | 160.8 | logs/M3-v200-u37-ids-stale-note.log |
| M3-v200-u37-name-past-31 | 2026-10-13 15:07:28 | 1 | 159.8 | logs/M3-v200-u37-name-past-31.log |
| M3-v200-u37-cr-refused | 2026-10-13 15:10:04 | 1 | 33.0 | logs/M3-v200-u37-cr-refused.log |
| M3-v200-u37-advice-board-only | 2026-10-13 15:10:08 | 1 | 33.6 | logs/M3-v200-u37-advice-board-only.log |
| M3-v200-u37-guard-exportrlgplan | 2026-10-13 15:10:37 | 1 | 31.7 | logs/M3-v200-u37-guard-exportrlgplan.log |
| M3-v200-u37-guard-pmoreport | 2026-10-13 15:10:41 | 1 | 34.2 | logs/M3-v200-u37-guard-pmoreport.log |
| M3-v200-u37-guard-crexport | 2026-10-13 15:11:09 | 1 | 35.1 | logs/M3-v200-u37-guard-crexport.log |
| M3-v200-u37-guard-exportidsreq | 2026-10-13 15:11:16 | 1 | 35.1 | logs/M3-v200-u37-guard-exportidsreq.log |
| M3-v200-u37-guard-exportflow | 2026-10-13 15:11:44 | 1 | 35.0 | logs/M3-v200-u37-guard-exportflow.log |
| M3-v200-u37-guard-exportexview | 2026-10-13 15:11:51 | 1 | 34.3 | logs/M3-v200-u37-guard-exportexview.log |
| M3-v200-u37-guard-exportsrc | 2026-10-13 15:12:19 | 1 | 33.6 | logs/M3-v200-u37-guard-exportsrc.log |
| M3-v200-u37-guard-exportplans | 2026-10-13 15:12:25 | 1 | 35.7 | logs/M3-v200-u37-guard-exportplans.log |
| M3-v200-u37-guard-exportfydpplan | 2026-10-13 15:12:53 | 1 | 39.6 | logs/M3-v200-u37-guard-exportfydpplan.log |
| M3-v200-u37-guard-exportcyccompare | 2026-10-13 15:13:01 | 1 | 41.9 | logs/M3-v200-u37-guard-exportcyccompare.log |
| M3-v200-u37-guard-exportreprog | 2026-10-13 15:13:33 | 1 | 38.1 | logs/M3-v200-u37-guard-exportreprog.log |
| M3-v200-u37-guard-exportfcview | 2026-10-13 15:13:43 | 1 | 37.7 | logs/M3-v200-u37-guard-exportfcview.log |
| M3-v200-u37-guard-exportcsv | 2026-10-13 15:14:11 | 1 | 39.0 | logs/M3-v200-u37-guard-exportcsv.log |
| M3-v200-u37-guard-exportacetieout | 2026-10-13 15:14:21 | 1 | 37.7 | logs/M3-v200-u37-guard-exportacetieout.log |
| M3-v200-u37-guard-exportexcel | 2026-10-13 15:14:50 | 1 | 36.0 | logs/M3-v200-u37-guard-exportexcel.log |
| M3-v200-u37-guard-exportcoa | 2026-10-13 15:14:58 | 1 | 41.5 | logs/M3-v200-u37-guard-exportcoa.log |
| M3-v200-u37-guard-exportppt | 2026-10-13 15:15:26 | 1 | 55.5 | logs/M3-v200-u37-guard-exportppt.log |
| P3-chart-c1 | 2026-10-13 15:16:33 | 1 | 0.1 | logs/P3-chart-c1.log |
| P3-chart-base | 2026-10-13 15:16:33 | 1 | 0.2 | logs/P3-chart-base.log |
| P3-chart-c1-r2 | 2026-10-13 15:16:41 | 0 | 21.7 | logs/P3-chart-c1-r2.log |
| P3-chart-base-r2 | 2026-10-13 15:16:41 | 0 | 21.8 | logs/P3-chart-base-r2.log |
| P3-chart-c1-r3 | 2026-10-13 15:17:37 | 0 | 16.2 | logs/P3-chart-c1-r3.log |
| P3-png-base | 2026-10-13 15:18:00 | 0 | 15.2 | logs/P3-png-base.log |
| P3-png-c1 | 2026-10-13 15:18:21 | 0 | 16.2 | logs/P3-png-c1.log |
| MC-c1-r2 | 2026-10-13 15:19:05 | 0 | 16.6 | logs/MC-c1-r2.log |
| F3-c1-r3 | 2026-10-13 15:19:29 | 0 | 39.6 | logs/F3-c1-r3.log |
| F3-base-r3 | 2026-10-13 15:19:29 | 1 | 42.5 | logs/F3-base-r3.log |
| M4-v200-u37-pptx-unchecked | 2026-10-13 15:20:49 | 1 | 37.4 | logs/M4-v200-u37-pptx-unchecked.log |
| M4-v200-u37-xlsx-unchecked | 2026-10-13 15:20:49 | 1 | 37.6 | logs/M4-v200-u37-xlsx-unchecked.log |
| M4-v200-u37-cell-unchecked | 2026-10-13 15:21:27 | 1 | 45.5 | logs/M4-v200-u37-cell-unchecked.log |
| M4-v200-u37-name-unchecked | 2026-10-13 15:21:27 | 1 | 47.2 | logs/M4-v200-u37-name-unchecked.log |
| M4-v200-u37-nonchars-allowed | 2026-10-13 15:22:12 | 1 | 39.9 | logs/M4-v200-u37-nonchars-allowed.log |
| M4-v200-u37-literal-unchecked | 2026-10-13 15:22:14 | 1 | 43.8 | logs/M4-v200-u37-literal-unchecked.log |
| M4-v200-u37-wrong-cell | 2026-10-13 15:22:52 | 1 | 71.8 | logs/M4-v200-u37-wrong-cell.log |
| M4-v200-u37-vt-allowed | 2026-10-13 15:22:58 | 1 | 70.2 | logs/M4-v200-u37-vt-allowed.log |
| M4-v200-u37-stat-silent | 2026-10-13 15:24:04 | 1 | 40.9 | logs/M4-v200-u37-stat-silent.log |
| M4-v200-u37-show-raw | 2026-10-13 15:24:08 | 1 | 41.7 | logs/M4-v200-u37-show-raw.log |
| M4-v200-u37-ids-org-kept | 2026-10-13 15:24:45 | 1 | 45.6 | logs/M4-v200-u37-ids-org-kept.log |
| M4-v200-u37-wrong-slide | 2026-10-13 15:24:50 | 1 | 44.0 | logs/M4-v200-u37-wrong-slide.log |
| M4-v200-u37-name-past-31 | 2026-10-13 15:25:31 | 1 | 53.9 | logs/M4-v200-u37-name-past-31.log |
| M4-v200-u37-ids-stale-note | 2026-10-13 15:25:34 | 1 | 53.2 | logs/M4-v200-u37-ids-stale-note.log |
| M4-v200-u37-advice-board-only | 2026-10-13 15:26:25 | 1 | 47.9 | logs/M4-v200-u37-advice-board-only.log |
| M4-v200-u37-cr-refused | 2026-10-13 15:26:28 | 1 | 51.3 | logs/M4-v200-u37-cr-refused.log |
| M4-v200-u37-png-markup | 2026-10-13 15:27:13 | 1 | 52.5 | logs/M4-v200-u37-png-markup.log |
| M4-v200-u37-png-unchecked | 2026-10-13 15:27:19 | 1 | 49.8 | logs/M4-v200-u37-png-unchecked.log |
| M4-v200-u37-guard-pmoreport | 2026-10-13 15:28:05 | 1 | 44.8 | logs/M4-v200-u37-guard-pmoreport.log |
| M4-v200-u37-guard-exportrlgplan | 2026-10-13 15:28:09 | 1 | 46.5 | logs/M4-v200-u37-guard-exportrlgplan.log |
| M4-v200-u37-guard-exportidsreq | 2026-10-13 15:28:50 | 1 | 46.0 | logs/M4-v200-u37-guard-exportidsreq.log |
| M4-v200-u37-guard-crexport | 2026-10-13 15:28:55 | 1 | 45.5 | logs/M4-v200-u37-guard-crexport.log |
| M4-v200-u37-guard-exportexview | 2026-10-13 15:29:36 | 1 | 41.7 | logs/M4-v200-u37-guard-exportexview.log |
| M4-v200-u37-guard-exportflow | 2026-10-13 15:29:41 | 1 | 42.8 | logs/M4-v200-u37-guard-exportflow.log |
| M4-v200-u37-guard-exportplans | 2026-10-13 15:30:18 | 1 | 40.8 | logs/M4-v200-u37-guard-exportplans.log |
| M4-v200-u37-guard-exportsrc | 2026-10-13 15:30:24 | 1 | 40.7 | logs/M4-v200-u37-guard-exportsrc.log |
| M4-v200-u37-guard-exportcyccompare | 2026-10-13 15:30:59 | 1 | 39.3 | logs/M4-v200-u37-guard-exportcyccompare.log |
| M4-v200-u37-guard-exportfydpplan | 2026-10-13 15:31:05 | 1 | 41.6 | logs/M4-v200-u37-guard-exportfydpplan.log |
| M4-v200-u37-guard-exportfcview | 2026-10-13 15:31:38 | 1 | 43.0 | logs/M4-v200-u37-guard-exportfcview.log |
| M4-v200-u37-guard-exportreprog | 2026-10-13 15:31:46 | 1 | 43.7 | logs/M4-v200-u37-guard-exportreprog.log |
| M4-v200-u37-guard-exportacetieout | 2026-10-13 15:32:21 | 1 | 51.2 | logs/M4-v200-u37-guard-exportacetieout.log |
| M4-v200-u37-guard-exportcsv | 2026-10-13 15:32:30 | 1 | 50.9 | logs/M4-v200-u37-guard-exportcsv.log |
| M4-v200-u37-guard-exportcoa | 2026-10-13 15:33:13 | 1 | 36.9 | logs/M4-v200-u37-guard-exportcoa.log |
| M4-v200-u37-guard-exportexcel | 2026-10-13 15:33:21 | 1 | 36.5 | logs/M4-v200-u37-guard-exportexcel.log |
| M4-v200-u37-guard-exportppt | 2026-10-13 15:33:58 | 1 | 32.9 | logs/M4-v200-u37-guard-exportppt.log |
| F3-c1-final | 2026-10-13 15:35:00 | 0 | 35.3 | logs/F3-c1-final.log |
| F3-base-final | 2026-10-13 15:35:00 | 1 | 38.9 | logs/F3-base-final.log |
| F3-compose42 | 2026-10-13 15:35:39 | 0 | 55.1 | logs/F3-compose42.log |
| F3-prev-c1 | 2026-10-13 15:35:39 | 1 | 56.6 | logs/F3-prev-c1.log |
| P3-imp-c1 | 2026-10-13 15:36:49 | 0 | 11.6 | logs/P3-imp-c1.log |
| P3-imp-base | 2026-10-13 15:36:49 | 0 | 11.8 | logs/P3-imp-base.log |
| P3-same-c1 | 2026-10-13 15:37:13 | 0 | 23.0 | logs/P3-same-c1.log |
| P3-same-base | 2026-10-13 15:37:13 | 0 | 24.2 | logs/P3-same-base.log |
| S3-base-audit-recon | 2026-10-13 15:37:44 | 0 | 487.2 | logs/S3-base-audit-recon.log |
| S3-c1-audit-recon | 2026-10-13 15:37:44 | 0 | 506.2 | logs/S3-c1-audit-recon.log |
| S3-c1-boot-same | 2026-10-13 15:46:10 | 0 | 34.2 | logs/S3-c1-boot-same.log |
| S3-c1-audit | 2026-10-13 15:46:44 | 0 | 31.3 | logs/S3-c1-audit.log |
| S3-c1-audit-ppt | 2026-10-13 15:47:15 | 0 | 16.4 | logs/S3-c1-audit-ppt.log |
| S3-c1-audit-other | 2026-10-13 15:45:51 | 0 | 105.6 | logs/S3-c1-audit-other.log |
| S3-c1-legacy-fsrc | 2026-10-13 15:47:32 | 0 | 11.0 | logs/S3-c1-legacy-fsrc.log |
| S3-c1-check | 2026-10-13 15:47:43 | 0 | 9.6 | logs/S3-c1-check.log |
| S3-c1-audit-hostile | 2026-10-13 15:47:37 | 0 | 166.9 | logs/S3-c1-audit-hostile.log |
| S3-c1-audit-inject | 2026-10-13 15:50:23 | 0 | 44.0 | logs/S3-c1-audit-inject.log |
| MC-compose42 | 2026-10-13 15:53:21 | 0 | 17.3 | logs/MC-compose42.log |

Exit codes, read with the run: a mutant (`M3-*`, `M4-*`) and a focused run on the base (`F3-base-*`) or on the earlier
attempt's board (`F3-prev-c1`) are expected to exit 1 -- that is the check failing; the table under "Mutations" and the
"Fail before, pass after" table say which checks. The others that exit 1, and what replaced them:

- `F3-base`, `F3-c1` (3 s): no check ran -- the harness directory had no `node_modules` (`ERR_MODULE_NOT_FOUND` for
  jsdom). `harness/node_modules` was linked to the copy's, and both were run again as `-r2`.
- `P3-chart-base`, `P3-chart-c1` (0.1 s): no node ran -- the log paths were relative after the `cd`; run again as `-r2`
  with absolute paths.

Superseded (complete, kept, not relied on for the final numbers): `MC-c1` (before the two chart entries; `MC-c1-r2`),
`F3-*-r2` and the 33 `M3-*` mutants (the board `606c4192`, before the chart image; outputs in `work/out3-606c4192/`),
`P3-chart-c1-r2` (the board before the chart refusal named the drawn text instead of its markup; `-r3`), `F3-*-r3` (the
harness `17ced092`, two comment lines before `e17d93b8`; `F3-*-final`), `LO-src-xlsx` (its input CSV was then rewritten in
the board's own import form -- month `2027-05`, an office PMO -- and converted again as `LO-src-xlsx-r2`, which
`probe3/imp.mjs` reads).

**The earlier attempt's runs** (`python3 -I bin3/runtable.py runs.tsv '2026-10-13 00:00' '2026-10-13 14:45'`; kept as
recorded; "Resuming" says which are relied on -- the base probes and the base suite runs -- and which are superseded --
every run on its `c1`). `S-base-audit-inject` has a log but no end record and no line here (its `-r2` is complete);
`S-base-audit-recon-r2` hit the 600 s cap (exit 124) and was replaced by `S3-base-audit-recon`.

| Label | Start (ET) | Exit | Wall s | Log |
|---|---|---|---|---|
| P-repro-base | 2026-10-13 13:29:39 | 0 | 10.9 | logs/P-repro-base.log |
| P-repro-codex | 2026-10-13 13:30:01 | 1 | 4.5 | logs/P-repro-codex.log |
| P-repro-codex2 | 2026-10-13 13:30:12 | 0 | 10.8 | logs/P-repro-codex2.log |
| X-xmlcheck-base | 2026-10-13 13:30:36 | 0 | 0.2 | logs/X-xmlcheck-base.log |
| LO-csv-base | 2026-10-13 13:30:48 | 0 | 4.0 | logs/LO-csv-base.log |
| P-lit-base | 2026-10-13 13:31:29 | 0 | 6.9 | logs/P-lit-base.log |
| LO-2-base | 2026-10-13 13:31:35 | 0 | 2.9 | logs/LO-2-base.log |
| LO-3-base | 2026-10-13 13:31:38 | 0 | 6.9 | logs/LO-3-base.log |
| P-reach-base | 2026-10-13 13:34:21 | 0 | 9.7 | logs/P-reach-base.log |
| P-reach2-base | 2026-10-13 13:35:39 | 0 | 12.7 | logs/P-reach2-base.log |
| P-domp | 2026-10-13 13:38:49 | 0 | 5.5 | logs/P-domp.log |
| P-where-base | 2026-10-13 13:40:25 | 0 | 15.7 | logs/P-where-base.log |
| P-where2-base | 2026-10-13 13:40:58 | 0 | 22.8 | logs/P-where2-base.log |
| F1-c1 | 2026-10-13 13:45:32 | 0 | 34.6 | logs/F1-c1.log |
| F1-base | 2026-10-13 13:46:19 | 1 | 39.7 | logs/F1-base.log |
| M-c1-v200-u37-cell-unchecked | 2026-10-13 13:50:06 | 1 | 41.0 | logs/M-c1-v200-u37-cell-unchecked.log |
| M-c1-v200-u37-guard-crexport | 2026-10-13 13:50:06 | 1 | 41.5 | logs/M-c1-v200-u37-guard-crexport.log |
| M-c1-v200-u37-guard-exportcoa | 2026-10-13 13:50:47 | 1 | 43.3 | logs/M-c1-v200-u37-guard-exportcoa.log |
| M-c1-v200-u37-guard-exportacetieout | 2026-10-13 13:50:47 | 1 | 44.8 | logs/M-c1-v200-u37-guard-exportacetieout.log |
| M-c1-v200-u37-guard-exportcyccompare | 2026-10-13 13:51:31 | 1 | 50.6 | logs/M-c1-v200-u37-guard-exportcyccompare.log |
| M-c1-v200-u37-guard-exportcsv | 2026-10-13 13:51:32 | 1 | 49.9 | logs/M-c1-v200-u37-guard-exportcsv.log |
| M-c1-v200-u37-guard-exportexview | 2026-10-13 13:52:22 | 1 | 45.2 | logs/M-c1-v200-u37-guard-exportexview.log |
| M-c1-v200-u37-guard-exportexcel | 2026-10-13 13:52:22 | 1 | 48.5 | logs/M-c1-v200-u37-guard-exportexcel.log |
| M-c1-v200-u37-guard-exportfcview | 2026-10-13 13:53:11 | 1 | 47.6 | logs/M-c1-v200-u37-guard-exportfcview.log |
| M-c1-v200-u37-guard-exportflow | 2026-10-13 13:53:07 | 1 | 52.1 | logs/M-c1-v200-u37-guard-exportflow.log |
| M-c1-v200-u37-guard-exportidsreq | 2026-10-13 13:53:59 | 1 | 45.7 | logs/M-c1-v200-u37-guard-exportidsreq.log |
| M-c1-v200-u37-guard-exportfydpplan | 2026-10-13 13:53:58 | 1 | 46.9 | logs/M-c1-v200-u37-guard-exportfydpplan.log |
| M-c1-v200-u37-guard-exportppt | 2026-10-13 13:54:45 | 1 | 39.3 | logs/M-c1-v200-u37-guard-exportppt.log |
| M-c1-v200-u37-guard-exportplans | 2026-10-13 13:54:45 | 1 | 39.1 | logs/M-c1-v200-u37-guard-exportplans.log |
| M-c1-v200-u37-guard-exportreprog | 2026-10-13 13:55:25 | 1 | 39.3 | logs/M-c1-v200-u37-guard-exportreprog.log |
| M-c1-v200-u37-guard-exportrlgplan | 2026-10-13 13:55:24 | 1 | 42.1 | logs/M-c1-v200-u37-guard-exportrlgplan.log |
| M-c1-v200-u37-guard-exportsrc | 2026-10-13 13:56:04 | 1 | 42.7 | logs/M-c1-v200-u37-guard-exportsrc.log |
| M-c1-v200-u37-guard-pmoreport | 2026-10-13 13:56:06 | 1 | 43.1 | logs/M-c1-v200-u37-guard-pmoreport.log |
| M-c1-v200-u37-ids-org-kept | 2026-10-13 13:56:47 | 1 | 44.8 | logs/M-c1-v200-u37-ids-org-kept.log |
| M-c1-v200-u37-literal-unchecked | 2026-10-13 13:56:49 | 1 | 47.5 | logs/M-c1-v200-u37-literal-unchecked.log |
| M-c1-v200-u37-name-unchecked | 2026-10-13 13:57:32 | 1 | 37.9 | logs/M-c1-v200-u37-name-unchecked.log |
| M-c1-v200-u37-nonchars-allowed | 2026-10-13 13:57:37 | 1 | 37.2 | logs/M-c1-v200-u37-nonchars-allowed.log |
| M-c1-v200-u37-pptx-unchecked | 2026-10-13 13:58:10 | 1 | 44.9 | logs/M-c1-v200-u37-pptx-unchecked.log |
| M-c1-v200-u37-show-raw | 2026-10-13 13:58:15 | 1 | 44.9 | logs/M-c1-v200-u37-show-raw.log |
| M-c1-v200-u37-stat-silent | 2026-10-13 13:58:54 | 1 | 43.4 | logs/M-c1-v200-u37-stat-silent.log |
| M-c1-v200-u37-vt-allowed | 2026-10-13 13:58:59 | 1 | 40.8 | logs/M-c1-v200-u37-vt-allowed.log |
| M-c1-v200-u37-wrong-slide | 2026-10-13 13:59:40 | 1 | 36.1 | logs/M-c1-v200-u37-wrong-slide.log |
| M-c1-v200-u37-wrong-cell | 2026-10-13 13:59:38 | 1 | 39.3 | logs/M-c1-v200-u37-wrong-cell.log |
| M-c1-v200-u37-xlsx-unchecked | 2026-10-13 14:00:17 | 1 | 39.3 | logs/M-c1-v200-u37-xlsx-unchecked.log |
| P-same-base | 2026-10-13 14:01:35 | 0 | 25.7 | logs/P-same-base.log |
| P-same-c1 | 2026-10-13 14:02:01 | 0 | 28.9 | logs/P-same-c1.log |
| S-c1-boot-same | 2026-10-13 14:02:44 | 0 | 49.6 | logs/S-c1-boot-same.log |
| S-base-boot-same | 2026-10-13 14:02:44 | 0 | 50.5 | logs/S-base-boot-same.log |
| S-c1-audit | 2026-10-13 14:03:34 | 0 | 42.3 | logs/S-c1-audit.log |
| S-base-audit | 2026-10-13 14:03:35 | 0 | 43.5 | logs/S-base-audit.log |
| S-c1-audit-ppt | 2026-10-13 14:04:17 | 0 | 23.6 | logs/S-c1-audit-ppt.log |
| S-base-audit-ppt | 2026-10-13 14:04:18 | 0 | 23.9 | logs/S-base-audit-ppt.log |
| S-base-audit-other | 2026-10-13 14:04:42 | 0 | 154.5 | logs/S-base-audit-other.log |
| S-c1-audit-other | 2026-10-13 14:04:40 | 0 | 167.3 | logs/S-c1-audit-other.log |
| S-base-legacy-fsrc | 2026-10-13 14:07:17 | 0 | 16.6 | logs/S-base-legacy-fsrc.log |
| S-c1-legacy-fsrc | 2026-10-13 14:07:28 | 0 | 22.0 | logs/S-c1-legacy-fsrc.log |
| S-base-audit-hostile | 2026-10-13 14:07:34 | 0 | 305.0 | logs/S-base-audit-hostile.log |
| S-base-audit-inject-r2 | 2026-10-13 14:13:58 | 0 | 56.5 | logs/S-base-audit-inject-r2.log |
| S-base-check-r2 | 2026-10-13 14:14:54 | 0 | 15.4 | logs/S-base-check-r2.log |
| S-c1-audit-hostile-r2 | 2026-10-13 14:13:58 | 0 | 304.2 | logs/S-c1-audit-hostile-r2.log |
| S-c1-audit-inject-r2 | 2026-10-13 14:19:19 | 0 | 95.1 | logs/S-c1-audit-inject-r2.log |
| S-c1-check-r2 | 2026-10-13 14:20:54 | 0 | 12.1 | logs/S-c1-check-r2.log |
| S-base-audit-recon-r2 | 2026-10-13 14:19:19 | 124 | 601.2 | logs/S-base-audit-recon-r2.log |

**Commands run directly** (not node, not Chromium; each short): text tools on files in this directory (`grep`, `sed -n`,
`diff`, `git hash-object`, `git diff --no-index` for `diffs/`, `git apply --check` / `git apply` in `work/compose42/final`);
the Python helpers that write files by asserted text edits (`bin3/board3.py`, `board3b.py`, `block3.py`, `block3b.py`,
`block3c.py`, `mkentries3.py`, `bin/mkfocused.py`) and `rec/bin/mkmut.py` for each mutant, all `python3 -I`;
`bin3/runtable.py` and log reads; `git clone -q --shared /home/user/orbit-board clone3-c1` in `work/` under `setsid -w
timeout -k 10 600`, run directly (its PID was not captured; it ended before the next command), then `git checkout -q
7ee498a`, the three files copied in, and a `node_modules` symlink to the read-only checkout's; `soffice --version` (noted
in `pids.txt`, PID not captured, exited at once).

## PIDs

Every command this builder ran under `bin/r.sh` (lock check; `setsid -w timeout -k 10 600`; PID recorded) is in
`pids.txt` below the line "third builder (second start of this track) begins 2026-10-13 14:51:41 EDT"; the lines above
it are the earlier attempt's. No process was killed by this builder. The two lanes and the waits were shell loops started
from this session (`run_in_background`), each running one `r.sh` command at a time; at most two node or Chromium processes
of this builder ran at once (a Chromium probe ran alone: playwright's node and its Chromium).

## Not done, said plainly

- **No commit, stage or push**, anywhere; `/home/user/orbit-board` and `/home/user/orbit-ui` were only read (and cloned
  with `--shared` into `work/` for scratch runs, where nothing was committed).
- **audit-import and audit-board were not run** (the lead runs them alone). By reading: no block in either feeds a
  forbidden character or a literal `_xHHHH_` to an export -- a scan of every file under `tools/` finds none raw and no
  `_xHHHH_` literal, and the workbooks the suites build with `buildXlsx` (audit-import's `mk` and `__wb`, audit-recon's `__w7x`) hold plain
  test text ("O&M <ampersand> \"quoted\"", "W2 IDLE" …). The one
  existing check that feeds such a character (audit-other's IDS reason `FY27\u0007`) is refused by the prompt before the
  writer, as before, and passes on `c1` (`S3-c1-audit-other`).
- **`tools/export-audit/mutate.mjs` was never imported, executed or run**; it was read and edited as text only
  (`mutate.mjs.txt`; mutants made with `rec/bin/mkmut.py`, counts with `rec/bin/mcount.py`, both `python3 -I`). In the
  scratch clone it is a copy of that text, which no suite run here reads.
- **The full-suite mutation sweep** (each new mutant through the whole audit-recon) was not run: each was run through the
  focused block, built verbatim from the suite. The final-tree queue is the lead's.
- **Excel and PowerPoint themselves** were not run (LibreOffice 24.2 and Chromium were).
- **Not changed, and said in the drafts:** half of an emoji is written as U+FFFD (decision 3); a CR in a cell and TAB/LF
  in a sheet name are written as they are (decision 4); the board's reader keeps `_xHHHH_` from another program's
  workbook as written (decision 2) -- a candidate ledger row for the lead: "the workbook reader does not decode OOXML
  `_xHHHH_`, so text from a LibreOffice-written source holds the `_x000b_` spelling (Excel not run), and since U37 a
  workbook export carrying such text is refused until the source is corrected"; number formats and fills unchecked
  (decision 9); workbooks and decks exported before this change are not repaired.
- **Codex's runner.py and Codex's probes were not run.** `codex/applied/` was used only as a board for the earlier
  attempt's own probe (`P-repro-codex2`).
- **U40 was not composed with this commit** (read only; see above).
