<!-- recovery/v200/UNRESOLVED-LEDGER.md, row U37. Text to APPEND to the row's last (Status) cell, after "Release blocker.".
     <sha> = the U37 commit; <time> = when the lead commits it (Eastern). Nothing here edits the regtext track's records; the
     regtext round-2 note in this row's Evidence cell (the slide deck) stays as it is: this commit closes it.
     Wrapped here for reading; in the table it is one line, joined with spaces. -->

 **Fixed by its own commit `<sha>` (<time> ET, 13 Oct), built by the u37 track from Codex's A2 refusal, after review, and
extended to the slide deck, the funds-flow chart image and the IDS box.** Every workbook and the deck are checked before a byte is made: each sheet name
as written (its first 31 characters), each text cell, each slide. A character XML 1.0 forbids (U+0000–U+0008, U+000B, U+000C,
U+000E–U+001F, U+FFFE, U+FFFF) refuses the export; so does a literal `_xHHHH_` in a workbook, which a spreadsheet reads as the
one character it spells. The alert and the status line name the sheet and the cell, or the slide, its title and the text,
with the character spelled out; all 16 workbook routes and the deck stop there, before a Blob, a download, their own
"exported" line or the IDS ORG; the open IDS box drops an earlier prompt problem. The funds-flow chart's Save as image
(an SVG read back as an XML image) is refused before its Blob, naming the drawn text; on the base Chromium could not render
it and said only "Could not render the chart to an image". An export without such text is byte for
byte what it was. Measured on the base with LibreOffice 24.2: such a workbook opened with the sheet cut off at that cell, the
deck with the rest of the Mission Critical table gone (closing the row's "Not checked"). Test: audit-recon "v2.00 (U37)",
84 checks, 60 failing on `7ee498a`, 24 passing on both (the controls and the no-page-error check); 35 mutations (`v200-u37-*`), each caught. Left as they were,
and said in NEXT-VERSION.md: half of an emoji (the board's own cuts make one; the encoder writes U+FFFD, which XML allows); a
carriage return in a cell, and a TAB or line break in a sheet name, which XML allows and a reader normalises; the board's
reader keeping a workbook's `_xHHHH_` as written (LibreOffice saves U+000B as `_x000b_`), so imported text can now refuse an
export until the file it came from is corrected; Excel and PowerPoint themselves were not run. **Status: fixed, in review.**
