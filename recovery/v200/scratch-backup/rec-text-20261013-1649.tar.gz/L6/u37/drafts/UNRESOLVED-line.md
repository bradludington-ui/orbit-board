<!-- NEXT-VERSION.md, "Unresolved after R1–R5 (11 Oct)". At 7ee498a the list has no U37 line (lines 778–809 hold U1–U14
     only), so A is a NEW line after the U14 line. If the registry-text track's draft line lands first, its sub-bullet for
     U37 is replaced by B instead (its text as it stands in rec/L6/regtext/drafts/UNRESOLVED-line.md is quoted below). -->

A. NEW line, after the U14 line:

  - **U37: built as its own commit** (a release blocker, the lead, 13 Oct, 12:02 PM ET): no workbook, no deck and no chart
    image is made from text holding a character XML 1.0 forbids (U+0000–U+0008, U+000B, U+000C, U+000E–U+001F, U+FFFE,
    U+FFFF), and no workbook from text holding a literal `_xHHHH_`; the export is refused before a byte, naming the sheet and
    cell, or the slide and its text, or the chart's text (above). Left as they were, and said above: half of an emoji, which
    the board's own cuts make and the encoder writes as U+FFFD; a carriage return in a cell, and a TAB or line break in a
    sheet name, which XML allows; the board's reader keeping a workbook's `_xHHHH_` as written, so imported text can refuse
    an export until its file is corrected. Excel and PowerPoint themselves were not run.

B. If the registry-text line lands first, its sub-bullet

    - **U37 (P1, a release blocker; its own fix track).** A character that XML 1.0 forbids makes a workbook part or a slide
      part malformed, for any text (registry text, a requirement title, a Plan Event on a slide, a destination name, which
      reaches `xl/workbook.xml`). A real browser's paste lets such a character in.

   becomes

    - **U37: fixed by its own commit** (above): such a character, in any text, refuses the workbook, the deck or the chart
      image before a byte, naming the sheet and cell, the slide and its text, or the chart's text; a workbook also refuses a
      literal `_xHHHH_`.
