<!-- U37's entry, under "### v2.00", after the U14 bullet and before "- **Unresolved after R1–R5 (11 Oct).**" -- or after the
     registry-text track's U36 bullet if that lands first. Same shape as the U13 / U1 / U14 bullets. Counts are this track's
     runs of 13 Oct (README.md). If the registry-text entry lands first, its "Not covered" paragraph "U37 (P1, a release
     blocker; fix track u37 under way on 13 Oct; this paragraph stands only if that fix does not land)" is removed, as that
     paragraph itself says, and replaced by: "- **U37:** fixed by its own commit (below / above)." -->
- **U37 — no export writes a character XML 1.0 forbids; it is refused before a byte, and says where** (a release blocker,
  the lead, 13 Oct, 12:02 PM ET; built from Codex's independent proposal, batch A2, after review, and extended to the slide
  deck). The one text writer both exports use, `_xesc`, escaped `& < > "` and nothing else, so U+0000–U+0008, U+000B,
  U+000C, U+000E–U+001F, U+FFFE and U+FFFF went into a workbook part, or a slide of the deck, as they were, and that part
  was not well-formed XML. An ordinary paste puts them there: Chromium 141 keeps U+000B, U+0001, U+0007 and U+001F pasted
  into a text field, and the board stores them. Measured on the base (`7ee498a`): a Plan Event typed with U+000B went raw
  into four sheets of the Excel export (Decision Bands, CR Cash Needs, Funded - Discretionary, PMO AV), two of the Priority
  drill, the Spend Plan Source, the IDS workbook and slide 5 of the deck; an RCN / EEIC title with U+0001 and U+000B into
  RCN-EEIC by Month; a funds-flow destination named with it, into three sheets of the Funds Flow workbook. LibreOffice 24.2
  opened such a workbook with the sheet cut off at that cell, and the deck with the rest of the Mission Critical table gone,
  its TOTAL and its MC SHORT row with it, and said nothing. Every workbook and the deck are now checked before a byte is
  made: each sheet name as it is written (its first 31 characters), each text cell, each slide. Such a character refuses
  the export, and the alert and the status line name the place (the sheet and the cell, or the slide, its title and the
  text) and show the text with the character spelled out where it sits. A workbook also refuses a literal `_xHHHH_`,
  because a spreadsheet reads it as the one character it spells (LibreOffice shows `_x0041_` as "A" and `_x000B_` as
  U+000B); the deck carries such text as typed. Each of the 16 routes that write a workbook, and the deck, stops there:
  before a Blob, a download, its own "exported" line, or anything it keeps (the IDS export's ORG). The IDS box, if open, no
  longer gives an earlier prompt problem as the reason. The funds-flow chart's "Save as image" reads the drawn chart back as
  an XML image: with such a character in a drawn name a browser could not render it and said only "Could not render the
  chart to an image" (Chromium, measured); it is now refused before its Blob, naming the text. Nothing is cleaned or cut: the
  text on the board stays as it was, and an export without such text is byte for byte what it was (all 17 routes, frozen
  clock, base and fix; the chart image still downloads in Chromium). Codex proposed the refusal, not the OOXML `_xHHHH_`
  escape: the board's own workbook reader keeps `_xHHHH_` as written, so escaping would change how the board reads back its
  own workbooks.
  - **What users may see:** an export refused with, for example, "Excel workbook not exported: sheet “Decision Bands”, cell
    H18 holds character U+000B, which ORBIT cannot write into a workbook without damaging it. It reads “Plan[U+000B]event”.
    No file was made, and the text on the board is unchanged. Change that text where it was entered — on the board, or in
    the file it was imported from — and export again." The deck says "PowerPoint deck not exported: slide 5 (“Mission
    Critical — Must-Pay Requirements”) holds character U+000B, which ORBIT cannot write into a deck without damaging it, in
    the text “Plan[U+000B]event”." The chart image says "Chart image not exported: the chart holds character U+000B, which
    ORBIT cannot draw into an image, in the text “Ctl[U+000B]”." A workbook holding the text `_x0041_` is refused the same
    way, "which a spreadsheet would read as a single character". Text imported from a workbook another program wrote can hold such a spelling: LibreOffice
    saves a U+000B as `_x000b_`, the board's reader keeps it as written ("Engine_x000b_spares"), and a workbook that
    carries it is now refused, naming the cell; the person corrects the file it came from and imports it again.
  - **Test:** audit-recon "v2.00 (U37) — no export writes a character XML 1.0 forbids; it is refused before a byte, and says
    where" (84 checks): each of the 31 characters in a cell; the words, whole; a sheet name; a literal `_xHHHH_` in a cell
    and a sheet name; the deck; where a person meets it (exportExcel, exportCSV, exportSrc, exportFlow and the IDS export,
    each naming the cell the base wrote the character into, the IDS ORG not kept, and the open IDS box no longer giving a
    missing reason as the reason; the funds-flow chart's Save as image, the chart drawing a destination named with
    U+000B); and every caller -- the 16 workbook routes and the deck, each made on ordinary data and then stopped by a
    stand-in refusal with no Blob, no download, no word after it and nothing changed. 60 checks fail on the board before
    the change; the 24 that pass on both are the controls (escape-like text a spreadsheet reads as
    written; ordinary text with a TAB, a line break, an emoji and half of one, read back by the board; a sheet name whose
    character lies past the 31 written; a carriage return; the deck with `_x0041_`; each route making its file on ordinary
    data, and the chart image's drawing on ordinary data; no page error).
  - **Mutations:** `v200-u37-xlsx-unchecked`, `-pptx-unchecked`, `-name-unchecked`, `-cell-unchecked`,
    `-literal-unchecked`, `-nonchars-allowed`, `-vt-allowed`, `-wrong-cell`, `-show-raw`, `-stat-silent`, `-wrong-slide`,
    `-ids-org-kept`, `-ids-stale-note`, `-name-past-31`, `-cr-refused`, `-advice-board-only`, `-png-unchecked`,
    `-png-markup`, and `-guard-<route>` for each of the 17 callers (`exportrlgplan`, `pmoreport`, `crexport`, `exportidsreq`, `exportflow`, `exportexview`, `exportsrc`,
    `exportplans`, `exportfydpplan`, `exportcyccompare`, `exportreprog`, `exportfcview`, `exportcsv`, `exportacetieout`,
    `exportexcel`, `exportcoa`, `exportppt`); each caught by the focused block (full-suite sensitivity runs in the
    final-tree queue).
  - **Not covered:** Excel and PowerPoint themselves (LibreOffice 24.2 was run; Office was not). Half of a two-part
    character is not refused: the browser's encoder writes U+FFFD in its place, which XML allows, and the board's own cuts
    make one out of a whole emoji (a title at 44 characters on CR Cash Needs and 56 on the deck, a PMO sheet name at 31, a
    funds-flow sheet name at 28 -- U42); refusing it would refuse the Excel export for an emoji in a title and the
    Priority drill for one in a PMO's name. A carriage return in a cell is written as it is, and a standards XML reader gives it back as a line feed; a TAB
    or a line break in a sheet name is read as a space (both allowed by XML; not changed here). The board's reader still
    keeps a workbook's `_xHHHH_` as written, so imported text can hold one (above). Number formats and fill colours are not
    checked: every one is the board's own constant or a band colour held to `#RRGGBB` on import. CSV, JSON, HTML and text
    exports are not XML and are unchanged. A workbook or deck exported before this change is not repaired.
