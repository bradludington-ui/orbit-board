# HOLD track — U3 and U4: the mixed-import hold cannot be written past

Builder's record for ORBIT v2.00, release track HOLD. Everything here is in `rec/L6/hold` (this directory). Nothing was
edited, staged, committed or pushed in `/home/user/orbit-board` or `/home/user/orbit-ui`; the lead commits. Times are
Eastern (`TZ=America/New_York date`). This README was assembled at {{NOW}} by `bin/mkreadme.py` from `README.src.md`
(hand-written) and the run records (`logs/runs.txt`, `logs/bx.txt`, `pids.txt`); the diffs below are inlined from
`diffs/` byte for byte.

## At a glance

| | U3 (commit 1, copy `c1`) | U4 (commit 2, copy `c2`) |
|---|---|---|
| Reproduced on the base (`7ee498a`, board `fce8a391`) | yes, six ways a save is asked for (probe, literals) | yes, held at the read, at the history copy, and Take the pen (probe, literals) |
| Board change | 5 code lines added (+3 comment lines) | 7 code lines added (+6 comment lines) |
| Suite block (audit-import) | 47 checks: **18 fail on base**, 0 on c1, 0 on c2 | 18 checks: **10 fail on base**, 10 on c1, 0 on c2 |
| New mutations | 6, each caught by the block | 5, each caught by the block |
| Re-run after the 9:11 AM ET restart (`r2-*`, fifth builder) | base 18 fail, c2 0: the same checks, verdicts and values as `r1-*` | base 10, c1 10, c2 0: the same as `r1-*` |
| Existing checks (focused, every audit-import block that touches these paths) | 709 checks: identical checks, verdicts and values on base, c1, c2 | (same runs) |
| Existing hold mutations on the final copy | {{EXMUT_SUMMARY}} | |
| mcount (text) | 1334 entries, each once | 1339 entries, each once (base 1328) |
| Other suites + `npm run check` (scratch clones) | — | {{SUITES_SUMMARY}} |

Proposed commits (the lead commits; nothing is committed here):

1. `v2.00 (U3): a Save asked for during the mixed-import hold is refused at once, never queued` — copy `c1`: board
   `82a2f1cc`, audit-import `22cdd78e`, mutate `c3cab761` (audit-recon `529e36f7`, audit-board `a7c575e5`, audit-other
   `d89396b0` unchanged).
2. `v2.00 (U4): the folder save checks the mixed-import hold after its read and before its write` — copy `c2` (cumulative):
   board `4b755576`, audit-import `f25c69f7`, mutate `27f0fdb6` (the other suites unchanged).

In each copy the mutation list is `tools/export-audit/mutate.mjs.txt`; it is committed as `tools/export-audit/mutate.mjs`.

## Resuming: what was kept from the earlier attempts, and what was re-run

### The fifth HOLD builder (13 Oct, from 9:13 AM ET)

The fourth builder was stopped by a usage limit at about 6:01 AM ET with everything built and run; the README (assembled at
5:58 AM ET) and the drafts were being finished. The container restarted at 9:11 AM ET. Before relying on anything I checked:

- **Copies and diffs.** `diff -rq` against the base and between the copies: only the board, `audit-import.mjs` and
  `mutate.mjs.txt` differ, base→c1 and c1→c2; the `node_modules` links are intact. The six diffs re-derived now
  (`chk5/`) are byte-identical to the stored `diffs/`, and none removes or changes a base line (pure insertions). Blobs
  re-hashed: board base `fce8a391` → c1 `82a2f1cc` → c2 `4b755576`; audit-import `4aba2506` → `22cdd78e` → `f25c69f7`;
  mutate `cbc6defc` → `c3cab761` → `27f0fdb6`; audit-recon, audit-board, audit-other unchanged. `orbit-board` HEAD is
  now `f40eded`; its board, suites, `mutate.mjs`, `package.json` and `NEXT-VERSION.md` blobs are still `7ee498a`'s (it
  differs only under `recovery/`), so the base stands.
- **The code.** I read both board diffs against the base's code (`impMixedBlock(what, quiet)`, `impMixedOn`,
  `saveSerial`, every caller of the five entry points: each awaits the result or ignores it, so a refusal returning at
  once — `undefined` or `false` — is handled as the refusal at the start of the run was; the autosave's `done=await p`
  stays false and says nothing). I kept the boards, blocks and entries unchanged.
- **Logs.** Every log in `logs/` has an exit record except `f3-F-holdall-c2`, which the third builder recorded as cut off
  and the fourth re-ran as `g4-F-holdall-c2` (complete). `x10-c2-saves-not-serial` (6:00–6:02 AM ET, the fourth builder's
  last run) is complete, with its exit record; it was not yet in the README.
- **Re-run now, after the restart** (`r2-*`, the same harness files): U3 on base and c2, U4 on base, c1 and c2. Each gives
  the same checks, verdicts and values as `r1-*` (table below).
- **Run now, new:** `x11-base-saves-not-serial` — the existing mutation `saves-not-serial` on the base against
  `F-folderA`, to compare with the fourth builder's `x10` on c2 (below); `bin/exsweep.py` (text only) lists every existing
  mutation entry whose find lands in the functions U3/U4 change.
- **Drafts:** kept, with these corrections: a broken line wrap in the U3 entry; the U3 entry's sentence on which blocks
  catch the older hold mutations (it said "the same existing blocks", not measured on the base for nine of them; now it
  names the blocks, and `saves-not-serial`'s five checks measured on both boards, x10/x11); a "Not covered" clause on a
  hold that comes while Take the pen reads or asks; the ledger texts also as one line each (a table cell holds no line
  break); and the "Unresolved" and R4b texts as exact lines with their leading spaces (the R4b text is now one added line,
  not a replacement). README: this section, the r2 and x10/x11 tables, the sweep of other entries, the overlap note on the
  adoption and U20/U30 tracks, the draft blobs and the run records.

### The fourth HOLD builder (13 Oct, 4:20–6:01 AM ET)

This directory held the third HOLD builder's work (stopped by a usage limit at about 12:51 AM ET; container restarted at
4:11 AM ET). Its `c1/` and `c2/` copies date from the first builder (5:51 PM ET, 12 Oct) with the third builder's edits (board
12:14–12:15 AM ET, suites 12:21 AM, mutate 12:25 AM). Before building on anything the fourth builder re-checked it ("I"
in this subsection is the fourth builder):

- **Copies.** `diff -rq` against the base: only the board, `audit-import.mjs` and `mutate.mjs.txt` differ in each; every
  other file (other suites, `NEXT-VERSION.md`, `package.json`, the shim, the `node_modules` link) is the base's. The diffs
  re-derived now (`chk/`) are byte-identical to the stored `diffs/`; every change, base→c1→c2, is a pure insertion (no base
  line changed or removed, in all three files). The U3 block is byte-identical in c1's and c2's suites and to
  `blocks/u3.mjs.txt`; the U4 block to `blocks/u4.mjs.txt`; the entries to `blocks/entries-u*.mjs.txt`.
- **Mutants and harnesses.** All 41 mutant boards in `mut/` were rebuilt from the copies' `mutate.mjs.txt` (text only,
  `rec/bin/mkmut.py`) into `chk/mut/`: all 41 identical. All 11 focused harnesses were rebuilt from c2's suite into
  `chk/harness/`: all identical to `harness/` and to the copies under `h/base`, `h/c1`, `h/c2`.
- **Kept as sound** (complete logs, exit records, the board and harness blobs they name are today's): the 39 probe runs
  (`probe-*`, 12:11–12:20 AM ET); the focused runs `f2-*`; the mutant runs `m1-*`, `m2-*`, `m3-*`; `f3-F-holdpre-base`,
  `f3-F-holdpre-c2`, `f4-F-litepre-base`, `f4-F-liteall-c2`.
- **Re-run:** `f3-F-holdall-c2` had been cut off by its batch wrapper's 600 s bound (no exit record; 170 of 270 rows):
  re-run alone as `g4-F-holdall-c2` (all 270 checks pass). The U3 and U4 focused runs on base, c1 and c2 were re-run as
  `r1-*` for confirmation: the same checks with the same verdicts as `f2-*`, every one.
- **Not run before, run now:** every other audit-import block that touches the changed paths, on base, c1 and c2
  (`g*`); the twelve existing hold mutations on c2 and two of them on the base (`x*`); the other suites and
  `npm run check` in scratch clones (`S-*`); mcount on every copy; a harness for the one block no earlier harness
  held (`F-nr02`).
- **Drafts, README:** written now (the earlier `drafts/` was empty).

## The findings, reproduced on the base first

Probe: `probe/hold-probe.mjs` (blob `fb8c557d`) = `probe/head.mjs.txt` + the W1H block and the W2 helpers copied
verbatim from the base's audit-import (lines 3745–3813 and 4153–4258, asserted by their first and last lines;
`bin/mkprobe.py`) + `probe/body.mjs.txt`. It records observations only (counts, booleans, the Full Fund generation a file
holds read from its text, status lines); the verdicts below are written by hand against them. Outputs: `out/probe-<copy>-<scenario>.json`.

**U3** — save A (the board file, or the shared folder) is held at the close of its write; a full import stops part-way and
cannot be put back (the hold is on); request B is asked for; saving is allowed again (`impMixedClear`, confirm answered
yes); A is let go.

| Scenario (B) | Base: after 60 turns | Base: end | c1 / c2: after 60 turns | c1 / c2: end |
|---|---|---|---|---|
| U3-file `saveInPlaceFile()` | not decided, "⏳ A save is already under way — this one runs as soon as it finishes." | `perm 2 · read 2 · open 2 · writes 2`, file Full Fund **NEW** | decided, "⛔ Saving to the board file is refused. …" | `perm 1 · read 1 · open 1 · writes 1`, Full Fund OLD |
| U3-save `saveInPlace()` (💾 Save, board file) | same, queued | writes 2, Full Fund **NEW** | refused at once, same words | writes 1, OLD |
| U3-pen `takePen()` (board file) | queued, after **reading the file again and asking** (read 2, asked 1) | writes 2, Full Fund **NEW** | "⛔ Taking the pen is refused. …", read 1, asked 0 | writes 1, OLD |
| U3-folder `saveInPlace()` (folder) | queued | 3 writes of the folder's copy, 2 history copies | "⛔ Writing to the shared folder is refused. …" | 2 writes, 1 history copy |
| U3-publish `driveStorePush(false)` (⬆ Publish now) | queued | 3 writes, 2 history copies | refused at once, same words | 2 writes, 1 history copy |
| U3-resolve `driveResolve('mine')` (Save yours over theirs) | queued | 3 writes, 3 history copies, 2 questions | "⛔ Choosing between the copies is refused. …" | 2 writes, 1 history copy |
| C3-file (control: no import) | queued | writes 2, OLD | queued (unchanged) | writes 2, OLD |
| C3-idle (control: hold on, nothing running) | refused, `perm 0 · read 0 · open 0 · writes 0` | — | the same | — |

In each U3 case on c1/c2, the retry after saving was allowed writes once and says "Saved" (the control).

**U4** — the board's first copy is saved to the folder (v1) and a note typed (EDIT-1); 💾 Save is held at a wait; the
import stops part-way there; the save is let go.

| Scenario | Base (and c1) | c2 |
|---|---|---|
| U4-read (held at its read of the folder's copy) | **1 write**, history +1, folder copy = EDIT-1, `DIRTY` false, stamp moved, "✅ Saved O&M FY27 to the shared folder — 5 KB." | 0 writes, history +0, folder copy = v1, `DIRTY` true, stamp back, "⛔ Writing to the shared folder is refused. …" |
| U4-hist (held at the close of its history copy) | **1 write**, history +1, stamp moved, "✅ Saved … A change made while it was saving is not in the folder yet" | 0 writes, history +1 (v1 as read), stamp back, refused |
| U4-pen (Take the pen from Alice, held at its history copy) | **1 write**, writer **brad**, 1 pen line, stamp and name moved, "✅ Saved … You now hold the pen for it." | 0 writes, writer Alice, 0 pen lines, stamp and name back, refused |
| C4-read (control: nothing happens at the read) | 1 write, "✅ Saved", header "Saved 12:13 AM" | the same ("Saved 12:20 AM") |
| C4-retry (U4-read, then allow saving again and 💾 Save) | first save already wrote; retry writes again | first refused; retry writes once, EDIT-1, "✅ Saved" |

Both findings reproduce; neither is called rare or common (how often an import stops part-way during another save was not
measured).

## The changes (exact diffs)

### Commit 1 — U3: board (`diffs/c1-board.diff`, blob `b172c561`)

```diff
{{DIFF:c1-board}}
```

### Commit 1 — U3: audit-import (`diffs/c1-audit-import.diff`, blob `e90c7511`)

```diff
{{DIFF:c1-audit-import}}
```

### Commit 1 — U3: mutate.mjs (`diffs/c1-mutate.diff`, blob `309c01b6`)

```diff
{{DIFF:c1-mutate}}
```

### Commit 2 — U4: board (`diffs/c2-board.diff`, blob `989ad20f`)

```diff
{{DIFF:c2-board}}
```

### Commit 2 — U4: audit-import (`diffs/c2-audit-import.diff`, blob `1e699987`)

```diff
{{DIFF:c2-audit-import}}
```

### Commit 2 — U4: mutate.mjs (`diffs/c2-mutate.diff`, blob `57e28f8c`)

```diff
{{DIFF:c2-mutate}}
```

## Decisions, with reasons, and the lead's six principles

**U3 — refuse at once at every way a save is asked for, not only the two the ledger named.** The ledger proposed
`saveInPlaceFile()` and `saveInPlace()` (the 💾 Save button, Take the pen). There are exactly four entry points into the
save queue (`saveSerial` callers): `saveInPlace`, `saveInPlaceFile`, `driveStorePush` (⬆ Publish now and the autosave) and
`driveResolve` (Save yours over theirs, Load theirs). The base probe shows the same queued-then-written path through
⬆ Publish now and Save yours over theirs (U3-publish, U3-resolve), so each gets the same one line; the finding is not closed
while any of them queues. `takePen` gets its own line as well: its question says "OK — take the pen and save now", and on
the base, under the hold, it read the board file again and asked that question first, and only then was its save queued
(probe U3-pen: read 2, asked 1). Each refusal uses the words its path already used (`saveInPlace` picks the folder's or the
board file's by `driveStoreOn()`; `driveResolve` keeps "Choosing between the copies", as its run says; `takePen` says
"Taking the pen", as its other refusals do), and the quiet autosave stays quiet. The checks at
the start of each run, and R4's after the read, are kept: a save asked for before the hold still meets them.

**U4 — check again after the read, and after the history copy, the last wait before the write.** The waits before the write
in `_driveStorePushRun` are `driveDir`, `driveStoreRead` and `snapKeep`. The first check covers the first two; the second
covers the history copy. The bytes are built between them, so an import stopping during the history copy leaves bytes with
no mix — the second check is there because the hold's contract is that nothing writes over the copy while the hold stands,
and because on the base that write said "✅ Saved" over the import's own message and its rescue buttons, and a Take the
pen held there took the pen. Stopped after the history copy, the save takes back its pen line (as the history failure just
above it does) and puts back the board's stamp, which the header shows as "Saved <time>" and by whom, unless something was
typed meanwhile (then the edit's stamp stands).

1. **Never lose any copy.** U3: the refused Save leaves the board file / the folder's copy as they were, with A's own write
   intact; nothing that was on screen is dropped. U4: the folder's copy keeps its bytes; the copy kept in the history before
   the refusal stays; the work stays on screen, unsaved (`DIRTY` true), and a Save once saving is allowed writes it
   (controls).
2. **Refuse or ask rather than guess.** Both refuse, with the hold's message and its buttons (save both copies; ⬇ Save a
   copy; allow saving again…). Nothing is queued to run later on a guess about what the person will decide.
3. **Money and exports.** No computation, money or export path is touched. The other suites (excel, ppt, other, recon,
   hostile, inject, boot-same, legacy) give the same results on c2 as on the base (below).
4. **Every word stays true, after it lands too.** U3: "⏳ … this one runs as soon as it finishes" was untrue under the hold;
   it is no longer said there. The refusal is the hold's own message, true while it stands. Take the pen no longer asks a
   question whose answer is then refused. U4: "✅ Saved" is no longer said when nothing should have been written; the header's
   saved time is not moved by a save that did not happen; the journal does not say the pen was taken.
5. **Smallest change.** U3: one line at each of five entry points (3 comment lines). U4: one line after the read, one line
   keeping the stamp, one five-line block before the write (6 comment lines).
6. **Existing checks preserved.** No existing check, fixture or expected value was edited; every change is an insertion.
   Every audit-import block that touches the changed paths (29 scenarios, listed below) gives the same checks, verdicts and
   values on base, c1 and c2. One shift in **which** check catches two existing mutations — not an edited expectation, but
   it must be said: `impmixed-file-unguarded` is no longer caught by R4b's before-file-access check
   (`audit-import.mjs`, R4b block, base lines 7023–7063: "refused before the file is touched: no permission request, no read,
   no open"; 5 checks fail there on the base), and `impmixed-folder-unguarded` no longer by the v1.95 hold block (base lines
   4373–4424) or the v1.99 batch hold block (base lines 6151–6228; one check each on the base). A Save asked for
   under the hold is now refused before its turn, so the check those mutations remove is reached only by a save asked for
   **before** the hold. Each is caught on c2 by exactly one check of the U3 block's "asked for before the hold" cases
   (below). R4b's and v1.95's checks still pass, with the same values.

**Kept from the earlier builders as built.** The c1 and c2 boards, blocks and entries above are the third builder's; the
fourth builder and I (the fifth) each read every line against the base and kept them unchanged (reasons above). Neither of
us changed anything in any copy.

## Tests

`audit-import.mjs`, inserted after `// ==== end v2.00 R4 ====` (the R4/R4b blocks' patterns: `await (async () => {`,
`bootMark()`, the two-space `const name`, `bootRelease(__bm, keepBoards())`, `settleBoards()`, the `// ==== …` markers):

- "v2.00 (U3) — a Save asked for during the mixed-import hold is refused at once, never queued": 47 checks (block lines
  7065–7197 in c1's suite).
- "v2.00 (U4) — the folder save checks the mixed-import hold after its read and before its write": 18 checks (block lines
  7198–7292 in c2's suite).

Expected values are hand-written literals (`'perm 1 · read 1 · open 1 · writes 1'`, `'OLD'`, `[2, 0, 0]`, `'EDIT-1'`,
`'Alice'`, the refusal words); board helpers are used only to observe.

**Focused runs** (`bin/mkfocused-multi.py`: the block, the suite's own imports, failure list, keepBoards, SEEN/chk and
scenario-ran guard, and the top-level helpers the block names, all verbatim; run by `bin/runner.mjs` against each copy's
own `boot.mjs`, `BOARD` unset and asserted):

{{FOCUSED_TABLE}}

Failing checks on the base (the same on the first run `f2-*`, the re-run `r1-*` and the fifth builder's re-run `r2-*`):

{{BASE_FAILS}}

The fifth builder's re-runs after the 9:11 AM ET restart, check by check against `r1-*` (`out/*.checks.jsonl`):

{{R2_CMP}}

## Mutations

**New entries** (in each copy's `mutate.mjs.txt`, before the line `  // v2.00 (R3, Brad 11 Oct): a save that lands under a
locked view says it saved the working plan.`; ids `v200-u3-*`, `v200-u4-*`). Each find matches its board exactly once.
Mutant boards by `rec/bin/mkmut.py` (text only). U3 mutants were made from c1 (`m1-*`) and from c2 (`m2-*`, the same checks
and verdicts as `m1-*`); U4 mutants from c2 (`m3-*`). Each run against the block's focused harness:

{{NEWMUT_TABLE}}

**Existing hold mutations on the final copy c2** (against `F-liteall`: the v1.95 hold, the lifting of the hold, the v1.99
batch hold, R4/R4b, U3 and U4, all verbatim), and the two whose catching moved, on the base (against `F-litepre`, the same
blocks without U3/U4). `saves-not-serial` was also run against `F-folderA` (the v1.95 "Save acknowledges exactly what it
wrote" blocks, verbatim) on c2 (`x10`, the fourth builder) and on the base (`x11`, mine), to see whether the blocks that catch
it are the same on both:

{{EXMUT_TABLE}}

{{X10_CMP}}

**The other existing entries on these paths.** `bin/exsweep.py` (text only, `rec/bin/mcread.py`) lists 47 entries whose find
lands in `saveInPlace`, `saveInPlaceFile`, `_saveInPlaceFileRun`, `driveStorePush`, `_driveStorePushRun`, `driveResolve`,
`_driveResolveRun`, `takePen`, `saveSerial` or `impMixedClear`, or that name the hold (`out/exsweep-c2.txt`): the 11 new ones,
9 of the 12 existing hold mutations above (`impmixed-not-marked`, `-not-kept` and `-lift-partial` change the hold's code
elsewhere), and 27 others (the file save's guards and acknowledgements, the folder save's history, writer, year and base,
Save yours over theirs' forced copy, R3's locked view; listed in that file). Those 27 were not run here. U3's and U4's lines change nothing unless the hold is
on (`impMixedBlock` returns false and `impMixedOn()` is false), so in every scenario that never sets the hold a mutant of
c2 behaves as the same mutant of the base; only a scenario that sets the hold could catch one differently, and those
scenarios are the hold blocks above. Full-suite sensitivity is the lead's run.

**mcount** (`rec/bin/mcount.py`, text only; `out/mcount/*.json`): base 1328 entries, 1328 once; c1 1334, 1334 once; c2 1339,
1339 once; none missing, none multiple, none unparsed. `mutate.mjs` was never imported, executed or run.

## Existing checks: every audit-import block on the changed paths

`bin/scnmap.py` lists the 29 scenarios in c2's audit-import that name `saveInPlace()`, `saveInPlaceFile`,
`driveStorePush`, `driveResolve`, `takePen`, `liveTick`/`livePublish` or set the hold. Each is in one of these harnesses
(verbatim from the suite): `F-folderA` (11 blocks), `F-folderB` (10), `F-hold` (3), `F-nr02` (1), `F-u2` (2), `F-u13` (1),
plus U3 and U4. `F-holdpre`/`F-holdall` and `F-litepre`/`F-liteall` are the hold blocks without/with U3 and U4.

{{REGRESSION_TABLE}}

## Other suites and `npm run check`

Run in scratch clones (`git clone --shared --no-checkout /home/user/orbit-board`, then `git checkout --detach 7ee498a`; the
copy's board, audit-import and mutate copied over; `node_modules` linked; nothing committed): `clones/base`, `clones/c1`,
`clones/c2` (c1's clone was made and not used: the suites were compared on the final copy, c2, against the base).
`orbit-board` HEAD was `674b6c5` then (`f40eded` at 9:13 AM ET); each differs from `7ee498a` only under `recovery/` (board,
suites, mutate, package.json and NEXT-VERSION.md blobs equal), so `7ee498a` was checked out. audit-import and audit-board were not run in
full (the lead runs those alone).

{{SUITES_TABLE}}

## Overlap with U18 (built separately on the same base)

U18's builder (`rec/L6/u18`, board `e3986f30`) changes the same lines of `_driveStorePushRun`: it keeps the stamp
(`const was={ts:MS.ts, by:MS.by};`) before `MS.ts=Date.now()`, and re-reads the folder's copy after the history copy, just
before `await driveWrite(...)`. Whichever is committed second will not apply cleanly. Merged, the order must be: history
copy → U18's re-read and comparison → U4's hold check → `driveWrite`, because U18's re-read is then the last wait before the
write; and the two stamp put-backs become one (`ts0/by0` or `was`). Each block's checks should then be run again on the
merged board. This track did not build or test the merge.

Near, not the same lines (checked by the fifth builder, 13 Oct, against each track's latest copy in `rec/L6/`): the adoption
track (`adopt/c3`, U29) and the U20/U30 track (`u20u30/c2`, U30) change `driveClashSay`'s message (base lines 26956–26961),
which ends about eight lines above `driveResolve`, where U3 adds a line (base line 26971). The hunks do not share or touch a
line, so each should apply on top of the other; the lead's commit check is what shows it. U20/U30's change at base lines
6492–6502 is in `saveSerial`'s neighbourhood (base line 6494), which U3 does not change.

## Not covered, and what was not done

- **A save already running when the hold comes** still lands and says "Saved": the board file's write after R4's re-check
  (`createWritable`/`write`/`close`), and the folder's `driveWrite` itself. Their bytes were built before the import, so
  they carry no mix, but the "Saved" line replaces the import's message (the hold's own message comes back on the next
  refused Save). The probes show it (c1/c2 U3-file: A's "💾 Saved in place … A change made while it was saving is not in the
  file yet" after B's refusal). Not proposed here: outside U3/U4 as written; the lead decides.
- **Load theirs** (`_driveResolveRun`, `'theirs'`) checks the hold only at its start; a hold set during its read was not
  examined.
- **Save yours over theirs, then a refusal:** by code (not run), `_driveResolveRun('mine')` records their copy as the base
  before calling the save; if the hold (or anything else) then stops the save, a 💾 Save once saving is allowed writes over
  their copy without asking again — as the person chose, with theirs kept in the folder's history.
- **Take the pen with the hold coming during its read or its question:** U3 checks the hold before Take the pen reads
  anything; a hold that comes while it reads the file or the folder's copy, or while its question is open, meets the U3
  check in `saveInPlace()` after the answer — refused at once, with the hold's message, after the question was asked. Not
  run.
- **One extra history copy:** a save the hold stops after its history copy leaves that copy (the folder's own copy) in the
  history until the next save that lands thins it.
- A save waiting for another tab's Web Lock (U20) is not changed. The hold is seen in another tab only when its mark could
  be kept in browser storage (a stopped import whose storage refused the mark holds this page only, as before).
- Not run: the full `audit-import.mjs` and `audit-board.mjs` (the lead's); `mutate.mjs` (never imported, executed or run;
  read as text only); any Chromium/playwright tool (none needed: no layout or UI surface changed); `playwright install`
  (never).
- Not run by the fifth builder: the other suites and `npm run check` again (the fourth builder's `S-*` runs at 5:49–5:59 AM
  ET are on the same files: the copies' blobs are unchanged since); the mutants `m1-*`/`m2-*`/`m3-*` and the regression
  harnesses `g*` again (same files, complete logs with exit records); the 27 other existing entries above.
- Not done: the U18 merge; any commit, stage or push; any edit in `/home/user/orbit-board` or `/home/user/orbit-ui`.

## Drafts (for the lead)

- `drafts/NEXT-VERSION-U3.md` — the U3 entry (commit 1).
- `drafts/NEXT-VERSION-U4.md` — the U4 entry (commit 2).
- `drafts/LEDGER-and-UNRESOLVED.md` — the text to append to the U3 and U4 ledger rows (with `<sha1>`/`<time1>`,
  `<sha2>`/`<time2>`; wrapped to read, and as one line to paste, since a table cell holds no line break), the exact
  replacement lines for "Unresolved after R1–R5" (leading spaces included), and an optional line to add under R4b's
  "Tracked, not changed" bullet.

Blobs (`git hash-object`) of the drafts as handed over: {{DRAFT_BLOBS}}.

## Files

- `c1/`, `c2/` — the cumulative copies (base + U3; base + U3 + U4). `diffs/` — their diffs. `blocks/` — the suite blocks
  and mutation entries as text. `probe/` — the reproduction. `harness/` (and `h/<copy>/tools/export-audit/`) — the focused
  harnesses. `mut/` — the mutant boards. `out/` — probe records, per-check records (`*.checks.jsonl`, rows
  `[scenario, case, check, passed, got]`), summaries, mcount. `logs/` — every run's log (`# start`, `# end … exit … wall_s`),
  `runs.txt`, `bx.txt`. `clones/` — the scratch clones. `chk/` — the fourth builder's rebuild checks; `chk5/` — the fifth
  builder's re-derived diffs. `bin/` — every script used.

## Every run

All node runs through `bin/run.sh` (`setsid -w timeout -k 10 600`, the `AUDIT_IMPORT_RUNNING` lock checked before each
start — it was never present during the fourth or the fifth builder's runs — `BOARD` and `MUT_FIRST_FAIL` unset); other
bounded commands through `bin/bx.sh`. The third builder's runs (before 4:11 AM ET) are listed as recorded; the fourth
builder's follow the first "resumed" line in `runs.txt`, and mine (the fifth) the second. In `bx.txt` the first three lines
(`mkmuts`, `mkharness2`, `mkharness3`) are the third builder's, then the fourth builder's, then mine after the "resumed"
line. My first text checks (the copies' `diff -rq`, the re-derived diffs into `chk5/`, `git hash-object`, `bin/exsweep.py`'s
first run, `grep`/`sed` reads, the edits to the drafts and this README's source) were run directly in the shell, each done
in a few seconds; `exsweep` and `mkreadme` were then run again through `bx.sh` (in `bx.txt`). My r2 batch (`r2-*` and
`x11`) was started through `bin/batch.sh` directly, not inside `bin/bx.sh` as the fourth
builder's batches were: each run in it was bounded by `run.sh` (600 s), but the wrapper itself had no 600 s bound of its own
(its PID, 2317, is in `pids.txt`; it ended at 9:19:54 AM ET after 3 min).

{{RUNS}}

## PIDs

Every PID started, with its command, is in `pids.txt` ({{PIDCOUNT}} lines; the fourth builder's start after the line
"# resumed by the fourth HOLD builder", mine after "# resumed by the fifth HOLD builder"). No process was killed by the
fourth builder or by me. The third builder's note on
`f3-F-holdall-c2` (its PIDs 25052 and 25054 stopped by PID) is in `logs/runs.txt`.
