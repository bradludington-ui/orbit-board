<!-- Draft for NEXT-VERSION.md, under "### v2.00 — 11 Oct 2026 ...", after the last built entry (U14, or whichever the lead
has committed last) and before "- **Unresolved after R1–R5 (11 Oct).**". Wrapped as the U13/U1/U14 entries are. The lead
commits; nothing here is in any copy. Commit 1 of 2 on this track (copy c1). -->
- **U3 — a Save asked for during the mixed-import hold is refused at once, never queued** (the lead's decision on 12 Oct,
  under Brad's "Don't wait for me. Let's keep pressing throughout to get this next version published.", about 5:30 PM ET;
  Brad's R4b contract, 11 Oct: "a Save requested while the mixed-import hold is already active must refuse immediately,
  before file access. Clearing the hold later must not resume that refused request."). A Save asked for while the hold was
  on and another save was running was queued, not refused: the board said "⏳ A save is already under way — this one runs
  as soon as it finishes", and the hold was checked only when its turn came. If saving was allowed again first ("allow
  saving again…", answered yes), it ran and wrote: on the board file, the imported Full Fund plan, from the mix, over the
  one whole copy of the board as it was; in the shared folder, another write and another history copy. The same held for
  every way a save is asked for: 💾 Save, Take the pen (which also read the file or the folder's copy and asked first),
  ⬆ Publish now and Save yours over theirs. Now each of them checks the hold when it is asked for, before it waits its
  turn, before anything is read or asked, and refuses at once in the words of its own path; allowing saving again later
  does not bring it back. The checks at the start of each save's turn, and R4's after the read, stay: a save asked for
  before the hold, still waiting when the hold comes, is refused when its turn comes, before the file or the folder's copy
  is read.
  - **What users may see:** with the hold on, 💾 Save, ⬆ Publish now, Save yours over theirs and Take the pen are refused
    at once, also while another save is running: "⛔ Saving to the board file is refused." (the board file), "⛔ Writing to
    the shared folder is refused." (working out of the shared folder), "⛔ Choosing between the copies is refused.",
    "⛔ Taking the pen is refused.", each followed by the hold's own explanation and its buttons (Load theirs, which shares
    Save yours over theirs' path, is refused at once in the same words, where before it was refused at its turn). They
    no longer say "⏳ A save is already under way — this one runs as soon as it finishes". Once saving is allowed again,
    the Save is pressed again. Take the pen no longer reads the board file or the folder's copy, or asks whether to take
    the pen, while the hold is on. The quiet autosave is refused quietly, as before, now without waiting its turn. With
    no hold, nothing changes: a Save asked for during another waits its turn and writes after it.
  - **Test:** audit-import "v2.00 (U3) — a Save asked for during the mixed-import hold is refused at once, never queued"
    (47 checks). Save A is held at the close of its write; the import stops part-way and cannot be put back; B is asked
    for; saving is allowed again; A is let go. B is the board file's Save (`saveInPlaceFile()`), 💾 Save and Take the pen
    on the board file, and 💾 Save, ⬆ Publish now and Save yours over theirs working out of the shared folder. Each B is
    over at once, touches, reads and asks nothing more, is not queued, says it is refused, and is not brought back: A alone
    wrote, and the board file holds no imported plan (`perm 1 · read 1 · open 1 · writes 1`, Full Fund `OLD`). Controls:
    asked for again once saving is allowed, Save writes; with no hold, B waits its turn and writes after A
    (`perm 2 · read 2 · open 2 · writes 2`); a Save asked for before the hold is refused when its turn comes, before the
    file or the folder's copy is read. 18 checks fail on the board before the change (`fce8a391`), three for each B: it
    waits its turn, says nothing of the hold, and once saving is allowed it writes (on the board file `writes 2` and Full
    Fund `NEW`, Take the pen having read the file again and asked first; in the folder, one more write of the folder's copy
    and one more history copy, two for Save yours over theirs). Every control passes on both.
  - **Mutations:** `v200-u3-save-queued`, `-save-file-words`, `-file-queued`, `-publish-queued`, `-resolve-queued` and
    `-pen-reads-first`; each caught by the focused block (full-suite sensitivity runs in the final-tree queue).
  - **Which check now catches two older mutations.** Nothing in an existing check or fixture changes, and every existing
    check of the audit-import blocks on these paths passes on this board with the same values (focused runs). But a Save
    asked for under the hold is now refused before its turn, so the checks at the start of the turn are reached only by a
    save asked for before the hold: `impmixed-file-unguarded` is no longer caught by R4b's before-file-access checks (R4b
    still passes), and `impmixed-folder-unguarded` no longer by the v1.95 and v1.99 hold blocks' folder checks (both still
    pass). Each is caught by one check of this block's "asked for before the hold" cases (a permission request and a read
    of the board file, or a read of the folder's copy, where none is expected). On the U4 board (focused runs) the other
    ten existing hold mutations are caught too, nine of them by the v1.95 hold and R4 blocks; `saves-not-serial` is caught
    by the same five checks of the v1.95 "Save acknowledges exactly what it wrote" blocks on the board before the change
    and on the U4 board, and by this block's no-hold control and before-the-hold cases as well.
  - **Not covered:** a save already running when the hold comes. Its bytes were built before the import, so they carry no
    mix, but it lands and says "Saved" over the import's message. The folder save's window before its write is U4, next;
    the board file's own write (after R4's check) and the folder's write itself are not checked again. A hold that comes
    while Take the pen reads or asks meets this check in its Save, after the question was answered (by the code; not
    run). ⬇ Save a copy is never refused, by design.
