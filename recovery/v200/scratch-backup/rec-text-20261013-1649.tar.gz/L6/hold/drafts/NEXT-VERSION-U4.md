<!-- Draft for NEXT-VERSION.md, directly after the U3 entry (commit 1 of this track). Wrapped as the U13/U1/U14 entries are.
The lead commits; nothing here is in any copy. Commit 2 of 2 on this track (copy c2). -->
- **U4 — the folder save checks the mixed-import hold after its read and before its write** (the lead's decision on 12 Oct,
  under Brad's "Don't wait for me. Let's keep pressing throughout to get this next version published.", about 5:30 PM ET).
  `_driveStorePushRun` checked the hold once, at its start, before it read the folder's copy. A full import that stopped
  part-way during that read, and could not be put back, set the hold, and the save went on: it built its bytes then, wrote
  them over the folder's copy, marked the board saved, and said "✅ Saved O&M FY27 to the shared folder", with the hold on.
  The same import stopping while the save kept the folder's copy in the history (the last wait before the write) let the
  save write too, over the import's own message, and a Take the pen held there took the pen. Now the folder save checks
  the hold again after its read and again after its history copy, just before it writes. Held, nothing is written over
  the folder's copy; the history copy already kept (the folder's copy, as read) stays; a pen line it wrote is taken back,
  and the board's stamp, which the header shows as when it was saved and by whom, goes back to what it was unless
  something was typed meanwhile. The board says writing to the shared folder is refused, and why; a quiet autosave says
  nothing, as at its start.
  - **What users may see:** in that race, instead of "✅ Saved": "⛔ Writing to the shared folder is refused. A full import
    stopped part-way in this browser and could not be put back …", with the hold's buttons. The work stays unsaved; the
    folder keeps its copy; once saving is allowed again, 💾 Save writes it. If the import stopped during the history copy,
    the folder's history holds one more copy of the folder's own copy until the next save thins it.
  - **Test:** audit-import "v2.00 (U4) — the folder save checks the mixed-import hold after its read and before its
    write" (18 checks): 💾 Save held at its read of the folder's copy, and at the close of its history copy, with the
    import stopping part-way there: nothing written over the folder's copy (it keeps its bytes), nothing kept in the
    history when held at the read and the folder's copy as read kept once when held at the history copy, refused and not
    "Saved", the note unsaved and the stamp as it was; Take the pen from Alice held at its history copy: nothing written,
    Alice still holds the pen, no journal line saying Brad took it, the stamp as it was. Controls: the same holds with
    nothing happening there write once and say Saved; once saving is allowed again, 💾 Save writes the note. 10 checks
    fail on the board before the change (`fce8a391`) and on the U3 board: each held save writes the folder's copy and
    says "✅ Saved" with the hold on, and Take the pen leaves Brad the writer and a journal line saying he took it. Every
    control passes on all three.
  - **Mutations:** `v200-u4-read-unchecked`, `-hist-unchecked`, `-stamp-moved`, `-pen-line-kept` and
    `-hist-says-nothing`; each caught by the focused block (full-suite sensitivity runs in the final-tree queue).
  - **Not covered:** the write itself (an import stopping while the folder's copy is being written: the bytes were built
    before the import, so they carry no mix, but the save lands and says "Saved"); the board file's own write after R4's
    check, likewise; Load theirs (`_driveResolveRun`, `'theirs'`) checks the hold only at its start, and a hold set during
    its read was not examined; after Save yours over theirs, a save the hold stops leaves their copy recorded as the one
    the work came from, so once saving is allowed again 💾 Save writes over it without asking again (as chosen; theirs is
    kept in the folder's history; by reading the code, not run). If U18 (the re-read just before the write) is committed
    too, this check belongs after U18's re-read, which is then the last wait before the write.
