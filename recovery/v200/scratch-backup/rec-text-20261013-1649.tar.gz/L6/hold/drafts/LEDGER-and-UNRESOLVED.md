# HOLD track (U3, U4): ledger texts and the "Unresolved after R1–R5" lines (drafts; the lead commits)

`<sha1>`/`<time1>` are commit 1 (U3, copy c1); `<sha2>`/`<time2>` are commit 2 (U4, copy c2). Blobs are `git hash-object`.

## 1. Text to append to the U3 row (`recovery/v200/UNRESOLVED-LEDGER.md`, the row beginning "| U3 |", its last cell)

 **Built on the lead's decision (12 Oct, under Brad's "Don't wait for me. Let's keep pressing throughout to get this next
version published.", about 5:30 PM ET), as its own commit: COMMITTED as `<sha1>` (<time1>)**: board `82a2f1cc`, audit-import
`22cdd78e`, mutate `c3cab761`, built on the base archive `7ee498a` (product `d66dd60`, board `fce8a391`). 💾 Save
(`saveInPlace`, also Take the pen's save), the board file's Save (`saveInPlaceFile`), ⬆ Publish now and the autosave
(`driveStorePush`) and Save yours over theirs / Load theirs (`driveResolve`) check the hold when asked for, before they wait
their turn, and refuse at once in the words of their path; Take the pen checks it before it reads the file or the folder's
copy or asks. The checks at the start of each turn and R4's after the read stay. Reproduced first on the base
(`rec/L6/hold/probe`, scenarios U3-file/-save/-pen/-folder/-publish/-resolve: each B waited its turn, saying "⏳ A save is
already under way — this one runs as soon as it finishes", and once saving was allowed again wrote: on the board file
`perm 2 · read 2 · open 2 · writes 2` and the imported Full Fund plan; controls C3-file and C3-idle pass). Focused block
47 checks: 18 fail on the base board, all pass after; every control passes on both. Six mutations, each caught by the block.
`impmixed-file-unguarded` and `impmixed-folder-unguarded` are now caught by this block's "asked for before the hold" cases
(R4b, and the v1.95 and v1.99 hold blocks, no longer reach the checks they remove; all still pass). mcount 1334/1334 once (text).
**Not covered:** a save already running when the hold comes still lands and says Saved (its bytes carry no mix); the folder's
case is U4. Full audit-import and full-suite sensitivity: in the final-tree queue.

The same, as one line, ready to append at the end of the row's last cell, before its closing `|` (a table cell holds no line
breaks; it starts with a space):

```
 **Built on the lead's decision (12 Oct, under Brad's "Don't wait for me. Let's keep pressing throughout to get this next version published.", about 5:30 PM ET), as its own commit: COMMITTED as `<sha1>` (<time1>)**: board `82a2f1cc`, audit-import `22cdd78e`, mutate `c3cab761`, built on the base archive `7ee498a` (product `d66dd60`, board `fce8a391`). 💾 Save (`saveInPlace`, also Take the pen's save), the board file's Save (`saveInPlaceFile`), ⬆ Publish now and the autosave (`driveStorePush`) and Save yours over theirs / Load theirs (`driveResolve`) check the hold when asked for, before they wait their turn, and refuse at once in the words of their path; Take the pen checks it before it reads the file or the folder's copy or asks. The checks at the start of each turn and R4's after the read stay. Reproduced first on the base (`rec/L6/hold/probe`, scenarios U3-file/-save/-pen/-folder/-publish/-resolve: each B waited its turn, saying "⏳ A save is already under way — this one runs as soon as it finishes", and once saving was allowed again wrote: on the board file `perm 2 · read 2 · open 2 · writes 2` and the imported Full Fund plan; controls C3-file and C3-idle pass). Focused block 47 checks: 18 fail on the base board, all pass after; every control passes on both. Six mutations, each caught by the block. `impmixed-file-unguarded` and `impmixed-folder-unguarded` are now caught by this block's "asked for before the hold" cases (R4b, and the v1.95 and v1.99 hold blocks, no longer reach the checks they remove; all still pass). mcount 1334/1334 once (text). **Not covered:** a save already running when the hold comes still lands and says Saved (its bytes carry no mix); the folder's case is U4. Full audit-import and full-suite sensitivity: in the final-tree queue.
```

## 2. Text to append to the U4 row (the row beginning "| U4 |", its last cell)

 **Built on the lead's decision (12 Oct, under Brad's "Don't wait for me…", about 5:30 PM ET), as its own commit after U3:
COMMITTED as `<sha2>` (<time2>)**: board `4b755576`, audit-import `f25c69f7`, mutate `27f0fdb6`. `_driveStorePushRun` checks
the hold again after its read of the folder's copy and again after its history copy, the last wait before the write; held,
nothing is written over the folder's copy, the history copy already kept stays, a pen line is taken back and the board's
stamp goes back to what it was. Reproduced first on the base (`rec/L6/hold/probe`, U4-read, U4-hist, U4-pen: each wrote the
folder's copy and said "✅ Saved O&M FY27 to the shared folder" with the hold on; Take the pen took the pen from Alice;
controls C4-read and C4-retry pass). Focused block 18 checks: 10 fail on the base board and on the U3 board, all pass after;
every control passes on all three. Five mutations, each caught by the block. mcount 1339/1339 once (text). **Not covered:**
the write itself (bytes built before the import; it lands and says Saved); the board file's own write after R4's check;
Load theirs after its read (not examined). **Overlaps U18** (built separately, same lines): if both are committed, this
check goes after U18's re-read, the last wait before the write, and the two stamp put-backs are one. Full audit-import and
full-suite sensitivity: in the final-tree queue.

The same, as one line, ready to append at the end of the row's last cell, before its closing `|` (a table cell holds no line
breaks; it starts with a space):

```
 **Built on the lead's decision (12 Oct, under Brad's "Don't wait for me…", about 5:30 PM ET), as its own commit after U3: COMMITTED as `<sha2>` (<time2>)**: board `4b755576`, audit-import `f25c69f7`, mutate `27f0fdb6`. `_driveStorePushRun` checks the hold again after its read of the folder's copy and again after its history copy, the last wait before the write; held, nothing is written over the folder's copy, the history copy already kept stays, a pen line is taken back and the board's stamp goes back to what it was. Reproduced first on the base (`rec/L6/hold/probe`, U4-read, U4-hist, U4-pen: each wrote the folder's copy and said "✅ Saved O&M FY27 to the shared folder" with the hold on; Take the pen took the pen from Alice; controls C4-read and C4-retry pass). Focused block 18 checks: 10 fail on the base board and on the U3 board, all pass after; every control passes on all three. Five mutations, each caught by the block. mcount 1339/1339 once (text). **Not covered:** the write itself (bytes built before the import; it lands and says Saved); the board file's own write after R4's check; Load theirs after its read (not examined). **Overlaps U18** (built separately, same lines): if both are committed, this check goes after U18's re-read, the last wait before the write, and the two stamp put-backs are one. Full audit-import and full-suite sensitivity: in the final-tree queue.
```

## 3. "Unresolved after R1–R5" in NEXT-VERSION.md

Exact text, leading spaces included (the fenced lines are the file's lines). Replace the line

```
  - **U3:** a Save queued behind a running save under the hold.
```

with

```
  - **U3: built as its own commit** (the lead's decision under Brad's "keep pressing", 12 Oct): a Save, Take the pen,
    ⬆ Publish now or Save yours over theirs asked for under the mixed-import hold is refused at once, also behind a save
    under way, and allowing saving again does not bring it back (above).
```

and replace the line

```
  - **U4:** the folder save's window for the hold.
```

with

```
  - **U4: built as its own commit after U3** (the same decision): the folder save checks the hold again after its read
    and after its history copy, just before its write (above). Not covered: the write itself, and the board file's own
    write after R4's check.
```

## 4. Optional: one line under R4b's "Tracked, not changed" bullet (NEXT-VERSION.md, under R4b)

Its two sub-bullets describe U3 and U4 as found and not changed; they were true when written and can stay as they are. So
that they do not read as still open, one sub-bullet can be added after the second ("  - Not examined: the folder save
(`_driveStorePushRun`) also checks the hold only before its folder read."); the lead decides, and no check depends on these
words:

```
  - Both are built since, as U3 and U4 (below). After U3, removing the check at the start of the board file's save
    (`impmixed-file-unguarded`) is caught by the U3 block's "asked for before the hold" case, no longer by R4b's
    before-file-access check, which a Save asked for under the hold no longer reaches (U3's entry says why).
```

R4b's own sentence "It catches `impmixed-file-unguarded` on the before-file-access check (`perm 1 · read 1 · open 0`)" stays
true of R4b on the board it was written for (`1c94537`); the added line says what changed after U3.
