# HOLD track (U3, U4) — independent verifier, round 1, lens B (test adequacy and regressions)

Everything here is in `rec/L6/hold/verify-tests-r1` (my own copies). I never edited the builder's files, and nothing in
`/home/user/orbit-board` or `/home/user/orbit-ui`. I committed, staged and pushed nothing. Times are Eastern
(`TZ=America/New_York date`). This README was assembled at 3:41 PM ET, 13 Oct 2026 by `bin/mkreadme.py` from `README.src.md`. The run
records (`logs/runs.txt`) and `pids.txt` are copied in at the end.

No earlier attempt of this review left anything behind: `verify-tests-r1/` did not exist when I started (1:09 PM ET,
13 Oct). Every run below is mine.

## Verdict

**Sound, with issues. Nothing must be fixed before commit.**

- The board change does what U3 and U4 ask.
- Every check the builder reports re-runs with the same checks, verdicts and values:
  - the U3 block, on base, c1 and c2;
  - the U4 block, on base, c1 and c2;
  - all 11 of the builder's new mutants;
  - the probe, all 13 scenarios on base and on c2;
  - every existing audit-import block on the changed paths, base against c2;
  - the other suites and `npm run check`, base against c2.
- Every new expected value is a literal. Every change is a pure insertion, so no existing expectation is edited.

**The issue is test adequacy.** I wrote 15 plausible wrong versions of the change (my own mutants):

- 6 are caught by the builder's U3 and U4 blocks.
- **9 pass every check the builder wrote.** Eight of them were also run against every existing audit-import block that
  sets the hold and calls a save (F-liteall, 123 checks), and pass those too. The ninth, `u3-pen-file-only`, was not run
  there.

Each of the 9 changes something the drafts promise:

- the quiet autosave is refused at once, and quietly;
- Take the pen with the hold on reads nothing and asks nothing (also with no other save running, and in the shared folder);
- an edit typed during a stopped save keeps its own stamp;
- a refused save reports no save;
- the header is drawn again.

One of the 9 (`u3-autosave-queued`) reopens U3 itself on the autosave path. Behind a save under way, the autosave is
queued again: the board says "⏳ … this one runs as soon as it finishes" over the import's message. Once saving is allowed
again, it writes the folder's copy. Another (`u4-hist-says-saved`) makes a refused save report success, so the
autosave would say "✓ Saved to the shared folder automatically" with nothing written.

**Ready to use:** a suite block written in the house style, plus 8 mutation entries:

- `supp/block.mjs.txt`, as a diff in `supp/proposed-audit-import.diff`;
- the entries in `supp/entries.mjs.txt`, as a diff in `supp/proposed-mutate.diff`.

The block has 18 checks:

| Board | Checks that fail |
|---|---|
| base `fce8a391` | 10 |
| c1 `82a2f1cc` | 4 (the U4 cases) |
| c2 `4b755576` | 0 |

It catches all 9 surviving mutants. With the 8 entries, mcount on c2 is 1347 entries, each matching once (text only).

These are should-fixes, not must-fixes: the product code is right on c2, and every draft claim I tested is true there.
They are listed first in "Should fix" because the drafts state these behaviours under "What users may see" with no check
behind them.

## Identities (git hash-object)

| file | base (`7ee498a`) | c1 (U3) | c2 (U3+U4) | builder's claim |
|---|---|---|---|---|
| prioritization-board-grid.html | `fce8a391` | `82a2f1cc` | `4b755576` | same |
| tools/export-audit/audit-import.mjs | `4aba2506` | `22cdd78e` | `f25c69f7` | same |
| tools/export-audit/mutate.mjs.txt | `cbc6defc` | `c3cab761` | `27f0fdb6` | same |
| audit-recon / audit-board / audit-other | `529e36f7` / `a7c575e5` / `d89396b0` | unchanged | unchanged | same |

- **Copies:** `cp/base`, `cp/c1`, `cp/c2` are `cp -a` of `rec/L6/base` and the builder's `c1/` and `c2/`. The
  `node_modules` link was kept and `chmod -R u+w` applied. `diff -rq` shows only the board, audit-import and
  `mutate.mjs.txt` differ, base→c1 and c1→c2.
- **Re-derived diffs** (`diffs/`) are pure insertions:

  | | board | audit-import | mutate |
  |---|---|---|---|
  | base→c1 | +8 / −0 | +133 / −0 | +19 / −0 |
  | c1→c2 | +13 / −0 | +95 / −0 | +16 / −0 |

- **orbit-board HEAD** is `3841339`. `git diff --name-only 7ee498a HEAD` outside `recovery/` is empty, so the base stands.

## What I checked, and what I found

### 1. The builder's reported runs, re-run (all the same)

**The focused U3 and U4 blocks.** I rebuilt the harnesses from my c2 suite with the builder's `mkfocused-multi.py`, read
first. All 12 harnesses are byte-identical to the builder's `harness/` after the first, path-naming line. Then I ran them
against each copy's own `boot.mjs`, with `BOARD` unset and asserted:

| run | board | checks | fail | vs the builder's `r1-*` |
|---|---|---|---|---|
| v1-F-u3-base | fce8a391 | 47 | 18 | same checks, verdicts, values |
| v1-F-u3-c1 | 82a2f1cc | 47 | 0 | same |
| v1-F-u3-c2 | 4b755576 | 47 | 0 | same |
| v1-F-u4-base | fce8a391 | 18 | 10 | same |
| v1-F-u4-c1 | 82a2f1cc | 18 | 10 | same |
| v1-F-u4-c2 | 4b755576 | 18 | 0 | same |

**The builder's 11 new mutants.** I made them from my c2 copy's `mutate.mjs.txt` with `rec/bin/mkmut.py`. That is text
only; each find matched once. All 41 mutant boards are byte-identical to the builder's `mut/`. Each was caught, with the
same checks and values as the builder's `m2-*` (U3) and `m3-*` (U4):

| mutant | U3 checks failing | | mutant | U4 checks failing |
|---|---|---|---|---|
| v200-u3-save-queued | 6 | | v200-u4-read-unchecked | 1 (only "nothing is kept in the history either") |
| v200-u3-save-file-words | 1 | | v200-u4-hist-unchecked | 6 |
| v200-u3-file-queued | 3 | | v200-u4-stamp-moved | 2 |
| v200-u3-publish-queued | 3 | | v200-u4-pen-line-kept | 1 |
| v200-u3-resolve-queued | 3 | | v200-u4-hist-says-nothing | 2 |
| v200-u3-pen-reads-first | 3 | | | |

**The probe.** `probe/hold-probe.mjs` was rebuilt with the builder's `mkprobe.py` and is byte-identical (`fb8c557d`). I ran
all 13 scenarios on base and on c2. `bin/cmpprobe.py` masks clock times; with that, every observation equals the
builder's `out/probe-*.json`. So the U3 and U4 reproductions on the base stand as reported.

**mcount** (`rec/bin/mcount.py`, text only):

| copy | entries | each matching once |
|---|---|---|
| base | 1328 | 1328 |
| c1 | 1334 | 1334 |
| c2 | 1339 | 1339 |

None is missing, matched more than once, or unparsed. `mutate.mjs` was never imported, executed or run.

**Existing checks on the changed paths**, base against c2, against the builder's `g*` runs as well:

| harness | checks | base = c2 | = builder's |
|---|---|---|---|
| F-folderA | 297 | yes | g2 (c2), g6 (base) |
| F-folderB (run in two halves, B1+B2, after the whole one hit 600 s under load) | 142 | yes | g1 (c2), g5 (base) |
| F-liteall c2 / F-litepre base | 123 / 58 | — | f4, both same |
| F-hold | 139 | yes | g3 (c2), g7 (base) |
| F-u2 | 57 | yes | g3 (c2), g7 (base) |
| F-u13 | 71 | yes | g3 (c2), g7 (base) |
| F-nr02 | 3 | yes | g2 (c2), g6 (base) |

Total on these harnesses: 297 + 142 + 139 + 57 + 71 + 3 = 709 checks, as the builder reported; every one has the same verdict and value on base and c2.

**The 12 existing hold mutations.** I made these from my copies' `mutate.mjs.txt` with `mkmut.py`, text only. They ran
on c2 against F-liteall (123 checks). The two whose catching moved also ran on the base against F-litepre (58 checks).
`saves-not-serial` also ran against F-folderA on both boards. Each run equals the builder's `x*` run, check for check,
with the same values:

| mutant (c2, F-liteall) | failing | caught by | = builder |
|---|---|---|---|
| impmixed-file-unguarded | 1 | U3 "asked for before the hold" (board file): `perm 2 · read 2 · open 1 · writes 1`; R4b passes | x1 |
| impmixed-folder-unguarded | 1 | U3 "asked for before the hold" (folder): `[2,1,true]`; v1.95 and v1.99 pass | x2 |
| impmixed-not-marked | 57 | v1.95 hold, R4, R4b, U3, U4 | x3 |
| impmixed-not-kept | 7 | v1.95 hold, v1.95 lifting | x4 |
| impmixed-clear-unasked | 2 | v1.95 hold | x4 |
| impmixed-boot-silent | 1 | v1.95 hold | x5 |
| impmixed-never-lifted | 2 | v1.95 "an import that lands whole lifts the hold" | x5 |
| impmixed-lift-partial | 1 | v1.95 lifting (the same block) | x6 |
| v200-r4-no-recheck | 3 | R4 | x6 |
| v200-r4-held-quietly | 1 | R4 | x7 |
| v200-r4-said-not-held | 3 | R4 | x7 |
| saves-not-serial | 5 | U3 (no-hold control, and both before-the-hold cases) | x8 |

The two whose catching moved, on the base:

- `x-base-impmixed-file-unguarded` (F-litepre): 5 R4b checks fail (= x8-base).
- `x-base-impmixed-folder-unguarded`: the v1.95 and v1.99 folder checks fail, 1 each (= x9).

So the builder's account of where the two moved mutations are caught is exact.

`saves-not-serial` against F-folderA (297 checks, the v1.95 "Save acknowledges exactly what it wrote" blocks among them): `x-c2-saves-not-serial-folderA`: 297 checks, 5 fail; same checks, verdicts and values as the builder's `x10-c2-saves-not-serial`: True; `x-base-saves-not-serial-folderA`: 297 checks, 5 fail; same checks, verdicts and values as the builder's `x11-base-saves-not-serial`: True.

**Other suites and `npm run check`.** These ran in scratch clones:

- `clones/base` and `clones/c2`: `git clone --shared --no-checkout /home/user/orbit-board`, then `git checkout --detach 7ee498a`.
- c2's board and audit-import were copied over the c2 clone. `node_modules` was linked. Nothing was committed.

| suite | base (clones/base) | c2 (clones/c2) | output, timings and the board's line count masked |
|---|---|---|---|
| boot-same | exit 0 | exit 0 | identical |
| audit | exit 0, ALL CHECKS PASSED | exit 0, ALL CHECKS PASSED | identical |
| audit-ppt | exit 0, ALL CHECKS PASSED | exit 0, ALL CHECKS PASSED | identical |
| audit-other | exit 0, ALL CHECKS PASSED | exit 0, ALL CHECKS PASSED | identical |
| legacy-fsrc | exit 0 | exit 0 | identical |
| audit-inject | exit 0, ALL CHECKS PASSED | exit 0, ALL CHECKS PASSED | identical |
| npm-check | exit 0, all checks passed | exit 0, all checks passed | identical but for the board's size and line count (+21 lines) |
| audit-recon | exit 0, ALL CHECKS PASSED | exit 0, ALL CHECKS PASSED | identical |
| audit-hostile | exit 0, ALL CHECKS PASSED | exit 0, ALL CHECKS PASSED | identical |

### 2. Literals, and whether each new check fails on the base

- **Literals.** Every expected value in both blocks is a literal: strings, numbers, booleans and arrays of them, including
  `J(at === 'read' ? [] : [true])`. Board helpers only observe: `touched()`, `status()`, `fold.note()`, `fold.raw(fy) === v1`,
  `stamp(T.ev) === s0`.
- **U3**, 47 checks: 18 fail on base. 27 of those that pass are labelled controls. **Two unlabelled checks pass on the
  base by design.** They are the "asked for before the hold, waiting its turn" cases ("refused when its turn comes,
  before the file is touched / before the folder's copy is read"). They guard behaviour that already existed. They are
  the checks that now catch `impmixed-file-unguarded` and `impmixed-folder-unguarded`.
- **U4**, 18 checks: 10 fail on base. 7 of those that pass are labelled controls. **One unlabelled check passes on the
  base:** "the history keeps the folder's copy as it was read, once" (hist case). The base also keeps that copy.
- None of these is wrong. Labelling the three "(kept behaviour)" would make "every new check fails on the base" literally
  true (minor).

### 3. Changed existing expectations

- **None.** Every hunk in the board, audit-import and mutate is an insertion. The existing checks on these paths give the
  same checks, verdicts and values on base and c2 (above).
- **One documented sensitivity changes.** NEXT-VERSION.md (base line 622, R4b): "It catches `impmixed-file-unguarded` on the
  before-file-access check (`perm 1 · read 1 · open 0`)". After U3 it does not, because a Save asked for under the hold
  never reaches that check. The builder says so in its README and in its U3 draft. It offers the R4b line only as
  "optional", but the sentence becomes untrue of the shipped suite (see Minor).

### 4. My own mutants (15), each a plausible wrong fix

Made by `bin/mkown.py` (text only; each find matches the c2 board once) from c2. Each was run against the builder's
focused block (F-u3 or F-u4). Each survivor was then run against F-liteall: the v1.95 hold, the lifting of the hold, the
v1.99 batch hold, R4, R4b, U3 and U4 — 123 checks, every audit-import block that sets the hold and calls a save, except
"⬆ Publish now … with its checks", whose hold case goes through the non-quiet path that none of these change. It was
also run against my proposed block (F-supp3, or F-supp4 for the Take the pen ones).

| own mutant | the plausible wrong fix | builder's block | F-liteall (123) | my block |
|---|---|---|---|---|
| u3-pen-after-read | Take the pen's check put after its read of the file | caught (2) | — | — |
| u3-file-says-but-queues | `impMixedBlock(...)` without `if … return`: says refused, still queues | caught (3) | — | — |
| u3-publish-silent | ⬆ Publish now refused quietly (`quiet` forced true) | caught (1) | — | — |
| u3-save-silent | 💾 Save refused with no words (`impMixedOn()`) | caught (2) | — | — |
| u4-stamp-ts-only | puts back the time but not who | caught (1) | — | — |
| u4-check-before-history | second check put before the history copy, not after | caught (6) | — | — |
| **u3-autosave-queued** | `if(!quiet && impMixedBlock(…))`: only Publish refused at once; the autosave queues again | **survives** | survives | caught (2) |
| **u3-autosave-loud** | the U3 check in `driveStorePush` drops `quiet` | **survives** | survives | caught (1) |
| **u3-pen-busy-only** | Take the pen refused at once only while another save runs | **survives** | survives | caught (4) |
| **u3-pen-file-only** | Take the pen refused at once only on the board file, not in the folder | **survives** | — (not run) | caught (2) |
| **u4-read-loud** | the U4 check after the read drops `quiet` | **survives** | survives | caught (1) |
| **u4-hist-loud** | the U4 refusal after the history copy drops `quiet` | **survives** | survives | caught (1) |
| **u4-hist-returns-true** | the refusal after the history copy returns `true` | **survives** | survives | caught (1) |
| **u4-stamp-unguarded** | stamp put back without `if(MS.ts===wroteTs)`: an edit typed meanwhile loses its stamp | **survives** | survives | caught (1) |
| **u4-no-render** | refusal after the history copy without `render()`: the header still shows the refused save's time | **survives** | survives | caught (1) |

What each survivor would do to a person:

- **u3-autosave-queued.** The base behaviour comes back for the autosave. Base run of my block, case (a):
  - the status shows "⏳ A save is already under way — this one runs as soon as it finishes" while the hold stands;
  - once saving is allowed, the queued autosave writes: `[3,1]`, a third write of the folder's copy and one more history
    copy, against `[2,0]` on c2.
- **u4-hist-returns-true.** `liveTick()` would say "✓ Saved to the shared folder automatically" (`done && _statN===said`)
  when nothing was written.
- **The three "loud" mutants.** Each puts "⛔ Writing to the shared folder is refused…" over the import's own message,
  the one that says which lists are where. The design keeps the autosave quiet.
- **u4-stamp-unguarded.** It turns the stamp of an edit typed during the stopped save back to before the save.
- **u4-no-render.** It leaves the header's tooltip saying the board was saved at the refused save's time.
- **u3-pen-busy-only and u3-pen-file-only.** Take the pen with the hold on reads the file or the folder's copy, then
  asks "OK — take the pen and save now", and only then refuses.

All of this is untrue on c2 (my block passes there) and untested in the builder's blocks.

## Findings

### Must fix

None.

### Should fix

**S1 — the U3 and U4 tests do not reach five behaviours the drafts promise; 9 plausible wrong fixes pass every check.**
Evidence: section 4 and the runs below.

| draft claim | where | tested? |
|---|---|---|
| "The quiet autosave is refused quietly, as before, now without waiting its turn" | U3 entry, "What users may see" | no |
| "a quiet autosave says nothing, as at its start" | U4 entry | no |
| "Take the pen no longer reads the board file or the folder's copy, or asks … while the hold is on" | U3 | only on the board file with a save under way |
| "the board's stamp … goes back to what it was unless something was typed meanwhile" | U4 | no |
| the header's saved time is not moved by a save that did not happen | the builder's README, principle 4 | through `MS.ts` only, not what is drawn |

Minimal fix: add the block in `supp/proposed-audit-import.diff` (insert after `// ==== end v2.00 (U4) ====`). The lead may
give it the U3 and U4 commits' own names and split it between them: cases (a), (b) and (g) belong to U3; (c) to (f) to
U4. Its seven cases:

- **(a)** the autosave behind a save under way, under the hold: over at once, not queued, the message line unchanged; and
  after "allow saving again", A alone wrote the folder's copy (`[2,0]`);
- **(b)** Take the pen on the board file, with the hold on and nothing running: `perm 0 · read 0 · open 0 · writes 0`, 0
  asked, "Taking the pen is refused";
- **(g)** the same, working out of the shared folder, taking the pen from Alice: the folder's copy is not read or written,
  0 asked;
- **(c)** an edit typed while the save's history copy is held: the edit keeps its stamp;
- **(d)** and **(e)** the autosave held at the read, and at the history copy: nothing written, returns `false`, the message
  line unchanged;
- **(f)** the header's saved time after the stop: what it was before. The stamp is first set to 5 Jan 2026, so a save made
  now cannot read the same minute.

How it runs:

| | checks | fail |
|---|---|---|
| base | 18 | 10 |
| c1 | 18 | 4 ((c)–(f), U4 not there yet) |
| c2 | 18 | 0 |
| each of the 9 survivors | 18 | 1–4 |

Add the 8 mutation entries in `supp/proposed-mutate.diff`, inserted before the line `  // v2.00 (R3, Brad 11 Oct): a save
that lands under a locked view says it saved the working plan.`:

- `v200-u3-autosave-queued`, `v200-u3-autosave-loud`, `v200-u3-pen-idle-reads`;
- `v200-u4-read-loud`, `v200-u4-hist-loud`, `v200-u4-hist-says-saved`, `v200-u4-stamp-over-edit`, `v200-u4-header-stale`.

`mkmut.py` builds each of them byte-identical to the own mutant run above. The table below shows what each is caught by.
With them, mcount on c2 is 1347 entries, each once. (`u3-pen-file-only` has no entry of its own; case (g) catches it.)

If the lead prefers the drafts unchanged without the block, then the claims in the table above should be marked "not
tested" in the drafts' "Test" lines.

**S2 — `v200-u4-read-unchecked` is caught by one check only.** That check is "nothing is kept in the history either". If
the U4 check after the read is removed, the save is still refused by the second check, so only the extra history copy
shows. Nothing else distinguishes the two checks: the stamp, the words and the bytes all match.

This is acceptable as it stands. One more observable would make the read check's purpose plain: the folder's copy is not
read twice, or no "(writer)" line appears in between. My block's (d) does not add this either, because the autosave
case is refused by the same pair. Noted, not required.

### Minor

- **The R4b sentence becomes untrue.** NEXT-VERSION.md, R4b entry (base line 622): "It catches `impmixed-file-unguarded` on
  the before-file-access check (`perm 1 · read 1 · open 0`)". After U3 this is untrue of the shipped suite. Measured: on c2,
  R4b passes with that mutant. The builder's optional added line (drafts/LEDGER-and-UNRESOLVED.md §4) should be added,
  not left optional (principle 4).
- **Unlabelled checks pass on the base by design** (section 2). They are the U3 block's two "asked for before the hold"
  checks and U4's "the history keeps the folder's copy as it was read, once". A "(kept behaviour)" label would keep
  "fails on the base" literal.
- **The U3 block's header comment** says a Save asked for before the hold "is refused when its turn comes". That is
  true only while the hold still stands at its turn. Its checks keep the hold on, and are right. The money-lens verifier
  measured the lifted case (its M1). Adding "while the hold still stands" to the comment is enough.
- **The U3 draft is loose about which blocks catch the older mutations.** It says "the other ten existing hold mutations
  are caught too, nine of them by the v1.95 hold and R4 blocks". Measured: two of the nine (`impmixed-never-lifted`,
  `impmixed-lift-partial`) are caught only by the v1.95 lifting block ("an import that lands whole lifts the hold a
  stopped one set"). Name it.
- **The U3 draft says Load theirs** (`driveResolve('theirs')`) "is refused at once in the same words". No check asks for
  Load theirs under the hold. It is the same line as Save yours over theirs, so the risk is low.

## Decisions, with reasons

- I classified the test gaps as should-fix, not must-fix. A must-fix needs a defect. The c2 board does what every tested
  claim says, and my 18 checks pass there. The gaps are claims with no check behind them, plus 9 wrong versions that
  would pass review. I proposed the block and entries rather than only describing them.
- **F-folderB in two halves.** The whole F-folderB harness hit the 600 s cap once on c2 (cut off, no exit record). On the
  base, the machine's memory-cgroup OOM killer killed it at 566 s (dmesg: "Killed process 9284 (node)"). I re-ran it as
  two harnesses built the same way from the same blocks (B1: the five v1.97/v1.99 blocks; B2: R3, R3 message, R4, R4b,
  R5). In suite order, B1+B2 hold the same 142 checks as the builder's whole F-folderB, and they compare equal.
- **One lane per run after 1:51 PM ET.** My first lanes ran two or more runs in one `setsid -w timeout -k 10 600` wrapper.
  Lane L15 hit its own 600 s cap during `ol-u4-read-loud`, whose node then finished alone without an end record. From then
  on each run had its own wrapper, and the queue runner (`bin/q.sh`, itself under `setsid -w timeout -k 10 600`, ≤540 s)
  started at most two.
- **The (f) header case was rewritten once.** In F-supp2 it compared the tooltip at minute resolution and passed on the
  base. In F-supp3 the stamp is first set to 5 Jan 2026. Only F-supp3/F-supp4 results are counted for (f).

## Lead's principles, for my proposal

| principle | how the proposal meets it |
|---|---|
| (1) never lose a copy | test only; it reads |
| (2) refuse or ask | its checks are refusals |
| (3) money and exports | untouched |
| (4) words stay true | it is what the block adds: quiet stays quiet, "Saved" never said, the header not stale |
| (5) smallest change | one block, 8 entries, no board change |
| (6) existing checks preserved | pure insertion; no existing check, fixture or expected value is touched |

## What I did not do

- I did not run the full `audit-import.mjs` or `audit-board.mjs` (the lead runs those alone).
- I did not import, execute or run `mutate.mjs`. I read it as text only (`mkmut.py`, `mcount.py`, `mcread.py`).
- I did not run Chromium or playwright, and never ran `playwright install`.
- I did not re-run on c1:
  - the regression harnesses (the builder's g8–g10);
  - the probe on c1;
  - the builder's `m1-*` (U3 mutants made from c1). Their c2 twins (`m2-*`) were re-run, and the U3 lines are the same.
- I did not re-run:
  - the builder's `f3-F-holdpre-*` and `g4-F-holdall-c2`. F-liteall/F-litepre hold the same hold blocks without the
    file-save two-saves case; F-folderA holds that case.
- I did not test the U18 merge. I did not examine the behaviour the money-lens verifier reported (S1–S3 there).
- The 27 "other" existing entries on these paths (the builder's exsweep) were not run, as with the builder.
- I edited, staged, committed and pushed nothing in orbit-board or orbit-ui. I killed no process; two of my runs were
  stopped by caps or the OOM killer, as recorded.

## Files

- **Copies:** `cp/base`, `cp/c1`, `cp/c2`, and their diffs in `diffs/`.
- **Harnesses:** `harness/` (F-*), installed in `h/<copy>/tools/export-audit` beside a link to that copy's `boot.mjs`.
- **Mutant boards:** `mut/`.
  - the builder's: `c1-*`, `c2-*`, `base-*`;
  - mine: `own-*`;
  - from my proposed entries: `x-*`.
- **My proposal:** `supp/`.
  - `block.mjs.txt`;
  - `suite/audit-import.mjs`, the c2 suite with the block;
  - `entries.mjs.txt`;
  - `mutate-c2x.mjs.txt`, c2's list with the entries;
  - `proposed-*.diff`.
- **Probe:** `probe/`, rebuilt.
- **Records:** `out/`, the per-check records (`*.checks.jsonl`), probe outputs, summaries and mcount.
- **Logs:** `logs/`, every run's log with `# start`/`# end … exit … wall_s`, and `runs.txt`.
- **Scripts:** `bin/`, every script.
- **Scratch clones:** `clones/`.

Blobs (git hash-object): `supp/block.mjs.txt` c698340b; `supp/suite/audit-import.mjs` a3014d5b; `supp/entries.mjs.txt` 0e506f4e; `supp/mutate-c2x.mjs.txt` 8f681737; `supp/proposed-audit-import.diff` a321377f; `supp/proposed-mutate.diff` 6e99c929; `harness/F-supp4.mjs` 702ac0e7; `harness/F-supp3.mjs` 31996e45; `harness/F-u3.mjs` 13f03406; `harness/F-u4.mjs` 74fbd625; `harness/F-liteall.mjs` 52804a86; `probe/hold-probe.mjs` fb8c557d; `bin/mkown.py` cddf994f; `bin/runner.mjs` e835140a; `bin/mkfocused-multi.py` 9a31d9d9.

## Every run

Labels:

| label | what it is |
|---|---|
| `v1-*` | the focused U3/U4 blocks |
| `bm-*` | the builder's mutants |
| `om-*` | my mutants against the builder's blocks |
| `os*` | my mutants against my block (`os`=F-supp v1, `os2`=supp2, `os4`=supp3, `os5`=supp4) |
| `ol*` | my mutants against F-liteall |
| `v2-`/`v3-`/`v4-` | my block on base/c1/c2 |
| `probe-*` | the probe |
| `f-*` | unmutated hold harnesses |
| `g-*` | regressions |
| `x-*` | existing hold mutants |
| `S-S1`/`S-S3`/`S-S5` | base suites |
| `S-S2`/`S-S4`/`S-S6` | c2 suites |

Each line is: label, start ET, exit, wall seconds, log.

```
v1-F-u4-base start_et="2026-10-13 13:12:25 EDT" exit=1 wall_s=43.9 log=logs/v1-F-u4-base.log 
v1-F-u3-base start_et="2026-10-13 13:12:25 EDT" exit=1 wall_s=50.8 log=logs/v1-F-u3-base.log 
v1-F-u4-c1 start_et="2026-10-13 13:13:09 EDT" exit=1 wall_s=42.1 log=logs/v1-F-u4-c1.log 
v1-F-u3-c1 start_et="2026-10-13 13:13:16 EDT" exit=0 wall_s=48.9 log=logs/v1-F-u3-c1.log 
v1-F-u4-c2 start_et="2026-10-13 13:13:51 EDT" exit=0 wall_s=38.3 log=logs/v1-F-u4-c2.log 
v1-F-u3-c2 start_et="2026-10-13 13:14:05 EDT" exit=0 wall_s=46.7 log=logs/v1-F-u3-c2.log 
bm-c2-u4-read-unchecked start_et="2026-10-13 13:18:00 EDT" exit=1 wall_s=36.9 log=logs/bm-c2-u4-read-unchecked.log 
bm-c2-u3-save-queued start_et="2026-10-13 13:18:00 EDT" exit=1 wall_s=44.3 log=logs/bm-c2-u3-save-queued.log 
bm-c2-u4-hist-unchecked start_et="2026-10-13 13:18:37 EDT" exit=1 wall_s=30.6 log=logs/bm-c2-u4-hist-unchecked.log 
bm-c2-u3-save-file-words start_et="2026-10-13 13:18:44 EDT" exit=1 wall_s=34.4 log=logs/bm-c2-u3-save-file-words.log 
bm-c2-u4-stamp-moved start_et="2026-10-13 13:19:08 EDT" exit=1 wall_s=28.8 log=logs/bm-c2-u4-stamp-moved.log 
bm-c2-u3-file-queued start_et="2026-10-13 13:19:19 EDT" exit=1 wall_s=33.6 log=logs/bm-c2-u3-file-queued.log 
bm-c2-u4-pen-line-kept start_et="2026-10-13 13:19:36 EDT" exit=1 wall_s=30.5 log=logs/bm-c2-u4-pen-line-kept.log 
bm-c2-u3-publish-queued start_et="2026-10-13 13:19:52 EDT" exit=1 wall_s=34.1 log=logs/bm-c2-u3-publish-queued.log 
bm-c2-u4-hist-says-nothing start_et="2026-10-13 13:20:07 EDT" exit=1 wall_s=22.9 log=logs/bm-c2-u4-hist-says-nothing.log 
bm-c2-u3-resolve-queued start_et="2026-10-13 13:20:27 EDT" exit=1 wall_s=25.6 log=logs/bm-c2-u3-resolve-queued.log 
bm-c2-u3-pen-reads-first start_et="2026-10-13 13:20:52 EDT" exit=1 wall_s=33.4 log=logs/bm-c2-u3-pen-reads-first.log 
v1-F-supp-base start_et="2026-10-13 13:21:05 EDT" exit=1 wall_s=26.8 log=logs/v1-F-supp-base.log 
v1-F-supp-c2 start_et="2026-10-13 13:21:32 EDT" exit=0 wall_s=26.1 log=logs/v1-F-supp-c2.log 
om-u3-autosave-loud start_et="2026-10-13 13:21:41 EDT" exit=0 wall_s=34.3 log=logs/om-u3-autosave-loud.log 
v1-F-supp-c1 start_et="2026-10-13 13:21:58 EDT" exit=1 wall_s=22.5 log=logs/v1-F-supp-c1.log 
om-u3-pen-busy-only start_et="2026-10-13 13:22:16 EDT" exit=0 wall_s=27.5 log=logs/om-u3-pen-busy-only.log 
om-u4-stamp-unguarded start_et="2026-10-13 13:22:31 EDT" exit=0 wall_s=27.5 log=logs/om-u4-stamp-unguarded.log 
om-u3-pen-after-read start_et="2026-10-13 13:22:43 EDT" exit=1 wall_s=38.4 log=logs/om-u3-pen-after-read.log 
om-u4-stamp-ts-only start_et="2026-10-13 13:22:58 EDT" exit=1 wall_s=32.1 log=logs/om-u4-stamp-ts-only.log 
om-u3-file-says-but-queues start_et="2026-10-13 13:23:22 EDT" exit=1 wall_s=42.2 log=logs/om-u3-file-says-but-queues.log 
om-u4-hist-loud start_et="2026-10-13 13:23:31 EDT" exit=0 wall_s=34.0 log=logs/om-u4-hist-loud.log 
om-u4-read-loud start_et="2026-10-13 13:24:05 EDT" exit=0 wall_s=28.6 log=logs/om-u4-read-loud.log 
om-u3-publish-silent start_et="2026-10-13 13:24:04 EDT" exit=1 wall_s=37.9 log=logs/om-u3-publish-silent.log 
om-u4-check-before-history start_et="2026-10-13 13:24:33 EDT" exit=1 wall_s=30.0 log=logs/om-u4-check-before-history.log 
om-u3-save-silent start_et="2026-10-13 13:24:42 EDT" exit=1 wall_s=31.2 log=logs/om-u3-save-silent.log 
om-u4-hist-returns-true start_et="2026-10-13 13:25:03 EDT" exit=0 wall_s=25.0 log=logs/om-u4-hist-returns-true.log 
os-u3-autosave-loud start_et="2026-10-13 13:25:28 EDT" exit=1 wall_s=22.6 log=logs/os-u3-autosave-loud.log 
os-u3-pen-busy-only start_et="2026-10-13 13:25:51 EDT" exit=1 wall_s=20.0 log=logs/os-u3-pen-busy-only.log 
os-u4-stamp-unguarded start_et="2026-10-13 13:26:11 EDT" exit=1 wall_s=21.1 log=logs/os-u4-stamp-unguarded.log 
os-u4-hist-loud start_et="2026-10-13 13:26:32 EDT" exit=1 wall_s=16.5 log=logs/os-u4-hist-loud.log 
os-u4-read-loud start_et="2026-10-13 13:26:48 EDT" exit=1 wall_s=18.6 log=logs/os-u4-read-loud.log 
v2-F-supp2-c2 start_et="2026-10-13 13:26:55 EDT" exit=0 wall_s=18.4 log=logs/v2-F-supp2-c2.log 
os-u4-hist-returns-true start_et="2026-10-13 13:27:07 EDT" exit=1 wall_s=19.7 log=logs/os-u4-hist-returns-true.log 
v2-F-supp2-base start_et="2026-10-13 13:27:14 EDT" exit=1 wall_s=18.8 log=logs/v2-F-supp2-base.log 
probe-base-U3-file start_et="2026-10-13 13:27:35 EDT" exit=0 wall_s=12.6 log=logs/probe-base-U3-file.log 
om-u3-autosave-queued start_et="2026-10-13 13:27:33 EDT" exit=0 wall_s=25.6 log=logs/om-u3-autosave-queued.log 
probe-base-C3-file start_et="2026-10-13 13:27:48 EDT" exit=0 wall_s=15.0 log=logs/probe-base-C3-file.log 
probe-base-C3-idle start_et="2026-10-13 13:28:03 EDT" exit=0 wall_s=17.3 log=logs/probe-base-C3-idle.log 
om-u4-no-render start_et="2026-10-13 13:27:58 EDT" exit=0 wall_s=29.5 log=logs/om-u4-no-render.log 
probe-base-U3-save start_et="2026-10-13 13:28:20 EDT" exit=0 wall_s=13.4 log=logs/probe-base-U3-save.log 
probe-base-U3-pen start_et="2026-10-13 13:28:34 EDT" exit=0 wall_s=11.9 log=logs/probe-base-U3-pen.log 
os2-u3-autosave-queued start_et="2026-10-13 13:28:28 EDT" exit=1 wall_s=21.7 log=logs/os2-u3-autosave-queued.log 
probe-base-U3-folder start_et="2026-10-13 13:28:46 EDT" exit=0 wall_s=13.7 log=logs/probe-base-U3-folder.log 
os2-u4-no-render start_et="2026-10-13 13:28:50 EDT" exit=1 wall_s=21.5 log=logs/os2-u4-no-render.log 
probe-base-U3-publish start_et="2026-10-13 13:28:59 EDT" exit=0 wall_s=12.0 log=logs/probe-base-U3-publish.log 
probe-base-U3-resolve start_et="2026-10-13 13:29:12 EDT" exit=0 wall_s=8.8 log=logs/probe-base-U3-resolve.log 
probe-base-U4-read start_et="2026-10-13 13:29:20 EDT" exit=0 wall_s=11.8 log=logs/probe-base-U4-read.log 
probe-base-U4-hist start_et="2026-10-13 13:29:32 EDT" exit=0 wall_s=15.3 log=logs/probe-base-U4-hist.log 
v3-F-supp3-c2 start_et="2026-10-13 13:29:29 EDT" exit=0 wall_s=23.6 log=logs/v3-F-supp3-c2.log 
probe-base-U4-pen start_et="2026-10-13 13:29:48 EDT" exit=0 wall_s=14.6 log=logs/probe-base-U4-pen.log 
probe-base-C4-read start_et="2026-10-13 13:30:02 EDT" exit=0 wall_s=16.1 log=logs/probe-base-C4-read.log 
v3-F-supp3-base start_et="2026-10-13 13:29:53 EDT" exit=1 wall_s=27.8 log=logs/v3-F-supp3-base.log 
probe-base-C4-retry start_et="2026-10-13 13:30:18 EDT" exit=0 wall_s=15.0 log=logs/probe-base-C4-retry.log 
os3-u4-no-render start_et="2026-10-13 13:30:21 EDT" exit=1 wall_s=21.2 log=logs/os3-u4-no-render.log 
probe-c2-U3-file start_et="2026-10-13 13:30:45 EDT" exit=0 wall_s=13.1 log=logs/probe-c2-U3-file.log 
v3-F-supp3-c1 start_et="2026-10-13 13:30:42 EDT" exit=1 wall_s=23.1 log=logs/v3-F-supp3-c1.log 
probe-c2-C3-file start_et="2026-10-13 13:30:58 EDT" exit=0 wall_s=9.9 log=logs/probe-c2-C3-file.log 
probe-c2-C3-idle start_et="2026-10-13 13:31:08 EDT" exit=0 wall_s=8.5 log=logs/probe-c2-C3-idle.log 
probe-c2-U3-save start_et="2026-10-13 13:31:16 EDT" exit=0 wall_s=9.0 log=logs/probe-c2-U3-save.log 
probe-c2-U3-pen start_et="2026-10-13 13:31:25 EDT" exit=0 wall_s=15.6 log=logs/probe-c2-U3-pen.log 
probe-c2-U3-folder start_et="2026-10-13 13:31:41 EDT" exit=0 wall_s=10.2 log=logs/probe-c2-U3-folder.log 
probe-c2-U3-publish start_et="2026-10-13 13:31:51 EDT" exit=0 wall_s=14.0 log=logs/probe-c2-U3-publish.log 
probe-c2-U3-resolve start_et="2026-10-13 13:32:05 EDT" exit=0 wall_s=15.0 log=logs/probe-c2-U3-resolve.log 
os4-u3-autosave-loud start_et="2026-10-13 13:31:53 EDT" exit=1 wall_s=28.6 log=logs/os4-u3-autosave-loud.log 
probe-c2-U4-read start_et="2026-10-13 13:32:20 EDT" exit=0 wall_s=21.2 log=logs/probe-c2-U4-read.log 
os4-u3-pen-busy-only start_et="2026-10-13 13:32:22 EDT" exit=1 wall_s=35.9 log=logs/os4-u3-pen-busy-only.log 
probe-c2-U4-hist start_et="2026-10-13 13:32:41 EDT" exit=0 wall_s=21.3 log=logs/probe-c2-U4-hist.log 
probe-c2-U4-pen start_et="2026-10-13 13:33:03 EDT" exit=0 wall_s=19.2 log=logs/probe-c2-U4-pen.log 
os4-u3-autosave-queued start_et="2026-10-13 13:32:58 EDT" exit=1 wall_s=31.8 log=logs/os4-u3-autosave-queued.log 
probe-c2-C4-read start_et="2026-10-13 13:33:22 EDT" exit=0 wall_s=17.8 log=logs/probe-c2-C4-read.log 
probe-c2-C4-retry start_et="2026-10-13 13:33:40 EDT" exit=0 wall_s=21.8 log=logs/probe-c2-C4-retry.log 
os4-u4-stamp-unguarded start_et="2026-10-13 13:33:30 EDT" exit=1 wall_s=35.5 log=logs/os4-u4-stamp-unguarded.log 
os4-u4-hist-loud start_et="2026-10-13 13:34:06 EDT" exit=1 wall_s=34.9 log=logs/os4-u4-hist-loud.log 
os4-u4-read-loud start_et="2026-10-13 13:34:41 EDT" exit=1 wall_s=31.5 log=logs/os4-u4-read-loud.log 
os4-u4-hist-returns-true start_et="2026-10-13 13:35:12 EDT" exit=1 wall_s=28.7 log=logs/os4-u4-hist-returns-true.log 
os4-u4-no-render start_et="2026-10-13 13:35:41 EDT" exit=1 wall_s=35.4 log=logs/os4-u4-no-render.log 
ol-u3-autosave-loud start_et="2026-10-13 13:34:13 EDT" exit=0 wall_s=201.2 log=logs/ol-u3-autosave-loud.log 
ol-u3-autosave-queued start_et="2026-10-13 13:36:18 EDT" exit=0 wall_s=208.2 log=logs/ol-u3-autosave-queued.log 
ol-u3-pen-busy-only start_et="2026-10-13 13:37:34 EDT" exit=0 wall_s=238.8 log=logs/ol-u3-pen-busy-only.log 
ol-u4-stamp-unguarded start_et="2026-10-13 13:39:47 EDT" exit=0 wall_s=239.1 log=logs/ol-u4-stamp-unguarded.log 
S-S1-boot-same start_et="2026-10-13 13:43:47 EDT" exit=0 wall_s=51.1 log=logs/S-S1-boot-same.log 
S-S1-audit start_et="2026-10-13 13:44:39 EDT" exit=0 wall_s=56.2 log=logs/S-S1-audit.log 
S-S1-audit-ppt start_et="2026-10-13 13:45:35 EDT" exit=0 wall_s=26.4 log=logs/S-S1-audit-ppt.log 
ol-u4-hist-loud start_et="2026-10-13 13:41:38 EDT" exit=0 wall_s=296.0 log=logs/ol-u4-hist-loud.log 
S-S1-audit-other start_et="2026-10-13 13:46:02 EDT" exit=0 wall_s=165.9 log=logs/S-S1-audit-other.log 
S-S1-legacy-fsrc start_et="2026-10-13 13:48:48 EDT" exit=0 wall_s=24.0 log=logs/S-S1-legacy-fsrc.log 
S-S1-audit-inject start_et="2026-10-13 13:49:12 EDT" exit=0 wall_s=70.4 log=logs/S-S1-audit-inject.log 
S-S1-npm-check start_et="2026-10-13 13:50:22 EDT" exit=0 wall_s=17.8 log=logs/S-S1-npm-check.log 
S-S2-boot-same start_et="2026-10-13 13:50:41 EDT" exit=0 wall_s=65.5 log=logs/S-S2-boot-same.log 
S-S2-audit start_et="2026-10-13 13:51:47 EDT" exit=0 wall_s=72.8 log=logs/S-S2-audit.log 
S-S2-audit-ppt start_et="2026-10-13 13:53:00 EDT" exit=0 wall_s=38.6 log=logs/S-S2-audit-ppt.log 
S-S2-audit-other start_et="2026-10-13 13:53:38 EDT" exit=0 wall_s=198.4 log=logs/S-S2-audit-other.log 
S-S2-legacy-fsrc start_et="2026-10-13 13:56:57 EDT" exit=0 wall_s=21.5 log=logs/S-S2-legacy-fsrc.log 
S-S2-audit-inject start_et="2026-10-13 13:57:19 EDT" exit=0 wall_s=71.6 log=logs/S-S2-audit-inject.log 
S-S2-npm-check start_et="2026-10-13 13:58:30 EDT" exit=0 wall_s=19.8 log=logs/S-S2-npm-check.log 
ol-u4-read-loud CUT OFF: its lane wrapper L15 (PID 30719) reached its own 600 s cap at about 13:51:38 EDT while this run was going, so run.sh was stopped before it wrote its end record; the node (PID 6361, own session) finished by itself (log: ALL CHECKS PASSED, '# exit 0 at 1:52:07 PM ET'). Not counted; re-run alone as ol2-u4-read-loud. Nothing was killed by me.
ol-u4-hist-returns-true start_et="2026-10-13 14:01:32 EDT" exit=0 wall_s=293.3 log=logs/ol-u4-hist-returns-true.log 
ol2-u4-read-loud start_et="2026-10-13 14:01:32 EDT" exit=0 wall_s=295.3 log=logs/ol2-u4-read-loud.log 
os4-u3-pen-file-only start_et="2026-10-13 14:06:34 EDT" exit=0 wall_s=69.4 log=logs/os4-u3-pen-file-only.log 
om-u3-pen-file-only start_et="2026-10-13 14:06:31 EDT" exit=0 wall_s=77.9 log=logs/om-u3-pen-file-only.log 
f-F-litepre-base start_et="2026-10-13 14:07:51 EDT" exit=0 wall_s=271.2 log=logs/f-F-litepre-base.log 
f-F-liteall-c2 start_et="2026-10-13 14:07:48 EDT" exit=0 wall_s=338.7 log=logs/f-F-liteall-c2.log 
v4-F-supp4-c2 start_et="2026-10-13 14:12:32 EDT" exit=0 wall_s=66.4 log=logs/v4-F-supp4-c2.log 
os5-u3-pen-file-only start_et="2026-10-13 14:13:39 EDT" exit=1 wall_s=64.9 log=logs/os5-u3-pen-file-only.log 
v4-F-supp4-base start_et="2026-10-13 14:13:36 EDT" exit=1 wall_s=70.0 log=logs/v4-F-supp4-base.log 
os5-u3-pen-busy-only start_et="2026-10-13 14:14:53 EDT" exit=1 wall_s=81.3 log=logs/os5-u3-pen-busy-only.log 
v4-F-supp4-c1 start_et="2026-10-13 14:14:56 EDT" exit=1 wall_s=80.5 log=logs/v4-F-supp4-c1.log 
g-F-folderB-base start_et="2026-10-13 14:16:24 EDT" exit=137 wall_s=565.8 log=logs/g-F-folderB-base.log TIMED OUT = incomplete
g-F-folderB-base NOT COUNTED: its node (PID 9284) was killed by the machine's memory-cgroup OOM killer at about 14:25:50 EDT (dmesg: 'Memory cgroup out of memory: Killed process 9284 (node)'; exit 137, 111 checks recorded). Not killed by me. Re-run as g2-F-folderB-base.
g-F-folderB-c2 CUT OFF: no end record; its lane wrapper (PID 9207) and the run's own timeout reached 600 s at about 14:26:21 EDT under load (122 checks recorded). Not counted; F-folderB re-run in two halves (F-folderB1, F-folderB2), both copies.
g-F-folderA-c2 start_et="2026-10-13 14:25:56 EDT" exit=0 wall_s=404.6 log=logs/g-F-folderA-c2.log 
g-F-folderA-base start_et="2026-10-13 14:26:30 EDT" exit=0 wall_s=375.1 log=logs/g-F-folderA-base.log 
g-F-folderB1-c2 start_et="2026-10-13 14:32:45 EDT" exit=0 wall_s=285.1 log=logs/g-F-folderB1-c2.log 
g-F-folderB1-base start_et="2026-10-13 14:32:48 EDT" exit=0 wall_s=282.5 log=logs/g-F-folderB1-base.log 
g-F-folderB2-c2 start_et="2026-10-13 14:37:33 EDT" exit=0 wall_s=64.3 log=logs/g-F-folderB2-c2.log 
g-F-folderB2-base start_et="2026-10-13 14:37:37 EDT" exit=0 wall_s=67.0 log=logs/g-F-folderB2-base.log 
g-F-hold-c2 start_et="2026-10-13 14:38:40 EDT" exit=0 wall_s=67.4 log=logs/g-F-hold-c2.log 
g-F-hold-base start_et="2026-10-13 14:38:53 EDT" exit=0 wall_s=68.1 log=logs/g-F-hold-base.log 
g-F-u2-c2 start_et="2026-10-13 14:39:56 EDT" exit=0 wall_s=91.8 log=logs/g-F-u2-c2.log 
g-F-u2-base start_et="2026-10-13 14:40:09 EDT" exit=0 wall_s=83.2 log=logs/g-F-u2-base.log 
g-F-u13-c2 start_et="2026-10-13 14:41:33 EDT" exit=0 wall_s=53.4 log=logs/g-F-u13-c2.log 
g-F-u13-base start_et="2026-10-13 14:41:36 EDT" exit=0 wall_s=52.0 log=logs/g-F-u13-base.log 
g-F-nr02-c2 start_et="2026-10-13 14:42:29 EDT" exit=0 wall_s=17.1 log=logs/g-F-nr02-c2.log 
g-F-nr02-base start_et="2026-10-13 14:42:32 EDT" exit=0 wall_s=17.5 log=logs/g-F-nr02-base.log 
S-S3-audit-recon start_et="2026-10-13 14:42:55 EDT" exit=0 wall_s=269.4 log=logs/S-S3-audit-recon.log 
S-S4-audit-recon start_et="2026-10-13 14:42:58 EDT" exit=0 wall_s=275.9 log=logs/S-S4-audit-recon.log 
S-S6-audit-hostile start_et="2026-10-13 14:47:37 EDT" exit=0 wall_s=263.3 log=logs/S-S6-audit-hostile.log 
S-S5-audit-hostile start_et="2026-10-13 14:47:33 EDT" exit=0 wall_s=268.6 log=logs/S-S5-audit-hostile.log 
ol-u4-no-render start_et="2026-10-13 14:52:02 EDT" exit=0 wall_s=259.6 log=logs/ol-u4-no-render.log 
x-c2-impmixed-file-unguarded start_et="2026-10-13 14:52:05 EDT" exit=1 wall_s=266.0 log=logs/x-c2-impmixed-file-unguarded.log 
x-c2-impmixed-folder-unguarded start_et="2026-10-13 14:56:31 EDT" exit=1 wall_s=296.6 log=logs/x-c2-impmixed-folder-unguarded.log 
x-c2-impmixed-not-marked start_et="2026-10-13 14:56:34 EDT" exit=1 wall_s=310.0 log=logs/x-c2-impmixed-not-marked.log 
x-c2-impmixed-not-kept start_et="2026-10-13 15:01:32 EDT" exit=1 wall_s=328.8 log=logs/x-c2-impmixed-not-kept.log 
x-c2-impmixed-clear-unasked start_et="2026-10-13 15:01:45 EDT" exit=1 wall_s=321.5 log=logs/x-c2-impmixed-clear-unasked.log 
x-c2-impmixed-boot-silent start_et="2026-10-13 15:07:08 EDT" exit=1 wall_s=419.7 log=logs/x-c2-impmixed-boot-silent.log 
x-c2-impmixed-never-lifted start_et="2026-10-13 15:07:11 EDT" exit=1 wall_s=418.4 log=logs/x-c2-impmixed-never-lifted.log 
x-c2-v200-r4-no-recheck start_et="2026-10-13 15:14:17 EDT" exit=1 wall_s=314.9 log=logs/x-c2-v200-r4-no-recheck.log 
x-c2-impmixed-lift-partial start_et="2026-10-13 15:14:14 EDT" exit=1 wall_s=321.6 log=logs/x-c2-impmixed-lift-partial.log 
x-c2-v200-r4-said-not-held start_et="2026-10-13 15:19:45 EDT" exit=1 wall_s=324.2 log=logs/x-c2-v200-r4-said-not-held.log 
x-c2-v200-r4-held-quietly start_et="2026-10-13 15:19:42 EDT" exit=1 wall_s=327.4 log=logs/x-c2-v200-r4-held-quietly.log 
x-base-impmixed-file-unguarded start_et="2026-10-13 15:25:23 EDT" exit=1 wall_s=250.1 log=logs/x-base-impmixed-file-unguarded.log 
x-c2-saves-not-serial start_et="2026-10-13 15:25:15 EDT" exit=1 wall_s=328.5 log=logs/x-c2-saves-not-serial.log 
x-base-impmixed-folder-unguarded start_et="2026-10-13 15:29:39 EDT" exit=1 wall_s=246.0 log=logs/x-base-impmixed-folder-unguarded.log 
x-c2-saves-not-serial-folderA start_et="2026-10-13 15:30:53 EDT" exit=1 wall_s=447.7 log=logs/x-c2-saves-not-serial-folderA.log 
x-base-saves-not-serial-folderA start_et="2026-10-13 15:33:52 EDT" exit=1 wall_s=455.6 log=logs/x-base-saves-not-serial-folderA.log
```

## PIDs

`pids.txt` (378 lines): every lane or queue-runner wrapper and, for each run, its `timeout` and `node` PIDs with
the command.
