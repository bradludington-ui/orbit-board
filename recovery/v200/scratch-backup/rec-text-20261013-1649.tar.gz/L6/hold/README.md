# HOLD track — U3 and U4: the mixed-import hold cannot be written past

Builder's record for ORBIT v2.00, release track HOLD. Everything here is in `rec/L6/hold` (this directory). Nothing was
edited, staged, committed or pushed in `/home/user/orbit-board` or `/home/user/orbit-ui`; the lead commits. Times are
Eastern (`TZ=America/New_York date`). This README was assembled at 2026-10-13 09:23 EDT by `bin/mkreadme.py` from `README.src.md`
(hand-written) and the run records (`logs/runs.txt`, `logs/bx.txt`, `pids.txt`); the diffs below are inlined from
`diffs/` byte for byte.

## At a glance

| | U3 (commit 1, copy `c1`) | U4 (commit 2, copy `c2`) |
|---|---|---|
| Reproduced on the base (`7ee498a`, board `fce8a391`) | yes, six ways a save is asked for (probe, literals) | yes, held at the read, at the history copy, and Take the pen (probe, literals) |
| Board change | 5 code lines added (+3 comment lines) | 7 code lines added (+6 comment lines) |
| Suite block (audit-import) | 47 checks: **18 fail on base**, 0 on c1, 0 on c2 | 18 checks: **10 fail on base**, 10 on c1, 0 on c2 |
| New mutations | 6, each caught by the block | 5, each caught by the block |
| Re-run after the 9:11 AM ET restart (`r2-*`, fifth builder) | base 18 fail, c2 0: the same checks, verdicts and values as `r1-*` | base 10, c1 10, c2 0: the same as `r1-*` |
| Existing checks (focused, every audit-import block that touches these paths) | 709 checks: identical checks, verdicts and values on base, c1, c2 | (same runs) |
| Existing hold mutations on the final copy | 12 of 12 caught (focused, verbatim blocks) | |
| mcount (text) | 1334 entries, each once | 1339 entries, each once (base 1328) |
| Other suites + `npm run check` (scratch clones) | — | all 9 pass on base and c2, the same |

Proposed commits (the lead commits; nothing is committed here):

1. `v2.00 (U3): a Save asked for during the mixed-import hold is refused at once, never queued` — copy `c1`: board
   `82a2f1cc`, audit-import `22cdd78e`, mutate `c3cab761` (audit-recon `529e36f7`, audit-board `a7c575e5`, audit-other
   `d89396b0` unchanged).
2. `v2.00 (U4): the folder save checks the mixed-import hold after its read and before its write` — copy `c2` (cumulative):
   board `4b755576`, audit-import `f25c69f7`, mutate `27f0fdb6` (the other suites unchanged).

In each copy the mutation list is `tools/export-audit/mutate.mjs.txt`; it is committed as `tools/export-audit/mutate.mjs`.

## Resuming: what was kept from the earlier attempts, and what was re-run

### The fifth HOLD builder (13 Oct, from 9:13 AM ET)

The fourth builder was stopped by a usage limit at about 6:01 AM ET with everything built and run; the README (assembled at
5:58 AM ET) and the drafts were being finished. The container restarted at 9:11 AM ET. Before relying on anything I checked:

- **Copies and diffs.** `diff -rq` against the base and between the copies: only the board, `audit-import.mjs` and
  `mutate.mjs.txt` differ, base→c1 and c1→c2; the `node_modules` links are intact. The six diffs re-derived now
  (`chk5/`) are byte-identical to the stored `diffs/`, and none removes or changes a base line (pure insertions). Blobs
  re-hashed: board base `fce8a391` → c1 `82a2f1cc` → c2 `4b755576`; audit-import `4aba2506` → `22cdd78e` → `f25c69f7`;
  mutate `cbc6defc` → `c3cab761` → `27f0fdb6`; audit-recon, audit-board, audit-other unchanged. `orbit-board` HEAD is
  now `f40eded`; its board, suites, `mutate.mjs`, `package.json` and `NEXT-VERSION.md` blobs are still `7ee498a`'s (it
  differs only under `recovery/`), so the base stands.
- **The code.** I read both board diffs against the base's code (`impMixedBlock(what, quiet)`, `impMixedOn`,
  `saveSerial`, every caller of the five entry points: each awaits the result or ignores it, so a refusal returning at
  once — `undefined` or `false` — is handled as the refusal at the start of the run was; the autosave's `done=await p`
  stays false and says nothing). I kept the boards, blocks and entries unchanged.
- **Logs.** Every log in `logs/` has an exit record except `f3-F-holdall-c2`, which the third builder recorded as cut off
  and the fourth re-ran as `g4-F-holdall-c2` (complete). `x10-c2-saves-not-serial` (6:00–6:02 AM ET, the fourth builder's
  last run) is complete, with its exit record; it was not yet in the README.
- **Re-run now, after the restart** (`r2-*`, the same harness files): U3 on base and c2, U4 on base, c1 and c2. Each gives
  the same checks, verdicts and values as `r1-*` (table below).
- **Run now, new:** `x11-base-saves-not-serial` — the existing mutation `saves-not-serial` on the base against
  `F-folderA`, to compare with the fourth builder's `x10` on c2 (below); `bin/exsweep.py` (text only) lists every existing
  mutation entry whose find lands in the functions U3/U4 change.
- **Drafts:** kept, with these corrections: a broken line wrap in the U3 entry; the U3 entry's sentence on which blocks
  catch the older hold mutations (it said "the same existing blocks", not measured on the base for nine of them; now it
  names the blocks, and `saves-not-serial`'s five checks measured on both boards, x10/x11); a "Not covered" clause on a
  hold that comes while Take the pen reads or asks; the ledger texts also as one line each (a table cell holds no line
  break); and the "Unresolved" and R4b texts as exact lines with their leading spaces (the R4b text is now one added line,
  not a replacement). README: this section, the r2 and x10/x11 tables, the sweep of other entries, the overlap note on the
  adoption and U20/U30 tracks, the draft blobs and the run records.

### The fourth HOLD builder (13 Oct, 4:20–6:01 AM ET)

This directory held the third HOLD builder's work (stopped by a usage limit at about 12:51 AM ET; container restarted at
4:11 AM ET). Its `c1/` and `c2/` copies date from the first builder (5:51 PM ET, 12 Oct) with the third builder's edits (board
12:14–12:15 AM ET, suites 12:21 AM, mutate 12:25 AM). Before building on anything the fourth builder re-checked it ("I"
in this subsection is the fourth builder):

- **Copies.** `diff -rq` against the base: only the board, `audit-import.mjs` and `mutate.mjs.txt` differ in each; every
  other file (other suites, `NEXT-VERSION.md`, `package.json`, the shim, the `node_modules` link) is the base's. The diffs
  re-derived now (`chk/`) are byte-identical to the stored `diffs/`; every change, base→c1→c2, is a pure insertion (no base
  line changed or removed, in all three files). The U3 block is byte-identical in c1's and c2's suites and to
  `blocks/u3.mjs.txt`; the U4 block to `blocks/u4.mjs.txt`; the entries to `blocks/entries-u*.mjs.txt`.
- **Mutants and harnesses.** All 41 mutant boards in `mut/` were rebuilt from the copies' `mutate.mjs.txt` (text only,
  `rec/bin/mkmut.py`) into `chk/mut/`: all 41 identical. All 11 focused harnesses were rebuilt from c2's suite into
  `chk/harness/`: all identical to `harness/` and to the copies under `h/base`, `h/c1`, `h/c2`.
- **Kept as sound** (complete logs, exit records, the board and harness blobs they name are today's): the 39 probe runs
  (`probe-*`, 12:11–12:20 AM ET); the focused runs `f2-*`; the mutant runs `m1-*`, `m2-*`, `m3-*`; `f3-F-holdpre-base`,
  `f3-F-holdpre-c2`, `f4-F-litepre-base`, `f4-F-liteall-c2`.
- **Re-run:** `f3-F-holdall-c2` had been cut off by its batch wrapper's 600 s bound (no exit record; 170 of 270 rows):
  re-run alone as `g4-F-holdall-c2` (all 270 checks pass). The U3 and U4 focused runs on base, c1 and c2 were re-run as
  `r1-*` for confirmation: the same checks with the same verdicts as `f2-*`, every one.
- **Not run before, run now:** every other audit-import block that touches the changed paths, on base, c1 and c2
  (`g*`); the twelve existing hold mutations on c2 and two of them on the base (`x*`); the other suites and
  `npm run check` in scratch clones (`S-*`); mcount on every copy; a harness for the one block no earlier harness
  held (`F-nr02`).
- **Drafts, README:** written now (the earlier `drafts/` was empty).

## The findings, reproduced on the base first

Probe: `probe/hold-probe.mjs` (blob `fb8c557d`) = `probe/head.mjs.txt` + the W1H block and the W2 helpers copied
verbatim from the base's audit-import (lines 3745–3813 and 4153–4258, asserted by their first and last lines;
`bin/mkprobe.py`) + `probe/body.mjs.txt`. It records observations only (counts, booleans, the Full Fund generation a file
holds read from its text, status lines); the verdicts below are written by hand against them. Outputs: `out/probe-<copy>-<scenario>.json`.

**U3** — save A (the board file, or the shared folder) is held at the close of its write; a full import stops part-way and
cannot be put back (the hold is on); request B is asked for; saving is allowed again (`impMixedClear`, confirm answered
yes); A is let go.

| Scenario (B) | Base: after 60 turns | Base: end | c1 / c2: after 60 turns | c1 / c2: end |
|---|---|---|---|---|
| U3-file `saveInPlaceFile()` | not decided, "⏳ A save is already under way — this one runs as soon as it finishes." | `perm 2 · read 2 · open 2 · writes 2`, file Full Fund **NEW** | decided, "⛔ Saving to the board file is refused. …" | `perm 1 · read 1 · open 1 · writes 1`, Full Fund OLD |
| U3-save `saveInPlace()` (💾 Save, board file) | same, queued | writes 2, Full Fund **NEW** | refused at once, same words | writes 1, OLD |
| U3-pen `takePen()` (board file) | queued, after **reading the file again and asking** (read 2, asked 1) | writes 2, Full Fund **NEW** | "⛔ Taking the pen is refused. …", read 1, asked 0 | writes 1, OLD |
| U3-folder `saveInPlace()` (folder) | queued | 3 writes of the folder's copy, 2 history copies | "⛔ Writing to the shared folder is refused. …" | 2 writes, 1 history copy |
| U3-publish `driveStorePush(false)` (⬆ Publish now) | queued | 3 writes, 2 history copies | refused at once, same words | 2 writes, 1 history copy |
| U3-resolve `driveResolve('mine')` (Save yours over theirs) | queued | 3 writes, 3 history copies, 2 questions | "⛔ Choosing between the copies is refused. …" | 2 writes, 1 history copy |
| C3-file (control: no import) | queued | writes 2, OLD | queued (unchanged) | writes 2, OLD |
| C3-idle (control: hold on, nothing running) | refused, `perm 0 · read 0 · open 0 · writes 0` | — | the same | — |

In each U3 case on c1/c2, the retry after saving was allowed writes once and says "Saved" (the control).

**U4** — the board's first copy is saved to the folder (v1) and a note typed (EDIT-1); 💾 Save is held at a wait; the
import stops part-way there; the save is let go.

| Scenario | Base (and c1) | c2 |
|---|---|---|
| U4-read (held at its read of the folder's copy) | **1 write**, history +1, folder copy = EDIT-1, `DIRTY` false, stamp moved, "✅ Saved O&M FY27 to the shared folder — 5 KB." | 0 writes, history +0, folder copy = v1, `DIRTY` true, stamp back, "⛔ Writing to the shared folder is refused. …" |
| U4-hist (held at the close of its history copy) | **1 write**, history +1, stamp moved, "✅ Saved … A change made while it was saving is not in the folder yet" | 0 writes, history +1 (v1 as read), stamp back, refused |
| U4-pen (Take the pen from Alice, held at its history copy) | **1 write**, writer **brad**, 1 pen line, stamp and name moved, "✅ Saved … You now hold the pen for it." | 0 writes, writer Alice, 0 pen lines, stamp and name back, refused |
| C4-read (control: nothing happens at the read) | 1 write, "✅ Saved", header "Saved 12:13 AM" | the same ("Saved 12:20 AM") |
| C4-retry (U4-read, then allow saving again and 💾 Save) | first save already wrote; retry writes again | first refused; retry writes once, EDIT-1, "✅ Saved" |

Both findings reproduce; neither is called rare or common (how often an import stops part-way during another save was not
measured).

## The changes (exact diffs)

### Commit 1 — U3: board (`diffs/c1-board.diff`, blob `b172c561`)

```diff
--- ../base/prioritization-board-grid.html	2026-10-12 21:17:00.000000000 +0000
+++ c1/prioritization-board-grid.html	2026-10-13 04:14:30.653760667 +0000
@@ -8301,6 +8301,10 @@
 }
 async function saveInPlace(){
   if(sandboxBlock('Saving to the shared file')||cycBlock('Saving to the shared file')) return;
+  // v2.00 (U3): THE MIXED-IMPORT HOLD REFUSES A SAVE WHEN IT IS ASKED FOR, never queued. Asked for behind a save under way, it
+  // waited its turn and was checked only then: if saving was allowed again meanwhile, it ran and wrote what the hold had held
+  // back. Brad, 11 Oct: refused at once, before the file is touched; allowing saving again does not bring it back.
+  if(impMixedBlock(driveStoreOn()? 'Writing to the shared folder' : 'Saving to the board file')) return;
   // THE YEAR THIS SAVE WAS ASKED FOR (v1.95, item 47): a save that waits behind another keeps it, and
   // never moves to another year's copy because the board moved on while it waited.
   const fy=MS.cur;
@@ -8317,6 +8321,7 @@
 }
 function saveInPlaceFile(){
   if(sandboxBlock('Saving to a file')||cycBlock('Saving to a file')) return;    // refused at once, never queued
+  if(impMixedBlock('Saving to the board file')) return;                         // v2.00 (U3): and under the mixed-import hold
   return saveSerial(_saveInPlaceFileRun);
 }
 async function _saveInPlaceFileRun(){
@@ -26840,6 +26845,7 @@
 // `fy`: the year it was asked for, captured now, before it waits.
 function driveStorePush(quiet, fy){
   if(sandboxBlock('Writing to the shared folder')||cycBlock('Writing to the shared folder')) return;   // at once, never queued
+  if(impMixedBlock('Writing to the shared folder', quiet)) return false;                             // v2.00 (U3): so is the hold
   const f=fy||MS.cur;
   return saveSerial(function(){ return _driveStorePushRun(quiet, f); });
 }
@@ -26969,6 +26975,7 @@
 // 'mine': keep their copy in the folder's history -- forced, whatever the spacing -- then save over it.
 function driveResolve(which){   // queued (v1.95); refused at once in a PMO copy or a locked view
   if(sandboxBlock('Writing to the shared folder')||cycBlock('Loading a board')) return false;
+  if(impMixedBlock('Choosing between the copies')) return false;     // v2.00 (U3): and under the mixed-import hold
   return saveSerial(function(){ return _driveResolveRun(which); });
 }
 async function _driveResolveRun(which){
@@ -27017,6 +27024,7 @@
 // Then it saves, recording you as the writer; the previous writer's next Save is refused.
 async function takePen(){
   if(sandboxBlock('Taking the pen')||cycBlock('Taking the pen')) return;
+  if(impMixedBlock('Taking the pen')) return;   // v2.00 (U3): it saves; under the hold, refused before anything is read or asked
   const folder=driveStoreOn(), ap=mySlug(), fy=MS.cur;
   let cur=null, what='this board file';
   try{
```

### Commit 1 — U3: audit-import (`diffs/c1-audit-import.diff`, blob `e90c7511`)

```diff
--- ../base/tools/export-audit/audit-import.mjs	2026-10-12 21:17:00.000000000 +0000
+++ c1/tools/export-audit/audit-import.mjs	2026-10-13 04:21:14.993784702 +0000
@@ -7062,6 +7062,139 @@
   await settleBoards();
 })();
 // ==== end v2.00 R4 ====
+// ==== v2.00 (U3): a Save asked for during the mixed-import hold is refused at once, never queued ====
+// v2.00 (U3): R4b's contract (Brad, 11 Oct): "a Save requested while the mixed-import hold is already active must refuse
+// immediately, before file access. Clearing the hold later must not resume that refused request." With another save under
+// way, such a Save was queued instead ("⏳ A save is already under way — this one runs as soon as it finishes") and checked
+// only when its turn came. If saving was allowed again first, it ran and wrote: for the board file, the mix -- the imported
+// Full Fund plan -- over the one whole copy of the board as it was. Here save A is held at the close of its write, the import
+// stops part-way and cannot be put back, request B is asked for, saving is allowed again ("allow saving again…", answered
+// yes), and A is let go. B is each way a save is asked for: the board file's Save, 💾 Save and Take the pen on the board
+// file; 💾 Save, ⬆ Publish now and Save yours over theirs working out of the shared folder. The controls: asked for again
+// once saving is allowed, it writes; with no hold, B waits its turn and writes after A; and a Save asked for BEFORE the hold,
+// still waiting its turn when the hold comes, is refused when its turn comes, before the file or the folder's copy is read.
+// FAILS ON 7ee498a (board fce8a391): B waits its turn and writes after A -- perm 2 · read 2 · open 2 · writes 2, the board
+// file holding the imported Full Fund plan; in the folder, a second write and a second history copy.
+await (async () => {   // a function, not a bare block: see settleBoards() in boot.mjs
+  const __bm = bootMark();
+  const name = 'v2.00 (U3) — a Save asked for during the mixed-import hold is refused at once, never queued';
+  try {
+    const { NEW, OLD } = w2Fx();
+    const { J, wire, KEY, status, qs, disk, folder, connect, gate, until, tick, pause } = W1H;
+    const turns = async n => { for (let i = 0; i < n; i++) await tick(); };
+    const QUEUED = /A save is already under way/;
+    // Which generation of the Full Fund plan a board file holds, read from its text.
+    const fileFF = html => { const m = String(html).match(/id="pubState">([\s\S]*?)<\/script>/);
+      const s = JSON.stringify(((JSON.parse(m[1]).appns || {}).ff || {}).years || {});
+      return /NEW/.test(s) && /OLD/.test(s) ? 'BOTH' : /NEW/.test(s) ? 'NEW' : /OLD/.test(s) ? 'OLD' : 'none'; };
+    // THE BOARD FILE: save A held at the close of its write; every permission request, read and open counted.
+    const inFile = async () => {
+      const T = boot({ html: OLD.html, ls: OLD.ls }); await pause(80);
+      wire(T.ev, 'brad', KEY.brad);
+      const f = disk(T.w, OLD.html);
+      T.w.__disk.requestPermission = async () => { f.hits.perm = (f.hits.perm || 0) + 1; return 'granted'; };
+      const touched = () => `perm ${f.hits.perm || 0} · read ${f.hits.read || 0} · open ${f.hits.open || 0} · writes ${f.writes}`;
+      const g = gate(); f.hold.close = g;
+      const pA = T.ev('saveInPlaceFile()');
+      const held = await until(() => (f.hits.close || 0) >= 1);
+      return { T, f, touched, g, pA, held };
+    };
+    // THE SHARED FOLDER: the board's first copy saved, a note typed, save A held at the close of its write of the copy;
+    // every read of the folder's copy counted.
+    const inFolder = async () => {
+      const T = boot({ html: OLD.html, ls: OLD.ls }); await pause(80);
+      wire(T.ev, 'brad', KEY.brad);
+      const fold = folder(); connect(T.ev, T.w, fold);
+      const NM = 'spmt-' + T.ev('MS.cur') + '-om.json', gh = fold.dir.getFileHandle; let reads = 0;
+      fold.dir.getFileHandle = async (n, o) => { if (n === NM && !(o && o.create)) reads++; return gh(n, o); };
+      await T.ev('saveInPlace()');
+      T.ev(`setNote('A','EDIT-1'); 'ok'`); await pause(5);
+      const g = gate(); fold.hold.main = g;
+      const pA = T.ev('saveInPlace()');
+      const held = await until(() => (fold.hits.main || 0) >= 2);
+      return { T, fold, reads: () => reads, g, pA, held };
+    };
+    const stop = (T) => { const r = w2Import(T, NEW.html, 'stuck', 8); wire(T.ev, 'brad', KEY.brad);   // w2Import answers yes to everything; this records the questions again
+      return J([r.ret, /could not be put back as it was/.test(r.stat), T.ev('String(impMixedOn())')]); };
+    const ask = async (T, how) => { const o = { decided: false, q0: qs(T.ev).length }; o.p = Promise.resolve(T.ev(how)).then(() => { o.decided = true; }); await turns(60); return o; };
+    for (const [how, words, label] of [['saveInPlaceFile()', 'Saving to the board file', 'the board file’s Save'],
+                                        ['saveInPlace()', 'Saving to the board file', '💾 Save'],
+                                        ['takePen()', 'Taking the pen', 'Take the pen']]) {
+      const at = label + ' on the board file, with a save under way';
+      const { T, f, touched, g, pA, held } = await inFile();
+      chk(name, at, 'save A is held at the close of its write (a control)', J([held, touched()]), J([true, 'perm 1 · read 1 · open 1 · writes 0']));
+      chk(name, at, 'the import stopped part-way, could not be put back, and the hold is on (a control)', stop(T), J([false, true, 'true']));
+      const b = await ask(T, how);
+      chk(name, at, 'refused at once: the request is over, nothing more is touched or asked, and it is not queued',
+        J([b.decided, touched(), qs(T.ev).length - b.q0, QUEUED.test(status(T.ev))]), J([true, 'perm 1 · read 1 · open 1 · writes 0', 0, false]));
+      chk(name, at, 'the board says ' + words.toLowerCase() + ' is refused, and that nothing writes over the board file',
+        new RegExp(words + ' is refused').test(status(T.ev)) && /nothing writes over it/.test(status(T.ev)), true);
+      T.ev(`globalThis.__yes=true; impMixedClear(); 'ok'`);
+      chk(name, at, 'saving is allowed again (a control)', T.ev('String(impMixedOn())'), 'false');
+      g.open(); await pA; await until(() => b.decided); await turns(60);
+      chk(name, at, 'allowing saving again does not bring it back: A alone wrote, and the board file holds no imported plan',
+        J([touched(), fileFF(f.content)]), J(['perm 1 · read 1 · open 1 · writes 1', 'OLD']));
+      const w0 = f.writes; await T.ev('saveInPlaceFile()');
+      chk(name, at, 'CONTROL — asked for again now saving is allowed, Save writes', J([f.writes - w0, /Saved in place/.test(status(T.ev))]), J([1, true]));
+    }
+    for (const [how, words, label] of [['saveInPlace()', 'Writing to the shared folder', '💾 Save'],
+                                        ['driveStorePush(false)', 'Writing to the shared folder', '⬆ Publish now'],
+                                        [`driveResolve('mine')`, 'Choosing between the copies', 'Save yours over theirs']]) {
+      const at = label + ' working out of the shared folder, with a save under way';
+      const { T, fold, reads, g, pA, held } = await inFolder();
+      const r0 = reads(), h0 = fold.hist().length;
+      chk(name, at, 'save A is held at the close of its write (a control)', held, true);
+      chk(name, at, 'the import stopped part-way, could not be put back, and the hold is on (a control)', stop(T), J([false, true, 'true']));
+      const b = await ask(T, how);
+      chk(name, at, 'refused at once: the request is over, the folder’s copy is not read again, nothing is asked, and it is not queued',
+        J([b.decided, reads() - r0, qs(T.ev).length - b.q0, QUEUED.test(status(T.ev))]), J([true, 0, 0, false]));
+      chk(name, at, 'the board says ' + words.toLowerCase() + ' is refused', new RegExp(words + ' is refused').test(status(T.ev)), true);
+      T.ev(`globalThis.__yes=true; impMixedClear(); 'ok'`);
+      g.open(); await pA; await until(() => b.decided); await turns(60);
+      chk(name, at, 'allowing saving again does not bring it back: A alone wrote the folder’s copy, nothing more was read, nothing more kept in its history',
+        J([fold.hits.main || 0, reads() - r0, fold.hist().length - h0]), J([2, 0, 0]));
+      const m0 = fold.hits.main || 0; await T.ev('saveInPlace()');
+      chk(name, at, 'CONTROL — asked for again now saving is allowed, 💾 Save writes', J([(fold.hits.main || 0) - m0, /✅ Saved O&M FY27 to the shared folder/.test(status(T.ev))]), J([1, true]));
+    }
+    // CONTROL -- NO HOLD: B waits its turn behind A, as it always has, and writes after it.
+    {
+      const at = 'CONTROL — no hold: the board file’s Save, with a save under way';
+      const { T, f, touched, g, pA } = await inFile();
+      const b = await ask(T, 'saveInPlaceFile()');
+      chk(name, at, 'B waits its turn, and the board says so', J([b.decided, QUEUED.test(status(T.ev)), touched()]), J([false, true, 'perm 1 · read 1 · open 1 · writes 0']));
+      g.open(); await pA; await until(() => b.decided);
+      chk(name, at, 'then B writes, after A', J([touched(), fileFF(f.content)]), J(['perm 2 · read 2 · open 2 · writes 2', 'OLD']));
+    }
+    // A SAVE ASKED FOR BEFORE THE HOLD, still waiting its turn when the hold comes: refused when its turn comes, before the
+    // file or the folder's copy is read (the check at the start of its turn; R4's after the read is the one behind it).
+    {
+      const at = 'the board file’s Save asked for before the hold, waiting its turn';
+      const { T, f, touched, g, pA } = await inFile();
+      const b = await ask(T, 'saveInPlaceFile()');
+      chk(name, at, 'B waits its turn (a control)', J([b.decided, QUEUED.test(status(T.ev))]), J([false, true]));
+      chk(name, at, 'the import stopped part-way, could not be put back, and the hold is on (a control)', stop(T), J([false, true, 'true']));
+      g.open(); await pA; await until(() => b.decided);
+      chk(name, at, 'refused when its turn comes, before the file is touched: A alone asked, read, opened and wrote',
+        J([touched(), /Saving to the board file is refused/.test(status(T.ev))]), J(['perm 1 · read 1 · open 1 · writes 1', true]));
+    }
+    {
+      const at = '💾 Save working out of the shared folder, asked for before the hold, waiting its turn';
+      const { T, fold, reads, g, pA } = await inFolder();
+      const r0 = reads();
+      const b = await ask(T, 'saveInPlace()');
+      chk(name, at, 'B waits its turn (a control)', J([b.decided, QUEUED.test(status(T.ev))]), J([false, true]));
+      chk(name, at, 'the import stopped part-way, could not be put back, and the hold is on (a control)', stop(T), J([false, true, 'true']));
+      g.open(); await pA; await until(() => b.decided);
+      chk(name, at, 'refused when its turn comes, before the folder’s copy is read: A alone wrote it',
+        J([fold.hits.main || 0, reads() - r0, /Writing to the shared folder is refused/.test(status(T.ev))]), J([2, 0, true]));
+    }
+  } catch (e) {
+    failures.push({ scenario: name, where: 'harness', what: 'the block threw: ' + String((e && e.stack) || e).slice(0, 300), got: 'threw', want: 'ran' });
+  }
+  bootRelease(__bm, keepBoards());
+  await settleBoards();
+})();
+// ==== end v2.00 (U3) ====
 // ==== v2.00 (R5): a restore during a save stays unsaved ====
 // ↶ Put this back marked the board unsaved but did not count as a change. A folder save still writing when the copy was
 // put back found nothing changed while it wrote and marked the board saved: the earlier copy on screen, the save's copy in
```

### Commit 1 — U3: mutate.mjs (`diffs/c1-mutate.diff`, blob `309c01b6`)

```diff
--- ../base/tools/export-audit/mutate.mjs.txt	2026-10-12 21:17:00.000000000 +0000
+++ c1/tools/export-audit/mutate.mjs.txt	2026-10-13 04:25:11.041798733 +0000
@@ -4285,6 +4285,25 @@
   { id: "v200-u14-notice-plural-it", area: "flowHtml", what: "the panel's notice says \"keeps it\" however many saved years the board cannot answer for: FY24 and FY26 \"stay in the saved selection\", and switching a year \"keeps it\"",
     find: "switching a year on or off keeps '+(F.unavail.length===1?'it':'them')+'.</div>'",
     repl: "switching a year on or off keeps it.</div>'" },
+  // v2.00 (U3): a Save asked for during the mixed-import hold is refused at once, never queued.
+  { id: "v200-u3-save-queued", area: "saveInPlace", what: "💾 Save (and Take the pen's save) asked for under the hold behind a save under way is queued, not refused: once saving is allowed again it runs and writes the imported Full Fund plan over the board file, or writes the folder's copy",
+    find: "  if(impMixedBlock(driveStoreOn()? 'Writing to the shared folder' : 'Saving to the board file')) return;\n",
+    repl: "" },
+  { id: "v200-u3-save-file-words", area: "saveInPlace", what: "💾 Save working out of the shared folder is refused at once under the hold, but in the board file's words: \"Saving to the board file is refused\", though it saves to the shared folder",
+    find: "impMixedBlock(driveStoreOn()? 'Writing to the shared folder' : 'Saving to the board file')",
+    repl: "impMixedBlock('Saving to the board file')" },
+  { id: "v200-u3-file-queued", area: "saveInPlaceFile", what: "the board file's Save asked for under the hold behind a save under way is queued: once saving is allowed again it writes the mix over the board file",
+    find: "  if(impMixedBlock('Saving to the board file')) return;                         // v2.00 (U3): and under the mixed-import hold\n",
+    repl: "" },
+  { id: "v200-u3-publish-queued", area: "driveStorePush", what: "⬆ Publish now asked for under the hold behind a save under way is queued: once saving is allowed again it writes the folder's copy",
+    find: "  if(impMixedBlock('Writing to the shared folder', quiet)) return false;                             // v2.00 (U3): so is the hold\n",
+    repl: "" },
+  { id: "v200-u3-resolve-queued", area: "driveResolve", what: "Save yours over theirs asked for under the hold behind a save under way is queued: once saving is allowed again it keeps a forced history copy and writes the folder's copy",
+    find: "  if(impMixedBlock('Choosing between the copies')) return false;     // v2.00 (U3): and under the mixed-import hold\n",
+    repl: "" },
+  { id: "v200-u3-pen-reads-first", area: "takePen", what: "Take the pen under the hold reads the board file and asks whether to take the pen before its save is refused",
+    find: "  if(impMixedBlock('Taking the pen')) return;   // v2.00 (U3): it saves; under the hold, refused before anything is read or asked\n",
+    repl: "" },
   // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.
   { id: "v200-r3-landed-view-unsaid", area: "_driveStorePushRun", what: "a folder save that lands while a locked view is on screen says “🔒 Not kept — PB27 is a locked view. ✅ Saved …” again, naming no plan (or, quiet, leaves persist's refusal on screen)",
     find: "  if(CYCVIEW){ _cycRefusedAt=0; setStat('✅ <b>Saved the working plan</b> of '+esc(APPN_LBL[ap]||ap)+' FY'+(fy%100)+' to the shared folder — '\n    +Math.round(body.length/1024)+' KB, built before '+blLbl(CYCVIEW)+' was put on screen. '+blLbl(CYCVIEW)+' is a locked view: nothing in it '\n    +'is saved. Everyone sees the working plan on their next refresh.'+penNote+lateNote); render(); return true; }\n",
```

### Commit 2 — U4: board (`diffs/c2-board.diff`, blob `989ad20f`)

```diff
--- c1/prioritization-board-grid.html	2026-10-13 04:14:30.653760667 +0000
+++ c2/prioritization-board-grid.html	2026-10-13 04:15:55.897765734 +0000
@@ -26878,6 +26878,10 @@
   // v2.00 (R3): A LOCKED CYCLE PUT ON SCREEN WHILE THE FOLDER WAS BEING READ is not the board. The bytes below would be the
   // locked plan, written over the working plan's copy with that copy kept as history, and "Saved" said. Nothing is written.
   if(cycBlock('Writing to the shared folder')) return false;
+  // v2.00 (U4): THE MIXED-IMPORT HOLD, CHECKED AGAIN AFTER THE READ. It was checked once, before the folder was read: a full
+  // import that stopped part-way during the read set the hold, and this save then wrote over the folder's copy and said
+  // "Saved". It is checked again after the last wait before the write, below.
+  if(impMixedBlock('Writing to the shared folder', quiet)) return false;   // v2.00 (U4): after the read
   // The year moved while the folder was being read: what is on screen is another year's board now.
   if(MS.cur!==fy){
     setStat('⚠ Not saved: the board moved to FY'+(MS.cur%100)+' while the shared folder’s copy of FY'+(fy%100)
@@ -26902,6 +26906,7 @@
       +'Press ↻ Reconnect to load the folder’s copy, or import a board first.');
     render(); return false;
   }
+  const ts0=MS.ts, by0=MS.by;      // v2.00 (U4): put back if the hold stops this save after its history copy (below)
   MS.ts=Date.now(); MS.by=whoAmI();
   // THE BYTES, AND WHICH SAVE THEY ARE (v1.95, item 47): built once, here, before the write's first wait.
   const body=JSON.stringify(livePayload(fwriter)), wroteTs=MS.ts, gen=_saveGen;
@@ -26928,6 +26933,14 @@
         render(); return false;
       }
     }
+    // v2.00 (U4): AND AFTER THE LAST WAIT BEFORE THE WRITE, the history copy above. An import that stopped part-way while it
+    // was being kept sets the hold: nothing is written over the folder's copy, and the copy kept in the history (the folder's
+    // copy as read) stays. The pen line, and the board's stamp the header shows as saved, go back to what they were.
+    if(impMixedOn()){
+      if(penLine) writerJournalUndo(penLine);
+      if(MS.ts===wroteTs){ MS.ts=ts0; MS.by=by0; }
+      impMixedBlock('Writing to the shared folder', quiet); render(); return false;
+    }
     await driveWrite(dir, driveName(fy, ap), body);
   }catch(e){ if(penLine) writerJournalUndo(penLine); throw e; }
   if(kept) await snapPrune(dir, fy, ap, kept.name, true);
```

### Commit 2 — U4: audit-import (`diffs/c2-audit-import.diff`, blob `1e699987`)

```diff
--- c1/tools/export-audit/audit-import.mjs	2026-10-13 04:21:14.993784702 +0000
+++ c2/tools/export-audit/audit-import.mjs	2026-10-13 04:21:15.061568417 +0000
@@ -7195,6 +7195,101 @@
   await settleBoards();
 })();
 // ==== end v2.00 (U3) ====
+// ==== v2.00 (U4): the folder save checks the mixed-import hold after its read and before its write ====
+// v2.00 (U4): _driveStorePushRun checked the hold once, before it read the folder's copy. A full import that stopped part-way
+// during that read, or while the copy it read was being kept in the folder's history, set the hold, and the save went on: it
+// wrote over the folder's copy and said "✅ Saved" with the hold on. The hold is now checked again after the read and after
+// the history copy, the last wait before the write. Here the board's first copy is saved and a note is typed; 💾 Save is held
+// at its read of the folder's copy, or at the close of its history copy; the import stops part-way there; the save is let
+// go. Take the pen from Alice is held the same way. The controls: the same holds with nothing happening there write and say
+// Saved, and once saving is allowed again 💾 Save writes the note.
+// FAILS ON 7ee498a (board fce8a391): every held save writes the folder's copy and says "✅ Saved" with the hold on; Take the
+// pen leaves Brad the writer and a line in the journal saying he took the pen.
+await (async () => {   // a function, not a bare block: see settleBoards() in boot.mjs
+  const __bm = bootMark();
+  const name = 'v2.00 (U4) — the folder save checks the mixed-import hold after its read and before its write';
+  try {
+    const { NEW, OLD } = w2Fx();
+    const { J, wire, KEY, status, folder, connect, gate, until, tick, pause } = W1H;
+    const turns = async n => { for (let i = 0; i < n; i++) await tick(); };
+    const stamp = ev => ev('JSON.stringify([MS.ts, MS.by])');      // the board's own stamp: the header's "Saved" time, and by whom
+    const pens = ev => +ev(`(MS.jrnl||[]).filter(function(e){ return e.p && e.p[0]==='(writer)'; }).length`);
+    const histNew = (fold, h0) => Object.keys((fold.root.dirs.history || { files: {} }).files).filter(n => !(n in h0)).map(n => fold.root.dirs.history.files[n]);
+    const hist0 = fold => Object.assign({}, (fold.root.dirs.history || { files: {} }).files);
+    // `at` 'read': the save's read of the folder's copy is held; 'hist': the close of its history copy.
+    const holdAt = (fold, NM, at) => { const g = gate(); let hit = () => (fold.hits.hist || 0) >= 1;
+      if (at === 'read') { const gh = fold.dir.getFileHandle; let n = 0;
+        fold.dir.getFileHandle = async (nm, o) => { if (!n && nm === NM && !(o && o.create)) { n = 1; await g.p; } return gh(nm, o); };
+        hit = () => n === 1; }
+      else fold.hold.hist = g;
+      return { g, hit }; };
+    const stop = (T) => { const r = w2Import(T, NEW.html, 'stuck', 8); wire(T.ev, 'brad', KEY.brad);   // w2Import answers yes to everything; this records the questions again
+      return J([r.ret, /could not be put back as it was/.test(r.stat), T.ev('String(impMixedOn())')]); };
+    for (const [at, withImport] of [['read', true], ['hist', true], ['read', false], ['hist', false]]) {
+      const where = (at === 'read' ? '💾 Save held at its read of the folder’s copy' : '💾 Save held at the close of its history copy')
+        + (withImport ? ', the import stops part-way there' : ' (a CONTROL: nothing happens there)');
+      const T = boot({ html: OLD.html, ls: OLD.ls }); await pause(80);
+      wire(T.ev, 'brad', KEY.brad);
+      const fold = folder(); connect(T.ev, T.w, fold);
+      const fy = +T.ev('MS.cur'), NM = 'spmt-' + fy + '-om.json';
+      await T.ev('saveInPlace()');
+      const v1 = fold.raw(fy);
+      T.ev(`setNote('A','EDIT-1'); 'ok'`); await pause(5);
+      const s0 = stamp(T.ev), h0 = hist0(fold), m0 = fold.hits.main || 0;
+      const { g, hit } = holdAt(fold, NM, at);
+      const p = T.ev('saveInPlace()');
+      const reached = await until(hit);
+      if (withImport) chk(name, where, 'the import stopped part-way, could not be put back, and the hold is on (a control)', stop(T), J([false, true, 'true']));
+      g.open(); await p; await turns(30);
+      if (!withImport) {
+        chk(name, where, 'the save writes the folder’s copy once, with the note, and says Saved',
+          J([reached, (fold.hits.main || 0) - m0, fold.note(fy, 'A'), /✅ Saved O&M FY27 to the shared folder/.test(status(T.ev))]), J([true, 1, 'EDIT-1', true]));
+        continue;
+      }
+      chk(name, where, 'nothing is written over the folder’s copy: it keeps its bytes', J([reached, (fold.hits.main || 0) - m0, fold.raw(fy) === v1]), J([true, 0, true]));
+      chk(name, where, at === 'read' ? 'nothing is kept in the history either: the save stopped before it' : 'the history keeps the folder’s copy as it was read, once',
+        J(histNew(fold, h0).map(t => t === v1)), J(at === 'read' ? [] : [true]));
+      chk(name, where, 'the board says writing to the shared folder is refused, and does not say Saved',
+        J([/Writing to the shared folder is refused/.test(status(T.ev)), /✅ Saved/.test(status(T.ev))]), J([true, false]));
+      chk(name, where, 'the note typed stays unsaved, and the board’s stamp is what it was before the save', J([T.ev('String(DIRTY)'), stamp(T.ev) === s0]), J(['true', true]));
+      if (at === 'read') {
+        T.ev(`globalThis.__yes=true; impMixedClear(); 'ok'`);
+        const m1 = fold.hits.main || 0; await T.ev('saveInPlace()');
+        chk(name, where, 'CONTROL — once saving is allowed again, 💾 Save writes the note and says Saved',
+          J([T.ev('String(impMixedOn())'), (fold.hits.main || 0) - m1, fold.note(fy, 'A'), /✅ Saved O&M FY27 to the shared folder/.test(status(T.ev))]), J(['false', 1, 'EDIT-1', true]));
+      }
+    }
+    // TAKE THE PEN FROM ALICE, held at the close of its history copy, the import stopping part-way there. Alice saves the
+    // folder's first copy (its writer); Brad's board loads it and takes the pen.
+    {
+      const where = 'Take the pen from Alice, held at the close of its history copy, the import stops part-way there';
+      const fold = folder();
+      const A = boot({ html: OLD.html, ls: OLD.ls }); await pause(80); wire(A.ev, 'Alice', KEY.alice); connect(A.ev, A.w, fold);
+      const fy = +A.ev('MS.cur');
+      A.ev(`setNote('A','ALICE-1'); 'ok'`); await pause(5); await A.ev('saveInPlace()');
+      const v1 = fold.raw(fy), writer = () => ((fold.copy(fy) || {}).writer || {}).by || '';
+      const T = boot({ html: OLD.html, ls: OLD.ls }); await pause(80); wire(T.ev, 'brad', KEY.brad); connect(T.ev, T.w, fold);
+      await T.ev('driveStorePull(false)');
+      chk(name, where, 'Alice holds the pen, and Brad’s board loaded her copy (a control)', J([writer(), T.ev(`String(S.notes.A||'')`)]), J(['Alice', 'ALICE-1']));
+      const s0 = stamp(T.ev), j0 = pens(T.ev), h0 = hist0(fold), m0 = fold.hits.main || 0;
+      const g = gate(); fold.hold.hist = g;
+      const p = T.ev('takePen()');
+      const reached = await until(() => (fold.hits.hist || 0) >= 1);
+      chk(name, where, 'the import stopped part-way, could not be put back, and the hold is on (a control)', stop(T), J([false, true, 'true']));
+      g.open(); await p; await turns(30);
+      chk(name, where, 'nothing is written: the folder’s copy keeps its bytes, and Alice still holds the pen',
+        J([reached, (fold.hits.main || 0) - m0, fold.raw(fy) === v1, writer()]), J([true, 0, true, 'Alice']));
+      chk(name, where, 'the journal does not say Brad took the pen, and the board’s stamp is what it was', J([pens(T.ev) - j0, stamp(T.ev) === s0]), J([0, true]));
+      chk(name, where, 'the board says writing to the shared folder is refused, and does not say Saved',
+        J([/Writing to the shared folder is refused/.test(status(T.ev)), /✅ Saved/.test(status(T.ev)), histNew(fold, h0).map(t => t === v1)]), J([true, false, [true]]));
+    }
+  } catch (e) {
+    failures.push({ scenario: name, where: 'harness', what: 'the block threw: ' + String((e && e.stack) || e).slice(0, 300), got: 'threw', want: 'ran' });
+  }
+  bootRelease(__bm, keepBoards());
+  await settleBoards();
+})();
+// ==== end v2.00 (U4) ====
 // ==== v2.00 (R5): a restore during a save stays unsaved ====
 // ↶ Put this back marked the board unsaved but did not count as a change. A folder save still writing when the copy was
 // put back found nothing changed while it wrote and marked the board saved: the earlier copy on screen, the save's copy in
```

### Commit 2 — U4: mutate.mjs (`diffs/c2-mutate.diff`, blob `57e28f8c`)

```diff
--- c1/tools/export-audit/mutate.mjs.txt	2026-10-13 04:25:11.041798733 +0000
+++ c2/tools/export-audit/mutate.mjs.txt	2026-10-13 04:25:11.077798735 +0000
@@ -4304,6 +4304,22 @@
   { id: "v200-u3-pen-reads-first", area: "takePen", what: "Take the pen under the hold reads the board file and asks whether to take the pen before its save is refused",
     find: "  if(impMixedBlock('Taking the pen')) return;   // v2.00 (U3): it saves; under the hold, refused before anything is read or asked\n",
     repl: "" },
+  // v2.00 (U4): the folder save checks the mixed-import hold after its read and before its write.
+  { id: "v200-u4-read-unchecked", area: "_driveStorePushRun", what: "the folder save no longer checks the hold after its read: an import that stopped part-way during the read is found only after the history copy is kept",
+    find: "  if(impMixedBlock('Writing to the shared folder', quiet)) return false;   // v2.00 (U4): after the read\n",
+    repl: "" },
+  { id: "v200-u4-hist-unchecked", area: "_driveStorePushRun", what: "the folder save no longer checks the hold after its history copy: an import that stopped part-way while the copy was kept does not stop the write, which says Saved",
+    find: "    if(impMixedOn()){\n      if(penLine) writerJournalUndo(penLine);\n",
+    repl: "    if(false){\n      if(penLine) writerJournalUndo(penLine);\n" },
+  { id: "v200-u4-stamp-moved", area: "_driveStorePushRun", what: "a folder save the hold stops after its history copy leaves the board stamped with the time and name of a save that did not happen",
+    find: "      if(MS.ts===wroteTs){ MS.ts=ts0; MS.by=by0; }\n",
+    repl: "" },
+  { id: "v200-u4-pen-line-kept", area: "_driveStorePushRun", what: "a Take the pen stopped by the hold after its history copy leaves the journal saying the pen was taken, though Alice still holds it",
+    find: "    if(impMixedOn()){\n      if(penLine) writerJournalUndo(penLine);\n",
+    repl: "    if(impMixedOn()){\n" },
+  { id: "v200-u4-hist-says-nothing", area: "_driveStorePushRun", what: "a folder save the hold stops after its history copy says nothing: the import's message stays, and nothing says the save was refused",
+    find: "      impMixedBlock('Writing to the shared folder', quiet); render(); return false;\n",
+    repl: "      render(); return false;\n" },
   // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.
   { id: "v200-r3-landed-view-unsaid", area: "_driveStorePushRun", what: "a folder save that lands while a locked view is on screen says “🔒 Not kept — PB27 is a locked view. ✅ Saved …” again, naming no plan (or, quiet, leaves persist's refusal on screen)",
     find: "  if(CYCVIEW){ _cycRefusedAt=0; setStat('✅ <b>Saved the working plan</b> of '+esc(APPN_LBL[ap]||ap)+' FY'+(fy%100)+' to the shared folder — '\n    +Math.round(body.length/1024)+' KB, built before '+blLbl(CYCVIEW)+' was put on screen. '+blLbl(CYCVIEW)+' is a locked view: nothing in it '\n    +'is saved. Everyone sees the working plan on their next refresh.'+penNote+lateNote); render(); return true; }\n",
```

## Decisions, with reasons, and the lead's six principles

**U3 — refuse at once at every way a save is asked for, not only the two the ledger named.** The ledger proposed
`saveInPlaceFile()` and `saveInPlace()` (the 💾 Save button, Take the pen). There are exactly four entry points into the
save queue (`saveSerial` callers): `saveInPlace`, `saveInPlaceFile`, `driveStorePush` (⬆ Publish now and the autosave) and
`driveResolve` (Save yours over theirs, Load theirs). The base probe shows the same queued-then-written path through
⬆ Publish now and Save yours over theirs (U3-publish, U3-resolve), so each gets the same one line; the finding is not closed
while any of them queues. `takePen` gets its own line as well: its question says "OK — take the pen and save now", and on
the base, under the hold, it read the board file again and asked that question first, and only then was its save queued
(probe U3-pen: read 2, asked 1). Each refusal uses the words its path already used (`saveInPlace` picks the folder's or the
board file's by `driveStoreOn()`; `driveResolve` keeps "Choosing between the copies", as its run says; `takePen` says
"Taking the pen", as its other refusals do), and the quiet autosave stays quiet. The checks at
the start of each run, and R4's after the read, are kept: a save asked for before the hold still meets them.

**U4 — check again after the read, and after the history copy, the last wait before the write.** The waits before the write
in `_driveStorePushRun` are `driveDir`, `driveStoreRead` and `snapKeep`. The first check covers the first two; the second
covers the history copy. The bytes are built between them, so an import stopping during the history copy leaves bytes with
no mix — the second check is there because the hold's contract is that nothing writes over the copy while the hold stands,
and because on the base that write said "✅ Saved" over the import's own message and its rescue buttons, and a Take the
pen held there took the pen. Stopped after the history copy, the save takes back its pen line (as the history failure just
above it does) and puts back the board's stamp, which the header shows as "Saved <time>" and by whom, unless something was
typed meanwhile (then the edit's stamp stands).

1. **Never lose any copy.** U3: the refused Save leaves the board file / the folder's copy as they were, with A's own write
   intact; nothing that was on screen is dropped. U4: the folder's copy keeps its bytes; the copy kept in the history before
   the refusal stays; the work stays on screen, unsaved (`DIRTY` true), and a Save once saving is allowed writes it
   (controls).
2. **Refuse or ask rather than guess.** Both refuse, with the hold's message and its buttons (save both copies; ⬇ Save a
   copy; allow saving again…). Nothing is queued to run later on a guess about what the person will decide.
3. **Money and exports.** No computation, money or export path is touched. The other suites (excel, ppt, other, recon,
   hostile, inject, boot-same, legacy) give the same results on c2 as on the base (below).
4. **Every word stays true, after it lands too.** U3: "⏳ … this one runs as soon as it finishes" was untrue under the hold;
   it is no longer said there. The refusal is the hold's own message, true while it stands. Take the pen no longer asks a
   question whose answer is then refused. U4: "✅ Saved" is no longer said when nothing should have been written; the header's
   saved time is not moved by a save that did not happen; the journal does not say the pen was taken.
5. **Smallest change.** U3: one line at each of five entry points (3 comment lines). U4: one line after the read, one line
   keeping the stamp, one five-line block before the write (6 comment lines).
6. **Existing checks preserved.** No existing check, fixture or expected value was edited; every change is an insertion.
   Every audit-import block that touches the changed paths (29 scenarios, listed below) gives the same checks, verdicts and
   values on base, c1 and c2. One shift in **which** check catches two existing mutations — not an edited expectation, but
   it must be said: `impmixed-file-unguarded` is no longer caught by R4b's before-file-access check
   (`audit-import.mjs`, R4b block, base lines 7023–7063: "refused before the file is touched: no permission request, no read,
   no open"; 5 checks fail there on the base), and `impmixed-folder-unguarded` no longer by the v1.95 hold block (base lines
   4373–4424) or the v1.99 batch hold block (base lines 6151–6228; one check each on the base). A Save asked for
   under the hold is now refused before its turn, so the check those mutations remove is reached only by a save asked for
   **before** the hold. Each is caught on c2 by exactly one check of the U3 block's "asked for before the hold" cases
   (below). R4b's and v1.95's checks still pass, with the same values.

**Kept from the earlier builders as built.** The c1 and c2 boards, blocks and entries above are the third builder's; the
fourth builder and I (the fifth) each read every line against the base and kept them unchanged (reasons above). Neither of
us changed anything in any copy.

## Tests

`audit-import.mjs`, inserted after `// ==== end v2.00 R4 ====` (the R4/R4b blocks' patterns: `await (async () => {`,
`bootMark()`, the two-space `const name`, `bootRelease(__bm, keepBoards())`, `settleBoards()`, the `// ==== …` markers):

- "v2.00 (U3) — a Save asked for during the mixed-import hold is refused at once, never queued": 47 checks (block lines
  7065–7197 in c1's suite).
- "v2.00 (U4) — the folder save checks the mixed-import hold after its read and before its write": 18 checks (block lines
  7198–7292 in c2's suite).

Expected values are hand-written literals (`'perm 1 · read 1 · open 1 · writes 1'`, `'OLD'`, `[2, 0, 0]`, `'EDIT-1'`,
`'Alice'`, the refusal words); board helpers are used only to observe.

**Focused runs** (`bin/mkfocused-multi.py`: the block, the suite's own imports, failure list, keepBoards, SEEN/chk and
scenario-ran guard, and the top-level helpers the block names, all verbatim; run by `bin/runner.mjs` against each copy's
own `boot.mjs`, `BOARD` unset and asserted):

| Run | Copy (board) | Harness | Checks | Fail | Exit | Start (ET) | Wall s |
|---|---|---|---|---|---|---|---|
| `f2-F-u3-base` | base (`fce8a391`) | F-u3 (`5080d131`) | 47 | 18 | 1 | 2026-10-13 00:22:35 EDT | 20.9 |
| `f2-F-u3-c1` | c1 (`82a2f1cc`) | F-u3 (`5080d131`) | 47 | 0 | 0 | 2026-10-13 00:22:56 EDT | 20.4 |
| `f2-F-u3-c2` | c2 (`4b755576`) | F-u3 (`5080d131`) | 47 | 0 | 0 | 2026-10-13 00:23:16 EDT | 22.7 |
| `f2-F-u4-base` | base (`fce8a391`) | F-u4 (`1f18a587`) | 18 | 10 | 1 | 2026-10-13 00:23:39 EDT | 17.0 |
| `f2-F-u4-c1` | c1 (`82a2f1cc`) | F-u4 (`1f18a587`) | 18 | 10 | 1 | 2026-10-13 00:23:56 EDT | 16.4 |
| `f2-F-u4-c2` | c2 (`4b755576`) | F-u4 (`1f18a587`) | 18 | 0 | 0 | 2026-10-13 00:24:13 EDT | 13.5 |
| `r1-F-u3-base` | base (`fce8a391`) | F-u3 (`5080d131`) | 47 | 18 | 1 | 2026-10-13 04:20:13 EDT | 28.0 |
| `r1-F-u3-c1` | c1 (`82a2f1cc`) | F-u3 (`5080d131`) | 47 | 0 | 0 | 2026-10-13 04:20:42 EDT | 22.7 |
| `r1-F-u3-c2` | c2 (`4b755576`) | F-u3 (`5080d131`) | 47 | 0 | 0 | 2026-10-13 04:21:04 EDT | 25.0 |
| `r1-F-u4-base` | base (`fce8a391`) | F-u4 (`1f18a587`) | 18 | 10 | 1 | 2026-10-13 04:21:29 EDT | 23.3 |
| `r1-F-u4-c1` | c1 (`82a2f1cc`) | F-u4 (`1f18a587`) | 18 | 10 | 1 | 2026-10-13 04:21:53 EDT | 20.6 |
| `r1-F-u4-c2` | c2 (`4b755576`) | F-u4 (`1f18a587`) | 18 | 0 | 0 | 2026-10-13 04:22:13 EDT | 17.4 |
| `r2-F-u3-base` | base (`fce8a391`) | F-u3 (`5080d131`) | 47 | 18 | 1 | 2026-10-13 09:16:54 EDT | 25.8 |
| `r2-F-u3-c2` | c2 (`4b755576`) | F-u3 (`5080d131`) | 47 | 0 | 0 | 2026-10-13 09:17:20 EDT | 14.1 |
| `r2-F-u4-base` | base (`fce8a391`) | F-u4 (`1f18a587`) | 18 | 10 | 1 | 2026-10-13 09:17:34 EDT | 12.0 |
| `r2-F-u4-c1` | c1 (`82a2f1cc`) | F-u4 (`1f18a587`) | 18 | 10 | 1 | 2026-10-13 09:17:46 EDT | 13.8 |
| `r2-F-u4-c2` | c2 (`4b755576`) | F-u4 (`1f18a587`) | 18 | 0 | 0 | 2026-10-13 09:18:00 EDT | 13.2 |

Failing checks on the base (the same on the first run `f2-*`, the re-run `r1-*` and the fifth builder's re-run `r2-*`):

- `r1-F-u3-base`:
  - the board file’s Save on the board file, with a save under way — refused at once: the request is over, nothing more is touched or asked, and it is not queued — got `[false,"perm 1 · read 1 · open 1 · writes 0",0,true]`
  - the board file’s Save on the board file, with a save under way — the board says saving to the board file is refused, and that nothing writes over the board file — got `false`
  - the board file’s Save on the board file, with a save under way — allowing saving again does not bring it back: A alone wrote, and the board file holds no imported plan — got `["perm 2 · read 2 · open 2 · writes 2","NEW"]`
  - 💾 Save on the board file, with a save under way — refused at once: the request is over, nothing more is touched or asked, and it is not queued — got `[false,"perm 1 · read 1 · open 1 · writes 0",0,true]`
  - 💾 Save on the board file, with a save under way — the board says saving to the board file is refused, and that nothing writes over the board file — got `false`
  - 💾 Save on the board file, with a save under way — allowing saving again does not bring it back: A alone wrote, and the board file holds no imported plan — got `["perm 2 · read 2 · open 2 · writes 2","NEW"]`
  - Take the pen on the board file, with a save under way — refused at once: the request is over, nothing more is touched or asked, and it is not queued — got `[false,"perm 1 · read 2 · open 1 · writes 0",1,true]`
  - Take the pen on the board file, with a save under way — the board says taking the pen is refused, and that nothing writes over the board file — got `false`
  - Take the pen on the board file, with a save under way — allowing saving again does not bring it back: A alone wrote, and the board file holds no imported plan — got `["perm 2 · read 3 · open 2 · writes 2","NEW"]`
  - 💾 Save working out of the shared folder, with a save under way — refused at once: the request is over, the folder’s copy is not read again, nothing is asked, and it is not queued — got `[false,0,0,true]`
  - 💾 Save working out of the shared folder, with a save under way — the board says writing to the shared folder is refused — got `false`
  - 💾 Save working out of the shared folder, with a save under way — allowing saving again does not bring it back: A alone wrote the folder’s copy, nothing more was read, nothing more kept in its history — got `[3,1,1]`
  - ⬆ Publish now working out of the shared folder, with a save under way — refused at once: the request is over, the folder’s copy is not read again, nothing is asked, and it is not queued — got `[false,0,0,true]`
  - ⬆ Publish now working out of the shared folder, with a save under way — the board says writing to the shared folder is refused — got `false`
  - ⬆ Publish now working out of the shared folder, with a save under way — allowing saving again does not bring it back: A alone wrote the folder’s copy, nothing more was read, nothing more kept in its history — got `[3,1,1]`
  - Save yours over theirs working out of the shared folder, with a save under way — refused at once: the request is over, the folder’s copy is not read again, nothing is asked, and it is not queued — got `[false,0,0,true]`
  - Save yours over theirs working out of the shared folder, with a save under way — the board says choosing between the copies is refused — got `false`
  - Save yours over theirs working out of the shared folder, with a save under way — allowing saving again does not bring it back: A alone wrote the folder’s copy, nothing more was read, nothing more kept in its history — got `[3,2,2]`
- `r1-F-u4-base`:
  - 💾 Save held at its read of the folder’s copy, the import stops part-way there — nothing is written over the folder’s copy: it keeps its bytes — got `[true,1,false]`
  - 💾 Save held at its read of the folder’s copy, the import stops part-way there — nothing is kept in the history either: the save stopped before it — got `[true]`
  - 💾 Save held at its read of the folder’s copy, the import stops part-way there — the board says writing to the shared folder is refused, and does not say Saved — got `[false,true]`
  - 💾 Save held at its read of the folder’s copy, the import stops part-way there — the note typed stays unsaved, and the board’s stamp is what it was before the save — got `["false",false]`
  - 💾 Save held at the close of its history copy, the import stops part-way there — nothing is written over the folder’s copy: it keeps its bytes — got `[true,1,false]`
  - 💾 Save held at the close of its history copy, the import stops part-way there — the board says writing to the shared folder is refused, and does not say Saved — got `[false,true]`
  - 💾 Save held at the close of its history copy, the import stops part-way there — the note typed stays unsaved, and the board’s stamp is what it was before the save — got `["true",false]`
  - Take the pen from Alice, held at the close of its history copy, the import stops part-way there — nothing is written: the folder’s copy keeps its bytes, and Alice still holds the pen — got `[true,1,false,"brad"]`
  - Take the pen from Alice, held at the close of its history copy, the import stops part-way there — the journal does not say Brad took the pen, and the board’s stamp is what it was — got `[1,false]`
  - Take the pen from Alice, held at the close of its history copy, the import stops part-way there — the board says writing to the shared folder is refused, and does not say Saved — got `[false,true,[true]]`

The fifth builder's re-runs after the 9:11 AM ET restart, check by check against `r1-*` (`out/*.checks.jsonl`):

| r1 run | r2 run (after the 9:11 AM restart) | checks / fail (r1) | checks / fail (r2) | same checks and verdicts | same values |
|---|---|---|---|---|---|
| `r1-F-u3-base` | `r2-F-u3-base` | 47 / 18 | 47 / 18 | yes | yes |
| `r1-F-u3-c2` | `r2-F-u3-c2` | 47 / 0 | 47 / 0 | yes | yes |
| `r1-F-u4-base` | `r2-F-u4-base` | 18 / 10 | 18 / 10 | yes | yes |
| `r1-F-u4-c1` | `r2-F-u4-c1` | 18 / 10 | 18 / 10 | yes | yes |
| `r1-F-u4-c2` | `r2-F-u4-c2` | 18 / 0 | 18 / 0 | yes | yes |

## Mutations

**New entries** (in each copy's `mutate.mjs.txt`, before the line `  // v2.00 (R3, Brad 11 Oct): a save that lands under a
locked view says it saved the working plan.`; ids `v200-u3-*`, `v200-u4-*`). Each find matches its board exactly once.
Mutant boards by `rec/bin/mkmut.py` (text only). U3 mutants were made from c1 (`m1-*`) and from c2 (`m2-*`, the same checks
and verdicts as `m1-*`); U4 mutants from c2 (`m3-*`). Each run against the block's focused harness:

| Mutation | From | Run | Board | Checks | Fail | Failing checks (case — check) |
|---|---|---|---|---|---|---|
| `v200-u3-file-queued` | c1 | `m1-v200-u3-file-queued` | `9a5406cb` | 47 | 3 | the board file’s Save on the board file, with a save under … — refused at once: the request is over, nothing more is touched or aske…; the board file’s Save on the board file, with a save under … — the board says saving to the board file is refused, and that nothing …; the board file’s Save on the board file, with a save under … — allowing saving again does not bring it back: A alone wrote, and the … |
| `v200-u3-pen-reads-first` | c1 | `m1-v200-u3-pen-reads-first` | `2096c023` | 47 | 3 | Take the pen on the board file, with a save under way — refused at once: the request is over, nothing more is touched or aske…; Take the pen on the board file, with a save under way — the board says taking the pen is refused, and that nothing writes ove…; Take the pen on the board file, with a save under way — allowing saving again does not bring it back: A alone wrote, and the … |
| `v200-u3-publish-queued` | c1 | `m1-v200-u3-publish-queued` | `41f8cb37` | 47 | 3 | ⬆ Publish now working out of the shared folder, with a save… — refused at once: the request is over, the folder’s copy is not read a…; ⬆ Publish now working out of the shared folder, with a save… — the board says writing to the shared folder is refused; ⬆ Publish now working out of the shared folder, with a save… — allowing saving again does not bring it back: A alone wrote the folde… |
| `v200-u3-resolve-queued` | c1 | `m1-v200-u3-resolve-queued` | `5e05f7e2` | 47 | 3 | Save yours over theirs working out of the shared folder, wi… — refused at once: the request is over, the folder’s copy is not read a…; Save yours over theirs working out of the shared folder, wi… — the board says choosing between the copies is refused; Save yours over theirs working out of the shared folder, wi… — allowing saving again does not bring it back: A alone wrote the folde… |
| `v200-u3-save-file-words` | c1 | `m1-v200-u3-save-file-words` | `6e6e0a06` | 47 | 1 | 💾 Save working out of the shared folder, with a save under … — the board says writing to the shared folder is refused |
| `v200-u3-save-queued` | c1 | `m1-v200-u3-save-queued` | `968f3195` | 47 | 6 | 💾 Save on the board file, with a save under way — refused at once: the request is over, nothing more is touched or aske…; 💾 Save on the board file, with a save under way — the board says saving to the board file is refused, and that nothing …; 💾 Save on the board file, with a save under way — allowing saving again does not bring it back: A alone wrote, and the …; 💾 Save working out of the shared folder, with a save under … — refused at once: the request is over, the folder’s copy is not read a…; 💾 Save working out of the shared folder, with a save under … — the board says writing to the shared folder is refused; 💾 Save working out of the shared folder, with a save under … — allowing saving again does not bring it back: A alone wrote the folde… |
| `v200-u3-file-queued` | c2 | `m2-v200-u3-file-queued` | `0f4ac05c` | 47 | 3 | (same checks and verdicts as m1) |
| `v200-u3-pen-reads-first` | c2 | `m2-v200-u3-pen-reads-first` | `8da041a8` | 47 | 3 | (same checks and verdicts as m1) |
| `v200-u3-publish-queued` | c2 | `m2-v200-u3-publish-queued` | `7ebb6205` | 47 | 3 | (same checks and verdicts as m1) |
| `v200-u3-resolve-queued` | c2 | `m2-v200-u3-resolve-queued` | `c91813a3` | 47 | 3 | (same checks and verdicts as m1) |
| `v200-u3-save-file-words` | c2 | `m2-v200-u3-save-file-words` | `4f8418fe` | 47 | 1 | (same checks and verdicts as m1) |
| `v200-u3-save-queued` | c2 | `m2-v200-u3-save-queued` | `f8f1353e` | 47 | 6 | (same checks and verdicts as m1) |
| `v200-u4-hist-says-nothing` | c2 | `m3-v200-u4-hist-says-nothing` | `b34356df` | 18 | 2 | 💾 Save held at the close of its history copy, the import st… — the board says writing to the shared folder is refused, and does not …; Take the pen from Alice, held at the close of its history c… — the board says writing to the shared folder is refused, and does not … |
| `v200-u4-hist-unchecked` | c2 | `m3-v200-u4-hist-unchecked` | `819706c5` | 18 | 6 | 💾 Save held at the close of its history copy, the import st… — nothing is written over the folder’s copy: it keeps its bytes; 💾 Save held at the close of its history copy, the import st… — the board says writing to the shared folder is refused, and does not …; 💾 Save held at the close of its history copy, the import st… — the note typed stays unsaved, and the board’s stamp is what it was be…; Take the pen from Alice, held at the close of its history c… — nothing is written: the folder’s copy keeps its bytes, and Alice stil…; Take the pen from Alice, held at the close of its history c… — the journal does not say Brad took the pen, and the board’s stamp is …; Take the pen from Alice, held at the close of its history c… — the board says writing to the shared folder is refused, and does not … |
| `v200-u4-pen-line-kept` | c2 | `m3-v200-u4-pen-line-kept` | `ad20429f` | 18 | 1 | Take the pen from Alice, held at the close of its history c… — the journal does not say Brad took the pen, and the board’s stamp is … |
| `v200-u4-read-unchecked` | c2 | `m3-v200-u4-read-unchecked` | `6fda3925` | 18 | 1 | 💾 Save held at its read of the folder’s copy, the import st… — nothing is kept in the history either: the save stopped before it |
| `v200-u4-stamp-moved` | c2 | `m3-v200-u4-stamp-moved` | `60ecb1d9` | 18 | 2 | 💾 Save held at the close of its history copy, the import st… — the note typed stays unsaved, and the board’s stamp is what it was be…; Take the pen from Alice, held at the close of its history c… — the journal does not say Brad took the pen, and the board’s stamp is … |

**Existing hold mutations on the final copy c2** (against `F-liteall`: the v1.95 hold, the lifting of the hold, the v1.99
batch hold, R4/R4b, U3 and U4, all verbatim), and the two whose catching moved, on the base (against `F-litepre`, the same
blocks without U3/U4). `saves-not-serial` was also run against `F-folderA` (the v1.95 "Save acknowledges exactly what it
wrote" blocks, verbatim) on c2 (`x10`, the fourth builder) and on the base (`x11`, mine), to see whether the blocks that catch
it are the same on both:

| Mutation | Copy | Run | Harness | Checks | Fail | Exit | Failing checks (scenario — case — check) |
|---|---|---|---|---|---|---|---|
| `impmixed-file-unguarded` | c2 | `x1-c2-impmixed-file-unguarded` | `18ba5094` | 123 | 1 | 1 | v2.00 (U3) — the board file’s Save asked for before the hold, … — refused when its turn comes, before the file is touched: A … |
| `impmixed-folder-unguarded` | c2 | `x2-c2-impmixed-folder-unguarded` | `18ba5094` | 123 | 1 | 1 | v2.00 (U3) — 💾 Save working out of the shared folder, asked fo… — refused when its turn comes, before the folder’s copy is re… |
| `impmixed-not-marked` | c2 | `x3-c2-impmixed-not-marked` | `18ba5094` | 123 | 57 | 1 | v1.95 — 💾 Save to the board file — refused: the file is not written, and the message says why …; v1.95 — 💾 Save to the shared folder — refused, the autosave included: nothing is written in the f…; v2.00 (R4) — the import stops part-way during the read — the import stopped part-way, could not be put back, and the…; v2.00 (R4) — the import stops part-way during the read — nothing is written: the file is never opened for writing; … (53 more) |
| `impmixed-clear-unasked` | c2 | `x4-c2-impmixed-clear-unasked` | `18ba5094` | 123 | 2 | 1 | v1.95 — allow saving again — declined: still refused, the mark kept; v1.95 — allow saving again — the question says the next save writes the mix over the boa… |
| `impmixed-not-kept` | c2 | `x4-c2-impmixed-not-kept` | `18ba5094` | 123 | 7 | 1 | v1.95 — reloaded — the mark is kept in browser storage; v1.95 — reloaded — the opening message says what happened and that nothing wri…; v1.95 — reloaded — 💾 Save is still refused; the board file is not written; v1.95 — allow saving again — declined: still refused, the mark kept; … (3 more) |
| `impmixed-boot-silent` | c2 | `x5-c2-impmixed-boot-silent` | `18ba5094` | 123 | 1 | 1 | v1.95 — reloaded — the opening message says what happened and that nothing wri… |
| `impmixed-never-lifted` | c2 | `x5-c2-impmixed-never-lifted` | `18ba5094` | 123 | 2 | 1 | v1.95 — the whole of it — importing the whole file again lifts the hold; v1.95 — the whole of it — reopened: 💾 Save is allowed, and the opening says what was … |
| `impmixed-lift-partial` | c2 | `x6-c2-impmixed-lift-partial` | `18ba5094` | 123 | 1 | 1 | v1.95 — part of it — an import that rewrites only some of those lists leaves the… |
| `v200-r4-no-recheck` | c2 | `x6-c2-v200-r4-no-recheck` | `18ba5094` | 123 | 3 | 1 | v2.00 (R4) — the import stops part-way during the read — nothing is written: the file is never opened for writing; v2.00 (R4) — the import stops part-way during the read — the board file keeps its bytes; v2.00 (R4) — the import stops part-way during the read — the board says the save is refused, and that nothing writes… |
| `v200-r4-held-quietly` | c2 | `x7-c2-v200-r4-held-quietly` | `18ba5094` | 123 | 1 | 1 | v2.00 (R4) — the import stops part-way during the read — the board says the save is refused, and that nothing writes… |
| `v200-r4-said-not-held` | c2 | `x7-c2-v200-r4-said-not-held` | `18ba5094` | 123 | 3 | 1 | v2.00 (R4) — the import stops part-way during the read — nothing is written: the file is never opened for writing; v2.00 (R4) — the import stops part-way during the read — the board file keeps its bytes; v2.00 (R4) — the import stops part-way during the read — the board says the save is refused, and that nothing writes… |
| `impmixed-file-unguarded` | base | `x8-base-impmixed-file-unguarded` | `70dd33c9` | 58 | 5 | 1 | v2.00 (R4b) — hold on, read not held — refused before the file is touched: no permission request, …; v2.00 (R4b) — hold on, cleared after the refusal (a held read i… — refused before the file is touched: no permission request, …; v2.00 (R4b) — hold on, cleared after the refusal (a held read i… — Save is refused at once: the request is over, and the board…; v2.00 (R4b) — hold on, cleared after the refusal (a held read i… — clearing the hold does not bring the refused Save back: not…; … (1 more) |
| `saves-not-serial` | c2 | `x8-c2-saves-not-serial` | `18ba5094` | 123 | 5 | 1 | v2.00 (U3) — CONTROL — no hold: the board file’s Save, with a … — B waits its turn, and the board says so; v2.00 (U3) — the board file’s Save asked for before the hold, … — B waits its turn (a control); v2.00 (U3) — the board file’s Save asked for before the hold, … — refused when its turn comes, before the file is touched: A …; v2.00 (U3) — 💾 Save working out of the shared folder, asked fo… — B waits its turn (a control); … (1 more) |
| `impmixed-folder-unguarded` | base | `x9-base-impmixed-folder-unguarded` | `70dd33c9` | 58 | 2 | 1 | v1.95 — 💾 Save to the shared folder — refused, the autosave included: nothing is written in the f…; v1.99 — held: 💾 Save to the shared folder — refused, the autosave included: nothing is written in the f… |
| `saves-not-serial` | c2 | `x10-c2-saves-not-serial` | `c0b31acd` | 297 | 5 | 1 | v1.95 — two saves — the second does not start while the first is writing; v1.95 — two saves — the file ends with the latest state, saved, and records the…; v1.95 — a queued save — it never runs for FY28: FY28’s copy is untouched, and the b…; v1.95 — autosave and Save — the Save waits for the autosave; … (1 more) |
| `saves-not-serial` | base | `x11-base-saves-not-serial` | `c0b31acd` | 297 | 5 | 1 | v1.95 — two saves — the second does not start while the first is writing; v1.95 — two saves — the file ends with the latest state, saved, and records the…; v1.95 — a queued save — it never runs for FY28: FY28’s copy is untouched, and the b…; v1.95 — autosave and Save — the Save waits for the autosave; … (1 more) |

`x11-base-saves-not-serial` (297 checks, 5 fail) and `x10-c2-saves-not-serial` (297 checks, 5 fail): the same failing checks, with the same values:
  - v1.95 — Save acknowledges exactly what it wrote (the file) — two saves — the second does not start while the first is writing — got `"2"`
  - v1.95 — Save acknowledges exactly what it wrote (the file) — two saves — the file ends with the latest state, saved, and records the copy it wrote — got `"ONE|false|true|2"`
  - v1.95 — Save acknowledges exactly what it wrote (the shared folder) — a queued save — it never runs for FY28: FY28’s copy is untouched, and the board says so — got `"true|false"`
  - v1.95 — Save acknowledges exactly what it wrote (the shared folder) — autosave and Save — the Save waits for the autosave — got `"3"`
  - v1.95 — Save acknowledges exactly what it wrote (the shared folder) — autosave and Save — the folder ends with the latest state, saved — got `"ONE|false"`

**The other existing entries on these paths.** `bin/exsweep.py` (text only, `rec/bin/mcread.py`) lists 47 entries whose find
lands in `saveInPlace`, `saveInPlaceFile`, `_saveInPlaceFileRun`, `driveStorePush`, `_driveStorePushRun`, `driveResolve`,
`_driveResolveRun`, `takePen`, `saveSerial` or `impMixedClear`, or that name the hold (`out/exsweep-c2.txt`): the 11 new ones,
9 of the 12 existing hold mutations above (`impmixed-not-marked`, `-not-kept` and `-lift-partial` change the hold's code
elsewhere), and 27 others (the file save's guards and acknowledgements, the folder save's history, writer, year and base,
Save yours over theirs' forced copy, R3's locked view; listed in that file). Those 27 were not run here. U3's and U4's lines change nothing unless the hold is
on (`impMixedBlock` returns false and `impMixedOn()` is false), so in every scenario that never sets the hold a mutant of
c2 behaves as the same mutant of the base; only a scenario that sets the hold could catch one differently, and those
scenarios are the hold blocks above. Full-suite sensitivity is the lead's run.

**mcount** (`rec/bin/mcount.py`, text only; `out/mcount/*.json`): base 1328 entries, 1328 once; c1 1334, 1334 once; c2 1339,
1339 once; none missing, none multiple, none unparsed. `mutate.mjs` was never imported, executed or run.

## Existing checks: every audit-import block on the changed paths

`bin/scnmap.py` lists the 29 scenarios in c2's audit-import that name `saveInPlace()`, `saveInPlaceFile`,
`driveStorePush`, `driveResolve`, `takePen`, `liveTick`/`livePublish` or set the hold. Each is in one of these harnesses
(verbatim from the suite): `F-folderA` (11 blocks), `F-folderB` (10), `F-hold` (3), `F-nr02` (1), `F-u2` (2), `F-u13` (1),
plus U3 and U4. `F-holdpre`/`F-holdall` and `F-litepre`/`F-liteall` are the hold blocks without/with U3 and U4.

| Harness | base run: checks / fail | c1 run: checks / fail | c2 run: checks / fail | same checks, verdicts, values |
|---|---|---|---|---|
| F-folderA | `g6-F-folderA-base` 297 / 0 (exit 0) | `g9-F-folderA-c1` 297 / 0 (exit 0) | `g2-F-folderA-c2` 297 / 0 (exit 0) | base=c1: yes; base=c2: yes |
| F-folderB | `g5-F-folderB-base` 142 / 0 (exit 0) | `g8-F-folderB-c1` 142 / 0 (exit 0) | `g1-F-folderB-c2` 142 / 0 (exit 0) | base=c1: yes; base=c2: yes |
| F-hold | `g7-F-hold-base` 139 / 0 (exit 0) | `g9-F-hold-c1` 139 / 0 (exit 0) | `g3-F-hold-c2` 139 / 0 (exit 0) | base=c1: yes; base=c2: yes |
| F-nr02 | `g6-F-nr02-base` 3 / 0 (exit 0) | `g9-F-nr02-c1` 3 / 0 (exit 0) | `g2-F-nr02-c2` 3 / 0 (exit 0) | base=c1: yes; base=c2: yes |
| F-u2 | `g7-F-u2-base` 57 / 0 (exit 0) | `g10-F-u2-c1` 57 / 0 (exit 0) | `g3-F-u2-c2` 57 / 0 (exit 0) | base=c1: yes; base=c2: yes |
| F-u13 | `g7-F-u13-base` 71 / 0 (exit 0) | `g10-F-u13-c1` 71 / 0 (exit 0) | `g3-F-u13-c2` 71 / 0 (exit 0) | base=c1: yes; base=c2: yes |
| F-holdpre | `f3-F-holdpre-base` 205 / 0 | — | `f3-F-holdpre-c2` 205 / 0 | base=c2: yes |
| F-holdall (holdpre + U3 + U4) | — | — | `g4-F-holdall-c2` 270 / 0 | its 205 non-U3/U4 checks = holdpre's on c2 |
| F-litepre / F-liteall | `f4-F-litepre-base` 58 / 0 | — | `f4-F-liteall-c2` 123 / 0 | liteall's 58 non-U3/U4 checks = litepre's on base |

## Other suites and `npm run check`

Run in scratch clones (`git clone --shared --no-checkout /home/user/orbit-board`, then `git checkout --detach 7ee498a`; the
copy's board, audit-import and mutate copied over; `node_modules` linked; nothing committed): `clones/base`, `clones/c1`,
`clones/c2` (c1's clone was made and not used: the suites were compared on the final copy, c2, against the base).
`orbit-board` HEAD was `674b6c5` then (`f40eded` at 9:13 AM ET); each differs from `7ee498a` only under `recovery/` (board,
suites, mutate, package.json and NEXT-VERSION.md blobs equal), so `7ee498a` was checked out. audit-import and audit-board were not run in
full (the lead runs those alone).

| Suite | base clone | c2 clone | same result |
|---|---|---|---|
| boot-same | exit 0, 10.5 s: same  prioritization-board-grid.html a published PMO copy parse 1304 ms · fast 436 ms / every page, source, save and er… | exit 0, 7.1 s: same  prioritization-board-grid.html a published PMO copy parse 858 ms · fast 227 ms / every page, source, save and err… | yes |
| audit | exit 0, 9.5 s: ALL CHECKS PASSED | exit 0, 6.0 s: ALL CHECKS PASSED | yes |
| audit-ppt | exit 0, 4.8 s: ALL CHECKS PASSED | exit 0, 3.2 s: ALL CHECKS PASSED | yes |
| audit-other | exit 0, 27.2 s: ALL CHECKS PASSED | exit 0, 30.8 s: ALL CHECKS PASSED | yes |
| audit-recon | exit 0, 77.8 s: ALL CHECKS PASSED | exit 0, 151.4 s: ALL CHECKS PASSED | yes |
| legacy-fsrc | exit 0, 2.0 s:   ok   legacy fsrc 'ufr' still honoured — all unfunded (d 0 · m 0 · u 60) /   every legacy Force setting computes exact… | exit 0, 2.2 s:   ok   legacy fsrc 'ufr' still honoured — all unfunded (d 0 · m 0 · u 60) /   every legacy Force setting computes exact… | yes |
| audit-hostile | exit 0, 66.1 s: ALL CHECKS PASSED | exit 0, 77.6 s: ALL CHECKS PASSED | yes |
| audit-inject | exit 0, 7.8 s: ALL CHECKS PASSED | exit 0, 9.4 s: ALL CHECKS PASSED | yes |
| npm-check | exit 0, 2.5 s: all checks passed | exit 0, 3.2 s: all checks passed | yes |

## Overlap with U18 (built separately on the same base)

U18's builder (`rec/L6/u18`, board `e3986f30`) changes the same lines of `_driveStorePushRun`: it keeps the stamp
(`const was={ts:MS.ts, by:MS.by};`) before `MS.ts=Date.now()`, and re-reads the folder's copy after the history copy, just
before `await driveWrite(...)`. Whichever is committed second will not apply cleanly. Merged, the order must be: history
copy → U18's re-read and comparison → U4's hold check → `driveWrite`, because U18's re-read is then the last wait before the
write; and the two stamp put-backs become one (`ts0/by0` or `was`). Each block's checks should then be run again on the
merged board. This track did not build or test the merge.

Near, not the same lines (checked by the fifth builder, 13 Oct, against each track's latest copy in `rec/L6/`): the adoption
track (`adopt/c3`, U29) and the U20/U30 track (`u20u30/c2`, U30) change `driveClashSay`'s message (base lines 26956–26961),
which ends about eight lines above `driveResolve`, where U3 adds a line (base line 26971). The hunks do not share or touch a
line, so each should apply on top of the other; the lead's commit check is what shows it. U20/U30's change at base lines
6492–6502 is in `saveSerial`'s neighbourhood (base line 6494), which U3 does not change.

## Not covered, and what was not done

- **A save already running when the hold comes** still lands and says "Saved": the board file's write after R4's re-check
  (`createWritable`/`write`/`close`), and the folder's `driveWrite` itself. Their bytes were built before the import, so
  they carry no mix, but the "Saved" line replaces the import's message (the hold's own message comes back on the next
  refused Save). The probes show it (c1/c2 U3-file: A's "💾 Saved in place … A change made while it was saving is not in the
  file yet" after B's refusal). Not proposed here: outside U3/U4 as written; the lead decides.
- **Load theirs** (`_driveResolveRun`, `'theirs'`) checks the hold only at its start; a hold set during its read was not
  examined.
- **Save yours over theirs, then a refusal:** by code (not run), `_driveResolveRun('mine')` records their copy as the base
  before calling the save; if the hold (or anything else) then stops the save, a 💾 Save once saving is allowed writes over
  their copy without asking again — as the person chose, with theirs kept in the folder's history.
- **Take the pen with the hold coming during its read or its question:** U3 checks the hold before Take the pen reads
  anything; a hold that comes while it reads the file or the folder's copy, or while its question is open, meets the U3
  check in `saveInPlace()` after the answer — refused at once, with the hold's message, after the question was asked. Not
  run.
- **One extra history copy:** a save the hold stops after its history copy leaves that copy (the folder's own copy) in the
  history until the next save that lands thins it.
- A save waiting for another tab's Web Lock (U20) is not changed. The hold is seen in another tab only when its mark could
  be kept in browser storage (a stopped import whose storage refused the mark holds this page only, as before).
- Not run: the full `audit-import.mjs` and `audit-board.mjs` (the lead's); `mutate.mjs` (never imported, executed or run;
  read as text only); any Chromium/playwright tool (none needed: no layout or UI surface changed); `playwright install`
  (never).
- Not run by the fifth builder: the other suites and `npm run check` again (the fourth builder's `S-*` runs at 5:49–5:59 AM
  ET are on the same files: the copies' blobs are unchanged since); the mutants `m1-*`/`m2-*`/`m3-*` and the regression
  harnesses `g*` again (same files, complete logs with exit records); the 27 other existing entries above.
- Not done: the U18 merge; any commit, stage or push; any edit in `/home/user/orbit-board` or `/home/user/orbit-ui`.

## Drafts (for the lead)

- `drafts/NEXT-VERSION-U3.md` — the U3 entry (commit 1).
- `drafts/NEXT-VERSION-U4.md` — the U4 entry (commit 2).
- `drafts/LEDGER-and-UNRESOLVED.md` — the text to append to the U3 and U4 ledger rows (with `<sha1>`/`<time1>`,
  `<sha2>`/`<time2>`; wrapped to read, and as one line to paste, since a table cell holds no line break), the exact
  replacement lines for "Unresolved after R1–R5" (leading spaces included), and an optional line to add under R4b's
  "Tracked, not changed" bullet.

Blobs (`git hash-object`) of the drafts as handed over: `drafts/NEXT-VERSION-U3.md` `ed0ce151`, `drafts/NEXT-VERSION-U4.md` `b9fd59f5`, `drafts/LEDGER-and-UNRESOLVED.md` `0bb2442a`.

## Files

- `c1/`, `c2/` — the cumulative copies (base + U3; base + U3 + U4). `diffs/` — their diffs. `blocks/` — the suite blocks
  and mutation entries as text. `probe/` — the reproduction. `harness/` (and `h/<copy>/tools/export-audit/`) — the focused
  harnesses. `mut/` — the mutant boards. `out/` — probe records, per-check records (`*.checks.jsonl`, rows
  `[scenario, case, check, passed, got]`), summaries, mcount. `logs/` — every run's log (`# start`, `# end … exit … wall_s`),
  `runs.txt`, `bx.txt`. `clones/` — the scratch clones. `chk/` — the fourth builder's rebuild checks; `chk5/` — the fifth
  builder's re-derived diffs. `bin/` — every script used.

## Every run

All node runs through `bin/run.sh` (`setsid -w timeout -k 10 600`, the `AUDIT_IMPORT_RUNNING` lock checked before each
start — it was never present during the fourth or the fifth builder's runs — `BOARD` and `MUT_FIRST_FAIL` unset); other
bounded commands through `bin/bx.sh`. The third builder's runs (before 4:11 AM ET) are listed as recorded; the fourth
builder's follow the first "resumed" line in `runs.txt`, and mine (the fifth) the second. In `bx.txt` the first three lines
(`mkmuts`, `mkharness2`, `mkharness3`) are the third builder's, then the fourth builder's, then mine after the "resumed"
line. My first text checks (the copies' `diff -rq`, the re-derived diffs into `chk5/`, `git hash-object`, `bin/exsweep.py`'s
first run, `grep`/`sed` reads, the edits to the drafts and this README's source) were run directly in the shell, each done
in a few seconds; `exsweep` and `mkreadme` were then run again through `bx.sh` (in `bx.txt`). My r2 batch (`r2-*` and
`x11`) was started through `bin/batch.sh` directly, not inside `bin/bx.sh` as the fourth
builder's batches were: each run in it was bounded by `run.sh` (600 s), but the wrapper itself had no 600 s bound of its own
(its PID, 2317, is in `pids.txt`; it ended at 9:19:54 AM ET after 3 min).

| Label | Start (ET) | Exit | Wall s | Log |
|---|---|---|---|---|
| # runs.txt for rec/L6/hold | | | | |
| `probe-base-U3-file` | 2026-10-13 00:11:28 EDT | 0 | 8.9 | `logs/probe-base-U3-file.log`  |
| `probe-base-C3-file` | 2026-10-13 00:11:37 EDT | 0 | 9.1 | `logs/probe-base-C3-file.log`  |
| `probe-base-C3-idle` | 2026-10-13 00:11:47 EDT | 0 | 8.9 | `logs/probe-base-C3-idle.log`  |
| `probe-base-U3-save` | 2026-10-13 00:12:04 EDT | 0 | 8.5 | `logs/probe-base-U3-save.log`  |
| `probe-base-U3-pen` | 2026-10-13 00:12:12 EDT | 0 | 10.0 | `logs/probe-base-U3-pen.log`  |
| `probe-base-U3-folder` | 2026-10-13 00:12:22 EDT | 0 | 9.7 | `logs/probe-base-U3-folder.log`  |
| `probe-base-U3-publish` | 2026-10-13 00:12:32 EDT | 0 | 12.0 | `logs/probe-base-U3-publish.log`  |
| `probe-base-U3-resolve` | 2026-10-13 00:12:44 EDT | 0 | 9.5 | `logs/probe-base-U3-resolve.log`  |
| `probe-base-U4-read` | 2026-10-13 00:12:54 EDT | 0 | 11.0 | `logs/probe-base-U4-read.log`  |
| `probe-base-U4-hist` | 2026-10-13 00:13:05 EDT | 0 | 9.8 | `logs/probe-base-U4-hist.log`  |
| `probe-base-U4-pen` | 2026-10-13 00:13:15 EDT | 0 | 10.1 | `logs/probe-base-U4-pen.log`  |
| `probe-base-C4-read` | 2026-10-13 00:13:25 EDT | 0 | 8.9 | `logs/probe-base-C4-read.log`  |
| `probe-base-C4-retry` | 2026-10-13 00:13:34 EDT | 0 | 11.9 | `logs/probe-base-C4-retry.log`  |
| `probe-c1-U3-file` | 2026-10-13 00:16:03 EDT | 0 | 9.1 | `logs/probe-c1-U3-file.log`  |
| `probe-c1-U3-save` | 2026-10-13 00:16:12 EDT | 0 | 10.4 | `logs/probe-c1-U3-save.log`  |
| `probe-c1-U3-pen` | 2026-10-13 00:16:22 EDT | 0 | 10.4 | `logs/probe-c1-U3-pen.log`  |
| `probe-c1-U3-folder` | 2026-10-13 00:16:33 EDT | 0 | 11.5 | `logs/probe-c1-U3-folder.log`  |
| `probe-c1-U3-publish` | 2026-10-13 00:16:44 EDT | 0 | 11.4 | `logs/probe-c1-U3-publish.log`  |
| `probe-c1-U3-resolve` | 2026-10-13 00:16:56 EDT | 0 | 12.0 | `logs/probe-c1-U3-resolve.log`  |
| `probe-c1-C3-file` | 2026-10-13 00:17:08 EDT | 0 | 10.6 | `logs/probe-c1-C3-file.log`  |
| `probe-c1-C3-idle` | 2026-10-13 00:17:18 EDT | 0 | 10.8 | `logs/probe-c1-C3-idle.log`  |
| `probe-c1-U4-read` | 2026-10-13 00:17:29 EDT | 0 | 10.1 | `logs/probe-c1-U4-read.log`  |
| `probe-c1-U4-hist` | 2026-10-13 00:17:39 EDT | 0 | 11.4 | `logs/probe-c1-U4-hist.log`  |
| `probe-c1-U4-pen` | 2026-10-13 00:17:51 EDT | 0 | 11.8 | `logs/probe-c1-U4-pen.log`  |
| `probe-c1-C4-read` | 2026-10-13 00:18:03 EDT | 0 | 11.6 | `logs/probe-c1-C4-read.log`  |
| `probe-c1-C4-retry` | 2026-10-13 00:18:14 EDT | 0 | 12.1 | `logs/probe-c1-C4-retry.log`  |
| `probe-c2-U3-file` | 2026-10-13 00:18:27 EDT | 0 | 9.9 | `logs/probe-c2-U3-file.log`  |
| `probe-c2-U3-save` | 2026-10-13 00:18:37 EDT | 0 | 12.7 | `logs/probe-c2-U3-save.log`  |
| `probe-c2-U3-pen` | 2026-10-13 00:18:49 EDT | 0 | 10.6 | `logs/probe-c2-U3-pen.log`  |
| `probe-c2-U3-folder` | 2026-10-13 00:19:00 EDT | 0 | 10.3 | `logs/probe-c2-U3-folder.log`  |
| `probe-c2-U3-publish` | 2026-10-13 00:19:10 EDT | 0 | 13.0 | `logs/probe-c2-U3-publish.log`  |
| `probe-c2-U3-resolve` | 2026-10-13 00:19:23 EDT | 0 | 14.0 | `logs/probe-c2-U3-resolve.log`  |
| `probe-c2-C3-file` | 2026-10-13 00:19:37 EDT | 0 | 10.9 | `logs/probe-c2-C3-file.log`  |
| `probe-c2-C3-idle` | 2026-10-13 00:19:48 EDT | 0 | 11.0 | `logs/probe-c2-C3-idle.log`  |
| `probe-c2-U4-read` | 2026-10-13 00:19:59 EDT | 0 | 12.6 | `logs/probe-c2-U4-read.log`  |
| `probe-c2-U4-hist` | 2026-10-13 00:20:12 EDT | 0 | 11.7 | `logs/probe-c2-U4-hist.log`  |
| `probe-c2-U4-pen` | 2026-10-13 00:20:24 EDT | 0 | 12.0 | `logs/probe-c2-U4-pen.log`  |
| `probe-c2-C4-read` | 2026-10-13 00:20:36 EDT | 0 | 10.2 | `logs/probe-c2-C4-read.log`  |
| `probe-c2-C4-retry` | 2026-10-13 00:20:46 EDT | 0 | 11.2 | `logs/probe-c2-C4-retry.log`  |
| `f1-F-u3-base` | 2026-10-13 00:22:10 EDT | 1 | 1.5 | `logs/f1-F-u3-base.log`  |
| `f1-F-u3-c1` | 2026-10-13 00:22:12 EDT | 1 | 1.1 | `logs/f1-F-u3-c1.log`  |
| `f1-F-u3-c2` | 2026-10-13 00:22:13 EDT | 1 | 1.4 | `logs/f1-F-u3-c2.log`  |
| `f1-F-u4-base` | 2026-10-13 00:22:15 EDT | 1 | 1.0 | `logs/f1-F-u4-base.log`  |
| `f1-F-u4-c1` | 2026-10-13 00:22:16 EDT | 1 | 1.4 | `logs/f1-F-u4-c1.log`  |
| `f1-F-u4-c2` | 2026-10-13 00:22:17 EDT | 1 | 1.6 | `logs/f1-F-u4-c2.log`  |
| `f2-F-u3-base` | 2026-10-13 00:22:35 EDT | 1 | 20.9 | `logs/f2-F-u3-base.log`  |
| `f2-F-u3-c1` | 2026-10-13 00:22:56 EDT | 0 | 20.4 | `logs/f2-F-u3-c1.log`  |
| `f2-F-u3-c2` | 2026-10-13 00:23:16 EDT | 0 | 22.7 | `logs/f2-F-u3-c2.log`  |
| `f2-F-u4-base` | 2026-10-13 00:23:39 EDT | 1 | 17.0 | `logs/f2-F-u4-base.log`  |
| `f2-F-u4-c1` | 2026-10-13 00:23:56 EDT | 1 | 16.4 | `logs/f2-F-u4-c1.log`  |
| `f2-F-u4-c2` | 2026-10-13 00:24:13 EDT | 0 | 13.5 | `logs/f2-F-u4-c2.log`  |
| `m1-v200-u3-save-queued` | 2026-10-13 00:26:31 EDT | 1 | 13.2 | `logs/m1-v200-u3-save-queued.log`  |
| `m1-v200-u3-save-file-words` | 2026-10-13 00:26:44 EDT | 1 | 13.4 | `logs/m1-v200-u3-save-file-words.log`  |
| `m1-v200-u3-file-queued` | 2026-10-13 00:26:57 EDT | 1 | 16.1 | `logs/m1-v200-u3-file-queued.log`  |
| `m1-v200-u3-publish-queued` | 2026-10-13 00:27:13 EDT | 1 | 18.4 | `logs/m1-v200-u3-publish-queued.log`  |
| `m1-v200-u3-resolve-queued` | 2026-10-13 00:27:32 EDT | 1 | 20.5 | `logs/m1-v200-u3-resolve-queued.log`  |
| `m1-v200-u3-pen-reads-first` | 2026-10-13 00:27:52 EDT | 1 | 22.2 | `logs/m1-v200-u3-pen-reads-first.log`  |
| `m2-v200-u3-save-queued` | 2026-10-13 00:28:26 EDT | 1 | 35.9 | `logs/m2-v200-u3-save-queued.log`  |
| `m2-v200-u3-save-file-words` | 2026-10-13 00:29:02 EDT | 1 | 40.3 | `logs/m2-v200-u3-save-file-words.log`  |
| `m2-v200-u3-file-queued` | 2026-10-13 00:29:43 EDT | 1 | 35.5 | `logs/m2-v200-u3-file-queued.log`  |
| `m2-v200-u3-publish-queued` | 2026-10-13 00:30:19 EDT | 1 | 45.6 | `logs/m2-v200-u3-publish-queued.log`  |
| `m2-v200-u3-resolve-queued` | 2026-10-13 00:31:04 EDT | 1 | 34.9 | `logs/m2-v200-u3-resolve-queued.log`  |
| `m2-v200-u3-pen-reads-first` | 2026-10-13 00:31:39 EDT | 1 | 34.0 | `logs/m2-v200-u3-pen-reads-first.log`  |
| `m3-v200-u4-read-unchecked` | 2026-10-13 00:32:13 EDT | 1 | 30.4 | `logs/m3-v200-u4-read-unchecked.log`  |
| `m3-v200-u4-hist-unchecked` | 2026-10-13 00:32:44 EDT | 1 | 28.8 | `logs/m3-v200-u4-hist-unchecked.log`  |
| `m3-v200-u4-stamp-moved` | 2026-10-13 00:33:13 EDT | 1 | 25.2 | `logs/m3-v200-u4-stamp-moved.log`  |
| `m3-v200-u4-pen-line-kept` | 2026-10-13 00:33:38 EDT | 1 | 31.8 | `logs/m3-v200-u4-pen-line-kept.log`  |
| `m3-v200-u4-hist-says-nothing` | 2026-10-13 00:34:10 EDT | 1 | 28.9 | `logs/m3-v200-u4-hist-says-nothing.log`  |
| `f3-F-holdpre-base` | 2026-10-13 00:35:14 EDT | 0 | 236.9 | `logs/f3-F-holdpre-base.log`  |
| `f3-F-holdpre-c2` | 2026-10-13 00:39:11 EDT | 0 | 213.1 | `logs/f3-F-holdpre-c2.log`  |
| f3-F-holdall-c2 CUT OFF: the batch wrapper's own 600 s bound ended at 00:45:14 EDT while this run was going; its recorded PIDs 25052 (timeout) and 25054 (node) were stopped by PID at 00:45:35 EDT. Incomplete; re-run as f4. | | | | |
| `f4-F-litepre-base` | 2026-10-13 00:46:24 EDT | 0 | 164.9 | `logs/f4-F-litepre-base.log`  |
| `f4-F-liteall-c2` | 2026-10-13 00:49:09 EDT | 0 | 163.1 | `logs/f4-F-liteall-c2.log`  |
| # resumed 2026-10-13 04:20:13 EDT by the fourth HOLD builder; runs below are this builder's | | | | |
| `r1-F-u3-base` | 2026-10-13 04:20:13 EDT | 1 | 28.0 | `logs/r1-F-u3-base.log`  |
| `r1-F-u3-c1` | 2026-10-13 04:20:42 EDT | 0 | 22.7 | `logs/r1-F-u3-c1.log`  |
| `r1-F-u3-c2` | 2026-10-13 04:21:04 EDT | 0 | 25.0 | `logs/r1-F-u3-c2.log`  |
| `r1-F-u4-base` | 2026-10-13 04:21:29 EDT | 1 | 23.3 | `logs/r1-F-u4-base.log`  |
| `r1-F-u4-c1` | 2026-10-13 04:21:53 EDT | 1 | 20.6 | `logs/r1-F-u4-c1.log`  |
| `r1-F-u4-c2` | 2026-10-13 04:22:13 EDT | 0 | 17.4 | `logs/r1-F-u4-c2.log`  |
| `g1-F-folderB-c2` | 2026-10-13 04:23:56 EDT | 0 | 288.3 | `logs/g1-F-folderB-c2.log`  |
| `g2-F-folderA-c2` | 2026-10-13 04:28:49 EDT | 0 | 104.9 | `logs/g2-F-folderA-c2.log`  |
| `g2-F-nr02-c2` | 2026-10-13 04:30:34 EDT | 0 | 12.2 | `logs/g2-F-nr02-c2.log`  |
| `g3-F-hold-c2` | 2026-10-13 04:30:50 EDT | 0 | 42.8 | `logs/g3-F-hold-c2.log`  |
| `g3-F-u2-c2` | 2026-10-13 04:31:33 EDT | 0 | 60.8 | `logs/g3-F-u2-c2.log`  |
| `g3-F-u13-c2` | 2026-10-13 04:32:34 EDT | 0 | 40.0 | `logs/g3-F-u13-c2.log`  |
| `g4-F-holdall-c2` | 2026-10-13 04:33:20 EDT | 0 | 225.2 | `logs/g4-F-holdall-c2.log`  |
| `g5-F-folderB-base` | 2026-10-13 04:37:12 EDT | 0 | 411.2 | `logs/g5-F-folderB-base.log`  |
| `g6-F-folderA-base` | 2026-10-13 04:44:14 EDT | 0 | 203.5 | `logs/g6-F-folderA-base.log`  |
| `g6-F-nr02-base` | 2026-10-13 04:47:37 EDT | 0 | 19.7 | `logs/g6-F-nr02-base.log`  |
| `g7-F-hold-base` | 2026-10-13 04:48:03 EDT | 0 | 45.5 | `logs/g7-F-hold-base.log`  |
| `g7-F-u2-base` | 2026-10-13 04:48:49 EDT | 0 | 34.6 | `logs/g7-F-u2-base.log`  |
| `g7-F-u13-base` | 2026-10-13 04:49:24 EDT | 0 | 62.5 | `logs/g7-F-u13-base.log`  |
| `g8-F-folderB-c1` | 2026-10-13 04:50:31 EDT | 0 | 303.7 | `logs/g8-F-folderB-c1.log`  |
| `g9-F-folderA-c1` | 2026-10-13 04:55:42 EDT | 0 | 288.5 | `logs/g9-F-folderA-c1.log`  |
| `g9-F-nr02-c1` | 2026-10-13 05:00:30 EDT | 0 | 37.8 | `logs/g9-F-nr02-c1.log`  |
| `g9-F-hold-c1` | 2026-10-13 05:01:09 EDT | 0 | 255.0 | `logs/g9-F-hold-c1.log`  |
| `g10-F-u2-c1` | 2026-10-13 05:05:29 EDT | 0 | 123.9 | `logs/g10-F-u2-c1.log`  |
| `g10-F-u13-c1` | 2026-10-13 05:07:33 EDT | 0 | 81.9 | `logs/g10-F-u13-c1.log`  |
| `x1-c2-impmixed-file-unguarded` | 2026-10-13 05:09:06 EDT | 1 | 237.7 | `logs/x1-c2-impmixed-file-unguarded.log`  |
| `x2-c2-impmixed-folder-unguarded` | 2026-10-13 05:13:13 EDT | 1 | 191.4 | `logs/x2-c2-impmixed-folder-unguarded.log`  |
| `x3-c2-impmixed-not-marked` | 2026-10-13 05:16:32 EDT | 1 | 187.3 | `logs/x3-c2-impmixed-not-marked.log`  |
| `x4-c2-impmixed-not-kept` | 2026-10-13 05:19:47 EDT | 1 | 169.2 | `logs/x4-c2-impmixed-not-kept.log`  |
| `x4-c2-impmixed-clear-unasked` | 2026-10-13 05:22:36 EDT | 1 | 182.7 | `logs/x4-c2-impmixed-clear-unasked.log`  |
| `x5-c2-impmixed-boot-silent` | 2026-10-13 05:25:48 EDT | 1 | 180.6 | `logs/x5-c2-impmixed-boot-silent.log`  |
| `x5-c2-impmixed-never-lifted` | 2026-10-13 05:28:48 EDT | 1 | 187.8 | `logs/x5-c2-impmixed-never-lifted.log`  |
| `x6-c2-impmixed-lift-partial` | 2026-10-13 05:32:06 EDT | 1 | 189.3 | `logs/x6-c2-impmixed-lift-partial.log`  |
| `x6-c2-v200-r4-no-recheck` | 2026-10-13 05:35:16 EDT | 1 | 157.0 | `logs/x6-c2-v200-r4-no-recheck.log`  |
| `x7-c2-v200-r4-held-quietly` | 2026-10-13 05:38:00 EDT | 1 | 143.7 | `logs/x7-c2-v200-r4-held-quietly.log`  |
| `x7-c2-v200-r4-said-not-held` | 2026-10-13 05:40:24 EDT | 1 | 145.2 | `logs/x7-c2-v200-r4-said-not-held.log`  |
| `x8-c2-saves-not-serial` | 2026-10-13 05:42:53 EDT | 1 | 140.1 | `logs/x8-c2-saves-not-serial.log`  |
| `x8-base-impmixed-file-unguarded` | 2026-10-13 05:45:13 EDT | 1 | 122.0 | `logs/x8-base-impmixed-file-unguarded.log`  |
| `x9-base-impmixed-folder-unguarded` | 2026-10-13 05:47:22 EDT | 1 | 119.2 | `logs/x9-base-impmixed-folder-unguarded.log`  |
| `S-base-boot-same` | 2026-10-13 05:49:27 EDT | 0 | 10.5 | `logs/S-base-boot-same.log`  |
| `S-base-audit` | 2026-10-13 05:49:38 EDT | 0 | 9.5 | `logs/S-base-audit.log`  |
| `S-base-audit-ppt` | 2026-10-13 05:49:47 EDT | 0 | 4.8 | `logs/S-base-audit-ppt.log`  |
| `S-base-audit-other` | 2026-10-13 05:49:52 EDT | 0 | 27.2 | `logs/S-base-audit-other.log`  |
| `S-base-legacy-fsrc` | 2026-10-13 05:50:19 EDT | 0 | 2.0 | `logs/S-base-legacy-fsrc.log`  |
| `S-base-audit-inject` | 2026-10-13 05:50:21 EDT | 0 | 7.8 | `logs/S-base-audit-inject.log`  |
| `S-base-npm-check` | 2026-10-13 05:50:29 EDT | 0 | 2.5 | `logs/S-base-npm-check.log`  |
| `S-c2-boot-same` | 2026-10-13 05:50:36 EDT | 0 | 7.1 | `logs/S-c2-boot-same.log`  |
| `S-c2-audit` | 2026-10-13 05:50:43 EDT | 0 | 6.0 | `logs/S-c2-audit.log`  |
| `S-c2-audit-ppt` | 2026-10-13 05:50:49 EDT | 0 | 3.2 | `logs/S-c2-audit-ppt.log`  |
| `S-c2-audit-other` | 2026-10-13 05:50:52 EDT | 0 | 30.8 | `logs/S-c2-audit-other.log`  |
| `S-c2-legacy-fsrc` | 2026-10-13 05:51:23 EDT | 0 | 2.2 | `logs/S-c2-legacy-fsrc.log`  |
| `S-c2-audit-inject` | 2026-10-13 05:51:25 EDT | 0 | 9.4 | `logs/S-c2-audit-inject.log`  |
| `S-c2-npm-check` | 2026-10-13 05:51:35 EDT | 0 | 3.2 | `logs/S-c2-npm-check.log`  |
| `S-base-audit-recon` | 2026-10-13 05:51:41 EDT | 0 | 77.8 | `logs/S-base-audit-recon.log`  |
| `S-base-audit-hostile` | 2026-10-13 05:52:59 EDT | 0 | 66.1 | `logs/S-base-audit-hostile.log`  |
| `S-c2-audit-recon` | 2026-10-13 05:54:09 EDT | 0 | 151.4 | `logs/S-c2-audit-recon.log`  |
| `S-c2-audit-hostile` | 2026-10-13 05:56:40 EDT | 0 | 77.6 | `logs/S-c2-audit-hostile.log`  |
| `x10-c2-saves-not-serial` | 2026-10-13 06:00:14 EDT | 1 | 137.7 | `logs/x10-c2-saves-not-serial.log`  |
| # resumed 2026-10-13 09:16:49 EDT by the fifth HOLD builder; runs below are this builder's | | | | |
| `r2-F-u3-base` | 2026-10-13 09:16:54 EDT | 1 | 25.8 | `logs/r2-F-u3-base.log`  |
| `r2-F-u3-c2` | 2026-10-13 09:17:20 EDT | 0 | 14.1 | `logs/r2-F-u3-c2.log`  |
| `r2-F-u4-base` | 2026-10-13 09:17:34 EDT | 1 | 12.0 | `logs/r2-F-u4-base.log`  |
| `r2-F-u4-c1` | 2026-10-13 09:17:46 EDT | 1 | 13.8 | `logs/r2-F-u4-c1.log`  |
| `r2-F-u4-c2` | 2026-10-13 09:18:00 EDT | 0 | 13.2 | `logs/r2-F-u4-c2.log`  |
| `x11-base-saves-not-serial` | 2026-10-13 09:18:13 EDT | 1 | 101.7 | `logs/x11-base-saves-not-serial.log`  |

Other bounded commands (`logs/bx.txt`: text helpers, mutant and harness builds, clones, batch wrappers):

| Label | Start (ET) | Exit | Wall s |
|---|---|---|---|
| `mkmuts` | 2026-10-13 00:26:06 EDT | 0 | 9.03 |
| `mkharness2` | 2026-10-13 00:34:56 EDT | 0 | 12.29 |
| `mkharness3` | 2026-10-13 00:45:59 EDT | 0 | 21.2 |
| `mcount-base` | 2026-10-13 04:18:16 EDT | 0 | 2.64 |
| `mcount-c1` | 2026-10-13 04:18:19 EDT | 0 | 3.63 |
| `mcount-c2` | 2026-10-13 04:18:22 EDT | 0 | 2.86 |
| `r1batch` | 2026-10-13 04:20:13 EDT | 0 | 137.48 |
| `mkmuts-recheck` | 2026-10-13 04:22:51 EDT | 0 | 9.13 |
| `mkharness-recheck` | 2026-10-13 04:23:18 EDT | 0 | 10.71 |
| `mkharness-nr02` | 2026-10-13 04:23:45 EDT | 0 | 0.61 |
| `g1batch` | 2026-10-13 04:23:56 EDT | 0 | 288.37 |
| `g2batch` | 2026-10-13 04:28:49 EDT | 0 | 117.26 |
| `g3batch` | 2026-10-13 04:30:50 EDT | 0 | 143.81 |
| `clone-base` | 2026-10-13 04:37:48 EDT | 0 | 0.27 |
| `checkout-base` | 2026-10-13 04:37:48 EDT | 0 | 1.41 |
| `clone-c1` | 2026-10-13 04:37:50 EDT | 0 | 0.26 |
| `checkout-c1` | 2026-10-13 04:37:50 EDT | 0 | 1.07 |
| `clone-c2` | 2026-10-13 04:37:51 EDT | 0 | 0.21 |
| `checkout-c2` | 2026-10-13 04:37:51 EDT | 0 | 1.23 |
| `g5batch` | 2026-10-13 04:37:12 EDT | 0 | 411.45 |
| `g6batch` | 2026-10-13 04:44:14 EDT | 0 | 223.56 |
| `g7batch` | 2026-10-13 04:48:03 EDT | 0 | 143.02 |
| `g9batch` | 2026-10-13 04:55:42 EDT | 0 | 581.8 |
| `g10batch` | 2026-10-13 05:05:29 EDT | 0 | 206.1 |
| `x4batch` | 2026-10-13 05:19:47 EDT | 0 | 352.13 |
| `x5batch` | 2026-10-13 05:25:47 EDT | 0 | 368.71 |
| `x6batch` | 2026-10-13 05:32:06 EDT | 0 | 346.52 |
| `x7batch` | 2026-10-13 05:38:00 EDT | 0 | 289.02 |
| `x8batch` | 2026-10-13 05:42:53 EDT | 0 | 262.15 |
| `suites-base-1` | 2026-10-13 05:49:27 EDT | 0 | 64.47 |
| `suites-c2-1` | 2026-10-13 05:50:36 EDT | 0 | 62.12 |
| `suites-base-2` | 2026-10-13 05:51:41 EDT | 0 | 143.98 |
| `suites-c2-2` | 2026-10-13 05:54:09 EDT | 0 | 229.17 |
| `exsweep-c2` | 2026-10-13 09:22:39 EDT | 0 | 1.14 |
| `mkreadme-5` | 2026-10-13 09:22:40 EDT | 0 | 0.15 |
| `mkreadme-6` | 2026-10-13 09:22:52 EDT | 0 | 0.14 |

## PIDs

Every PID started, with its command, is in `pids.txt` (382 lines; the fourth builder's start after the line
"# resumed by the fourth HOLD builder", mine after "# resumed by the fifth HOLD builder"). No process was killed by the
fourth builder or by me. The third builder's note on
`f3-F-holdall-c2` (its PIDs 25052 and 25054 stopped by PID) is in `logs/runs.txt`.
