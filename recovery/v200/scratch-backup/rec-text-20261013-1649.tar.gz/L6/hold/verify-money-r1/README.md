# HOLD track (U3, U4) — independent adversarial verification, lens A (data loss and money), round 1

Verifier's record. Everything is in `rec/L6/hold/verify-money-r1` (this directory). Times are Eastern
(`TZ=America/New_York date`). Started 12:25 PM ET, 13 Oct; this README written from about 1:07 PM ET, 13 Oct (last checked 1:08 PM ET). No earlier
attempt of this review had left anything here (the directory did not exist), so nothing was reused.

Nothing was edited, staged, committed or pushed in `/home/user/orbit-board` or `/home/user/orbit-ui`. The builder's files
(`rec/L6/hold/c1`, `c2`, …) were only read; every run here is on my own copies (`c/base`, `c/c1`, `c/c2`, `cp -a`, chmod u+w)
or in my own scratch clones (`clones/base`, `clones/c2`, `git clone --shared`, never committed). `mutate.mjs` was never
imported or run: mutants were made from `mutate.mjs.txt` as text by `rec/bin/mkmut.py`, counts by `rec/bin/mcount.py`.
No Chromium or playwright was used; `playwright install` was never run.

## Verdict

**Sound, with issues.** The board changes do what U3 and U4 ask, lose no copy, touch no money or export, and every existing
check I re-ran gives the same verdicts and values. One draft sentence is false and must be corrected before it is committed
(M1, text only). Three adjacent behaviours, all identical on the base, should be decided by the lead (S1–S3).

## Identities (git hash-object)

| file | base (`7ee498a`) | c1 (U3) | c2 (U3+U4) | builder's claim |
|---|---|---|---|---|
| prioritization-board-grid.html | `fce8a391` | `82a2f1cc` | `4b755576` | same |
| tools/export-audit/audit-import.mjs | `4aba2506` | `22cdd78e` | `f25c69f7` | same |
| tools/export-audit/mutate.mjs.txt | `cbc6defc` | `c3cab761` | `27f0fdb6` | same |
| audit-recon / audit-board / audit-other | `529e36f7` / `a7c575e5` / `d89396b0` | unchanged | unchanged | same |

`orbit-board` HEAD is now `3841339`; `git diff 7ee498a HEAD -- . ':!recovery'` is empty, and the clone's board, audit-import
and mutate.mjs blobs are `fce8a391`, `4aba2506`, `cbc6defc`, so the base stands. Re-derived diffs (`diffs/c1-*.diff`,
`diffs/c2-*.diff`): pure insertions — board +8/−0 and +13/−0, audit-import +133/−0 and +95/−0, mutate +19/−0 and +16/−0;
the board's changed lines are identical to the builder's `diffs/c1-board.diff` and `c2-board.diff`. The 13 mutant boards I
made (11 new entries, `impmixed-file-unguarded`, `impmixed-folder-unguarded`) are byte-identical to the builder's `mut/c2-*`.
My focused harnesses (`harness/F-u3.mjs` `238de95f`, `F-u4.mjs` `094ac287`, `F-liteall.mjs` `c8fce9b5`, rebuilt from c2's
audit-import with the builder's `mkfocused-multi.py`) differ from the builder's only in the header line naming the source path.

## Read, not run: every caller and every wait

- Entry points into the save queue (`saveSerial` callers): `saveInPlace` (💾 Save button, File menu via `mRun`, Take the pen),
  `saveInPlaceFile` (no caller in the board; tests only), `driveStorePush` (⬆ Publish now via `livePublish`, the autosave via
  `liveTick`), `driveResolve` (Load theirs, Save yours over theirs, load-without-keeping). Each now refuses at once under the
  hold. Callers: `liveTick` does `done=await p` (false → says nothing), `livePublish` does `ok=await …; return !!ok`,
  `takePen` awaits `saveInPlace()` inside `try…finally{_takePen=null}`, the rest ignore the result. A `false`/`undefined`
  returned at once is handled exactly as the run's own refusal was. No keyboard shortcut or unload handler saves
  (`beforeunload` only removes the lock file).
- Waits in `_driveStorePushRun` before its write: `driveDir`, `driveStoreRead` (covered by the new after-read check), the
  history copy `snapKeep` (covered by the new after-history check), then `driveWrite` (createWritable/write/close — not
  covered; disclosed). `writerMay` and `driveClashSay` are synchronous. The bytes are built synchronously after the
  after-read check, and a full import's storage writes and its hold are set in one synchronous run (`lsAll` →
  `fullImportUndone`), so no bytes are ever built from a half-set mix.
- `fullImportUndone` leaves the board on screen as it was; in folder mode the payload is this board's `MS` only, so a folder
  write under the hold writes the board on screen, not the storage mix (the mix reaches a write through `buildSavedHtml` on
  the board-file path). U4 therefore protects the hold's contract and its words more than the bytes; the batch import's
  "could not put the board on screen back" case is where the folder bytes themselves could be mixed.
- U4's put-back: `MS.ts/MS.by` go back only if `MS.ts===wroteTs` (an edit typed meanwhile keeps its stamp — measured, V-edit-hist);
  the pen line is undone; `MS.dataPack` is left recomputed (harmless). The pre-existing "history could not be kept" refusal a
  few lines above does not put the stamp back (not this track; U18 merges the two put-backs).

## Runs (each through `bin/run.sh`: `setsid -w timeout -k 10 600`, lock checked first, PIDs in `pids.txt`)

| label | start ET (13 Oct) | exit | wall s | result | log |
|---|---|---|---|---|---|
| probe-c2-V-write-folder | 12:35:02 | 0 | 26.5 | observations | logs/probe-c2-V-write-folder.log |
| probe-c2-V-open-file | 12:35:37 | 0 | 25.5 | observations | logs/probe-c2-V-open-file.log |
| probe-base-V-write-folder | 12:35:37 | 0 | 29.0 | observations | logs/probe-base-V-write-folder.log |
| probe-c2-V-auto-queued | 12:36:03 | 0 | 34.4 | observations | logs/probe-c2-V-auto-queued.log |
| probe-base-V-open-file | 12:36:06 | 0 | 32.2 | observations | logs/probe-base-V-open-file.log |
| probe-c2-V-auto-read | 12:36:37 | 0 | 33.0 | observations | logs/probe-c2-V-auto-read.log |
| probe-base-V-auto-queued | 12:36:38 | 0 | 32.0 | observations | logs/probe-base-V-auto-queued.log |
| probe-base-V-auto-read | 12:37:10 | 0 | 29.6 | observations | logs/probe-base-V-auto-read.log |
| probe-c2-V-pen-read | 12:37:10 | 0 | 30.1 | observations | logs/probe-c2-V-pen-read.log |
| probe-c2-V-before-lifted | 12:37:40 | 0 | 24.4 | observations | logs/probe-c2-V-before-lifted.log |
| probe-base-V-pen-read | 12:37:40 | 0 | 30.7 | observations | logs/probe-base-V-pen-read.log |
| probe-base-V-before-lifted | 12:38:11 | 0 | 25.2 | observations | logs/probe-base-V-before-lifted.log |
| probe-c2-V-edit-hist | 12:38:05 | 0 | 32.1 | observations | logs/probe-c2-V-edit-hist.log |
| probe-base-V-edit-hist | 12:38:36 | 0 | 26.9 | observations | logs/probe-base-V-edit-hist.log |
| probe-c2-V-resolve-read | 12:38:37 | 0 | 28.8 | observations | logs/probe-c2-V-resolve-read.log |
| probe-base-V-resolve-read | 12:39:03 | 0 | 25.0 | observations | logs/probe-base-V-resolve-read.log |
| probe-c2-V-crosstab | 12:39:06 | 0 | 22.6 | observations | logs/probe-c2-V-crosstab.log |
| probe-base-V-crosstab | 12:39:28 | 0 | 22.7 | observations | logs/probe-base-V-crosstab.log |
| F-u4-base | 12:41:14 | 1 | 51.4 | 18 checks, 10 fail (as claimed) | logs/F-u4-base.log |
| F-u3-base | 12:41:14 | 1 | 60.9 | 47 checks, 18 fail (as claimed) | logs/F-u3-base.log |
| F-u4-c2 | 12:42:05 | 0 | 48.3 | 18 checks, 0 fail | logs/F-u4-c2.log |
| F-u3-c2 | 12:42:15 | 0 | 68.1 | 47 checks, 0 fail | logs/F-u3-c2.log |
| M-v200-u4-read-unchecked (c2 mutant, F-u4) | 12:42:54 | 1 | 49.2 | caught, 1 check | logs/M-v200-u4-read-unchecked.log |
| M-v200-u3-save-queued (F-u3) | 12:43:23 | 1 | 66.6 | caught, 6 checks | logs/M-v200-u3-save-queued.log |
| M-v200-u4-hist-unchecked (F-u4) | 12:43:43 | 1 | 51.8 | caught, 6 checks | logs/M-v200-u4-hist-unchecked.log |
| M-v200-u4-stamp-moved (F-u4) | 12:44:35 | 1 | 46.8 | caught, 2 checks | logs/M-v200-u4-stamp-moved.log |
| M-v200-u3-save-file-words (F-u3) | 12:44:30 | 1 | 55.5 | caught, 1 check | logs/M-v200-u3-save-file-words.log |
| M-v200-u4-pen-line-kept (F-u4) | 12:45:22 | 1 | 47.2 | caught, 1 check | logs/M-v200-u4-pen-line-kept.log |
| M-v200-u3-file-queued (F-u3) | 12:45:25 | 1 | 56.2 | caught, 3 checks | logs/M-v200-u3-file-queued.log |
| M-v200-u4-hist-says-nothing (F-u4) | 12:46:09 | 1 | 46.8 | caught, 2 checks | logs/M-v200-u4-hist-says-nothing.log |
| M-v200-u3-publish-queued (F-u3) | 12:46:21 | 1 | 62.3 | caught, 3 checks | logs/M-v200-u3-publish-queued.log |
| M-impmixed-file-unguarded (F-u3) | 12:46:56 | 1 | 53.0 | caught, 1 check (before-the-hold case) | logs/M-impmixed-file-unguarded.log |
| M-v200-u3-resolve-queued (F-u3) | 12:47:24 | 1 | 56.3 | caught, 3 checks | logs/M-v200-u3-resolve-queued.log |
| M-impmixed-folder-unguarded (F-u3) | 12:47:49 | 1 | 55.6 | caught, 1 check (before-the-hold case) | logs/M-impmixed-folder-unguarded.log |
| M-v200-u3-pen-reads-first (F-u3) | 12:48:20 | 1 | 54.5 | caught, 3 checks | logs/M-v200-u3-pen-reads-first.log |
| F-liteall-c2 | 12:49:53 | 0 | 300.2 | 123 checks, 0 fail | logs/F-liteall-c2.log |
| F-liteall-base | 12:49:53 | 1 | 301.6 | 123 checks, 28 fail (18 U3 + 10 U4; the 58 existing checks pass) | logs/F-liteall-base.log |
| ML-impmixed-file-unguarded (F-liteall) | 12:55:15 | 1 | 258.7 | 1 fail, only U3's before-the-hold case: R4b, v1.95, v1.99 blocks pass | logs/ML-impmixed-file-unguarded.log |
| ML-impmixed-folder-unguarded (F-liteall) | 12:55:15 | 1 | 261.5 | 1 fail, only U3's before-the-hold case | logs/ML-impmixed-folder-unguarded.log |
| S-check-base (not a git tree) | 12:59:47 | 1 | 10.3 | 2 fails: "could not ask git" (no repo) — superseded by S2 | logs/S-check-base.log |
| S-check-c2 (not a git tree) | 12:59:47 | 1 | 10.5 | the same 2 — superseded by S2 | logs/S-check-c2.log |
| S2-check-c2 (scratch clone) | 13:00:31 | 0 | 9.9 | all checks passed | logs/S2-check-c2.log |
| S2-check-base (scratch clone) | 13:00:31 | 0 | 10.1 | all checks passed; output identical but for the line counts (+21) | logs/S2-check-base.log |
| F-u4-c1 | 13:00:59 | 1 | 32.3 | 18 checks, 10 fail (as claimed for the U3 board) | logs/F-u4-c1.log |
| S-c2-audit-other (clone) | 13:00:59 | 0 | 84.1 | ALL CHECKS PASSED | logs/S-c2-audit-other.log |
| S-c2-audit (clone; exports) | 13:01:31 | 0 | 26.7 | ALL CHECKS PASSED | logs/S-c2-audit.log |
| S-base-audit (clone) | 13:01:58 | 0 | 29.2 | ALL CHECKS PASSED; output identical to c2's | logs/S-base-audit.log |
| S-base-audit-other (clone) | 13:02:23 | 0 | 99.1 | ALL CHECKS PASSED; output identical to c2's | logs/S-base-audit-other.log |
| probe-c2x-V-resolve-read (my S1 proposal) | 13:05:53 | 0 | 38.0 | observations (S1 closed) | logs/probe-c2x-V-resolve-read.log |

Existing checks (`bin/cmpexist.py` on F-liteall): the 58 checks of the v1.95 hold, the v1.95 lift, the v1.99 batch hold, R4
and R4b have the same keys in the same order, the same verdicts and the same values on base and c2 (0 differ). I did not
re-run the builder's 709-check set (F-folderA/B, F-hold, F-u2, F-u13, F-nr02) or audit-recon, audit-hostile, audit-inject,
audit-ppt, boot-same, legacy-fsrc.

mcount (text only, `out/mcount-*.txt`): base 1328/1328 once, c1 1334/1334, c2 1339/1339; the new entries sit just before
"  // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan."

## The probes (`probe/vprobe.mjs` `a6ad3671` = head `df211948` + W1H and the W2 helpers verbatim from the base suite + body `38ab6fd2`)

Observations only; the verdicts below are mine. Outputs `out/probe-<copy>-<scenario>.json`; `bin/show.py` prints them.

| scenario | base `fce8a391` | c2 `4b755576` | reading |
|---|---|---|---|
| V-write-folder: folder save held at the close of its own write; import stops there | writes 1, "✅ Saved O&M FY27 … A change made while it was saving is not in the folder yet — it is saved next time.", hold on, rescue buttons gone from the line | identical | disclosed "not covered" window (S3) |
| V-open-file: board-file save held at createWritable, after R4's check | writes 1, Full Fund OLD, "💾 Saved in place … 💾 Save again to write it.", hold on | identical | disclosed; bytes carry no mix |
| V-auto-queued: autosave tick behind save A, hold on | "⏳ A save is already under way — this one runs as soon as it finishes." (then refused quietly at its turn: untrue) | nothing said; the import's message and rescue buttons stay | U3 improves the words |
| V-auto-read: quiet autosave held at its read; import stops | **writes 1, history +1, DIRTY false, stamp moved, nothing said** | refused quietly: writes 0, DIRTY true, stamp back, import's message unchanged | U4 closes the quiet form too |
| V-pen-read: Take the pen (folder) held at its read; import stops | asked once, then "⛔ Writing to the shared folder is refused"; Alice still writer, 0 pen lines, writes 0 | identical | as the drafts say |
| V-before-lifted: board-file Save B asked BEFORE the hold, waiting behind A; hold; "allow saving again" (yes); A let go | B runs: perm 2 · read 2 · open 2 · writes 2, **Full Fund NEW** | **identical** | M1 / S2 |
| V-edit-hist: folder save held at its history copy; import stops; EDIT-2 typed there | writes 1, "✅ Saved …" | refused, writes 0, history +1, the edit's stamp kept, DIRTY true; after allowing, Save writes EDIT-2 | U4 put-back correct |
| V-resolve-read: Save yours over theirs held at its read; import stops; then allow; then quiet autosave | asked 1, their copy kept, **base recorded as theirs**, refused; after allowing, the quiet autosave writes over Bob's copy, asked 0, Bob's note gone from the folder's copy (kept in history ×2), status still "💾 Save is allowed again." | **identical** | S1 |
| V-crosstab: hold mark only in storage (another tab), B behind A | B queued ("⏳ …"), refused at its turn | B refused at once, "⛔ Saving to the board file is refused …" | U3 holds across tabs |

## Findings

### Must fix (text only; no code change)

**M1 — the U3 NEXT-VERSION draft states a guarantee the board does not give.** `drafts/NEXT-VERSION-U3.md` says: "The checks at
the start of each save's turn, and R4's after the read, stay: a save asked for before the hold, still waiting when the hold
comes, is refused when its turn comes, before the file or the folder's copy is read." Reproduction V-before-lifted (base and
c2 alike): B asked before the hold and waiting behind A; the import stops part-way; "allow saving again…" answered yes; A let
go → B runs and writes the mix over the board file (`perm 2 · read 2 · open 2 · writes 2`, Full Fund `NEW`). It is refused
only if the hold still stands at its turn. Neither the draft's "Not covered" nor the ledger text mentions this case. Minimal
fix (replace the sentence):

> The checks at the start of each save's turn, and R4's after the read, stay: a save asked for before the hold, still waiting
> when the hold comes, is refused when its turn comes if the hold still stands then, before the file or the folder's copy is
> read. If saving is allowed again before its turn, it runs at once and writes, as the question that allows it warns ("The
> next save writes the board on screen, and that mix for the other appropriations, over the board file").

and add to the U3 entry's and U3 ledger text's "Not covered": "a save asked for before the hold and still waiting when saving
is allowed again runs at once and writes the mix — on the board file the imported Full Fund plan (measured on the base and on
this board alike)". The U3 block's comment in audit-import says the same unconditional sentence ("is refused when its turn
comes"); its checks keep the hold on and are right — add "while the hold still stands" to the comment (comment only).

### Should fix (the lead decides; all three are identical on the base, so not introduced by this change)

**S1 — Save yours over theirs does not re-check the hold after its read; once saving is allowed, the autosave writes over
their copy without asking.** `_driveResolveRun` checks the hold only at its start. V-resolve-read: a hold that comes during its
read lets it ask, keep their copy (forced), and record their copy as the base (`driveBaseSet(ap, theirs)`); the save is then
refused ("⛔ Writing to the shared folder is refused"). After "allow saving again", the quiet autosave (`driveStorePush(true)`)
writes over Bob's copy with no question and no word (asked 0, Bob's note gone from the folder's copy; kept twice in the
history). The builder's "Not covered" says a 💾 Save does this "as the person chose"; the autosave does it too, after the board
told the person the choice was refused. Proposed (the U4 pattern, `diffs/c2x-proposal-resolve.diff`, board `ac4f29b5`):

```
   if(impMixedBlock('Choosing between the copies')) return false;   // v2.00 (U4): checked again after the read, as the folder save is
   … after the forced snapKeep of their copy, before driveBaseSet(ap, theirs):
     if(impMixedBlock('Choosing between the copies')) return false;   // v2.00 (U4): and after their copy is kept, before it is decided
```

Measured on that scratch copy (probe-c2x-V-resolve-read): asked 0, no history copy, base not moved, "⛔ Choosing between the
copies is refused"; after allowing, the autosave writes nothing and Bob's note stays. Not run against any suite; it would need
a block case and mutations if adopted.

**S2 — a save waiting when the hold comes runs as soon as saving is allowed again (V-before-lifted).** Asked before the hold,
it writes the mix without a fresh press, right after "💾 Save is allowed again." The question does warn that "the next save
writes … that mix". Options: (a) make the question say a save is waiting and will run at once (words only); (b) count holds
(a number bumped where `fullImportUndone`/`batchImportUndone` set the mark, captured when a save is asked, compared at the
start of its turn) and refuse a save that a hold came during, even if lifted; (c) refuse `impMixedClear` while `_saveBusy`
(this changes the new U3 block's "saving is allowed again (a control)" step, so it would need the expectation listed).

**S3 — the "Saved" line in the disclosed write window says more than is true.** V-write-folder / V-open-file: with the hold on,
the line that replaces the import's message (and its rescue buttons) ends "— it is saved next time" / "— 💾 Save again to write
it", but the next save is refused while the hold stands; and the "change made while it was saving" is the import's own
storage write, not anything on screen. The drafts' "Not covered" should say the hold's message and buttons are replaced there
and come back only with the next refused save; a fix is the lead's call (outside U3/U4 as written).

### Minor

- U3 draft, "What users may see": "The quiet autosave is refused quietly, as before" — not as before: behind a save under way
  the base said "⏳ A save is already under way — this one runs as soon as it finishes" and then refused it without a word
  (V-auto-queued). Better: "is refused quietly; it no longer says '⏳ … runs as soon as it finishes' behind another save".
- Board comment in `saveInPlace`: "Brad, 11 Oct: refused at once, before the file is touched; allowing saving again does not
  bring it back." reads as Brad's words; his R4b contract is "a Save requested while the mixed-import hold is already active
  must refuse immediately, before file access. Clearing the hold later must not resume that refused request." Quote it, or
  say "(Brad's R4b contract, 11 Oct)".
- NEXT-VERSION's R4b entry still says "It catches `impmixed-file-unguarded` on the before-file-access check"; after U3 it does
  not (ML-impmixed-file-unguarded: R4b passes with that mutant on c2). The builder offers the correcting line as optional;
  make it part of the commit.
- Thin catches, all real: `v200-u4-read-unchecked` is caught by one check (an extra history copy — the after-history check
  still stops the write), `v200-u3-save-file-words` by one, `impmixed-file-unguarded` and `impmixed-folder-unguarded` by one
  each (the U3 block's before-the-hold cases). The quiet autosave path of U4 (V-auto-read) is not in the U4 block.

## The lead's six principles, checked literally

1. **No copy lost.** Measured: refused saves leave the board file / folder copy byte-identical; the history copy kept before
   a U4 refusal stays; work stays on screen, unsaved, and is written once saving is allowed (V-edit-hist retry, F-u4
   controls). S1 is a pre-existing path where a copy is replaced (kept in history) without a fresh ask.
2. **Refuse or ask, not guess.** Met for saves asked under the hold. S1 and S2 are pre-existing paths that act later on an
   earlier answer.
3. **Money and exports.** No computation or export path touched (diff read); audit and audit-other give identical output on
   base and c2; npm run check passes on both.
4. **Words true after landing.** The changed paths say true things (refusals, quiet autosave). M1 is a false sentence in the
   draft; S3 and the "quietly, as before" wording are the remaining untrue words nearby.
5. **Smallest change.** 21 board lines (8 code); one line per entry point and two checks plus a put-back in the folder save.
6. **Existing checks preserved.** Pure insertions; 58 re-run existing checks identical; the shift in which check catches
   `impmixed-file-unguarded`/`impmixed-folder-unguarded` is real and disclosed by the builder (confirmed by the ML runs).

## What I did not do, and rule gaps

- Not run: the full audit-import.mjs and audit-board.mjs (the lead's); the builder's other focused sets (F-folderA/B, F-hold,
  F-holdall, F-u2, F-u13, F-nr02); audit-recon, audit-hostile, audit-inject, audit-ppt, boot-same, legacy-fsrc; the U18 merge.
- My S1 proposal was checked by one probe only; no suite block or mutation was written for it.
- Rule gaps, said plainly: my quick text commands (cat, sed, grep, diff, cp, git hash-object, git clone, python text
  helpers before 12:40) and one `node --check probe/vprobe.mjs` (12:34 PM ET, a syntax check that executes nothing) ran without
  the `setsid timeout` wrapper. The first probe lanes (`bin/probes.sh base|c2 …`, PIDs 20948 and 20952) were wrapped with a
  3000 s bound, not 600 s; each node run inside them had its own 600 s bound and all ended by 12:39:51 PM ET. The first
  `probes.sh c2 V-write-folder` call was foreground and its wrapper PID was not recorded (its node child was). Later lanes
  were wrapped at 600 s.
- PIDs: every PID I started is in `pids.txt` with its command. I killed no process.

## Files

- `c/base`, `c/c1`, `c/c2` (copies), `c/c2x` (scratch copy with my S1 proposal only), `clones/base`, `clones/c2`.
- `diffs/` (re-derived diffs; `c2x-proposal-resolve.diff`), `harness/`, `h/<copy>/tools/export-audit/` (harness beside the
  copy's boot.mjs link), `mut/` (13 mutants), `probe/`, `out/` (probe JSON, checks.jsonl, mcount), `logs/` (every run, with
  `# end … exit … wall_s` records; `runs.txt`), `bin/` (run.sh `8f9f0959`, frun.sh `f447df8c`, probes.sh `77054710`,
  runner.mjs `e835140a`, mkprobe.py `96cbdc66`, mkfocused-multi.py `9a31d9d9`, show.py `3f37c9a7`, summ.py `9c2067b5`,
  cmpexist.py `6dc5299d`, lane scripts).
