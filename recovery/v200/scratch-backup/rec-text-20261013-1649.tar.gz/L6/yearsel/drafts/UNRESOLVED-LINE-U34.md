  - **U34: built as its own commit, with two fix-round commits after the verifiers' two rounds** (Codex's review, as Brad
    supplied it, 12 Oct: "the malformed saved-year selection"): a saved year selection the board did not write is read as
    no year, kept as saved, and said on the panel and in the export; it is never read as ALL YEARS or as a year it does not
    name, and its quote keeps the exported workbook well-formed (above). Its limits are under "Not covered": a whole number
    that is no plausible year, an enormous list of distinct whole numbers, "kept" meaning the same value rather than the
    same bytes (1e999 is written back as null); a whole saved value of 1e999 read as ALL YEARS with nothing said; a saved
    NaN that makes the file's whole saved state unreadable, with the warning replaced on the status line in the same
    opening (U-new-nan); a saved year a century off an offered year printed as that year (U-new-fy2); a selection nested
    too deep for the board to open; and two findings recorded on their own: the saved appropriation selection, which still
    reads a malformed value as all appropriations with nothing said and counts money from appropriations the file does
    not name (U-new-aps), and saved prime-match text or category names holding U+FFFF, which still make the funds-flow
    export a workbook that is not well-formed (U-new-xml, the same writer gap as U37).
