Text to append to the U34 row of recovery/v200/UNRESOLVED-LEDGER.md (line 67 at `60336a0`, and still line 67 at `cadc4aa` and `c8a8603`).
It replaces the draft of 12 Oct, 8:32 PM ET (kept in drafts/superseded-c1/).

"Evidence so far" column, appended:

**Measured on the base, 12 Oct, 7:34–7:43 PM ET** (records head `7ee498a`, board `fce8a391` = U14 `d66dd60`;
`rec/L6/yearsel`, probes P1 and P2), and in the verifiers' round (13 Oct, 11:46 PM–12:15 AM and 4:14 AM ET). Each shape was
opened from the board's own saved file (`boot({html})`).
- **Read as ALL YEARS ($540M on the fixture, ALL YEARS lit, no notice):** a string ("2026" or "2027"), an object ({} or
  {"0":2027,"length":1}), a bare number (2027), true, "", 0, false, an empty list, [2026.5], ["FY27"] and 5,000 × "x".
- **Read as a year the file does not name:** ["2027"] and [[2027]] counted as FY27 ($500M). [null] and [""] were said as a
  saved "FY0", and [true] as "FY1".
- **One whole year counted, the bad entry silently dropped:** [2025, 2026.5] ($40M), [2027, "x"] and ["<b>x</b>", 2027].
- **Duplicates and an unsorted list** were read correctly.
- **Whole numbers that are no plausible year** were given U14's notice, printed by their last two digits: -2027 as FY-27,
  10000 as FY0, 99999 as FY99 (the export prints them whole).
- **Enormous lists:** 20,000 distinct numbers produced a 118,370-character notice, and each calculation took about 1.6 s.
- **Deep nesting:** at every depth tried from 3,654 to 4,153 lists deep (not at 3,154) the board opened but the
  funds-flow calculation threw (stack overflow); from 4,155 deep the board does not open (13 Oct, 4:41 AM ET,
  FR-depth-on-base).
- **No money mismatch:** in every shape that calculated, the calculation, the panel and the exported workbook agreed.
- **The value was kept as the same value** through the save and the reopen (JSON's: spaces dropped, -0 as 0, 1e999 as null).

"Status" column, appended:

**P2 (no money mismatch, no loss: a silent misreading of a hand-edited or damaged file, the kind Brad's U14 decision
forbids).** **Fix built and measured (12 Oct, 7:41–8:31 PM ET), reviewed by two verifiers (13 Oct, 11:46 PM–4:15 AM ET),
and corrected in a fix round (13 Oct, 4:35 AM ET onward; `rec/L6/yearsel`).**
- **The fix:** only no saved selection (null, or no key) is ALL YEARS, and a year is a whole number. Anything else is read as
  no year, not counted, kept as saved, and said: in the scope label, in a panel notice quoting the file (escaped), and in an
  export NOTE. A selection holding what the board cannot read is never ALL YEARS: not the chip, not the label. The quote is
  cut between characters, and U+FFFE / U+FFFF are quoted as their escape, so the export stays a well-formed workbook. A
  click on the year buttons chooses again and replaces what cannot be read.
- **The verifiers' must-fix (fixed in the round):** commit 1 alone quoted U+FFFE / U+FFFF raw into the export (a workbook
  that is not well-formed) and could cut an emoji in half; and it lit ALL YEARS beside an entry it could not read when the
  other years were every year offered.
- **The block:** 34 checks. 24 fail on `d66dd60`; the other 10 pass there by design (seven controls, two click controls,
  "nothing asked"); 5 fail on commit 1 alone; all 34 pass after. U14's 63 checks pass unchanged.
- **Mutations:** 27, each caught.
- **Other runs:** audit-recon's 306 recorded checks keep the same verdict and value. audit, audit-ppt, audit-other,
  audit-hostile, audit-inject, boot-same, legacy-fsrc and npm run check pass.
- **The catalog**, counted as text: 1,355 / 1,355.

**COMMITTED as `<sha>` (<time>)** [and `<sha2>` (<time2>) if the two commits land separately]: board `593593a4`,
audit-recon `5eac80ea`, mutate `f4e0739f`, after `d66dd60`. Limits, stated in NEXT-VERSION.md's "Not covered" and for the
evidence matrix:
- whole numbers that are no plausible year are still read as years (the FY1999 control pins that no range is read in),
  printed by their last two digits on the panel;
- an enormous list of distinct whole numbers is still named in full and is slow to read; the saved list sorts as text;
- "kept" is the same value, not the same bytes; 1e999 is quoted as "null" and written back as null;
- U+FFFE / U+FFFF are quoted as their escape, not as the character the file holds;
- a selection nested 4,155 deep or more stops the board opening (jsdom; the same before);
- the saved appropriation selection (`aps`) still reads a malformed value as all appropriations with nothing said, and
  counts money from appropriations the file does not name: its own row, U-new-aps;
- other saved text holding U+FFFF (prime-match tokens, category names) still makes the funds-flow export not well-formed:
  its own row, U-new-xml;
- only the saved-file opening path was tested; how the board writes the selection was checked from `09cf071` on;
- jsdom only.
