  - **U34: built as its own commit, with a fix-round commit after the verifiers' round** (Codex's review, as Brad supplied it,
    12 Oct: "the malformed saved-year selection"): a saved year selection the board did not write is read as no year, kept
    as saved, and said on the panel and in the export; it is never read as ALL YEARS or as a year it does not name, and its
    quote keeps the exported workbook well-formed (above). Its limits are under "Not covered": a whole number that is no
    plausible year, an enormous list of distinct whole numbers, "kept" meaning the same value rather than the same bytes
    (1e999 is written back as null), a selection nested too deep for the board to open, and two findings recorded on their
    own: the saved appropriation selection, which still reads a malformed value as all appropriations with nothing said
    and counts money from appropriations the file does not name (U-new-aps), and saved prime-match text or category names
    holding U+FFFF, which still make the funds-flow export a workbook that is not well-formed (U-new-xml).
