- **U34 — a saved year selection this board did not write is read as no year, kept and said** (Codex's review, as Brad
  supplied it on 12 Oct, about 6:05 PM ET: "the malformed saved-year selection"; Brad: "record the malformed saved-year
  selection ... explicitly"). The board writes a saved year selection in two forms only: nothing (ALL YEARS), or a list of
  whole years from its own buttons. A selection it did not write, as a hand-edited or damaged saved file carries it, was read
  with nothing said. A string ("2026"), an object, a bare number or an empty list read as ALL YEARS: $540,000,000 on the
  synthetic fixture, with ALL YEARS lit. [2026.5] and 5,000 entries of "x" read the same way. ["2027"] counted as FY27
  ($500,000,000). [null] and [true] were said as a saved "FY0" and "FY1". [2025, 2026.5] counted FY25 and said nothing of the
  rest. Nothing crashed. The money always matched across the calculation, the panel and the export, and the file kept the
  value byte for byte. Now only no saved selection (null, or no key) is ALL YEARS. A year is a whole number, as the board
  writes it. Anything else is read as no year: it is not counted, it is kept as saved, and it is said, with what is counted
  instead. It is said in the scope (the panel, the chart, the export's Scope line), in a notice on the panel and in the
  export's NOTE. The notice quotes the file: at most three entries, each cut at 40 characters, shown as text. Duplicates
  are still read once, and an unsorted list in order, with nothing said. ALL YEARS, a year's "only", or a year switched on
  or off chooses again and replaces what cannot be read, as the notice says. A toggle starts from the years the board could
  read.
  - **What users may see:** a saved file whose year selection was edited by hand or damaged now opens on "no year counted",
    or on the years the board could read, with a notice saying what the file holds. It used to show every year (or a year
    the file does not name), with nothing said.
  - **Test:** audit-recon "v2.00 (U34) — a saved year selection this board did not write is never read as ALL YEARS; it is
    kept and said" (22 checks). Each shape is opened from the board's own saved file and read apart in the calculation, the
    panel and the exported workbook's bytes, then saved and reopened. The eleven shapes are a string, an object, a bare
    number, an empty list, a year as text, 2026.5, null, true, one whole year beside one that is not, text that is markup
    (checked escaped), and 5,000 entries. There are six controls: no key, null, duplicates, out of order, 5,000 of one year,
    and a whole year no appropriation offers. One check switches FY27 on beside "2026", and three click controls follow.
    13 checks fail on the board before the change (`d66dd60`). Every control passes on both. U14's 63 checks pass unchanged.
  - **Mutations:** `v200-yearsel-not-a-list-all-years`, `-nothing-read-all-years`, `-number-coerced`, `-fraction-unsaid`,
    `-whole-unsaid`, `-label-unsaid`, `-panel-unsaid`, `-export-unsaid`, `-markup-unescaped`, `-counted-unsaid`,
    `-plural-it` and `-toggle-from-all`. Each is caught by the focused block (full-suite sensitivity runs in the final-tree
    queue).
  - **Not covered:**
    - A whole number that is no plausible year (-2027, 0, 1990, 10000, 99999) is still read as a year and given U14's notice.
      The panel and the scope label print it by its last two digits ("FY-27", "FY0", "FY99"), while the export's NOTE
      prints it whole. The board prints every year this way, and its import accepts any non-zero whole year.
    - An enormous list of distinct whole numbers is still named in full, and is slow to read. At 3,000 the panel's notice
      is 18,070 characters. At 20,000 it is 118,370 characters, and the calculation and the panel each took 1.3–1.6 s in
      jsdom (the de-duplication grows with the square of the length). The scope label, the export's Scope line and its file
      name name them all.
    - The saved appropriation selection shaped the same ways ("om", [], ["xx"]) still reads as all appropriations, with
      nothing said. This was measured on `d66dd60` and is unchanged here.
    - A click on the year buttons replaces what could not be read, as the notice says. The earlier text survives only in
      the file's own history.
    - Only the saved-file opening path was tested. Browser storage, the shared folder's copy, a PMO copy and a batch import
      carry the same stored value to the same readers, but were not opened here.
    - Not covered either: a locked-cycle view; Chromium (jsdom only); whether the longer label fits the 1,280-pixel chart
      image.
