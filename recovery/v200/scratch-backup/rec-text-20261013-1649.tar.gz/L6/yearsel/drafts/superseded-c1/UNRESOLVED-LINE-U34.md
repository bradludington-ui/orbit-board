  - **U34: built as its own commit** (Codex's review, as Brad supplied it, 12 Oct: "the malformed saved-year selection"): a
    saved year selection the board did not write is read as no year, kept as saved, and said on the panel and in the
    export; it is never read as ALL YEARS or as a year it does not name (above). Its limits are under "Not covered": a whole
    number that is no plausible year, an enormous list of distinct whole numbers, and the saved appropriation selection,
    which still reads a malformed value as all appropriations with nothing said.
