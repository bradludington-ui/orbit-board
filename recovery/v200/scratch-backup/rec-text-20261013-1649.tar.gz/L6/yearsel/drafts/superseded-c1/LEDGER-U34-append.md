Text to append to the U34 row of recovery/v200/UNRESOLVED-LEDGER.md.

"Evidence so far" column, appended:

**Measured on the base, 12 Oct, 7:34–7:43 PM ET** (records head `7ee498a`, board `fce8a391` = U14 `d66dd60`;
`rec/L6/yearsel`, probes P1 and P2). Each shape was opened from the board's own saved file (`boot({html})`).
- **Read as ALL YEARS ($540M on the fixture, ALL YEARS lit, no notice):** a string ("2026" or "2027"), an object ({} or
  {"0":2027,"length":1}), a bare number (2027), true, an empty list, [2026.5], ["FY27"] and 5,000 × "x".
- **Read as a year the file does not name:** ["2027"] and [[2027]] counted as FY27 ($500M). [null] and [""] were said as a
  saved "FY0", and [true] as "FY1".
- **One whole year counted, the bad entry silently dropped:** [2025, 2026.5] ($40M), [2027, "x"] and ["<b>x</b>", 2027].
- **Duplicates and an unsorted list** were read correctly.
- **Whole numbers that are no plausible year** were given U14's notice, printed by their last two digits: -2027 as FY-27,
  10000 as FY0, 99999 as FY99 (the export prints them whole).
- **Enormous lists:** 20,000 distinct numbers produced a 118,370-character notice, and each calculation took about 1.6 s.
- **No crash and no money mismatch:** in every shape, the calculation, the panel and the exported workbook agreed.
- **The value was written back byte for byte** through the save and the reopen.

"Status" column, appended:

**P2 (no money mismatch, no loss: a silent misreading of a hand-edited or damaged file, the kind Brad's U14 decision
forbids).** **Fix built and measured (12 Oct, 7:41–8:31 PM ET; `rec/L6/yearsel`).**
- **The fix:** only no saved selection (null, or no key) is ALL YEARS, and a year is a whole number. Anything else is read as
  no year, not counted, kept as saved, and said: in the scope label, in a panel notice quoting the file (escaped), and in an
  export NOTE. A click on the year buttons chooses again and replaces what cannot be read.
- **The block:** 22 checks. 13 fail on `d66dd60`, and all pass after. U14's 63 checks pass unchanged.
- **Mutations:** 12, each caught.
- **Other runs:** audit-recon's 306 recorded checks keep the same verdict and value. audit, audit-ppt, audit-other,
  audit-hostile, audit-inject, boot-same, legacy-fsrc and npm run check pass on both boards.
- **The catalog**, counted as text: 1,340 / 1,340.

**COMMITTED as `<sha>` (<time>)**: board `a67635bb`, audit-recon `98758fe5`, mutate `bb57fce8`, after `d66dd60`. Limits,
stated in NEXT-VERSION.md's "Not covered" and for the evidence matrix:
- whole numbers that are no plausible year are still read as years, printed by their last two digits on the panel;
- an enormous list of distinct whole numbers is still named in full and is slow to read;
- the saved appropriation selection (`aps`) still reads a malformed value as all appropriations with nothing said (measured
  on the base, unchanged; same class, not this finding);
- only the saved-file opening path was tested;
- jsdom only.
