Text to append to the U34 row of recovery/v200/UNRESOLVED-LEDGER.md (line 67 at `60336a0`, and still line 67 at `cadc4aa`, `c8a8603` and `3841339`).
It replaces the drafts of 12 Oct, 8:32 PM ET (kept in drafts/superseded-c1/) and of 13 Oct, 5:39 AM ET (kept in drafts/superseded-c2/).

"Evidence so far" column, appended:

**Measured on the base, 12 Oct, 7:34–7:43 PM ET** (records head `7ee498a`, board `fce8a391` = U14 `d66dd60`;
`rec/L6/yearsel`, probes P1 and P2), and in the verifiers' two rounds (13 Oct, 11:46 PM–12:15 AM and 4:14 AM ET; 9:35–10:48
AM ET). Each shape was opened from the board's own saved file (`boot({html})`).
- **Read as ALL YEARS ($540M on the fixture, ALL YEARS lit, no notice):** a string ("2026" or "2027"), an object ({} or
  {"0":2027,"length":1}), a bare number (2027), true, "", 0, false, an empty list, [2026.5], ["FY27"] and 5,000 × "x".
- **Read as a year the file does not name:** ["2027"] and [[2027]] counted as FY27 ($500M). [null] and [""] were said as a
  saved "FY0", and [true] as "FY1".
- **One whole year counted, the bad entry silently dropped:** [2025, 2026.5] ($40M), [2027, "x"] and ["<b>x</b>", 2027].
- **Partner and FMS money:** with FY25 International Partner $3M and FY27 FMS $2M typed in, "2026" read as ALL YEARS and
  counted both: $545M (13 Oct, 12:04 PM ET, FR4-focused-on-base).
- **Duplicates and an unsorted list** were read correctly.
- **Whole numbers that are no plausible year** were given U14's notice, printed by their last two digits: -2027 as FY-27,
  10000 as FY0, 99999 as FY99 (the export prints them whole). [2025, 2125] reads "saved FY25 not available" (U-new-fy2).
- **Enormous lists:** 20,000 distinct numbers produced a 118,370-character notice, and each calculation took about 1.6 s.
- **Deep nesting:** at every depth tried from 3,654 to 4,153 lists deep (not at 3,154) the board opened but the
  funds-flow calculation threw (stack overflow); from about 4,150 deep the board does not open (4,154 opened in one boot
  and not in the next; 13 Oct, 4:41 AM ET, FR-depth-on-base).
- **Not JSON:** a saved NaN makes the whole saved state unreadable, and the opening's warning is replaced in the same
  opening (U-new-nan; the same on the base and after the change).
- **No money mismatch:** in every shape that calculated, the calculation, the panel and the exported workbook agreed.
- **The value was kept as the same value** through the save and the reopen (JSON's: spaces dropped, -0 as 0, 1e999 as null).

"Status" column, appended:

**P2 (no money mismatch, no loss: a silent misreading of a hand-edited or damaged file, the kind Brad's U14 decision
forbids).** **Fix built and measured (12 Oct, 7:41–8:31 PM ET), reviewed by two verifiers twice (13 Oct, 11:46 PM–4:15 AM
ET and 9:35–10:48 AM ET), and corrected in two fix rounds (13 Oct, 4:35–5:39 AM ET and from 11:57 AM ET; `rec/L6/yearsel`).**
- **The fix:** only no saved selection (null, or no key) is ALL YEARS, and a year is a whole number. Anything else is read as
  no year, not counted, kept as saved, and said: in the scope label, in a panel notice quoting the file (escaped), and in an
  export NOTE. A selection holding what the board cannot read is never ALL YEARS: not the chip, not the label. The quote is
  cut between characters at 40, and every U+FFFE / U+FFFF is quoted as its escape, so the export stays a well-formed
  workbook. A click on the year buttons chooses again and replaces what cannot be read.
- **The verifiers' first-round must-fix (fixed in the first fix round):** commit 1 alone quoted U+FFFE / U+FFFF raw into
  the export (a workbook that is not well-formed) and could cut an emoji in half; and it lit ALL YEARS beside an entry it
  could not read when the other years were every year offered.
- **The verifiers' second round (fixed in the second fix round, tests and words only; the board is unchanged):** the
  drafts' "only no saved selection is ALL YEARS" did not hold for a whole value of 1e999 (null by the time the board reads
  it), and the drafts did not name what NaN does; both are now stated (limits below; U-new-nan). Six plausible wrong fixes
  passed every check: escaping only the first forbidden character, cutting a 40-character quote or not cutting a
  41-character one, reading a year as four digits or above zero, and counting partner and FMS money for every year beside
  an entry the board cannot read. Five checks and six mutations now pin them.
- **The block:** 39 checks. 28 fail on `d66dd60`; the other 11 pass there by design (eight controls, two click controls,
  "nothing asked"); 6 fail on commit 1 alone; all 39 pass after. U14's 63 checks pass unchanged.
- **Mutations:** 33, each caught.
- **Other runs:** audit-recon's 306 recorded checks keep the same verdict and value. audit, audit-ppt, audit-other,
  audit-hostile, audit-inject, boot-same, legacy-fsrc and npm run check pass.
- **The catalog**, counted as text: 1,361 / 1,361.

**COMMITTED as `<sha>` (<time>)** [and `<sha2>` (<time2>), `<sha3>` (<time3>) if the three commits land separately]: board
`593593a4`, audit-recon `2d34269d`, mutate `ba8b55ad`, after `d66dd60`. Limits, stated in NEXT-VERSION.md's "Not covered"
and for the evidence matrix:
- whole numbers that are no plausible year are still read as years (the FY1999 and -2027 controls pin that a year need not
  be in 2000–2099, have four digits, or be above zero), printed by their last two digits on the panel;
- a whole number a century off an offered year is printed as that year by U14's label and notice: its own row, U-new-fy2;
- an enormous list of distinct whole numbers is still named in full and is slow to read; the saved list sorts as text;
- "kept" is the same value, not the same bytes; 1e999 is null by the time the board reads it -- quoted as "null" and
  written back as null as an entry, read as ALL YEARS with nothing said as the whole value; a decimal that is a whole year
  to a number's precision is that year;
- a saved NaN makes the whole saved state unreadable, and the opening's warning is replaced in the same opening: its own
  row, U-new-nan;
- U+FFFE / U+FFFF are quoted as their escape, not as the character the file holds;
- a selection nested about 4,150 deep or more stops the board opening (jsdom; the same before);
- the saved appropriation selection (`aps`) still reads a malformed value as all appropriations with nothing said, and
  counts money from appropriations the file does not name: its own row, U-new-aps;
- other saved text holding U+FFFF (prime-match tokens, category names) still makes the funds-flow export not well-formed:
  its own row, U-new-xml (the same writer gap as U37);
- the suite opens the saved file only (a probe also reopened from browser storage); how the board writes the selection
  was checked from `09cf071` on;
- jsdom only.
