# YEARSEL (U34) — independent adversarial verifier, round 1, LENS A (data loss and money)

Verified 12–13 Oct 2026, 11:39 PM – 12:12 AM ET, in this directory only, and resumed at 4:12 AM ET on 13 Oct after a usage
limit (one more probe, VR1, at 4:14 AM ET; see "Resumed" below). Every run was made between 11:46 PM and 12:10 AM ET, or at 4:14 AM ET.
**Nothing was edited, staged, committed or pushed in `/home/user/orbit-board` or `/home/user/orbit-ui`.** Both were only read
(`git log`, `git show`, `grep`). My scratch clone `gitclone/` (`git clone --shared`, checked out at `7ee498a`) had c2's three
files copied over for `npm run check`; nothing was committed there. `mutate.mjs` was never imported or run: it was read as text
by `rec/bin/mcount.py` and `rec/bin/mkmut.py` (`python3 -I`). The builder's files were not edited.

Object verified: the builder's c1 (`rec/L6/yearsel/c1`): board `a67635bb`, audit-recon `98758fe5`, mutate `bb57fce8`
(blobs re-hashed here, equal to the builder's). Base: `rec/L6/base` (board `fce8a391`, audit-recon `529e36f7`, mutate `cbc6defc`).

## Verdict: sound with issues — ONE must-fix (a new corrupt-export path), fix built and measured here as c2

The reader change is right and does what the builder says: I reproduced the 13 base failures, the 85/85 pass on c1, U14's
63 checks unchanged, and three of the twelve mutants (blobs equal to the builder's). Money matched across the calculation, the
panel and the exported TOTAL FUNDING lines in every shape I opened (17 shapes, plus 6 operations and 4 clicks). The malformed
value was kept byte for byte through save, reopen, and six unrelated saving operations (layout, axis, events, an appropriation
toggle, ALL appropriations, the carry-over switch). No recorded check changed.

### MUST-FIX 1 — the quoted saved entry can make the funds-flow export a workbook that is not well-formed XML (new in c1)

`flowUnreadSaved()`'s quote `q` writes the file's text into the export NOTE without the two characters XML 1.0 forbids that
`JSON.stringify` leaves alone (U+FFFE, U+FFFF), and it cuts at 40 UTF-16 units, so it can cut an emoji in half.
`_xesc` (the XLSX writer's escape) escapes only `& < > "`.

Reproduction (probe VP2, check VC1; U14's no-plan fixture; `flow.fys` replaced as text in the saved file, opened with
`boot({html})`, `exportFlow()` bytes kept and parsed by expat, `xmlcheck.py`):

| saved `fys` (file text) | base `fce8a391` export | c1 `a67635bb` export |
|---|---|---|
| `["￿",2027]` | well-formed | **`xl/worksheets/sheet1.xml`: not well-formed (invalid token), line 1, column 1017** |
| `"￾"` | well-formed | **not well-formed (invalid token), line 1, column 1003** |
| `["😀"×25,2027]` | well-formed | well-formed, but the NOTE says `…😀�…` — a character the file does not hold; the panel shows a lone surrogate |

The base never quotes the selection, so the same file exported a well-formed workbook before this commit. The board's own
lenient `xlsxRead` reads the bad sheet back, which is why the builder's 22 checks did not see it.

**Minimal fix (c2 = c1 + this; `diffs/c2-board-vs-c1.diff`, blob `0449ccc1`):**

```diff
+// Cut between characters, never inside one, and U+FFFE / U+FFFF quoted as the file's own escape: XML 1.0 forbids both, so
+// the export's sheet holding one is not well-formed.
 function flowUnreadSaved(){
-  const v=flowCfg().fys, q=x=>{ const t=String(JSON.stringify(x)); return t.length>40? t.slice(0,40)+'…' : t; };
+  const v=flowCfg().fys, q=x=>{ const t=Array.from(String(JSON.stringify(x)).slice(0,82).replace(/[￾￿]/g, c=>'\\u'+c.charCodeAt(0).toString(16)));
+    return t.length>40? t.slice(0,40).join('')+'…' : t.join(''); };
```

(`slice(0,82)` before `Array.from` keeps the work bounded: a first draft without it took 228 ms per calculation on a 3 MB
saved object, against 58 ms on c1; with it, 29 / 14 ms.) c2 board `28e73898`.

Measured on c2: VC2 4/4 pass (VC1: 3 fail on c1, 4 fail on base — the base has no notice at all); VP4 every exported workbook
well-formed (11 shapes); VF2 the builder's focused harness 85/85 (U14 63, U34 22); VS2 audit-recon ALL CHECKS PASSED, 328
recorded checks, 0 differ from the builder's c1 S2 run; VN2 `npm run check` all checks passed (VN1 base likewise; the only
differences are the line counts, 29650 → 29684 main-script lines).

**Proposed test** (`probe/vcheck-block.mjs.txt`, blob `01743a8f`; to be folded into the U34 block in its house form):
4 checks, literals — U+FFFF in an entry; U+FFFE as the whole value; 45 emoji (cut after the quote and 39 emoji, no U+FFFD in
any part); CONTROL 50 × "a" (cut at 40 as before). Each also checks the workbook's parts for XML-forbidden characters and
U+FFFD, and that the value is kept on save.

**Proposed mutation entries** (in `c2/tools/export-audit/mutate.mjs.txt`, blob `45d966e3`, before the R3 line;
`diffs/c2-mutate-vs-c1.diff`): `v200-yearsel-quote-xml-unsafe`, `v200-yearsel-quote-splits-char`, `v200-yearsel-quote-uncut`.
mcount (text): c2 catalog on c2 board 1343/1343 once; c1 catalog on c2 board 1340/1340. Each mutant made by `mkmut.py`
(1 match) and caught: VM5 2 failing (U+FFFF, U+FFFE), VM6 1 failing (45 emoji), VM7 2 failing (45 emoji, CONTROL).

**How old the class is (VR1, resumed 4:14 AM ET):** the forbidden-character problem itself is older than U34. On the base, a
saved prime-match token holding U+FFFF (`flow.rules.lm = "LOCKHEED\uFFFF"`) already makes `xl/worksheets/sheet1.xml` not
well-formed (expat: invalid token, line 1, column 10493), and a saved OGC category name holding it breaks both
`xl/workbook.xml` (it is a sheet name; column 404) and `sheet1.xml` (column 6582); c1 and c2 alike. The same saved file with
`fys = ["\uFFFF", 2025]` exports WELL-FORMED on the base and c2, and NOT well-formed on c1 (column 979). So c1 adds a new path
into a known-bad writer for a file that exported cleanly before -- that is the must-fix -- and c2 closes only that path. The
writer's own gap (`_xesc` passes U+FFFE/U+FFFF; the board's IDS export already refuses them, `IDS_BADCH`, line 13314) is a
separate, pre-existing row (should-fix 4).

## SHOULD-FIX

1. **The 40-character cut is not pinned by any check.** My mutant (c1 with `t.length>40`/`slice(0,40)` → 4000) passes all 85
   checks (VM1). The proposed CONTROL check catches it (VM4).
2. **The appropriation sibling should be its own ledger row, with its money stated.** On a board where FULL FUND has $7M of
   FY25 rows beside O&M's $40M (VA1, c1; `flowSelAppns` is unchanged from the base): saved `aps` `"om"`, `[]`, `["xx"]` or
   `{"0":"om"}` count **$47M, "all appropriations"**, with nothing said; `["om","xx"]` drops `"xx"` silently ($40M). The drafts
   carry it only as a U34 limit, without the money effect ("This was measured on d66dd60 and is unchanged here").
3. **Drafts' "Not covered" / ledger text to add:** U+FFFE/U+FFFF quoted as escapes (if the fix lands); a saved selection
   nested ~20,000 deep stops the board opening at all (RangeError at boot) on the base and the fix alike (VD1, pre-existing);
   `1e999` in an entry is Infinity, quoted as `null`, and written back as `null` on the next save (`JSON.stringify`, as on
   the base); and that only versions from `09cf071` on were checked for how they write `fys` (all write numbers).

4. **Record the pre-existing writer gap as its own ledger row** (not in U34's scope): the funds-flow export writes saved
   prime-match tokens and OGC category names through `_xesc`, which passes U+FFFE/U+FFFF, so a damaged saved file makes a
   workbook Excel must repair -- on the base, c1 and c2 alike (VR1). The board already refuses these characters in the IDS
   export's reason (`IDS_BADCH`). The U34 drafts' "Not covered" should say this, so U34's c2 fix is not read as covering it.

## MINOR

- **ALL YEARS is lit beside the U34 notice** when the readable years name every offered year: `[2025,2027,2028,2029,2030,2031,"x"]`
  lights ALL YEARS, the label says "· all years", and the notice says "this total counts FY25, FY27, …, FY31 only" (VP2 ALLX).
  The money is right ($540M) and the base does the same for the well-formed list (WHOLE-ALL control), but the drafts' "never
  read as ALL YEARS" is not literally true of the chip, and no check pins it either way (my variant with `&& !F.unread` on the
  chip passes all 85, VM3).
- **NOTE order (U14's above U34's) is unpinned:** swapping the two splices passes all 85 (VM2). No check has both notices.
- Process: the builder self-reports unbounded read-only commands and unbounded wrapper scripts (its README §11). Mine are below.

## Every run (all through `run.sh`: `setsid -w timeout -k 10 600`, lock checked first — never present — PIDs in `pids.txt`)

| label | start ET | exit | wall s | result |
|---|---|---|---|---|
| VP1-probe-on-base / -c1 | 11:46:10 PM | 1 / 1 | 2.7 / 2.7 | harness could not import jsdom (boot.mjs copied, not linked); fixed, re-run as VP2 |
| VP2-probe-on-base | 11:46:43 PM | 0 | 59.4 | 11 shapes + ops + clicks; all exports well-formed |
| VP2-probe-on-c1 | 11:46:43 PM | 0 | 63.7 | FFFF / FFFE-whole exports not well-formed; EMOJI has U+FFFD; INF quoted "null"; ALLX ALL YEARS lit; ops keep `"2026"` |
| VC1-check-on-base / -c1 / -c2 | 11:51:33 PM | 1 / 1 / 0 | 22.5 / 22.7 / 21.2 | 4 fail / 3 fail / 4 pass (first c2 draft) |
| VP3-probe-on-c2 | 11:51:33 PM | 0 | 67.6 | first c2 draft: all well-formed; BIGOBJ 228 ms |
| VA1-aps-on-c1 | 11:52:54 PM | 0 | 35.0 | aps sibling: $47M for "om", [], ["xx"] |
| VF1-focused-on-c2 | 11:52:54 PM | 0 | 145.8 | first c2 draft: 85/85 |
| VM1-cut4000-focused | 11:52:54 PM | 0 | 149.3 | mutant survives 85/85 (gap) |
| VS1-audit-recon-c2 | 11:55:47 PM | 0 | 291.5 | first c2 draft: 328, 0 differ |
| VM4-cut4000-vcheck | 12:00:52 AM | 1 | 11.9 | caught: 4 failing |
| VM2-noteorder-focused | 12:00:52 AM | 0 | 82.9 | survives 85/85 (gap) |
| VM3-allyears-unread-focused | 12:00:52 AM | 0 | 86.7 | 85/85 (chip unpinned) |
| VC2-check-on-c2 | 12:03:18 AM | 0 | 8.9 | final c2: 4/4 |
| VP4-probe-on-c2 | 12:03:18 AM | 0 | 21.6 | final c2: all 11 exports well-formed; BIGOBJ 29/14 ms |
| VF2-focused-on-c2 | 12:03:18 AM | 0 | 47.5 | final c2: 85/85 |
| VN1-check-base / VN2-check-c2 | 12:04:26 / 12:04:30 AM | 0 / 0 | 4.6 / 4.9 | all checks passed |
| VS2-audit-recon-c2 | 12:04:42 AM | 0 | 145.1 | final c2: ALL CHECKS PASSED, 328, 0 differ |
| VM5 / VM6 / VM7 (quote mutants, vcheck) | 12:07:47 AM | 1 / 1 / 1 | 8.0 / 7.7 / 8.3 | caught: 2 / 1 / 2 failing |
| VF3-focused-on-base | 12:08:15 AM | 1 | 94.6 | 13 failing, all U34 (as the builder says); U14 0 failing |
| VF3-focused-on-c1 | 12:08:15 AM | 0 | 91.9 | 85/85 |
| VM8 toggle-from-all / VM9 number-coerced / VM10 counted-unsaid | 12:08:15 AM | 1 / 1 / 1 | 93.7 / 93.1 / 90.8 | 1 / 3 / 2 failing — the builder's lists; mutant blobs `59781bb5` / `61b983db` / `58d00aba` equal the builder's |
| VD1-deep-on-base / -c1 / -c2 | 12:10:25 AM | 0 / 0 / 0 | 9.3 / 9.1 / 9.4 | depth 1000 fine; 20,000 and 200,000 stop the board booting on all three |
| VR1-rules-on-base / -c1 / -c2 (resumed) | 4:14:43 AM | 0 / 0 / 0 | 7.8 / 7.8 / 7.7 | U+FFFF in saved `rules.lm` / category name: not well-formed on all three (pre-existing); in `fys`: well-formed on base and c2, not on c1 (expat via `xmlcheck.py`, run under `setsid -w timeout`) |

Logs: `logs/<label>.log`; per-check records `out/<label>.checks.jsonl`; exported workbooks `out/xlsx-<copy>/`.
Text-only counts (no node): mcount base/c1 catalogs on base/c1 boards as the builder reported (1340/1340, 1328/1328,
1328/1328, 1329 + 11 missing); c2 catalog on c2 1343/1343.

## PIDs

70 lines in `pids.txt` (each run's `timeout` PID and its child; VR1 added six at 4:14 AM ET). At 12:11 AM ET, and again at
4:14 AM ET after VR1, none of them was present in `/proc`. Nothing was killed.

## Blobs

c2 board `28e73898e9ec158a197e55cefbfdad24f603b775`; c2 audit-recon `98758fe5` (= c1); c2 mutate `45d966e3`;
diffs `c2-board-vs-c1.diff` `0449ccc1`, `c2-mutate-vs-c1.diff` `44f1dc87`; blocks `vprobe` `5dc63738`, `vcheck` `01743a8f`,
`vaps` `c5ee59a5`, `vdeep` `fa4b5338`; harnesses `vprobe.mjs` `42405a94`, `vcheck.mjs` `c0cfeb17`, `vaps.mjs` `b4de6367`,
`vdeep.mjs` `9391374c`, `vrules.mjs` `cabdd56d` (block `probe/vrules-block.mjs.txt` `e9c95256`), focused (the builder's, copied unchanged) `3b2ff2d8`; `runner.mjs` `f851f139` (the builder's, unchanged),
`run.sh` `04c45513`, `batch.sh` `7cb39835`, `pair.sh` `2b30f794`, `xmlcheck.py` `3e970bd1`; my mutants `c1-cut4000` `88b57715`,
`c1-noteorder` `49408317`, `c1-allyears-unread` `dfc824f9`; quote mutants `a7943f70` (xml-unsafe), `2d29e5c7` (splits-char),
`02676f93` (uncut).

## What I did not do, and my rule deviations

- Did not run audit-import, audit-board, Chromium, verify:grid or playwright; did not commit, push or edit orbit-board/orbit-ui.
- Did not re-run all twelve builder mutants (three spot-checked), nor audit, audit-ppt, audit-other, audit-hostile,
  audit-inject, boot-same or legacy-fsrc on c2 (c2 changes one expression inside `flowUnreadSaved`; audit-recon and
  `npm run check` were run on it).
- Did not write the U34 block revision in its house form; the four checks are a proposal in `probe/vcheck-block.mjs.txt`.
- Did not open the file through browser storage, the shared folder, a PMO copy or a batch import.
- Unbounded commands: read-only `cat`/`grep`/`sed`/`ls`/`diff`/`git hash-object`/`uptime`, `cp`/`ln -s`/`mkdir`/`chmod`,
  and short `python3 -I` text scripts (xmlcheck, show, the c2 edits, the mutant writers). One `node --check` (syntax only)
  ran unbounded and before I had checked the lock (the lock was absent when checked a moment later). Two Python heredocs
  refined c2 after `bin/edit-c2.py` (the comment wording, then `slice(0,82)`); the final diff is `diffs/c2-board-vs-c1.diff`.
