# YEARSEL (ledger U34): the malformed saved-year selection — three commits proposed (build + two fix rounds), built and measured on scratch copies

> **FIX ROUND 2, 13 Oct (from 11:57 AM ET) — read "Fix round 2" below first.** The verifiers' second round (both
> "sound-with-issues") found two must-fixes in the drafts' words -- a whole saved value of 1e999 still opens as ALL YEARS
> with nothing said, and the drafts never said that a saved NaN makes the whole saved state unreadable -- and six plausible
> wrong fixes that passed every check. Commit 3 (copy **c3**: board `593593a4`, the same as c2's; audit-recon `2d34269d`;
> mutate `ba8b55ad`) adds five checks and six mutations and corrects the drafts. It makes no board change. The U34 block
> now has **39 checks** (28 fail on `d66dd60`, 6 on c1, 0 on c3) and **33 mutations**, each caught. Where the sections
> below (the build's and the first fix round's) say 34 checks, 27 mutations, "no range is read into a year", "only no
> saved selection is ALL YEARS", or list the drafts and the limits, Fix round 2 supersedes them. They are kept as the record.

> **FIX ROUND, 13 Oct (from 4:35 AM ET) — read "Fix round" below first.** Two verifiers reviewed the build (verdicts
> "sound-with-issues"). The money verifier's must-fix MF1 was real: c1 quotes a saved entry holding U+FFFE / U+FFFF raw into
> the funds-flow export, making a workbook that is not well-formed, and its 40-unit cut can split an emoji. The tests
> verifier showed c1 still lights ALL YEARS (and labels "all years") beside an entry it cannot read when the other years are
> every year offered. Commit 2 (copy **c2**: board `593593a4`, audit-recon `5eac80ea`, mutate `f4e0739f`) fixes both and
> closes the test gaps: the U34 block has **34 checks** (24 fail on `d66dd60`, 5 on c1, 0 on c2) and **27 mutations**.
> **Commit 1 must not land without commit 2**; squashing them is recommended. Where the build's sections below say "one
> commit", "22 checks", "12 mutations", "byte for byte", "never as ALL YEARS" (of c1) or list the drafts and limits, they are
> **superseded** by the Fix round section; they are kept as they were, as the record of the build.

Built 12 Oct 2026, 7:31–8:34 PM ET, by the YEARSEL builder of the v2.00 release workflow. Every run was made between
7:34 and 8:30 PM ET.

**Nothing was edited, staged, committed or pushed in `/home/user/orbit-board` or `/home/user/orbit-ui`.** orbit-board was
only read: `git log`, `git show`, `git ls-tree`, `git status`, `git rev-parse`, the ledger file, and `git clone --shared`
into my own scratch clone. At 8:11 PM ET its HEAD was `60336a0` and `git status --short` printed nothing. The board file
stays the empty template; every fixture is synthetic and made at run time.

**Starting point.** The prompt said an earlier builder might have left work here. `rec/L6/yearsel` did not exist at
7:31 PM ET, so I started fresh. Nothing was kept from an earlier attempt, and nothing of one was re-run.

**The finding is U34 in the ledger.** orbit-board HEAD `60336a0` already has a U34 row, "A malformed saved-year
selection", so the U34 placeholder is the real number. The code comments and the suite block say "U34".

## Verdict (of the build, 12 Oct — SUPERSEDED in part by the Fix round: c1 alone is not to land)

**One commit is proposed.** It is a minimal fix, and it is clearly right by the lead's principles:
- A saved year selection the board did not write is read as **no year**.
- It is **kept as saved**.
- It is **said** on the panel, in the scope label and in the export's NOTE, with what is counted instead.
- It is **never read as ALL YEARS**, and never as a year it does not name.
- Nothing crashes, and the money always matches its label.

The fix is c1. It is cumulative: c1 = base + this commit.

| copy | board | audit-recon | mutate.mjs | other files |
|---|---|---|---|---|
| base (`7ee498a` records head; product `d66dd60`) | `fce8a391` | `529e36f7` | `cbc6defc` | — |
| **c1** | **`a67635bb`** | **`98758fe5`** | **`bb57fce8`** | identical to the base (`diff -rq`: these three only) |

Diffs against the base are in `diffs/`: `c1-board.diff` (+35 −4), `c1-audit-recon.diff` (+163) and `c1-mutate.mjs.diff`
(+38). Appendix A gives them in full.

**Suggested subject:** `v2.00 (U34): a saved year selection the board did not write is read as no year, kept and said --
never as ALL YEARS`

## 1. What the base does (reproduced first; probes P1 and P2; literals; healthy controls)

**The fixture** is U14's no-plan fixture:
- O&M, one service, F1 asking $1,000M;
- base year 2027, FY27 pot $500M, `MS.years` {2027}, the carryover rule off;
- workbook: O&M FY25 'USAF O&M Discretionary', $40M.

The board offers FY25 and FY27–FY31, so ALL YEARS is $540M.

**The method.** The board's own saved file was built (`buildSavedHtml`). Its `pubState` → `appns.om.flow.fys` was replaced as
text, which is what a hand edit or damage leaves. The file was then opened through the board's opening path
(`boot({html})`). Each shape was read in the calculation, the panel (DOM) and the export (the XLSX bytes read back), and
then saved and reopened.

**The writers.** The board writes `fys` in three ways only (verified in every version since the card build `09cf071`):
- `null` (ALL YEARS);
- `[y]` (a year's "only");
- `next.sort()` of the whole years from its own buttons (a toggle, never empty).

Observations: `out/P1-obs.jsonl`, `out/P2-obs-base.jsonl` (summarised by `bin/show-obs.py`).

| shape in the file | base `d66dd60` reads it as | ALL YEARS lit | said? |
|---|---|---|---|
| no key; `null` (controls) | ALL YEARS, $540M | yes | — (correct) |
| `[2027]`, `[2025,2027]` (controls) | FY27 $500M; FY25+FY27 $540M | no | — (correct) |
| `[2026]` (control, U14) | no year counted, $0 | no | U14 notice (correct) |
| `"2026"`, `"2027"`, `{}`, `{"0":2027,"length":1}`, `2027`, `true` | **ALL YEARS, $540M** | **yes** | **nothing** |
| `[]`, `[2026.5]`, `["FY27"]`, 5,000 × `"x"` | **ALL YEARS, $540M** | **yes** | **nothing** |
| `["2027"]`, `[[2027]]` | **FY27, $500M** (a guess, by `Number()`) | no | nothing |
| `[null]`, `[""]` | no year; said as **"saved FY0 not available"** | no | false words |
| `[true]` | said as **"saved FY1 not available"** | no | false words |
| `[2025,2026.5]`, `[2027.5,2025]` | **FY25 $40M**; the bad entry dropped | no | **nothing** |
| `[2027,"x"]`, `["<b>x</b>",2027]` | **FY27 $500M**; the bad entry dropped | no | **nothing** |
| `[2027,2027]`, `[2031,2025,2027]`, `[2027]`×20,000 | read once / in order | no | — (correct) |
| `[-2027]`, `[0]`, `[10000,2027]`, `[99999]`, `[1990]`, `[2040]` | whole numbers: U14 notice | no | as "FY-27", "FY0", "FY0", "FY99", "FY90", "FY40" on the panel and label; whole in the export NOTE |
| 3,000 / 20,000 distinct whole numbers | every offered year counted, $540M; all named | no | notice of 18,070 / 118,370 characters; the calculation and the panel each took 1.3–1.6 s at 20,000 |

**In every shape, on the base:**
- **no crash:** 0 jsdom errors;
- **no money mismatch:** the calculation, the panel's total funding and the exported TOTAL FUNDING (twice) agree;
- **nothing asked:** `window.confirm` was never called;
- **the malformed value is written back byte for byte** through the save and the reopen. The base never rewrites it, so
  it never loses it either.

**The defect is silence.** The value silently becomes ALL YEARS, silently becomes a year the file does not name, or loses an
entry in silence. That is exactly what Brad's U14 decision forbids ("Explicit saved selections must never silently switch to
ALL YEARS").

**Click paths on the base** (probe C-lines):
- ALL YEARS and a year's "only" work.
- **FY27 switched on beside `"2026"` switches FY27 OFF.** The toggle starts from every year, giving $40M. It does the same
  beside `[]` and `[2027.5]`.

**Found in passing (a LIMIT, not fixed here).** The saved **appropriation** selection (`flowCfg().aps`) has the same shape
problem. `"om"`, `[]` and `["xx"]` all read as all appropriations, with nothing said (probe APS-lines, base and c1 alike).
On this fixture the money is unchanged, because only O&M has rows. On a board with other appropriations' rows, more would be
counted than the file names. It is outside U34's finding, so it is left as a stated limit.

## 2. The change (c1): what, and how it meets each principle

The board diff (Appendix A.1), in five places:
1. `flowSavedYears()` (the U14 reader):
   - **only `null` or no key is ALL YEARS** (`if(C.fys==null) return null`);
   - **a year is a whole number** (`flowYearOk`: `typeof y==='number' && Number.isInteger(y)`), with no `Number()`
     coercion;
   - a non-list reads as `[]`, and an empty or all-bad list reads as `[]`, never `null`.
2. A new `flowUnreadSaved()` describes what cannot be read: the whole value (not a list, or an empty one), or the entries
   that are not whole numbers. It quotes at most three, each cut at 40 characters. A new `flowUnreadText()` gives the words
   the panel and the export share.
3. `flowCalc()`: `F.unread`, and a scope-label suffix with no file text in it, because the label also names the export
   file:
   - `· saved year selection not a list of years, not counted`, or
   - `· N saved entr(y|ies) not a year, not counted`.
4. The panel: a `.flowunread` notice under U14's notice, escaped with `esc()`:
   - "The saved year selection is "2026", not a list of years this board can read. It is kept as saved, and nothing is
     counted. Click ALL YEARS, a year’s only, or a year to switch it on or off, to choose again; any of these replaces what
     cannot be read."
   - For entries: "…holds 2026.5, which this board cannot read as a year. It is kept as saved and not counted: this total
     counts FY25 only. …"
5. The export: a NOTE in the panel's words, after U14's NOTE.

`flowSelYears`, `flowUnavailYears`, `flowToggleYear`, `flowOneYear` and `flowAllYears` are **unchanged**. Because the reader
now returns `[]` instead of `null`, a toggle starts from the years the board could read.

**After the change** (`out/P2-obs-c1.jsonl`, `out/P3-obs-c1.jsonl`):
- every malformed shape above reads as no year, or as its whole years only;
- each is said on the panel, in the label and in the export NOTE;
- each is kept byte for byte through the save and the reopen;
- 0 errors;
- the controls are unchanged;
- FY27 switched on beside `"2026"` gives `[2027]`, $500M.

**The lead's principles:**
1. **Never lose a copy.** The malformed value stays in the saved selection, byte for byte, through every read, save and
   reopen (checked for every shape). Only a person's click on the year buttons replaces what cannot be read, and the notice
   says so before the click. U14's kept years still survive a toggle beside it.
2. **Refuse rather than guess.** `"2027"`, `[[2027]]`, `true` and `null` are no longer coerced by `Number()` into FY27,
   FY1 or FY0. Anything that is not a whole number is not read, and is said, quoted as saved.
3. **Money and exports match the computation exactly.** The total is the sum of the years read. The panel's total, the
   calculation and the exported TOTAL FUNDING (both lines) agree for every shape, and so do the Scope line and the NOTE.
   audit-recon's 306 recorded checks are unchanged in verdict and value.
4. **Every word stays true, after the operation too.** The base said ALL YEARS, "FY0" or "FY1" where the file holds
   something else. Now the label, the notice and the NOTE say what is held and what is counted.
   - The tail names the effect of a click ("replaces what cannot be read"), which is true even beside a U14 saved year,
     which a toggle keeps. An earlier draft said "replaces it", which was not true there; it was corrected before the
     final runs (§ 6).
   - After a click, the notice goes (checked).
   - The file's text is shown as text, never as markup (checked).
5. **Smallest change.** Two reader lines change, there are two small new functions, `F` gains one field, and there are one
   label line, one panel block and one export line (+35 −4). No caller changed.
   - Not changed: the `y%100` year printing, the O(n²) de-duplication and the appropriation selection. Each is a stated
     limit.
6. **Existing checks preserved.** No existing check, fixture or expected value was edited.
   - The behaviour that changes concerns values the board never writes. No existing suite sets `fys` to anything but `null`
     or lists of whole numbers (grep over `tools/export-audit/*.mjs`).
   - U14's 63 checks pass unchanged.
   - Every existing catalog entry still matches the c1 board exactly once (1,328 / 1,328).

## 3. Tests: the suite block (audit-recon, after U14's block) — the build's 22 checks; SUPERSEDED: now 34 (FR.3)

`// ==== v2.00 (U34): a saved year selection this board did not write is read as no year, kept as saved and said -- never
as ALL YEARS ====` … `// ==== end v2.00 (U34) ====`. Scenario `'v2.00 (U34) — a saved year selection this board did not
write is never read as ALL YEARS; it is kept and said'`. It follows the v2.00 house form: an async wrapper, `bootMark()` /
`bootRelease(__bm, keep)` / `settleBoards()`, the two-space `const name` line, and `w5Chk`.

**22 checks, every expected value a hand-written literal.** Board helpers give observed values only. Each shape check
compares 19 observed values:
- the stored value, the years read, `[total, executed, planned]` and the label;
- the panel's total, ALL YEARS lit, the lit years, the `.flowunread` notice and U14's notice;
- the export: built, its Scope line, TOTAL FUNDING twice, and its U34 NOTE;
- the file after the save, byte-equal;
- the reopened copy's stored value, years and total;
- questions asked, and errors.

| check (where) | base `fce8a391` | c1 `a67635bb` |
|---|---|---|
| a string `"2026"` | FAIL | pass |
| an object `{}` | FAIL | pass |
| a bare number `2027` | FAIL | pass |
| an empty list `[]` | FAIL | pass |
| a year as text `["2027"]` | FAIL | pass |
| not a whole number `[2026.5]` | FAIL | pass |
| null in the list `[null]` | FAIL | pass |
| true in the list `[true]` | FAIL | pass |
| one whole year, one not `[2025,2026.5]` | FAIL | pass |
| text that is markup `["<b>x</b>",2027]` | FAIL | pass |
| an enormous list (5,000 × `"x"`) | FAIL | pass |
| CONTROL — no key | pass | pass |
| CONTROL — null | pass | pass |
| CONTROL — duplicates `[2027,2027]` | pass | pass |
| CONTROL — out of order `[2031,2025,2027]` | pass | pass |
| CONTROL — an enormous list of one year (2027 × 5,000) | pass | pass |
| CONTROL — a whole year no appropriation offers `[2040]` (U14's notice) | pass | pass |
| text that is markup · escaped (the notice's HTML; only the board's three `<b>`) | FAIL | pass |
| `"2026"`, then FY27 switched on (→ `[2027]`, $500M) | FAIL (`[2025,2028,2029,2030,2031]`, $40M) | pass |
| CONTROL — `[2025, 2026.5]`, then FY27 switched on (→ `[2025,2027]`, $540M) | pass | pass |
| CONTROL — `"2026"`, then ALL YEARS, then FY27's only | pass | pass |
| nothing asked | pass | pass |

The **focused harness** is `harness/c1/focused-u14-u34.mjs`, blob `3b2ff2d8`. It is built by `bin/mkfocused.py` (rec/L3/u14's,
unchanged) VERBATIM from c1's audit-recon: the preamble helpers, U14's block, the U34 block, and the scenario-ran guard. It
runs through `runner.mjs` (rec/L2/u2impl's, unchanged), which asserts the board it booted.

| run | board | checks | result |
|---|---|---|---|
| F2-focused-on-c1 | `a67635bb` | 85 (U14 63 + U34 22) | **ALL CHECKS PASSED** |
| F2-focused-on-base | `fce8a391` (BOARD set) | 85 | **13 FAILING**: the 13 FAILs above; U14 63 / 63 and the 9 controls pass |

## 4. Mutations (catalog entries; mutate.mjs read as TEXT only) — the build's 12; SUPERSEDED: now 27 (FR.6)

There are 12 entries, `{ id, area, what, find, repl }`. They sit in `c1/tools/export-audit/mutate.mjs.txt` before the line
`  // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.`, under a two-line
`// v2.00 (U34, …)` comment. They were written by `bin/mkentries.py` as JSON string literals. Each mutant board was made by
`rec/bin/mkmut.py` (text only), and each was run through the focused harness with BOARD set to the mutant.

| id | caught | failing checks (all U34; U14's 63 pass in every mutant) | mutant board |
|---|---|---|---|
| `v200-yearsel-not-a-list-all-years` | yes, 4 | a string; an object; a bare number; "2026", then FY27 switched on | `71002f1e` |
| `v200-yearsel-nothing-read-all-years` | yes, 10 | a string; an object; a bare number; an empty list; a year as text; not a whole number; null in the list; true in the list; an enormous list; "2026", then FY27 switched on | `988e484b` |
| `v200-yearsel-number-coerced` | yes, 3 | a year as text; null in the list; true in the list | `61b983db` |
| `v200-yearsel-fraction-unsaid` | yes, 2 | not a whole number; one whole year, one not | `5595e6e8` |
| `v200-yearsel-whole-unsaid` | yes, 4 | a string; an object; a bare number; an empty list | `f1b8bf82` |
| `v200-yearsel-label-unsaid` | yes, 11 | the eleven shape checks | `43102e10` |
| `v200-yearsel-panel-unsaid` | yes, 12 | the eleven shape checks; text that is markup · escaped | `dec3b696` |
| `v200-yearsel-export-unsaid` | yes, 11 | the eleven shape checks | `9fd100ab` |
| `v200-yearsel-markup-unescaped` | yes, 2 | text that is markup; text that is markup · escaped | `f8dc397a` |
| `v200-yearsel-counted-unsaid` | yes, 2 | one whole year, one not; text that is markup | `58d00aba` |
| `v200-yearsel-plural-it` | yes, 1 | an enormous list | `f86f4169` |
| `v200-yearsel-toggle-from-all` | yes, 1 | "2026", then FY27 switched on | `59781bb5` |

Per-mutant check lists are in `out/M2-c1-tally.txt` and `out/M2-c1-*.checks.jsonl`. They are identical to the first round's
(`out/M-c1-tally.txt`, run on the superseded first copy; see § 6).

**Text counts** (`rec/bin/mcount.py`, `python3 -I`, mutate read as text):
- c1 catalog on the c1 board: **1,340 / 1,340** once, none missing, multiple or unparsed.
- The base catalog on the c1 board: 1,328 / 1,328.
- The base catalog on the base board: 1,328 / 1,328.
- The c1 catalog on the base board: 1,329 once and 11 missing. The 11 are the new entries, whose finds are new code;
  `-toggle-from-all` finds U14's line.

## 5. Other suites and `npm run check` (base vs the final c1)

Each suite was run from the copy's root, bounded by `run.sh`.

| suite | base | c1 (final) |
|---|---|---|
| boot-same | exit 0 ("identical either way"), 25.8 s | exit 0, 24.5 s |
| legacy-fsrc | exit 0, 7.0 s | exit 0, 8.9 s |
| audit-ppt | ALL CHECKS PASSED, 8.6 s | ALL CHECKS PASSED, 9.8 s |
| audit | ALL CHECKS PASSED, 21.0 s | ALL CHECKS PASSED, 20.3 s |
| audit-inject | ALL CHECKS PASSED, 24.7 s | ALL CHECKS PASSED, 27.0 s |
| audit-hostile | ALL CHECKS PASSED, 123.7 s | ALL CHECKS PASSED, 95.3 s |
| audit-other | ALL CHECKS PASSED, 84.8 s | ALL CHECKS PASSED, 74.2 s |
| audit-recon (full) | ALL CHECKS PASSED, 306 recorded checks, 201.2 s | ALL CHECKS PASSED, 328 recorded checks, 247.2 s |
| `npm run check` (scratch clone `gitclone/` at `7ee498a`) | all checks passed (main script 29,650 lines) | all checks passed (29,681 lines; the only line that differs) |

The audit-recon comparison is `out/cmp-recon-base-c1-final.txt`, made by `bin/cmpchecks.py`:
- 306 checks in common, **0 differing** in verdict or value;
- 0 only in the base;
- 22 only in c1, all U34, all passing.

**For `npm run check`**, the clone is `git clone --shared /home/user/orbit-board`, then `git checkout 7ee498a`. Its board,
audit-recon and mutate blobs were checked equal to the base's. c1's three files were then copied over (`mutate.mjs.txt` as
`mutate.mjs`), giving blobs `a67635bb` / `98758fe5` / `bb57fce8`. Nothing was committed there.

**Not run:** the full audit-import and audit-board (the lead's), Chromium, and verify:grid.

## 6. Decisions, with reasons

- **Fix rather than defer.** The fix is local to the saved-year reader and its words. Every caller already handles a saved
  list with no year (U14's "no year counted"). The behaviour that changes concerns values the board never writes. It closes
  the silent ALL YEARS that Brad's U14 decision forbids.
- **A year is a whole JavaScript number. There is no range check.** The import files rows under any non-zero `parseInt`
  year, so the board can offer, and save, a year such as 27 or 99999. A range would call a board-written selection
  unreadable. Whole numbers outside 2000–2099 keep U14's notice and the board's usual two-digit printing (a stated limit).
- **Strings are not read as years, not even `"2027"`.** The board has never written a string. Reading one would be a guess
  (principle 2), and `Number()` also turns `true`, `null`, `""` and `[2027]` into years.
- **Duplicates and order are read as before, with nothing said.** Reading `[2027,2027]` as FY27 is not a guess, and no
  word becomes false.
- **No file text in the scope label.** The label names the export file. The notice and the NOTE quote the file instead,
  three entries at most, each cut at 40 characters, and the panel escapes them.
- **A click replaces what cannot be read; it is not kept through toggles.** A non-list cannot hold a list of toggled years,
  and keeping junk entries through toggles would need a mixed-type sort. The notice says so before any click, and U14's
  kept years are still kept by a toggle.
- **The enormous-list cost and the appropriation selection are left alone.** A performance check would be machine-timed,
  and so flaky. The `aps` problem is another finding. Both are named as limits.
- **Notice wording corrected once (8:11 PM ET).** The first build's tail said "any of these replaces it". Beside a U14
  saved year that a toggle keeps, "it" (the selection) would not be wholly replaced. The tail now says "replaces what
  cannot be read".
  - The first copy, its diffs, harness and mutants are kept in `superseded/` (`c1-first`, board `97d24ad7`).
  - c1 was rebuilt from the base by the same scripts.
  - Every run was made again on the final c1: F2, M2, S2, N2 and P3.
  - The first round's runs (F1, M, S on c1, N-check-c1, P2-on-c1) stand for the superseded copy only. The base runs
    (P1, P2-on-base, F1-on-base, S-*-base, N-check-base) are unaffected.

## 7. Drafts for the lead (the lead commits; I did not) — SUPERSEDED: the build's drafts are now in `drafts/superseded-c1/`; the current ones are listed in FR.7

- `drafts/NEXT-VERSION-U34.md`: the entry, under v2.00 after U14's, in the style of the U13 / U1 / U14 entries. It covers
  what was wrong, what changes, "What users may see", "Test", "Mutations" and "Not covered".
- `drafts/UNRESOLVED-LINE-U34.md`: "Unresolved after R1–R5" has no U34 line yet, so this is a **new** line, after U14's.
- `drafts/LEDGER-U34-append.md`: text to append to the existing U34 row (line 67 of `recovery/v200/UNRESOLVED-LEDGER.md` at
  `60336a0`), for its "Evidence so far" and "Status" columns, with `<sha>` and `<time>` placeholders. It proposes **P2**:
  no money mismatch and no loss, but a silent misreading.

**LIMITS, for the evidence matrix and "Not covered"** (all measured on both boards, probe P2 / P3):
1. A whole number that is no plausible year (−2027, 0, 1990, 10000, 99999) is read as a year and given U14's notice. The
   panel and the label print it by its last two digits (FY-27, FY0, FY90, FY0, FY99); the export's NOTE prints it whole.
2. An enormous list of distinct whole numbers is named in full: 18,070 notice characters at 3,000, and 118,370 at 20,000.
   The calculation and the panel each take 1.3–1.6 s at 20,000 in jsdom, because the de-duplication is quadratic. The label,
   the Scope line and the export file name carry them all.
3. The saved appropriation selection (`aps`) shaped the same ways reads as all appropriations, with nothing said.
4. A click replaces what could not be read. The earlier text survives only in the file's history.
5. Only the saved-file opening path was tested. Browser storage, the folder copy, a PMO copy and a batch import carry the
   same value to the same readers, but were not opened here.
6. Not covered either: a locked-cycle view, Chromium, and whether the longer label fits the chart image.

## 8. Every run (start ET, exit, wall seconds, log)

Every node run went through `run.sh` (`setsid -w timeout -k 10 600`, its own process group, the lock check, PIDs to
`pids.txt`). The lock `AUDIT_IMPORT_RUNNING` was absent before every run: no run waited and none was skipped. All logs are
in `logs/`. Exit 1 on a focused-on-base or mutant run is the expected failure.

| label | start (ET) | exit | wall s | what |
|---|---|---|---|---|
| P1-probe-on-base | 19:34:22 | 0 | 34.7 | probe v1, base |
| P2-probe-on-base | 19:42:12 | 0 | 56.4 | probe v2, base |
| P2-probe-on-c1 | 19:43:08 | 0 | 60.3 | probe v2, first c1 (superseded) |
| F1-focused-on-c1 | 19:46:31 | 0 | 70.2 | first c1 (superseded): 85 / 85 |
| F1-focused-on-base | 19:47:48 | 1 | 58.0 | base: 13 failing |
| M-c1-v200-yearsel-not-a-list-all-years | 19:50:36 | 1 | 112.0 | first c1 mutant: 4 failing |
| M-c1-v200-yearsel-number-coerced | 19:50:36 | 1 | 113.9 | 3 failing |
| M-c1-v200-yearsel-nothing-read-all-years | 19:50:36 | 1 | 115.5 | 10 failing |
| M-c1-v200-yearsel-panel-unsaid | 19:52:35 | 1 | 116.2 | 12 failing |
| M-c1-v200-yearsel-whole-unsaid | 19:52:35 | 1 | 117.0 | 4 failing |
| M-c1-v200-yearsel-label-unsaid | 19:52:35 | 1 | 118.2 | 11 failing |
| M-c1-v200-yearsel-fraction-unsaid | 19:52:35 | 1 | 119.4 | 2 failing |
| M-c1-v200-yearsel-plural-it | 19:54:38 | 1 | 90.8 | 1 failing |
| M-c1-v200-yearsel-counted-unsaid | 19:54:38 | 1 | 91.2 | 2 failing |
| M-c1-v200-yearsel-toggle-from-all | 19:54:38 | 1 | 93.0 | 1 failing |
| M-c1-v200-yearsel-markup-unescaped | 19:54:38 | 1 | 92.9 | 2 failing |
| M-c1-v200-yearsel-export-unsaid | 19:54:38 | 1 | 94.9 | 11 failing |
| S-boot-same-c1 / -base | 19:56:41 | 0 / 0 | 23.5 / 25.8 | first c1 / base |
| S-legacy-fsrc-base / -c1 | 19:57:07 | 0 / 0 | 7.0 / 8.0 | |
| S-audit-ppt-base / -c1 | 19:57:15 | 0 / 0 | 8.6 / 11.5 | |
| S-audit-base / -c1 | 19:57:30 | 0 / 0 | 21.0 / 22.4 | |
| S-audit-hostile-base / -c1 | 19:57:53 | 0 / 0 | 123.7 / 125.9 | |
| S-audit-inject-c1 / -base | 19:59:59 | 0 / 0 | 23.7 / 24.7 | |
| S-audit-other-c1 / -base | 20:00:27 | 0 / 0 | 83.3 / 84.8 | |
| S-audit-recon-c1 | 20:01:57 | 0 | 261.8 | first c1 |
| S-audit-recon-base | 20:06:25 | 0 | 201.2 | base |
| N-check-base | 20:10:09 | 0 | 7.6 | scratch clone at 7ee498a |
| N-check-c1 | 20:10:34 | 0 | 6.2 | first c1 files in the clone |
| **F2-focused-on-c1** | 20:13:40 | 0 | 90.3 | **final c1: 85 / 85** |
| **F2-focused-on-base** | 20:13:40 | 1 | 90.9 | **base: 13 failing** |
| M2-c1-v200-yearsel-number-coerced | 20:15:19 | 1 | 102.9 | final c1 mutant: 3 failing |
| M2-c1-v200-yearsel-fraction-unsaid | 20:15:19 | 1 | 103.9 | 2 failing |
| M2-c1-v200-yearsel-not-a-list-all-years | 20:15:19 | 1 | 105.8 | 4 failing |
| M2-c1-v200-yearsel-nothing-read-all-years | 20:15:19 | 1 | 106.2 | 10 failing |
| M2-c1-v200-yearsel-whole-unsaid | 20:17:10 | 1 | 117.8 | 4 failing |
| M2-c1-v200-yearsel-label-unsaid | 20:17:10 | 1 | 119.9 | 11 failing |
| M2-c1-v200-yearsel-panel-unsaid | 20:17:10 | 1 | 120.5 | 12 failing |
| M2-c1-v200-yearsel-export-unsaid | 20:17:10 | 1 | 124.0 | 11 failing |
| M2-c1-v200-yearsel-markup-unescaped | 20:19:20 | 1 | 135.4 | 2 failing |
| M2-c1-v200-yearsel-plural-it | 20:19:20 | 1 | 136.0 | 1 failing |
| M2-c1-v200-yearsel-toggle-from-all | 20:19:20 | 1 | 136.9 | 1 failing |
| M2-c1-v200-yearsel-counted-unsaid | 20:19:20 | 1 | 137.3 | 2 failing |
| S2-legacy-fsrc-c1 | 20:21:47 | 0 | 8.9 | final c1 |
| S2-boot-same-c1 | 20:21:47 | 0 | 24.5 | |
| S2-audit-ppt-c1 | 20:22:12 | 0 | 9.8 | |
| S2-audit-c1 | 20:22:12 | 0 | 20.3 | |
| S2-audit-inject-c1 | 20:22:32 | 0 | 27.0 | |
| S2-audit-hostile-c1 | 20:22:32 | 0 | 95.3 | |
| S2-audit-other-c1 | 20:24:12 | 0 | 74.2 | |
| S2-audit-recon-c1 | 20:24:12 | 0 | 247.2 | 328 checks |
| N2-check-c1 | 20:28:38 | 0 | 7.2 | final c1 files in the clone |
| P3-probe-on-c1 | 20:28:45 | 0 | 101.1 | probe v2, final c1 |

The machine was shared with other tracks (load average 12–22 on 4 cores), so wall times vary.

## 9. PIDs

`pids.txt` had 296 PID lines at 8:34 PM ET, and the last edits of this README add a few more through `bx.sh`. Each is a `timeout` PID and its child, with the time, the label and the command, written by
`run.sh` or `bx.sh`.

At 8:30:57 PM ET, `/proc` was read (nothing was signalled). Five recorded PIDs were present: 24868, 24870, 26810, 26815 and
27661. Each recorded command of mine had ended with its exit recorded (`git clone`, `edit-board`, `P2-probe-on-base`). The
live processes under those numbers are other tracks' processes on reused PIDs: Chromium and `node audit-recon.mjs`, with
working directories in `rec/L6/base` and `rec/L6/regtext/gc/c1`. **None of my processes is alive. Nothing was killed.** A second read at 8:34 PM ET found 32106 and 32108 present: also reused numbers, belonging to another track's processes (cwd `scratchpad/uichunk3/p2/fix1/grid/`), while my `bx.sh` calls under those numbers had ended.

## 10. Blobs (git hash-object)

**Deliverables:**
- board `a67635bb533f7b5669d67fcf8400d37b9144fc6c`
- audit-recon `98758fe54bd0d82ae9095d63b736d5004c18c9f0`
- mutate.mjs `bb57fce8e4d9efbb59a93e05e949d01bd8800a49`

**Diffs:**
- `diffs/c1-board.diff` `879f61a1`
- `diffs/c1-audit-recon.diff` `ddf89406`
- `diffs/c1-mutate.mjs.diff` `45a349ec`

**Blocks:**
- `blocks/block-yearsel.mjs.txt` `8ff51199`
- `blocks/entries-yearsel.mjs.txt` `00c28262`

**Harnesses:**
- `harness/c1/focused-u14-u34.mjs` `3b2ff2d8`
- `harness/c1/probe.mjs` `3a6e15d5`
- `harness/base/probe.mjs` `26ab3793`
- `probe/probe-block.mjs.txt` `77e6304d` (v1, used by P1: `e87ea5e0`)

**Tools:**
- `runner.mjs` `f851f139`
- `run.sh` `cb198769`
- `bx.sh` `b88b3db5`
- `bin/edit-board.py` `da2d9071`
- `bin/mkentries.py` `03012c7d`
- `bin/mkfocused.py` `bd72eb11`
- `bin/mkprobe.py` `47dd00c5`
- `bin/insert-block.py` `23cea676`
- `bin/insert-before.py` `9833474d`
- `bin/cmpchecks.py` `1560f4fc`
- `bin/tally.py` `faa4d7da`

Each run log's `IDS` line records the booted board's blob, the harness blob, `boot.mjs`, the shim and the runner.

## 11. What I did not do, and my rule deviations (said plainly)

**Not done:**
- The full audit-import and audit-board.
- Chromium, playwright and verify:grid.
- Any commit or push.
- Any edit in orbit-board or orbit-ui.
- `mutate.mjs` was never imported or run. It was read as text only, by `mcount.py` and `mkmut.py` (`python3 -I`).
- The appropriation-selection problem and the enormous-list cost were measured and named, not fixed.
- No Chromium screenshot of the new notice.

**Commands not bounded by `setsid -w timeout -k 10 600`:**
- Read-only commands run directly: `date`, `ls`, `grep`, `sed`, `head`, `cat`, `wc`, `diff` of my own files, `git
  hash-object`, and `python3 -I -c` one-liners that summarise my own `out/` files.
- Read-only git calls in orbit-board, run directly:
  - at about 7:38 PM ET, two `git log -S`, bounded by `setsid -w timeout -k 10 120` but not through `bx.sh` (their PIDs
    are not in `pids.txt`), and `git log | wc -l`, `git rev-parse` and `git status --short`, unbounded;
  - at 8:11 PM ET, `git log --oneline -3` and `git status --short`, unbounded.
- `mkdir`, `chmod +x`, `ln -s`, the `sed -i` that renamed the mutant labels in my `mutrun.sh`, and `echo >>` lines.

**Wrapper scripts not bounded as a whole:** `mutrun.sh`, `suitepair.sh` and `suites-c1.sh` are not under one 600 s bound.
Each run inside them is its own bounded `run.sh` call, and the wrappers only wait.

**Edits made outside `bx.sh`:**
- My own files were written with the Write tool: the probe, the block, `edit-board.py`, `mkentries.py`, the drafts and this
  README.
- One Python heredoc (about 7:41 PM ET) patched my probe file directly, not under `bx.sh`.
- Every edit to the copies' board, suite and catalog was made by a script under `bx.sh`.

## Fix round (13 Oct, from 4:35 AM ET): the verifiers' must-fix and should-fixes, as commit 2 (c2)

> Superseded in part by **Fix round 2** (below): the counts, the drafts and the limits. Kept as the record.

**Starting point.** The prompt said an earlier attempt of this fix round might have been stopped by a usage limit at about
12:50 AM ET. Nothing of one was in this directory: no file outside `verify-money-r1/`, `verify-tests-r1/` and `wfstate/` was
newer than the build (8:35 PM ET on 12 Oct), the copies' blobs were the builder's (re-hashed at 4:38 AM ET: c1 `a67635bb` /
`98758fe5` / `bb57fce8`, base `fce8a391` / `529e36f7` / `cbc6defc`), and README.md had no "Fix round" section. So nothing
was kept from a stopped attempt, and the fix round started fresh at 4:35 AM ET. The verifiers' own directories were only
read (their verdicts in `wfstate/`, their diffs, probe blocks, logs and READMEs); nothing in them was changed.

**What is proposed now: two commits.** Commit 1 is c1, unchanged from the build. Commit 2 is c2 = c1 + this round. **Commit
1 must not land without commit 2**: on its own it writes a workbook that is not well-formed for a saved entry holding
U+FFFE / U+FFFF (the money verifier's MF1), cuts an emoji in half in the quote, and lights ALL YEARS beside an entry it
cannot read. I recommend squashing the two into one U34 commit (base → c2, `diffs/c2-*-vs-base.diff`); the drafts describe
the final state.

| copy | board | audit-recon | mutate.mjs | other files |
|---|---|---|---|---|
| base (`7ee498a`; product `d66dd60`) | `fce8a391` | `529e36f7` | `cbc6defc` | — |
| c1 = base + commit 1 (unchanged) | `a67635bb` | `98758fe5` | `bb57fce8` | as base |
| **c2 = c1 + commit 2 (this round)** | **`593593a43172e30755f6fca03785a28e5a8c048f`** | **`5eac80eaa8ff24d2a7cde860433624fdd3633c10`** | **`f4e0739ff53f9531b1e2ae21378f2e98580e09ff`** | as base (`diff -rq c1 c2`: these three only) |

**Suggested subject for commit 2:** `v2.00 (U34): the quote of a saved entry is cut between characters and never carries
what XML forbids; a selection holding what the board cannot read is never ALL YEARS`. Squashed: the commit-1 subject.

### FR.1 Every verifier item, and what was done

| item (verifier) | action | evidence |
|---|---|---|
| **MF1** (money): the quote can make the funds-flow export a workbook that is not well-formed (U+FFFE / U+FFFF), and the 40-unit cut splits a surrogate pair (half an emoji on the panel, U+FFFD in the export) | **Fixed** with the verifier's own expression (two lines, plus comment): `Array.from(String(JSON.stringify(x)).slice(0,82).replace(/[\uFFFE\uFFFF]/g, c=>'\\u'+…))`, cut at 40 characters | 3 shape checks (U+FFFF beside 2027, U+FFFE whole, 45 emoji), and every shape's export is now parsed part by part as XML (`w7Pkg`, the suite's own package reader). On c1 the U+FFFF and U+FFFE exports read "unreadable xl/worksheets/sheet1.xml"; on c2 every part reads. expat (the verifier's `xmlcheck.py`): all 11 workbooks of the verifier's probe on c2 WELL-FORMED (`fr/out/xmlcheck-vprobe-c2.txt`). 3 mutations |
| **SF1** (money): no check pins the 40-character cut | **Fixed** | "a long entry" (120 × "A") and the 45-emoji check; `v200-yearsel-quote-uncut` |
| **SF2** (money): the appropriation selection should get its own ledger row with its money | **Recorded, not fixed** (another finding; principle 5) | `drafts/LEDGER-NEW-ROWS.md` row U-new-aps. Re-measured on base and c2 (FR-VA-*): "om", [], ["xx"], {"0":"om"} count **$47M** as all appropriations; ["om"] counts $40M; ["om","xx"] drops "xx" silently. Identical on both |
| **SF3** (money): limits (a) escapes, (b) deep nesting, (c) 1e999, (d) writers checked from `09cf071` | **Stated** in NEXT-VERSION "Not covered" and the ledger text; (b) **measured more exactly** | FR-depth-*: deepest that opens is 4,154 on base and c2 alike; on the base, at every depth tried from 3,654 to 4,153 (not at 3,154), the board opens but the funds-flow calculation throws (stack overflow in `Number()` of nested lists), while c2 reads, quotes and exports every depth that opens (§ FR.4) |
| **SF4** (money): the pre-existing XLSX writer gap (U+FFFF in saved prime-match tokens and category names) as its own row | **Recorded, not fixed** (pre-existing, outside U34; a fix belongs to the writer and its own decision, as `IDS_BADCH` refuses rather than cleans) | `drafts/LEDGER-NEW-ROWS.md` row U-new-xml. FR-VR-* on base and c2: the same three expat errors at the same columns on both (sheet1 col 10493; workbook col 404 and sheet1 col 6582); the year selection holding U+FFFF exports well-formed on both |
| **PRODUCT** (tests): [2025, 2027–2031, "x"] lights ALL YEARS and the label says "all years" | **Fixed** (the verifier's 4 conditions, written so U14's catalog entry still finds its text) | "every offered year beside an entry it cannot read"; 4 mutations (chip, label, label not passed, year chips) |
| **TEST GAP** (tests): no falsy shape | **Fixed** | "", 0, false; `-falsy-all-years`, `-falsy-unsaid` |
| **TEST GAP** (tests): only the Scope line, TOTAL FUNDING and the NOTE are read | **Fixed** | "the export beside the NOTE" ([2027, "x"]'s sheet = [2027]'s row for row but the Scope line, plus NOTE and blank at index 3); `-note-replaces-line` |
| **TEST GAP** (tests): a year U14 says beside an entry; a long entry | **Fixed** | "beside a year U14 says", "· the NOTEs in order", "a long entry"; `-label-unsaid-beside-u14`, `-panel-unsaid-beside-u14`, `-note-order`, `-quote-uncut` |
| minor (tests): the no-range decision is untested | **Pinned** | CONTROL "a year the board offers outside 2000–2099" ([1999] on a board holding $7M of FY1999 rows); `-year-range` |
| minor (tests): 9 of 22 pass on the base by design | **Said** | now 10 of 34 (seven controls, two click controls, "nothing asked") |
| minor (tests): "three click controls" | **Corrected** in the draft | two click controls and "nothing asked" |
| minor (tests): "kept byte for byte" is the same JSON value | **Corrected** everywhere it is still claimed (drafts, block comment, this section); the build's sections above keep their words and are marked superseded | -0 → 0, 2.027e3 → 2027, spaces dropped (verifier VP V12/V13); 1e999 → null |
| minor (tests): "5000 saved entries not a year" | **Corrected** to "not years" | the enormous-list check; `-plural-label` |
| minor (tests): `flowSavedYears` sorts as text | **Stated** (U14's, harmless for four-digit years) | NEXT-VERSION "Not covered" |
| minor (tests): `probe/board-2154832.html` not in the README | **Said here**: the builder's probe left one 2.8 MB board file there at 7:36 PM ET on 12 Oct (a template whose `pubState` is 4 characters; synthetic, nothing of anyone's) | — |
| minor (money): NOTE order not pinned | **Fixed** | "beside a year U14 says · the NOTEs in order"; `-note-order` |
| minor (money): BIGOBJ cost | **Bounded** by the MF1 expression (`slice(0,82)` before the character split); the verifier measured 29/14 ms at 3 MB against 58 ms on c1 | not re-measured here |
| process (both) | my own deviations are in § FR.9 | — |

### FR.2 The board change (commit 2, `diffs/c2-board-vs-c1.diff`, +14 −8)

1. `flowUnreadSaved`'s quote: the MF1 expression, cut between characters (`Array.from`), U+FFFE / U+FFFF quoted as their
   escape, at most 82 UTF-16 units read before the split. Comment extended in the U34 comment above it.
2. `flowScopeLabel(ys, aps, un, ur)`: "· all years" also needs `!ur`; `flowCalc` passes `UR` (its only caller).
3. The ALL YEARS chip also needs `!F.unread`; a year chip is also lit when `F.unread`. The year-chip condition is written
   `((selY.length<yrs.length || F.unavail.length>0) || !!F.unread)` so that U14's catalog entry
   `v200-u14-chips-unlit-beside-unavailable` (find `(selY.length<yrs.length || F.unavail.length>0)`) still matches exactly
   once: my first c2 board (`ffe57b70`, kept in `superseded/fr-c2-board-first/`) wrote it as one list and that entry
   stopped matching (mcount 1,339 / 1,340), so it was rebuilt from c1 by the same script before any final run.
4. The label's plural: "N saved entries not years".

Nothing else changed: `flowSavedYears`, `flowYearOk`, the notice and NOTE wording, the toggles and the export rows are as in
c1. Combined with commit 1 the board diff against the base is +46 −9 (`diffs/c2-board-vs-base.diff`).

**The lead's principles, for commit 2:**
1. **Never lose a copy.** Nothing about what is kept changes: the quote is display only, and every one of the 20 shapes is
   checked kept (the same value) through the save and the reopen, U+FFFF and the 45 emoji included.
2. **Refuse rather than guess.** A selection holding what the board cannot read is no longer called ALL YEARS just because
   the years it can read happen to be every year offered; the years are named and lit instead. Falsy values stay "not a
   list" (tested now).
3. **Money and exports match exactly.** No money changes: the builder's probe gives the same 67 observations on c1 and c2
   apart from timings and the two intended changes (`fr/out/cmp-P3c1-P4c2.txt`). Every shape's export is a well-formed
   package (jsdom's XML parser), expat agrees on the verifier's 11 probe exports, and [2027, "x"]'s sheet is [2027]'s row for
   row but the Scope line and the added NOTE.
4. **Every word stays true.** The label no longer says "all years" beside a notice saying "this total counts FY25, FY27, …
   only"; the quote never shows half a character, nor a U+FFFD the file does not hold; "5000 saved entries not years".
5. **Smallest change.** One expression, four conditions, one argument, one word (+14 −8).
6. **Existing checks preserved.** No check, fixture or expected value in the repository changes: U14's 63 checks pass
   unchanged, audit-recon's 306 recorded base checks keep verdict and value (§ FR.5), and every existing catalog entry
   matches once. Commit 1's own block (not yet in the repository) changes in these places, listed as the rule asks:
   - `tools/export-audit/audit-recon.mjs` c1:5230 → c2:5257, the enormous-list label: old `'no year counted · all
     appropriations · 5000 saved entries not a year, not counted'`, new `'… 5000 saved entries not years, not counted'` --
     the board's wording was corrected (a plural noun with a singular complement).
   - c1:5200–5201 → c2:5219–5221, `want(...)`: one value appended to every shape's expectation, `'ok · every part reads ·
     every count holds'` (the export's package read as XML); no old value changed. `look(...)` returns the matching
     observed value last.
   - `withFys(text)` → `withFys(text, more)`, `look(text)` → `look(text, more)`, `whole(q, text)` → `whole(q, text, stored =
     text)`: optional arguments, every old call unchanged.
   - The block's header comment: "byte for byte" → "(the same value)", and the new shapes in its FAILS ON list.

### FR.3 Tests: the U34 block now has 34 checks

New in the block (12): "an empty string", "zero", "false", "a long entry", "U+FFFF in an entry", "U+FFFE as the whole
value", "45 emoji in an entry", "beside a year U14 says", "every offered year beside an entry it cannot read", "CONTROL — a
year the board offers outside 2000–2099", "beside a year U14 says · the NOTEs in order", "the export beside the NOTE". Every
expected value is a hand-written literal; board helpers give observed values only. Each shape check now compares 20
observed values (the 19 of the build plus the export's package). The focused harness is `fr/harness/c2/focused-final.mjs`
(blob `ecad9b0b`), built by `fr/bin/mkfocused-fr.py` = the builder's `mkfocused.py` plus the suite's own `w7Pkg` / `w7Ok`,
copied VERBATIM.

| check (U34 block) | new in the round | base `fce8a391` | c1 `a67635bb` | c2 `593593a4` |
|---|---|---|---|---|
| a string |  | **FAIL** | pass | pass |
| an object |  | **FAIL** | pass | pass |
| a bare number |  | **FAIL** | pass | pass |
| an empty list |  | **FAIL** | pass | pass |
| a year as text |  | **FAIL** | pass | pass |
| not a whole number |  | **FAIL** | pass | pass |
| null in the list |  | **FAIL** | pass | pass |
| true in the list |  | **FAIL** | pass | pass |
| one whole year, one not |  | **FAIL** | pass | pass |
| text that is markup |  | **FAIL** | pass | pass |
| an enormous list |  | **FAIL** | **FAIL** | pass |
| an empty string | yes | **FAIL** | pass | pass |
| zero | yes | **FAIL** | pass | pass |
| false | yes | **FAIL** | pass | pass |
| a long entry | yes | **FAIL** | pass | pass |
| U+FFFF in an entry | yes | **FAIL** | **FAIL** | pass |
| U+FFFE as the whole value | yes | **FAIL** | **FAIL** | pass |
| 45 emoji in an entry | yes | **FAIL** | **FAIL** | pass |
| beside a year U14 says | yes | **FAIL** | pass | pass |
| every offered year beside an entry it cannot read | yes | **FAIL** | **FAIL** | pass |
| CONTROL — no key |  | pass | pass | pass |
| CONTROL — null |  | pass | pass | pass |
| CONTROL — duplicates |  | pass | pass | pass |
| CONTROL — out of order |  | pass | pass | pass |
| CONTROL — an enormous list of one year |  | pass | pass | pass |
| CONTROL — a whole year no appropriation offers |  | pass | pass | pass |
| CONTROL — a year the board offers outside 2000–2099 | yes | pass | pass | pass |
| beside a year U14 says · the NOTEs in order | yes | **FAIL** | pass | pass |
| the export beside the NOTE | yes | **FAIL** | pass | pass |
| text that is markup · escaped |  | **FAIL** | pass | pass |
| "2026", then FY27 switched on |  | **FAIL** | pass | pass |
| [2025, 2026.5], then FY27 switched on |  | pass | pass | pass |
| "2026", then ALL YEARS, then FY27's only |  | pass | pass | pass |
| nothing asked |  | pass | pass | pass |

| run (final harness `ecad9b0b`) | board | start (ET) | exit | wall s | checks | result |
|---|---|---|---|---|---|---|
| FR3-focused-on-c2 | c2 `593593a4` | 05:12:46 | 0 | 109.9 | 97 | **ALL CHECKS PASSED**: U14 63/63, U34 34/34 |
| FR3-focused-on-base | base `fce8a391` (BOARD set) | 05:12:49 | 1 | 107.6 | 97 | 24 failing, all U34 (the 24 FAILs above); U14 63/63 and the 10 by-design passes pass |
| FR3-focused-on-c1 | c1 `a67635bb` (BOARD set) | 05:14:37 | 1 | 109.4 | 97 | 5 failing: an enormous list (the label wording), U+FFFF in an entry, U+FFFE as the whole value (both "unreadable xl/worksheets/sheet1.xml"), 45 emoji (half an emoji on the panel, U+FFFD in the NOTE), every offered year beside an entry (ALL YEARS lit, "all years") |

The same verdicts, check for check, as the runs on the first block build (FR2-*, harness `c8cc2ed0`): 97 common, 0 differing on each board. Against the build's F2 runs (85 checks), the only verdict that moved is c1's "an enormous list" (the label's new wording); the other differences are the appended package value.

### FR.4 Measured in passing

- **Deep nesting** (FR-depth-on-base / -on-c2, 4:41 AM ET; `fr/probe/depth-block.mjs.txt`): the deepest saved selection
  that opens is **4,154** lists deep on both boards (4,155 stops the board at boot with "Maximum call stack size exceeded"
  -- before U34's code runs). On the **base**, at every depth tried from 3,654 to 4,153 the board opens but `flowCalc` throws the same error (its
  `Number()` of a nested list recurses), so the funds flow cannot be drawn; 3,154 and 2,154 work. On **c2** every depth
  that opens calculates, draws the panel (quoting "[[[[…"), exports and saves. c1 was not run.
- **XML well-formedness in jsdom**: jsdom's `DOMParser` (application/xml) refuses U+FFFF, U+FFFE and U+0001 but reads a
  lone surrogate and U+FFFD (FR-domparser-ffff-2), which is why the emoji check compares the quoted text itself.
- **The builder's probe** (P4 on c2 against P3 on c1): 65 of 67 observations identical but for timings; the two that differ
  are the 5,000 × "x" label ("not years") and [2025, 2027–2031, "x"] (ALL YEARS unlit, the six years lit, no "all years").
- **The verifier's probe** on c2 (FR-VP-vprobe-on-c2): ALLX unlit with the years lit; FFFF / FFFE quoted as escapes;
  INF ([1e999, 2027]) quoted as "null", stored as [null, 2027]; -0 read as 0 (U14's FY0 notice); U14 and U34 notices both
  present, U14's NOTE first; the six unrelated saving operations keep "2026"; all 11 exports WELL-FORMED by expat.

### FR.5 Other suites, audit-recon in full, `npm run check` (final c2)

| suite | c2 (final board `593593a4`) | compared with |
|---|---|---|
| audit-recon (full) | FS2, **ALL CHECKS PASSED**, 340 recorded checks, 229.1 s | the base's 306 (build run S): **306 common, 0 differing**; 34 only in c2, all U34, all passing (`fr/out/cmp-recon-base-c2.txt`). Against c1's 328: the U34 shape checks differ only by the appended package value |
| audit-hostile | FS, ALL CHECKS PASSED, 346.2 s | c1's S2: 124 common, 0 differing (`fr/out/cmp-hostile-c1-c2.txt`) |
| audit-other, audit, audit-inject, audit-ppt, boot-same, legacy-fsrc | FS, each exit 0 (ALL CHECKS PASSED where the suite prints it) | c1's S2 logs: 0 differing lines with timings masked (the build showed c1's equal to the base's) |
| `npm run check` (scratch clone `gitclone/` at `7ee498a`, c2's three files copied over) | FR-N3 and FR-N4 (after the final audit-recon), exit 0, all checks passed | the only differing lines are the sizes: main script 29,650 (base) → 29,681 (c1) → 29,687 (c2) lines |

Every suite ran on the final board. audit-recon ran with the final block (`5eac80ea`). The other seven (FS-*) ran at
4:59–5:06 AM ET; none of them reads the U34 block (only audit-recon changed after they started, at 5:01 AM ET, in comments
and in how two string literals are spelled).

**mcount** (text only, `rec/bin/mcount.py`, `python3 -I`; `fr/out/mcount-final.txt`):
- c2 catalog on the c2 board: **1,355 / 1,355** once, none missing, multiple or unparsed.
- c1 catalog on the c2 board: 1,340 / 1,340. The base catalog on the c2 board: 1,328 / 1,328. Base on base: 1,328 / 1,328.
- c2 catalog on c1: 1,347 once, 8 missing (the new entries whose finds are commit 2's code). On the base: 1,329, 26 missing.

### FR.6 Mutations: 27 entries, each caught (final harness `ecad9b0b`)

The 15 new entries are in `c2/tools/export-audit/mutate.mjs.txt` after the build's 12, before the R3 line, under a two-line
`// v2.00 (U34, the verifiers' round, 13 Oct)` comment, written by `fr/bin/mkentries-fr.py` as JSON string literals. Each
mutant board was made by `rec/bin/mkmut.py` (text only, under `bx.sh`) and run through the final focused harness with BOARD
set to it (`fr/queue-final.sh`).

| id | caught | failing checks (all U34; U14's 63 pass in every mutant) | mutant board |
|---|---|---|---|
| `v200-yearsel-not-a-list-all-years` | yes, 8 | a string; an object; a bare number; an empty string; zero; false; U+FFFE as the whole value; "2026", then FY27 switched on | `1180a4ea` |
| `v200-yearsel-nothing-read-all-years` | yes, 15 | a string; an object; a bare number; an empty list; a year as text; not a whole number; null in the list; true in the list; an enormous list; an empty string; zero; false; a long entry; U+FFFE as the whole value; "2026", then FY27 switched on | `f9ed4a47` |
| `v200-yearsel-number-coerced` | yes, 3 | a year as text; null in the list; true in the list | `ad31d7b8` |
| `v200-yearsel-fraction-unsaid` | yes, 2 | not a whole number; one whole year, one not | `9ffbc199` |
| `v200-yearsel-whole-unsaid` | yes, 8 | a string; an object; a bare number; an empty list; an empty string; zero; false; U+FFFE as the whole value | `37bccd3e` |
| `v200-yearsel-label-unsaid` | yes, 20 | a string; an object; a bare number; an empty list; a year as text; not a whole number; null in the list; true in the list; one whole year, one not; text that is markup; an enormous list; an empty string; zero; false; a long entry; U+FFFF in an entry; U+FFFE as the whole value; 45 emoji in an entry; beside a year U14 says; every offered year beside an entry it cannot read | `8f075c8d` |
| `v200-yearsel-panel-unsaid` | yes, 21 | a string; an object; a bare number; an empty list; a year as text; not a whole number; null in the list; true in the list; one whole year, one not; text that is markup; an enormous list; an empty string; zero; false; a long entry; U+FFFF in an entry; U+FFFE as the whole value; 45 emoji in an entry; beside a year U14 says; every offered year beside an entry it cannot read; text that is markup · escaped | `0ba70227` |
| `v200-yearsel-export-unsaid` | yes, 22 | a string; an object; a bare number; an empty list; a year as text; not a whole number; null in the list; true in the list; one whole year, one not; text that is markup; an enormous list; an empty string; zero; false; a long entry; U+FFFF in an entry; U+FFFE as the whole value; 45 emoji in an entry; beside a year U14 says; every offered year beside an entry it cannot read; beside a year U14 says · the NOTEs in order; the export beside the NOTE | `4f0d7a66` |
| `v200-yearsel-markup-unescaped` | yes, 2 | text that is markup; text that is markup · escaped | `78afa75c` |
| `v200-yearsel-counted-unsaid` | yes, 5 | one whole year, one not; text that is markup; U+FFFF in an entry; 45 emoji in an entry; every offered year beside an entry it cannot read | `db9602b8` |
| `v200-yearsel-plural-it` | yes, 1 | an enormous list | `f0cce367` |
| `v200-yearsel-toggle-from-all` | yes, 1 | "2026", then FY27 switched on | `8a0b4e7b` |
| `v200-yearsel-quote-xml-unsafe` | yes, 2 | U+FFFF in an entry; U+FFFE as the whole value | `db1c25d1` |
| `v200-yearsel-quote-splits-char` | yes, 1 | 45 emoji in an entry | `11bdd79c` |
| `v200-yearsel-quote-uncut` | yes, 2 | a long entry; 45 emoji in an entry | `05c7e9ec` |
| `v200-yearsel-falsy-all-years` | yes, 3 | an empty string; zero; false | `fc41837b` |
| `v200-yearsel-falsy-unsaid` | yes, 3 | an empty string; zero; false | `cc58beea` |
| `v200-yearsel-allyears-lit-unread` | yes, 1 | every offered year beside an entry it cannot read | `523eac2d` |
| `v200-yearsel-label-all-years-unread` | yes, 1 | every offered year beside an entry it cannot read | `facd0499` |
| `v200-yearsel-label-ur-unpassed` | yes, 1 | every offered year beside an entry it cannot read | `e1988c95` |
| `v200-yearsel-year-chips-unlit-unread` | yes, 1 | every offered year beside an entry it cannot read | `3c839bba` |
| `v200-yearsel-note-replaces-line` | yes, 1 | the export beside the NOTE | `90067a2e` |
| `v200-yearsel-note-order` | yes, 1 | beside a year U14 says · the NOTEs in order | `8a1de76b` |
| `v200-yearsel-label-unsaid-beside-u14` | yes, 1 | beside a year U14 says | `2127cba4` |
| `v200-yearsel-panel-unsaid-beside-u14` | yes, 1 | beside a year U14 says | `babbb76d` |
| `v200-yearsel-year-range` | yes, 1 | CONTROL — a year the board offers outside 2000–2099 | `2dafe2ae` |
| `v200-yearsel-plural-label` | yes, 1 | an enormous list | `a31ed17e` |

Every mutant either verifier reported surviving is now a catalog entry, and caught: `vb-falsy-reads-all-years` (=
`-falsy-all-years`), `vb-falsy-unsaid`, `vb-note-replaces-line`, `vb-label-unsaid-beside-u14`, `vb-panel-unsaid-beside-u14`,
`vb-quote-uncut` / the cut-at-4000 mutant, `vb-year-range`, and the money verifier's `quote-xml-unsafe`, `quote-splits-char`,
`quote-uncut`, the note-order swap (VM2) and the ALL YEARS chip (VM3).

**A first batch (FM-*, harness `c8cc2ed0`) is superseded.** It ran the same catalog through the first build of the final
block, whose only differences from the final are comments and two string literals spelled with the raw U+FFFE / U+FFFF
character instead of its escape (the editing tool had written them so; § FR.9). 18 of its runs ended: 15 caught (exit 1);
three (`-panel-unsaid`, `-markup-unescaped`, `-quote-xml-unsafe`) were killed by the memory cgroup's OOM killer (exit 137,
dmesg "Memory cgroup out of memory: Killed process 11350 / 13140 / 19816 (node)", each near 2 GB) -- incomplete, not
results. I then stopped that batch's wrapper (below) and ran every entry again in FM2 at most two at a time.

### FR.7 Drafts (current; the build's are in `drafts/superseded-c1/`)

- `drafts/NEXT-VERSION-U34.md`: the U34 entry for the final state (commit 1 + commit 2, or the squash). If the two commits
  land separately, commit 1 carries `drafts/superseded-c1/NEXT-VERSION-U34.md` and commit 2 replaces it with this one.
- `drafts/UNRESOLVED-LINE-U34.md`: the new U34 line for "Unresolved after R1–R5".
- `drafts/LEDGER-U34-append.md`: the text to append to the U34 row (line 67 at `c8a8603`), with `<sha>` / `<time>`
  placeholders; it proposes **P2**, as before.
- `drafts/LEDGER-NEW-ROWS.md`: **two new rows**, numbers for the lead to assign (placeholders `U-new-aps`, `U-new-xml`): the
  saved appropriation selection (P2, money stated: $47M against $40M) and the funds-flow XLSX writer passing U+FFFF from
  saved prime-match tokens and category names (P2, pre-existing).

**LIMITS, for the evidence matrix and "Not covered"** (all stated in the drafts):
1. Whole numbers that are no plausible year are read as years (no range: pinned by the FY1999 control), printed by their
   last two digits on the panel and label, whole in the export NOTE.
2. An enormous list of distinct whole numbers is named in full and is slow (118,370 characters, 1.3–1.6 s at 20,000);
   the saved list sorts as text (U14's).
3. "Kept as saved" is the same value, not the same bytes: spaces dropped, -0 → 0, 2.027e3 → 2027; 1e999 is read as
   Infinity, quoted "null" and written back as null.
4. U+FFFE / U+FFFF are quoted as their escape, not as the character the file holds.
5. A selection nested 4,155 deep or more stops the board opening (jsdom's stack; as before); at depths tried from 3,654 to 4,153,
   the base's funds flow threw and c2's does not.
6. The saved appropriation selection: U-new-aps. Other saved text with U+FFFF in the export: U-new-xml.
7. A click replaces what could not be read (as the notice says).
8. Only the saved-file opening path; writers checked from `09cf071` on; no locked-cycle view; jsdom only; the label's fit
   in the chart image not checked.

### FR.8 Every run of the fix round (start ET, exit, wall seconds, log)

Every node run went through `run.sh` (`setsid -w timeout -k 10 600`, its own process group, the lock check, PIDs to
`pids.txt`). The lock `AUDIT_IMPORT_RUNNING` was absent before every run: no run waited and none was skipped (no "waiting"
or "SKIPPED" line in `logs/runs.txt`). Exit 1 on a focused-on-base, focused-on-c1 or mutant run is the expected failure.
The machine was shared (load average 17–29 on 4 cores, memory at times under 2 GB free), so wall times vary.

| label | start (ET, 13 Oct) | exit | wall s | log |
|---|---|---|---|---|
| FR-domparser-ffff | 04:40:28 | 1 | 0.3 | `logs/FR-domparser-ffff.log` |
| FR-domparser-ffff-2 | 04:40:33 | 0 | 2.3 | `logs/FR-domparser-ffff-2.log` |
| FR-depth-on-base | 04:41:51 | 0 | 44.2 | `logs/FR-depth-on-base.log` |
| FR-depth-on-c2 | 04:41:51 | 0 | 49.2 | `logs/FR-depth-on-c2.log` |
| FR-syntax-c2-suite | 04:46:25 | 0 | 0.2 | `logs/FR-syntax-c2-suite.log` |
| FR-syntax-c2-focused | 04:46:25 | 0 | 0.2 | `logs/FR-syntax-c2-focused.log` |
| FR1-focused-on-base | 04:46:32 | 1 | 106.3 | `logs/FR1-focused-on-base.log` |
| FR1-focused-on-c2 | 04:46:32 | 0 | 107.2 | `logs/FR1-focused-on-c2.log` |
| FR2-focused-on-c1 | 04:51:48 | 1 | 121.2 | `logs/FR2-focused-on-c1.log` |
| FR2-focused-on-base | 04:51:46 | 1 | 128.4 | `logs/FR2-focused-on-base.log` |
| FR2-focused-on-c2 | 04:51:44 | 0 | 131.4 | `logs/FR2-focused-on-c2.log` |
| FM-v200-yearsel-not-a-list-all-years | 04:54:08 | 1 | 117.8 | `logs/FM-v200-yearsel-not-a-list-all-years.log` |
| FM-v200-yearsel-number-coerced | 04:54:13 | 1 | 122.0 | `logs/FM-v200-yearsel-number-coerced.log` |
| FM-v200-yearsel-nothing-read-all-years | 04:54:10 | 1 | 125.4 | `logs/FM-v200-yearsel-nothing-read-all-years.log` |
| FR-N3-check-c2 | 04:56:19 | 0 | 9.5 | `logs/FR-N3-check-c2.log` |
| FR-P4-probe-on-c2 | 04:55:16 | 0 | 110.8 | `logs/FR-P4-probe-on-c2.log` |
| FR-VA-aps-on-base | 04:57:07 | 0 | 18.9 | `logs/FR-VA-aps-on-base.log` |
| FR-VA-aps-on-c2 | 04:57:26 | 0 | 30.4 | `logs/FR-VA-aps-on-c2.log` |
| FR-VR-rules-on-c2 | 04:57:56 | 0 | 24.0 | `logs/FR-VR-rules-on-c2.log` |
| FR-VR-rules-on-base | 04:58:20 | 0 | 30.3 | `logs/FR-VR-rules-on-base.log` |
| FM-v200-yearsel-fraction-unsaid | 04:56:10 | 1 | 173.1 | `logs/FM-v200-yearsel-fraction-unsaid.log` |
| FM-v200-yearsel-whole-unsaid | 04:56:18 | 1 | 166.7 | `logs/FM-v200-yearsel-whole-unsaid.log` |
| FS-legacy-fsrc-c2 | 04:59:05 | 0 | 15.4 | `logs/FS-legacy-fsrc-c2.log` |
| FM-v200-yearsel-label-unsaid | 04:56:21 | 1 | 181.5 | `logs/FM-v200-yearsel-label-unsaid.log` |
| FS-audit-ppt-c2 | 04:59:24 | 0 | 23.1 | `logs/FS-audit-ppt-c2.log` |
| FS-boot-same-c2 | 04:59:07 | 0 | 43.3 | `logs/FS-boot-same-c2.log` |
| FR-VP-vprobe-on-c2 | 04:59:01 | 0 | 60.3 | `logs/FR-VP-vprobe-on-c2.log` |
| FS-audit-c2 | 04:59:51 | 0 | 27.9 | `logs/FS-audit-c2.log` |
| FS-audit-inject-c2 | 04:59:53 | 0 | 39.7 | `logs/FS-audit-inject-c2.log` |
| FR-syntax-c2-suite-2 | 05:01:02 | 0 | 0.4 | `logs/FR-syntax-c2-suite-2.log` |
| FR-syntax-final | 05:01:02 | 0 | 0.5 | `logs/FR-syntax-final.log` |
| FM-v200-yearsel-panel-unsaid | 04:59:04 | 137 | 335.3 | `logs/FM-v200-yearsel-panel-unsaid.log` |
| FM-v200-yearsel-markup-unescaped | 04:59:25 | 137 | 315.0 | `logs/FM-v200-yearsel-markup-unescaped.log` |
| FM-v200-yearsel-export-unsaid | 04:59:07 | 1 | 348.1 | `logs/FM-v200-yearsel-export-unsaid.log` |
| FS-audit-other-c2 | 05:00:38 | 0 | 268.1 | `logs/FS-audit-other-c2.log` |
| FS-audit-hostile-c2 | 05:00:20 | 0 | 346.2 | `logs/FS-audit-hostile-c2.log` |
| FM-v200-yearsel-counted-unsaid | 05:04:45 | 1 | 158.5 | `logs/FM-v200-yearsel-counted-unsaid.log` |
| FM-v200-yearsel-plural-it | 05:04:47 | 1 | 162.9 | `logs/FM-v200-yearsel-plural-it.log` |
| FM-v200-yearsel-toggle-from-all | 05:05:00 | 1 | 157.9 | `logs/FM-v200-yearsel-toggle-from-all.log` |
| FM-v200-yearsel-quote-xml-unsafe | 05:07:28 | 137 | 166.6 | `logs/FM-v200-yearsel-quote-xml-unsafe.log` |
| FM-v200-yearsel-quote-splits-char | 05:07:30 | 1 | 178.1 | `logs/FM-v200-yearsel-quote-splits-char.log` |
| FM-v200-yearsel-quote-uncut | 05:07:38 | 1 | 177.7 | `logs/FM-v200-yearsel-quote-uncut.log` |
| FM-v200-yearsel-falsy-all-years | 05:10:18 | 1 | 113.3 | `logs/FM-v200-yearsel-falsy-all-years.log` |
| FM-v200-yearsel-falsy-unsaid | 05:10:30 | 1 | 122.9 | `logs/FM-v200-yearsel-falsy-unsaid.log` |
| FM-v200-yearsel-allyears-lit-unread | 05:10:38 | 1 | 126.5 | `logs/FM-v200-yearsel-allyears-lit-unread.log` |
| FR3-focused-on-c2 | 05:12:46 | 0 | 109.9 | `logs/FR3-focused-on-c2.log` |
| FR3-focused-on-base | 05:12:49 | 1 | 107.6 | `logs/FR3-focused-on-base.log` |
| FR3-focused-on-c1 | 05:14:37 | 1 | 109.4 | `logs/FR3-focused-on-c1.log` |
| FM2-v200-yearsel-not-a-list-all-years | 05:16:29 | 1 | 98.4 | `logs/FM2-v200-yearsel-not-a-list-all-years.log` |
| FS2-audit-recon-c2 | 05:14:40 | 0 | 229.1 | `logs/FS2-audit-recon-c2.log` |
| FM2-v200-yearsel-nothing-read-all-years | 05:18:08 | 1 | 52.0 | `logs/FM2-v200-yearsel-nothing-read-all-years.log` |
| FM2-v200-yearsel-number-coerced | 05:18:32 | 1 | 73.9 | `logs/FM2-v200-yearsel-number-coerced.log` |
| FR-N4-check-c2-final | 05:20:05 | 0 | 5.8 | `logs/FR-N4-check-c2-final.log` |
| FM2-v200-yearsel-fraction-unsaid | 05:19:05 | 1 | 86.4 | `logs/FM2-v200-yearsel-fraction-unsaid.log` |
| FM2-v200-yearsel-whole-unsaid | 05:19:49 | 1 | 71.5 | `logs/FM2-v200-yearsel-whole-unsaid.log` |
| FM2-v200-yearsel-label-unsaid | 05:20:33 | 1 | 75.0 | `logs/FM2-v200-yearsel-label-unsaid.log` |
| FM2-v200-yearsel-panel-unsaid | 05:21:01 | 1 | 82.2 | `logs/FM2-v200-yearsel-panel-unsaid.log` |
| FM2-v200-yearsel-export-unsaid | 05:21:50 | 1 | 85.2 | `logs/FM2-v200-yearsel-export-unsaid.log` |
| FM2-v200-yearsel-markup-unescaped | 05:22:28 | 1 | 68.3 | `logs/FM2-v200-yearsel-markup-unescaped.log` |
| FM2-v200-yearsel-counted-unsaid | 05:23:17 | 1 | 55.4 | `logs/FM2-v200-yearsel-counted-unsaid.log` |
| FM2-v200-yearsel-plural-it | 05:23:40 | 1 | 74.0 | `logs/FM2-v200-yearsel-plural-it.log` |
| FM2-v200-yearsel-toggle-from-all | 05:24:13 | 1 | 98.2 | `logs/FM2-v200-yearsel-toggle-from-all.log` |
| FM2-v200-yearsel-quote-xml-unsafe | 05:24:57 | 1 | 107.5 | `logs/FM2-v200-yearsel-quote-xml-unsafe.log` |
| FM2-v200-yearsel-quote-splits-char | 05:25:56 | 1 | 102.1 | `logs/FM2-v200-yearsel-quote-splits-char.log` |
| FM2-v200-yearsel-quote-uncut | 05:26:50 | 1 | 80.8 | `logs/FM2-v200-yearsel-quote-uncut.log` |
| FM2-v200-yearsel-falsy-all-years | 05:27:38 | 1 | 74.8 | `logs/FM2-v200-yearsel-falsy-all-years.log` |
| FM2-v200-yearsel-falsy-unsaid | 05:28:11 | 1 | 81.2 | `logs/FM2-v200-yearsel-falsy-unsaid.log` |
| FM2-v200-yearsel-allyears-lit-unread | 05:28:55 | 1 | 75.6 | `logs/FM2-v200-yearsel-allyears-lit-unread.log` |
| FM2-v200-yearsel-label-all-years-unread | 05:29:34 | 1 | 96.9 | `logs/FM2-v200-yearsel-label-all-years-unread.log` |
| FM2-v200-yearsel-label-ur-unpassed | 05:30:12 | 1 | 111.4 | `logs/FM2-v200-yearsel-label-ur-unpassed.log` |
| FM2-v200-yearsel-year-chips-unlit-unread | 05:31:11 | 1 | 96.9 | `logs/FM2-v200-yearsel-year-chips-unlit-unread.log` |
| FM2-v200-yearsel-note-replaces-line | 05:32:05 | 1 | 69.8 | `logs/FM2-v200-yearsel-note-replaces-line.log` |
| FM2-v200-yearsel-note-order | 05:32:49 | 1 | 51.9 | `logs/FM2-v200-yearsel-note-order.log` |
| FM2-v200-yearsel-label-unsaid-beside-u14 | 05:33:17 | 1 | 48.5 | `logs/FM2-v200-yearsel-label-unsaid-beside-u14.log` |
| FM2-v200-yearsel-panel-unsaid-beside-u14 | 05:33:45 | 1 | 73.8 | `logs/FM2-v200-yearsel-panel-unsaid-beside-u14.log` |
| FM2-v200-yearsel-year-range | 05:34:09 | 1 | 93.1 | `logs/FM2-v200-yearsel-year-range.log` |
| FM2-v200-yearsel-plural-label | 05:35:02 | 1 | 76.3 | `logs/FM2-v200-yearsel-plural-label.log` |

Superseded or incomplete, and why:
- FR-domparser-ffff (exit 1): jsdom not found (the probe file sat outside a `node_modules` path); re-run as -2 with
  `fr/node_modules` linked to orbit-board's (read only).
- FR1-*: the first c2 board `ffe57b70` (its year-chip line broke a U14 catalog entry's find, § FR.2); FR2-* and FR-N3: the
  final board with the first block build (`6f88f9d5`, harness `c8cc2ed0`); FM-*: see FR.6. Each was run again on the final
  files (FR3-*, FS2, FR-N4, FM2-*), with the same verdicts check for check (FR2 vs FR3: 97 common, 0 differing on each board).
- The smaller suites (FS-*) and the probes (FR-P4, FR-VA, FR-VR, FR-VP, FR-depth) ran on the final board; none reads the
  U34 block.

### FR.9 PIDs, deviations, and what I did not do

**PIDs.** Every run's `timeout` PID and its child are in `pids.txt` (with time, label and command), and so are `bx.sh`
calls. Two wrapper PIDs were added by hand: 2742, the first mutant batch's `fr/mutrun.sh FM` (recorded at 5:11 AM ET with
its command line and working directory read from `/proc`, then stopped with one `kill -TERM 2742` -- the only process I
signalled in this round; its in-flight runs were left to finish and did), and 24087, `fr/queue-final.sh`, which records
itself. Nothing was killed by name or pattern; no pkill or killall. At 5:36:51 AM ET, `/proc` was read for the 321 distinct PIDs then recorded in this round (`pids.txt` from line 302): none
was present. At 5:39:33 AM ET, for the 329 then recorded: two were present, 13137 and 13140 -- numbers my run
FM-v200-yearsel-markup-unescaped had used (it ended at 5:04:40 AM ET, exit 137), now reused by another track's Chromium
renderers (`/opt/pw-browsers/chromium-1194/.../chrome --type=renderer`); they were gone a moment later. Not mine; not
touched. Nothing else was signalled.

**Deviations, said plainly:**
- The first mutant batch's wrapper (`fr/mutrun.sh`) and the final queue (`fr/queue-final.sh`), and the waiting loops I
  used to follow them, are not under one 600 s bound; each run inside them is its own bounded `run.sh` call, and the
  wrappers only wait. The wrapper 2742 was not in `pids.txt` when it started; I recorded it before stopping it.
- At 3 runs at once with a 3 GB gate, the memory cgroup's OOM killer killed three of my runs (above) and, in the same
  minutes, several other tracks' Chromium processes were killed too (dmesg shows chrome PIDs with higher OOM scores): my
  ~2 GB runs added to that pressure. The final queue ran at most two at once with a 5 GB gate; no further OOM kill of mine.
- Read-only commands ran directly, unbounded: `date`, `ls`, `grep`, `sed -n`, `cat`, `diff`, `ps`, `free`, `uptime`,
  `dmesg`, `git hash-object`, `python3 -I -c` summaries of my own files; and in orbit-board, read only, `git log
  --oneline -5` / `-1`, `git status --short` and reading the ledger (each under `timeout 20` or plain `grep`/`sed`).
- My own files were written with the Write / Edit tools (the block, scripts, drafts, this README). **The editing tool wrote
  the six characters "\uffff" / "\ufffe" as the raw characters U+FFFF / U+FFFE**, in the block (4 places), two drafts and
  this section's first draft. Found at 5:00 AM ET by `grep` for the bytes; each was rewritten as the escape text by
  `fr/bin/unraw.py` (under `bx.sh`), and later edits that needed the escape went through `fr/bin/edit-tok.py`. In a JS string
  literal both spellings are the same value (so the first harness ran the same checks), but the final files carry no raw
  noncharacter: `grep -c` for the two byte sequences gives 0 in the block, the suite, the drafts and this README (the board
  holds the same one of each as the base, in `IDS_BADCH`).
- Copies' files were changed only by scripts under `bx.sh` (`bin/fr-edit-board.py`, `fr/bin/replace-block.py`,
  `bin/insert-before.py`, `cp`).

**Not done:**
- The full audit-import and audit-board (the lead's); Chromium, playwright and verify:grid; any commit or push; any edit in
  orbit-board or orbit-ui. orbit-board was only read: at about 4:55 AM ET its HEAD was `cadc4aa`, and at 5:31 and
  5:39 AM ET `c8a8603`, with `git status --short` printing nothing. orbit-ui's `git status --short` (read at 5:39 AM ET)
  shows one untracked `node_modules` symlink dated 8:38 PM ET on 11 Oct, before this track existed: not mine.
- `mutate.mjs` was never imported or run: read as text only by `mcount.py` and `mkmut.py` (`python3 -I`).
- U-new-aps and U-new-xml were measured and recorded, not fixed (outside U34; principle 5).
- No range check for "a year" (a decision, now pinned by a control); no change to the enormous-list cost or the text sort.
- The depth probe was not run on c1; the BIGOBJ cost was not re-measured (the verifier's figures are cited).
- No Chromium screenshot of the notice or the lit years.

### FR.10 Blobs of the fix round (git hash-object)

**Deliverables (c2):** board `593593a43172e30755f6fca03785a28e5a8c048f`, audit-recon
`5eac80eaa8ff24d2a7cde860433624fdd3633c10`, mutate.mjs `f4e0739ff53f9531b1e2ae21378f2e98580e09ff`.

**Diffs:** `diffs/c2-board-vs-c1.diff` `ce20006e` (+14 −8); `diffs/c2-audit-recon-vs-c1.diff` `d9342d10`;
`diffs/c2-mutate-vs-c1.diff` `5dc5c982` (+47); against the base (the squash): `diffs/c2-board-vs-base.diff` `a5bca717`
(+46 −9), `diffs/c2-audit-recon-vs-base.diff` `0d8a376f`, `diffs/c2-mutate-vs-base.diff` `835b0bbf` (+85). Appendix B gives
the three c2-vs-c1 diffs in full.

**Blocks:** `fr/blocks/block-yearsel-c2.mjs.txt` `6d804431` (the final U34 block, as in c2's audit-recon);
`fr/blocks/entries-yearsel-fr.mjs.txt` `f8edd0ca` (the 15 new entries).

**Harnesses:** `fr/harness/c2/focused-final.mjs` `ecad9b0b` (final); `fr/harness/c2/focused-u14-u34.mjs` `c8cc2ed0` (first,
superseded); probes `fr/harness/{base,c2}/depth.mjs` `fbcdfff1` / `f63b9bd4`, `fr/harness/c2/P.mjs` `14e25a70` (the builder's
probe block), `fr/harness/c2/vprobe.mjs` `e0546ca6`, `fr/harness/{base,c2}/vaps.mjs` `f63af288` / `847a674a`,
`fr/harness/{base,c2}/vrules.mjs` `6c2e8cf1` / `48b5f154` (the money verifier's probe blocks, unchanged);
`fr/probe/depth-block.mjs.txt` `ab24495d`.

**Tools:** `bin/fr-edit-board.py` `133d383c`, `fr/bin/mkentries-fr.py` `20ff2029`, `fr/bin/mkfocused-fr.py` `b5ce8ce8`,
`fr/bin/replace-block.py` `9f31cde3`, `fr/bin/unraw.py` `2a84e381`, `fr/bin/edit-tok.py` `6ba8b867`, `fr/bin/showfail.py`
`ccd273d3`, `fr/bin/cmpobs.py` `f694742c`, `fr/bin/runtable.py` `5eaf3ce0`, `fr/bin/fillreadme.py` `e46c782d` (fills this section's
tables), `fr/bin/mergereadme.py` `c0cb458c` (merged it here), `fr/mutrun.sh` `64b87f2a` (first batch, stopped), `fr/mutrun2.sh` `a26ba9b3` (written, never run: replaced by
`fr/queue-final.sh` `79e9b174`), `fr/suites-c2.sh` `f95be340`, `fr/probes.sh` `f9e75c28`; unchanged from the build:
`run.sh`, `bx.sh`, `runner.mjs`, `bin/mkprobe.py`, `bin/insert-before.py`, `bin/cmpchecks.py`, `bin/tally.py`.

**Drafts:** `drafts/NEXT-VERSION-U34.md` `fcb77023`, `drafts/UNRESOLVED-LINE-U34.md` `22b1d81a`,
`drafts/LEDGER-U34-append.md` `f49a617a`, `drafts/LEDGER-NEW-ROWS.md` `cff0ecb6`.

**Superseded:** `superseded/fr-c2-board-first/` (the first c2 board `ffe57b70`, its diff, the first block with raw
characters and its audit-recon); `superseded/README-build-0835.md` (this README as the build left it, byte for byte, 60,145
bytes, blob `e4d81529`); `drafts/superseded-c1/` (the build's drafts).

## Fix round 2 (13 Oct, from 11:57 AM ET): the verifiers' second round, as commit 3 (c3)

**Starting point.** The prompt said a stopped attempt of this round might have left work here (the lead stopped the
latest one at about 11:45 AM ET). Nothing of one was in this directory. Outside `verify-money-r2/`, `verify-tests-r2/` and
`wfstate/`, nothing was newer than the first fix round's last write (README.md and `pids.txt`, 5:38–5:39 AM ET), apart from
the directory times of `.` (9:46 AM ET, when the verifiers made their folders) and `gitclone/.git` (9:54 AM ET: a lock file
made and removed, as `git status` does; its HEAD is still `7ee498a` and nothing is committed there). The copies' blobs were
the first fix round's (re-hashed at 12:00 PM ET: base `fce8a391` / `529e36f7` / `cbc6defc`, c1 `a67635bb` / `98758fe5` /
`bb57fce8`, c2 `593593a4` / `5eac80ea` / `f4e0739f`). README.md had the "Fix round" section and no second one; `logs/` and
`pids.txt` had nothing after 5:38 AM ET. So nothing was kept from a stopped attempt, nothing of one was re-run, and this
round started fresh at 11:57 AM ET. No process of mine from earlier rounds was running. The verifiers' folders were only
read; what this round took from them (their measured check, shapes, catalog entries and probes) was copied, and is said
below where it is used.

**The two verdicts.** Both "sound-with-issues". The money verifier's two must-fixes are words: the drafts claimed "only no
saved selection is ALL YEARS", which a whole saved value of 1e999 contradicts (MF1), and they never said what NaN does (MF2).
Its should-fixes are a test gap (partner and FMS money, SF1) and a recorded limit (a century-off year, SF2). The tests
verifier had no must-fix; its should-fixes are three test gaps (SF1–SF3), each with a plausible wrong fix that passed every
check, and the counts that follow.

**What is proposed now: three commits.** Commit 1 is c1 and commit 2 is c2, both unchanged. Commit 3 is c3 = c2 + this
round: **tests and catalog only; the board is c2's, byte for byte** (`diff -rq c2 c3`: audit-recon and mutate.mjs only). I
still recommend squashing all three into one U34 commit (base → c3, `diffs/c3-*-vs-base.diff`); the drafts describe that
final state. Commit 1 must not land without commit 2 (first fix round); commit 3 may land with or after them.

| copy | board | audit-recon | mutate.mjs | other files |
|---|---|---|---|---|
| base (`7ee498a`; product `d66dd60`) | `fce8a391` | `529e36f7` | `cbc6defc` | — |
| c1 = base + commit 1 (unchanged) | `a67635bb` | `98758fe5` | `bb57fce8` | as base |
| c2 = c1 + commit 2 (unchanged) | `593593a4` | `5eac80ea` | `f4e0739f` | as base |
| **c3 = c2 + commit 3 (this round)** | **`593593a43172e30755f6fca03785a28e5a8c048f`** (= c2) | **`2d34269d69be10a5c04772c12796e6b0bda90aaf`** | **`ba8b55adf994892e91e9b009139be566ebe0e458`** | as base |

**Suggested subject for commit 3:** `v2.00 (U34): tests pin every forbidden character of a quote, the 40-character cut's
edge, partner and FMS money, and a year read with no range`. Squashed: the commit-1 subject.

### FR2.1 Every verifier item, and what was done

| item (verifier) | action | evidence |
|---|---|---|
| **MF1** (money): "only no saved selection is ALL YEARS" is false for a whole saved value of 1e999 / -1e999 (null by the time the board reads it: $540M, ALL YEARS lit, nothing said; the first save writes null) | **Corrected in the drafts** (the verifier's corrections A, B, E and F, checked against my own re-run). **No board change** (§ FR2.8 says why) | FP1-probe-on-c3 / -on-base (the verifier's probe, copied unchanged): WHOLE-INF and WHOLE-NEGINF stored null at open, $540M, ALL YEARS lit, no notice, Save writes null, on both boards; all 15 observation keys the same as the verifier's P1 on each board (`fr2/out/cmp-P1-*.txt`) |
| **MF2** (money): a saved NaN makes the whole saved state unreadable; the "do not save over this file" warning is replaced in the same opening | **Recorded**: a new "Not covered" bullet (correction D, quoting the board's own words) and a new ledger row **U-new-nan** (P1 candidate, data loss). **No board change** (outside U34; § FR2.8) | FP2-nan-on-c3 / -on-base: the same observations as the verifier's P2 (fresh browser: the SHELL TEMPLATE line left showing, 0 requirements; the browser holding the board: "No saved state in this copy…", $500M, no FY25 rows), apart from the fixture's save time |
| **SF1** (money): no check covers International Partner or FMS money; mutant `om6` (`(UR? flowYears() : YS)`) passed all 97 | **Adopted verbatim**: the check "partner and FMS money" (before "nothing asked") and the entry `v200-yearsel-other-sources-all-years` | Fails on the base ($3M IP + $2M FMS, $545M beside "2026"); passes on c3; the mutant fails exactly that check |
| **SF2** (money): a saved year a century off an offered year prints as that year ([2025, 2125] says "saved FY25 not available" while FY25's $40M is counted) | **Recorded**: correction C in "Not covered" and a new ledger row **U-new-fy2** (P3, U14's wording) | FP1 CENTURY-PAIR / CENTURY-ONLY on c3 and the base: the verifier's observations, key for key; the storage reopen reads "saved FY25, FY25 not available" |
| minor (money): [2026.9999999999999] is FY27, $500M, nothing said | **Stated** (folded into the "kept as saved" bullet, correction B) | FP1 NEAR-INT: stored [2027], $500M, on both boards |
| minor (money): the drafts say only the saved-file path was tested | **Corrected**: the drafts now cite the probe's storage reopen | FP1: for all 13 parseable shapes, the storage reopen stores the same value and reads the same unread part as the file opening (totals leave out FY25's executed rows, which live in the file only) |
| minor (money): lone surrogates, control characters, U+FFFF in an object key are quoted as escapes; 26 workbooks well-formed | **Re-measured, no action** | expat on my FP1 workbooks: 26 / 26 WELL-FORMED on c3 and 26 / 26 on the base (`fr2/out/xmlcheck-P1-*.txt`) |
| **SF1** (tests): only one forbidden character per quote is tested; `.replace(/[…]/, …)` without `g` passed all 97 | **Adopted verbatim**: the shape "two characters XML forbids in one entry" and the entry `v200-yearsel-quote-escape-first-only` | Fails on the base (counted FY27, nothing said) and on c1 (sheet1 unreadable); passes on c3; the mutant fails exactly that check |
| **SF2** (tests): the edge of the 40-character cut is not pinned (`>=40`, `>41` passed) | **Adopted verbatim**: "a quote of exactly 40 characters", "a quote of 41 characters"; entries `-quote-cut-at-40-or-more`, `-quote-cut-above-41` | Both fail on the base (ALL YEARS $540M); pass on c1 and c3; each mutant fails its own check |
| **SF3** (tests): "no range is read into a year" overclaims; four-digit and above-zero mutants passed | **Adopted**: the control "a whole number no year could be" ([-2027], U14's FY-27 notice) and the entry `-year-four-digits`; **plus** `v200-yearsel-year-positive` (the verifier's `om-year-positive`, which also survived; the same control catches it). "No range" is reworded in the block (header and both controls' promises) and the drafts: a year need not be in 2000–2099, have four digits, or be above zero | The control passes on the base by design, on c1 and on c3; each of the two mutants fails exactly that control |
| counts (tests) | **Updated** in the drafts | 39 checks; 28 fail on `d66dd60`, 11 pass there by design; 6 fail on c1 alone (measured in one harness: FR4-focused-on-c1); 33 mutations; catalog 1,361 / 1,361 |
| minor (tests): the depth wording | **Adopted**: "about 4,150 lists deep or more (in jsdom, 4,154 opened in one boot and not in the next)" | the first fix round's FR-depth logs, as the verifier read them |
| minor (tests): 10 of 34 pass on the base by design | **Said**: now 11 of 39 (eight controls, two click controls, "nothing asked"), as U14's block does | FR4-focused-on-base |
| minor (tests): "the export beside the NOTE" is relational | **Kept as is.** The [2027, "x"] sheet's own values are pinned by literals elsewhere: its Scope line and TOTAL FUNDING ($500M twice) in the by27 shapes, and its $2M FMS / $502M in the partner check | — |
| minor (tests): U34 releases after every shape | **Kept** (the same helper; it keeps memory bounded) | — |
| minor (tests): the builder's P3 probe on c1 was not re-run | **Not re-run**: the board did not change in this round | — |
| process (both) | their own deviations; mine are in § FR2.10 | — |

### FR2.2 The change (commit 3, tests and catalog only)

`diffs/c3-audit-recon-vs-c2.diff` (+37 −8) and `diffs/c3-mutate-vs-c2.diff` (+20 −0); `diffs/c3-board-vs-c2.diff` is
empty. Against the base (the squash): board +46 −9 (as c2), audit-recon +263 −0, mutate +105 −0. Appendix C gives commit 3
in full.

How it was built (text only, under `bx.sh`): `git merge-file` of the two verifiers' measured c3 suites over c2's
(`fr2/blocks/audit-recon-merged.mjs.txt`; their hunks do not overlap, and the merge was clean), then `fr2/bin/mkc3.py`
rewrote the block's header comment, its FAILS ON list and the two controls' promises, and wrote the catalog: the tests
verifier's four entries and the money verifier's one, verbatim, plus `v200-yearsel-year-positive`, under one two-line
`// v2.00 (U34, the verifiers' second round, 13 Oct)` comment before the R3 line. No escape was typed by hand: the script
writes a backslash as `chr(92)`, and `grep` for the raw U+FFFE / U+FFFF bytes gives 0 in the suite, the catalog, the
scripts and the drafts.

**The lead's principles, for commit 3:**
1. **Never lose a copy.** Nothing in the board changes. The new shapes are checked kept (the same value) through the save
   and the reopen, like every shape.
2. **Refuse rather than guess.** Nothing changes in what the board reads; the tests now hold it to not guessing in five more
   places (the second forbidden character, the cut's edge both ways, -2027, partner and FMS money beside "2026").
3. **Money and exports match exactly.** The partner check reads partner and FMS money in the calculation and in the
   exported workbook against literals ($0 beside "2026"; $2M FMS, $502M beside [2027, "x"]). The new quote shapes parse
   every part of the export as XML.
4. **Every word stays true.** The block's and the drafts' words are corrected where they overclaimed: "no range is read
   into a year" (now: it need not be in 2000–2099, have four digits, or be above zero), "only no saved selection is ALL
   YEARS" (now: and 1e999, read as null), and what NaN does.
5. **Smallest change.** No board change; five checks and six catalog entries, the verifiers' own where they measured them.
6. **Existing checks preserved.** No check, fixture or expected value in the repository changes: audit-recon's 306
   recorded base checks keep verdict and value (§ FR2.5), U14's 63 pass, every existing catalog entry matches once. In
   commit 1–2's own block (not yet in the repository), these lines change, listed as the rule asks; no expected value
   changes:
   - `tools/export-audit/audit-recon.mjs` c2:5147 → c3:5147, header: old `-- no range is read into "a year".`, new `-- a
     year need not be in 2000-2099.` (the FY1999 control pins 2000–2099 only; the tests verifier's SF3).
   - c2:5148–5154 → c3:5152–5159, the FAILS ON list: rewritten to add 38 × "B", 39 × "C", the two-character entry, and
     "2026" counting $3M partner and $2M FMS money ($545M); "the seven controls" → "the eight controls".
   - c2:5293 → c3:5303, the FY1999 control's promise (its `what` text, not its expected value): old `(no range is read into
     "a year")`, new `(a year need not be in 2000–2099)`.
   - New lines only, elsewhere: the second round's header (4 lines), three shapes after "45 emoji in an entry", the -2027
     control after FY1999's, and the partner check before "nothing asked".

### FR2.3 Tests: the U34 block now has 39 checks

| check (U34 block) | new in this round | base `fce8a391` | c1 `a67635bb` | c3 `593593a4` (= c2) |
|---|---|---|---|---|
| a string |  | **FAIL** | pass | pass |
| an object |  | **FAIL** | pass | pass |
| a bare number |  | **FAIL** | pass | pass |
| an empty list |  | **FAIL** | pass | pass |
| a year as text |  | **FAIL** | pass | pass |
| not a whole number |  | **FAIL** | pass | pass |
| null in the list |  | **FAIL** | pass | pass |
| true in the list |  | **FAIL** | pass | pass |
| one whole year, one not |  | **FAIL** | pass | pass |
| text that is markup |  | **FAIL** | pass | pass |
| an enormous list |  | **FAIL** | **FAIL** | pass |
| an empty string |  | **FAIL** | pass | pass |
| zero |  | **FAIL** | pass | pass |
| false |  | **FAIL** | pass | pass |
| a long entry |  | **FAIL** | pass | pass |
| U+FFFF in an entry |  | **FAIL** | **FAIL** | pass |
| U+FFFE as the whole value |  | **FAIL** | **FAIL** | pass |
| 45 emoji in an entry |  | **FAIL** | **FAIL** | pass |
| two characters XML forbids in one entry | yes | **FAIL** | **FAIL** | pass |
| a quote of exactly 40 characters | yes | **FAIL** | pass | pass |
| a quote of 41 characters | yes | **FAIL** | pass | pass |
| beside a year U14 says |  | **FAIL** | pass | pass |
| every offered year beside an entry it cannot read |  | **FAIL** | **FAIL** | pass |
| CONTROL — no key |  | pass | pass | pass |
| CONTROL — null |  | pass | pass | pass |
| CONTROL — duplicates |  | pass | pass | pass |
| CONTROL — out of order |  | pass | pass | pass |
| CONTROL — an enormous list of one year |  | pass | pass | pass |
| CONTROL — a whole year no appropriation offers |  | pass | pass | pass |
| CONTROL — a year the board offers outside 2000–2099 |  | pass | pass | pass |
| CONTROL — a whole number no year could be | yes | pass | pass | pass |
| beside a year U14 says · the NOTEs in order |  | **FAIL** | pass | pass |
| the export beside the NOTE |  | **FAIL** | pass | pass |
| text that is markup · escaped |  | **FAIL** | pass | pass |
| "2026", then FY27 switched on |  | **FAIL** | pass | pass |
| [2025, 2026.5], then FY27 switched on |  | pass | pass | pass |
| "2026", then ALL YEARS, then FY27's only |  | pass | pass | pass |
| partner and FMS money | yes | **FAIL** | pass | pass |
| nothing asked |  | pass | pass | pass |

Totals: base 28 of 39 U34 checks failing (U14: 0 of 63 failing); c1 6 failing; c3 0 failing (U14 0 of 63 failing on c3).

| run (harness `fr2/harness/c3/focused-c3.mjs`, blob `ab7dfc3e`) | board | start (ET) | exit | wall s | checks | result |
|---|---|---|---|---|---|---|
| FR4-focused-on-c3 | c3 `593593a4` | 12:04:54 | 0 | 174.2 | 102 | **ALL CHECKS PASSED**: U14 63/63, U34 39/39 |
| FR4-focused-on-base | base `fce8a391` (BOARD set) | 12:04:57 | 1 | 173.7 | 102 | 28 failing, all U34 (the FAILs above); U14 63/63; the 11 by-design passes pass |
| FR4-focused-on-c1 | c1 `a67635bb` (BOARD set) | 12:07:51 | 1 | 185.0 | 102 | 6 failing, all U34: the five of the first fix round (an enormous list, U+FFFF in an entry, U+FFFE as the whole value, 45 emoji, every offered year beside an entry) and "two characters XML forbids in one entry" (sheet1 unreadable); U14 63/63 |

The harness is built by the first fix round's `fr/bin/mkfocused-fr.py` from c3's suite (the U14 and U34 blocks, the
preamble helpers and `w7Pkg` / `w7Ok`, VERBATIM); against the first fix round's `focused-final.mjs` it differs only in its
header line and the suite's own diff.

### FR2.4 Mutations: 33 entries, each caught (harness `ab7dfc3e`)

Every U34 entry was made into a mutant board from c3 by `rec/bin/mkmut.py` (text only, under `bx.sh`) and run through the
c3 focused harness with BOARD set to it (`fr2/qrun.sh`, at most two at once). U14's 63 checks pass in every mutant.

| id | caught | failing checks (all U34; U14's 63 pass in every mutant) | against FM2 (first fix round, 34-check harness) | run | mutant board |
|---|---|---|---|---|---|
| `v200-yearsel-not-a-list-all-years` | yes, 9 | a string; an object; a bare number; an empty string; zero; false; U+FFFE as the whole value; "2026", then FY27 switched on; partner and FMS money | all 8 still failing; also: partner and FMS money | 12:25:49, exit 1, 163.4 s | `1180a4ea` |
| `v200-yearsel-nothing-read-all-years` | yes, 18 | a string; an object; a bare number; an empty list; a year as text; not a whole number; null in the list; true in the list; an enormous list; an empty string; zero; false; a long entry; U+FFFE as the whole value; a quote of exactly 40 characters; a quote of 41 characters; "2026", then FY27 switched on; partner and FMS money | all 15 still failing; also: a quote of exactly 40 characters; a quote of 41 characters; partner and FMS money | 12:25:53, exit 1, 173.8 s | `f9ed4a47` |
| `v200-yearsel-number-coerced` | yes, 3 | a year as text; null in the list; true in the list | all 3 still failing | 12:28:56, exit 1, 208.7 s | `ad31d7b8` |
| `v200-yearsel-fraction-unsaid` | yes, 2 | not a whole number; one whole year, one not | all 2 still failing | 12:29:00, exit 1, 211.3 s | `9ffbc199` |
| `v200-yearsel-whole-unsaid` | yes, 8 | a string; an object; a bare number; an empty list; an empty string; zero; false; U+FFFE as the whole value | all 8 still failing | 12:32:35, exit 1, 180.8 s | `37bccd3e` |
| `v200-yearsel-label-unsaid` | yes, 23 | a string; an object; a bare number; an empty list; a year as text; not a whole number; null in the list; true in the list; one whole year, one not; text that is markup; an enormous list; an empty string; zero; false; a long entry; U+FFFF in an entry; U+FFFE as the whole value; 45 emoji in an entry; two characters XML forbids in one entry; a quote of exactly 40 characters; a quote of 41 characters; beside a year U14 says; every offered year beside an entry it cannot read | all 20 still failing; also: two characters XML forbids in one entry; a quote of exactly 40 characters; a quote of 41 characters | 12:32:39, exit 1, 184.5 s | `8f075c8d` |
| `v200-yearsel-panel-unsaid` | yes, 24 | a string; an object; a bare number; an empty list; a year as text; not a whole number; null in the list; true in the list; one whole year, one not; text that is markup; an enormous list; an empty string; zero; false; a long entry; U+FFFF in an entry; U+FFFE as the whole value; 45 emoji in an entry; two characters XML forbids in one entry; a quote of exactly 40 characters; a quote of 41 characters; beside a year U14 says; every offered year beside an entry it cannot read; text that is markup · escaped | all 21 still failing; also: two characters XML forbids in one entry; a quote of exactly 40 characters; a quote of 41 characters | 12:35:53, exit 1, 218.6 s | `0ba70227` |
| `v200-yearsel-export-unsaid` | yes, 25 | a string; an object; a bare number; an empty list; a year as text; not a whole number; null in the list; true in the list; one whole year, one not; text that is markup; an enormous list; an empty string; zero; false; a long entry; U+FFFF in an entry; U+FFFE as the whole value; 45 emoji in an entry; two characters XML forbids in one entry; a quote of exactly 40 characters; a quote of 41 characters; beside a year U14 says; every offered year beside an entry it cannot read; beside a year U14 says · the NOTEs in order; the export beside the NOTE | all 22 still failing; also: two characters XML forbids in one entry; a quote of exactly 40 characters; a quote of 41 characters | 12:35:56, exit 1, 218.1 s | `4f0d7a66` |
| `v200-yearsel-markup-unescaped` | yes, 2 | text that is markup; text that is markup · escaped | all 2 still failing | 12:39:36, exit 1, 220.2 s | `78afa75c` |
| `v200-yearsel-counted-unsaid` | yes, 6 | one whole year, one not; text that is markup; U+FFFF in an entry; 45 emoji in an entry; two characters XML forbids in one entry; every offered year beside an entry it cannot read | all 5 still failing; also: two characters XML forbids in one entry | 12:39:40, exit 1, 216.6 s | `db9602b8` |
| `v200-yearsel-plural-it` | yes, 1 | an enormous list | all 1 still failing | 12:43:35, exit 1, 216.9 s | `f0cce367` |
| `v200-yearsel-toggle-from-all` | yes, 1 | "2026", then FY27 switched on | all 1 still failing | 12:43:38, exit 1, 231.7 s | `8a0b4e7b` |
| `v200-yearsel-quote-xml-unsafe` | yes, 3 | U+FFFF in an entry; U+FFFE as the whole value; two characters XML forbids in one entry | all 2 still failing; also: two characters XML forbids in one entry | 12:47:43, exit 1, 261.0 s | `db1c25d1` |
| `v200-yearsel-quote-splits-char` | yes, 1 | 45 emoji in an entry | all 1 still failing | 12:47:47, exit 1, 249.5 s | `11bdd79c` |
| `v200-yearsel-quote-uncut` | yes, 3 | a long entry; 45 emoji in an entry; a quote of 41 characters | all 2 still failing; also: a quote of 41 characters | 12:52:20, exit 1, 266.4 s | `05c7e9ec` |
| `v200-yearsel-falsy-all-years` | yes, 3 | an empty string; zero; false | all 3 still failing | 12:52:23, exit 1, 265.9 s | `fc41837b` |
| `v200-yearsel-falsy-unsaid` | yes, 3 | an empty string; zero; false | all 3 still failing | 12:56:49, exit 1, 194.0 s | `cc58beea` |
| `v200-yearsel-allyears-lit-unread` | yes, 1 | every offered year beside an entry it cannot read | all 1 still failing | 12:56:53, exit 1, 202.5 s | `523eac2d` |
| `v200-yearsel-label-all-years-unread` | yes, 1 | every offered year beside an entry it cannot read | all 1 still failing | 13:00:28, exit 1, 155.9 s | `facd0499` |
| `v200-yearsel-label-ur-unpassed` | yes, 1 | every offered year beside an entry it cannot read | all 1 still failing | 13:00:32, exit 1, 158.4 s | `e1988c95` |
| `v200-yearsel-year-chips-unlit-unread` | yes, 1 | every offered year beside an entry it cannot read | all 1 still failing | 13:03:06, exit 1, 207.7 s | `3c839bba` |
| `v200-yearsel-note-replaces-line` | yes, 1 | the export beside the NOTE | all 1 still failing | 13:03:15, exit 1, 214.2 s | `90067a2e` |
| `v200-yearsel-note-order` | yes, 1 | beside a year U14 says · the NOTEs in order | all 1 still failing | 13:07:03, exit 1, 217.2 s | `8a1de76b` |
| `v200-yearsel-label-unsaid-beside-u14` | yes, 1 | beside a year U14 says | all 1 still failing | 13:07:07, exit 1, 216.2 s | `2127cba4` |
| `v200-yearsel-panel-unsaid-beside-u14` | yes, 1 | beside a year U14 says | all 1 still failing | 13:10:42, exit 1, 184.4 s | `babbb76d` |
| `v200-yearsel-year-range` | yes, 2 | CONTROL — a year the board offers outside 2000–2099; CONTROL — a whole number no year could be | all 1 still failing; also: CONTROL — a whole number no year could be | 13:10:46, exit 1, 178.7 s | `2dafe2ae` |
| `v200-yearsel-plural-label` | yes, 1 | an enormous list | all 1 still failing | 13:13:59, exit 1, 178.0 s | `a31ed17e` |
| `v200-yearsel-quote-escape-first-only` | yes, 1 | two characters XML forbids in one entry | new in this round | 12:11:38, exit 1, 203.8 s | `11541f23` |
| `v200-yearsel-quote-cut-at-40-or-more` | yes, 1 | a quote of exactly 40 characters | new in this round | 12:15:02, exit 1, 175.2 s | `fe2224c9` |
| `v200-yearsel-quote-cut-above-41` | yes, 1 | a quote of 41 characters | new in this round | 12:18:02, exit 1, 108.0 s | `e3747fec` |
| `v200-yearsel-year-four-digits` | yes, 1 | CONTROL — a whole number no year could be | new in this round | 12:20:15, exit 1, 139.1 s | `34f4b5d3` |
| `v200-yearsel-year-positive` | yes, 1 | CONTROL — a whole number no year could be | new in this round | 12:20:18, exit 1, 138.6 s | `f486a9ad` |
| `v200-yearsel-other-sources-all-years` | yes, 1 | partner and FMS money | new in this round | 12:22:37, exit 1, 114.8 s | `d15fcd09` |

33 of 33 caught.

### FR2.5 audit-recon in full, `npm run check`, mcount; the suites not re-run

- **audit-recon** (FS3-audit-recon-c3, 12:11:34 ET, exit 0, 427.7 s, `logs/FS3-audit-recon-c3.log`): **ALL CHECKS PASSED, 345 recorded checks**. Against the base's 306
  (build run S): 306 common, **0 differing** in verdict or value; 39 only in c3, all U34, all passing
  (`fr2/out/cmp-recon-base-c3.txt`). Against c2's 340 (FS2): 0 differing; 5 new, all passing (`fr2/out/cmp-recon-c2-c3.txt`).
- **`npm run check`** (FR5-npm-check-c3, 12:22:40 ET, exit 0, 7.1 s, `logs/FR5-npm-check-c3.log`, scratch clone `gitclone/` at `7ee498a` with c3's three files copied
  over, `mutate.mjs.txt` as `mutate.mjs`, never committed): all checks passed; its output equals c2's (FR-N4) line for line
  but the timing. `tools/check.mjs` reads the board only.
- **mcount** (text only, `rec/bin/mcount.py`, `python3 -I`; `fr2/out/mcount-all.txt`, every catalog on every board):
  c3 catalog on c3 **1,361 / 1,361** once, none missing, multiple or unparsed; c2's on c3 1,355 / 1,355; c1's on c3
  1,340 / 1,340; the base's on c3 1,328 / 1,328. c3's on c1: 1,350 once, 11 missing (the entries whose finds are code commit 2 wrote);
  on the base: 1,330 once, 31 missing (the entries whose finds are U34's code).
- **Not re-run, and why:** audit, audit-ppt, audit-other, audit-hostile, audit-inject, boot-same and legacy-fsrc read the
  board and their own files; neither changed in this round (c3's board is c2's blob `593593a4`, and only audit-recon and
  the catalog differ). Their first-fix-round runs on that board (FS-*, 4:59–5:06 AM ET) stand.

### FR2.6 The verifier's probes, re-run (P1 and P2, copied unchanged)

`fr2/harness/c3/r2probe.mjs` and `r2nan.mjs` are the money verifier's harnesses, byte for byte (blobs `7e648acf`,
`97f20b64`); only the `./boot.mjs` link points at c3's. Each ran on c3 and on the base (BOARD set).
- **P1** (13 shapes plus NaN, each opened, read, exported, saved at once, after an unrelated operation, and reopened from
  the file and from storage): on each board, all 15 observation keys equal the verifier's, with the fixture's save times
  and the workbook tags masked (`fr2/bin/cmpp1.py`). expat: 26 / 26 workbooks WELL-FORMED on each board. The values the
  drafts cite: WHOLE-INF and WHOLE-NEGINF stored null, $540M, ALL YEARS lit, no notice, Save writes null; CENTURY-PAIR
  "FY25 · all appropriations · saved FY25 not available, not counted", $40M, NOTE names FY2125; NEAR-INT stored [2027],
  $500M, nothing said; every shape's storage reopen stores and reads the same as its file opening.
- **P2** (NaN): the same observations as the verifier's on each board, apart from the fixture's save time.

### FR2.7 Drafts (current; the first fix round's are in `drafts/superseded-c2/`, the build's in `drafts/superseded-c1/`; blobs in § FR2.11)

- `drafts/NEXT-VERSION-U34.md`: the U34 entry for the final state. Changed from the first fix round's:
  the 1e999 qualification of "only no saved selection is ALL YEARS"; partner and FMS money; the quote's 40/41 edge and
  "every U+FFFE and U+FFFF"; Test (39 checks, 23 shapes, eight controls, the partner check, 28 / 11); Mutations (33);
  "Not covered": the no-plausible-year bullet (what the two controls pin, and correction C), the "kept as saved" bullet
  (correction B), the new NaN bullet (correction D, in the board's own words), the depth wording, and the tested paths.
- `drafts/UNRESOLVED-LINE-U34.md`: the U34 line, with correction E's limits.
- `drafts/LEDGER-U34-append.md`: the U34 row's text, with correction F's limits, the second rounds, the
  counts, and commit 3's blobs; it still proposes **P2**.
- `drafts/LEDGER-NEW-ROWS.md`: **four new rows** (placeholders for the lead to number): U-new-aps and
  U-new-xml (first fix round, unchanged), **U-new-nan** (P1 candidate, data loss) and **U-new-fy2** (P3), the verifier's
  drafted rows with my re-runs added to their evidence. A note above the new rows says that U-new-xml is the same writer
  gap as **U37** (`_xesc`; added to the ledger at `bbe7285` and made a release blocker at 12:02 PM ET), and proposes adding
  its evidence to U37 rather than opening a row, so that U37's fix also covers U+FFFE / U+FFFF.

**LIMITS, for the evidence matrix and "Not covered"** (all stated in the drafts):
1. Whole numbers that are no plausible year are read as years; a year need not be in 2000–2099, have four digits, or be
   above zero (the FY1999 and -2027 controls). They print by their last two digits on the panel and label, whole in the
   NOTE; a century-off year prints as an offered one (U-new-fy2).
2. An enormous list of distinct whole numbers is named in full and is slow (118,370 characters, 1.3–1.6 s at 20,000);
   the saved list sorts as text.
3. "Kept as saved" is the same value, not the same bytes: spaces dropped, -0 → 0, 2.027e3 → 2027, 2026.9999999999999 →
   2027 (FY27, nothing said). 1e999 is null by the time the board reads it: as an entry, quoted "null" and written back as
   null; **as the whole value, ALL YEARS with nothing said ($540M), and the first save writes null** (as before the change).
4. **A saved NaN makes the whole saved state unreadable, and the warning not to save over the file is replaced in the same
   opening** (U-new-nan; as before the change).
5. U+FFFE / U+FFFF are quoted as their escape, not as the character the file holds.
6. A selection nested about 4,150 deep or more stops the board opening (jsdom's stack; as before).
7. The saved appropriation selection: U-new-aps. Other saved text with U+FFFF in the export: U-new-xml.
8. A click replaces what could not be read (as the notice says).
9. The suite opens the saved file; a probe also reopened from storage; the shared folder, PMO copy and batch import were
   not opened; writers checked from `09cf071` on; no locked-cycle view; jsdom only; the label's fit in the chart image not
   checked.

### FR2.8 Decisions, with reasons

- **No board change for 1e999 (MF1).** Every U34 reader runs after the opening's copy, `MS = normalizeStore(JSON.parse(
  JSON.stringify(raw||{})))` (c3 board line 5999), which has already turned Infinity into null, the board's own ALL YEARS.
  Only `raw`, before that copy, still holds Infinity. A fix would have to scan the raw saved state in the opening path every
  load takes, and even then the board could only say it, not keep it: JSON has no spelling for Infinity, so any save writes
  null. Keeping it would need a new stored form the board then writes. That is a larger change than the finding (a hand
  edit typing a number beyond 1.8e308), and principle 5 asks for the smallest; the verifier also asked for words only. The
  limit is stated with its money ($540M, ALL YEARS, nothing said), as principle 4 asks.
- **No board change for NaN (MF2).** The file's whole saved state fails `JSON.parse`, before any U34 code runs; it is the
  opening path every unreadable saved state shares (`_bootLost`, said and cleared at the first render; then the status
  chain from c3 line 31564, which checks `_bootRestoreErr` but not what `_bootLost` held, sets the SHELL TEMPLATE line,
  line 31617, or "No saved state in this copy", line 31679). Which line wins on the status bar is a decision across many warnings, outside U34; the verifier
  asked for a record. It is the one data-loss risk found here, so its row proposes **P1 candidate** for the lead.
- **The verifiers' measured code is taken verbatim** (their shapes, check and entries), so their before/after runs stay
  evidence for it; my own runs repeat each.
- **One entry more than proposed** (`-year-positive`): the tests verifier's `om-year-positive` survived as well; the same
  control catches it, and a catalog entry keeps it caught.
- **The "no range" words corrected, not the control's value.** Only the promises (comment and `what` text) change; every
  expected value stays.
- **Commit 3 kept separate, squash recommended.** It touches only the suite and the catalog, so it can land on its own;
  the squash is one reviewable U34 change.

### FR2.9 Every run of this round (start ET, exit, wall seconds, log)

Every node run went through `run.sh` (`setsid -w timeout -k 10 600`, its own process group, the lock check, PIDs to
`pids.txt`). Each queue (`fr2/q1.sh`, `fr2/qrun.sh`) ran under its own `setsid -w timeout -k 10 600`, launched from my
shell, and held at most two node runs at once with a 5 GB MemAvailable gate. The lock `AUDIT_IMPORT_RUNNING` was absent
before every run: no run waited and none was skipped. Exit 1 on a focused-on-base, focused-on-c1 or mutant run is the
expected failure.

| label | start (ET, 13 Oct) | exit | wall s | log |
|---|---|---|---|---|
| FR4-syntax-recon-c3 | 12:04:35 | 0 | 0.3 | `logs/FR4-syntax-recon-c3.log` |
| FR4-syntax-harness-c3 | 12:04:35 | 0 | 0.3 | `logs/FR4-syntax-harness-c3.log` |
| FR4-focused-on-c3 | 12:04:54 | 0 | 174.2 | `logs/FR4-focused-on-c3.log` |
| FR4-focused-on-base | 12:04:57 | 1 | 173.7 | `logs/FR4-focused-on-base.log` |
| FR4-focused-on-c1 | 12:07:51 | 1 | 185.0 | `logs/FR4-focused-on-c1.log` |
| FM3-v200-yearsel-quote-escape-first-only | 12:11:38 | 1 | 203.8 | `logs/FM3-v200-yearsel-quote-escape-first-only.log` |
| FM3-v200-yearsel-quote-cut-at-40-or-more | 12:15:02 | 1 | 175.2 | `logs/FM3-v200-yearsel-quote-cut-at-40-or-more.log` |
| FS3-audit-recon-c3 | 12:11:34 | 0 | 427.7 | `logs/FS3-audit-recon-c3.log` |
| FM3-v200-yearsel-quote-cut-above-41 | 12:18:02 | 1 | 108.0 | `logs/FM3-v200-yearsel-quote-cut-above-41.log` |
| FM3-v200-yearsel-year-four-digits | 12:20:15 | 1 | 139.1 | `logs/FM3-v200-yearsel-year-four-digits.log` |
| FM3-v200-yearsel-year-positive | 12:20:18 | 1 | 138.6 | `logs/FM3-v200-yearsel-year-positive.log` |
| FR5-npm-check-c3 | 12:22:40 | 0 | 7.1 | `logs/FR5-npm-check-c3.log` |
| FP2-nan-on-c3 | 12:22:48 | 0 | 9.5 | `logs/FP2-nan-on-c3.log` |
| FP2-nan-on-base | 12:23:01 | 0 | 8.9 | `logs/FP2-nan-on-base.log` |
| FM3-v200-yearsel-other-sources-all-years | 12:22:37 | 1 | 114.8 | `logs/FM3-v200-yearsel-other-sources-all-years.log` |
| FP1-probe-on-c3 | 12:24:53 | 0 | 55.4 | `logs/FP1-probe-on-c3.log` |
| FP1-probe-on-base | 12:24:56 | 0 | 53.5 | `logs/FP1-probe-on-base.log` |
| FM3-v200-yearsel-not-a-list-all-years | 12:25:49 | 1 | 163.4 | `logs/FM3-v200-yearsel-not-a-list-all-years.log` |
| FM3-v200-yearsel-nothing-read-all-years | 12:25:53 | 1 | 173.8 | `logs/FM3-v200-yearsel-nothing-read-all-years.log` |
| FM3-v200-yearsel-number-coerced | 12:28:56 | 1 | 208.7 | `logs/FM3-v200-yearsel-number-coerced.log` |
| FM3-v200-yearsel-fraction-unsaid | 12:29:00 | 1 | 211.3 | `logs/FM3-v200-yearsel-fraction-unsaid.log` |
| FM3-v200-yearsel-whole-unsaid | 12:32:35 | 1 | 180.8 | `logs/FM3-v200-yearsel-whole-unsaid.log` |
| FM3-v200-yearsel-label-unsaid | 12:32:39 | 1 | 184.5 | `logs/FM3-v200-yearsel-label-unsaid.log` |
| FM3-v200-yearsel-panel-unsaid | 12:35:53 | 1 | 218.6 | `logs/FM3-v200-yearsel-panel-unsaid.log` |
| FM3-v200-yearsel-export-unsaid | 12:35:56 | 1 | 218.1 | `logs/FM3-v200-yearsel-export-unsaid.log` |
| FM3-v200-yearsel-markup-unescaped | 12:39:36 | 1 | 220.2 | `logs/FM3-v200-yearsel-markup-unescaped.log` |
| FM3-v200-yearsel-counted-unsaid | 12:39:40 | 1 | 216.6 | `logs/FM3-v200-yearsel-counted-unsaid.log` |
| FM3-v200-yearsel-plural-it | 12:43:35 | 1 | 216.9 | `logs/FM3-v200-yearsel-plural-it.log` |
| FM3-v200-yearsel-toggle-from-all | 12:43:38 | 1 | 231.7 | `logs/FM3-v200-yearsel-toggle-from-all.log` |
| FM3-v200-yearsel-quote-splits-char | 12:47:47 | 1 | 249.5 | `logs/FM3-v200-yearsel-quote-splits-char.log` |
| FM3-v200-yearsel-quote-xml-unsafe | 12:47:43 | 1 | 261.0 | `logs/FM3-v200-yearsel-quote-xml-unsafe.log` |
| FM3-v200-yearsel-quote-uncut | 12:52:20 | 1 | 266.4 | `logs/FM3-v200-yearsel-quote-uncut.log` |
| FM3-v200-yearsel-falsy-all-years | 12:52:23 | 1 | 265.9 | `logs/FM3-v200-yearsel-falsy-all-years.log` |
| FM3-v200-yearsel-falsy-unsaid | 12:56:49 | 1 | 194.0 | `logs/FM3-v200-yearsel-falsy-unsaid.log` |
| FM3-v200-yearsel-allyears-lit-unread | 12:56:53 | 1 | 202.5 | `logs/FM3-v200-yearsel-allyears-lit-unread.log` |
| FM3-v200-yearsel-label-all-years-unread | 13:00:28 | 1 | 155.9 | `logs/FM3-v200-yearsel-label-all-years-unread.log` |
| FM3-v200-yearsel-label-ur-unpassed | 13:00:32 | 1 | 158.4 | `logs/FM3-v200-yearsel-label-ur-unpassed.log` |
| FM3-v200-yearsel-year-chips-unlit-unread | 13:03:06 | 1 | 207.7 | `logs/FM3-v200-yearsel-year-chips-unlit-unread.log` |
| FM3-v200-yearsel-note-replaces-line | 13:03:15 | 1 | 214.2 | `logs/FM3-v200-yearsel-note-replaces-line.log` |
| FM3-v200-yearsel-note-order | 13:07:03 | 1 | 217.2 | `logs/FM3-v200-yearsel-note-order.log` |
| FM3-v200-yearsel-label-unsaid-beside-u14 | 13:07:07 | 1 | 216.2 | `logs/FM3-v200-yearsel-label-unsaid-beside-u14.log` |
| FM3-v200-yearsel-year-range | 13:10:46 | 1 | 178.7 | `logs/FM3-v200-yearsel-year-range.log` |
| FM3-v200-yearsel-panel-unsaid-beside-u14 | 13:10:42 | 1 | 184.4 | `logs/FM3-v200-yearsel-panel-unsaid-beside-u14.log` |
| FM3-v200-yearsel-plural-label | 13:13:59 | 1 | 178.0 | `logs/FM3-v200-yearsel-plural-label.log` |

Text-only tools (under `bx.sh`, PIDs recorded): `cp -a c2 c3`, `git merge-file`, `fr2/bin/mkc3.py` (twice: the second
rewording "no range"), `mkfocused-fr.py`, `mcount-all.sh`, `mkmut.py` for each mutant, `mkdiffs.sh`, `xmlcheck.py`,
`mkdrafts.py`, the copy into `gitclone/`.

### FR2.10 PIDs, deviations, and what I did not do

**PIDs.** Every run's `timeout` PID and its child are in `pids.txt` (with time, label and command), and so are the `bx.sh`
calls and each queue wrapper (`fr2/q1.sh`, `fr2/qrun.sh` record their own PID). The `setsid` and `timeout` PIDs of each
queue's bound, launched from my shell, were read from `ps` a few seconds after each launch and added by hand (labels
`fr2-q1-outer`, `fr2-Q2-outer` … `fr2-Q11-outer`). At 1:17:17 PM ET, `/proc` was read for the 214 distinct PIDs recorded in
this round (`pids.txt` from line 633): none was present. I sent no signal to any process in this round: nothing was
killed, by PID, name or pattern; no pkill or killall. No run hit its 600 s cap, and no queue hit its own (the longest,
Q7, took 510 s).

**Deviations, said plainly:**
- One `python3 -I rec/bin/mcount.py … --list` (text only, a second or so) ran directly, not under `bx.sh`, at about
  12:03 PM ET; its output was not used. Read-only commands ran directly: `date`, `ls`, `grep`, `sed -n`, `cat`, `diff`,
  `ps`, `free`, `uptime`, `git hash-object`, `git -C gitclone status/log`, and `python3 -I` summaries of my own logs and
  check files (`tally.py`, `cmprecon.py`, `cmpp1.py`, `showfail.py`).
- My waiting loops (`until grep …; do sleep …; done`, to be told when a queue ended) only read `logs/runs.txt` or the
  queue's own output file, and were not under a 600 s bound; each ended when its queue did.
- The editing tool again wrote the escape text as the raw character once, in an `assert` of `fr2/bin/mkdrafts.py` (a
  check that no draft holds the raw character); it was rewritten as `chr(0xFFFF)` / `chr(0xFFFE)` before the drafts were
  written again. `grep` for the raw bytes gives 0 in every source, script and draft this round wrote, and in README.md.
  Run outputs (check records, probe logs) hold what the board observed, raw where the board holds it raw.

**Not done:**
- The full audit-import and audit-board (the lead's); Chromium, playwright and verify:grid; any commit or push; any edit in
  orbit-board or orbit-ui (`gitclone/` is my own scratch clone, never committed). orbit-board was only read: at 1:17 PM ET
  its HEAD was `3841339`, `git status --short` printed nothing, and its ledger's U34 row is still line 67; it now also has
  rows U35–U42 (U37 is the writer gap U-new-xml belongs to; § FR2.7). orbit-ui was not touched in this round.
- `mutate.mjs` was never imported or run: read as text only by `mcount.py` and `mkmut.py`.
- No board change in this round: 1e999 as a whole value (MF1) and NaN (MF2, U-new-nan) are recorded with their limits,
  not fixed; nor U-new-fy2, U-new-aps or U-new-xml.
- The other seven suites were not re-run (their inputs did not change; § FR2.5). The builder's P3/P4 probes and the depth
  probe were not re-run (the board did not change).

### FR2.11 Blobs of this round (git hash-object)

| file | blob |
|---|---|
| `c3/prioritization-board-grid.html` | `593593a43172e30755f6fca03785a28e5a8c048f` |
| `c3/tools/export-audit/audit-recon.mjs` | `2d34269d69be10a5c04772c12796e6b0bda90aaf` |
| `c3/tools/export-audit/mutate.mjs.txt` | `ba8b55adf994892e91e9b009139be566ebe0e458` |
| `diffs/c3-board-vs-c2.diff` | `e69de29bb2d1d6434b8b29ae775ad8c2e48c5391` |
| `diffs/c3-audit-recon-vs-c2.diff` | `8dfed1ff96b8b797bc729cb7c0ddab999d90e578` |
| `diffs/c3-mutate-vs-c2.diff` | `e968bc59dbfd1c3f8b91b4a387dcdd453bea0ef4` |
| `diffs/c3-board-vs-base.diff` | `5e9fb0c3283e1d5d29212c866a8499992adc450b` |
| `diffs/c3-audit-recon-vs-base.diff` | `a45aed01de5d0f6e2a70a3300bcf3c4d24bfc80b` |
| `diffs/c3-mutate-vs-base.diff` | `38c78f326bf7298a7768c44240e92164a018869a` |
| `fr2/harness/c3/focused-c3.mjs` | `ab7dfc3e85625e553fde58286b28a8b008cdd32b` |
| `fr2/harness/c3/r2probe.mjs` | `7e648acfc7f38b5cbdd8d4d22c72265250a99dc2` |
| `fr2/harness/c3/r2nan.mjs` | `97f20b641afc3b2673cc183fc33d7900b2dc9b25` |
| `fr2/blocks/audit-recon-merged.mjs.txt` | `ef2fb25568658ce6ca193c21649daa28aacd3447` |
| `drafts/NEXT-VERSION-U34.md` | `c7ceb4597ffb36d23483af1b4179f813fe65386b` |
| `drafts/UNRESOLVED-LINE-U34.md` | `4c4a1e3f8493e3211ae032deb691aaa0c1bb3279` |
| `drafts/LEDGER-U34-append.md` | `859710646c16d5e9f76a21caba73820bde143ea0` |
| `drafts/LEDGER-NEW-ROWS.md` | `86707152824810e6b1478334c17560d861e188e6` |
| `fr2/qrun.sh` | `24471f002764f6b13184005057f17973a610dd69` |
| `fr2/q1.sh` | `3c970cfdcd7dc97db5fdc38b0feb22693fea08af` |
| `fr2/bin/mkc3.py` | `97863ab08a0787bb6d3adf034f49021375f89fff` |
| `fr2/bin/mkdrafts.py` | `e69bd0dfc3fb281611c659194c3bb9a077f6b5b7` |
| `fr2/bin/tally.py` | `5b4f4ceb6ac222632d33e3cb245b773c962992f1` |
| `fr2/bin/cmprecon.py` | `72d3a392e2757fa9ac62dabd8ef60aea58d0e0c8` |
| `fr2/bin/cmpp1.py` | `3686840bb78dfd4ae63e6f09afe9e1ab80b09e9a` |
| `fr2/bin/mcount-all.sh` | `d3bac392927b65755414fae0ec332ab2982f44a1` |
| `fr2/bin/mkdiffs.sh` | `f237dc93582e287f3473e605fabe2b70bf3f78cf` |
| `fr2/bin/fillreadme2.py` | `a370c60d7eb06cb39fb43a742c386f355c5fede9` |
| `fr2/bin/xmlcheck.py` | `3e970bd1e8a408e43c0dc767efa2225b3cd66287` |
| `run.sh` | `cb1987694333f3678201a255a04acdd26c4e5daf` |
| `bx.sh` | `b88b3db5ce8a8ddb6c1bcf557c3e2aa158052c7e` |
| `runner.mjs` | `f851f1391102e59aa12f0ca301b40bb4ddd005f3` |

## Appendix A — the exact diffs (against the base)

The three diffs follow, exactly as in `diffs/`.

### A.1 `diffs/c1-board.diff` (blob 879f61a138705c119c8fe84050237a97fd804366)

```diff
--- ../base/prioritization-board-grid.html	2026-10-12 21:17:00.000000000 +0000
+++ c1/prioritization-board-grid.html	2026-10-13 00:12:04.728118657 +0000
@@ -15349,11 +15349,32 @@
 }
 // v2.00 (U14): the saved year selection as it is stored -- each year once, in order -- or null when none is saved (ALL YEARS).
 // Read, never written: only a person's click (flowToggleYear, flowOneYear, flowAllYears) changes it.
+// v2.00 (U34): A SAVED SELECTION THIS BOARD DID NOT WRITE IS NEVER READ AS ALL YEARS. None saved (null, or no key) is ALL YEARS,
+// and nothing else is. A year is a whole number, as the board writes it; anything else -- a string ("2026"), an object, a bare
+// number, 2026.5, null, an empty list -- is read as no year, kept as saved, and said (flowUnreadSaved). It read as ALL YEARS,
+// or as a year it is not ("2027" as FY27, true as FY1), with nothing said.
+function flowYearOk(y){ return typeof y==='number' && Number.isInteger(y); }
 function flowSavedYears(){
   const C=flowCfg();
-  if(!Array.isArray(C.fys)) return null;
-  const s=C.fys.map(Number).filter((y,i,a)=>Number.isInteger(y) && a.indexOf(y)===i);
-  return s.length? s.sort() : null;
+  if(C.fys==null) return null;
+  const s=(Array.isArray(C.fys)? C.fys : []).filter((y,i,a)=>flowYearOk(y) && a.indexOf(y)===i);
+  return s.sort();
+}
+// v2.00 (U34): what of the saved year selection this board cannot read as years, or null when it reads all of it: the whole
+// value (not a list, or an empty one), or the entries that are not whole numbers. `what` quotes the file -- at most three
+// entries, each cut at 40 characters -- for the panel's notice (escaped there) and the export's NOTE.
+function flowUnreadSaved(){
+  const v=flowCfg().fys, q=x=>{ const t=String(JSON.stringify(x)); return t.length>40? t.slice(0,40)+'\u2026' : t; };
+  if(v==null) return null;
+  if(!Array.isArray(v) || !v.length) return {whole:true, n:1, what:q(v)};
+  const bad=v.filter(y=>!flowYearOk(y));
+  return bad.length? {whole:false, n:bad.length, what:bad.slice(0,3).map(q).join(', ')+(bad.length>3? ' and '+(bad.length-3)+' more' : '')} : null;
+}
+function flowUnreadText(F, fy){
+  const U=F.unread, L=a=>a.map(fy).join(', '), one=U.n===1;
+  if(U.whole) return 'The saved year selection is '+U.what+', not a list of years this board can read. It is kept as saved, and nothing is counted.';
+  return 'The saved year selection holds '+U.what+', which this board cannot read as '+(one?'a year':'years')+'. '+(one?'It is':'They are')
+    +' kept as saved'+(F.fys.length? ' and not counted: this total counts '+L(F.fys)+' only.' : ', and nothing is counted.');
 }
 // v2.00 (U14): the saved years the board cannot answer for now: no plan held for them, no imported row filed or counted in
 // them, outside the plan window. The panel and the export name them, and what is counted instead.
@@ -15586,8 +15607,9 @@
   const RIX=(AX==='buys')? null : flowReqIndex();
   const YS = (arg==null)? flowSelYears() : [Number(arg)];
   const UN = (arg==null)? flowUnavailYears() : [];      // v2.00 (U14): saved years the board cannot answer for now
+  const UR = (arg==null)? flowUnreadSaved() : null;     // v2.00 (U34): what of the saved selection cannot be read as years
   const AS = (arg==null)? flowSelAppns() : FLOW_APPNS.slice();
-  const F={fy:YS[YS.length-1], fys:YS, aps:AS, multi:YS.length>1, unavail:UN,
+  const F={fy:YS[YS.length-1], fys:YS, aps:AS, multi:YS.length>1, unavail:UN, unread:UR,
            label:flowScopeLabel(YS,AS,UN), tot:0, appn:APPN_SLUGS.reduce(function(o,s){ o[s]=0; return o; },{}), dual:0, rows:0,
            // Executed money and planned money are both in the total, and which is which is a fact
            // the chart has to be able to STATE - so it is counted here rather than inferred later
@@ -15674,6 +15696,8 @@
   // v2.00 (U14): a saved year the board cannot answer for is said in the scope itself -- the panel, the chart, the image, the
   // export's Scope line and its file name all print this label -- kept in the selection, and not counted
   if(UN.length) F.label+=' \u00b7 saved '+UN.map(y=>'FY'+(y%100)).join(', ')+' not available, not counted';
+  // v2.00 (U34): and a saved selection, or part of one, that cannot be read as years
+  if(UR) F.label+=' \u00b7 '+(UR.whole? 'saved year selection not a list of years' : UR.n+' saved '+(UR.n===1?'entry':'entries')+' not a year')+', not counted';
   return F;
 }
 // v1.99 (item 92): what partner and FMS money is, said the same way on the panel and in the export
@@ -16555,6 +16579,11 @@
     +(F.unavail.length? '<div class="flowunavail" style="border:1px solid var(--amber);border-radius:8px;padding:8px 11px;margin-bottom:9px;font-size:10px">'
        +'<b style="color:var(--amber)">'+esc(flowUnavailText(F, y=>'FY'+(y%100)))+'</b> '
        +'Click <b>ALL YEARS</b>, or a year\u2019s <b>only</b>, to choose again; switching a year on or off keeps '+(F.unavail.length===1?'it':'them')+'.</div>' : '')
+    // v2.00 (U34): A SAVED SELECTION THE BOARD CANNOT READ AS YEARS is said, quoted as saved, with what is counted instead. Any
+    // click on the year buttons chooses again and replaces what cannot be read (a toggle starts from the years it could read).
+    +(F.unread? '<div class="flowunread" style="border:1px solid var(--amber);border-radius:8px;padding:8px 11px;margin-bottom:9px;font-size:10px">'
+       +'<b style="color:var(--amber)">'+esc(flowUnreadText(F, y=>'FY'+(y%100)))+'</b> '
+       +'Click <b>ALL YEARS</b>, a year\u2019s <b>only</b>, or a year to switch it on or off, to choose again; any of these replaces what cannot be read.</div>' : '')
     +'<div style="font-size:9.5px;color:var(--dim);margin-bottom:6px">Loaded: '
     +FLOW_APPNS.map(a=>(LOAD[a].has
         ? '<b style="color:var(--ink)">'+esc(APPN_LBL[a])+'</b> '+LOAD[a].n+' events'
@@ -16756,6 +16785,8 @@
     +'. Executed is the imported CCaR QPE; planned is '+(APPN_LBL[F.planSlug]||'this board')+'\u2019s own allocation.'],[]);
   if(F.multi) sum.splice(3,0,['NOTE: separate appropriation years added together \u2014 a portfolio total, '
     +'not one year of funding. Fiscal years included: '+F.fys.map(y=>'FY'+y).join(', ')+'.'],[]);
+  // v2.00 (U34): a saved selection the board cannot read as years, in the panel's words, under U14's NOTE
+  if(F.unread) sum.splice(3,0,['NOTE: '+flowUnreadText(F, y=>'FY'+y)],[]);
   // v2.00 (U14): a saved year the board cannot answer for now, in the panel's words, first under the Scope line
   if(F.unavail.length) sum.splice(3,0,['NOTE: '+flowUnavailText(F, y=>'FY'+y)],[]);
   // v1.99 (item 92): only the appropriations in scope -- one switched off is not a $0 line
```

### A.2 `diffs/c1-mutate.mjs.diff` (blob 45a349ec4b841b5d4a50664284121ed04f84924a)

```diff
--- ../base/tools/export-audit/mutate.mjs.txt	2026-10-12 21:17:00.000000000 +0000
+++ c1/tools/export-audit/mutate.mjs.txt	2026-10-13 00:12:05.132118681 +0000
@@ -4285,6 +4285,44 @@
   { id: "v200-u14-notice-plural-it", area: "flowHtml", what: "the panel's notice says \"keeps it\" however many saved years the board cannot answer for: FY24 and FY26 \"stay in the saved selection\", and switching a year \"keeps it\"",
     find: "switching a year on or off keeps '+(F.unavail.length===1?'it':'them')+'.</div>'",
     repl: "switching a year on or off keeps it.</div>'" },
+  // v2.00 (U34, Codex's review as Brad supplied it, 12 Oct: "the malformed saved-year selection"): a saved year selection the
+  // board did not write is read as no year, kept as saved and said -- never as ALL YEARS, never as a year it is not.
+  { id: "v200-yearsel-not-a-list-all-years", area: "flowSavedYears", what: "a saved year selection that is not a list reads as ALL YEARS again: \"2026\", {} or a bare 2027 counts every year, $540M, ALL YEARS lit, while the notice says nothing is counted",
+    find: "  if(C.fys==null) return null;\n  const s=(Array.isArray(C.fys)? C.fys : [])",
+    repl: "  if(!Array.isArray(C.fys)) return null;\n  const s=(Array.isArray(C.fys)? C.fys : [])" },
+  { id: "v200-yearsel-nothing-read-all-years", area: "flowSavedYears", what: "a saved list with no whole year in it reads as ALL YEARS again: [], [2026.5], [\"2027\"] and 5,000 × \"x\" count every year, $540M",
+    find: "  return s.sort();\n}\n// v2.00 (U34): what of the saved year selection",
+    repl: "  return s.length? s.sort() : null;\n}\n// v2.00 (U34): what of the saved year selection" },
+  { id: "v200-yearsel-number-coerced", area: "flowSavedYears", what: "the saved entries are read through Number() again: [\"2027\"] counts as FY27, [true] is said as a saved FY1, [null] as a saved FY0",
+    find: "(Array.isArray(C.fys)? C.fys : []).filter((y,i,a)=>flowYearOk(y) && a.indexOf(y)===i)",
+    repl: "(Array.isArray(C.fys)? C.fys : []).map(Number).filter((y,i,a)=>Number.isInteger(y) && a.indexOf(y)===i)" },
+  { id: "v200-yearsel-fraction-unsaid", area: "flowUnreadSaved", what: "only entries that are not numbers are said: [2026.5] counts nothing and says nothing; [2025, 2026.5] counts FY25 with nothing said of 2026.5",
+    find: "  const bad=v.filter(y=>!flowYearOk(y));",
+    repl: "  const bad=v.filter(y=>typeof y!=='number');" },
+  { id: "v200-yearsel-whole-unsaid", area: "flowUnreadSaved", what: "a saved selection that is not a list, or an empty one, counts nothing and says nothing: \"2026\" reads \"no year counted\" with no reason, on the panel and in the export",
+    find: "  if(!Array.isArray(v) || !v.length) return {whole:true, n:1, what:q(v)};",
+    repl: "  if(!Array.isArray(v) || !v.length) return null;" },
+  { id: "v200-yearsel-label-unsaid", area: "flowCalc", what: "the scope label leaves out what cannot be read: the panel, the chart and the export's Scope line say \"no year counted\" with no reason, while the notice says it",
+    find: "  if(UR) F.label+=' \\u00b7 '+(UR.whole?",
+    repl: "  if(false) F.label+=' \\u00b7 '+(UR.whole?" },
+  { id: "v200-yearsel-panel-unsaid", area: "flowHtml", what: "the panel leaves out its notice of a saved selection it cannot read, while the export says it",
+    find: "    +(F.unread? '<div class=\"flowunread\"",
+    repl: "    +(false? '<div class=\"flowunread\"" },
+  { id: "v200-yearsel-export-unsaid", area: "exportFlow", what: "the export leaves out its NOTE of a saved selection the board cannot read, while the panel says it",
+    find: "  if(F.unread) sum.splice(3,0,['NOTE: '+flowUnreadText(F, y=>'FY'+y)],[]);",
+    repl: "  if(false) sum.splice(3,0,['NOTE: '+flowUnreadText(F, y=>'FY'+y)],[]);" },
+  { id: "v200-yearsel-markup-unescaped", area: "flowHtml", what: "the panel prints the file's text as markup: a saved \"<b>x</b>\" is a bold x in the notice, not the text the file holds",
+    find: "+esc(flowUnreadText(F, y=>'FY'+(y%100)))+",
+    repl: "+flowUnreadText(F, y=>'FY'+(y%100))+" },
+  { id: "v200-yearsel-counted-unsaid", area: "flowUnreadText", what: "the notice says \"nothing is counted\" while a whole year beside the bad entry is counted: [2025, 2026.5] totals $40M under \"nothing is counted\"",
+    find: "+' kept as saved'+(F.fys.length?",
+    repl: "+' kept as saved'+(false?" },
+  { id: "v200-yearsel-plural-it", area: "flowUnreadText", what: "the notice says \"It is kept\" however many entries it cannot read: 5,000 × \"x\" read \"It is kept as saved\"",
+    find: "+(one?'It is':'They are')",
+    repl: "+'It is'" },
+  { id: "v200-yearsel-toggle-from-all", area: "flowToggleYear", what: "a toggle on a saved selection it cannot read starts from every year: FY27 switched on beside \"2026\" switches FY27 OFF and counts the other five, $40M",
+    find: "  const all=flowYears(), cur=flowSavedYears()||all.slice();",
+    repl: "  const all=flowYears(), cur=(flowSavedYears()||[]).length? flowSavedYears() : all.slice();" },
   // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.
   { id: "v200-r3-landed-view-unsaid", area: "_driveStorePushRun", what: "a folder save that lands while a locked view is on screen says “🔒 Not kept — PB27 is a locked view. ✅ Saved …” again, naming no plan (or, quiet, leaves persist's refusal on screen)",
     find: "  if(CYCVIEW){ _cycRefusedAt=0; setStat('✅ <b>Saved the working plan</b> of '+esc(APPN_LBL[ap]||ap)+' FY'+(fy%100)+' to the shared folder — '\n    +Math.round(body.length/1024)+' KB, built before '+blLbl(CYCVIEW)+' was put on screen. '+blLbl(CYCVIEW)+' is a locked view: nothing in it '\n    +'is saved. Everyone sees the working plan on their next refresh.'+penNote+lateNote); render(); return true; }\n",
```

### A.3 `diffs/c1-audit-recon.diff` (blob ddf8940679b6898e816d3ab8834f7f75cdb90f0e)

```diff
--- ../base/tools/export-audit/audit-recon.mjs	2026-10-12 21:17:00.000000000 +0000
+++ c1/tools/export-audit/audit-recon.mjs	2026-10-13 00:12:04.840093320 +0000
@@ -5123,6 +5123,169 @@
   await settleBoards();
 })();
 // ==== end v2.00 (U14) ====
+// ==== v2.00 (U34): a saved year selection this board did not write is read as no year, kept as saved and said -- never as ALL YEARS ====
+// Codex's review, as Brad supplied it on 12 Oct: "the malformed saved-year selection"; Brad: "record the malformed saved-year
+// selection ... explicitly". U14 keeps a saved year the board cannot answer for and says it; this is the selection the board
+// never writes at all, as a hand-edited or damaged saved file carries it. The board writes null (ALL YEARS) or a list of whole
+// years from its own buttons, and nothing else. The board is U14's no-plan fixture: O&M, one service, F1 asking $1,000M, base
+// year 2027, FY27 pot $500M, MS.years {2027}, the rule off; workbook O&M FY25 'USAF O&M Discretionary' $40M. Offered: FY25,
+// FY27-FY31; ALL YEARS = 40 + 500 = $540M. Its saved file is built once (buildSavedHtml); for each shape, the file's own
+// appropriation's flow.fys is replaced AS TEXT, the file is opened through the board's opening path (boot({html})), read
+// apart in the calculation, the panel and the export (its bytes read back), then saved and opened again.
+// A SHAPE THE BOARD DID NOT WRITE -- not a list ("2026", {}, 2027), an empty list, or entries that are not whole numbers
+// ("2027", 2026.5, null, true, text) -- counts no year from what it cannot read; it is never read as ALL YEARS, never as a
+// year it is not, and it is said: the scope label (the panel, the chart, the export's Scope line), the panel's notice
+// (quoting the file, escaped) and the export's NOTE, with what is counted instead. It is kept as saved, byte for byte
+// through the reads, the save and the reopen, until a person chooses again; a year switched on starts from the years it could
+// read. CONTROLS (as before): no key and null are ALL YEARS; duplicates are read once and an unsorted list in order, with
+// nothing said; a whole year no appropriation offers is U14's notice.
+// FAILS ON d66dd60 (U14; records head 7ee498a): every shape the board did not write -- "2026", {}, 2027 and [] read as ALL YEARS
+// $540M, ALL YEARS lit, nothing said; ["2027"] as FY27 $500M; [2026.5] and 5,000 × "x" as ALL YEARS; [null] and [true] as
+// "saved FY0 / FY1 not available"; [2025, 2026.5] and ["<b>x</b>", 2027] counted their one whole year with nothing said; and
+// FY27 switched on beside "2026" switched it OFF from every year ($40M). Passing there too: the six controls, and FY27 switched
+// on beside [2025, 2026.5], ALL YEARS and a year's only on "2026".
+await (async () => {
+  const name = 'v2.00 (U34) — a saved year selection this board did not write is never read as ALL YEARS; it is kept and said';
+  const { bootMark, bootRelease, settleBoards } = await import('./boot.mjs');
+  const __bm = bootMark();
+  try {
+    const J = JSON.stringify, M = 1000000;
+    const row = (fy, title, budget, amt, office) => { const r = Array(32).fill(''); r[0] = fy; r[1] = fy + '-03'; r[2] = 'U14' + fy; r[3] = title;
+      r[4] = budget; r[7] = 'Event ' + title; r[9] = amt; r[10] = 'Allocated'; r[18] = office; return r; };
+    const WB = { om: { asOf: '2026-09', hdr: [], read: 1, noFy: 0, rows: { 2025: [row(2025, 'Ordinary Support', 'USAF O&M Discretionary', 40 * M, 'Program (TSS)')] } } };
+    // window.confirm answering `ans`, every question counted and kept
+    const counted = (w, ans) => { w.__cc = 0; w.__ccMsgs = []; w.confirm = m => { w.__cc++; w.__ccMsgs.push(String(m)); return ans; }; };
+    const X = boot();
+    seed(X.ev, { services: ['USAF'], items: [it('F1', 'PSM', [1000 * M])], disc: [500 * M], mand: [0], order: ['F1'] });
+    X.ev(`BASE_ITEMS.length=0; DATA.items.forEach(function(i){ BASE_ITEMS.push(i); BASE_ASK[i.id]=i.ask.slice(); });
+      S.bm={disc:[${500 * M}], mand:[0], adds:[]}; MS.base=2027; MS.cur=2027; FYMON=fyMonths(2027); MS.years={2027:S};
+      applyState(S); MS.years[2027]=S; EXDB.all=${J(WB)}; EXDB.ts=1;
+      var C=flowCfg(); delete C.pseudo; C.other={}; C.fys=null; C.aps=null; save(); 'ok'`);
+    counted(X.w, true);
+    const slug = JSON.parse(X.ev('JSON.stringify(_AP.slug)')), html0 = X.ev('buildSavedHtml()');
+    const RE = /(<script type="application\/json" id="pubState">)([\s\S]*?)(<\/script>)/;
+    // the saved file with its own appropriation's flow.fys replaced by `text`, as a hand edit leaves it (undefined: no key)
+    const withFys = text => html0.replace(RE, (m, a, b, c) => {
+      const P = JSON.parse(b), F = P.appns[slug].flow;
+      if (text === undefined) delete F.fys; else F.fys = '__FYS__';
+      let s = J(P).replace(/</g, '\\u003c');
+      if (text !== undefined) s = s.replace('"__FYS__"', () => text);
+      return a + s + c; });
+    const fileFys = h => { const F = JSON.parse(RE.exec(h)[2]).appns[slug].flow; return 'fys' in F ? J(F.fys) : '(no key)'; };
+    const now = R => JSON.parse(R.ev(`(function(){ var F=flowCalc(); return JSON.stringify({stored:String(JSON.stringify(flowCfg().fys)),
+      sel:flowSelYears(), t:[F.tot, F.execV, F.planV], label:F.label}); })()`));
+    const panel = R => { R.ev(`flowOpen=true; flowSel=''; flowBody(); 'ok'`);
+      const b = R.w.document.getElementById('flowBody'), btn = [...b.querySelectorAll('button')], n = b.querySelector('.flowunread'), u = b.querySelector('.flowunavail');
+      const tf = /total funding \$([\d,]+\.\d\d)M/.exec(b.textContent);
+      return { total: tf ? tf[1] : '', allOn: btn.filter(x => x.getAttribute('onclick') === 'flowAllYears()').map(x => x.classList.contains('on'))[0],
+        lit: btn.filter(x => /^flowToggleYear\(\d+\)$/.test(x.getAttribute('onclick') || '') && x.classList.contains('on')).map(x => x.textContent),
+        notice: n ? n.textContent : '', html: n ? n.innerHTML : '', unavail: u ? u.textContent : '' }; };
+    const cell = c => (c && typeof c === 'object' && 'v' in c) ? c.v : c;
+    // the exported workbook read back from its bytes
+    const book = async R => { const wb = JSON.parse(await R.w.eval(`(async function(){ var cap=null, _B=window.Blob;
+        window.Blob=function(p,o){ if(p&&p[0]&&p[0].byteLength) cap=p[0]; return new _B(p,o); };
+        try{ exportFlow(); }catch(e){ window.Blob=_B; return JSON.stringify({__err:'threw '+String((e&&e.message)||e)}); }
+        window.Blob=_B; if(!cap) return JSON.stringify({__err:'no file'});
+        var ab=cap.buffer.slice(cap.byteOffset,cap.byteOffset+cap.byteLength); return JSON.stringify(await xlsxRead(ab)); })()`));
+      const ff = wb['Funds Flow'] || [], all = lab => ff.filter(r => w6Lbl(r) === lab).map(r => num(cell(r[1]))).filter(v => v !== null);
+      return { err: wb.__err || 'ok', scope: w6Lbl(ff[1] || []), tot: all('TOTAL FUNDING'),
+        notes: ff.map(w6Lbl).filter(t => /^NOTE: The saved year selection (is|holds) /.test(t)) }; };
+    // one shape, opened: what it counts and says everywhere, and what the save and the reopen carry
+    const look = async text => {
+      const R = boot({ html: withFys(text) }); counted(R.w, true);
+      const a = now(R), P = panel(R), B = await book(R), h2 = R.ev('buildSavedHtml()'), R2 = boot({ html: h2 }), r = now(R2);
+      return [a.stored, a.sel, a.t, a.label, P.total, P.allOn, P.lit, P.notice, P.unavail, B.err, B.scope, B.tot, B.notes,
+        fileFys(h2) === (text === undefined ? '(no key)' : J(JSON.parse(text))), r.stored === a.stored, r.sel, r.t[0], R.w.__cc, R.errors.length + R2.errors.length]; };
+    // the same, expected -- every value a literal
+    const want = (stored, sel, t, label, total, allOn, lit, notice, unavail, notes) =>
+      [stored, sel, t, label, total, allOn, lit, notice, unavail, 'ok', 'Scope: ' + label, [t[0], t[0]], notes, true, true, sel, t[0], 0, 0];
+    const ALL = 'FY25, FY27–FY31 · all years · all appropriations · FY27, FY28, FY29, FY30, FY31 planned, the rest executed';
+    const L0 = 'no year counted · all appropriations · saved year selection not a list of years, not counted';
+    const L1 = 'no year counted · all appropriations · 1 saved entry not a year, not counted';
+    const O = [2025, 2027, 2028, 2029, 2030, 2031], T540 = [540 * M, 40 * M, 500 * M], T500 = [500 * M, 0, 500 * M], T0 = [0, 0, 0];
+    const TAIL = ' Click ALL YEARS, a year’s only, or a year to switch it on or off, to choose again; any of these replaces what cannot be read.';
+    const WH = q => 'The saved year selection is ' + q + ', not a list of years this board can read. It is kept as saved, and nothing is counted.';
+    const H1 = q => 'The saved year selection holds ' + q + ', which this board cannot read as a year. It is kept as saved, and nothing is counted.';
+    const whole = (q, text) => [text, J(want(text, [], T0, L0, '0.00', false, [], WH(q) + TAIL, '', ['NOTE: ' + WH(q)]))];
+    const one = (q, text) => [text, J(want(text, [], T0, L1, '0.00', false, [], H1(q) + TAIL, '', ['NOTE: ' + H1(q)]))];
+    const SHAPES = [
+      // [where, what is promised, the text in the file, expected]
+      ['a string', 'the saved selection "2026", not a list: no year counted (never ALL YEARS $540M), ALL YEARS not lit, said on the panel and in the export, kept through the save and the reopen', ...whole('"2026"', '"2026"')],
+      ['an object', '{}: no year counted, said, kept', ...whole('{}', '{}')],
+      ['a bare number', '2027 alone, not in a list: no year counted (never ALL YEARS, never a guess at FY27), said, kept', ...whole('2027', '2027')],
+      ['an empty list', '[]: names no year -- no year counted (never ALL YEARS), said, kept', ...whole('[]', '[]')],
+      ['a year as text', '["2027"]: text is not a year the board writes -- not counted as FY27 (no guess), said, kept', ...one('"2027"', '["2027"]')],
+      ['not a whole number', '[2026.5]: not counted, never ALL YEARS, said, kept', ...one('2026.5', '[2026.5]')],
+      ['null in the list', '[null] (NaN, as a saved file writes it): not read as a year "FY0", said as it is saved, kept', ...one('null', '[null]')],
+      ['true in the list', '[true]: not read as a year "FY1", said as it is saved, kept', ...one('true', '[true]')],
+      ['one whole year, one not', '[2025, 2026.5]: FY25 counted ($40M executed), 2026.5 said and not counted, kept',
+        '[2025,2026.5]', J(want('[2025,2026.5]', [2025], [40 * M, 40 * M, 0], 'FY25 · all appropriations · 1 saved entry not a year, not counted', '40.00', false, ['FY25'],
+          'The saved year selection holds 2026.5, which this board cannot read as a year. It is kept as saved and not counted: this total counts FY25 only.' + TAIL, '',
+          ['NOTE: The saved year selection holds 2026.5, which this board cannot read as a year. It is kept as saved and not counted: this total counts FY2025 only.']))],
+      ['text that is markup', '["<b>x</b>", 2027]: FY27 counted ($500M), the text quoted as saved and shown as text, never as markup',
+        '["<b>x</b>",2027]', J(want('["<b>x</b>",2027]', [2027], T500, 'FY27 · all appropriations · PLANNED (board allocation, O&M) · 1 saved entry not a year, not counted', '500.00', false, ['FY27 · plan'],
+          'The saved year selection holds "<b>x</b>", which this board cannot read as a year. It is kept as saved and not counted: this total counts FY27 only.' + TAIL, '',
+          ['NOTE: The saved year selection holds "<b>x</b>", which this board cannot read as a year. It is kept as saved and not counted: this total counts FY2027 only.']))],
+      ['an enormous list', '5,000 entries of "x": no year counted, never ALL YEARS; three quoted and the rest counted, said in the plural, kept',
+        '[' + Array(5000).fill('"x"').join(',') + ']', J(want('[' + Array(5000).fill('"x"').join(',') + ']', [], T0, 'no year counted · all appropriations · 5000 saved entries not a year, not counted', '0.00', false, [],
+          'The saved year selection holds "x", "x", "x" and 4997 more, which this board cannot read as years. They are kept as saved, and nothing is counted.' + TAIL, '',
+          ['NOTE: The saved year selection holds "x", "x", "x" and 4997 more, which this board cannot read as years. They are kept as saved, and nothing is counted.']))],
+      ['CONTROL — no key', 'no saved selection is ALL YEARS: $540M, ALL YEARS lit, nothing said', undefined, J(want('undefined', O, T540, ALL, '540.00', true, [], '', '', []))],
+      ['CONTROL — null', 'null, the board\'s own ALL YEARS: $540M, ALL YEARS lit, nothing said', 'null', J(want('null', O, T540, ALL, '540.00', true, [], '', '', []))],
+      ['CONTROL — duplicates', '[2027, 2027]: FY27 once, $500M, nothing said, kept as saved', '[2027,2027]',
+        J(want('[2027,2027]', [2027], T500, 'FY27 · all appropriations · PLANNED (board allocation, O&M)', '500.00', false, ['FY27 · plan'], '', '', []))],
+      ['CONTROL — out of order', '[2031, 2025, 2027]: read in order, $540M, nothing said, kept as saved', '[2031,2025,2027]',
+        J(want('[2031,2025,2027]', [2025, 2027, 2031], T540, 'FY25, FY27, FY31 · all appropriations · FY27, FY31 planned, the rest executed', '540.00', false, ['FY25', 'FY27 · plan', 'FY31 · plan'], '', '', []))],
+      ['CONTROL — an enormous list of one year', '2027 five thousand times: FY27, $500M, nothing said, kept as saved', '[' + Array(5000).fill('2027').join(',') + ']',
+        J(want('[' + Array(5000).fill('2027').join(',') + ']', [2027], T500, 'FY27 · all appropriations · PLANNED (board allocation, O&M)', '500.00', false, ['FY27 · plan'], '', '', []))],
+      ['CONTROL — a whole year no appropriation offers', '[2040]: U14\'s notice, nothing counted, nothing else said', '[2040]',
+        J(want('[2040]', [], T0, 'no year counted · all appropriations · saved FY40 not available, not counted', '0.00', false, [], '',
+          'The saved year selection includes FY40, which this board cannot answer for now: it holds no plan for that year, no imported row is filed or counted in it, and it is outside the plan window (FY27–FY31). It stays in the saved selection, and nothing is counted. Click ALL YEARS, or a year’s only, to choose again; switching a year on or off keeps it.', []))],
+    ];
+    for (const [where, what, text, exp] of SHAPES) {
+      w5Chk(name, where, what, J(await look(text)), exp);
+      bootRelease(__bm, [X.w]);
+    }
+    // the markup is text on the panel: escaped in the notice's HTML, no element made from it
+    {
+      const R = boot({ html: withFys('["<b>x</b>",2027]') }); counted(R.w, true); const P = panel(R);
+      w5Chk(name, 'text that is markup · escaped', 'the notice\'s HTML carries "&lt;b&gt;x&lt;/b&gt;" (text, as the DOM writes it back), and its only <b> elements are the board\'s own three -- none is made from the file',
+        J([P.html.indexOf('"&lt;b&gt;x&lt;/b&gt;"') >= 0, (P.html.match(/<b[ >]/g) || []).length]), J([true, 3]));
+      bootRelease(__bm, [X.w]);
+    }
+    // a person's click on such a selection chooses again, as the notice says
+    const click = (R, onclick) => { R.ev(`flowOpen=true; flowBody(); 'ok'`);
+      const b = [...R.w.document.querySelectorAll('#flowBody button')].find(x => x.getAttribute('onclick') === onclick);
+      if (!b) return false; b.click(); return true; };
+    {
+      const R = boot({ html: withFys('"2026"') }); counted(R.w, true);
+      const ok = click(R, 'flowToggleYear(2027)'), a = now(R), P = panel(R);
+      w5Chk(name, '"2026", then FY27 switched on', 'the toggle starts from the years it could read -- none -- so FY27 is the selection: [2027] saved, $500M, no notice (never every year but FY27)',
+        J([ok, a.stored, a.sel, a.t, P.notice, P.lit, R.errors.length]), J([true, '[2027]', [2027], T500, '', ['FY27 · plan'], 0]));
+      bootRelease(__bm, [X.w]);
+    }
+    {
+      const R = boot({ html: withFys('[2025,2026.5]') }); counted(R.w, true);
+      const ok = click(R, 'flowToggleYear(2027)'), a = now(R), P = panel(R);
+      w5Chk(name, '[2025, 2026.5], then FY27 switched on', 'CONTROL — FY25 kept and FY27 added: [2025, 2027] saved, $540M; what could not be read is replaced, and the notice goes',
+        J([ok, a.stored, a.sel, a.t, P.notice, R.errors.length]), J([true, '[2025,2027]', [2025, 2027], T540, '', 0]));
+      bootRelease(__bm, [X.w]);
+    }
+    {
+      const R = boot({ html: withFys('"2026"') }); counted(R.w, true);
+      const okA = click(R, 'flowAllYears()'), a = now(R), okO = click(R, 'flowOneYear(2027)'), b = now(R);
+      w5Chk(name, '"2026", then ALL YEARS, then FY27\'s only', 'CONTROL — ALL YEARS on its own click: null saved, $540M; then FY27\'s only: [2027], $500M',
+        J([okA, a.stored, a.t, okO, b.stored, b.t, R.errors.length]), J([true, 'null', T540, true, '[2027]', T500, 0]));
+      bootRelease(__bm, [X.w]);
+    }
+    w5Chk(name, 'nothing asked', 'the base board asked nothing while its file was built', J([X.w.__cc, X.errors.length]), J([0, 0]));
+  } catch (e) {
+    failures.push({ scenario: name, where: 'harness', what: 'the block threw: ' + String((e && e.message) || e).slice(0, 160), got: 'threw', want: 'ran' });
+  }
+  bootRelease(__bm, []);
+  await settleBoards();
+})();
+// ==== end v2.00 (U34) ====
 
 {
   const src = _selfRead(_selfPath(import.meta.url), 'utf8');
```

## Appendix B — the fix round's exact diffs (c2 against c1)

The three diffs follow, exactly as in `diffs/`.

### B.1 `diffs/c2-board-vs-c1.diff` (blob ce20006edd689db14a7b2e6f48619dc5075bffe4)

```diff
--- c1/prioritization-board-grid.html	2026-10-13 00:12:04.728118657 +0000
+++ c2/prioritization-board-grid.html	2026-10-13 08:50:04.332953204 +0000
@@ -15362,9 +15362,12 @@
 }
 // v2.00 (U34): what of the saved year selection this board cannot read as years, or null when it reads all of it: the whole
 // value (not a list, or an empty one), or the entries that are not whole numbers. `what` quotes the file -- at most three
-// entries, each cut at 40 characters -- for the panel's notice (escaped there) and the export's NOTE.
+// entries, each cut at 40 characters -- for the panel's notice (escaped there) and the export's NOTE. Each is cut between
+// characters, never inside one, and U+FFFE / U+FFFF are quoted as the file's own escape ("\uffff"): XML 1.0 forbids both, so
+// the export's sheet holding one would not be a well-formed workbook. Only the first 82 units are read, so the cost stays small.
 function flowUnreadSaved(){
-  const v=flowCfg().fys, q=x=>{ const t=String(JSON.stringify(x)); return t.length>40? t.slice(0,40)+'\u2026' : t; };
+  const v=flowCfg().fys, q=x=>{ const t=Array.from(String(JSON.stringify(x)).slice(0,82).replace(/[\uFFFE\uFFFF]/g, c=>'\\u'+c.charCodeAt(0).toString(16)));
+    return t.length>40? t.slice(0,40).join('')+'\u2026' : t.join(''); };
   if(v==null) return null;
   if(!Array.isArray(v) || !v.length) return {whole:true, n:1, what:q(v)};
   const bad=v.filter(y=>!flowYearOk(y));
@@ -15419,13 +15422,15 @@
 // v2.00 (U14): ALL YEARS names its years as they run -- "FY25, FY27–FY31" -- so a dash never spans a year that is in no total;
 // it read "FY25–FY31" over a FY26 nothing counted in. A saved selection with a year the board cannot answer for is never
 // called all years (`un`: those years; flowCalc says them after the label). No year counted reads "no year counted".
-function flowScopeLabel(ys, aps, un){
+// v2.00 (U34): nor is one holding what the board cannot read as years (`ur`: flowUnreadSaved), even when the years it can read
+// are every year offered; it read "· all years" beside "this total counts FY25, FY27, ... only".
+function flowScopeLabel(ys, aps, un, ur){
   const allY=flowYears(), FY=y=>'FY'+(y%100);
   const runs=a=>a.reduce((o,y)=>{ const r=o[o.length-1]; if(r && y===r[1]+1) r[1]=y; else o.push([y,y]); return o; }, [])
     .map(r=>r[0]===r[1]? FY(r[0]) : FY(r[0])+'\u2013'+FY(r[1])).join(', ');
   const yl = !ys.length? 'no year counted'
     : ys.length===1? 'FY'+(ys[0]%100)
-    : ((ys.length===allY.length && !(un||[]).length)? runs(ys)+' \u00b7 all years'
+    : ((ys.length===allY.length && !(un||[]).length && !ur)? runs(ys)+' \u00b7 all years'
        : ys.map(y=>'FY'+(y%100)).join(', '));
   const al = aps.length===FLOW_APPNS.length? 'all appropriations'
     : aps.map(a=>APPN_LBL[a]).join(' + ');
@@ -15610,7 +15615,7 @@
   const UR = (arg==null)? flowUnreadSaved() : null;     // v2.00 (U34): what of the saved selection cannot be read as years
   const AS = (arg==null)? flowSelAppns() : FLOW_APPNS.slice();
   const F={fy:YS[YS.length-1], fys:YS, aps:AS, multi:YS.length>1, unavail:UN, unread:UR,
-           label:flowScopeLabel(YS,AS,UN), tot:0, appn:APPN_SLUGS.reduce(function(o,s){ o[s]=0; return o; },{}), dual:0, rows:0,
+           label:flowScopeLabel(YS,AS,UN,UR), tot:0, appn:APPN_SLUGS.reduce(function(o,s){ o[s]=0; return o; },{}), dual:0, rows:0,
            // Executed money and planned money are both in the total, and which is which is a fact
            // the chart has to be able to STATE - so it is counted here rather than inferred later
            // from the year list, which would go wrong the moment a year carries a partial import.
@@ -15697,7 +15702,7 @@
   // export's Scope line and its file name all print this label -- kept in the selection, and not counted
   if(UN.length) F.label+=' \u00b7 saved '+UN.map(y=>'FY'+(y%100)).join(', ')+' not available, not counted';
   // v2.00 (U34): and a saved selection, or part of one, that cannot be read as years
-  if(UR) F.label+=' \u00b7 '+(UR.whole? 'saved year selection not a list of years' : UR.n+' saved '+(UR.n===1?'entry':'entries')+' not a year')+', not counted';
+  if(UR) F.label+=' \u00b7 '+(UR.whole? 'saved year selection not a list of years' : UR.n+' saved '+(UR.n===1?'entry not a year':'entries not years'))+', not counted';
   return F;
 }
 // v1.99 (item 92): what partner and FMS money is, said the same way on the panel and in the export
@@ -16505,12 +16510,13 @@
   let h='<div style="margin-bottom:6px;display:flex;gap:5px;flex-wrap:wrap;align-items:center">'
     +'<span style="font-size:9px;color:var(--dim);font-weight:800;letter-spacing:.8px;width:74px">FISCAL YEAR</span>'
     // v2.00 (U14): ALL YEARS is lit only for ALL YEARS: a saved selection holding a year the board cannot answer for is not it
-    +chip(selY.length===yrs.length && !F.unavail.length,'ALL YEARS','flowAllYears()','Every year this board can answer for \u2014 executed and planned together')
+    // v2.00 (U34): nor is one holding what the board cannot read as years; the years it counts are lit instead
+    +chip(selY.length===yrs.length && !F.unavail.length && !F.unread,'ALL YEARS','flowAllYears()','Every year this board can answer for \u2014 executed and planned together')
     // A planned year is marked ON THE CHIP. Both kinds are selectable together and the total adds
     // them up, so which is which has to be visible at the point of choosing, not only afterwards.
     +yrs.map(function(f){
         const pl=flowYearKind(f)==='plan';
-        return chip(selY.indexOf(f)>=0 && (selY.length<yrs.length || F.unavail.length>0),'FY'+(f%100)+(pl?' \u00b7 plan':''),
+        return chip(selY.indexOf(f)>=0 && ((selY.length<yrs.length || F.unavail.length>0) || !!F.unread),'FY'+(f%100)+(pl?' \u00b7 plan':''),
             'flowToggleYear('+f+')',
             // v2.00 (R1): a planned year with rows STORED under it has every one COUNTED in a later year (OBBBA). It said "has no
             // O&M execution imported" of an FY25 whose O&M rows were imported and are all counted in FY26.
```

### B.2 `diffs/c2-mutate-vs-c1.diff` (blob 5dc5c98269db8e2a5ac456c3d13b3ed93ac18230)

```diff
--- c1/tools/export-audit/mutate.mjs.txt	2026-10-13 00:12:05.132118681 +0000
+++ c2/tools/export-audit/mutate.mjs.txt	2026-10-13 08:51:13.892957339 +0000
@@ -4323,6 +4323,53 @@
   { id: "v200-yearsel-toggle-from-all", area: "flowToggleYear", what: "a toggle on a saved selection it cannot read starts from every year: FY27 switched on beside \"2026\" switches FY27 OFF and counts the other five, $40M",
     find: "  const all=flowYears(), cur=flowSavedYears()||all.slice();",
     repl: "  const all=flowYears(), cur=(flowSavedYears()||[]).length? flowSavedYears() : all.slice();" },
+  // v2.00 (U34, the verifiers' round, 13 Oct): the quote of a saved entry is cut between characters and never carries what
+  // XML forbids; a selection holding what the board cannot read is never ALL YEARS; falsy values, both notices, the export's rows.
+  { id: "v200-yearsel-quote-xml-unsafe", area: "flowUnreadSaved", what: "the quote carries U+FFFE / U+FFFF as they are: a saved [\"\\uffff\", 2027] puts a character XML 1.0 forbids into the export's sheet, which is then not a well-formed workbook",
+    find: ".slice(0,82).replace(/[\\uFFFE\\uFFFF]/g, c=>'\\\\u'+c.charCodeAt(0).toString(16)));",
+    repl: ".slice(0,82));" },
+  { id: "v200-yearsel-quote-splits-char", area: "flowUnreadSaved", what: "the quote is cut by UTF-16 units: an entry of 45 emoji is cut inside the 20th -- half a character on the panel, U+FFFD in the export, neither in the file",
+    find: "q=x=>{ const t=Array.from(String(JSON.stringify(x)).slice(0,82)",
+    repl: "q=x=>{ const t=(s=>s.split(''))(String(JSON.stringify(x)).slice(0,82)" },
+  { id: "v200-yearsel-quote-uncut", area: "flowUnreadSaved", what: "the quote is not cut at 40 characters: an entry of 120 \"A\" is quoted whole, to 82 characters",
+    find: "    return t.length>40? t.slice(0,40).join('')+'\\u2026' : t.join(''); };",
+    repl: "    return t.join(''); };" },
+  { id: "v200-yearsel-falsy-all-years", area: "flowSavedYears", what: "a falsy saved selection reads as ALL YEARS again: \"\", 0 or false counts every year, $540M, while the notice says nothing is counted",
+    find: "  if(C.fys==null) return null;\n  const s=(Array.isArray(C.fys)? C.fys : [])",
+    repl: "  if(!C.fys) return null;\n  const s=(Array.isArray(C.fys)? C.fys : [])" },
+  { id: "v200-yearsel-falsy-unsaid", area: "flowUnreadSaved", what: "a falsy saved selection is not said: \"\", 0 or false counts no year with no reason given, on the panel, in the label and in the export",
+    find: "  if(v==null) return null;\n  if(!Array.isArray(v) || !v.length)",
+    repl: "  if(!v) return null;\n  if(!Array.isArray(v) || !v.length)" },
+  { id: "v200-yearsel-allyears-lit-unread", area: "flowHtml", what: "ALL YEARS is lit beside an entry the board cannot read when the years it can read are every year offered: [2025, 2027-2031, \"x\"] lights ALL YEARS under a notice saying \"this total counts FY25, FY27, ... only\"",
+    find: "!F.unavail.length && !F.unread,'ALL YEARS'",
+    repl: "!F.unavail.length,'ALL YEARS'" },
+  { id: "v200-yearsel-label-all-years-unread", area: "flowScopeLabel", what: "the scope label says \"all years\" beside an entry the board cannot read: [2025, 2027-2031, \"x\"] reads \"FY25, FY27–FY31 · all years\" on the panel and in the export's Scope line",
+    find: "!(un||[]).length && !ur)?",
+    repl: "!(un||[]).length)?" },
+  { id: "v200-yearsel-label-ur-unpassed", area: "flowCalc", what: "flowCalc does not tell the label what it cannot read: [2025, 2027-2031, \"x\"] reads \"· all years\" again",
+    find: "label:flowScopeLabel(YS,AS,UN,UR),",
+    repl: "label:flowScopeLabel(YS,AS,UN)," },
+  { id: "v200-yearsel-year-chips-unlit-unread", area: "flowHtml", what: "beside an entry the board cannot read, with every offered year read, no year button is lit: nothing on screen shows which years the total counts",
+    find: "(selY.length<yrs.length || F.unavail.length>0) || !!F.unread)",
+    repl: "(selY.length<yrs.length || F.unavail.length>0))" },
+  { id: "v200-yearsel-note-replaces-line", area: "exportFlow", what: "the export's U34 NOTE replaces the row under the Source line instead of being added: the other-sources line goes from the export when a saved entry cannot be read",
+    find: "  if(F.unread) sum.splice(3,0,['NOTE: '+flowUnreadText(F, y=>'FY'+y)],[]);",
+    repl: "  if(F.unread) sum.splice(3,1,['NOTE: '+flowUnreadText(F, y=>'FY'+y)],[]);" },
+  { id: "v200-yearsel-note-order", area: "exportFlow", what: "the export's NOTEs swap places: U34's NOTE comes first under the Scope line and U14's after it, unlike the panel, where U14's notice is first",
+    find: "  if(F.unread) sum.splice(3,0,['NOTE: '+flowUnreadText(F, y=>'FY'+y)],[]);\n  // v2.00 (U14): a saved year the board cannot answer for now, in the panel's words, first under the Scope line\n  if(F.unavail.length) sum.splice(3,0,['NOTE: '+flowUnavailText(F, y=>'FY'+y)],[]);",
+    repl: "  if(F.unavail.length) sum.splice(3,0,['NOTE: '+flowUnavailText(F, y=>'FY'+y)],[]);\n  // v2.00 (U14): a saved year the board cannot answer for now, in the panel's words, first under the Scope line\n  if(F.unread) sum.splice(3,0,['NOTE: '+flowUnreadText(F, y=>'FY'+y)],[]);" },
+  { id: "v200-yearsel-label-unsaid-beside-u14", area: "flowCalc", what: "the scope label says only U14's part when a saved year it cannot answer for sits beside an entry it cannot read: [2040, \"x\"] reads \"saved FY40 not available\" and nothing of \"x\"",
+    find: "  if(UR) F.label+=' \\u00b7 '+(UR.whole?",
+    repl: "  if(UR && !UN.length) F.label+=' \\u00b7 '+(UR.whole?" },
+  { id: "v200-yearsel-panel-unsaid-beside-u14", area: "flowHtml", what: "the panel shows only U14's notice when a saved year it cannot answer for sits beside an entry it cannot read: [2040, \"x\"] says nothing of \"x\" on screen",
+    find: "    +(F.unread? '<div class=\"flowunread\"",
+    repl: "    +(F.unread && !F.unavail.length? '<div class=\"flowunread\"" },
+  { id: "v200-yearsel-year-range", area: "flowYearOk", what: "a year must lie in 2000-2099: a saved [1999] on a board holding FY1999 rows -- a year the board offers and writes -- is said as an entry it cannot read, and its $7M is not counted",
+    find: "function flowYearOk(y){ return typeof y==='number' && Number.isInteger(y); }",
+    repl: "function flowYearOk(y){ return typeof y==='number' && Number.isInteger(y) && y>=2000 && y<=2099; }" },
+  { id: "v200-yearsel-plural-label", area: "flowCalc", what: "the scope label's plural is \"5000 saved entries not a year\" again",
+    find: "(UR.n===1?'entry not a year':'entries not years')",
+    repl: "(UR.n===1?'entry not a year':'entries not a year')" },
   // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.
   { id: "v200-r3-landed-view-unsaid", area: "_driveStorePushRun", what: "a folder save that lands while a locked view is on screen says “🔒 Not kept — PB27 is a locked view. ✅ Saved …” again, naming no plan (or, quiet, leaves persist's refusal on screen)",
     find: "  if(CYCVIEW){ _cycRefusedAt=0; setStat('✅ <b>Saved the working plan</b> of '+esc(APPN_LBL[ap]||ap)+' FY'+(fy%100)+' to the shared folder — '\n    +Math.round(body.length/1024)+' KB, built before '+blLbl(CYCVIEW)+' was put on screen. '+blLbl(CYCVIEW)+' is a locked view: nothing in it '\n    +'is saved. Everyone sees the working plan on their next refresh.'+penNote+lateNote); render(); return true; }\n",
```

### B.3 `diffs/c2-audit-recon-vs-c1.diff` (blob d9342d1090059ec43611dc6b840d83d3000447ad)

```diff
--- c1/tools/export-audit/audit-recon.mjs	2026-10-13 00:12:04.840093320 +0000
+++ c2/tools/export-audit/audit-recon.mjs	2026-10-13 09:01:01.792727588 +0000
@@ -5135,15 +5135,23 @@
 // A SHAPE THE BOARD DID NOT WRITE -- not a list ("2026", {}, 2027), an empty list, or entries that are not whole numbers
 // ("2027", 2026.5, null, true, text) -- counts no year from what it cannot read; it is never read as ALL YEARS, never as a
 // year it is not, and it is said: the scope label (the panel, the chart, the export's Scope line), the panel's notice
-// (quoting the file, escaped) and the export's NOTE, with what is counted instead. It is kept as saved, byte for byte
+// (quoting the file, escaped) and the export's NOTE, with what is counted instead. It is kept as saved (the same value)
 // through the reads, the save and the reopen, until a person chooses again; a year switched on starts from the years it could
 // read. CONTROLS (as before): no key and null are ALL YEARS; duplicates are read once and an unsorted list in order, with
 // nothing said; a whole year no appropriation offers is U14's notice.
-// FAILS ON d66dd60 (U14; records head 7ee498a): every shape the board did not write -- "2026", {}, 2027 and [] read as ALL YEARS
-// $540M, ALL YEARS lit, nothing said; ["2027"] as FY27 $500M; [2026.5] and 5,000 × "x" as ALL YEARS; [null] and [true] as
-// "saved FY0 / FY1 not available"; [2025, 2026.5] and ["<b>x</b>", 2027] counted their one whole year with nothing said; and
-// FY27 switched on beside "2026" switched it OFF from every year ($40M). Passing there too: the six controls, and FY27 switched
-// on beside [2025, 2026.5], ALL YEARS and a year's only on "2026".
+// AND (the verifiers' round, 13 Oct): "", 0 and false are not lists either. A quoted entry is cut at 40 characters, between
+// characters, and U+FFFE / U+FFFF are quoted as their escape -- XML 1.0 forbids both -- so every shape's export is a
+// well-formed workbook, every part read as XML (w7Pkg). Every offered year beside an entry it cannot read is not ALL YEARS: the
+// chip is not lit, the label does not say "all years" (U14's rule). A year U14 says beside an entry U34 says: both said, U14's
+// NOTE first. The NOTE is ADDED to the export: every other row is as without the entry. CONTROL: a whole year the board offers
+// outside 2000-2099 (FY1999 rows) is a year -- no range is read into "a year".
+// FAILS ON d66dd60 (U14; records head 7ee498a): every shape the board did not write -- "2026", {}, 2027, [], "", 0 and false read
+// as ALL YEARS $540M, ALL YEARS lit, nothing said; ["2027"] as FY27 $500M; [2026.5], 5,000 × "x", 120 × "A" and "\ufffe" as ALL
+// YEARS; [null] and [true] as "saved FY0 / FY1 not available"; [2025, 2026.5], ["<b>x</b>", 2027], ["\uffff", 2027] and 45 emoji
+// beside 2027 counted their one whole year with nothing said; [2040, "x"] said FY40 only; [2025, 2027-2031, "x"] read as ALL
+// YEARS; so the export carried no U34 NOTE (both whole-export checks); and FY27 switched on beside "2026" switched it OFF from
+// every year ($40M). Passing there too: the seven controls, and FY27 switched on beside [2025, 2026.5], ALL YEARS and a year's
+// only on "2026".
 await (async () => {
   const name = 'v2.00 (U34) — a saved year selection this board did not write is never read as ALL YEARS; it is kept and said';
   const { bootMark, bootRelease, settleBoards } = await import('./boot.mjs');
@@ -5164,9 +5172,11 @@
     counted(X.w, true);
     const slug = JSON.parse(X.ev('JSON.stringify(_AP.slug)')), html0 = X.ev('buildSavedHtml()');
     const RE = /(<script type="application\/json" id="pubState">)([\s\S]*?)(<\/script>)/;
-    // the saved file with its own appropriation's flow.fys replaced by `text`, as a hand edit leaves it (undefined: no key)
-    const withFys = text => html0.replace(RE, (m, a, b, c) => {
+    // the saved file with its own appropriation's flow.fys replaced by `text`, as a hand edit leaves it (undefined: no key);
+    // `more`, when given, changes the rest of the saved state first (the FY1999 control's rows)
+    const withFys = (text, more) => html0.replace(RE, (m, a, b, c) => {
       const P = JSON.parse(b), F = P.appns[slug].flow;
+      if (more) more(P);
       if (text === undefined) delete F.fys; else F.fys = '__FYS__';
       let s = J(P).replace(/</g, '\\u003c');
       if (text !== undefined) s = s.replace('"__FYS__"', () => text);
@@ -5190,15 +5200,25 @@
       const ff = wb['Funds Flow'] || [], all = lab => ff.filter(r => w6Lbl(r) === lab).map(r => num(cell(r[1]))).filter(v => v !== null);
       return { err: wb.__err || 'ok', scope: w6Lbl(ff[1] || []), tot: all('TOTAL FUNDING'),
         notes: ff.map(w6Lbl).filter(t => /^NOTE: The saved year selection (is|holds) /.test(t)) }; };
-    // one shape, opened: what it counts and says everywhere, and what the save and the reopen carry
-    const look = async text => {
-      const R = boot({ html: withFys(text) }); counted(R.w, true);
-      const a = now(R), P = panel(R), B = await book(R), h2 = R.ev('buildSavedHtml()'), R2 = boot({ html: h2 }), r = now(R2);
+    // the exported Funds Flow sheet, every row as its cells' values
+    const flowRows = async R => { const wb = JSON.parse(await R.w.eval(`(async function(){ var cap=null, _B=window.Blob;
+        window.Blob=function(p,o){ if(p&&p[0]&&p[0].byteLength) cap=p[0]; return new _B(p,o); };
+        try{ exportFlow(); }catch(e){ window.Blob=_B; return '{}'; }
+        window.Blob=_B; if(!cap) return '{}';
+        var ab=cap.buffer.slice(cap.byteOffset,cap.byteOffset+cap.byteLength); return JSON.stringify(await xlsxRead(ab)); })()`));
+      return (wb['Funds Flow'] || []).map(r => (r || []).map(cell)); };
+    // one shape, opened: what it counts and says everywhere, and what the save and the reopen carry; last, the export's
+    // package, every part read as XML (w7Pkg) -- a workbook that is not well-formed is not an export
+    const look = async (text, more) => {
+      const R = boot({ html: withFys(text, more) }); counted(R.w, true);
+      const a = now(R), P = panel(R), B = await book(R), h2 = R.ev('buildSavedHtml()'), R2 = boot({ html: h2 }), r = now(R2), cc = R.w.__cc;
       return [a.stored, a.sel, a.t, a.label, P.total, P.allOn, P.lit, P.notice, P.unavail, B.err, B.scope, B.tot, B.notes,
-        fileFys(h2) === (text === undefined ? '(no key)' : J(JSON.parse(text))), r.stored === a.stored, r.sel, r.t[0], R.w.__cc, R.errors.length + R2.errors.length]; };
+        fileFys(h2) === (text === undefined ? '(no key)' : J(JSON.parse(text))), r.stored === a.stored, r.sel, r.t[0], cc, R.errors.length + R2.errors.length,
+        w7Ok(w7Pkg(R.w, 'exportFlow'))]; };
     // the same, expected -- every value a literal
     const want = (stored, sel, t, label, total, allOn, lit, notice, unavail, notes) =>
-      [stored, sel, t, label, total, allOn, lit, notice, unavail, 'ok', 'Scope: ' + label, [t[0], t[0]], notes, true, true, sel, t[0], 0, 0];
+      [stored, sel, t, label, total, allOn, lit, notice, unavail, 'ok', 'Scope: ' + label, [t[0], t[0]], notes, true, true, sel, t[0], 0, 0,
+        'ok · every part reads · every count holds'];
     const ALL = 'FY25, FY27–FY31 · all years · all appropriations · FY27, FY28, FY29, FY30, FY31 planned, the rest executed';
     const L0 = 'no year counted · all appropriations · saved year selection not a list of years, not counted';
     const L1 = 'no year counted · all appropriations · 1 saved entry not a year, not counted';
@@ -5206,8 +5226,15 @@
     const TAIL = ' Click ALL YEARS, a year’s only, or a year to switch it on or off, to choose again; any of these replaces what cannot be read.';
     const WH = q => 'The saved year selection is ' + q + ', not a list of years this board can read. It is kept as saved, and nothing is counted.';
     const H1 = q => 'The saved year selection holds ' + q + ', which this board cannot read as a year. It is kept as saved, and nothing is counted.';
-    const whole = (q, text) => [text, J(want(text, [], T0, L0, '0.00', false, [], WH(q) + TAIL, '', ['NOTE: ' + WH(q)]))];
+    // `stored`: the value as the board writes it back, when the file's text spells it otherwise ("\uffff" for the character)
+    const whole = (q, text, stored = text) => [text, J(want(stored, [], T0, L0, '0.00', false, [], WH(q) + TAIL, '', ['NOTE: ' + WH(q)]))];
     const one = (q, text) => [text, J(want(text, [], T0, L1, '0.00', false, [], H1(q) + TAIL, '', ['NOTE: ' + H1(q)]))];
+    // one entry it cannot read beside 2027: FY27 counted, $500M, the entry said
+    const L27 = 'FY27 · all appropriations · PLANNED (board allocation, O&M) · 1 saved entry not a year, not counted';
+    const H27 = (q, fy) => 'The saved year selection holds ' + q + ', which this board cannot read as a year. It is kept as saved and not counted: this total counts ' + fy + ' only.';
+    const by27 = (q, text, stored = text) => [text, J(want(stored, [2027], T500, L27, '500.00', false, ['FY27 · plan'], H27(q, 'FY27') + TAIL, '', ['NOTE: ' + H27(q, 'FY2027')]))];
+    const E = '\u{1F600}';
+    const U40 = 'The saved year selection includes FY40, which this board cannot answer for now: it holds no plan for that year, no imported row is filed or counted in it, and it is outside the plan window (FY27–FY31). It stays in the saved selection, and nothing is counted. Click ALL YEARS, or a year’s only, to choose again; switching a year on or off keeps it.';
     const SHAPES = [
       // [where, what is promised, the text in the file, expected]
       ['a string', 'the saved selection "2026", not a list: no year counted (never ALL YEARS $540M), ALL YEARS not lit, said on the panel and in the export, kept through the save and the reopen', ...whole('"2026"', '"2026"')],
@@ -5227,9 +5254,31 @@
           'The saved year selection holds "<b>x</b>", which this board cannot read as a year. It is kept as saved and not counted: this total counts FY27 only.' + TAIL, '',
           ['NOTE: The saved year selection holds "<b>x</b>", which this board cannot read as a year. It is kept as saved and not counted: this total counts FY2027 only.']))],
       ['an enormous list', '5,000 entries of "x": no year counted, never ALL YEARS; three quoted and the rest counted, said in the plural, kept',
-        '[' + Array(5000).fill('"x"').join(',') + ']', J(want('[' + Array(5000).fill('"x"').join(',') + ']', [], T0, 'no year counted · all appropriations · 5000 saved entries not a year, not counted', '0.00', false, [],
+        '[' + Array(5000).fill('"x"').join(',') + ']', J(want('[' + Array(5000).fill('"x"').join(',') + ']', [], T0, 'no year counted · all appropriations · 5000 saved entries not years, not counted', '0.00', false, [],
           'The saved year selection holds "x", "x", "x" and 4997 more, which this board cannot read as years. They are kept as saved, and nothing is counted.' + TAIL, '',
           ['NOTE: The saved year selection holds "x", "x", "x" and 4997 more, which this board cannot read as years. They are kept as saved, and nothing is counted.']))],
+      // the verifiers' round: falsy values are not lists either
+      ['an empty string', '"": not a list -- no year counted (never ALL YEARS $540M), ALL YEARS not lit, said, kept', ...whole('""', '""')],
+      ['zero', '0: not a list -- no year counted (never ALL YEARS), said, kept', ...whole('0', '0')],
+      ['false', 'false: not a list -- no year counted (never ALL YEARS), said, kept', ...whole('false', 'false')],
+      // the quote: cut at 40 characters, between characters, and never carrying what XML 1.0 forbids (the package, last value)
+      ['a long entry', '[120 × "A"]: not counted; quoted as its first 40 characters and "…" on the panel and in the NOTE; kept whole',
+        '["' + 'A'.repeat(120) + '"]', J(want('["' + 'A'.repeat(120) + '"]', [], T0, L1, '0.00', false, [], H1('"' + 'A'.repeat(39) + '…') + TAIL, '', ['NOTE: ' + H1('"' + 'A'.repeat(39) + '…')]))],
+      ['U+FFFF in an entry', '["\\uffff", 2027], as a damaged file holds it: FY27 counted, the entry quoted as the file\'s own escape "\\uffff" -- never the character XML 1.0 forbids, so the workbook is well-formed; kept',
+        ...by27('"\\uffff"', '["\\uffff",2027]', '["\uffff",2027]')],
+      ['U+FFFE as the whole value', '"\\ufffe": not a list; quoted as "\\ufffe", and the workbook is well-formed; kept', ...whole('"\\ufffe"', '"\\ufffe"', '"\ufffe"')],
+      ['45 emoji in an entry', 'an entry of 45 emoji beside 2027: quoted as its first 40 characters -- the opening quote and 39 emoji -- and "…", never cut inside one (no half on the panel, no U+FFFD in the export); kept',
+        ...by27('"' + E.repeat(39) + '…', J([E.repeat(45), 2027]))],
+      // both findings at once, and every offered year beside an entry it cannot read
+      ['beside a year U14 says', '[2040, "x"]: both said -- the label carries both, both notices are on the panel, the U34 NOTE is in the export; kept', '[2040,"x"]',
+        J(want('[2040,"x"]', [], T0, 'no year counted · all appropriations · saved FY40 not available, not counted · 1 saved entry not a year, not counted', '0.00', false, [],
+          H1('"x"') + TAIL, U40, ['NOTE: ' + H1('"x"')]))],
+      ['every offered year beside an entry it cannot read', '[2025, 2027-2031, "x"]: every offered year counted, $540M, but it is not ALL YEARS -- ALL YEARS not lit, the six years lit, the label never "all years"; said, kept',
+        '[2025,2027,2028,2029,2030,2031,"x"]', J(want('[2025,2027,2028,2029,2030,2031,"x"]', O, T540,
+          'FY25, FY27, FY28, FY29, FY30, FY31 · all appropriations · FY27, FY28, FY29, FY30, FY31 planned, the rest executed · 1 saved entry not a year, not counted', '540.00', false,
+          ['FY25', 'FY27 · plan', 'FY28 · plan', 'FY29 · plan', 'FY30 · plan', 'FY31 · plan'],
+          'The saved year selection holds "x", which this board cannot read as a year. It is kept as saved and not counted: this total counts FY25, FY27, FY28, FY29, FY30, FY31 only.' + TAIL, '',
+          ['NOTE: The saved year selection holds "x", which this board cannot read as a year. It is kept as saved and not counted: this total counts FY2025, FY2027, FY2028, FY2029, FY2030, FY2031 only.']))],
       ['CONTROL — no key', 'no saved selection is ALL YEARS: $540M, ALL YEARS lit, nothing said', undefined, J(want('undefined', O, T540, ALL, '540.00', true, [], '', '', []))],
       ['CONTROL — null', 'null, the board\'s own ALL YEARS: $540M, ALL YEARS lit, nothing said', 'null', J(want('null', O, T540, ALL, '540.00', true, [], '', '', []))],
       ['CONTROL — duplicates', '[2027, 2027]: FY27 once, $500M, nothing said, kept as saved', '[2027,2027]',
@@ -5241,9 +5290,31 @@
       ['CONTROL — a whole year no appropriation offers', '[2040]: U14\'s notice, nothing counted, nothing else said', '[2040]',
         J(want('[2040]', [], T0, 'no year counted · all appropriations · saved FY40 not available, not counted', '0.00', false, [], '',
           'The saved year selection includes FY40, which this board cannot answer for now: it holds no plan for that year, no imported row is filed or counted in it, and it is outside the plan window (FY27–FY31). It stays in the saved selection, and nothing is counted. Click ALL YEARS, or a year’s only, to choose again; switching a year on or off keeps it.', []))],
+      ['CONTROL — a year the board offers outside 2000–2099', '[1999] on a board holding $7M of FY1999 rows: a whole number is a year, as the board writes it -- FY99 counted, nothing said, kept (no range is read into "a year")',
+        '[1999]', J(want('[1999]', [1999], [7 * M, 7 * M, 0], 'FY99 · all appropriations', '7.00', false, ['FY99'], '', '', [])),
+        P => { P.execDb.all.om.rows[1999] = [row(1999, 'Old Support', 'USAF O&M Discretionary', 7 * M, 'Program (TSS)')]; }],
     ];
-    for (const [where, what, text, exp] of SHAPES) {
-      w5Chk(name, where, what, J(await look(text)), exp);
+    for (const [where, what, text, exp, more] of SHAPES) {
+      w5Chk(name, where, what, J(await look(text, more)), exp);
+      bootRelease(__bm, [X.w]);
+    }
+    // both NOTEs in the export, in order: U14's first under the Scope line, then U34's, each with its blank row
+    {
+      const R = boot({ html: withFys('[2040,"x"]') }); counted(R.w, true); const ff = await flowRows(R);
+      w5Chk(name, 'beside a year U14 says · the NOTEs in order', 'the export\'s NOTE rows: U14\'s at row 4 (index 3), U34\'s at index 5, each followed by a blank row',
+        J(ff.map((r, i) => [i, String(r[0] ?? '')]).filter(x => /^NOTE: /.test(x[1]))),
+        J([[3, 'NOTE: The saved year selection includes FY2040, which this board cannot answer for now: it holds no plan for that year, no imported row is filed or counted in it, and it is outside the plan window (FY2027–FY2031). It stays in the saved selection, and nothing is counted.'],
+          [5, 'NOTE: The saved year selection holds "x", which this board cannot read as a year. It is kept as saved, and nothing is counted.']]));
+      bootRelease(__bm, [X.w]);
+    }
+    // the NOTE is ADDED: [2027, "x"] exports every row [2027] exports, in order, but its Scope line, and a NOTE with its blank row
+    {
+      const Ra = boot({ html: withFys('[2027]') }); counted(Ra.w, true); const a = (await flowRows(Ra)).map(r => J(r));
+      const Rb = boot({ html: withFys('[2027,"x"]') }); counted(Rb.w, true); const b = (await flowRows(Rb)).map(r => J(r));
+      const nx = b.findIndex(r => r.indexOf('NOTE: The saved year selection holds') >= 0);
+      const rest = b.filter((r, i) => i !== 1 && i !== nx && i !== nx + 1), same = a.filter((r, i) => i !== 1);
+      w5Chk(name, 'the export beside the NOTE', '[2027, "x"] exports every row [2027] exports, in the same order, but its Scope line; the NOTE and a blank row are added at index 3, under the Source line',
+        J([a.length > 20, b.length - a.length, nx, b[nx + 1], J(rest) === J(same)]), J([true, 2, 3, '[]', true]));
       bootRelease(__bm, [X.w]);
     }
     // the markup is text on the panel: escaped in the notice's HTML, no element made from it
```

## Appendix C — fix round 2's exact diffs (c3 against c2)

`diffs/c3-board-vs-c2.diff` is empty (blob e69de29bb2d1d6434b8b29ae775ad8c2e48c5391): the board did not change. The other two follow, exactly as in `diffs/`.

### C.1 `diffs/c3-mutate-vs-c2.diff` (blob e968bc59dbfd1c3f8b91b4a387dcdd453bea0ef4)

```diff
--- c2/tools/export-audit/mutate.mjs.txt	2026-10-13 08:51:13.892957339 +0000
+++ c3/tools/export-audit/mutate.mjs.txt	2026-10-13 16:02:26.825376564 +0000
@@ -4370,6 +4370,26 @@
   { id: "v200-yearsel-plural-label", area: "flowCalc", what: "the scope label's plural is \"5000 saved entries not a year\" again",
     find: "(UR.n===1?'entry not a year':'entries not years')",
     repl: "(UR.n===1?'entry not a year':'entries not a year')" },
+  // v2.00 (U34, the verifiers' second round, 13 Oct): every forbidden character of a quote is escaped; the cut's edge (40 whole,
+  // 41 cut); partner and FMS money counted for the years read only; -2027 is a year as the board reads it.
+  { id: "v200-yearsel-quote-escape-first-only", area: "flowUnreadSaved", what: "only the first U+FFFE / U+FFFF of a quote is escaped: a saved [\"\\uffff\\ufffe\", 2027] puts the second raw into the export's sheet, which is then not a well-formed workbook",
+    find: ".replace(/[\\uFFFE\\uFFFF]/g, c=>",
+    repl: ".replace(/[\\uFFFE\\uFFFF]/, c=>" },
+  { id: "v200-yearsel-quote-cut-at-40-or-more", area: "flowUnreadSaved", what: "a quote of exactly 40 characters is given a \"…\" though nothing follows",
+    find: "    return t.length>40? t.slice(0,40)",
+    repl: "    return t.length>=40? t.slice(0,40)" },
+  { id: "v200-yearsel-quote-cut-above-41", area: "flowUnreadSaved", what: "a quote of 41 characters is shown whole, not cut at 40",
+    find: "    return t.length>40? t.slice(0,40)",
+    repl: "    return t.length>41? t.slice(0,40)" },
+  { id: "v200-yearsel-year-four-digits", area: "flowYearOk", what: "a year must have four digits: a saved [-2027] is said as an entry the board cannot read, not as U14's year it cannot answer for",
+    find: "function flowYearOk(y){ return typeof y==='number' && Number.isInteger(y); }",
+    repl: "function flowYearOk(y){ return typeof y==='number' && Number.isInteger(y) && y>=1000 && y<=9999; }" },
+  { id: "v200-yearsel-year-positive", area: "flowYearOk", what: "a year must be above zero: a saved [-2027] is said as an entry the board cannot read, not as U14's year it cannot answer for",
+    find: "function flowYearOk(y){ return typeof y==='number' && Number.isInteger(y); }",
+    repl: "function flowYearOk(y){ return typeof y==='number' && Number.isInteger(y) && y>0; }" },
+  { id: "v200-yearsel-other-sources-all-years", area: "flowCalc", what: "partner and FMS money is counted for every year when the saved selection cannot be read: \"2026\" says no year counted and exports $5M of total funding",
+    find: "  YS.forEach(y=>{ const O=C.other[y]||{}; F.ip+=+O.ip||0; F.fms+=+O.fms||0; });",
+    repl: "  (UR? flowYears() : YS).forEach(y=>{ const O=C.other[y]||{}; F.ip+=+O.ip||0; F.fms+=+O.fms||0; });" },
   // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.
   { id: "v200-r3-landed-view-unsaid", area: "_driveStorePushRun", what: "a folder save that lands while a locked view is on screen says “🔒 Not kept — PB27 is a locked view. ✅ Saved …” again, naming no plan (or, quiet, leaves persist's refusal on screen)",
     find: "  if(CYCVIEW){ _cycRefusedAt=0; setStat('✅ <b>Saved the working plan</b> of '+esc(APPN_LBL[ap]||ap)+' FY'+(fy%100)+' to the shared folder — '\n    +Math.round(body.length/1024)+' KB, built before '+blLbl(CYCVIEW)+' was put on screen. '+blLbl(CYCVIEW)+' is a locked view: nothing in it '\n    +'is saved. Everyone sees the working plan on their next refresh.'+penNote+lateNote); render(); return true; }\n",
```

### C.2 `diffs/c3-audit-recon-vs-c2.diff` (blob 8dfed1ff96b8b797bc729cb7c0ddab999d90e578)

```diff
--- c2/tools/export-audit/audit-recon.mjs	2026-10-13 09:01:01.792727588 +0000
+++ c3/tools/export-audit/audit-recon.mjs	2026-10-13 16:02:26.816888681 +0000
@@ -5144,14 +5144,19 @@
 // well-formed workbook, every part read as XML (w7Pkg). Every offered year beside an entry it cannot read is not ALL YEARS: the
 // chip is not lit, the label does not say "all years" (U14's rule). A year U14 says beside an entry U34 says: both said, U14's
 // NOTE first. The NOTE is ADDED to the export: every other row is as without the entry. CONTROL: a whole year the board offers
-// outside 2000-2099 (FY1999 rows) is a year -- no range is read into "a year".
+// outside 2000-2099 (FY1999 rows) is a year -- a year need not be in 2000-2099.
+// AND (the verifiers' second round, 13 Oct): two characters XML forbids in one entry are both quoted as their escape; a quote of
+// exactly 40 characters is shown whole and one of 41 is cut at 40. Partner and FMS money typed in is counted for the years read
+// only: none beside "2026", FY27's beside [2027, "x"]. CONTROL: -2027 is a whole number, so a year as the board reads it (U14's
+// notice, "FY-27") -- a year need not have four digits, nor be above zero.
 // FAILS ON d66dd60 (U14; records head 7ee498a): every shape the board did not write -- "2026", {}, 2027, [], "", 0 and false read
-// as ALL YEARS $540M, ALL YEARS lit, nothing said; ["2027"] as FY27 $500M; [2026.5], 5,000 × "x", 120 × "A" and "\ufffe" as ALL
-// YEARS; [null] and [true] as "saved FY0 / FY1 not available"; [2025, 2026.5], ["<b>x</b>", 2027], ["\uffff", 2027] and 45 emoji
-// beside 2027 counted their one whole year with nothing said; [2040, "x"] said FY40 only; [2025, 2027-2031, "x"] read as ALL
-// YEARS; so the export carried no U34 NOTE (both whole-export checks); and FY27 switched on beside "2026" switched it OFF from
-// every year ($40M). Passing there too: the seven controls, and FY27 switched on beside [2025, 2026.5], ALL YEARS and a year's
-// only on "2026".
+// as ALL YEARS $540M, ALL YEARS lit, nothing said; ["2027"] as FY27 $500M; [2026.5], 5,000 × "x", 120 × "A", 38 × "B", 39 × "C"
+// and "\ufffe" as ALL YEARS; [null] and [true] as "saved FY0 / FY1 not available"; [2025, 2026.5], ["<b>x</b>", 2027],
+// ["\uffff", 2027], ["\uffff\ufffe", 2027] and 45 emoji beside 2027 counted their one whole year with nothing said; [2040, "x"]
+// said FY40 only; [2025, 2027-2031, "x"] read as ALL YEARS; so the export carried no U34 NOTE (both whole-export checks); FY27
+// switched on beside "2026" switched it OFF from every year ($40M); and "2026" counted FY25's $3M partner and FY27's $2M FMS
+// money ($545M). Passing there too: the eight controls, and FY27 switched on beside [2025, 2026.5], ALL YEARS and a year's only
+// on "2026".
 await (async () => {
   const name = 'v2.00 (U34) — a saved year selection this board did not write is never read as ALL YEARS; it is kept and said';
   const { bootMark, bootRelease, settleBoards } = await import('./boot.mjs');
@@ -5269,6 +5274,11 @@
       ['U+FFFE as the whole value', '"\\ufffe": not a list; quoted as "\\ufffe", and the workbook is well-formed; kept', ...whole('"\\ufffe"', '"\\ufffe"', '"\ufffe"')],
       ['45 emoji in an entry', 'an entry of 45 emoji beside 2027: quoted as its first 40 characters -- the opening quote and 39 emoji -- and "…", never cut inside one (no half on the panel, no U+FFFD in the export); kept',
         ...by27('"' + E.repeat(39) + '…', J([E.repeat(45), 2027]))],
+      // the verifiers' second round: every forbidden character escaped, and the cut's edge (40 whole, 41 cut)
+      ['two characters XML forbids in one entry', '["\\uffff\\ufffe", 2027]: FY27 counted; both quoted as their escape -- every one, not the first only -- so the workbook is well-formed; kept',
+        ...by27('"\\uffff\\ufffe"', '["\\uffff\\ufffe",2027]', '["\uffff\ufffe",2027]')],
+      ['a quote of exactly 40 characters', '[38 × "B"]: its quote is 40 characters -- shown whole, with no "…"; kept', ...one('"' + 'B'.repeat(38) + '"', '["' + 'B'.repeat(38) + '"]')],
+      ['a quote of 41 characters', '[39 × "C"]: its quote is 41 characters -- cut at 40, then "…"; kept', ...one('"' + 'C'.repeat(39) + '…', '["' + 'C'.repeat(39) + '"]')],
       // both findings at once, and every offered year beside an entry it cannot read
       ['beside a year U14 says', '[2040, "x"]: both said -- the label carries both, both notices are on the panel, the U34 NOTE is in the export; kept', '[2040,"x"]',
         J(want('[2040,"x"]', [], T0, 'no year counted · all appropriations · saved FY40 not available, not counted · 1 saved entry not a year, not counted', '0.00', false, [],
@@ -5290,9 +5300,12 @@
       ['CONTROL — a whole year no appropriation offers', '[2040]: U14\'s notice, nothing counted, nothing else said', '[2040]',
         J(want('[2040]', [], T0, 'no year counted · all appropriations · saved FY40 not available, not counted', '0.00', false, [], '',
           'The saved year selection includes FY40, which this board cannot answer for now: it holds no plan for that year, no imported row is filed or counted in it, and it is outside the plan window (FY27–FY31). It stays in the saved selection, and nothing is counted. Click ALL YEARS, or a year’s only, to choose again; switching a year on or off keeps it.', []))],
-      ['CONTROL — a year the board offers outside 2000–2099', '[1999] on a board holding $7M of FY1999 rows: a whole number is a year, as the board writes it -- FY99 counted, nothing said, kept (no range is read into "a year")',
+      ['CONTROL — a year the board offers outside 2000–2099', '[1999] on a board holding $7M of FY1999 rows: a whole number is a year, as the board writes it -- FY99 counted, nothing said, kept (a year need not be in 2000–2099)',
         '[1999]', J(want('[1999]', [1999], [7 * M, 7 * M, 0], 'FY99 · all appropriations', '7.00', false, ['FY99'], '', '', [])),
         P => { P.execDb.all.om.rows[1999] = [row(1999, 'Old Support', 'USAF O&M Discretionary', 7 * M, 'Program (TSS)')]; }],
+      ['CONTROL — a whole number no year could be', '[-2027]: a whole number is a year, as the board reads it -- U14\'s notice ("FY-27"), nothing counted, no U34 notice (a year need not have four digits, nor be above zero)',
+        '[-2027]', J(want('[-2027]', [], T0, 'no year counted · all appropriations · saved FY-27 not available, not counted', '0.00', false, [], '',
+          'The saved year selection includes FY-27, which this board cannot answer for now: it holds no plan for that year, no imported row is filed or counted in it, and it is outside the plan window (FY27–FY31). It stays in the saved selection, and nothing is counted. Click ALL YEARS, or a year’s only, to choose again; switching a year on or off keeps it.', []))],
     ];
     for (const [where, what, text, exp, more] of SHAPES) {
       w5Chk(name, where, what, J(await look(text, more)), exp);
@@ -5349,6 +5362,22 @@
         J([okA, a.stored, a.t, okO, b.stored, b.t, R.errors.length]), J([true, 'null', T540, true, '[2027]', T500, 0]));
       bootRelease(__bm, [X.w]);
     }
+    // partner and FMS money is typed per fiscal year and counted for the years in scope (flowOtherNote), so none of it is
+    // counted for what cannot be read: FY25 International Partners $3M and FY27 Foreign Military Sales $2M typed in, "2026"
+    // counts none of it ($0 total funding, as "no year counted" says), and [2027, "x"] counts FY27's $2M only ($502M)
+    {
+      const other = P => { P.appns[slug].flow.other = { 2025: { ip: 3 * M }, 2027: { fms: 2 * M } }; };
+      const got = [];
+      for (const text of ['"2026"', '[2027,"x"]']) {
+        const R = boot({ html: withFys(text, other) }); counted(R.w, true);
+        const c = JSON.parse(R.ev(`(function(){ var F=flowCalc(); return JSON.stringify([F.ip, F.fms, F.grand]); })()`));
+        const ff = await flowRows(R), line = lab => ff.filter(r => String(r[0] ?? '').trim() === lab).map(r => num(r[1])).filter(v => v !== null);
+        got.push([c, line('International Partners'), line('Foreign Military Sales'), line('TOTAL FUNDING')]);
+        bootRelease(__bm, [X.w]);
+      }
+      w5Chk(name, 'partner and FMS money', '"2026": no partner or FMS money counted, $0 total funding in the calculation and the export; [2027, "x"]: FY27\'s $2M FMS only, $502M total funding',
+        J(got), J([[[0, 0, 0], [0, 0], [0, 0], [0, 0]], [[0, 2000000, 502000000], [0, 0], [2000000, 2000000], [502000000, 502000000]]]));
+    }
     w5Chk(name, 'nothing asked', 'the base board asked nothing while its file was built', J([X.w.__cc, X.errors.length]), J([0, 0]));
   } catch (e) {
     failures.push({ scenario: name, where: 'harness', what: 'the block threw: ' + String((e && e.message) || e).slice(0, 160), got: 'threw', want: 'ran' });
```
