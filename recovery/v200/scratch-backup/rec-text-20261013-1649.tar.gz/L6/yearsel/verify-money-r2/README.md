# YEARSEL (U34) — independent adversarial verifier, round 2, LENS A (data loss and money)

Started 9:34 AM ET, 13 Oct 2026 (the container restarted at 9:11 AM ET; this folder did not exist, so no earlier attempt
of this review was found and nothing was carried over). Everything was done on my own copies in this folder. Nothing in
`/home/user/orbit-board` or `/home/user/orbit-ui` was edited, staged, committed or pushed; both were only read (git log /
git show / grep). The builder's files were not touched. `mutate.mjs` was never imported or run: it was read as text only
(`rec/bin/mcount.py`, `rec/bin/mkmut.py`, `python3 -I`). No Chromium, no playwright, no full audit-import or audit-board.

## Verdict: sound-with-issues

The c2 board change (`593593a4`, = base `fce8a391` + U34 commit 1 + fix round) is sound on every Lens A path I could reach:
no shape I tried makes it lose the saved value, write over it unasked, misstate money, export a wrong figure, crash, or
silently switch a selection it can parse to ALL YEARS. Its suite and catalog changes are pure additions.

The issues are in what the drafts say and in one money path the tests do not reach:

* **MF1 (drafts, text only).** A whole saved value of `1e999` or `-1e999` is read as ALL YEARS, $540M, ALL YEARS lit, with
  nothing said — on c2 as on the base — because opening copies the saved state through JSON
  (`MS = normalizeStore(JSON.parse(JSON.stringify(raw||{})))`, c2 board line 5999), so the reader only ever sees `null`.
  The draft says "Now only no saved selection (null, or no key) is ALL YEARS" and lists 1e999 only as an *entry*, "read as
  Infinity" (it is read as null). The release note is false for this shape, and Brad asked for the limits to be named.
* **MF2 (drafts + ledger, text only).** The task names NaN. A saved selection written as `NaN` (what a JSON writer outside
  the browser can produce — Python's `json` does by default) makes the file's whole saved state unreadable. The board says
  "Could not read 1 item on opening … do not save over this file", and then, in the same opening, replaces that line with
  "SHELL TEMPLATE — no data inside (safe for any machine)" or "No saved state in this copy". A Save from there writes a
  board without the file's state. Base and c2 alike. Not U34's code, but it is the NaN limit and it is a data-loss path,
  and it is not named anywhere in the drafts.
* **SF1 (test gap, money).** International Partner and FMS money is counted per year in scope. The U34 fixture holds none,
  so a mutant that counts it for every year when the selection cannot be read survives all 97 focused checks while it
  exports **$5M of TOTAL FUNDING under "no year counted"** (OM-om6). A one-check addition (built as c3, below) fails on the
  base, passes on c2 and catches it.
* **SF2 (drafts + ledger).** A saved year a century off an offered year (`[2025, 2125]`) is printed as that year by U14's
  label and notice: "FY25 · … · saved FY25 not available, not counted" on the panel and the export's Scope line, while FY25's
  $40M is counted. Base and c2 alike (U14's wording).

Exact replacement texts for the drafts and the two new ledger rows are in `drafts/U34-draft-corrections.md`.

## The lead's six principles, checked against c2

1. **Never lose a copy.** Held for the change. Every parseable malformed shape I opened (13 here; the block's 20) was kept
   as the same value through reading, the panel, the export, the board's Save straight after opening, an unrelated saving
   operation (`flowSetLayout('tree')`), the reopened file and this browser's storage (P1). A click replaces it only after
   the notice says so. Exceptions, both from before the change: a number too large for the browser is null before the
   board reads it (MF1), and NaN makes the whole saved state unreadable (MF2).
2. **Refuse or ask rather than guess.** Held: "2027", true, null, objects, falsy values and empty lists are no longer read
   as years or as ALL YEARS. Exception (JSON's, not the board's): `[2026.9999999999999]` is the number 2027 by the time the
   board sees it, and is counted as FY27 with nothing said (P1 NEAR-INT, base and c2 alike).
3. **Money and every export match the computation.** Held. In all 13 shapes and both reopenings, `flowCalc`, the panel's
   total and the exported TOTAL FUNDING lines agree (P1); every exported workbook (26 on c2) is well-formed XML by expat;
   audit-recon's 306 shared checks keep their verdicts and values; partner and FMS money is right on c2 (SUP2-on-c2) — but
   untested by the block (SF1).
4. **Every word stays true.** Held for c2's own new words in every shape probed, including after save and reopen. Not
   held by the drafts for 1e999 (MF1) and not by U14's two-digit years (SF2, pre-existing).
5. **Smallest change.** Board +46 −9 against the base; nothing in it I would remove.
6. **Existing checks preserved.** Held: `audit-recon.mjs` and `mutate.mjs.txt` diffs against the base are additions only
   (0 lines removed); audit-recon base 306 / c2 340, 306 shared, 0 differing, 34 new all passing; the base catalog's 1,328
   entries each match the c2 board once; U14's 63 focused checks pass on c2.

## What I ran (all times ET, 13 Oct 2026; every node run through `run.sh`: lock checked first, `setsid -w timeout -k 10 600`)

The lock file `AUDIT_IMPORT_RUNNING` was absent at every check; no run waited or was skipped.

| label | start | exit | wall s | log | result |
|---|---|---|---|---|---|
| P1-probe-on-base | 9:40:20 AM | 0 | 46.1 | logs/P1-probe-on-base.log | 13 shapes; 1e999/-1e999 ALL YEARS; "2026" ALL YEARS $540M; [2125] "FY25" |
| P1-probe-on-c2 | 9:40:20 AM | 0 | 47.6 | logs/P1-probe-on-c2.log | 1e999/-1e999 ALL YEARS (null at open); every other shape said, kept, money agreeing |
| xmlcheck P1 (python3 -I, bounded, not via bx.sh) | 9:42:05 AM | 0 | <2 | out/xmlcheck-P1-c2.txt, -base.txt | all 26 c2 workbooks and all 26 base workbooks WELL-FORMED |
| mcount ×3 (text only, via bx.sh) | 9:43:35 AM | 0 | <2 | out/mcount-*.txt | c2 catalog on c2 1,355/1,355 once; base catalog on c2 1,328/1,328; c2 catalog on base 1,329 once, 26 missing (new) |
| F1-focused-on-c2 | 9:44:05 AM | 0 | 125.1 | logs/F1-focused-on-c2.log | ALL CHECKS PASSED, 97 (U14 63, U34 34) |
| F1-focused-on-base | 9:44:05 AM | 1 | 128.2 | logs/F1-focused-on-base.log | 24 failing, all U34; U14 63/63; U34 10 pass by design |
| P2-nan-on-c2 / -base | 9:50:03 AM | 0 / 0 | 10.6 / 11.6 | logs/P2-nan-on-*.log | identical: warning set then replaced; Save would write no file state |
| S1-audit-recon-base | 9:50:53 AM | 0 | 217.1 | logs/S1-audit-recon-base.log | ALL CHECKS PASSED, 306 |
| S1-audit-recon-c2 | 9:50:53 AM | 0 | 268.4 | logs/S1-audit-recon-c2.log | ALL CHECKS PASSED, 340; 306 shared, 0 differing |
| N1-check-base (`node tools/check.mjs`, the npm check script, in gitclone/ at 7ee498a) | 9:55:43 AM | 0 | 6.3 | logs/N1-check-base.log | all checks passed |
| N2-check-c2 (same clone, c2 board and audit-recon copied in, never committed) | 9:55:50 AM | 0 | 5.7 | logs/N2-check-c2.log | all checks passed; only line counts differ (29,650 → 29,687) |
| OM-om1-dup-counted | 9:56:35 AM | 1 | 143.3 | logs/OM-om1-dup-counted.log | caught, 2 failing (duplicates controls) |
| OM-om2-export-all-years | 9:56:35 AM | 1 | 111.2 | logs/OM-om2-export-all-years.log | caught, 22 failing |
| OM-om3-save-cleans | 9:58:59 AM | 1 | 105.2 | logs/OM-om3-save-cleans.log | caught, 22 failing |
| OM-om4-load-normalises | 9:58:59 AM | 1 | 109.9 | logs/OM-om4-load-normalises.log | caught, 8 failing |
| OM-om5-note-two-digit | 10:00:49 AM | 1 | 122.2 | logs/OM-om5-note-two-digit.log | caught, 5 failing |
| OM-om6-other-sources-all-years | 10:00:49 AM | 0 | 124.8 | logs/OM-om6-other-sources-all-years.log | **SURVIVES**, 97/97 (SF1) |
| SUP-on-c2 / -base / -om6 (first draft of the new check) | 10:03:39 / 10:03:39 / 10:05:29 AM | 1 / 1 / 1 | 106.0 / 110.1 / 92.7 | logs/SUP-on-*.first-draft.log (renamed after the run) | superseded: my check read the section header "TOTAL FUNDING" (no value) as null; fixed with the block's own null filter |
| SUP2-on-c2 | 10:07:15 AM | 0 | 114.3 | logs/SUP2-on-c2.log | 98/98, the new check passes |
| SUP2-on-base | 10:07:15 AM | 1 | 115.3 | logs/SUP2-on-base.log | 25 failing, the new check among them ("2026": $3M IP, $2M FMS, $545M) |
| SUP2-on-om6 | 10:09:10 AM | 1 | 108.2 | logs/SUP2-on-om6.log | 1 failing: the new check ($5M total funding under "no year counted") |
| BM-* (builder mutants rebuilt by mkmut.py; blobs equal the builder's fr/mut2) | from 10:11:35 AM | see § Builder mutants | | logs/BM-*.log, logs/bmq.log | |
| S2-audit-recon-c3 (c2 board + the proposed check; copies/c3) | 10:18:35 AM | 0 | 216.8 | logs/S2-audit-recon-c3.log | ALL CHECKS PASSED, 341; 340 shared with c2, 0 differing; the new one passes |
| S2-audit-recon-c3suite-on-base (base board + c3's audit-recon; copies/base-c3suite) | 10:18:35 AM | 1 | 221.8 | logs/S2-audit-recon-c3suite-on-base.log | 25 failing, all U34, the new check among them; the 306 shared with S1-base: 0 differing |

`logs/runs.txt` has one line per node run as `run.sh` wrote it (the SUP first-draft logs were renamed afterwards).

## Findings in detail

### MF1 — 1e999 as the whole saved value is ALL YEARS, nothing said; the drafts say otherwise
Reproduction (P1, U14's no-plan fixture: O&M FY25 $40M executed, FY27–FY31 $500M planned): the saved file's
`appns.om.flow.fys` replaced as text by `1e999` (or `-1e999`), opened with `boot({html})`.
- c2 and base alike: `flowCfg().fys` is `null` at open; label "FY25, FY27–FY31 · all years · …"; panel $540.00M, ALL YEARS
  lit, no notice; export TOTAL FUNDING 540,000,000 twice, no U34 NOTE; the board's Save straight after opening writes
  `"fys":null`.
- `[1e999]` on c2: stored `[null]` at open, "holds null, which this board cannot read as a year", $0, kept as `[null]`.
- Cause: c2 board line 5999, `MS = normalizeStore(JSON.parse(JSON.stringify(raw||{})))` — Infinity becomes null before
  any reader. No small board change can tell this null from the board's own; the fix is the text (corrections A, B, E, F).

### MF2 — NaN makes the file's whole saved state unreadable, and the warning is replaced in the same opening
Reproduction (P2): the same file with `flow.fys` replaced as text by `NaN`.
- Fresh browser: DIAG.log holds "⚠ Could not read # item on opening: the saved board state in this file. That data is NOT
  loaded — do not save over this file …"; the status line left showing is "🧩 SHELL TEMPLATE v2.00 … no data inside (safe for
  any machine)…" (board line 31617, the opening's status chain, which checks `_bootRestoreErr` but not `_bootLost`); the
  board is the shell; its Save would write a state with 0 requirements and no execution rows.
- The browser that holds the board (its storage given): the line left is "No saved state in this copy — make sure you
  opened the latest board file…"; it shows this browser's copy ($500M); its Save would write that copy with no FY25
  execution rows (they were in the file only).
- Base and c2 identical. Pre-existing; outside U34's change. The fix asked of this commit is the record (correction D, the
  U-new-nan row), not code.

### SF1 — partner and FMS money is not reached by the U34 block
Mutant om6 (c2 board line 15693, `YS.forEach(...)` → `(UR? flowYears() : YS).forEach(...)`): with the selection unreadable,
partner and FMS money of every year is counted. 97/97 pass (OM-om6). With FY25 IP $3M and FY27 FMS $2M typed in, it reports
**$5,000,000 of total funding under "no year counted"** for "2026" and $505M for [2027, "x"] (SUP2-on-om6).
Proposed: `copies/c3` = c2 + one check inside the U34 block before "nothing asked" (`diffs/c3-audit-recon-vs-c2.diff`,
literals: `[[[0,0,0],[0,0],[0,0],[0,0]], [[0,2000000,502000000],[0,0],[2000000,2000000],[502000000,502000000]]]`) + catalog
entry `v200-yearsel-other-sources-all-years` before the R3 line (`diffs/c3-mutate-vs-c2.diff`). Before-fail/after-pass:
SUP2-on-base fails it (got `[[[3000000,2000000,545000000],…`), SUP2-on-c2 passes, SUP2-on-om6 fails it. mcount on c3: 1,356 /
1,356 once; the mkmut-built mutant equals om6 (blob `d15fcd09`). If the lead takes it, the drafts' counts become 35 checks,
25 failing on d66dd60, 28 mutations (correction G).

### SF2 — U14's two-digit year names an offered year
Reproduction (P1 CENTURY-PAIR, base and c2 identical): `[2025,2125]` → label and export Scope line "FY25 · all appropriations ·
saved FY25 not available, not counted"; panel notice "includes FY25, which this board cannot answer for now: … no imported
row is filed or counted in it … this total counts FY25 only", while $40M of FY25 is counted; the export NOTE says FY2125.
`[2125]` alone: "saved FY25 not available", $0. The drafts' "printed by their last two digits" does not say the printed year
can be one the board counts. Correction C and row U-new-fy2.

### Minor
- `[2026.9999999999999]` is FY27, $500M, nothing said (JSON precision; base the same). In correction B.
- `[1e21]`: panel "FY0", export NOTE "FY1e+21" (already covered by the drafts' two-digit limit).
- Browser storage path: P1's "reopenedStorage" opened a board from this browser's storage alone; every malformed shape was
  read and said the same way there (e.g. "2026": "no year counted · saved year selection not a list of years, not
  counted"). The drafts say only the file path was tested; P1 adds this one. (The executed FY25 rows are not in storage,
  so totals there differ from the file's for shapes that count FY25 — the board's design, not U34.)
- Lone surrogates, control characters and U+FFFF in an object key are quoted as escapes; every such export is well-formed.

## Builder mutants (re-run, text-only rebuild)

The 18 entries I rebuilt with `mkmut.py` from the c2 catalog give blobs equal to the builder's `fr/mut2` mutants
(`out/builder-mutant-blobs.txt`). Eight money/data ones were re-run through my focused harness:
All 8 caught; U14's 63 checks pass in every one (the queue ran 10:11:35–10:18:18 AM ET, wrapper rc 0, `logs/bmq.log`):

| mutant | start | exit | wall s | failing checks |
|---|---|---|---|---|
| quote-xml-unsafe | 10:11:35 AM | 1 | 112.1 | 2: U+FFFF in an entry; U+FFFE as the whole value |
| falsy-all-years | 10:11:35 AM | 1 | 121.6 | 3: an empty string; zero; false |
| counted-unsaid | 10:13:37 AM | 1 | 106.4 | 5 |
| allyears-lit-unread | 10:13:37 AM | 1 | 109.0 | 1: every offered year beside an entry it cannot read |
| export-unsaid | 10:15:26 AM | 1 | 79.3 | 22 |
| note-replaces-line | 10:15:26 AM | 1 | 86.4 | 1: the export beside the NOTE |
| year-range | 10:16:52 AM | 1 | 81.5 | 1: CONTROL — a year the board offers outside 2000–2099 |
| toggle-from-all | 10:16:52 AM | 1 | 85.8 | 1: "2026", then FY27 switched on |

## PIDs

`pids.txt` (one line per PID, with its command): 82 distinct PIDs, none present at 10:22:30 AM ET. No process was killed or signalled by me. The queue wrapper for the
builder mutants (`bmq.sh`, bounded at 1,500 s; every run inside it bounded at 600 s by `run.sh`) was started in the
background at 10:11:35 AM ET and its PIDs recorded at 10:11:54 AM ET; I first recorded three wrong PIDs (my own `ps`
pipeline) and removed those lines.

## Deviations, said plainly
- The builder-mutant queue wrapper ran under a 1,500 s bound, not 600 s (each node run inside it had the 600 s bound).
- The two expat checks (`xmlcheck.py`) and the three `mymut.py`/`mkmut.py` builds ran under `setsid -w timeout` or directly
  as short `python3 -I` text tools without PID records; `mkfocused-fr.py`, `mcount.py`, `git clone` and `git checkout`
  ran through `bx.sh` (PIDs recorded).
- Short read-only commands (grep, sed, git log/show in orbit-board under `setsid -w timeout -k 10 120/300`, cat, diff) ran
  without PID records.

## What I did not do
- No full audit-import or audit-board (the lead's); no Chromium, playwright, verify:grid, screenshots.
- I did not re-run audit-hostile, audit-other, audit-inject, audit, audit-ppt, legacy-fsrc or boot-same (the builder and
  both round-1 verifiers did, on the same board blob); I ran audit-recon and the check script.
- I did not re-run all 27 builder mutants (the round-2 tests verifier covers them); 8 here, plus 6 of my own.
- The c3 suite (the proposed check) ran in full on the c2 board and on the base board (S2); nothing beyond audit-recon was run on c3.
- No commit, push or edit outside this folder.

## Blobs (git hash-object, 10:23 AM ET)

Copies: base board `fce8a391`, audit-recon `529e36f7`, mutate `cbc6defc`; c1 board `a67635bb`; c2 board `593593a4`, audit-recon `5eac80ea`, mutate `f4e0739f` (all equal the builder's claims). c3 = c2 board + the proposed check and entry; base-c3suite = base board + c3's audit-recon.

- `copies/c3/tools/export-audit/audit-recon.mjs` `b7c290f67e504aac01c5df92a2460d3c91dfb631`
- `copies/c3/tools/export-audit/mutate.mjs.txt` `346ba7fddd794f2bcf2e48955c34f8c8fbd667e0`
- `diffs/c3-audit-recon-vs-c2.diff` `11a6956259026ba7f17f4419e10697d7be118d63`
- `diffs/c3-mutate-vs-c2.diff` `c262ef92af5669fffadfe68c9a323a57b83c0d77`
- `drafts/U34-draft-corrections.md` `8e440368986180c3079433f02d7f2c249edf7922`
- `probe/r2probe-block.mjs.txt` `4c1661dc2dc11283f30355f4ea54170d8f93d1c8`
- `probe/r2nan-block.mjs.txt` `f45e41e20b53f705e77fa1793c1085f5b094188a`
- `probe/supp-other-fragment.mjs.txt` `9dcf20cf976ce8f1ddb352d63d977ccfc1fd66c6`
- `harness/c2/r2probe.mjs` `7e648acfc7f38b5cbdd8d4d22c72265250a99dc2`
- `harness/c2/r2nan.mjs` `97f20b641afc3b2673cc183fc33d7900b2dc9b25`
- `harness/c2/focused.mjs` `a1d1beb71390665a0ec82ea5d55565a0a3cddc1f`
- `harness/c2/supp.mjs` `8028ac074d316993df651019f4cbb1c613322a76`
- `mut/om1-dup-counted.html` `0587776b24157e1cb1850035046ed85d2294b434`
- `mut/om2-export-all-years.html` `38550f85d9f24275418c53440a3acb7ce5583cba`
- `mut/om3-save-cleans.html` `c4ec854641a6c88012e3afd9c2d3f9ed1b10d1b1`
- `mut/om4-load-normalises.html` `8e17f62b6e1302c67b0dcebfcf39a13c9fea7749`
- `mut/om5-note-two-digit.html` `02327c86234253ebbb52d77751e13947fc7c96f7`
- `mut/om6-other-sources-all-years.html` `d15fcd0953d3869e0412f3932640144a73ccc3de`
- `runner.mjs` `f851f1391102e59aa12f0ca301b40bb4ddd005f3`
- `run.sh` `2401711e9ca801daf615bc56df89246234107fc1`
- `batch.sh` `e9cf49afb0b6480405836f7f5a285b938462ac2a`
- `bx.sh` `e985e39e5781a3d5e993cbe69cefdccbb57c7be6`
- `bmq.sh` `db89345b97dd5654fcc5fe3bf651f6e25008b88c`
- `bin/brief.py` `8cfb35e59c787cff63b21d27d1d531e96a118a16`
- `bin/show.py` `db7c6abe537e47a45584aab57d4f94dadd5758c1`
- `bin/mymut.py` `84665fd8c90a62450c1c081fb743dfc12312cdaf`
- `bin/xmlcheck.py` `3e970bd1e8a408e43c0dc767efa2225b3cd66287`
- `bin/mkfocused-fr.py` `b5ce8ce85ff71e80f8b37b1b9b18ab3052111b8d`
- harness/base/* are byte-identical to harness/c2/* (the board is chosen by runner.mjs, asserted in each log's IDS line).
- `focused.mjs` equals the builder's `fr/harness/c2/focused-final.mjs` (`ecad9b0b`) apart from its first comment line.
