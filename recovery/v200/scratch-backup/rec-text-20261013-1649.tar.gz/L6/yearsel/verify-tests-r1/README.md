# YEARSEL (U34) — independent adversarial verification, round 1, lens B (test adequacy and regressions)

Verifier's directory: `rec/L6/yearsel/verify-tests-r1`. Work began 12 Oct 2026, 11:46 PM ET (the directory did not exist
then, so nothing was resumed from an earlier verifier); every run below was made between 11:49 PM ET on 12 Oct and the
time stamped on the last row of § 9.

**Nothing was edited, staged, committed or pushed in `/home/user/orbit-board` or `/home/user/orbit-ui`.** orbit-board was
read only: one `git show 7ee498a:tools/check.mjs` (11:55 PM ET, under `timeout 20`, not through `bx.sh` -- a deviation,
§ 11) and `git clone --shared` into my own `gitclone/` (through `bx.sh`). The builder's files were never edited: every
copy, harness, mutant and variant here is my own. mutate.mjs was never imported or run; it was read as text only
(`rec/bin/mcount.py`, `rec/bin/mkmut.py`, `python3 -I`). No Chromium, no playwright.

## Verdict: SOUND WITH ISSUES -- no must-fix; four should-fixes (one product, three test gaps); some minor points

Every claim of the builder's that I re-ran held exactly (§ 2–§ 6). Its 22 checks are hand-written literals, 13 fail on the
base for the reasons it states, and its 12 mutants are caught with the same failing checks. But seven of my own twelve
plausible wrong fixes pass every one of its 22 checks (§ 4), and one malformed shape still reads as ALL YEARS on c1 (§ 5).

## 1. Identities (git hash-object)

| file | base (`rec/L6/base`, copied to `b0/`) | c1 (builder's, copied to `c1/`) |
|---|---|---|
| prioritization-board-grid.html | `fce8a391bd8a248d5185e199d22190c1687eaea0` | `a67635bb533f7b5669d67fcf8400d37b9144fc6c` |
| tools/export-audit/audit-recon.mjs | `529e36f7c20e635b2722ea53b6a4f44b4ed328af` | `98758fe54bd0d82ae9095d63b736d5004c18c9f0` |
| tools/export-audit/mutate.mjs.txt | `cbc6defc6803851e847844848fc9b186daeeb268` | `bb57fce8e4d9efbb59a93e05e949d01bd8800a49` |
| audit-import / audit-board / audit-other | `4aba2506` / `a7c575e5` / `d89396b0` | the same |

`diff -rq b0 c1`: only those three files differ. All match the builder's README and the prompt.

## 2. The diffs against the base; existing expectations

My own diffs (`diffs/prioritization-board-grid.html.diff`, `diffs/audit-recon.mjs.diff`, `diffs/mutate.mjs.txt.diff`) have
the same bodies as the builder's `diffs/c1-*.diff`.
- board: +35 −4 in five hunks (the reader, two new functions, `F.unread`, the label line, the panel notice, the export NOTE);
- audit-recon: **+163 −0**, one hunk after U14's block (`// ==== end v2.00 (U14) ====`);
- mutate.mjs: **+38 −0**, one hunk directly before `  // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view
  says it saved the working plan.`

**No existing check, fixture or expected value was changed in any suite** (no `-` line in either suite diff; every other
suite file is byte-identical to the base). Nothing to list under principle 6.

## 3. The new checks: literals, base failure, house form

- Every expected value is built from hand-written literals (`want(...)`, `ALL`, `L0`, `L1`, `O`, `T540/T500/T0`, `TAIL`,
  `WH`/`H1` over literal quotes, `Array(5000).fill('"x"')`). Board helpers give observed values only. The one computed
  comparison, the file after the save, is `fileFys(h2) === J(JSON.parse(text))`: observed against the test's own input,
  not against a board helper.
- Block form matches U14's in audit-recon: async wrapper, `bootMark()` / `bootRelease(__bm, …)` / `settleBoards()`, the
  two-space `  const name = '…';` line, `// ==== v2.00 (U34) …` and `// ==== end v2.00 (U34) ====`, the `catch` that
  records a throw as a failure.
- On the base (`VF-focused-on-base`): **13 of the 22 fail**, exactly the builder's 13, every observed value identical to
  its F2-on-base (`cmpchecks.py`: 85 common, 0 differing). The observed base values are the defects it names: "2026", {},
  2027, [], [2026.5], 5,000 × "x" → $540M with ALL YEARS lit; ["2027"] → FY27 $500M; [null]/[true] → "saved FY0/FY1 not
  available"; [2025, 2026.5] → $40M with nothing said; "2026" then FY27 on → [2025,2028,2029,2030,2031], $40M.
- **The other 9 pass on the base by design** (six shape controls, two click controls, "nothing asked"). This follows
  U14's block (6 CONTROL checks). It is not "every new check fails on the base" read literally (minor, § 8).

## 4. Mutants: the builder's 12 re-run, and 12 of my own (plus one candidate correction)

**The builder's 12** (`mut/b/`, rebuilt by `mkmut.py` from c1's catalog; each mutant board's blob equals the builder's):
all caught, with the same failing checks as its M2 runs, check for check (`cmpchecks.py`: 85 common, 0 differing, for each
of the 12). Counts: not-a-list-all-years 4, nothing-read-all-years 10, number-coerced 3, fraction-unsaid 2, whole-unsaid 4,
label-unsaid 11, panel-unsaid 12, export-unsaid 11, markup-unescaped 2, counted-unsaid 2, plural-it 1, toggle-from-all 1.

**My own** (`mut/vmutants.mjs.txt`, same `{ id, area, what, find, repl }` shape, each find once on c1 by `mcount.py`;
applied by `mkmut.py`; run through the builder's U14+U34 focused harness rebuilt verbatim from c1's audit-recon):

| my mutant (a plausible wrong fix) | caught by the builder's 22? | failing checks |
|---|---|---|
| `vb-falsy-reads-all-years`: reader `if(!C.fys) return null` | **NO (85/85 pass)** | — |
| `vb-falsy-unsaid`: `if(!v) return null` in flowUnreadSaved | **NO** | — |
| `vb-note-replaces-line`: export `sum.splice(3,1,…)` (drops the line under Source) | **NO** | — |
| `vb-label-unsaid-beside-u14`: `if(UR && !UN.length)` on the label | **NO** | — |
| `vb-panel-unsaid-beside-u14`: no U34 notice when U14's is on screen | **NO** | — |
| `vb-quote-uncut`: the 40-character cut removed | **NO** | — |
| `vb-year-range`: a year must be 2000–2099 | **NO** | — |
| `vb-empty-list-all-years`: [] read as ALL YEARS | yes | an empty list |
| `vb-whole-when-none-read`: no readable year → "not a list" wording | yes | 5 |
| `vb-clean-on-read`: the reader rewrites the saved value | yes | 13 |
| `vb-duplicates-counted`: de-duplication dropped | yes | CONTROL duplicates; CONTROL 5,000 of one year |
| `vb-quote-unstringified`: `String(x)` for the quote | yes | 7 |

(`vfix-allyears-unlit` in the same file is not a mutant: one line of the § 5 correction, run to see the 22 still pass —
they do.)

**What the survivors re-open, measured on the base and on c1** (my probe, `VP-vprobe-on-*`):
- `""`, `0` and `false`: on the base each reads as **ALL YEARS, $540M, ALL YEARS lit, nothing said**; on c1 each is "no
  year counted" with the notice and the NOTE (correct). The builder's block has no falsy shape, so a fix written with the
  everyday `if(!x)` re-opens the exact defect U34 closes and passes all 22.
- `[2027, "x"]`'s export is `[2027]`'s plus the Scope suffix and a NOTE with its blank row (c1, correct); no check compares
  the rest of the sheet, so a NOTE spliced in over a line (the export loses its other-sources line) passes.
- `[2040, "x"]` (a year U14 says beside an entry U34 says): c1 says both (label, both notices, both NOTEs; correct); untested.
- a 120-character entry: c1 quotes 40 characters and "…" (correct); untested.
- a board-offered year outside 2000–2099: the builder's decision (no range) is not pinned by any check.

**A supplement that catches them** (measurement only, the lead decides; `bin/mksupp.py` → `supp/tools/export-audit/
audit-recon.mjs`, diff `diffs/supp-audit-recon.diff`, +33 lines inside the U34 block): shapes `""`, `0`, `false`, a
120-character entry, `[2040,"x"]`, every offered year beside "x", and a whole-sheet comparison of `[2027,"x"]` against
`[2027]`. Results (`VSUP-*`, `VSUPM-*`): on the base 20 of 29 U34 checks fail (all 7 new ones among them); on c1 every new
check passes but "every offered year beside an entry it cannot read" (§ 5); on c1 + the § 5 correction all 92 pass; six
of the seven surviving mutants are now caught, each by its own new check (falsy ×2 → "an empty string", "zero", "false"; splice →
"the export beside the NOTE"; beside-U14 ×2 → "beside a year U14 says"; quote → "a long entry"). `vb-year-range` stays
uncaught (no fixture offers a year outside 2000–2099).

## 5. One shape still reads as ALL YEARS on c1 (should-fix; product)

`[2025,2027,2028,2029,2030,2031,"x"]` -- every offered year beside one entry the board cannot read -- on c1
(`VP-vprobe-on-c1`, V1): the ALL YEARS chip is **lit**, no year chip is lit, the scope label and the export's Scope line
say **"FY25, FY27–FY31 · all years · … · 1 saved entry not a year, not counted"**, while the notice says "holds "x" … not
counted: this total counts FY25, FY27, FY28, FY29, FY30, FY31 only". The money is right ($540M, the six years read). But
the commit's own promise and its block's scenario name ("never read as ALL YEARS") are false for this shape, and it breaks
U14's rule for the same chip ("ALL YEARS is lit only for ALL YEARS: a saved selection holding a year the board cannot
answer for is not it"; `flowScopeLabel`: "A saved selection with a year the board cannot answer for is never called all
years"). Clicking the lit ALL YEARS chip replaces the "x" (V14) -- said by the notice, so not a silent loss.

**Minimal correction, measured** (`variant/vfix-allyears.html`, `diffs/vfix-allyears.diff`, 5 lines, no comment added yet):
`flowScopeLabel(ys, aps, un, ur)` with `&& !ur` beside `!(un||[]).length`; `flowScopeLabel(YS,AS,UN,UR)` in flowCalc; the
ALL YEARS chip `&& !F.unread`; a year chip lit also `|| !!F.unread`. On it: the builder's 85 pass (`VX-focused-on-vfix`),
the supplement's 92 pass (`VSUP-focused-supp-on-vfix`), and V1 reads "FY25, FY27, FY28, FY29, FY30, FY31 · all
appropriations · … · 1 saved entry not a year, not counted", ALL YEARS unlit, the six years lit (`VX-vprobe-on-vfix`).
It would need a `// v2.00 (U34): …` comment and a catalog entry (e.g. the chip's `&& !F.unread` removed) if adopted.

## 6. Re-runs of the builder's runs, compared

(Filled from § 9; each compared with the builder's log or observations.)

| builder's run | my re-run (label) | result | compared with |
|---|---|---|---|
| F2-focused-on-c1 (85/85) | VF2-focused-on-c1 | ALL CHECKS PASSED, 85 | builder's F2 checks: 85 common, 0 differing (`cmpchecks.py`) |
| F2-focused-on-base (13 failing) | VF-focused-on-base | 13 FAILING, the same 13 | 85 common, 0 differing |
| M2 × 12 | BM-* × 12 | each exit 1, the same failing checks | each 85 common, 0 differing |
| P1-probe-on-base | VR-P1-probe-on-base | 54 observations | identical to `out/P1-obs.jsonl` apart from timings (54/54, `cmpobs.py`) |
| P2-probe-on-base | VR-P2-probe-on-base | 67 observations | identical to `out/P2-obs-base.jsonl` apart from timings (67/67) |
| P3-probe-on-c1 | VR-P3-probe-on-c1 | 67 observations | identical to `out/P3-obs-c1.jsonl` apart from timings (67/67) |
| S-audit-recon-base / S2-audit-recon-c1 | VS-audit-recon-base / -c1 | both ALL CHECKS PASSED; 306 / 328 recorded checks | base vs c1: 306 common, 0 differing, 22 only in c1 (all U34, all pass); each equal to the builder's run check for check |
| S2-audit-hostile | VS-audit-hostile-base / -c1 | both ALL CHECKS PASSED, 124 recorded checks each | 124 common, 0 differing (base vs c1, and c1 vs the builder's) |
| S2-audit-other, -inject, audit, -ppt, legacy-fsrc | VS-* base / c1 | all ALL CHECKS PASSED (legacy-fsrc: "every legacy Force setting computes exactly as before") | base and c1 logs identical apart from headers; c1 logs identical to the builder's S2 logs apart from times |
| S2-boot-same | VS-boot-same-base / -c1 | "same" on all four boots, both | only the millisecond timings differ |
| N-check-base / N2-check-c1 | VN-check-base / VN-check-c1 (my clone `gitclone/` at `7ee498a`, c1's three files copied in, `mutate.mjs.txt` as `mutate.mjs`; blobs `a67635bb` / `98758fe5` / `bb57fce8` checked) | both "all checks passed" | the only differing lines: 31,672 → 31,703 lines, main script 29,650 → 29,681 lines |

## 7. mcount (text only, `python3 -I rec/bin/mcount.py`)

| catalog | board | entries | once | missing |
|---|---|---|---|---|
| c1 | c1 | 1,340 | 1,340 | none |
| base | c1 | 1,328 | 1,328 | none |
| base | base | 1,328 | 1,328 | none |
| c1 | base | 1,340 | 1,329 | the 11 new entries whose finds are new code (`-toggle-from-all` finds U14's line) |
| my `mut/vmutants.mjs.txt` | c1 | 13 | 13 | none |

All as the builder reported.

## 8. Minor points

- The drafts' "Test" paragraph says "One check switches FY27 on beside "2026", and three click controls follow"; the block
  has two click controls and a "nothing asked" check (22 = 11 shapes + 6 controls + escaped + 3 clicks + nothing asked).
- "Kept byte for byte" (README, drafts, ledger) is checked as the same JSON value (`J(JSON.parse(text))`), and is only that:
  a hand-edited `[-0]` comes back `[0]`, `[2.027e3]` as `[2027]`, whitespace is dropped -- the JSON reader and writer, on
  the base too. "Kept as the same value" is the true wording.
- 9 of the 22 checks pass on the base (controls, by design and as in U14). Say so wherever "every new check fails on the
  base" is claimed.
- The label for 5,000 entries reads "5000 saved entries not a year" (plural noun, singular complement).
- The builder's `probe/board-2154832.html` (2.8 MB, 7:36 PM ET, a board with a 4-character pubState) is not mentioned in
  its README.
- `flowSavedYears` still sorts with the default (text) order; whole numbers of different lengths (999, 10000) sort wrongly
  in the saved list. Unchanged from U14; harmless for four-digit years.

## 9. Every run (start ET, exit, wall seconds, log)

| label | start (ET) | exit | wall s | result | log |
|---|---|---|---|---|---|
| VF-focused-on-c1 | 12 Oct 23:51:01 EDT | 137 | 147.0 |  -- INCOMPLETE (exit 137) | logs/VF-focused-on-c1.log |
| VF-focused-on-base | 12 Oct 23:51:01 EDT | 1 | 165.1 | 13 FAILING CHECK(S) | logs/VF-focused-on-base.log |
| VP-vprobe-on-c1 | 12 Oct 23:55:32 EDT | 1 | 47.4 | probe: 16 observation lines; the guard reports the probe scenario as never checked | logs/VP-vprobe-on-c1.log |
| VN-check-base | 12 Oct 23:56:19 EDT | 0 | 9.8 | all checks passed | logs/VN-check-base.log |
| VN-check-c1 | 12 Oct 23:56:34 EDT | 0 | 9.2 | all checks passed | logs/VN-check-c1.log |
| VF2-focused-on-c1 | 12 Oct 23:55:32 EDT | 0 | 116.3 | ALL CHECKS PASSED | logs/VF2-focused-on-c1.log |
| VM-vb-clean-on-read | 12 Oct 23:56:19 EDT | 1 | 108.9 | 13 FAILING CHECK(S) | logs/VM-vb-clean-on-read.log |
| VP-vprobe-on-base | 12 Oct 23:57:28 EDT | 1 | 43.3 | probe: 16 observation lines; the guard reports the probe scenario as never checked | logs/VP-vprobe-on-base.log |
| VM-vb-empty-list-all-years | 12 Oct 23:58:08 EDT | 1 | 102.1 | 1 FAILING CHECK(S) | logs/VM-vb-empty-list-all-years.log |
| VM-vb-duplicates-counted | 12 Oct 23:58:11 EDT | 1 | 115.7 | 2 FAILING CHECK(S) | logs/VM-vb-duplicates-counted.log |
| VM-vb-falsy-unsaid | 12 Oct 23:59:50 EDT | 0 | 78.7 | ALL CHECKS PASSED | logs/VM-vb-falsy-unsaid.log |
| VM-vb-falsy-reads-all-years | 13 Oct 00:00:07 EDT | 0 | 76.3 | ALL CHECKS PASSED | logs/VM-vb-falsy-reads-all-years.log |
| VM-vb-note-replaces-line | 13 Oct 00:01:09 EDT | 0 | 78.1 | ALL CHECKS PASSED | logs/VM-vb-note-replaces-line.log |
| VM-vb-label-unsaid-beside-u14 | 13 Oct 00:01:23 EDT | 0 | 75.2 | ALL CHECKS PASSED | logs/VM-vb-label-unsaid-beside-u14.log |
| VM-vb-quote-uncut | 13 Oct 00:02:27 EDT | 0 | 38.8 | ALL CHECKS PASSED | logs/VM-vb-quote-uncut.log |
| VM-vb-panel-unsaid-beside-u14 | 13 Oct 00:02:39 EDT | 0 | 34.5 | ALL CHECKS PASSED | logs/VM-vb-panel-unsaid-beside-u14.log |
| VM-vb-whole-when-none-read | 13 Oct 00:03:06 EDT | 1 | 46.9 | 5 FAILING CHECK(S) | logs/VM-vb-whole-when-none-read.log |
| VM-vb-quote-unstringified | 13 Oct 00:03:13 EDT | 1 | 45.4 | 7 FAILING CHECK(S) | logs/VM-vb-quote-unstringified.log |
| VM-vfix-allyears-unlit | 13 Oct 00:03:53 EDT | 0 | 47.1 | ALL CHECKS PASSED | logs/VM-vfix-allyears-unlit.log |
| VM-vb-year-range | 13 Oct 00:03:59 EDT | 0 | 45.9 | ALL CHECKS PASSED | logs/VM-vb-year-range.log |
| BM-v200-yearsel-export-unsaid | 13 Oct 00:04:40 EDT | 1 | 50.2 | 11 FAILING CHECK(S) | logs/BM-v200-yearsel-export-unsaid.log |
| BM-v200-yearsel-counted-unsaid | 13 Oct 00:04:44 EDT | 1 | 48.3 | 2 FAILING CHECK(S) | logs/BM-v200-yearsel-counted-unsaid.log |
| BM-v200-yearsel-label-unsaid | 13 Oct 00:05:30 EDT | 1 | 46.3 | 11 FAILING CHECK(S) | logs/BM-v200-yearsel-label-unsaid.log |
| BM-v200-yearsel-fraction-unsaid | 13 Oct 00:05:33 EDT | 1 | 46.0 | 2 FAILING CHECK(S) | logs/BM-v200-yearsel-fraction-unsaid.log |
| BM-v200-yearsel-not-a-list-all-years | 13 Oct 00:06:16 EDT | 1 | 51.8 | 4 FAILING CHECK(S) | logs/BM-v200-yearsel-not-a-list-all-years.log |
| BM-v200-yearsel-markup-unescaped | 13 Oct 00:06:19 EDT | 1 | 51.8 | 2 FAILING CHECK(S) | logs/BM-v200-yearsel-markup-unescaped.log |
| BM-v200-yearsel-number-coerced | 13 Oct 00:07:08 EDT | 1 | 32.7 | 3 FAILING CHECK(S) | logs/BM-v200-yearsel-number-coerced.log |
| BM-v200-yearsel-nothing-read-all-years | 13 Oct 00:07:11 EDT | 1 | 31.5 | 10 FAILING CHECK(S) | logs/BM-v200-yearsel-nothing-read-all-years.log |
| BM-v200-yearsel-plural-it | 13 Oct 00:07:41 EDT | 1 | 54.1 | 1 FAILING CHECK(S) | logs/BM-v200-yearsel-plural-it.log |
| BM-v200-yearsel-panel-unsaid | 13 Oct 00:07:42 EDT | 1 | 53.6 | 12 FAILING CHECK(S) | logs/BM-v200-yearsel-panel-unsaid.log |
| BM-v200-yearsel-whole-unsaid | 13 Oct 00:08:35 EDT | 1 | 84.6 | 4 FAILING CHECK(S) | logs/BM-v200-yearsel-whole-unsaid.log |
| BM-v200-yearsel-toggle-from-all | 13 Oct 00:08:36 EDT | 1 | 84.3 | 1 FAILING CHECK(S) | logs/BM-v200-yearsel-toggle-from-all.log |
| VX-vprobe-on-vfix | 13 Oct 00:10:09 EDT | 1 | 27.9 | probe: 16 observation lines; the guard reports the probe scenario as never checked | logs/VX-vprobe-on-vfix.log |
| VX-focused-on-vfix | 13 Oct 00:10:09 EDT | 0 | 62.5 | ALL CHECKS PASSED | logs/VX-focused-on-vfix.log |
| VSUP-focused-supp-on-base | 13 Oct 00:10:36 EDT | 1 | 61.2 | 20 FAILING CHECK(S) | logs/VSUP-focused-supp-on-base.log |
| VSUP-focused-supp-on-c1 | 13 Oct 00:11:11 EDT | 1 | 57.9 | 1 FAILING CHECK(S) | logs/VSUP-focused-supp-on-c1.log |
| VSUPM-vb-falsy-reads-all-years | 13 Oct 00:11:38 EDT | 1 | 65.1 | 4 FAILING CHECK(S) | logs/VSUPM-vb-falsy-reads-all-years.log |
| VSUP-focused-supp-on-vfix | 13 Oct 00:12:09 EDT | 0 | 67.2 | ALL CHECKS PASSED | logs/VSUP-focused-supp-on-vfix.log |
| VSUPM-vb-note-replaces-line | 13 Oct 00:12:43 EDT | 1 | 63.1 | 2 FAILING CHECK(S) | logs/VSUPM-vb-note-replaces-line.log |
| VSUPM-vb-falsy-unsaid | 13 Oct 00:13:16 EDT | 1 | 56.0 | 4 FAILING CHECK(S) | logs/VSUPM-vb-falsy-unsaid.log |
| VSUPM-vb-panel-unsaid-beside-u14 | 13 Oct 00:13:46 EDT | 1 | 51.5 | 2 FAILING CHECK(S) | logs/VSUPM-vb-panel-unsaid-beside-u14.log |
| VSUPM-vb-label-unsaid-beside-u14 | 13 Oct 00:14:12 EDT | 1 | 47.5 | 2 FAILING CHECK(S) | logs/VSUPM-vb-label-unsaid-beside-u14.log |
| VSUPM-vb-year-range | 13 Oct 00:14:37 EDT | 1 | 45.7 | 1 FAILING CHECK(S) | logs/VSUPM-vb-year-range.log |
| VSUPM-vb-quote-uncut | 13 Oct 00:15:00 EDT | 1 | 54.9 | 2 FAILING CHECK(S) | logs/VSUPM-vb-quote-uncut.log |
| VS-audit-recon-base | 13 Oct 00:15:23 EDT | 0 | 160.5 | ALL CHECKS PASSED | logs/VS-audit-recon-base.log |
| VS-audit-recon-c1 | 13 Oct 00:15:55 EDT | 0 | 190.8 | ALL CHECKS PASSED | logs/VS-audit-recon-c1.log |
| VS-audit-hostile-base | 13 Oct 00:18:04 EDT | 0 | 92.6 | ALL CHECKS PASSED | logs/VS-audit-hostile-base.log |
| VS-audit-other-base | 13 Oct 00:19:36 EDT | 0 | 50.4 | ALL CHECKS PASSED | logs/VS-audit-other-base.log |
| VS-audit-hostile-c1 | 13 Oct 00:19:06 EDT | 0 | 90.1 | ALL CHECKS PASSED | logs/VS-audit-hostile-c1.log |
| VS-audit-inject-base | 13 Oct 00:20:27 EDT | 0 | 18.9 | ALL CHECKS PASSED | logs/VS-audit-inject-base.log |
| VS-audit-base | 13 Oct 00:20:46 EDT | 0 | 14.6 | ALL CHECKS PASSED | logs/VS-audit-base.log |
| VS-audit-ppt-base | 13 Oct 00:21:00 EDT | 0 | 7.2 | ALL CHECKS PASSED | logs/VS-audit-ppt-base.log |
| VS-boot-same-base | 13 Oct 00:21:07 EDT | 0 | 12.4 | identical either way | logs/VS-boot-same-base.log |
| VS-audit-other-c1 | 13 Oct 00:20:36 EDT | 0 | 44.9 | ALL CHECKS PASSED | logs/VS-audit-other-c1.log |
| VS-legacy-fsrc-base | 13 Oct 00:21:20 EDT | 0 | 4.0 |  | logs/VS-legacy-fsrc-base.log |
| VS-audit-inject-c1 | 13 Oct 00:21:21 EDT | 0 | 10.9 | ALL CHECKS PASSED | logs/VS-audit-inject-c1.log |
| VS-audit-c1 | 13 Oct 00:21:32 EDT | 0 | 9.2 | ALL CHECKS PASSED | logs/VS-audit-c1.log |
| VS-audit-ppt-c1 | 13 Oct 00:21:41 EDT | 0 | 4.5 | ALL CHECKS PASSED | logs/VS-audit-ppt-c1.log |
| VS-boot-same-c1 | 13 Oct 00:21:45 EDT | 0 | 12.7 | identical either way | logs/VS-boot-same-c1.log |
| VS-legacy-fsrc-c1 | 13 Oct 00:21:58 EDT | 0 | 3.5 |  | logs/VS-legacy-fsrc-c1.log |
| VR-P3-probe-on-c1 | 13 Oct 00:21:24 EDT | 0 | 57.0 | probe: 67 observation lines | logs/VR-P3-probe-on-c1.log |
| VR-P2-probe-on-base | 13 Oct 00:22:02 EDT | 0 | 68.0 | probe: 67 observation lines | logs/VR-P2-probe-on-base.log |
| VR-P1-probe-on-base | 13 Oct 00:23:10 EDT | 0 | 65.7 | probe: 54 observation lines | logs/VR-P1-probe-on-base.log |

**VF-focused-on-c1 (exit 137) was killed by the kernel, not by me**: `dmesg` records "Memory cgroup out of memory: Killed
process 8975 (node)" at 11:53 PM ET -- 8975 is that run's node PID in `pids.txt`. The machine was shared (load 25–32 on 4
cores; other tracks' node processes up to 1.8 GB each; the same OOM sweep killed two other tracks' processes, 6310 and
6356, which were never mine). It had recorded 79 checks, all passing. I re-ran it as `VF2-focused-on-c1` after adding a
memory gate to my `run.sh` (wait, polling every 20 s up to 30 min, until 2,500 MB is available) and ran two at a time.

## 10. PIDs

`pids.txt` holds every `timeout` PID and its child, with the time, the label and the command, written by `run.sh` and
`bx.sh`. I signalled nothing; I stopped only my own background watcher task (a `tail`-style loop over my `logs/runs.txt`)
through the session's task tool. At 12:24:59 AM ET on 13 Oct, `pids.txt` had 211 lines and `/proc` held none of its PIDs: none of my processes was alive.

## 11. What I did not do, and deviations

- Did not run the full audit-import or audit-board (the lead's), Chromium, playwright or verify:grid.
- Did not commit, stage or push anything; changed nothing in orbit-board or orbit-ui; did not edit the builder's files.
- Did not import or run mutate.mjs.
- Did not test browser storage, the folder copy, a PMO copy or a batch import (the builder did not either).
- Did not propose catalog entries for the supplement or the § 5 correction; they are measurements for the lead.
- **Deviations:** one read-only `git show` in orbit-board ran under `timeout 20` directly, not `setsid … 600` through
  `bx.sh` (its PID is not in `pids.txt`). Read-only commands (`ls`, `cat`, `grep`, `sed`, `diff`, `git hash-object`,
  `python3 -I` summaries of my own files, `free`, `uptime`, `dmesg`) ran directly. `queue.sh` and `chain.sh` only wait, and
  are not under one 600 s bound; every run inside them is its own bounded `run.sh` call. My own files were written with
  the Write tool, one `sed -i` (renaming my candidate-correction entry), and one `python3 -I` heredoc that added the
  memory gate to my `run.sh`.

## 12. Blobs of my files (git hash-object, at the end)

- `harness/c1/focused-u14-u34.mjs` `d0e2144eb74b95ab38ce031e01b945f65710ffaa`
- `harness/c1/focused-supp.mjs` `78c3735dc46e2a408744203a67cfaf3fcdbe693e`
- `harness/c1/vprobe.mjs` `5c02c809ca8f221cf83d54dea442bfdf4ce2940d`
- `harness/b0/vprobe.mjs` `27a19abf11b3e92c5f1e1e19ca16421f23ba16f0`
- `harness/c1/bprobe-v2.mjs` `153321d05db4766f3e2c353b6c1381337d0fa2dc`
- `harness/b0/bprobe-v2.mjs` `921aac599fe5f1cfe47ec8957d3d8b7bf37b0ab5`
- `harness/b0/bprobe-v1.mjs` `5b52f0ead4ffd42198cbae6a5b451f5e91a73766`
- `probe/vprobe-block.mjs.txt` `bff020cb1b9be81a447050c5f5d3d7398efca829`
- `mut/vmutants.mjs.txt` `2fe119f19b1a0b242075a8aa591ffff631ed3088`
- `supp/tools/export-audit/audit-recon.mjs` `cda64e588056f9e5f9618c9a2068e2ff6b2a3780`
- `variant/vfix-allyears.html` `f75366beb55772d12ffa7400b679704f4bf48c7c`
- `diffs/vfix-allyears.diff` `b284003a186adf94b9897da3093ad3927c77c510`
- `diffs/supp-audit-recon.diff` `843d17b572c706b8f5bb9258545b83307a7131d3`
- `diffs/prioritization-board-grid.html.diff` `ea61a6803c97fdc636e8d4a6fe2b12916dfda5f9`
- `diffs/audit-recon.mjs.diff` `af0be760eeb38e4e6b1902789afb287471cf8c71`
- `diffs/mutate.mjs.txt.diff` `6c0fe25b69f3f5d323c379398197d15d82ede65d`
- `run.sh` `89e8a7fc783e39913ee15fbc3f03e9759b15e717`
- `bx.sh` `d83fabaab35142028631d6b177cb7f205290c398`
- `queue.sh` `5e32245fb481b2608676191c814dd275983b5655`
- `chain.sh` `4aa3315d608fecd0d09d4b84f007db482a928a3d`
- `runner.mjs` `f851f1391102e59aa12f0ca301b40bb4ddd005f3`
- `jobs1.txt` `c2fa4eccc3b4ac17ba3c3857c55151c842fcb6ea`
- `jobs4.txt` `c48fadf4e0b10bddcd0253b88c967e8609255f1a`
- `bin/cmpchecks.py` `1560f4fcc7add6d9854469e4a72662b5adc7599d`
- `bin/cmpobs.py` `35d48174bf75fab9d32250a0f66f8fedb616fb11`
- `bin/mkfocused.py` `bd72eb11751848f023a2b85e72c1ff8e09dbb75a`
- `bin/mkprobe.py` `47dd00c57dd0fbad0709f14b02249fba66cb7682`
- `bin/mksupp.py` `2cab808c5a2c2b759ca4d3071911d76029c41ea6`
- `bin/mkvfix.py` `696d4e16393eb5c067530b47a362601fe0ba52ed`
- `bin/runtable.py` `32e1a60dc4a33bbd48c53e24be80d1b499c4118b`
- `bin/tally.py` `faa4d7dab08b425b76cad7528d242fba81529d9a`
- `bin/vshow.py` `1745b8066923d0163003e5ee7d4ba77cc9220a2b`

My mutant boards (`mut/v/*.html`) and the builder's rebuilt (`mut/b/*.html`): each run log's IDS line records the booted board's blob; the 12 rebuilt ones equal the builder's (§ 4).

## 13. Resumed session (after a usage-limit pause)

Resumed 4:17 AM ET, 13 Oct 2026. Nothing was run in this session: no node, no Chromium, no suite, no mutant. I only read my own files and
the builder's (read-only `ls`, `cat`, `grep`, `git hash-object`, `python3 -I` summaries of my own `out/*.jsonl`).
The builder's c1 blobs are unchanged since § 1 (a67635bb / 98758fe5 / bb57fce8). No PID in `pids.txt` is alive.
One wording note to § 4: with the supplement, `vb-year-range` fails one check, "every offered year beside an entry it
cannot read", the same check c1 itself fails (`out/VSUPM-vb-year-range.checks.jsonl`, `out/VSUP-on-c1.checks.jsonl`), so it
is still not caught by anything that passes on c1. The verdict and findings above are unchanged.
