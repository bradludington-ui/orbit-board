# YEARSEL (ledger U34): verify-money, round 3 (lens A: data loss and money)

This is an independent adversarial review of the builder's second fix round, copy c3, in `rec/L6/yearsel`. It started
fresh: this folder did not exist when I began (2:44 PM ET, 13 Oct), so no earlier attempt of this review was carried over.
I proposed no commit and changed none of the builder's files. Nothing was committed or pushed, and nothing in
`/home/user/orbit-board` or `/home/user/orbit-ui` was changed. I only read them (`git log`, `git show`, `awk`).

**Verdict: sound-with-issues. There is no must-fix.** I tried the U34 change from the data-loss and money side. It did not
lose a copy of anyone's saved value, write over a value unasked, misstate money, or export a wrong figure or a
workbook that is not well-formed. That held on every path I opened:
- the opening path, read, export, Save and reopen (the builder's 39 checks, re-run here: 102/102 on c3, and on the base 28
  failing, all U34);
- four unrelated saving operations;
- a locked-cycle view entered, refused and left;
- this browser's copy and the file's copy disagreeing at opening;
- a U14 year beside an unreadable entry after a click.

All 15 existing catalog mutants that touch the changed functions are still caught on c3. These are the 14 `v200-u14-*`
entries and `v199-flow-export-lastyear`, and none of the earlier rounds had shown this.

There are two should-fixes:
- **SF1** is a pre-existing money gap next to U34. It is not U34's code, and it is identical on the base. Under a locked
  view, a funds-flow edit the board refuses ("the change was not kept") is still counted in the view's panel and in its
  export, "[PB27 LOCKED].xlsx". Example: typed partner money of $3,000,000 gives TOTAL FUNDING $503,000,000.
- **SF2** is about the drafts. "Not covered either: a locked-cycle view" can now be replaced by the measured behaviour.

Neither blocks committing U34.

## 1. What was reviewed (identities)

My copies are `copies/base` (`cp -a` of `rec/L6/base`) and `copies/c3` (`cp -a` of the builder's `c3`). Both are `chmod u+w`
and keep the `node_modules` symlink. The blobs (`git hash-object`) match the builder's claims:

| file | base | c3 |
|---|---|---|
| prioritization-board-grid.html | fce8a391bd8a248d5185e199d22190c1687eaea0 | 593593a43172e30755f6fca03785a28e5a8c048f |
| tools/export-audit/audit-recon.mjs | 529e36f7c20e635b2722ea53b6a4f44b4ed328af | 2d34269d69be10a5c04772c12796e6b0bda90aaf |
| tools/export-audit/mutate.mjs.txt | cbc6defc6803851e847844848fc9b186daeeb268 | ba8b55adf994892e91e9b009139be566ebe0e458 |
| audit-import / audit-board / audit-other | 4aba2506 / a7c575e5 / d89396b0 | the same |

`diff -rq` shows only those three files differ. I made my own diffs against the base in `diffs/`. Their bodies are line
for line the builder's `diffs/c3-*-vs-base.diff`; only the header paths differ.
- `c3-board-vs-base.diff`: blob 3c9bb6cf, +46 −9.
- `c3-audit-recon-vs-base.diff`: blob 036e4dac, +263 −0, all in the new U34 block after U14's.
- `c3-mutate-vs-base.diff`: blob 9ab20184, +105 −0. It adds 33 entries, all inserted before the R3 line.

No existing check, fixture or expected value is removed or edited.

## 2. The change against the lead's six principles, literally

| # | principle | what I measured on c3 (593593a4) | holds? |
|---|---|---|---|
| 1 | Never lose any copy of anyone's work; when two copies conflict, keep both and ask or say | The malformed saved value stays the same value through every read, an export, Save, four unrelated saving operations (an appropriation switched off and on, FY27 partner money typed, a prime rule), a locked-cycle view entered and left (with a refused click and a refused ALL YEARS under the view), and a reopen from the file. P3 checks this for "2026", [2027,"x"] and [2040,"x"]. Only a person's click outside a view replaces it, and the notice says so first (builder's checks). Two copies at opening (P3 COPIES-*): this browser's newer copy is opened and said ("Opened with this browser's copy … 💾 Save writes them into the file"), the same on the base. The known exceptions are pre-existing and stated in the drafts: a whole 1e999 is null before any U34 code runs, and NaN makes the state unreadable (U-new-nan). | yes, with the drafts' stated limits |
| 2 | Refuse or ask rather than guess | "2027", [[2027]], true, null and 2026.5 are not read as years, and each is said (P3 TEXT-EQ-YEAR, ARR-ARR; the builder's block). A list counts only the whole years it names. | yes |
| 3 | Money and every export match the computation exactly | In every P3 shape, flowCalc's US total, partner, FMS and grand totals equal the panel's total and the exported TOTAL FUNDING (both lines), International Partners and Foreign Military Sales lines. This holds under a locked view and after the saving operations. All 24 P3 workbooks and 8 P4 workbooks are well-formed (expat). | yes for U34. A pre-existing gap next to it is SF1 below. |
| 4 | Every word the board says stays true, including after the operation | The label, notice and NOTE name what is held and what is counted, in every P3 shape and in the view. After a click the notice goes (builder). One wording reads oddly but is true: minor m1. In a locked view a click is refused ("the change was not kept"), yet the view's panel shows the clicked selection until the view is left. The base does the same; it is part of SF1. | yes for U34 |
| 5 | The smallest change that closes the finding | Board +46 −9: two reader lines, two small functions, one field, one label line, one panel block, one export line. | yes |
| 6 | Every existing check, fixture and expected value preserved | audit-recon +263 −0 and mutate.mjs.txt +105 −0. The base catalog's 1,328 entries each match c3 once (text only). U14's 63 checks pass on c3 (F1). The 15 existing catalog mutants on the changed functions (14 `v200-u14-*` and `v199-flow-export-lastyear`), applied to c3, are each caught. That evidence was not in the builder's drafts. No other suite sets `fys` to anything but null or lists of whole years (grep: audit-recon, audit-inject only). | yes |

## 3. What I probed (bounded jsdom probes through the board's own opening path; base and c3; observations only)

**P3** (`harness/c3/r3probe.mjs`). It uses U14's no-plan fixture, built exactly as the U34 block builds it: O&M, FY25
executed $40M, FY27 planned $500M, offered FY25 and FY27–FY31. Each shape replaces the file's own `flow.fys` as text, opens
with `boot({html})`, and observes the calculation, the panel and the exported workbook. The workbook bytes are kept for
expat. It ran on c3 and on the base: P3-probe-on-c3 and P3-probe-on-base, 3:04:50 PM ET, exit 0/0, 81.8/80.0 s. Raw
lines are in `logs/P3-probe-on-*.log`.

- **VIEW-STR, VIEW-PART, VIEW-U14** (`"2026"`, `[2027,"x"]`, `[2040,"x"]`): lock PB27 (`cycLock`, confirm answered yes),
  view it (`cycView('PB|2027')`), read and export, then click FY25 and ALL YEARS under the view, leave, run `flowSetRule`,
  save, and reopen.
  - On c3 the view reads the working plan's saved selection, says it, and counts what it counts. "2026" gives $0 and
    the notice. The view's export (`… [PB27 LOCKED].xlsx`) carries the U34 NOTE. [2040,"x"] carries U14's NOTE and then
    U34's.
  - Both clicks under the view are refused ("🔒 Saving is off while PB27 is on screen … the change was not kept"), and
    browser storage keeps `"2026"`. The view's own panel then shows the clicked selection: FY25 $40M, then ALL YEARS
    $540M. See SF1.
  - Leaving restores `"2026"` and the notice. Save writes `"2026"`, and the reopened board reads the same.
  - The base reads `"2026"` as ALL YEARS $540M in the view, with nothing said, and keeps `"2026"` too. No copy of the
    value is lost on either board.
- **OPS-PART, OPS-STR**: four saving operations run in turn on `[2027,"x"]` and `"2026"`: an appropriation switched off,
  switched on, FY27 International Partners typed as 3, and a prime-match rule. After each one, the memory, the saved file
  and browser storage all hold the malformed value unchanged.
  - On c3, `[2027,"x"]` gives $500M, then $503M after the partner money. The panel, flowCalc and the export (TOTAL
    FUNDING 503000000 twice, International Partners 3000000 twice) agree, and the NOTE says "counts FY2027 only".
  - On c3, `"2026"` stays at $0 throughout, and the typed FY27 partner money is not counted.
  - The base counts `"2026"` as ALL YEARS: $543,000,000 with the partner money, and nothing said.
- **COPIES-file-str-ls-2027, COPIES-file-2027-ls-str**: the file and this browser's storage disagree about the
  selection. Both boards open this browser's newer copy and say so: "Opened with this browser's copy of the board — it
  has changes made after this file was last saved … 💾 Save writes them into the file." This is the general opening rule
  and it is identical on base and c3. When the storage copy holds `"2026"`, c3 says the U34 notice and counts $0.
- **U14X-then-FY27** (`[2040,"x"]`, then FY27 switched on): c3 saves `[2027,2040]` and counts $500M. U14's notice and
  NOTE stay, U34's go, and the export agrees. The base gives the same result.
- **Words.** For each shape below I checked the label, the notice, the NOTE and the export's file name.
  - TEXT-EQ-YEAR `["2027",2027]` and YEAR-EQ-TEXT `[2027,"2027"]`: FY27 $500M, and the notice says "holds "2027", …
    not counted: this total counts FY27 only". See minor m1.
  - BIGINT-BESIDE `[1e21,2027]`: U14's notice prints "FY0" on the panel and "FY1e+21" in the NOTE, the same on the
    base. It is saved back as `[1e+21,2027]`.
  - NEG0-BESIDE `[-0,2027]`: it is saved back as `[0,2027]`, as the drafts say.
  - STR-WHOLE `"2026"` and ARR-ARR `[[2027]]`: $0, said. The base reads `[[2027]]` as FY27, $500M, with nothing said.
- **Well-formed.** All 24 P3 workbooks (12 per board) are WELL-FORMED by expat (`out/xmlcheck-P3.txt`).

**P4** (`harness/c3/r3p4.mjs`, the same fixture, with a well-formed `[2027]`) checks a funds-flow edit made under a locked
view (SF1). It ran as P4-view-edit-on-c3 and P4-view-edit-on-base at 3:44:46 and 3:45:02 PM ET, exit 0/0, 16.0/16.7 s.
The two boards' observations are identical once the time stamps are masked. All 8 workbooks are WELL-FORMED.

## 4. Findings

### Must-fix

None. My probes P3 and P4, the re-run of the builder's focused harness (F1) and the 15 existing mutants (UM/UR) found no
U34 defect that loses data, writes over a copy unasked, misstates money, exports a wrong figure, or says something false.

### Should-fix

**SF1. Pre-existing and outside U34, next to it. Under a locked-cycle view, a funds-flow edit the board refuses is
still counted in the view's panel and in the export labelled as the lock.**

How it happens:
- `cycView` gives the view a throwaway copy of the whole store: `V = JSON.parse(JSON.stringify(_cycStash.MS))` with the
  lock's years.
- `save()` refuses under the view, through `cycRefuse` → `cycReapply`. `cycReapply` restores only the year's state
  (`applyState(c.years[MS.cur])`). It never restores `MS.flow`.
- So a funds-flow edit made on screen stays in the view's copy. That covers partner and FMS money, prime rules,
  categories and the year selection. The status line says "the change was not kept", but the panel counts the edit, and
  so does the export.

Repro (P4, identical on base fce8a391 and c3 593593a4):
1. Take U14's no-plan fixture with a saved selection of `[2027]`.
2. Lock it: `blCyc='PB'; blYr=MS.cur; cycLock()`. Then `cycView('PB|2027')`.
3. Type `flowSetOther(2027,'ip','3')`. The status line reads "🔒 Saving is off while PB27 is on screen … the change was
   not kept".
4. The calculation then gives grand $503,000,000. `exportFlow` writes "ORBIT Funds Flow - FY27 all appropriations PLANNED
   board allocation O M 2026-10-13 [PB27 LOCKED].xlsx". It has International Partners 3,000,000 on both lines and TOTAL
   FUNDING 503,000,000 on both lines.
5. After `cycLeave()`, the working plan holds no partner money: `other` is `{}` and the total is $500,000,000. So the
   workbook carries $3,000,000 that neither the lock nor the plan holds.

A year clicked under the view behaves the same way: the export reads $543,000,000 "[PB27 LOCKED]". Every workbook is
well-formed.

This contradicts cycView's own comment, "nothing edited can LOOK kept". The status line after the export does begin
"🔒 Not kept — PB27 is a locked view", but the workbook carries nothing to that effect.

Minimal fix direction, not built (it is outside U34's finding): have `cycReapply` also put back the view's MS-level
funds-flow settings from the stash, for example `if(_cycStash) MS.flow=JSON.parse(JSON.stringify(_cycStash.MS.flow||{}));`.
Better still, rebuild every MS-level field except `years` from the stash. Test with P4's literals: after the refused edit,
expect $500,000,000 in the calculation and the export, International Partners 0, and an empty partner-money store
(`other` `{}`) after leaving.

I propose a new ledger row, U-new-viewflow: money; an export of a figure the board says it did not keep; a P1/P2
candidate for the lead. The LOCKED-IX interaction track may own it.

**SF2. Drafts: the locked-cycle view is now measured.** `NEXT-VERSION-U34.md` "Not covered" ends "Not covered either: a
locked-cycle view; …", and the ledger limits say "jsdom only". I propose this replacement for the locked-view half:

> A locked-cycle view reads the working plan's saved year selection, so a malformed one is said there as well, and the
> view's export carries the NOTE (money verifier round 3, P3 VIEW-*, jsdom). A click on the year buttons under the view
> is refused ("the change was not kept"), and the plan keeps the saved value; leaving the view brings the notice back,
> and Save writes the saved value. Until the view is left, its own panel and export show the clicked selection, as they
> do for every funds-flow setting changed under a view (ledger U-new-viewflow).

Optionally, add to the Test/evidence text: "The 14 `v200-u14-*` catalog mutants and `v199-flow-export-lastyear`, applied
to the U34 board, are each still caught (money verifier round 3)."

### Minor

- **m1.** A text entry equal to a year beside that year (`["2027",2027]`) reads: 'The saved year selection holds "2027",
  which this board cannot read as a year. It is kept as saved and not counted: this total counts FY27 only.' This is
  true, because the quote marks name the text and FY27 is counted ($500M). But it can read as a contradiction. No change
  is needed. If the builder wants, the drafts' 'Not covered' could say that a year written as text beside the same year
  is said, and the year is counted once.
- **m2.** U14's year printing also covers numbers the drafts do not list. `[1e21,2027]` prints "FY0" on the panel and in
  the label and "FY1e+21" in the NOTE, and is saved back as `[1e+21,2027]`. The base does the same. This falls under
  "a whole number that is no plausible year", and the list there could add 1e21.
- **m3.** The builder's README § 2, principle 1, still says the value is kept "byte for byte". The drafts were corrected
  to "the same value, not the same bytes". The README is not shipped.
- **m4.** At opening, a newer copy in this browser wins over the file and is said ("Opened with this browser's copy …
  Save writes them into the file"). This is identical on the base and c3, and it is not U34's.
- **m5.** I did not re-run full audit-recon, npm run check or the other suites. The board blob equals c2's, which both
  round-2 verifiers ran, and the builder ran audit-recon on c3 (345, ALL CHECKS PASSED). See § 9.

## 5. Every run (start ET, exit, wall seconds, log)

Start times are ET (24-hour, 13 Oct). Every node run was bounded by `setsid -w timeout -k 10 600` (run.sh) and checked the AUDIT_IMPORT_RUNNING lock first. `logs/runs.txt` is the record; `logs/chunks.txt` has each chunk's end. Text-only checks: mcount (2:52 PM ET, exit 0, `out/mcount.txt`): c3 catalog on c3 1,361/1,361 once; base catalog on c3 1,328/1,328; c3 catalog on base 1,330 once, 31 missing (U34's own); base on base 1,328/1,328. xmlcheck (expat) on P3's 24 and P4's 8 workbooks: all WELL-FORMED. The superseded first queue (2:58 PM ET, setup failure) is in `logs/failed-setup/`.

| label | start ET | exit | wall s | log | result |
|---|---|---|---|---|---|
| UM-v199-flow-export-lastyear | 14:59:22 | 1 | 297.2 | logs/UM-v199-flow-export-lastyear.log | 56 failing (U14 22, U34 34) |
| P3-probe-on-base | 15:04:50 | 0 | 80.0 | logs/P3-probe-on-base.log | probe done, 15 OBS lines |
| P3-probe-on-c3 | 15:04:50 | 0 | 81.8 | logs/P3-probe-on-c3.log | probe done, 15 OBS lines |
| F1-focused-on-c3 | 15:06:10 | 0 | 401.3 | logs/F1-focused-on-c3.log | ALL CHECKS PASSED |
| F1-focused-on-base | 15:06:12 | 1 | 405.3 | logs/F1-focused-on-base.log | 28 failing (U14 0, U34 28) |
| UM-v200-u14-stored-unoffered | 15:12:57 | 137 | 232.1 | logs/UM-v200-u14-stored-unoffered.log | OOM-killed by the memory cgroup (shared machine); killed before the summary; re-run below |
| UM-v200-u14-saved-falls-back | 15:12:57 | 1 | 319.0 | logs/UM-v200-u14-saved-falls-back.log | 28 failing (U14 7, U34 21) |
| UM-v200-u14-export-notice-dropped | 15:16:49 | 1 | 274.3 | logs/UM-v200-u14-export-notice-dropped.log | 6 failing (U14 5, U34 1) |
| UM-v200-u14-read-makes-year | 15:21:37 | 1 | 358.0 | logs/UM-v200-u14-read-makes-year.log | 27 failing (U14 27, U34 0) |
| UM-v200-u14-label-dash-gap | 15:21:37 | 1 | 364.0 | logs/UM-v200-u14-label-dash-gap.log | 4 failing (U14 2, U34 2) |
| UM-v200-u14-toggle-collapses | 15:27:42 | 137 | 259.7 | logs/UM-v200-u14-toggle-collapses.log | OOM-killed by the memory cgroup (shared machine); killed before the summary; re-run below |
| UM-v200-u14-toggle-drops-saved | 15:27:42 | 1 | 316.3 | logs/UM-v200-u14-toggle-drops-saved.log | 7 failing (U14 7, U34 0) |
| UM-v200-u14-panel-notice-dropped | 15:32:58 | 137 | 205.7 | logs/UM-v200-u14-panel-notice-dropped.log | OOM-killed by the memory cgroup (shared machine); killed before the summary; re-run below |
| UM-v200-u14-read-writes-marks | 15:32:58 | 1 | 256.3 | logs/UM-v200-u14-read-writes-marks.log | 8 failing (U14 8, U34 0) |
| UM-v200-u14-chips-unlit-beside-unavailable | 15:37:15 | 137 | 215.9 | logs/UM-v200-u14-chips-unlit-beside-unavailable.log | OOM-killed by the memory cgroup (shared machine); killed before the summary; re-run below |
| UM-v200-u14-toggle-off-drops-saved | 15:37:15 | 137 | 243.3 | logs/UM-v200-u14-toggle-off-drops-saved.log | OOM-killed by the memory cgroup (shared machine); killed before the summary; re-run below |
| UM-v200-u14-only-keeps-saved | 15:41:18 | 137 | 207.0 | logs/UM-v200-u14-only-keeps-saved.log | OOM-killed by the memory cgroup (shared machine); killed before the summary; re-run below |
| UM-v200-u14-allyears-keeps-saved | 15:41:18 | 137 | 207.9 | logs/UM-v200-u14-allyears-keeps-saved.log | OOM-killed by the memory cgroup (shared machine); killed before the summary; re-run below |
| P4-view-edit-on-c3 | 15:44:46 | 0 | 16.0 | logs/P4-view-edit-on-c3.log | probe done, 2 OBS lines |
| P4-view-edit-on-base | 15:45:02 | 0 | 16.7 | logs/P4-view-edit-on-base.log | probe done, 2 OBS lines |
| UM-v200-u14-notice-plural-it | 15:44:46 | 1 | 195.7 | logs/UM-v200-u14-notice-plural-it.log | 2 failing (U14 2, U34 0) |
| UR-v200-u14-stored-unoffered | 15:48:02 | 1 | 91.9 | logs/UR-v200-u14-stored-unoffered.log | 15 failing (U14 15, U34 0) |
| UR-v200-u14-toggle-collapses | 15:49:34 | 1 | 86.3 | logs/UR-v200-u14-toggle-collapses.log | 3 failing (U14 3, U34 0) |
| UR-v200-u14-panel-notice-dropped | 15:51:01 | 1 | 102.9 | logs/UR-v200-u14-panel-notice-dropped.log | 7 failing (U14 7, U34 0) |
| UR-v200-u14-chips-unlit-beside-unavailable | 15:52:44 | 1 | 101.3 | logs/UR-v200-u14-chips-unlit-beside-unavailable.log | 1 failing (U14 1, U34 0) |
| UR-v200-u14-toggle-off-drops-saved | 15:54:25 | 1 | 130.2 | logs/UR-v200-u14-toggle-off-drops-saved.log | 2 failing (U14 2, U34 0) |
| UR-v200-u14-only-keeps-saved | 15:56:36 | 1 | 103.7 | logs/UR-v200-u14-only-keeps-saved.log | 1 failing (U14 1, U34 0) |
| UR-v200-u14-allyears-keeps-saved | 15:58:19 | 1 | 88.4 | logs/UR-v200-u14-allyears-keeps-saved.log | 1 failing (U14 1, U34 0) |
| F2-u14only-on-c3 | 15:59:48 | 0 | 98.5 | logs/F2-u14only-on-c3.log | ALL CHECKS PASSED |

F1 against the builder's FR4 (`fr2/out/FR4-focused-on-*.checks.jsonl`): 102 shared checks, 0 differing in verdict or value, on c3 and on the base.

## 6. PIDs

Every PID is in `pids.txt`, with its command and the time it was recorded:
- each run's `timeout` PID and its `node` child (written by `run.sh`);
- each chunk's `timeout` around `q.sh` (written by `chunks.sh`);
- each driver shell.

| PID | recorded (ET) | what |
|---|---|---|
| 22258 | 14:58:15 EDT | bash-chunks-driver :: |
| 22264 | 14:58:15 EDT | timeout-q.sh chunk |
| 22280 | 14:58:16 EDT | timeout P3-probe-on-c3 |
| 22283 | 14:58:16 EDT | timeout P3-probe-on-base |
| 22282 | 14:58:16 EDT | node P3-probe-on-c3 |
| 22292 | 14:58:16 EDT | node P3-probe-on-base |
| 22356 | 14:58:18 EDT | timeout F1-focused-on-c3 |
| 22358 | 14:58:18 EDT | node F1-focused-on-c3 |
| 22382 | 14:58:19 EDT | timeout F1-focused-on-base |
| 22385 | 14:58:19 EDT | node F1-focused-on-base |
| 22493 | 14:58:22 EDT | timeout-q.sh chunk |
| 22506 | 14:58:22 EDT | timeout UM-v200-u14-saved-falls-back |
| 22508 | 14:58:22 EDT | node UM-v200-u14-saved-falls-back |
| 22513 | 14:58:22 EDT | timeout UM-v200-u14-stored-unoffered |
| 22520 | 14:58:23 EDT | node UM-v200-u14-stored-unoffered |
| 22615 | 14:58:25 EDT | timeout UM-v200-u14-export-notice-dropped |
| 22617 | 14:58:25 EDT | node UM-v200-u14-export-notice-dropped |
| 22641 | 14:58:26 EDT | timeout UM-v200-u14-label-dash-gap |
| 22643 | 14:58:26 EDT | node UM-v200-u14-label-dash-gap |
| 22764 | 14:58:29 EDT | timeout-q.sh chunk |
| 22778 | 14:58:29 EDT | timeout UM-v200-u14-toggle-drops-saved |
| 22783 | 14:58:29 EDT | timeout UM-v200-u14-read-makes-year |
| 22785 | 14:58:29 EDT | node UM-v200-u14-read-makes-year |
| 22782 | 14:58:29 EDT | node UM-v200-u14-toggle-drops-saved |
| 22848 | 14:58:32 EDT | timeout UM-v200-u14-toggle-collapses |
| 22850 | 14:58:32 EDT | node UM-v200-u14-toggle-collapses |
| 22874 | 14:58:33 EDT | timeout UM-v200-u14-panel-notice-dropped |
| 22877 | 14:58:33 EDT | node UM-v200-u14-panel-notice-dropped |
| 22990 | 14:58:37 EDT | timeout-q.sh chunk |
| 23021 | 14:58:37 EDT | timeout UM-v200-u14-chips-unlit-beside-unavailable |
| 23007 | 14:58:37 EDT | timeout UM-v200-u14-read-writes-marks |
| 23012 | 14:58:37 EDT | node UM-v200-u14-read-writes-marks |
| 23024 | 14:58:37 EDT | node UM-v200-u14-chips-unlit-beside-unavailable |
| 23292 | 14:58:53 EDT | timeout UM-v200-u14-toggle-off-drops-saved |
| 23294 | 14:58:53 EDT | node UM-v200-u14-toggle-off-drops-saved |
| 23345 | 14:58:53 EDT | timeout UM-v200-u14-only-keeps-saved |
| 23347 | 14:58:53 EDT | node UM-v200-u14-only-keeps-saved |
| 23700 | 14:59:13 EDT | timeout-q.sh chunk |
| 23736 | 14:59:15 EDT | timeout UM-v200-u14-notice-plural-it |
| 23725 | 14:59:15 EDT | timeout UM-v200-u14-allyears-keeps-saved |
| 23738 | 14:59:15 EDT | node UM-v200-u14-notice-plural-it |
| 23727 | 14:59:15 EDT | node UM-v200-u14-allyears-keeps-saved |
| 23938 | 14:59:23 EDT | timeout UM-v199-flow-export-lastyear |
| 23940 | 14:59:23 EDT | node UM-v199-flow-export-lastyear |
| 30679 | 15:04:49 EDT | bash-chunks-driver :: |
| 30690 | 15:04:50 EDT | timeout-q.sh chunk |
| 30709 | 15:04:50 EDT | timeout P3-probe-on-c3 |
| 30714 | 15:04:50 EDT | node P3-probe-on-c3 |
| 30725 | 15:04:50 EDT | timeout P3-probe-on-base |
| 30729 | 15:04:50 EDT | node P3-probe-on-base |
| 32471 | 15:06:10 EDT | timeout F1-focused-on-c3 |
| 32475 | 15:06:10 EDT | node F1-focused-on-c3 |
| 32596 | 15:06:12 EDT | timeout F1-focused-on-base |
| 32598 | 15:06:12 EDT | node F1-focused-on-base |
| 6070 | 15:12:57 EDT | timeout-q.sh chunk |
| 6079 | 15:12:57 EDT | timeout UM-v200-u14-stored-unoffered |
| 6087 | 15:12:57 EDT | timeout UM-v200-u14-saved-falls-back |
| 6083 | 15:12:57 EDT | node UM-v200-u14-stored-unoffered |
| 6090 | 15:12:57 EDT | node UM-v200-u14-saved-falls-back |
| 7804 | 15:14:27 EDT | bash-chunks-driver-2 :: |
| 10346 | 15:16:49 EDT | timeout UM-v200-u14-export-notice-dropped |
| 10349 | 15:16:49 EDT | node UM-v200-u14-export-notice-dropped |
| 16455 | 15:21:24 EDT | timeout-q.sh chunk |
| 16459 | 15:21:24 EDT | timeout-q.sh chunk |
| 16463 | 15:21:24 EDT | timeout-q.sh chunk |
| 16761 | 15:21:37 EDT | timeout-q.sh chunk |
| 16776 | 15:21:38 EDT | timeout UM-v200-u14-label-dash-gap |
| 16774 | 15:21:38 EDT | timeout UM-v200-u14-read-makes-year |
| 16778 | 15:21:38 EDT | node UM-v200-u14-label-dash-gap |
| 16779 | 15:21:38 EDT | node UM-v200-u14-read-makes-year |
| 22986 | 15:27:42 EDT | timeout-q.sh chunk |
| 23000 | 15:27:42 EDT | timeout UM-v200-u14-toggle-drops-saved |
| 22996 | 15:27:42 EDT | timeout UM-v200-u14-toggle-collapses |
| 22998 | 15:27:42 EDT | node UM-v200-u14-toggle-collapses |
| 23002 | 15:27:42 EDT | node UM-v200-u14-toggle-drops-saved |
| 27196 | 15:32:58 EDT | timeout-q.sh chunk |
| 27215 | 15:32:58 EDT | timeout UM-v200-u14-read-writes-marks |
| 27219 | 15:32:59 EDT | node UM-v200-u14-read-writes-marks |
| 27217 | 15:32:59 EDT | timeout UM-v200-u14-panel-notice-dropped |
| 27220 | 15:32:59 EDT | node UM-v200-u14-panel-notice-dropped |
| 32049 | 15:37:15 EDT | timeout-q.sh chunk |
| 32062 | 15:37:15 EDT | timeout UM-v200-u14-chips-unlit-beside-unavailable |
| 32064 | 15:37:15 EDT | node UM-v200-u14-chips-unlit-beside-unavailable |
| 32065 | 15:37:15 EDT | timeout UM-v200-u14-toggle-off-drops-saved |
| 32076 | 15:37:15 EDT | node UM-v200-u14-toggle-off-drops-saved |
| 2491 | 15:41:18 EDT | timeout-q.sh chunk |
| 2504 | 15:41:18 EDT | timeout UM-v200-u14-allyears-keeps-saved |
| 2502 | 15:41:18 EDT | timeout UM-v200-u14-only-keeps-saved |
| 2506 | 15:41:18 EDT | node UM-v200-u14-allyears-keeps-saved |
| 2507 | 15:41:19 EDT | node UM-v200-u14-only-keeps-saved |
| 6264 | 15:44:46 EDT | timeout-q.sh chunk |
| 6275 | 15:44:46 EDT | timeout UM-v200-u14-notice-plural-it |
| 6278 | 15:44:46 EDT | timeout P4-view-edit-on-c3 |
| 6277 | 15:44:46 EDT | node UM-v200-u14-notice-plural-it |
| 6280 | 15:44:46 EDT | node P4-view-edit-on-c3 |
| 6561 | 15:45:02 EDT | timeout P4-view-edit-on-base |
| 6563 | 15:45:02 EDT | node P4-view-edit-on-base |
| 7455 | 15:46:02 EDT | bash-chunks-driver-3 :: |
| 9969 | 15:48:02 EDT | timeout-q.sh chunk |
| 9976 | 15:48:02 EDT | timeout UR-v200-u14-stored-unoffered |
| 9979 | 15:48:03 EDT | node UR-v200-u14-stored-unoffered |
| 11338 | 15:49:34 EDT | timeout-q.sh chunk |
| 11345 | 15:49:34 EDT | timeout UR-v200-u14-toggle-collapses |
| 11354 | 15:49:35 EDT | node UR-v200-u14-toggle-collapses |
| 12913 | 15:51:01 EDT | timeout-q.sh chunk |
| 12925 | 15:51:01 EDT | timeout UR-v200-u14-panel-notice-dropped |
| 12927 | 15:51:01 EDT | node UR-v200-u14-panel-notice-dropped |
| 15028 | 15:52:44 EDT | timeout-q.sh chunk |
| 15035 | 15:52:44 EDT | timeout UR-v200-u14-chips-unlit-beside-unavailable |
| 15038 | 15:52:44 EDT | node UR-v200-u14-chips-unlit-beside-unavailable |
| 17635 | 15:54:25 EDT | timeout-q.sh chunk |
| 17642 | 15:54:26 EDT | timeout UR-v200-u14-toggle-off-drops-saved |
| 17645 | 15:54:26 EDT | node UR-v200-u14-toggle-off-drops-saved |
| 19641 | 15:56:36 EDT | timeout-q.sh chunk |
| 19648 | 15:56:36 EDT | timeout UR-v200-u14-only-keeps-saved |
| 19650 | 15:56:36 EDT | node UR-v200-u14-only-keeps-saved |
| 20860 | 15:58:19 EDT | timeout-q.sh chunk |
| 20867 | 15:58:20 EDT | timeout UR-v200-u14-allyears-keeps-saved |
| 20869 | 15:58:20 EDT | node UR-v200-u14-allyears-keeps-saved |
| 22446 | 15:59:48 EDT | timeout-q.sh chunk |
| 22456 | 15:59:48 EDT | timeout F2-u14only-on-c3 |
| 22459 | 15:59:48 EDT | node F2-u14only-on-c3 |

## 7. Blobs of my own files (git hash-object)

| file | blob |
|---|---|
| run.sh | 99bb8e8adc860765b0070b3167bcfb957c629ac9 |
| q.sh | 7e94519d931d539bb2b3b860cb8f90042aebbe2e |
| chunks.sh | 2fd023ab7d50c0c51e1683a57f6e25dc78762e43 |
| runner.mjs | f851f1391102e59aa12f0ca301b40bb4ddd005f3 |
| bin/entries.py | cf0a3b4a45f11da33a91590c6306b8f373703973 |
| bin/mkfocused-fr.py | b5ce8ce85ff71e80f8b37b1b9b18ab3052111b8d |
| bin/xmlcheck.py | 3e970bd1e8a408e43c0dc767efa2225b3cd66287 |
| bin/show.py | 024dd6426bba1b337380c72169348c5fe31ba833 |
| harness/c3/focused.mjs | 340e812f7c842dd371d398525afdedfcd241ae09 |
| harness/c3/focused-u14.mjs | d902982699a121b5714e8139f83f9d9e84a074e4 |
| harness/c3/r3probe.mjs | a33844d2843e8f8c2e61619eb1b5ae50d90c69cf |
| harness/c3/r3p4.mjs | 6be56c3ae52a7a81d1b4ba1bbd244d5ee789a86d |
| probe/r3probe-block.mjs.txt | c2a99602874871dbef413a19aa9a2feadb09f343 |
| probe/r3p4-block.mjs.txt | 1041eb58babc42cc3b1d9f07e36b8fe7e3835a3a |
| diffs/c3-board-vs-base.diff | 3c9bb6cfa756a257b531c37521c91e55d7e3be99 |
| diffs/c3-audit-recon-vs-base.diff | 036e4dac8e7127defb2c007dc83b51583a7613ec |
| diffs/c3-mutate-vs-base.diff | 9ab2018447aafc2101788496e01be0dbc0c62b32 |
| out/mcount.txt | b89cf1008cd14645544dc362ebd8a8a8bf2ace53 |
| out/xmlcheck-P3.txt | 69ca55d642fc709612db7da81af82ed1101bae18 |
| mut/v199-flow-export-lastyear.html | e9c6dbb0776cad4a656353c78aec57c49872452f |
| mut/v200-u14-allyears-keeps-saved.html | 460cf14c261b496e723bd12401e872ff700e9c65 |
| mut/v200-u14-chips-unlit-beside-unavailable.html | a0c6641f420f3a58a570e0a28c94c7d71415e989 |
| mut/v200-u14-export-notice-dropped.html | cdc94dccb7e79192e07a70b7c2fe248d5741f87a |
| mut/v200-u14-label-dash-gap.html | 7ee7294891366fce301e2490dfa6b462409f1b69 |
| mut/v200-u14-notice-plural-it.html | 3b646cbf1624b44dd775657ae5cb94d9c03e4513 |
| mut/v200-u14-only-keeps-saved.html | e1b3f4de9c3bb21d781b1c4b1469f942261c00a4 |
| mut/v200-u14-panel-notice-dropped.html | f660c4d35ac4a10d9f9948040e9297a64b6b9e0a |
| mut/v200-u14-read-makes-year.html | a61a2cc64c832d32e4268130162e0dc5c6bb9bac |
| mut/v200-u14-read-writes-marks.html | 2a349c376b505694dacc9528767434ce13606965 |
| mut/v200-u14-saved-falls-back.html | 178bcb16b356a7e5202af18c2ba23c92a5665721 |
| mut/v200-u14-stored-unoffered.html | 736c70862c89d0bded28db2a6c7aa78b3bf0b466 |
| mut/v200-u14-toggle-collapses.html | 03de4c413bd8c23aeadb47c93faf287084c68a04 |
| mut/v200-u14-toggle-drops-saved.html | aac74fa4a5e8fd9007d068bcfdc33a2b8b1b51b3 |
| mut/v200-u14-toggle-off-drops-saved.html | 05d41e789ad9420d3b0b7ebafa23314e82fe7471 |

## 8. Decisions, with reasons

- **No must-fix.** Every can't-fail I could reach measured clean on c3, and the earlier rounds' must-fixes are wording that
  the drafts now carry. I re-read every draft claim I could check against my own observations. These held: 1e999 as the
  whole value is ALL YEARS; NaN is U-new-nan; -0 is written back as 0; 2.027e3 is written back as 2027; a century-off
  year prints as that year (U-new-fy2); the 28 / 11 split; 39 checks; 33 mutations; 1,361 / 1,361.
- **SF1 is a should-fix, not a must-fix.** It is identical on the base: U34 neither causes it nor changes it. It sits in
  `cycReapply` and `cycView`, which U34 does not touch. It still matters for money and exports, so I wrote a repro, a fix
  direction and a ledger-row proposal rather than leaving it in a note.
- **The U14-only harness for the re-runs.** The two-block harness was OOM-killed seven times while two ran at once on the
  shared machine. Each of those seven had already recorded failing U14 checks before it was killed. I re-ran the seven
  one at a time with a harness holding only U14's block, verbatim (`focused-u14.mjs`, d9029826), so that each "caught"
  rests on U14's own checks. F2 is the control: the same harness on unmutated c3, 63/63.
- **Only base and c3 were probed**, not c1 or c2: c3's board is c2's.

## 9. What I did not do, and my deviations (said plainly)

- No commit, no push, and no edit in `/home/user/orbit-board` or `/home/user/orbit-ui`, which were only read. No edit to
  any builder file. Nothing was imported from or run of `mutate.mjs`: it was read as text only, by `mcount.py`, `mkmut.py`
  and `bin/entries.py` (which uses `mcread.py`).
- I did not run audit-import, audit-board, Chromium, playwright or verify:grid. I did not re-run full audit-recon (about
  430 s solo, longer under this load), npm run check, audit, audit-ppt, audit-other, audit-hostile, audit-inject,
  boot-same or legacy-fsrc. The builder and the round-2 verifiers ran them on this board blob.
- I did not re-run the builder's 33 U34 catalog mutants. The builder (FM3) and the round-2 verifiers ran them. My mutant
  runs were the 15 existing entries on the changed functions.
- I did not probe a shared-folder copy, a PMO copy, a batch import, Chromium, or the PNG image itself. jsdom has no
  canvas, so for the image I checked only the chart's aria-label and the label it prints.
- **Deviations.**
  1. **The first queue (2:58 PM ET) failed in setup.** The harness's `boot.mjs` was a plain copy, so jsdom did not
     resolve from it. 18 runs exited 1 within 2–20 s. Their logs are kept in `logs/failed-setup/` and superseded. I
     replaced the copy with a symlink to the copy's own `boot.mjs`, as the earlier rounds did.
  2. **UM-v199** started after that fix and ran properly. It is the one valid run of that queue. Its log was moved
     while it was running, so the `# end` line run.sh appends was lost. Its runs.txt record (exit 1, 297.2 s) and the
     runner's own `# exit 1 at 3:04:17 PM ET` line remain.
  3. **The driver loops (`chunks.sh` and its callers) had no 600 s bound of their own.** Each chunk's `q.sh` and each
     node run had one. I shrank later chunks to two runs, or one, so that no chunk would outrun its bound. One chunk
     (B-01) was cut to 3 runs mid-queue for that reason, and its third run finished inside the bound.
  4. **Seven node runs were OOM-killed** by the session's memory cgroup (exit 137, dmesg "Memory cgroup out of memory").
     Other processes on the machine, including other agents' Chromium, were killed in the same minutes. All seven were
     re-run one at a time (UR-*). I sent no signal to any process.
  5. **Short text tools ran without a PID record**: `show.py`, `entries.py`, the tally one-liners and `split`. mkmut,
     mcount and xmlcheck ran under `setsid -w timeout -k 10 600`.
- **PID reuse.** At 4:01:50 PM ET one PID from my list, 22385, was alive. It had been recorded at 2:58:19 PM ET for a
  failed-setup run that exited within 3 s, so it now belongs to another agent's node process, started about 2 minutes
  earlier. I did not touch it. None of my own runs was still running.
- The lock `AUDIT_IMPORT_RUNNING` was absent before every run (`run.sh` checks it). No run waited and none was skipped.
