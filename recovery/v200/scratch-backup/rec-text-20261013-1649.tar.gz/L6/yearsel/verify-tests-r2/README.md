# YEARSEL (U34) — independent verifier, round 2, LENS B (test adequacy and regressions)

Folder: `rec/L6/yearsel/verify-tests-r2` (this folder). Started fresh at 9:45 AM ET on 13 Oct: the folder did not exist, so
no earlier attempt of this review left work to reuse. Nothing here edits the builder's files; every copy, harness, mutant
and clone is my own. Nothing was committed or pushed; orbit-board and orbit-ui were only read (`git clone --shared` from
orbit-board into my own scratch clones, and `git log` / `git status`).

## Verdict: sound, with three test gaps to close (no must-fix)

- **Everything the builder reports reproduced exactly** on my own copies: the focused block (97 checks) on base / c1 / c2
  value for value (24 / 5 / 0 failing); all 27 catalog mutants caught with the same failing checks; audit-recon 306 base
  checks unchanged and 340 on c2 equal to the builder's run; audit-hostile, audit-other, audit, audit-ppt, audit-inject,
  legacy-fsrc and boot-same identical to the base; `npm run check` passes (size only differs); mcount 1,355 / 1,355 and
  every base entry once; the builder's probes (P4, VP, VA, VR, depth) identical. **No existing expectation changed.**
- **Five of my sixteen plausible wrong fixes survive all 97 checks** (section 4.2). One of them (`om-escape-first-only`)
  brings back round 1's MF1 -- a workbook that is not well-formed -- for an entry holding two such characters (expat,
  section 5). The others leave the 40-character cut's edge and the "no range" decision unpinned. Each is closed by a
  measured four-shape, four-entry addition (c3, section 6): its three new shapes fail on the base (its control passes there by design), all
  four pass on c2's board, and it catches all five.
- The c2 board itself measured right everywhere I looked. Minor points in 7.4.

## 1. What was reviewed (identities)

| copy (mine, `copies/` and `proposal/`) | board | audit-recon | mutate.mjs.txt |
|---|---|---|---|
| base = rec/L6/base (`7ee498a`, product `d66dd60`) | `fce8a391` | `529e36f7` | `cbc6defc` |
| c1 = builder's commit 1 | `a67635bb` | `98758fe5` | `bb57fce8` |
| **c2 = builder's commit 2 (the final copy)** | **`593593a4`** | **`5eac80ea`** | **`f4e0739f`** |
| c3 = c2 + my proposed test additions (section 6) | `593593a4` (unchanged) | `4f9fc5e2` | `bca91404` |

Every blob matches the builder's claims (`out/blobs-copies.txt`). `diff -rq` base→c2 and c1→c2: only these three files.
audit-import (`4aba2506`), audit-board (`a7c575e5`) and audit-other (`d89396b0`) are the base's in every copy.

Diffs (mine, `diffs/`; the bodies equal the builder's `diffs/c2-*-vs-base.diff` line for line):
- board base→c2 `+46 −9` (`diffs/c2-vs-base-prioritization-board-grid.html.diff`)
- audit-recon base→c2 `+234 −0` (`diffs/c2-vs-base-audit-recon.mjs.diff`): one new block after U14's end marker; **no
  existing line, check, fixture or expected value changed**
- mutate.mjs.txt base→c2 `+85 −0` (`diffs/c2-vs-base-mutate.mjs.txt.diff`): 27 entries before the R3 line, nothing else
- c3 vs c2: audit-recon `+10 −0`, mutate `+13 −0`, board unchanged (`diffs/c3-vs-c2-*.diff`)

## 2. Method

- Every node run went through `run.sh` (`setsid -w timeout -k 10 600`, own process group, the AUDIT_IMPORT_RUNNING lock
  check before start, a memory gate of 4.5 GB MemAvailable, PIDs to `pids.txt`, one line per run to `logs/runs.txt`).
  `queue.sh` runs a jobs file at most two at a time (the builder's three-at-once batch met the OOM killer); `chain*.sh`
  only wait for one queue to finish and start the next. Text helpers ran under `bx.sh` (same bound, PIDs recorded).
- Focused harness `harness/c2/focused.mjs` (`4de2c6da`), built by the builder's `mkfocused-fr.py` from my c2 suite: the
  suite's preamble, `w7Pkg`/`w7Ok`, the U14 and U34 blocks and the scenario-ran guard, VERBATIM. Its body is identical to
  the builder's `fr/harness/c2/focused-final.mjs` (`ecad9b0b`) but for the first comment line (the source path).
  `harness/c2/boot.mjs` links to my c2 copy's boot.mjs (node resolves the real path, so the default board is c2's).
- Check records (SUITE_CHECKS) compared by (scenario, where) → verdict and value with `bin/cmpchecks.py`.
- mutate.mjs was never imported or run: `mcount.py` and `mkmut.py` (text only, `python3 -I`).

## 3. The new checks: literals, and fail-before / pass-after

**Existing expectations.** audit-recon base→c2 is `+234 −0`, all inside the new `// ==== v2.00 (U34) ... ====` /
`// ==== end v2.00 (U34) ====` block placed after U14's end marker. mutate.mjs base→c2 is `+85 −0`. **No existing check,
fixture or expected value changed** (there is no file:line to list). U14's 63 checks pass unchanged on c2 (VF-focused-on-c2).

**House form.** The block has the async wrapper, `bootMark()` / `bootRelease(__bm, [X.w])` per shape / `bootRelease(__bm, [])`
and `await settleBoards()` at the end, the two-space `  const name = '...';` line, and both markers -- U14's form in the same file (this suite has
no `keepBoards`). One difference: U14 releases once, at the end; U34 also releases after every shape, keeping its base board
(`bootRelease(__bm, [X.w])`, the same helper), which bounds memory across 27 boots. I see no harm in it. Mutation ids are
`v200-yearsel-*`, entries `{ id, area, what, find, repl }`, inserted before the R3 line.

**Literals.** Every expected value in the 34 checks is built from hand-written literals (`want(...)`, `whole/one/by27`, the
label, notice and NOTE strings, the totals `T540/T500/T0`, `[2025, 2027, ...]`). Board helpers give observed values only.
A few expectations are relations rather than literals, which I record without calling them defects:
- each shape's `fileFys(h2) === J(JSON.parse(text))` and `r.stored === a.stored` are expected `true`: the saved file and
  the reopened board hold the same value as the input text (itself a literal) and as the first open (itself checked
  against a literal);
- "the export beside the NOTE" compares the [2027, "x"] sheet with the [2027] sheet row for row (`J(rest) === J(same)`
  expected `true`, and `a.length > 20` expected `true`). The [2027] sheet itself is not pinned here, so a change that broke
  both sheets the same way would pass this one check (other suites pin the funds-flow export).

**Fail before, pass after** (my runs, section 5): 34 new checks; **24 fail on the base**, all U34; the other **10 pass on
the base by design** -- the seven CONTROLs, the two click controls ("[2025, 2026.5], then FY27 switched on" and "\"2026\",
then ALL YEARS, then FY27's only") and "nothing asked". The hard rule says every new test must fail on the base; these 10
are controls, U14's block has the same kind, and the drafts say so. 5 fail on c1 alone; all 34 pass on c2.

## 4. Mutations

### 4.1 The builder's 27 catalog entries, re-made and re-run (all caught, the same failing checks as the builder's FM2)

Each mutant board was re-made from my c2 copy's `mutate.mjs.txt` with `rec/bin/mkmut.py` (text only); **all 27 are byte-identical**
to the builder's `fr/mut2/*.html` (blobs in `out/blobs-mutants.txt`). Each ran the focused harness (97 checks) with BOARD set to it.
**27/27 caught (exit 1); for every one the failing set equals the builder's FM2 run of the same id; U14's 63 pass in all 27** (`out/BM-tally.txt`).

| id | start (ET) | exit | wall | failing |
|---|---|---|---|---|
| `v200-yearsel-not-a-list-all-years` | 10:08:17 | 1 | 108.8 s | 8 |
| `v200-yearsel-nothing-read-all-years` | 10:08:51 | 1 | 107.5 s | 15 |
| `v200-yearsel-number-coerced` | 10:10:08 | 1 | 102.5 s | 3 |
| `v200-yearsel-fraction-unsaid` | 10:10:39 | 1 | 103.3 s | 2 |
| `v200-yearsel-whole-unsaid` | 10:11:52 | 1 | 123.8 s | 8 |
| `v200-yearsel-label-unsaid` | 10:12:23 | 1 | 118.0 s | 20 |
| `v200-yearsel-panel-unsaid` | 10:13:58 | 1 | 106.9 s | 21 |
| `v200-yearsel-export-unsaid` | 10:14:23 | 1 | 100.0 s | 22 |
| `v200-yearsel-markup-unescaped` | 10:15:46 | 1 | 79.7 s | 2 |
| `v200-yearsel-counted-unsaid` | 10:16:05 | 1 | 81.1 s | 5 |
| `v200-yearsel-plural-it` | 10:17:06 | 1 | 87.1 s | 1 |
| `v200-yearsel-toggle-from-all` | 10:17:28 | 1 | 88.9 s | 1 |
| `v200-yearsel-quote-xml-unsafe` | 10:18:35 | 1 | 97.4 s | 2 |
| `v200-yearsel-quote-splits-char` | 10:18:57 | 1 | 96.8 s | 1 |
| `v200-yearsel-quote-uncut` | 10:20:14 | 1 | 83.7 s | 2 |
| `v200-yearsel-falsy-all-years` | 10:20:36 | 1 | 81.7 s | 3 |
| `v200-yearsel-falsy-unsaid` | 10:21:40 | 1 | 70.7 s | 3 |
| `v200-yearsel-allyears-lit-unread` | 10:21:59 | 1 | 63.9 s | 1 |
| `v200-yearsel-label-all-years-unread` | 10:22:52 | 1 | 56.9 s | 1 |
| `v200-yearsel-label-ur-unpassed` | 10:23:05 | 1 | 55.5 s | 1 |
| `v200-yearsel-year-chips-unlit-unread` | 10:23:51 | 1 | 50.7 s | 1 |
| `v200-yearsel-note-replaces-line` | 10:24:01 | 1 | 50.6 s | 1 |
| `v200-yearsel-note-order` | 10:24:44 | 1 | 47.6 s | 1 |
| `v200-yearsel-label-unsaid-beside-u14` | 10:24:54 | 1 | 47.8 s | 1 |
| `v200-yearsel-panel-unsaid-beside-u14` | 10:25:34 | 1 | 42.4 s | 1 |
| `v200-yearsel-year-range` | 10:25:44 | 1 | 42.0 s | 1 |
| `v200-yearsel-plural-label` | 10:26:19 | 1 | 37.6 s | 1 |

### 4.2 My own mutants of c2: sixteen plausible wrong fixes (`bin/om.py`, `mut/om/om.json`)

Each is one exact-once text replacement on the c2 board, run through the focused harness (97 checks). The last column is my
four-shape supplement block alone (section 6), run on every one of them.

| mutant | the plausible wrong fix | start (ET), exit, wall | the 97 checks | the supplement alone |
|---|---|---|---|---|
| `om-chips-lit-precedence` | precedence slip: every year button is lit whenever an entry cannot be read | 09:53:54, 1, 99.1 s | caught, 19 failing: a string; an object; a bare number; an empty list; a year as text; not a whole number; null in the list; true in the list; one whole year, one not; text that is markup; an enormous list; an empty string; zero; false; a long entry; U+FFFF in an entry; U+FFFE as the whole value; 45 emoji in an entry; beside a year U14 says | caught: two characters XML forbids in one entry; a quote of exactly 40 characters; a quote of 41 characters |
| `om-clean-on-read` | DATA LOSS: what cannot be read is cleaned out of the saved selection when it is read | 09:53:58, 1, 102.9 s | caught, 12 failing: a year as text; not a whole number; null in the list; true in the list; one whole year, one not; text that is markup; an enormous list; a long entry; U+FFFF in an entry; 45 emoji in an entry; beside a year U14 says; every offered year beside an entry it cannot read | caught: two characters XML forbids in one entry; a quote of exactly 40 characters; a quote of 41 characters |
| `om-cut-ge40` | the quote is cut at 40 or more: a quote of exactly 40 characters gets a "…" though nothing follows | 09:55:35, 0, 99.0 s | **SURVIVED (97/97 pass)** | caught: a quote of exactly 40 characters |
| `om-cut-gt41` | the quote is cut only above 41: a 41-character quote is shown whole, not cut at 40 | 09:55:42, 0, 104.3 s | **SURVIVED (97/97 pass)** | caught: a quote of 41 characters |
| `om-dedupe-dropped` | duplicates are no longer read once | 09:57:16, 1, 139.7 s | caught, 2 failing: CONTROL — duplicates; CONTROL — an enormous list of one year | passes (no supplement shape touches it) |
| `om-empty-list-unsaid` | an empty list is read as no year but not said | 09:57:27, 1, 108.1 s | caught, 1 failing: an empty list | passes (no supplement shape touches it) |
| `om-escape-first-only` | only the FIRST U+FFFE/U+FFFF in a quote is escaped (no g flag): a second one goes raw into the export | 09:59:16, 0, 112.1 s | **SURVIVED (97/97 pass)** | caught: two characters XML forbids in one entry |
| `om-finite-not-integer` | a year is any finite number: 2026.5 is a year | 09:59:38, 1, 108.7 s | caught, 3 failing: not a whole number; one whole year, one not; [2025, 2026.5], then FY27 switched on | passes (no supplement shape touches it) |
| `om-label-counts-all-entries` | the label counts every saved entry, not the ones it cannot read | 10:01:10, 1, 113.7 s | caught, 6 failing: one whole year, one not; text that is markup; U+FFFF in an entry; 45 emoji in an entry; beside a year U14 says; every offered year beside an entry it cannot read | caught: two characters XML forbids in one entry |
| `om-note-above-scope` | the U34 NOTE is put above the Scope line instead of under it | 10:01:29, 1, 115.1 s | caught, 22 failing: a string; an object; a bare number; an empty list; a year as text; not a whole number; null in the list; true in the list; one whole year, one not; text that is markup; an enormous list; an empty string; zero; false; a long entry; U+FFFF in an entry; U+FFFE as the whole value; 45 emoji in an entry; beside a year U14 says; every offered year beside an entry it cannot read; beside a year U14 says · the NOTEs in order; the export beside the NOTE | caught: two characters XML forbids in one entry; a quote of exactly 40 characters; a quote of 41 characters |
| `om-null-entry-harmless` | a null entry (NaN as a file writes it) is skipped as harmless and not said | 10:03:06, 1, 103.6 s | caught, 1 failing: null in the list | passes (no supplement shape touches it) |
| `om-only-when-none-readable` | an entry is said only when no entry can be read: [2025, 2026.5] counts FY25 with nothing said | 10:03:25, 1, 113.6 s | caught, 9 failing: one whole year, one not; text that is markup; U+FFFF in an entry; 45 emoji in an entry; beside a year U14 says; every offered year beside an entry it cannot read; beside a year U14 says · the NOTEs in order; the export beside the NOTE; text that is markup · escaped | caught: two characters XML forbids in one entry |
| `om-quote-strip` | U+FFFE/U+FFFF are dropped from the quote instead of quoted as their escape | 10:04:51, 1, 97.2 s | caught, 2 failing: U+FFFF in an entry; U+FFFE as the whole value | caught: two characters XML forbids in one entry |
| `om-slice-79` | only 79 units are read before the split: a 45-emoji entry is quoted without its "…" | 10:05:22, 1, 94.1 s | caught, 1 failing: 45 emoji in an entry | passes (no supplement shape touches it) |
| `om-year-4digit` | a year must have four digits (1000-9999): a range read into "a year" | 10:06:29, 0, 105.7 s | **SURVIVED (97/97 pass)** | caught: CONTROL — a whole number no year could be |
| `om-year-positive` | a year must be above 0: [0] and [-5] are said as unreadable instead of U14 years | 10:06:58, 0, 111.8 s | **SURVIVED (97/97 pass)** | caught: CONTROL — a whole number no year could be |

**Five of my sixteen survive all 97 checks** (each exit 0): `om-escape-first-only`, `om-cut-ge40`, `om-cut-gt41`,
`om-year-4digit`, `om-year-positive`. The supplement catches each of the five by the check written for it, and passes on c2.

## 5. Every run the builder reports, re-run on my copies, and compared

| builder's run | my run (start ET, exit, wall) | compared | result |
|---|---|---|---|
| FR3-focused-on-c2 (exit 0, 97) | VF-focused-on-c2 (09:48:04, 0, 119.2 s) | check records by (scenario, where) | **97/97 pass; 97 common, 0 verdicts and 0 values differ** |
| FR3-focused-on-base (exit 1, 24 failing) | VF-focused-on-base (09:48:08, 1, 123.0 s) | same | **24 failing, all U34; 0 differ** (U14 63/63) |
| FR3-focused-on-c1 (exit 1, 5 failing) | VF-focused-on-c1 (09:50:04, 1, 125.9 s) | same | **5 failing** (an enormous list; U+FFFF in an entry; U+FFFE as the whole value; 45 emoji; every offered year beside an entry); **0 differ** |
| FM2-* × 27 (each exit 1) | BM-* × 27 (10:08:17–10:26:19, each exit 1, 37.6–123.8 s) | failing set per id | **27/27 caught, every failing set equal to the builder's; U14 0 failing in all** (`out/BM-tally.txt`) |
| FS2-audit-recon-c2 (exit 0, 340) | VS-audit-recon-c2 (10:29:08, 0, 100.6 s) and VS-audit-recon-base (10:29:12, 0, 76.0 s) | records | c2 **340/340 pass, equal to the builder's FS2 check for check**; base 306/306; **306 common, 0 differ**; 34 only in c2, all U34 |
| FS audit-hostile on c2 | VS-audit-hostile-c2 (10:30:29, 0, 45.9 s) / -base (10:30:51, 0, 49.4 s) | records | 124 / 124, **0 differ**; ALL CHECKS PASSED both |
| FS audit-other, audit, audit-ppt, audit-inject, legacy-fsrc, boot-same on c2 | VS-* on c2 and base (10:31:16–10:32:45, all exit 0; 27.6/32.7, 10.1/10.2, 5.0/5.1, 12.7/12.6, 3.7/3.6, 12.1/11.8 s) | whole log, times and paths masked | **0 differing lines** for each suite; ALL CHECKS PASSED / "computes exactly as before" / "identical either way" |
| FR-N3 / FR-N4 npm run check | VN-check-base (10:32:55, 0, 3.1 s) in `gc-base`, VN-check-c2 (10:32:59, 0, 3.7 s) in `gc-c2` (clones at `7ee498a`) | whole log, masked | the only differences: `31672 → 31709 lines`, `3.57 → 3.58 MB`, main script `29650 → 29687 lines` |
| mcount (text) | `out/mcount-*.txt` (09:5x, each exit 0) | counts | c2 catalog on c2 **1,355/1,355 once**; c1's on c2 1,340/1,340; base's on c2 **1,328/1,328** (every existing entry once); base on base 1,328/1,328; c2's on c1 1,347 (8 missing); c2's on base 1,329 (26 missing) -- all as the builder says |
| FR-P4-probe-on-c2 | RP-P4-probe-on-c2 (10:33:17, 0, 74.0 s) | OBS by label, timings out | **67/67 identical** |
| FR-VP-vprobe-on-c2 | RP-VP-vprobe-on-c2 (10:33:21, 0, 21.5 s) + expat | OBS; expat | **23/23 identical**; all 11 workbooks WELL-FORMED, the same list as the builder's `xmlcheck-vprobe-c2.txt` |
| FR-VA-aps-on-base / -c2 | RP-VA-aps-on-base (10:33:43, 0, 15.2 s) / -c2 (10:33:59, 0, 10.6 s) | OBS | 8/8 and 8/8 identical ($47M "all appropriations" for "om", [], ["xx"], {"0":"om"}; $40M for ["om"]) |
| FR-VR-rules-on-c2 / -base | RP-VR-rules-on-c2 (10:34:12, 0, 8.6 s) / -base (10:34:22, 0, 7.8 s) + expat | whole log, masked; expat | 0 differing lines; expat: rules.lm U+FFFF → sheet1 col 10493, category U+FFFF → workbook col 404 and sheet1 col 6582, on **both** boards; fys U+FFFF well-formed on both |
| FR-depth-on-base / -c2 | RP-depth-on-base (10:34:32, 0, 15.4 s) / -c2 (10:34:36, 0, 19.2 s) | every STEPS line | identical to the builder's line for line (see 7.4: the 4,154 boundary) |

Mine only:
- SUPP-* (supplement alone): on c2 (10:27:05, 0, 5.0 s) 5/5 pass; on the base (10:27:09, 1, 4.7 s) 3 fail (the three new
  shapes; the -2027 control passes); on c1 (10:27:13, 1, 5.7 s) 1 fails (two forbidden characters: c1 quoted them raw).
- FSUPP-focused-supp-on-c2 (10:27:17, 0, 77.0 s): U14 + U34 + supplement, **102/102 pass**, the 97 common identical to VF.
- RP-VP2 (my cut-down vprobe, five shapes, workbooks to expat): on c2 (10:34:50, 0, 11.8 s) all five WELL-FORMED; on the
  base (10:35:04, 0, 15.7 s) all five WELL-FORMED (the base never quotes the entry); on `om-escape-first-only`
  (10:34:57, 0, 15.8 s) **["\uffff\ufffe", 2027] → sheet1.xml "not well-formed (invalid token): line 1, column 1023",
  contains U+FFFE; "\uffff\uffff\uffff" → column 1009, contains U+FFFF**.
- C3F / C3M (the c3 proposal, section 6).

## 6. Proposed test additions (c3 = c2 + four shapes and four catalog entries; board unchanged)

For the lead to fold into the U34 commit (or a follow-up commit). Nothing in the board changes; the product in c2 is
already right on all four shapes. `proposal/c3/` is a cumulative copy (cp -a of my c2, node_modules link kept);
`diffs/c3-vs-c2-audit-recon.mjs.diff` (+10 −0) and `diffs/c3-vs-c2-mutate.mjs.txt.diff` (+13 −0) are in the appendix.

**Shapes added to the U34 block** (after "45 emoji in an entry", and the control after the FY1999 control), with a
two-line addition to the block's header comment. Every expected value is a hand-written literal, through the block's own
`by27` / `one` / `want` helpers:
1. `two characters XML forbids in one entry` -- `["\uffff\ufffe", 2027]`: FY27 counted ($500M), both quoted as their escape
   (`"\\uffff\\ufffe"`), the package reads (`w7Ok`), kept.
2. `a quote of exactly 40 characters` -- `[38 × "B"]`: quoted whole, no "…".
3. `a quote of 41 characters` -- `[39 × "C"]`: cut at 40, then "…".
4. `CONTROL — a whole number no year could be` -- `[-2027]`: U14's notice ("FY-27"), nothing counted, no U34 notice, kept.

**Catalog entries** (before the R3 line; each find once on c3/c2's board, mcount **1,359 / 1,359** once on c3; the base's
1,328 still once):
`v200-yearsel-quote-escape-first-only` (the escape's `/g` dropped), `v200-yearsel-quote-cut-at-40-or-more` (`>=40`),
`v200-yearsel-quote-cut-above-41` (`>41`), `v200-yearsel-year-four-digits` (`y>=1000 && y<=9999`). The mutant boards
mkmut.py makes from them are byte-identical to my `om-escape-first-only`, `om-cut-ge40`, `om-cut-gt41` and
`om-year-4digit`.

| run (harness `harness/c3/focused.mjs` `a580f2c6`, 101 checks) | start (ET) | exit | wall | result |
|---|---|---|---|---|
| C3F-on-c3 (board `593593a4`) | 10:35:27 | 0 | 207.4 s | **ALL CHECKS PASSED, 101**; the 97 shared with c2's harness identical in verdict and value |
| C3F-on-base (`fce8a391`) | 10:35:31 | 1 | 234.2 s | 27 failing = the 24 + the three new shapes; the -2027 control passes there by design; U14 63/63 |
| C3M-v200-yearsel-quote-escape-first-only | 10:43:51 | 1 | 241.1 s | caught: "two characters XML forbids in one entry" |
| C3M-v200-yearsel-quote-cut-at-40-or-more | 10:39:26 | 1 | 298.5 s | caught: "a quote of exactly 40 characters" |
| C3M-v200-yearsel-quote-cut-above-41 | 10:38:54 | 1 | 295.7 s | caught: "a quote of 41 characters" |
| C3M-v200-yearsel-year-four-digits | 10:44:25 | 1 | 232.6 s | caught: "CONTROL — a whole number no year could be" |

On c1 the new "two characters" shape also fails (SUPP-on-c1: c1 quoted them raw) and the other three pass, so with c3
commit 1 alone would fail 6 (5 in VF-on-c1 + 1 in SUPP-on-c1; not run as one harness).

**Draft text to change if c3 is taken** (`drafts/NEXT-VERSION-U34.md` and `drafts/LEDGER-U34-append.md`):
- Test: "(34 checks)" → "(38 checks)"; the shapes add "two characters XML forbids in one entry, a quote of exactly 40
  characters and one of 41"; "seven controls" → "eight controls", adding "and -2027 (a whole number no year could be is
  still a year: U14's notice)"; "24 checks fail ... the other 10 pass there by design (the seven controls, ...)" → "27
  checks fail ... the other 11 pass there by design (the eight controls, the two click controls and "nothing asked")".
- Mutations: add `-quote-escape-first-only`, `-quote-cut-at-40-or-more`, `-quote-cut-above-41`, `-year-four-digits`.
- Ledger: "34 checks. 24 fail ... 10 pass ... 5 fail on commit 1 alone" → "38 checks. 27 fail ... 11 pass ... 6 fail on
  commit 1 alone"; "Mutations: 27" → "31"; "1,355 / 1,355" → "1,359 / 1,359".
- Not covered (either way): "the FY1999 control pins that no range is read into 'a year'" is true only with the -2027
  control (without it, a 1000–9999 or a >0 range passes every check); the depth line, see 7.4.

## 7. Findings

### 7.1 Must-fix: none

Everything the builder reports reproduced exactly on my own copies (section 5): the 97 focused checks on base, c1 and c2
value for value; all 27 catalog mutants caught with the same failing checks; audit-recon's 306 base checks unchanged and
its 340 equal to the builder's run; every other suite and `npm run check` equal to the base but for the file's size; the
probes' observations identical. No existing check, fixture or expected value changed. I found no defect in the c2 board.

### 7.2 Should-fix (test gaps; each with a surviving mutant and a measured fix -- section 6)

- **SF1. The XML escape is pinned for one character per quote only.** Mutant `om-escape-first-only` (the escape's `/g`
  dropped: `.replace(/[\ufffe\uffff]/, ...)`) passes all 97 checks (OM-om-escape-first-only, 9:59:16 AM ET, exit 0) and
  brings back round 1's MF1: for a saved `["\uffff\ufffe", 2027]` the funds-flow export is not a well-formed workbook
  (RP-VP2-on-escfirst 10:34:57 AM ET; expat: sheet1.xml "not well-formed (invalid token): line 1, column 1023", contains
  U+FFFE; for `"\uffff\uffff\uffff"`, column 1009). c2 itself is right (RP-VP2-on-c2: both WELL-FORMED). Fix: shape 1 and
  `v200-yearsel-quote-escape-first-only` (C3M, exit 1).
- **SF2. The 40-character cut's edge is unpinned.** `om-cut-ge40` (a 40-character quote gets "…" though nothing
  follows) and `om-cut-gt41` (a 41-character quote shown whole, not cut at 40) both pass all 97 (9:55:35 / 9:55:42 AM ET,
  exit 0). Both make a word on the panel and in the export NOTE untrue (principle 4) and contradict the drafts' "each cut at
  40 characters". The block's long shapes (120 × "A", 45 emoji) are cut either way. Fix: shapes 2 and 3 and the two
  entries (C3M, exit 1 each).
- **SF3. "No range is read into 'a year'" is pinned against one range only.** The FY1999 control catches a 2000–2099
  range (the builder's `-year-range`), but `om-year-4digit` (1000–9999) and `om-year-positive` (> 0) pass all 97 (10:06:29 /
  10:06:58 AM ET, exit 0). The drafts say "the FY1999 control pins that no range is read into 'a year'". Fix: the -2027
  control and `v200-yearsel-year-four-digits` (C3M, exit 1); or, if not taken, reword the drafts to "pins that 1999 is read
  as a year".

### 7.3 My other eleven mutants were caught (section 4.2)

Including the DATA-LOSS one (`om-clean-on-read`, 12 failing), the money ones (`om-dedupe-dropped`: the duplicates and
5,000 × 2027 controls; `om-finite-not-integer`, `om-null-entry-harmless`, `om-only-when-none-readable`), the export's
place (`om-note-above-scope`, 22 failing) and the quote's read length (`om-slice-79`, by the 45-emoji shape).

### 7.4 Minor

- **The depth limit is not exact.** The drafts say "nested 4,155 lists deep or more stops the board opening". In the
  builder's FR-depth logs and in mine (identical line for line), the THRESHOLD search had 4,154 opening, but the STEPS boot
  at 4,154 failed to open on both boards ("Maximum call stack size exceeded" at boot; `failedAt: "opened"`). Say "about
  4,150 lists deep or more (in jsdom 4,154 opened in one boot and not in the next)".
- **10 of the 34 new checks pass on the base by design** (seven controls, two click controls, "nothing asked"). This
  departs from the letter of "every new test must fail on the base"; the drafts say it, and U14's block has the same kind.
- **"The export beside the NOTE" is relational**: it compares [2027, "x"]'s sheet with [2027]'s (expected `true`) and
  checks `a.length > 20`; the [2027] sheet itself is not pinned by literals in this block.
- The builder's "65 of 67 probe observations identical between c1 and c2" compares its P3 on c1 with P4 on c2; I re-ran
  P4 on c2 only (67/67 identical to the builder's P4), not P3 on c1.

## 8. Every run (start ET, exit, wall seconds, log)

From `logs/runs.txt` (one line per `run.sh` call). Logs are `logs/<label>.log`. Exit 1 on a base, c1 or mutant run is the
expected failure. No run waited for or was skipped by the AUDIT_IMPORT_RUNNING lock (no "waiting" or "SKIPPED" line), and none
timed out or was killed (no exit 124/137).

| label | start (ET, 13 Oct) | exit | wall s |
|---|---|---|---|
| VF-focused-on-c2 | 09:48:04 | 0 | 119.2 |
| VF-focused-on-base | 09:48:08 | 1 | 123.0 |
| VF-focused-on-c1 | 09:50:04 | 1 | 125.9 |
| (jobs1.txt done 09:52:10 EDT) | | | |
| OM-om-chips-lit-precedence | 09:53:54 | 1 | 99.1 |
| OM-om-clean-on-read | 09:53:58 | 1 | 102.9 |
| OM-om-cut-ge40 | 09:55:35 | 0 | 99.0 |
| OM-om-cut-gt41 | 09:55:42 | 0 | 104.3 |
| OM-om-empty-list-unsaid | 09:57:27 | 1 | 108.1 |
| OM-om-dedupe-dropped | 09:57:16 | 1 | 139.7 |
| OM-om-escape-first-only | 09:59:16 | 0 | 112.1 |
| OM-om-finite-not-integer | 09:59:38 | 1 | 108.7 |
| OM-om-label-counts-all-entries | 10:01:10 | 1 | 113.7 |
| OM-om-note-above-scope | 10:01:29 | 1 | 115.1 |
| OM-om-null-entry-harmless | 10:03:06 | 1 | 103.6 |
| OM-om-only-when-none-readable | 10:03:25 | 1 | 113.6 |
| OM-om-quote-strip | 10:04:51 | 1 | 97.2 |
| OM-om-slice-79 | 10:05:22 | 1 | 94.1 |
| OM-om-year-4digit | 10:06:29 | 0 | 105.7 |
| OM-om-year-positive | 10:06:58 | 0 | 111.8 |
| BM-v200-yearsel-not-a-list-all-years | 10:08:17 | 1 | 108.8 |
| BM-v200-yearsel-nothing-read-all-years | 10:08:51 | 1 | 107.5 |
| BM-v200-yearsel-number-coerced | 10:10:08 | 1 | 102.5 |
| BM-v200-yearsel-fraction-unsaid | 10:10:39 | 1 | 103.3 |
| BM-v200-yearsel-whole-unsaid | 10:11:52 | 1 | 123.8 |
| BM-v200-yearsel-label-unsaid | 10:12:23 | 1 | 118.0 |
| BM-v200-yearsel-panel-unsaid | 10:13:58 | 1 | 106.9 |
| BM-v200-yearsel-export-unsaid | 10:14:23 | 1 | 100.0 |
| BM-v200-yearsel-markup-unescaped | 10:15:46 | 1 | 79.7 |
| BM-v200-yearsel-counted-unsaid | 10:16:05 | 1 | 81.1 |
| BM-v200-yearsel-plural-it | 10:17:06 | 1 | 87.1 |
| BM-v200-yearsel-toggle-from-all | 10:17:28 | 1 | 88.9 |
| BM-v200-yearsel-quote-xml-unsafe | 10:18:35 | 1 | 97.4 |
| BM-v200-yearsel-quote-splits-char | 10:18:57 | 1 | 96.8 |
| BM-v200-yearsel-quote-uncut | 10:20:14 | 1 | 83.7 |
| BM-v200-yearsel-falsy-all-years | 10:20:36 | 1 | 81.7 |
| BM-v200-yearsel-falsy-unsaid | 10:21:40 | 1 | 70.7 |
| BM-v200-yearsel-allyears-lit-unread | 10:21:59 | 1 | 63.9 |
| BM-v200-yearsel-label-all-years-unread | 10:22:52 | 1 | 56.9 |
| BM-v200-yearsel-label-ur-unpassed | 10:23:05 | 1 | 55.5 |
| BM-v200-yearsel-year-chips-unlit-unread | 10:23:51 | 1 | 50.7 |
| BM-v200-yearsel-note-replaces-line | 10:24:01 | 1 | 50.6 |
| BM-v200-yearsel-note-order | 10:24:44 | 1 | 47.6 |
| BM-v200-yearsel-label-unsaid-beside-u14 | 10:24:54 | 1 | 47.8 |
| BM-v200-yearsel-panel-unsaid-beside-u14 | 10:25:34 | 1 | 42.4 |
| BM-v200-yearsel-year-range | 10:25:44 | 1 | 42.0 |
| BM-v200-yearsel-plural-label | 10:26:19 | 1 | 37.6 |
| (jobs2.txt done 10:26:56 EDT) | | | |
| SUPP-on-c2 | 10:27:05 | 0 | 5.0 |
| SUPP-on-base | 10:27:09 | 1 | 4.7 |
| SUPP-on-c1 | 10:27:13 | 1 | 5.7 |
| SUPPM-om-chips-lit-precedence | 10:27:21 | 1 | 8.6 |
| SUPPM-om-clean-on-read | 10:27:31 | 1 | 5.2 |
| SUPPM-om-cut-ge40 | 10:27:38 | 1 | 6.2 |
| SUPPM-om-cut-gt41 | 10:27:46 | 1 | 7.9 |
| SUPPM-om-dedupe-dropped | 10:27:56 | 0 | 13.5 |
| SUPPM-om-empty-list-unsaid | 10:28:12 | 0 | 7.7 |
| SUPPM-om-escape-first-only | 10:28:22 | 1 | 8.6 |
| FSUPP-focused-supp-on-c2 | 10:27:17 | 0 | 77.0 |
| SUPPM-om-finite-not-integer | 10:28:32 | 0 | 7.4 |
| SUPPM-om-label-counts-all-entries | 10:28:36 | 1 | 6.2 |
| SUPPM-om-note-above-scope | 10:28:40 | 1 | 4.6 |
| SUPPM-om-null-entry-harmless | 10:28:44 | 0 | 4.0 |
| SUPPM-om-only-when-none-readable | 10:28:48 | 1 | 4.2 |
| SUPPM-om-quote-strip | 10:28:52 | 1 | 4.4 |
| SUPPM-om-slice-79 | 10:28:56 | 0 | 4.6 |
| SUPPM-om-year-4digit | 10:29:00 | 1 | 4.8 |
| SUPPM-om-year-positive | 10:29:04 | 1 | 4.7 |
| (jobs3.txt done 10:29:08 EDT) | | | |
| VS-audit-recon-base | 10:29:12 | 0 | 76.0 |
| VS-audit-recon-c2 | 10:29:08 | 0 | 100.6 |
| VS-audit-hostile-c2 | 10:30:29 | 0 | 45.9 |
| VS-audit-hostile-base | 10:30:51 | 0 | 49.4 |
| VS-audit-other-c2 | 10:31:16 | 0 | 27.6 |
| VS-audit-c2 | 10:31:45 | 0 | 10.1 |
| VS-audit-base | 10:31:58 | 0 | 10.2 |
| VS-audit-other-base | 10:31:41 | 0 | 32.7 |
| VS-audit-ppt-c2 | 10:32:11 | 0 | 5.0 |
| VS-audit-ppt-base | 10:32:15 | 0 | 5.1 |
| VS-audit-inject-c2 | 10:32:19 | 0 | 12.7 |
| VS-audit-inject-base | 10:32:23 | 0 | 12.6 |
| VS-legacy-fsrc-c2 | 10:32:33 | 0 | 3.7 |
| VS-legacy-fsrc-base | 10:32:37 | 0 | 3.6 |
| VS-boot-same-c2 | 10:32:41 | 0 | 12.1 |
| VS-boot-same-base | 10:32:45 | 0 | 11.8 |
| VN-check-base | 10:32:55 | 0 | 3.1 |
| VN-check-c2 | 10:32:59 | 0 | 3.7 |
| (jobs4.txt done 10:33:03 EDT) | | | |
| RP-VP-vprobe-on-c2 | 10:33:21 | 0 | 21.5 |
| RP-VA-aps-on-base | 10:33:43 | 0 | 15.2 |
| RP-VA-aps-on-c2 | 10:33:59 | 0 | 10.6 |
| RP-VR-rules-on-c2 | 10:34:12 | 0 | 8.6 |
| RP-VR-rules-on-base | 10:34:22 | 0 | 7.8 |
| RP-P4-probe-on-c2 | 10:33:17 | 0 | 74.0 |
| RP-depth-on-base | 10:34:32 | 0 | 15.4 |
| RP-depth-on-c2 | 10:34:36 | 0 | 19.2 |
| RP-VP2-on-c2 | 10:34:50 | 0 | 11.8 |
| RP-VP2-on-escfirst | 10:34:57 | 0 | 15.8 |
| RP-VP2-on-base | 10:35:04 | 0 | 15.7 |
| (jobs5.txt done 10:35:19 EDT) | | | |
| C3F-on-c3 | 10:35:27 | 0 | 207.4 |
| C3F-on-base | 10:35:31 | 1 | 234.2 |
| C3M-v200-yearsel-quote-cut-above-41 | 10:38:54 | 1 | 295.7 |
| C3M-v200-yearsel-quote-cut-at-40-or-more | 10:39:26 | 1 | 298.5 |
| C3M-v200-yearsel-quote-escape-first-only | 10:43:51 | 1 | 241.1 |
| C3M-v200-yearsel-year-four-digits | 10:44:25 | 1 | 232.6 |
| (jobs6.txt done 10:48:18 EDT) | | | |

101 runs. Text-only helpers (mkfocused, mkmut × 31, om.py, mksupp, mkc3, mcount × 8, xmlcheck × 3, clones) ran under `bx.sh`.

## 9. PIDs

`pids.txt`: 315 lines, 313 distinct PIDs -- each `run.sh` / `bx.sh` call's timeout PID and its child, with the command,
and the wrappers `queue.sh` (×6), `chain.sh`, `chain2.sh` and `chain3.sh` (they only wait). At 10:50 AM ET on 13 Oct none of the
313 was present in /proc. **I sent no signal to any process** (no kill of any kind), and touched no other track's process.

## 10. Blobs (git hash-object)

Copies: `out/blobs-copies.txt` (section 1 table). Mutant boards: `out/blobs-mutants.txt` (16 own, 27 builder's -- each equal
to the builder's `fr/mut2` blob -- and the 4 c3 ones, each equal to my matching own mutant). My tools, harnesses, jobs files,
diffs and README parts: `out/blobs-tools.txt`. Key ones:
- `harness/c2/focused.mjs` `4de2c6da` (body = the builder's `ecad9b0b` but line 1); `harness/c2/focused-supp.mjs` `d3a4bbc6`;
  `harness/c2/supp-only.mjs` `87501f4e`; `harness/c2/supp-block.mjs.txt` `75469c59`; `harness/c2/vprobe2.mjs` `936c382c`;
  `harness/c3/focused.mjs` `a580f2c6`; `runner.mjs` `f851f139` (the builder's, unchanged).
- c3: audit-recon `4f9fc5e2`, mutate.mjs.txt `bca91404`, board `593593a4` (= c2).

## 11. What I did not do, and my deviations (said plainly)

- I did not run the full audit-import or audit-board (the lead's), Chromium, playwright or verify:grid. No commit, no push,
  no edit in orbit-board or orbit-ui (two scratch clones with `git clone --shared` at `7ee498a`; orbit-board's HEAD is now
  `cf1e6e1`, records only, untouched). The builder's files were only read.
- mutate.mjs was never imported or run; mcount.py and mkmut.py read mutate.mjs.txt as text (`python3 -I`).
- I did not re-run the builder's P3 probe on c1 (its "65 of 67 identical c1→c2" is the builder's), nor its superseded FM-*,
  FR1-* and FR2-* runs, nor anything of the build round on c1 beyond VF-focused-on-c1 and SUPP-on-c1.
- I did not build or propose any board change: the product in c2 measured right on every shape I tried.
- **Deviations.** (1) Two `node --check` syntax checks of my supplement harness (about 9:57 AM ET) ran directly, not through
  run.sh: no bound, no lock check (the lock was absent at the runs just before and after), nothing executed but the parser.
  (2) Short read-only commands (ls, grep, diff, git hash-object, git log/status on orbit-board) and python text scripts
  for tallies ran directly, not under bx.sh. (3) The tool layer wrote my first `\uffff` in `bin/mksupp.py` as the raw
  character; I rewrote both characters as escapes before any run (every file checked: 0 raw U+FFFE/U+FFFF). The same happened in two README drafts, rewritten before assembly. The
  only raw U+FFFE/U+FFFF left in my folder are in `harness/{c2,base}/vrules.mjs`, the builder's probe copied verbatim
  (inside JS strings and a regex class, where they are the same values as their escapes; a probe, not a deliverable).

## Appendix A — my proposed test additions (c3 against c2), exact

### A.1 `diffs/c3-vs-c2-audit-recon.mjs.diff` (blob 6ab9f829639b5dd156e771a05935d82e1e5c525c)
```diff
--- copies/c2/tools/export-audit/audit-recon.mjs	2026-10-13 09:01:01.792727588 +0000
+++ proposal/c3/tools/export-audit/audit-recon.mjs	2026-10-13 14:00:57.092791419 +0000
@@ -5145,6 +5145,8 @@
 // chip is not lit, the label does not say "all years" (U14's rule). A year U14 says beside an entry U34 says: both said, U14's
 // NOTE first. The NOTE is ADDED to the export: every other row is as without the entry. CONTROL: a whole year the board offers
 // outside 2000-2099 (FY1999 rows) is a year -- no range is read into "a year".
+// AND (the verifiers' second round, 13 Oct): two characters XML forbids in one entry are both quoted as their escape; a quote of
+// exactly 40 characters is shown whole and one of 41 is cut at 40. CONTROL: -2027 is a whole number, so a year (U14's notice).
 // FAILS ON d66dd60 (U14; records head 7ee498a): every shape the board did not write -- "2026", {}, 2027, [], "", 0 and false read
 // as ALL YEARS $540M, ALL YEARS lit, nothing said; ["2027"] as FY27 $500M; [2026.5], 5,000 × "x", 120 × "A" and "\ufffe" as ALL
 // YEARS; [null] and [true] as "saved FY0 / FY1 not available"; [2025, 2026.5], ["<b>x</b>", 2027], ["\uffff", 2027] and 45 emoji
@@ -5269,6 +5271,11 @@
       ['U+FFFE as the whole value', '"\\ufffe": not a list; quoted as "\\ufffe", and the workbook is well-formed; kept', ...whole('"\\ufffe"', '"\\ufffe"', '"\ufffe"')],
       ['45 emoji in an entry', 'an entry of 45 emoji beside 2027: quoted as its first 40 characters -- the opening quote and 39 emoji -- and "…", never cut inside one (no half on the panel, no U+FFFD in the export); kept',
         ...by27('"' + E.repeat(39) + '…', J([E.repeat(45), 2027]))],
+      // the verifiers' second round: every forbidden character escaped, and the cut's edge (40 whole, 41 cut)
+      ['two characters XML forbids in one entry', '["\\uffff\\ufffe", 2027]: FY27 counted; both quoted as their escape -- every one, not the first only -- so the workbook is well-formed; kept',
+        ...by27('"\\uffff\\ufffe"', '["\\uffff\\ufffe",2027]', '["\uffff\ufffe",2027]')],
+      ['a quote of exactly 40 characters', '[38 × "B"]: its quote is 40 characters -- shown whole, with no "…"; kept', ...one('"' + 'B'.repeat(38) + '"', '["' + 'B'.repeat(38) + '"]')],
+      ['a quote of 41 characters', '[39 × "C"]: its quote is 41 characters -- cut at 40, then "…"; kept', ...one('"' + 'C'.repeat(39) + '…', '["' + 'C'.repeat(39) + '"]')],
       // both findings at once, and every offered year beside an entry it cannot read
       ['beside a year U14 says', '[2040, "x"]: both said -- the label carries both, both notices are on the panel, the U34 NOTE is in the export; kept', '[2040,"x"]',
         J(want('[2040,"x"]', [], T0, 'no year counted · all appropriations · saved FY40 not available, not counted · 1 saved entry not a year, not counted', '0.00', false, [],
@@ -5293,6 +5300,9 @@
       ['CONTROL — a year the board offers outside 2000–2099', '[1999] on a board holding $7M of FY1999 rows: a whole number is a year, as the board writes it -- FY99 counted, nothing said, kept (no range is read into "a year")',
         '[1999]', J(want('[1999]', [1999], [7 * M, 7 * M, 0], 'FY99 · all appropriations', '7.00', false, ['FY99'], '', '', [])),
         P => { P.execDb.all.om.rows[1999] = [row(1999, 'Old Support', 'USAF O&M Discretionary', 7 * M, 'Program (TSS)')]; }],
+      ['CONTROL — a whole number no year could be', '[-2027]: a whole number is a year, as the board reads it -- U14\'s notice ("FY-27"), nothing counted, no U34 notice (no range is read into "a year")',
+        '[-2027]', J(want('[-2027]', [], T0, 'no year counted · all appropriations · saved FY-27 not available, not counted', '0.00', false, [], '',
+          'The saved year selection includes FY-27, which this board cannot answer for now: it holds no plan for that year, no imported row is filed or counted in it, and it is outside the plan window (FY27–FY31). It stays in the saved selection, and nothing is counted. Click ALL YEARS, or a year’s only, to choose again; switching a year on or off keeps it.', []))],
     ];
     for (const [where, what, text, exp, more] of SHAPES) {
       w5Chk(name, where, what, J(await look(text, more)), exp);
```

### A.2 `diffs/c3-vs-c2-mutate.mjs.txt.diff` (blob 1d89e67885c4a76d38f1b13ed240a1b433202e06)
```diff
--- copies/c2/tools/export-audit/mutate.mjs.txt	2026-10-13 08:51:13.892957339 +0000
+++ proposal/c3/tools/export-audit/mutate.mjs.txt	2026-10-13 14:00:57.112106557 +0000
@@ -4370,6 +4370,19 @@
   { id: "v200-yearsel-plural-label", area: "flowCalc", what: "the scope label's plural is \"5000 saved entries not a year\" again",
     find: "(UR.n===1?'entry not a year':'entries not years')",
     repl: "(UR.n===1?'entry not a year':'entries not a year')" },
+  // v2.00 (U34, the verifiers' second round, 13 Oct): every forbidden character of a quote is escaped; the cut's edge; no range.
+  { id: "v200-yearsel-quote-escape-first-only", area: "flowUnreadSaved", what: "only the first U+FFFE / U+FFFF of a quote is escaped: a saved [\"\\uffff\\ufffe\", 2027] puts the second raw into the export's sheet, which is then not a well-formed workbook",
+    find: ".replace(/[\\uFFFE\\uFFFF]/g, c=>",
+    repl: ".replace(/[\\uFFFE\\uFFFF]/, c=>" },
+  { id: "v200-yearsel-quote-cut-at-40-or-more", area: "flowUnreadSaved", what: "a quote of exactly 40 characters is given a \"…\" though nothing follows",
+    find: "    return t.length>40? t.slice(0,40)",
+    repl: "    return t.length>=40? t.slice(0,40)" },
+  { id: "v200-yearsel-quote-cut-above-41", area: "flowUnreadSaved", what: "a quote of 41 characters is shown whole, not cut at 40",
+    find: "    return t.length>40? t.slice(0,40)",
+    repl: "    return t.length>41? t.slice(0,40)" },
+  { id: "v200-yearsel-year-four-digits", area: "flowYearOk", what: "a year must have four digits: a saved [-2027] is said as an entry the board cannot read, not as U14's year it cannot answer for",
+    find: "function flowYearOk(y){ return typeof y==='number' && Number.isInteger(y); }",
+    repl: "function flowYearOk(y){ return typeof y==='number' && Number.isInteger(y) && y>=1000 && y<=9999; }" },
   // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.
   { id: "v200-r3-landed-view-unsaid", area: "_driveStorePushRun", what: "a folder save that lands while a locked view is on screen says “🔒 Not kept — PB27 is a locked view. ✅ Saved …” again, naming no plan (or, quiet, leaves persist's refusal on screen)",
     find: "  if(CYCVIEW){ _cycRefusedAt=0; setStat('✅ <b>Saved the working plan</b> of '+esc(APPN_LBL[ap]||ap)+' FY'+(fy%100)+' to the shared folder — '\n    +Math.round(body.length/1024)+' KB, built before '+blLbl(CYCVIEW)+' was put on screen. '+blLbl(CYCVIEW)+' is a locked view: nothing in it '\n    +'is saved. Everyone sees the working plan on their next refresh.'+penNote+lateNote); render(); return true; }\n",
```

## Appendix B — what was reviewed (c2 against the base), exact (bodies equal the builder's diffs/c2-*-vs-base.diff)

### `diffs/c2-vs-base-prioritization-board-grid.html.diff` (blob 6b37182668a3c35f16c099c5a9c0ccf780f09da5)
```diff
--- base/prioritization-board-grid.html	2026-10-12 21:17:00.000000000 +0000
+++ c2/prioritization-board-grid.html	2026-10-13 08:50:04.332953204 +0000
@@ -15349,11 +15349,35 @@
 }
 // v2.00 (U14): the saved year selection as it is stored -- each year once, in order -- or null when none is saved (ALL YEARS).
 // Read, never written: only a person's click (flowToggleYear, flowOneYear, flowAllYears) changes it.
+// v2.00 (U34): A SAVED SELECTION THIS BOARD DID NOT WRITE IS NEVER READ AS ALL YEARS. None saved (null, or no key) is ALL YEARS,
+// and nothing else is. A year is a whole number, as the board writes it; anything else -- a string ("2026"), an object, a bare
+// number, 2026.5, null, an empty list -- is read as no year, kept as saved, and said (flowUnreadSaved). It read as ALL YEARS,
+// or as a year it is not ("2027" as FY27, true as FY1), with nothing said.
+function flowYearOk(y){ return typeof y==='number' && Number.isInteger(y); }
 function flowSavedYears(){
   const C=flowCfg();
-  if(!Array.isArray(C.fys)) return null;
-  const s=C.fys.map(Number).filter((y,i,a)=>Number.isInteger(y) && a.indexOf(y)===i);
-  return s.length? s.sort() : null;
+  if(C.fys==null) return null;
+  const s=(Array.isArray(C.fys)? C.fys : []).filter((y,i,a)=>flowYearOk(y) && a.indexOf(y)===i);
+  return s.sort();
+}
+// v2.00 (U34): what of the saved year selection this board cannot read as years, or null when it reads all of it: the whole
+// value (not a list, or an empty one), or the entries that are not whole numbers. `what` quotes the file -- at most three
+// entries, each cut at 40 characters -- for the panel's notice (escaped there) and the export's NOTE. Each is cut between
+// characters, never inside one, and U+FFFE / U+FFFF are quoted as the file's own escape ("\uffff"): XML 1.0 forbids both, so
+// the export's sheet holding one would not be a well-formed workbook. Only the first 82 units are read, so the cost stays small.
+function flowUnreadSaved(){
+  const v=flowCfg().fys, q=x=>{ const t=Array.from(String(JSON.stringify(x)).slice(0,82).replace(/[\uFFFE\uFFFF]/g, c=>'\\u'+c.charCodeAt(0).toString(16)));
+    return t.length>40? t.slice(0,40).join('')+'\u2026' : t.join(''); };
+  if(v==null) return null;
+  if(!Array.isArray(v) || !v.length) return {whole:true, n:1, what:q(v)};
+  const bad=v.filter(y=>!flowYearOk(y));
+  return bad.length? {whole:false, n:bad.length, what:bad.slice(0,3).map(q).join(', ')+(bad.length>3? ' and '+(bad.length-3)+' more' : '')} : null;
+}
+function flowUnreadText(F, fy){
+  const U=F.unread, L=a=>a.map(fy).join(', '), one=U.n===1;
+  if(U.whole) return 'The saved year selection is '+U.what+', not a list of years this board can read. It is kept as saved, and nothing is counted.';
+  return 'The saved year selection holds '+U.what+', which this board cannot read as '+(one?'a year':'years')+'. '+(one?'It is':'They are')
+    +' kept as saved'+(F.fys.length? ' and not counted: this total counts '+L(F.fys)+' only.' : ', and nothing is counted.');
 }
 // v2.00 (U14): the saved years the board cannot answer for now: no plan held for them, no imported row filed or counted in
 // them, outside the plan window. The panel and the export name them, and what is counted instead.
@@ -15398,13 +15422,15 @@
 // v2.00 (U14): ALL YEARS names its years as they run -- "FY25, FY27–FY31" -- so a dash never spans a year that is in no total;
 // it read "FY25–FY31" over a FY26 nothing counted in. A saved selection with a year the board cannot answer for is never
 // called all years (`un`: those years; flowCalc says them after the label). No year counted reads "no year counted".
-function flowScopeLabel(ys, aps, un){
+// v2.00 (U34): nor is one holding what the board cannot read as years (`ur`: flowUnreadSaved), even when the years it can read
+// are every year offered; it read "· all years" beside "this total counts FY25, FY27, ... only".
+function flowScopeLabel(ys, aps, un, ur){
   const allY=flowYears(), FY=y=>'FY'+(y%100);
   const runs=a=>a.reduce((o,y)=>{ const r=o[o.length-1]; if(r && y===r[1]+1) r[1]=y; else o.push([y,y]); return o; }, [])
     .map(r=>r[0]===r[1]? FY(r[0]) : FY(r[0])+'\u2013'+FY(r[1])).join(', ');
   const yl = !ys.length? 'no year counted'
     : ys.length===1? 'FY'+(ys[0]%100)
-    : ((ys.length===allY.length && !(un||[]).length)? runs(ys)+' \u00b7 all years'
+    : ((ys.length===allY.length && !(un||[]).length && !ur)? runs(ys)+' \u00b7 all years'
        : ys.map(y=>'FY'+(y%100)).join(', '));
   const al = aps.length===FLOW_APPNS.length? 'all appropriations'
     : aps.map(a=>APPN_LBL[a]).join(' + ');
@@ -15586,9 +15612,10 @@
   const RIX=(AX==='buys')? null : flowReqIndex();
   const YS = (arg==null)? flowSelYears() : [Number(arg)];
   const UN = (arg==null)? flowUnavailYears() : [];      // v2.00 (U14): saved years the board cannot answer for now
+  const UR = (arg==null)? flowUnreadSaved() : null;     // v2.00 (U34): what of the saved selection cannot be read as years
   const AS = (arg==null)? flowSelAppns() : FLOW_APPNS.slice();
-  const F={fy:YS[YS.length-1], fys:YS, aps:AS, multi:YS.length>1, unavail:UN,
-           label:flowScopeLabel(YS,AS,UN), tot:0, appn:APPN_SLUGS.reduce(function(o,s){ o[s]=0; return o; },{}), dual:0, rows:0,
+  const F={fy:YS[YS.length-1], fys:YS, aps:AS, multi:YS.length>1, unavail:UN, unread:UR,
+           label:flowScopeLabel(YS,AS,UN,UR), tot:0, appn:APPN_SLUGS.reduce(function(o,s){ o[s]=0; return o; },{}), dual:0, rows:0,
            // Executed money and planned money are both in the total, and which is which is a fact
            // the chart has to be able to STATE - so it is counted here rather than inferred later
            // from the year list, which would go wrong the moment a year carries a partial import.
@@ -15674,6 +15701,8 @@
   // v2.00 (U14): a saved year the board cannot answer for is said in the scope itself -- the panel, the chart, the image, the
   // export's Scope line and its file name all print this label -- kept in the selection, and not counted
   if(UN.length) F.label+=' \u00b7 saved '+UN.map(y=>'FY'+(y%100)).join(', ')+' not available, not counted';
+  // v2.00 (U34): and a saved selection, or part of one, that cannot be read as years
+  if(UR) F.label+=' \u00b7 '+(UR.whole? 'saved year selection not a list of years' : UR.n+' saved '+(UR.n===1?'entry not a year':'entries not years'))+', not counted';
   return F;
 }
 // v1.99 (item 92): what partner and FMS money is, said the same way on the panel and in the export
@@ -16481,12 +16510,13 @@
   let h='<div style="margin-bottom:6px;display:flex;gap:5px;flex-wrap:wrap;align-items:center">'
     +'<span style="font-size:9px;color:var(--dim);font-weight:800;letter-spacing:.8px;width:74px">FISCAL YEAR</span>'
     // v2.00 (U14): ALL YEARS is lit only for ALL YEARS: a saved selection holding a year the board cannot answer for is not it
-    +chip(selY.length===yrs.length && !F.unavail.length,'ALL YEARS','flowAllYears()','Every year this board can answer for \u2014 executed and planned together')
+    // v2.00 (U34): nor is one holding what the board cannot read as years; the years it counts are lit instead
+    +chip(selY.length===yrs.length && !F.unavail.length && !F.unread,'ALL YEARS','flowAllYears()','Every year this board can answer for \u2014 executed and planned together')
     // A planned year is marked ON THE CHIP. Both kinds are selectable together and the total adds
     // them up, so which is which has to be visible at the point of choosing, not only afterwards.
     +yrs.map(function(f){
         const pl=flowYearKind(f)==='plan';
-        return chip(selY.indexOf(f)>=0 && (selY.length<yrs.length || F.unavail.length>0),'FY'+(f%100)+(pl?' \u00b7 plan':''),
+        return chip(selY.indexOf(f)>=0 && ((selY.length<yrs.length || F.unavail.length>0) || !!F.unread),'FY'+(f%100)+(pl?' \u00b7 plan':''),
             'flowToggleYear('+f+')',
             // v2.00 (R1): a planned year with rows STORED under it has every one COUNTED in a later year (OBBBA). It said "has no
             // O&M execution imported" of an FY25 whose O&M rows were imported and are all counted in FY26.
@@ -16555,6 +16585,11 @@
     +(F.unavail.length? '<div class="flowunavail" style="border:1px solid var(--amber);border-radius:8px;padding:8px 11px;margin-bottom:9px;font-size:10px">'
        +'<b style="color:var(--amber)">'+esc(flowUnavailText(F, y=>'FY'+(y%100)))+'</b> '
        +'Click <b>ALL YEARS</b>, or a year\u2019s <b>only</b>, to choose again; switching a year on or off keeps '+(F.unavail.length===1?'it':'them')+'.</div>' : '')
+    // v2.00 (U34): A SAVED SELECTION THE BOARD CANNOT READ AS YEARS is said, quoted as saved, with what is counted instead. Any
+    // click on the year buttons chooses again and replaces what cannot be read (a toggle starts from the years it could read).
+    +(F.unread? '<div class="flowunread" style="border:1px solid var(--amber);border-radius:8px;padding:8px 11px;margin-bottom:9px;font-size:10px">'
+       +'<b style="color:var(--amber)">'+esc(flowUnreadText(F, y=>'FY'+(y%100)))+'</b> '
+       +'Click <b>ALL YEARS</b>, a year\u2019s <b>only</b>, or a year to switch it on or off, to choose again; any of these replaces what cannot be read.</div>' : '')
     +'<div style="font-size:9.5px;color:var(--dim);margin-bottom:6px">Loaded: '
     +FLOW_APPNS.map(a=>(LOAD[a].has
         ? '<b style="color:var(--ink)">'+esc(APPN_LBL[a])+'</b> '+LOAD[a].n+' events'
@@ -16756,6 +16791,8 @@
     +'. Executed is the imported CCaR QPE; planned is '+(APPN_LBL[F.planSlug]||'this board')+'\u2019s own allocation.'],[]);
   if(F.multi) sum.splice(3,0,['NOTE: separate appropriation years added together \u2014 a portfolio total, '
     +'not one year of funding. Fiscal years included: '+F.fys.map(y=>'FY'+y).join(', ')+'.'],[]);
+  // v2.00 (U34): a saved selection the board cannot read as years, in the panel's words, under U14's NOTE
+  if(F.unread) sum.splice(3,0,['NOTE: '+flowUnreadText(F, y=>'FY'+y)],[]);
   // v2.00 (U14): a saved year the board cannot answer for now, in the panel's words, first under the Scope line
   if(F.unavail.length) sum.splice(3,0,['NOTE: '+flowUnavailText(F, y=>'FY'+y)],[]);
   // v1.99 (item 92): only the appropriations in scope -- one switched off is not a $0 line
```

### `diffs/c2-vs-base-audit-recon.mjs.diff` (blob 75383ed703a03bc0b0bf727a6b5c0afe4d9eedb7)
```diff
--- base/tools/export-audit/audit-recon.mjs	2026-10-12 21:17:00.000000000 +0000
+++ c2/tools/export-audit/audit-recon.mjs	2026-10-13 09:01:01.792727588 +0000
@@ -5123,6 +5123,240 @@
   await settleBoards();
 })();
 // ==== end v2.00 (U14) ====
+// ==== v2.00 (U34): a saved year selection this board did not write is read as no year, kept as saved and said -- never as ALL YEARS ====
+// Codex's review, as Brad supplied it on 12 Oct: "the malformed saved-year selection"; Brad: "record the malformed saved-year
+// selection ... explicitly". U14 keeps a saved year the board cannot answer for and says it; this is the selection the board
+// never writes at all, as a hand-edited or damaged saved file carries it. The board writes null (ALL YEARS) or a list of whole
+// years from its own buttons, and nothing else. The board is U14's no-plan fixture: O&M, one service, F1 asking $1,000M, base
+// year 2027, FY27 pot $500M, MS.years {2027}, the rule off; workbook O&M FY25 'USAF O&M Discretionary' $40M. Offered: FY25,
+// FY27-FY31; ALL YEARS = 40 + 500 = $540M. Its saved file is built once (buildSavedHtml); for each shape, the file's own
+// appropriation's flow.fys is replaced AS TEXT, the file is opened through the board's opening path (boot({html})), read
+// apart in the calculation, the panel and the export (its bytes read back), then saved and opened again.
+// A SHAPE THE BOARD DID NOT WRITE -- not a list ("2026", {}, 2027), an empty list, or entries that are not whole numbers
+// ("2027", 2026.5, null, true, text) -- counts no year from what it cannot read; it is never read as ALL YEARS, never as a
+// year it is not, and it is said: the scope label (the panel, the chart, the export's Scope line), the panel's notice
+// (quoting the file, escaped) and the export's NOTE, with what is counted instead. It is kept as saved (the same value)
+// through the reads, the save and the reopen, until a person chooses again; a year switched on starts from the years it could
+// read. CONTROLS (as before): no key and null are ALL YEARS; duplicates are read once and an unsorted list in order, with
+// nothing said; a whole year no appropriation offers is U14's notice.
+// AND (the verifiers' round, 13 Oct): "", 0 and false are not lists either. A quoted entry is cut at 40 characters, between
+// characters, and U+FFFE / U+FFFF are quoted as their escape -- XML 1.0 forbids both -- so every shape's export is a
+// well-formed workbook, every part read as XML (w7Pkg). Every offered year beside an entry it cannot read is not ALL YEARS: the
+// chip is not lit, the label does not say "all years" (U14's rule). A year U14 says beside an entry U34 says: both said, U14's
+// NOTE first. The NOTE is ADDED to the export: every other row is as without the entry. CONTROL: a whole year the board offers
+// outside 2000-2099 (FY1999 rows) is a year -- no range is read into "a year".
+// FAILS ON d66dd60 (U14; records head 7ee498a): every shape the board did not write -- "2026", {}, 2027, [], "", 0 and false read
+// as ALL YEARS $540M, ALL YEARS lit, nothing said; ["2027"] as FY27 $500M; [2026.5], 5,000 × "x", 120 × "A" and "\ufffe" as ALL
+// YEARS; [null] and [true] as "saved FY0 / FY1 not available"; [2025, 2026.5], ["<b>x</b>", 2027], ["\uffff", 2027] and 45 emoji
+// beside 2027 counted their one whole year with nothing said; [2040, "x"] said FY40 only; [2025, 2027-2031, "x"] read as ALL
+// YEARS; so the export carried no U34 NOTE (both whole-export checks); and FY27 switched on beside "2026" switched it OFF from
+// every year ($40M). Passing there too: the seven controls, and FY27 switched on beside [2025, 2026.5], ALL YEARS and a year's
+// only on "2026".
+await (async () => {
+  const name = 'v2.00 (U34) — a saved year selection this board did not write is never read as ALL YEARS; it is kept and said';
+  const { bootMark, bootRelease, settleBoards } = await import('./boot.mjs');
+  const __bm = bootMark();
+  try {
+    const J = JSON.stringify, M = 1000000;
+    const row = (fy, title, budget, amt, office) => { const r = Array(32).fill(''); r[0] = fy; r[1] = fy + '-03'; r[2] = 'U14' + fy; r[3] = title;
+      r[4] = budget; r[7] = 'Event ' + title; r[9] = amt; r[10] = 'Allocated'; r[18] = office; return r; };
+    const WB = { om: { asOf: '2026-09', hdr: [], read: 1, noFy: 0, rows: { 2025: [row(2025, 'Ordinary Support', 'USAF O&M Discretionary', 40 * M, 'Program (TSS)')] } } };
+    // window.confirm answering `ans`, every question counted and kept
+    const counted = (w, ans) => { w.__cc = 0; w.__ccMsgs = []; w.confirm = m => { w.__cc++; w.__ccMsgs.push(String(m)); return ans; }; };
+    const X = boot();
+    seed(X.ev, { services: ['USAF'], items: [it('F1', 'PSM', [1000 * M])], disc: [500 * M], mand: [0], order: ['F1'] });
+    X.ev(`BASE_ITEMS.length=0; DATA.items.forEach(function(i){ BASE_ITEMS.push(i); BASE_ASK[i.id]=i.ask.slice(); });
+      S.bm={disc:[${500 * M}], mand:[0], adds:[]}; MS.base=2027; MS.cur=2027; FYMON=fyMonths(2027); MS.years={2027:S};
+      applyState(S); MS.years[2027]=S; EXDB.all=${J(WB)}; EXDB.ts=1;
+      var C=flowCfg(); delete C.pseudo; C.other={}; C.fys=null; C.aps=null; save(); 'ok'`);
+    counted(X.w, true);
+    const slug = JSON.parse(X.ev('JSON.stringify(_AP.slug)')), html0 = X.ev('buildSavedHtml()');
+    const RE = /(<script type="application\/json" id="pubState">)([\s\S]*?)(<\/script>)/;
+    // the saved file with its own appropriation's flow.fys replaced by `text`, as a hand edit leaves it (undefined: no key);
+    // `more`, when given, changes the rest of the saved state first (the FY1999 control's rows)
+    const withFys = (text, more) => html0.replace(RE, (m, a, b, c) => {
+      const P = JSON.parse(b), F = P.appns[slug].flow;
+      if (more) more(P);
+      if (text === undefined) delete F.fys; else F.fys = '__FYS__';
+      let s = J(P).replace(/</g, '\\u003c');
+      if (text !== undefined) s = s.replace('"__FYS__"', () => text);
+      return a + s + c; });
+    const fileFys = h => { const F = JSON.parse(RE.exec(h)[2]).appns[slug].flow; return 'fys' in F ? J(F.fys) : '(no key)'; };
+    const now = R => JSON.parse(R.ev(`(function(){ var F=flowCalc(); return JSON.stringify({stored:String(JSON.stringify(flowCfg().fys)),
+      sel:flowSelYears(), t:[F.tot, F.execV, F.planV], label:F.label}); })()`));
+    const panel = R => { R.ev(`flowOpen=true; flowSel=''; flowBody(); 'ok'`);
+      const b = R.w.document.getElementById('flowBody'), btn = [...b.querySelectorAll('button')], n = b.querySelector('.flowunread'), u = b.querySelector('.flowunavail');
+      const tf = /total funding \$([\d,]+\.\d\d)M/.exec(b.textContent);
+      return { total: tf ? tf[1] : '', allOn: btn.filter(x => x.getAttribute('onclick') === 'flowAllYears()').map(x => x.classList.contains('on'))[0],
+        lit: btn.filter(x => /^flowToggleYear\(\d+\)$/.test(x.getAttribute('onclick') || '') && x.classList.contains('on')).map(x => x.textContent),
+        notice: n ? n.textContent : '', html: n ? n.innerHTML : '', unavail: u ? u.textContent : '' }; };
+    const cell = c => (c && typeof c === 'object' && 'v' in c) ? c.v : c;
+    // the exported workbook read back from its bytes
+    const book = async R => { const wb = JSON.parse(await R.w.eval(`(async function(){ var cap=null, _B=window.Blob;
+        window.Blob=function(p,o){ if(p&&p[0]&&p[0].byteLength) cap=p[0]; return new _B(p,o); };
+        try{ exportFlow(); }catch(e){ window.Blob=_B; return JSON.stringify({__err:'threw '+String((e&&e.message)||e)}); }
+        window.Blob=_B; if(!cap) return JSON.stringify({__err:'no file'});
+        var ab=cap.buffer.slice(cap.byteOffset,cap.byteOffset+cap.byteLength); return JSON.stringify(await xlsxRead(ab)); })()`));
+      const ff = wb['Funds Flow'] || [], all = lab => ff.filter(r => w6Lbl(r) === lab).map(r => num(cell(r[1]))).filter(v => v !== null);
+      return { err: wb.__err || 'ok', scope: w6Lbl(ff[1] || []), tot: all('TOTAL FUNDING'),
+        notes: ff.map(w6Lbl).filter(t => /^NOTE: The saved year selection (is|holds) /.test(t)) }; };
+    // the exported Funds Flow sheet, every row as its cells' values
+    const flowRows = async R => { const wb = JSON.parse(await R.w.eval(`(async function(){ var cap=null, _B=window.Blob;
+        window.Blob=function(p,o){ if(p&&p[0]&&p[0].byteLength) cap=p[0]; return new _B(p,o); };
+        try{ exportFlow(); }catch(e){ window.Blob=_B; return '{}'; }
+        window.Blob=_B; if(!cap) return '{}';
+        var ab=cap.buffer.slice(cap.byteOffset,cap.byteOffset+cap.byteLength); return JSON.stringify(await xlsxRead(ab)); })()`));
+      return (wb['Funds Flow'] || []).map(r => (r || []).map(cell)); };
+    // one shape, opened: what it counts and says everywhere, and what the save and the reopen carry; last, the export's
+    // package, every part read as XML (w7Pkg) -- a workbook that is not well-formed is not an export
+    const look = async (text, more) => {
+      const R = boot({ html: withFys(text, more) }); counted(R.w, true);
+      const a = now(R), P = panel(R), B = await book(R), h2 = R.ev('buildSavedHtml()'), R2 = boot({ html: h2 }), r = now(R2), cc = R.w.__cc;
+      return [a.stored, a.sel, a.t, a.label, P.total, P.allOn, P.lit, P.notice, P.unavail, B.err, B.scope, B.tot, B.notes,
+        fileFys(h2) === (text === undefined ? '(no key)' : J(JSON.parse(text))), r.stored === a.stored, r.sel, r.t[0], cc, R.errors.length + R2.errors.length,
+        w7Ok(w7Pkg(R.w, 'exportFlow'))]; };
+    // the same, expected -- every value a literal
+    const want = (stored, sel, t, label, total, allOn, lit, notice, unavail, notes) =>
+      [stored, sel, t, label, total, allOn, lit, notice, unavail, 'ok', 'Scope: ' + label, [t[0], t[0]], notes, true, true, sel, t[0], 0, 0,
+        'ok · every part reads · every count holds'];
+    const ALL = 'FY25, FY27–FY31 · all years · all appropriations · FY27, FY28, FY29, FY30, FY31 planned, the rest executed';
+    const L0 = 'no year counted · all appropriations · saved year selection not a list of years, not counted';
+    const L1 = 'no year counted · all appropriations · 1 saved entry not a year, not counted';
+    const O = [2025, 2027, 2028, 2029, 2030, 2031], T540 = [540 * M, 40 * M, 500 * M], T500 = [500 * M, 0, 500 * M], T0 = [0, 0, 0];
+    const TAIL = ' Click ALL YEARS, a year’s only, or a year to switch it on or off, to choose again; any of these replaces what cannot be read.';
+    const WH = q => 'The saved year selection is ' + q + ', not a list of years this board can read. It is kept as saved, and nothing is counted.';
+    const H1 = q => 'The saved year selection holds ' + q + ', which this board cannot read as a year. It is kept as saved, and nothing is counted.';
+    // `stored`: the value as the board writes it back, when the file's text spells it otherwise ("\uffff" for the character)
+    const whole = (q, text, stored = text) => [text, J(want(stored, [], T0, L0, '0.00', false, [], WH(q) + TAIL, '', ['NOTE: ' + WH(q)]))];
+    const one = (q, text) => [text, J(want(text, [], T0, L1, '0.00', false, [], H1(q) + TAIL, '', ['NOTE: ' + H1(q)]))];
+    // one entry it cannot read beside 2027: FY27 counted, $500M, the entry said
+    const L27 = 'FY27 · all appropriations · PLANNED (board allocation, O&M) · 1 saved entry not a year, not counted';
+    const H27 = (q, fy) => 'The saved year selection holds ' + q + ', which this board cannot read as a year. It is kept as saved and not counted: this total counts ' + fy + ' only.';
+    const by27 = (q, text, stored = text) => [text, J(want(stored, [2027], T500, L27, '500.00', false, ['FY27 · plan'], H27(q, 'FY27') + TAIL, '', ['NOTE: ' + H27(q, 'FY2027')]))];
+    const E = '\u{1F600}';
+    const U40 = 'The saved year selection includes FY40, which this board cannot answer for now: it holds no plan for that year, no imported row is filed or counted in it, and it is outside the plan window (FY27–FY31). It stays in the saved selection, and nothing is counted. Click ALL YEARS, or a year’s only, to choose again; switching a year on or off keeps it.';
+    const SHAPES = [
+      // [where, what is promised, the text in the file, expected]
+      ['a string', 'the saved selection "2026", not a list: no year counted (never ALL YEARS $540M), ALL YEARS not lit, said on the panel and in the export, kept through the save and the reopen', ...whole('"2026"', '"2026"')],
+      ['an object', '{}: no year counted, said, kept', ...whole('{}', '{}')],
+      ['a bare number', '2027 alone, not in a list: no year counted (never ALL YEARS, never a guess at FY27), said, kept', ...whole('2027', '2027')],
+      ['an empty list', '[]: names no year -- no year counted (never ALL YEARS), said, kept', ...whole('[]', '[]')],
+      ['a year as text', '["2027"]: text is not a year the board writes -- not counted as FY27 (no guess), said, kept', ...one('"2027"', '["2027"]')],
+      ['not a whole number', '[2026.5]: not counted, never ALL YEARS, said, kept', ...one('2026.5', '[2026.5]')],
+      ['null in the list', '[null] (NaN, as a saved file writes it): not read as a year "FY0", said as it is saved, kept', ...one('null', '[null]')],
+      ['true in the list', '[true]: not read as a year "FY1", said as it is saved, kept', ...one('true', '[true]')],
+      ['one whole year, one not', '[2025, 2026.5]: FY25 counted ($40M executed), 2026.5 said and not counted, kept',
+        '[2025,2026.5]', J(want('[2025,2026.5]', [2025], [40 * M, 40 * M, 0], 'FY25 · all appropriations · 1 saved entry not a year, not counted', '40.00', false, ['FY25'],
+          'The saved year selection holds 2026.5, which this board cannot read as a year. It is kept as saved and not counted: this total counts FY25 only.' + TAIL, '',
+          ['NOTE: The saved year selection holds 2026.5, which this board cannot read as a year. It is kept as saved and not counted: this total counts FY2025 only.']))],
+      ['text that is markup', '["<b>x</b>", 2027]: FY27 counted ($500M), the text quoted as saved and shown as text, never as markup',
+        '["<b>x</b>",2027]', J(want('["<b>x</b>",2027]', [2027], T500, 'FY27 · all appropriations · PLANNED (board allocation, O&M) · 1 saved entry not a year, not counted', '500.00', false, ['FY27 · plan'],
+          'The saved year selection holds "<b>x</b>", which this board cannot read as a year. It is kept as saved and not counted: this total counts FY27 only.' + TAIL, '',
+          ['NOTE: The saved year selection holds "<b>x</b>", which this board cannot read as a year. It is kept as saved and not counted: this total counts FY2027 only.']))],
+      ['an enormous list', '5,000 entries of "x": no year counted, never ALL YEARS; three quoted and the rest counted, said in the plural, kept',
+        '[' + Array(5000).fill('"x"').join(',') + ']', J(want('[' + Array(5000).fill('"x"').join(',') + ']', [], T0, 'no year counted · all appropriations · 5000 saved entries not years, not counted', '0.00', false, [],
+          'The saved year selection holds "x", "x", "x" and 4997 more, which this board cannot read as years. They are kept as saved, and nothing is counted.' + TAIL, '',
+          ['NOTE: The saved year selection holds "x", "x", "x" and 4997 more, which this board cannot read as years. They are kept as saved, and nothing is counted.']))],
+      // the verifiers' round: falsy values are not lists either
+      ['an empty string', '"": not a list -- no year counted (never ALL YEARS $540M), ALL YEARS not lit, said, kept', ...whole('""', '""')],
+      ['zero', '0: not a list -- no year counted (never ALL YEARS), said, kept', ...whole('0', '0')],
+      ['false', 'false: not a list -- no year counted (never ALL YEARS), said, kept', ...whole('false', 'false')],
+      // the quote: cut at 40 characters, between characters, and never carrying what XML 1.0 forbids (the package, last value)
+      ['a long entry', '[120 × "A"]: not counted; quoted as its first 40 characters and "…" on the panel and in the NOTE; kept whole',
+        '["' + 'A'.repeat(120) + '"]', J(want('["' + 'A'.repeat(120) + '"]', [], T0, L1, '0.00', false, [], H1('"' + 'A'.repeat(39) + '…') + TAIL, '', ['NOTE: ' + H1('"' + 'A'.repeat(39) + '…')]))],
+      ['U+FFFF in an entry', '["\\uffff", 2027], as a damaged file holds it: FY27 counted, the entry quoted as the file\'s own escape "\\uffff" -- never the character XML 1.0 forbids, so the workbook is well-formed; kept',
+        ...by27('"\\uffff"', '["\\uffff",2027]', '["\uffff",2027]')],
+      ['U+FFFE as the whole value', '"\\ufffe": not a list; quoted as "\\ufffe", and the workbook is well-formed; kept', ...whole('"\\ufffe"', '"\\ufffe"', '"\ufffe"')],
+      ['45 emoji in an entry', 'an entry of 45 emoji beside 2027: quoted as its first 40 characters -- the opening quote and 39 emoji -- and "…", never cut inside one (no half on the panel, no U+FFFD in the export); kept',
+        ...by27('"' + E.repeat(39) + '…', J([E.repeat(45), 2027]))],
+      // both findings at once, and every offered year beside an entry it cannot read
+      ['beside a year U14 says', '[2040, "x"]: both said -- the label carries both, both notices are on the panel, the U34 NOTE is in the export; kept', '[2040,"x"]',
+        J(want('[2040,"x"]', [], T0, 'no year counted · all appropriations · saved FY40 not available, not counted · 1 saved entry not a year, not counted', '0.00', false, [],
+          H1('"x"') + TAIL, U40, ['NOTE: ' + H1('"x"')]))],
+      ['every offered year beside an entry it cannot read', '[2025, 2027-2031, "x"]: every offered year counted, $540M, but it is not ALL YEARS -- ALL YEARS not lit, the six years lit, the label never "all years"; said, kept',
+        '[2025,2027,2028,2029,2030,2031,"x"]', J(want('[2025,2027,2028,2029,2030,2031,"x"]', O, T540,
+          'FY25, FY27, FY28, FY29, FY30, FY31 · all appropriations · FY27, FY28, FY29, FY30, FY31 planned, the rest executed · 1 saved entry not a year, not counted', '540.00', false,
+          ['FY25', 'FY27 · plan', 'FY28 · plan', 'FY29 · plan', 'FY30 · plan', 'FY31 · plan'],
+          'The saved year selection holds "x", which this board cannot read as a year. It is kept as saved and not counted: this total counts FY25, FY27, FY28, FY29, FY30, FY31 only.' + TAIL, '',
+          ['NOTE: The saved year selection holds "x", which this board cannot read as a year. It is kept as saved and not counted: this total counts FY2025, FY2027, FY2028, FY2029, FY2030, FY2031 only.']))],
+      ['CONTROL — no key', 'no saved selection is ALL YEARS: $540M, ALL YEARS lit, nothing said', undefined, J(want('undefined', O, T540, ALL, '540.00', true, [], '', '', []))],
+      ['CONTROL — null', 'null, the board\'s own ALL YEARS: $540M, ALL YEARS lit, nothing said', 'null', J(want('null', O, T540, ALL, '540.00', true, [], '', '', []))],
+      ['CONTROL — duplicates', '[2027, 2027]: FY27 once, $500M, nothing said, kept as saved', '[2027,2027]',
+        J(want('[2027,2027]', [2027], T500, 'FY27 · all appropriations · PLANNED (board allocation, O&M)', '500.00', false, ['FY27 · plan'], '', '', []))],
+      ['CONTROL — out of order', '[2031, 2025, 2027]: read in order, $540M, nothing said, kept as saved', '[2031,2025,2027]',
+        J(want('[2031,2025,2027]', [2025, 2027, 2031], T540, 'FY25, FY27, FY31 · all appropriations · FY27, FY31 planned, the rest executed', '540.00', false, ['FY25', 'FY27 · plan', 'FY31 · plan'], '', '', []))],
+      ['CONTROL — an enormous list of one year', '2027 five thousand times: FY27, $500M, nothing said, kept as saved', '[' + Array(5000).fill('2027').join(',') + ']',
+        J(want('[' + Array(5000).fill('2027').join(',') + ']', [2027], T500, 'FY27 · all appropriations · PLANNED (board allocation, O&M)', '500.00', false, ['FY27 · plan'], '', '', []))],
+      ['CONTROL — a whole year no appropriation offers', '[2040]: U14\'s notice, nothing counted, nothing else said', '[2040]',
+        J(want('[2040]', [], T0, 'no year counted · all appropriations · saved FY40 not available, not counted', '0.00', false, [], '',
+          'The saved year selection includes FY40, which this board cannot answer for now: it holds no plan for that year, no imported row is filed or counted in it, and it is outside the plan window (FY27–FY31). It stays in the saved selection, and nothing is counted. Click ALL YEARS, or a year’s only, to choose again; switching a year on or off keeps it.', []))],
+      ['CONTROL — a year the board offers outside 2000–2099', '[1999] on a board holding $7M of FY1999 rows: a whole number is a year, as the board writes it -- FY99 counted, nothing said, kept (no range is read into "a year")',
+        '[1999]', J(want('[1999]', [1999], [7 * M, 7 * M, 0], 'FY99 · all appropriations', '7.00', false, ['FY99'], '', '', [])),
+        P => { P.execDb.all.om.rows[1999] = [row(1999, 'Old Support', 'USAF O&M Discretionary', 7 * M, 'Program (TSS)')]; }],
+    ];
+    for (const [where, what, text, exp, more] of SHAPES) {
+      w5Chk(name, where, what, J(await look(text, more)), exp);
+      bootRelease(__bm, [X.w]);
+    }
+    // both NOTEs in the export, in order: U14's first under the Scope line, then U34's, each with its blank row
+    {
+      const R = boot({ html: withFys('[2040,"x"]') }); counted(R.w, true); const ff = await flowRows(R);
+      w5Chk(name, 'beside a year U14 says · the NOTEs in order', 'the export\'s NOTE rows: U14\'s at row 4 (index 3), U34\'s at index 5, each followed by a blank row',
+        J(ff.map((r, i) => [i, String(r[0] ?? '')]).filter(x => /^NOTE: /.test(x[1]))),
+        J([[3, 'NOTE: The saved year selection includes FY2040, which this board cannot answer for now: it holds no plan for that year, no imported row is filed or counted in it, and it is outside the plan window (FY2027–FY2031). It stays in the saved selection, and nothing is counted.'],
+          [5, 'NOTE: The saved year selection holds "x", which this board cannot read as a year. It is kept as saved, and nothing is counted.']]));
+      bootRelease(__bm, [X.w]);
+    }
+    // the NOTE is ADDED: [2027, "x"] exports every row [2027] exports, in order, but its Scope line, and a NOTE with its blank row
+    {
+      const Ra = boot({ html: withFys('[2027]') }); counted(Ra.w, true); const a = (await flowRows(Ra)).map(r => J(r));
+      const Rb = boot({ html: withFys('[2027,"x"]') }); counted(Rb.w, true); const b = (await flowRows(Rb)).map(r => J(r));
+      const nx = b.findIndex(r => r.indexOf('NOTE: The saved year selection holds') >= 0);
+      const rest = b.filter((r, i) => i !== 1 && i !== nx && i !== nx + 1), same = a.filter((r, i) => i !== 1);
+      w5Chk(name, 'the export beside the NOTE', '[2027, "x"] exports every row [2027] exports, in the same order, but its Scope line; the NOTE and a blank row are added at index 3, under the Source line',
+        J([a.length > 20, b.length - a.length, nx, b[nx + 1], J(rest) === J(same)]), J([true, 2, 3, '[]', true]));
+      bootRelease(__bm, [X.w]);
+    }
+    // the markup is text on the panel: escaped in the notice's HTML, no element made from it
+    {
+      const R = boot({ html: withFys('["<b>x</b>",2027]') }); counted(R.w, true); const P = panel(R);
+      w5Chk(name, 'text that is markup · escaped', 'the notice\'s HTML carries "&lt;b&gt;x&lt;/b&gt;" (text, as the DOM writes it back), and its only <b> elements are the board\'s own three -- none is made from the file',
+        J([P.html.indexOf('"&lt;b&gt;x&lt;/b&gt;"') >= 0, (P.html.match(/<b[ >]/g) || []).length]), J([true, 3]));
+      bootRelease(__bm, [X.w]);
+    }
+    // a person's click on such a selection chooses again, as the notice says
+    const click = (R, onclick) => { R.ev(`flowOpen=true; flowBody(); 'ok'`);
+      const b = [...R.w.document.querySelectorAll('#flowBody button')].find(x => x.getAttribute('onclick') === onclick);
+      if (!b) return false; b.click(); return true; };
+    {
+      const R = boot({ html: withFys('"2026"') }); counted(R.w, true);
+      const ok = click(R, 'flowToggleYear(2027)'), a = now(R), P = panel(R);
+      w5Chk(name, '"2026", then FY27 switched on', 'the toggle starts from the years it could read -- none -- so FY27 is the selection: [2027] saved, $500M, no notice (never every year but FY27)',
+        J([ok, a.stored, a.sel, a.t, P.notice, P.lit, R.errors.length]), J([true, '[2027]', [2027], T500, '', ['FY27 · plan'], 0]));
+      bootRelease(__bm, [X.w]);
+    }
+    {
+      const R = boot({ html: withFys('[2025,2026.5]') }); counted(R.w, true);
+      const ok = click(R, 'flowToggleYear(2027)'), a = now(R), P = panel(R);
+      w5Chk(name, '[2025, 2026.5], then FY27 switched on', 'CONTROL — FY25 kept and FY27 added: [2025, 2027] saved, $540M; what could not be read is replaced, and the notice goes',
+        J([ok, a.stored, a.sel, a.t, P.notice, R.errors.length]), J([true, '[2025,2027]', [2025, 2027], T540, '', 0]));
+      bootRelease(__bm, [X.w]);
+    }
+    {
+      const R = boot({ html: withFys('"2026"') }); counted(R.w, true);
+      const okA = click(R, 'flowAllYears()'), a = now(R), okO = click(R, 'flowOneYear(2027)'), b = now(R);
+      w5Chk(name, '"2026", then ALL YEARS, then FY27\'s only', 'CONTROL — ALL YEARS on its own click: null saved, $540M; then FY27\'s only: [2027], $500M',
+        J([okA, a.stored, a.t, okO, b.stored, b.t, R.errors.length]), J([true, 'null', T540, true, '[2027]', T500, 0]));
+      bootRelease(__bm, [X.w]);
+    }
+    w5Chk(name, 'nothing asked', 'the base board asked nothing while its file was built', J([X.w.__cc, X.errors.length]), J([0, 0]));
+  } catch (e) {
+    failures.push({ scenario: name, where: 'harness', what: 'the block threw: ' + String((e && e.message) || e).slice(0, 160), got: 'threw', want: 'ran' });
+  }
+  bootRelease(__bm, []);
+  await settleBoards();
+})();
+// ==== end v2.00 (U34) ====
 
 {
   const src = _selfRead(_selfPath(import.meta.url), 'utf8');
```

### `diffs/c2-vs-base-mutate.mjs.txt.diff` (blob e67138645f9c86c19457b1bef376050d8d528acd)
```diff
--- base/tools/export-audit/mutate.mjs.txt	2026-10-12 21:17:00.000000000 +0000
+++ c2/tools/export-audit/mutate.mjs.txt	2026-10-13 08:51:13.892957339 +0000
@@ -4285,6 +4285,91 @@
   { id: "v200-u14-notice-plural-it", area: "flowHtml", what: "the panel's notice says \"keeps it\" however many saved years the board cannot answer for: FY24 and FY26 \"stay in the saved selection\", and switching a year \"keeps it\"",
     find: "switching a year on or off keeps '+(F.unavail.length===1?'it':'them')+'.</div>'",
     repl: "switching a year on or off keeps it.</div>'" },
+  // v2.00 (U34, Codex's review as Brad supplied it, 12 Oct: "the malformed saved-year selection"): a saved year selection the
+  // board did not write is read as no year, kept as saved and said -- never as ALL YEARS, never as a year it is not.
+  { id: "v200-yearsel-not-a-list-all-years", area: "flowSavedYears", what: "a saved year selection that is not a list reads as ALL YEARS again: \"2026\", {} or a bare 2027 counts every year, $540M, ALL YEARS lit, while the notice says nothing is counted",
+    find: "  if(C.fys==null) return null;\n  const s=(Array.isArray(C.fys)? C.fys : [])",
+    repl: "  if(!Array.isArray(C.fys)) return null;\n  const s=(Array.isArray(C.fys)? C.fys : [])" },
+  { id: "v200-yearsel-nothing-read-all-years", area: "flowSavedYears", what: "a saved list with no whole year in it reads as ALL YEARS again: [], [2026.5], [\"2027\"] and 5,000 × \"x\" count every year, $540M",
+    find: "  return s.sort();\n}\n// v2.00 (U34): what of the saved year selection",
+    repl: "  return s.length? s.sort() : null;\n}\n// v2.00 (U34): what of the saved year selection" },
+  { id: "v200-yearsel-number-coerced", area: "flowSavedYears", what: "the saved entries are read through Number() again: [\"2027\"] counts as FY27, [true] is said as a saved FY1, [null] as a saved FY0",
+    find: "(Array.isArray(C.fys)? C.fys : []).filter((y,i,a)=>flowYearOk(y) && a.indexOf(y)===i)",
+    repl: "(Array.isArray(C.fys)? C.fys : []).map(Number).filter((y,i,a)=>Number.isInteger(y) && a.indexOf(y)===i)" },
+  { id: "v200-yearsel-fraction-unsaid", area: "flowUnreadSaved", what: "only entries that are not numbers are said: [2026.5] counts nothing and says nothing; [2025, 2026.5] counts FY25 with nothing said of 2026.5",
+    find: "  const bad=v.filter(y=>!flowYearOk(y));",
+    repl: "  const bad=v.filter(y=>typeof y!=='number');" },
+  { id: "v200-yearsel-whole-unsaid", area: "flowUnreadSaved", what: "a saved selection that is not a list, or an empty one, counts nothing and says nothing: \"2026\" reads \"no year counted\" with no reason, on the panel and in the export",
+    find: "  if(!Array.isArray(v) || !v.length) return {whole:true, n:1, what:q(v)};",
+    repl: "  if(!Array.isArray(v) || !v.length) return null;" },
+  { id: "v200-yearsel-label-unsaid", area: "flowCalc", what: "the scope label leaves out what cannot be read: the panel, the chart and the export's Scope line say \"no year counted\" with no reason, while the notice says it",
+    find: "  if(UR) F.label+=' \\u00b7 '+(UR.whole?",
+    repl: "  if(false) F.label+=' \\u00b7 '+(UR.whole?" },
+  { id: "v200-yearsel-panel-unsaid", area: "flowHtml", what: "the panel leaves out its notice of a saved selection it cannot read, while the export says it",
+    find: "    +(F.unread? '<div class=\"flowunread\"",
+    repl: "    +(false? '<div class=\"flowunread\"" },
+  { id: "v200-yearsel-export-unsaid", area: "exportFlow", what: "the export leaves out its NOTE of a saved selection the board cannot read, while the panel says it",
+    find: "  if(F.unread) sum.splice(3,0,['NOTE: '+flowUnreadText(F, y=>'FY'+y)],[]);",
+    repl: "  if(false) sum.splice(3,0,['NOTE: '+flowUnreadText(F, y=>'FY'+y)],[]);" },
+  { id: "v200-yearsel-markup-unescaped", area: "flowHtml", what: "the panel prints the file's text as markup: a saved \"<b>x</b>\" is a bold x in the notice, not the text the file holds",
+    find: "+esc(flowUnreadText(F, y=>'FY'+(y%100)))+",
+    repl: "+flowUnreadText(F, y=>'FY'+(y%100))+" },
+  { id: "v200-yearsel-counted-unsaid", area: "flowUnreadText", what: "the notice says \"nothing is counted\" while a whole year beside the bad entry is counted: [2025, 2026.5] totals $40M under \"nothing is counted\"",
+    find: "+' kept as saved'+(F.fys.length?",
+    repl: "+' kept as saved'+(false?" },
+  { id: "v200-yearsel-plural-it", area: "flowUnreadText", what: "the notice says \"It is kept\" however many entries it cannot read: 5,000 × \"x\" read \"It is kept as saved\"",
+    find: "+(one?'It is':'They are')",
+    repl: "+'It is'" },
+  { id: "v200-yearsel-toggle-from-all", area: "flowToggleYear", what: "a toggle on a saved selection it cannot read starts from every year: FY27 switched on beside \"2026\" switches FY27 OFF and counts the other five, $40M",
+    find: "  const all=flowYears(), cur=flowSavedYears()||all.slice();",
+    repl: "  const all=flowYears(), cur=(flowSavedYears()||[]).length? flowSavedYears() : all.slice();" },
+  // v2.00 (U34, the verifiers' round, 13 Oct): the quote of a saved entry is cut between characters and never carries what
+  // XML forbids; a selection holding what the board cannot read is never ALL YEARS; falsy values, both notices, the export's rows.
+  { id: "v200-yearsel-quote-xml-unsafe", area: "flowUnreadSaved", what: "the quote carries U+FFFE / U+FFFF as they are: a saved [\"\\uffff\", 2027] puts a character XML 1.0 forbids into the export's sheet, which is then not a well-formed workbook",
+    find: ".slice(0,82).replace(/[\\uFFFE\\uFFFF]/g, c=>'\\\\u'+c.charCodeAt(0).toString(16)));",
+    repl: ".slice(0,82));" },
+  { id: "v200-yearsel-quote-splits-char", area: "flowUnreadSaved", what: "the quote is cut by UTF-16 units: an entry of 45 emoji is cut inside the 20th -- half a character on the panel, U+FFFD in the export, neither in the file",
+    find: "q=x=>{ const t=Array.from(String(JSON.stringify(x)).slice(0,82)",
+    repl: "q=x=>{ const t=(s=>s.split(''))(String(JSON.stringify(x)).slice(0,82)" },
+  { id: "v200-yearsel-quote-uncut", area: "flowUnreadSaved", what: "the quote is not cut at 40 characters: an entry of 120 \"A\" is quoted whole, to 82 characters",
+    find: "    return t.length>40? t.slice(0,40).join('')+'\\u2026' : t.join(''); };",
+    repl: "    return t.join(''); };" },
+  { id: "v200-yearsel-falsy-all-years", area: "flowSavedYears", what: "a falsy saved selection reads as ALL YEARS again: \"\", 0 or false counts every year, $540M, while the notice says nothing is counted",
+    find: "  if(C.fys==null) return null;\n  const s=(Array.isArray(C.fys)? C.fys : [])",
+    repl: "  if(!C.fys) return null;\n  const s=(Array.isArray(C.fys)? C.fys : [])" },
+  { id: "v200-yearsel-falsy-unsaid", area: "flowUnreadSaved", what: "a falsy saved selection is not said: \"\", 0 or false counts no year with no reason given, on the panel, in the label and in the export",
+    find: "  if(v==null) return null;\n  if(!Array.isArray(v) || !v.length)",
+    repl: "  if(!v) return null;\n  if(!Array.isArray(v) || !v.length)" },
+  { id: "v200-yearsel-allyears-lit-unread", area: "flowHtml", what: "ALL YEARS is lit beside an entry the board cannot read when the years it can read are every year offered: [2025, 2027-2031, \"x\"] lights ALL YEARS under a notice saying \"this total counts FY25, FY27, ... only\"",
+    find: "!F.unavail.length && !F.unread,'ALL YEARS'",
+    repl: "!F.unavail.length,'ALL YEARS'" },
+  { id: "v200-yearsel-label-all-years-unread", area: "flowScopeLabel", what: "the scope label says \"all years\" beside an entry the board cannot read: [2025, 2027-2031, \"x\"] reads \"FY25, FY27–FY31 · all years\" on the panel and in the export's Scope line",
+    find: "!(un||[]).length && !ur)?",
+    repl: "!(un||[]).length)?" },
+  { id: "v200-yearsel-label-ur-unpassed", area: "flowCalc", what: "flowCalc does not tell the label what it cannot read: [2025, 2027-2031, \"x\"] reads \"· all years\" again",
+    find: "label:flowScopeLabel(YS,AS,UN,UR),",
+    repl: "label:flowScopeLabel(YS,AS,UN)," },
+  { id: "v200-yearsel-year-chips-unlit-unread", area: "flowHtml", what: "beside an entry the board cannot read, with every offered year read, no year button is lit: nothing on screen shows which years the total counts",
+    find: "(selY.length<yrs.length || F.unavail.length>0) || !!F.unread)",
+    repl: "(selY.length<yrs.length || F.unavail.length>0))" },
+  { id: "v200-yearsel-note-replaces-line", area: "exportFlow", what: "the export's U34 NOTE replaces the row under the Source line instead of being added: the other-sources line goes from the export when a saved entry cannot be read",
+    find: "  if(F.unread) sum.splice(3,0,['NOTE: '+flowUnreadText(F, y=>'FY'+y)],[]);",
+    repl: "  if(F.unread) sum.splice(3,1,['NOTE: '+flowUnreadText(F, y=>'FY'+y)],[]);" },
+  { id: "v200-yearsel-note-order", area: "exportFlow", what: "the export's NOTEs swap places: U34's NOTE comes first under the Scope line and U14's after it, unlike the panel, where U14's notice is first",
+    find: "  if(F.unread) sum.splice(3,0,['NOTE: '+flowUnreadText(F, y=>'FY'+y)],[]);\n  // v2.00 (U14): a saved year the board cannot answer for now, in the panel's words, first under the Scope line\n  if(F.unavail.length) sum.splice(3,0,['NOTE: '+flowUnavailText(F, y=>'FY'+y)],[]);",
+    repl: "  if(F.unavail.length) sum.splice(3,0,['NOTE: '+flowUnavailText(F, y=>'FY'+y)],[]);\n  // v2.00 (U14): a saved year the board cannot answer for now, in the panel's words, first under the Scope line\n  if(F.unread) sum.splice(3,0,['NOTE: '+flowUnreadText(F, y=>'FY'+y)],[]);" },
+  { id: "v200-yearsel-label-unsaid-beside-u14", area: "flowCalc", what: "the scope label says only U14's part when a saved year it cannot answer for sits beside an entry it cannot read: [2040, \"x\"] reads \"saved FY40 not available\" and nothing of \"x\"",
+    find: "  if(UR) F.label+=' \\u00b7 '+(UR.whole?",
+    repl: "  if(UR && !UN.length) F.label+=' \\u00b7 '+(UR.whole?" },
+  { id: "v200-yearsel-panel-unsaid-beside-u14", area: "flowHtml", what: "the panel shows only U14's notice when a saved year it cannot answer for sits beside an entry it cannot read: [2040, \"x\"] says nothing of \"x\" on screen",
+    find: "    +(F.unread? '<div class=\"flowunread\"",
+    repl: "    +(F.unread && !F.unavail.length? '<div class=\"flowunread\"" },
+  { id: "v200-yearsel-year-range", area: "flowYearOk", what: "a year must lie in 2000-2099: a saved [1999] on a board holding FY1999 rows -- a year the board offers and writes -- is said as an entry it cannot read, and its $7M is not counted",
+    find: "function flowYearOk(y){ return typeof y==='number' && Number.isInteger(y); }",
+    repl: "function flowYearOk(y){ return typeof y==='number' && Number.isInteger(y) && y>=2000 && y<=2099; }" },
+  { id: "v200-yearsel-plural-label", area: "flowCalc", what: "the scope label's plural is \"5000 saved entries not a year\" again",
+    find: "(UR.n===1?'entry not a year':'entries not years')",
+    repl: "(UR.n===1?'entry not a year':'entries not a year')" },
   // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.
   { id: "v200-r3-landed-view-unsaid", area: "_driveStorePushRun", what: "a folder save that lands while a locked view is on screen says “🔒 Not kept — PB27 is a locked view. ✅ Saved …” again, naming no plan (or, quiet, leaves persist's refusal on screen)",
     find: "  if(CYCVIEW){ _cycRefusedAt=0; setStat('✅ <b>Saved the working plan</b> of '+esc(APPN_LBL[ap]||ap)+' FY'+(fy%100)+' to the shared folder — '\n    +Math.round(body.length/1024)+' KB, built before '+blLbl(CYCVIEW)+' was put on screen. '+blLbl(CYCVIEW)+' is a locked view: nothing in it '\n    +'is saved. Everyone sees the working plan on their next refresh.'+penNote+lateNote); render(); return true; }\n",
```
