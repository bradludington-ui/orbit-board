# CYCREG fix round: test-adequacy review, round 2 (lens B)

Written 13 Oct 2026; last edited at 9:44 AM ET. This is an independent check of the builder's CYCREG fix round (ledger rows
U32 and U33). The proposal is the copy `rec/L6/cycreg/fr/c1`, described in `wfstate/fix_cycreg_r1.json`. I edited none of the
builder's files and nothing in `/home/user/orbit-board` or `/home/user/orbit-ui`. I committed, staged and pushed nothing.

**Verdict: the fix is sound, but one test gap must be closed before it is committed.** The product change exports the right money
on every shape and route I tried, base vs fix. Every builder run I repeated gives the same result. The suites I may run pass on the
fix exactly as they do on the base. The new tests have one gap that must be closed (MUST-FIX 1) and four that should be (S1 to S4).

- **MUST-FIX 1 (money).** This commit changed a money line with no check behind it. If that line alone is reverted, the RCN-EEIC
  sheet loses USAF $900 / ANG $200 entirely, and all 90 CYCREG checks still pass.
- **S1 to S4.** Each of four other plausible wrong fixes survives the block. The proposed checks below catch every one, fail on
  the base, and pass on the fix.

## How this review was resumed

An earlier attempt of this same review ran from 5:51 to 6:06 AM ET and was stopped by the usage limit. The container restarted at
9:11 AM ET and I resumed at 9:13 AM ET. Here is what I reused and what I re-ran:

- **Reused, every run that has an exit record on the same blobs.** That is the focused block on the base and on the fix
  (`V-F-b0`, `V-F-fx`), all 22 builder mutants (`V-MB-*`), my XLSX probe on the fix (`XP-fx`), and 6 of my 16 own mutants
  (`V-MV-*`).
- **Re-run under new labels, `V2-MV-*`.** Four own-mutant runs had started with no exit record. Six more had never started.
- **Unchanged copies.** `b0/` is still identical to `rec/L6/base` and `fx/` to the builder's `fr/c1` (`diff -r`, both clean).

## What was checked (identities)

| file | base `b0/` (7ee498a, product d66dd60) | fix `fx/` (= builder `fr/c1`) |
|---|---|---|
| prioritization-board-grid.html | fce8a391bd8a248d5185e199d22190c1687eaea0 | 19e6e5089ab801dcd4e4777c794fa82992f0c28d |
| tools/export-audit/audit-recon.mjs | 529e36f7c20e635b2722ea53b6a4f44b4ed328af | 089703716ac470a6d5ce3114eccd8b5d478c32fe |
| tools/export-audit/mutate.mjs.txt | cbc6defc6803851e847844848fc9b186daeeb268 | 0cfd2487af96ee0a731a723ce24b50c9231bb179 |
| audit-import / audit-board / audit-other | 4aba2506 / a7c575e5 / d89396b0 | unchanged |

- **Scratch clones.** `gc/b0` and `gc/fx` are `git clone --shared /home/user/orbit-board` at detached 7ee498a. Each has the
  node_modules symlink and `runtime-encoding-shim.mjs`. `gc/fx` also has the fix's three files copied in. Nothing in either clone
  was committed.
- **Blobs of my harnesses and helpers.** These are in `out/blobs.txt`:
  - `h/fx/h-cycreg.mjs` b80a9462: the focused CYCREG harness. I checked its block is verbatim from the fix's audit-recon: the
    block text is found as is, and every non-comment line is found in the suite.
  - `h/fx/h-cycreg-plus.mjs` b715b01f: the same harness with my proposed checks added.
  - `h/fx/p2.mjs` a5388df2: my XLSX probe.
  - `bin/xread.py` b0579e48: an independent reader using Python zipfile and XML, nothing from the board.

## Suite diffs against the base, and changed expectations

- **audit-recon.mjs: a pure addition.** One hunk adds 249 lines and removes 0. It is the block `// ==== v2.00 (CYCREG) ...` to
  `// ==== end v2.00 (CYCREG) ====`, placed after the U14 block and before the scenario-ran guard.
- **mutate.mjs.txt: a pure addition.** One hunk adds 67 lines and removes 0. It holds the 22 `v200-cycreg-*` entries, inserted
  directly before the line `// v2.00 (R3, Brad 11 Oct): a save that lands under a locked view ...`.
- **No other suite file changed** (`diff -rq b0 fx`).
- **No existing check, fixture or expected value changed (principle 6).**
- **House style matches.** The block has the two-space `  const name = '...'` line the guard reads (its quotes are U+2019, never
  an ASCII apostrophe), `bootMark()` with `bootRelease(__bm, [])`, `settleBoards()`, and the ==== markers. `bootRelease(__bm, [])`
  is what 25 other audit-recon blocks use; audit-recon has no `keepBoards`.

## Expected values are literals, and the new checks fail on the base

- **Every `want` is a hand-written literal**, or a concatenation of literal constants (`ROWS`, `WANT`, `WANT_NF`, `AT_PB`,
  `TWICE`, `LIST_TAIL`, `ENTRY_TAIL`, `SAYS`). Board helpers appear only on the observed side.
- **On the base, 50 of the 90 checks fail.** The 40 that pass are all fixtures (each labelled CONTROL, R1 funded 900 / 200 / 0 or
  pots of 0) and the ordinary-key CONTROL cases, as the task asks. I listed all 40 by name and none of them is a non-control check.
- **The base failures show the doubling**, read back from the XLSX bytes:
  - Codex 1 shows K1's row twice: USAF TOTAL 1,800, ANG TOTAL 400.
  - Codex 2 shows 22222 / BBBBB and "— no RCN/EEIC assigned —" each at 900: USAF 1,800 / ANG 400.
  - The NOT FUNDED Ask shows 1,800 for 2 requirements.
- **The fix's whole suite on the base board** (`S2-recon-fxsuite-on-b0`) fails exactly 50 checks. They are the same 50 as the
  focused run and all are in the CYCREG scenario; every other block passes.
- **My independent reader agrees on the money.** `bin/xread.py` read 15 workbooks from the base (`XP2-b0`) and 15 from the fix
  (`XP-fx`):
  - Base: Codex 1, Codex 2 and the working plan's [K1, K1], each after import, after reopening and after saving and reopening,
    all show USAF 1,800 / ANG 400 / all services 2,200. The ordinary-key control shows 900 / 200 / 1,100.
  - Fix: every one shows 900 / 200 / 1,100.
  - The suite reads the bytes with the board's own `xlsxRead` (the `w6Book` convention used by audit-recon's 32 other reads). That
    is how this suite reads workbooks; my reader is the independent cross-check.

## mcount (text only, mcount.py, 9:21:54 AM ET)

- Fix mutate on the fix board: 1,350 entries, each found once.
- Base mutate on the fix board: 1,328 of 1,328 found once, so every existing entry still applies.
- Fix mutate on the base board: 1,328 found once. The 22 new `v200-cycreg-*` entries are missing on the base, as they should be.
- Base mutate on the base board: 1,328 of 1,328 found once.

## The builder's runs, repeated and compared

| builder's run | mine | same? |
|---|---|---|
| FR2-base 50 fail / 40 pass; FR2-fix 90 pass | V-F-b0 50 / 40; V-F-fx 90 / 0 | yes |
| 22 mutants, every one caught (keys-repeat 15, none-is-text 6, door-open 16, ...) | V-MB-* | yes: same count and the same failing checks for all 22 (compared against `fr/mutant-failures.txt`) |
| S-audit-recon-fr-suite-on-base-board: exactly the 50 CYCREG checks fail | S2-recon-fxsuite-on-b0 | yes |
| other suites on the fix (gc/fr), all exit 0 | S2-*-fx and S2-*-b0 | yes: boot-same, audit, audit-ppt, legacy-fsrc, audit-inject, audit-other, audit-hostile, audit-recon and npm run check all pass on both |
| FRI v1.95 W1 53, W2 242, v1.97 W1 15, W3 111, v2.00 R3–U13 167 | V2-I-* on the fix | yes, same counts, all pass. The harnesses are the builder's, and I checked every block in them is verbatim in audit-import. |
| FRB v1.97 W1 178; FRB2-83: 21 pass plus 2 harness lines (w4Template) on both boards | V2-B-* | yes, the same on the fix and the base |
| FR-vprobe…vprobe6 on the fix; FR-probe and FR-probe2 on the fix and the base | V2-R-* (copies in `probe/`, blobs identical) | yes: normalised output identical for all 10 |
| mcount 1,350 / 1,350 and 1,328 / 1,328 | out/mcount2.txt | yes |

## My own mutants: 16, each a plausible wrong fix (`bin/mkvm2.py`, `diffs/mut-vm2-*.diff`)

Nine are caught by the block:

| mutant | failing checks |
|---|---|
| keys-string-unique | 6 |
| none-text-excluded | 2 |
| breakout-dup | 13 |
| rollup-dup | 13 |
| door-cycles-skipped | 4 |
| one-own-board | 3 |
| report-drops-rcn | 5 |
| say-cycles-dropped | 4 |
| switch-not-cleared | 1 |

**Seven survive the block, each with all 90 checks passing.** For each one I measured what goes wrong:

| mutant (one-line change) | what goes wrong, observed | proposed check catches it |
|---|---|---|
| vm2-known-from-list: `known` built from `keysOf()` | list [{k:1}], R1 on "1": the XLSX (xread) shows USAF TOTAL 0, ANG TOTAL 0, ALL 0. The money is in no row (XM-known). Fix and base: 900 / 200 / 1,100. | yes, 4 fail (V2-P-vm2-known-from-list) |
| vm2-del-first-row-alone: ✕ on row 1 of a repeated key removes that row alone | R1 moves silently to 22222 / BBBBB. The question says row 1 "stays" while row 1 is the one removed (XM-delfirst). | yes, 1 |
| vm2-several-own-board: Import several boards treats a file handed over as the user's own | PB27 [K1, K1] is taken, `prio27om` is rewritten and the list is now [K1, K1] (XM-several; the base does the same) | yes, 1 |
| vm2-add-if: `if` for `while` in rcnAdd | 4 adds in one millisecond, 2 removed, 1 more: keys [_2, _3, _3] (XM-addif) | yes, 1 |
| vm2-say-first-only | the full import's question drops "holds the key “__none__” (rcn[2])" (XM-firstonly) | yes, 1 |
| vm2-none-renamed: NONE = '__unassigned__' | an opened file with an entry keyed "__unassigned__" exports USAF 1,800 / ANG 400 / 2,200 (XM-renamed) | yes, 1 |
| vm2-sidecar-xhr-refused (the file:// opt-in sidecar) | not probed. jsdom cannot take the file:// branch. By reading, the fix changes both branches the same way. | no check proposed |

## Findings

### MUST-FIX 1 (tests, money): the `known` line this commit changed has no check

- **What the line does.** `const known={}; keys.forEach(function(k){ known[k]=1; });` is new in this commit; the base used
  `keysOf()`. It decides which assignments land in a printed row.
- **Reproduction.** Revert that line alone (`mut/v/vm2-known-from-list.html`, blob 8081f099):
  - V-MV-vm2-known-from-list (6:05:32 AM ET, exit 0) passes all 90 CYCREG checks.
  - XM-known (9:21:53 AM ET, exit 0) takes the working plan's list [{k:1, rcn:'44444', eeic:'DDDDD'}] with R1 on "1", opens it
    directly, and also brings it in by full import and reopens it. My reader then finds every RCN-EEIC total at 0: USAF 0, ANG 0,
    all services 0. The fix gives 900 / 200 / 1,100 as not assigned; the base gives 900 / 200 / 1,100 under 44444 / DDDDD.
- **Why the block misses it.** Its only number-key case is [1, "1"], where a text "1" entry keeps the money in a row.
- **Minimal fix.**
  - Add one CASES entry, as in `bin/mkplus.py`:
    `{ c: '... the working plan lists the number 1 alone, R1 on “1”', o: { asg: '1', plan: [N1] }, view: '', lab: ON_NONE, why: AT_WP + NOT_TEXT, says: 'O&M working plan’s list holds a key that is not text (rcn[0].k is the number 1)', routes: ['door', 'full', 'reopened', 'saved', 'opened', 'opened-saved'] }`.
  - Add one mutation entry: `{ id: "v200-cycreg-known-from-list", area: "monSheet", what: "...", find: "const known={}; keys.forEach(function(k){ known[k]=1; });", repl: "const known={}; keysOf().forEach(function(k){ known[k]=1; });" }`.
    The find matches the fix board once.
- **Shown.**
  - V2-P-fx: the case passes, and with S1 to S4 below the block has 103 checks, all passing.
  - V2-P-b0: the case's 7 non-fixture checks fail on the base (the door passes the file, the full import says nothing, and the row
    reads 11111 / AAAAA).
  - V2-P-vm2-known-from-list: 4 checks fail, each with totals 0.

### SHOULD-FIX

- **S1. ✕ on the FIRST row of a repeated key has no check.**
  - The mutant vm2-del-first-row-alone silently re-points R1 to the second row's codes, a different line of accounting in the
    export, and its question is untrue. It passes 90 of 90.
  - Proposed: a CONTROL check (as on d66dd60). It passes on the base and the fix and catches the mutant:
    `rcnDel(0)` on [K1 11111, K1 22222], R1 on K1. The question must read, literally, "Remove RCN 11111 / EEIC AAAAA?\n\n1
    assignment (requirements, services and CLINs) point at it across all fiscal years. Every one is cleared -- none is left
    pointing at something that no longer exists.". After it the list is [K1 22222] and R1 is ''.
- **S2. ⇊ Import several boards is not driven by the block.** The builder says so; the mutant shows it matters.
  - With vm2-several-own-board, a file handed over with PB27 [K1, K1] is taken and stored, and the suite passes.
  - Proposed: the Codex 1 file through `importBoards`. It must be refused whole, with the literal alert `'“cycle.html” was not
    imported: ' + AT_PB + TWICE + '.\n\n' + LIST_TAIL + ' Nothing on this board was changed.'`, and browser storage must be
    byte-identical.
  - It fails on the base (taken, `prio27om` moved), passes on the fix, and catches the mutant.
- **S3. The Add RCN / EEIC check has only one key in use**, so `if` in place of `while` survives.
  - Proposed: 4 adds in one millisecond, 2 removed, 1 more. Expect 3 entries with 3 distinct keys.
  - It fails on the base ([3, 2]), passes on the fix, and catches the mutant.
- **S4. Nothing checks that the full import names every problem in a list.** The builder's README states this fix ("named only
  the first problem").
  - Proposed: PB27 [K1, K1, "__none__"]. The question line must equal
    `'  • ' + SAYS('O&M PB27’s list holds the key “K1” twice (rcn[0] and rcn[1]), holds the key “__none__” (rcn[2])')`.
  - It fails on the base, passes on the fix, and catches vm2-say-first-only.

### MINOR

- **M1. The not-assigned bucket is tested as unforgeable only against the literal "__none__".**
  - A sentinel renamed to other text (vm2-none-renamed) brings back Codex 2's doubling for that name, and the suite passes.
  - Proposed: a CONTROL with an entry keyed "__unassigned__" on an opened file, expecting 900 / 200 / 1,100 as not assigned.
    It passes on the base and the fix, and catches the mutant. No test can cover every name; this one pins the property for a
    second name.
- **M2. The file:// sidecar branch (XHR, opt-in `spmtSidecar=1`) has no check.** Only the fetch branch is checked. By reading,
  the fix changes both branches identically.
- **M3. The new block makes audit-recon longer.** On the same loaded box: 116 s on the base, 155 s on the fix. The builder saw
  222.7 s and 245.0 s.
- **M4. If the lead adopts my checks, the draft's "Test" paragraph needs updating.** It says 90 checks and 50 failing on the base.
  With MUST-FIX 1 and S1 to S4 it would be 103 checks and 60 failing on the base (V2-P-b0: 43 pass, 60 fail).

## Every run

Every node run of mine went through `bin/run.sh`. That script waits on the lock, runs `setsid -w timeout -k 10 600`, and writes PIDs to `pids.txt` and a line to `logs/runs.txt`. The lock file was never present when I checked. Times are Eastern, 13 Oct. The table is generated from `logs/runs.txt` (copy: `out/runs-table.md`). Rows above the **resumed** marker are the earlier attempt's runs, reused because each has an exit record on the same blobs. The earlier attempt's four started-but-unfinished own-mutant runs (V-MV-vm2-none-renamed, -none-text-excluded, -one-own-board, -report-drops-rcn) have no exit record; they were re-run as V2-MV-*.

How to read the result column:

- XP/XM rows are probes. They observe only, and their workbooks are read by `bin/xread.py` into `out/xsum-<label>.txt`.
- V2-R rows are the builder's and the round-1 money verifier's probes, re-run unchanged on my copies. Their output, normalised for paths and timings, is identical to the builder's logs.
- On the fix, the block's checks, including mine, are V2-P rows. V2-I rows are focused audit-import blocks and V2-B rows are focused audit-board blocks; both use the builder's harnesses, which I checked are verbatim from the suites.

| label | start (ET) | exit | wall s | result | log |
|---|---|---|---|---|---|
| V-F-b0 | 05:53:25 | 1 | 74.1 | 50 FAILING CHECK(S) ; 40p/50f | logs/V-F-b0.log |
| V-F-fx | 05:53:25 | 0 | 79.7 | ALL CHECKS PASSED ; 90p/0f | logs/V-F-fx.log |
| V-MB-v200-cycreg-keys-by-value | 05:59:21 | 1 | 89.9 | 6 FAILING CHECK(S) ; 84p/6f | logs/V-MB-v200-cycreg-keys-by-value.log |
| V-MB-v200-cycreg-keys-repeat | 05:59:21 | 1 | 92.8 | 15 FAILING CHECK(S) ; 75p/15f | logs/V-MB-v200-cycreg-keys-repeat.log |
| V-MB-v200-cycreg-notfunded-repeat | 05:59:21 | 1 | 93.3 | 2 FAILING CHECK(S) ; 88p/2f | logs/V-MB-v200-cycreg-notfunded-repeat.log |
| V-MB-v200-cycreg-keys-cycle-only | 05:59:21 | 1 | 94.6 | 9 FAILING CHECK(S) ; 81p/9f | logs/V-MB-v200-cycreg-keys-cycle-only.log |
| XP-fx | 06:00:43 | 0 | 32.6 | probe, observations only (out/xsum-XP-fx.txt) | logs/XP-fx.log |
| V-MB-v200-cycreg-none-money-unseen | 06:00:51 | 1 | 84.1 | 8 FAILING CHECK(S) ; 82p/8f | logs/V-MB-v200-cycreg-none-money-unseen.log |
| V-MB-v200-cycreg-none-is-text | 06:00:54 | 1 | 81.9 | 6 FAILING CHECK(S) ; 84p/6f | logs/V-MB-v200-cycreg-none-is-text.log |
| V-MB-v200-cycreg-none-ask-unseen | 06:00:56 | 1 | 80.3 | 1 FAILING CHECK(S) ; 89p/1f | logs/V-MB-v200-cycreg-none-ask-unseen.log |
| V-MB-v200-cycreg-door-open | 06:00:54 | 1 | 83.0 | 16 FAILING CHECK(S) ; 74p/16f | logs/V-MB-v200-cycreg-door-open.log |
| V-MB-v200-cycreg-door-repeat | 06:02:16 | 1 | 52.0 | 11 FAILING CHECK(S) ; 79p/11f | logs/V-MB-v200-cycreg-door-repeat.log |
| V-MB-v200-cycreg-door-adjacent | 06:02:15 | 1 | 54.8 | 1 FAILING CHECK(S) ; 89p/1f | logs/V-MB-v200-cycreg-door-adjacent.log |
| V-MB-v200-cycreg-door-underscores | 06:02:16 | 1 | 55.1 | 5 FAILING CHECK(S) ; 85p/5f | logs/V-MB-v200-cycreg-door-underscores.log |
| V-MB-v200-cycreg-door-sentinel-only | 06:02:17 | 1 | 54.0 | 1 FAILING CHECK(S) ; 89p/1f | logs/V-MB-v200-cycreg-door-sentinel-only.log |
| V-MB-v200-cycreg-door-not-text | 06:03:08 | 1 | 46.4 | 8 FAILING CHECK(S) ; 82p/8f | logs/V-MB-v200-cycreg-door-not-text.log |
| V-MB-v200-cycreg-own-takes-entry | 06:03:10 | 1 | 46.6 | 1 FAILING CHECK(S) ; 89p/1f | logs/V-MB-v200-cycreg-own-takes-entry.log |
| V-MB-v200-cycreg-own-board-refused | 06:03:11 | 1 | 45.8 | 13 FAILING CHECK(S) ; 77p/13f | logs/V-MB-v200-cycreg-own-board-refused.log |
| V-MB-v200-cycreg-own-board-unsaid | 06:03:11 | 1 | 46.0 | 10 FAILING CHECK(S) ; 80p/10f | logs/V-MB-v200-cycreg-own-board-unsaid.log |
| V-MB-v200-cycreg-folder-refused | 06:03:54 | 1 | 48.0 | 1 FAILING CHECK(S) ; 89p/1f | logs/V-MB-v200-cycreg-folder-refused.log |
| V-MB-v200-cycreg-sidecar-refused | 06:03:57 | 1 | 46.3 | 1 FAILING CHECK(S) ; 89p/1f | logs/V-MB-v200-cycreg-sidecar-refused.log |
| V-MB-v200-cycreg-refusal-untrue | 06:03:57 | 1 | 46.6 | 4 FAILING CHECK(S) ; 86p/4f | logs/V-MB-v200-cycreg-refusal-untrue.log |
| V-MB-v200-cycreg-repeat-row-clears | 06:03:57 | 1 | 47.5 | 1 FAILING CHECK(S) ; 89p/1f | logs/V-MB-v200-cycreg-repeat-row-clears.log |
| V-MB-v200-cycreg-repeat-row-unsaid | 06:04:42 | 1 | 47.1 | 1 FAILING CHECK(S) ; 89p/1f | logs/V-MB-v200-cycreg-repeat-row-unsaid.log |
| V-MB-v200-cycreg-add-key-reused | 06:04:43 | 1 | 47.1 | 1 FAILING CHECK(S) ; 89p/1f | logs/V-MB-v200-cycreg-add-key-reused.log |
| V-MV-vm2-add-if | 06:04:44 | 0 | 47.0 | ALL CHECKS PASSED ; 90p/0f | logs/V-MV-vm2-add-if.log |
| V-MV-vm2-breakout-dup | 06:04:45 | 1 | 46.7 | 13 FAILING CHECK(S) ; 77p/13f | logs/V-MV-vm2-breakout-dup.log |
| V-MV-vm2-del-first-row-alone | 06:05:29 | 0 | 47.3 | ALL CHECKS PASSED ; 90p/0f | logs/V-MV-vm2-del-first-row-alone.log |
| V-MV-vm2-door-cycles-skipped | 06:05:30 | 1 | 46.9 | 4 FAILING CHECK(S) ; 86p/4f | logs/V-MV-vm2-door-cycles-skipped.log |
| V-MV-vm2-keys-string-unique | 06:05:31 | 1 | 46.4 | 6 FAILING CHECK(S) ; 84p/6f | logs/V-MV-vm2-keys-string-unique.log |
| V-MV-vm2-known-from-list | 06:05:32 | 0 | 47.6 | ALL CHECKS PASSED ; 90p/0f | logs/V-MV-vm2-known-from-list.log |
| **resumed 13 Oct, 9:13 AM ET** | | | | | |
| V2-MV-vm2-none-renamed | 09:16:53 | 0 | 59.3 | ALL CHECKS PASSED ; 90p/0f | logs/V2-MV-vm2-none-renamed.log |
| V2-MV-vm2-several-own-board | 09:16:53 | 0 | 59.8 | ALL CHECKS PASSED ; 90p/0f | logs/V2-MV-vm2-several-own-board.log |
| V2-MV-vm2-rollup-dup | 09:16:52 | 1 | 59.9 | 13 FAILING CHECK(S) ; 77p/13f | logs/V2-MV-vm2-rollup-dup.log |
| V2-MV-vm2-none-text-excluded | 09:17:52 | 1 | 52.2 | 2 FAILING CHECK(S) ; 88p/2f | logs/V2-MV-vm2-none-text-excluded.log |
| V2-MV-vm2-say-cycles-dropped | 09:17:52 | 1 | 52.5 | 4 FAILING CHECK(S) ; 86p/4f | logs/V2-MV-vm2-say-cycles-dropped.log |
| V2-MV-vm2-sidecar-xhr-refused | 09:17:52 | 0 | 53.1 | ALL CHECKS PASSED ; 90p/0f | logs/V2-MV-vm2-sidecar-xhr-refused.log |
| V2-MV-vm2-one-own-board | 09:18:44 | 1 | 64.4 | 3 FAILING CHECK(S) ; 87p/3f | logs/V2-MV-vm2-one-own-board.log |
| V2-MV-vm2-switch-not-cleared | 09:18:46 | 1 | 64.2 | 1 FAILING CHECK(S) ; 89p/1f | logs/V2-MV-vm2-switch-not-cleared.log |
| V2-MV-vm2-say-first-only | 09:18:45 | 0 | 64.8 | ALL CHECKS PASSED ; 90p/0f | logs/V2-MV-vm2-say-first-only.log |
| V2-MV-vm2-report-drops-rcn | 09:19:49 | 1 | 30.9 | 5 FAILING CHECK(S) ; 85p/5f | logs/V2-MV-vm2-report-drops-rcn.log |
| XM-addif | 09:21:38 | 0 | 2.8 | 1 XP lines ; 0 workbooks read | logs/XM-addif.log |
| XM-delfirst | 09:21:41 | 0 | 2.5 | 1 XP lines ; 0 workbooks read | logs/XM-delfirst.log |
| XM-firstonly | 09:21:44 | 0 | 2.3 | 1 XP lines ; 0 workbooks read | logs/XM-firstonly.log |
| XM-several | 09:21:46 | 0 | 2.2 | 1 XP lines ; 0 workbooks read | logs/XM-several.log |
| XP2-b0 | 09:21:38 | 0 | 13.8 | 38 XP lines ; 15 workbooks read | logs/XP2-b0.log |
| XM-known | 09:21:53 | 0 | 3.0 | 4 XP lines ; 2 workbooks read | logs/XM-known.log |
| XM-renamed | 09:21:56 | 0 | 2.4 | 2 XP lines ; 1 workbooks read | logs/XM-renamed.log |
| S2-boot-same-fx | 09:24:15 | 0 | 15.9 | every page, source, save and error list identical | logs/S2-boot-same-fx.log |
| S2-boot-same-b0 | 09:24:15 | 0 | 16.8 | every page, source, save and error list identical | logs/S2-boot-same-b0.log |
| S2-audit-fx | 09:24:31 | 0 | 19.2 | ALL CHECKS PASSED | logs/S2-audit-fx.log |
| S2-audit-b0 | 09:24:32 | 0 | 21.9 | ALL CHECKS PASSED | logs/S2-audit-b0.log |
| S2-audit-ppt-fx | 09:24:51 | 0 | 11.0 | ALL CHECKS PASSED | logs/S2-audit-ppt-fx.log |
| S2-audit-ppt-b0 | 09:24:54 | 0 | 8.7 | ALL CHECKS PASSED | logs/S2-audit-ppt-b0.log |
| S2-legacy-fsrc-fx | 09:25:02 | 0 | 6.0 | every legacy Force setting computes exactly as before | logs/S2-legacy-fsrc-fx.log |
| S2-legacy-fsrc-b0 | 09:25:03 | 0 | 8.0 | every legacy Force setting computes exactly as before | logs/S2-legacy-fsrc-b0.log |
| S2-audit-inject-b0 | 09:25:11 | 0 | 16.6 | ALL CHECKS PASSED | logs/S2-audit-inject-b0.log |
| S2-audit-inject-fx | 09:25:08 | 0 | 20.4 | ALL CHECKS PASSED | logs/S2-audit-inject-fx.log |
| S2-audit-other-b0 | 09:25:27 | 0 | 68.2 | ALL CHECKS PASSED | logs/S2-audit-other-b0.log |
| S2-audit-other-fx | 09:25:28 | 0 | 68.6 | ALL CHECKS PASSED | logs/S2-audit-other-fx.log |
| V2-P-fx | 09:25:50 | 0 | 148.2 | ALL CHECKS PASSED ; 103p/0f | logs/V2-P-fx.log |
| S2-audit-hostile-fx | 09:26:37 | 0 | 107.0 | ALL CHECKS PASSED | logs/S2-audit-hostile-fx.log |
| S2-audit-hostile-b0 | 09:26:36 | 0 | 110.8 | ALL CHECKS PASSED | logs/S2-audit-hostile-b0.log |
| V2-P-b0 | 09:28:18 | 1 | 77.7 | 60 FAILING CHECK(S) ; 43p/60f | logs/V2-P-b0.log |
| S2-audit-recon-b0 | 09:28:26 | 0 | 116.3 | ALL CHECKS PASSED | logs/S2-audit-recon-b0.log |
| S2-check-b0 | 09:30:23 | 0 | 3.0 | all checks passed | logs/S2-check-b0.log |
| V2-P-vm2-known-from-list | 09:29:36 | 1 | 54.7 | 4 FAILING CHECK(S) ; 99p/4f | logs/V2-P-vm2-known-from-list.log |
| S2-audit-recon-fx | 09:28:24 | 0 | 154.7 | ALL CHECKS PASSED | logs/S2-audit-recon-fx.log |
| S2-check-fx | 09:30:58 | 0 | 3.2 | all checks passed | logs/S2-check-fx.log |
| V2-P-vm2-add-if | 09:30:31 | 1 | 48.4 | 1 FAILING CHECK(S) ; 102p/1f | logs/V2-P-vm2-add-if.log |
| V2-P-vm2-del-first-row-alone | 09:31:19 | 1 | 48.0 | 1 FAILING CHECK(S) ; 102p/1f | logs/V2-P-vm2-del-first-row-alone.log |
| V2-P-vm2-several-own-board | 09:32:07 | 1 | 60.0 | 1 FAILING CHECK(S) ; 102p/1f | logs/V2-P-vm2-several-own-board.log |
| V2-I-w2-fx | 09:32:31 | 0 | 83.4 | ALL CHECKS PASSED ; 125p/0f 10p/0f 11p/0f 2p/0f 42p/0f 8p/0f 6p/0f 6p/0f 3p/0f 3p/0f 4p/0f 6p/0f 3p/0f 4p/0f 5p/0f 4p/0f | logs/V2-I-w2-fx.log |
| V2-I-v197w1-fx | 09:33:55 | 0 | 21.7 | ALL CHECKS PASSED ; 9p/0f 3p/0f 3p/0f | logs/V2-I-v197w1-fx.log |
| V2-P-vm2-say-first-only | 09:33:07 | 1 | 81.8 | 1 FAILING CHECK(S) ; 102p/1f | logs/V2-P-vm2-say-first-only.log |
| V2-B-v197w1-fx | 09:34:17 | 0 | 38.9 | ALL CHECKS PASSED ; 35p/0f 24p/0f 24p/0f 47p/0f 25p/0f 13p/0f 6p/0f 4p/0f | logs/V2-B-v197w1-fx.log |
| V2-B-83-fx | 09:34:56 | 1 | 8.8 | 2 FAILING CHECK(S) ; 11p/0f 4p/0f 3p/0f 3p/0f | logs/V2-B-83-fx.log |
| V2-B-83-b0 | 09:35:05 | 1 | 9.1 | 2 FAILING CHECK(S) ; 11p/0f 4p/0f 3p/0f 3p/0f | logs/V2-B-83-b0.log |
| V2-P-vm2-none-renamed | 09:34:29 | 1 | 75.2 | 1 FAILING CHECK(S) ; 102p/1f | logs/V2-P-vm2-none-renamed.log |
| S2-recon-fxsuite-on-b0 | 09:32:31 | 1 | 193.2 | 50 FAILING CHECK(S) | logs/S2-recon-fxsuite-on-b0.log |
| V2-I-v200-fx | 09:35:45 | 0 | 82.2 | ALL CHECKS PASSED ; 8p/0f 4p/0f 7p/0f 13p/0f 7p/0f 16p/0f 41p/0f 71p/0f | logs/V2-I-v200-fx.log |
| V2-I-w1-fx | 09:37:07 | 0 | 46.2 | ALL CHECKS PASSED ; 12p/0f 18p/0f 10p/0f 13p/0f | logs/V2-I-w1-fx.log |
| V2-R-vprobe-fx | 09:38:15 | 0 | 26.9 | probe output identical to the builder's run (normalised) | logs/V2-R-vprobe-fx.log |
| V2-R-vprobe2-fx | 09:38:42 | 0 | 24.2 | probe output identical to the builder's run (normalised) | logs/V2-R-vprobe2-fx.log |
| V2-R-vprobe3-fx | 09:39:06 | 0 | 32.5 | probe output identical to the builder's run (normalised) | logs/V2-R-vprobe3-fx.log |
| V2-R-vprobe4-fx | 09:39:39 | 0 | 22.5 | probe output identical to the builder's run (normalised) | logs/V2-R-vprobe4-fx.log |
| V2-R-vprobe5-fx | 09:40:02 | 0 | 21.5 | probe output identical to the builder's run (normalised) | logs/V2-R-vprobe5-fx.log |
| V2-R-vprobe6-fx | 09:40:23 | 0 | 22.3 | probe output identical to the builder's run (normalised) | logs/V2-R-vprobe6-fx.log |
| V2-I-v197w3-fx | 09:36:34 | 0 | 261.6 | ALL CHECKS PASSED ; 19p/0f 23p/0f 18p/0f 23p/0f 12p/0f 16p/0f | logs/V2-I-v197w3-fx.log |
| V2-R-frprobe-fx | 09:40:45 | 0 | 20.5 | probe output identical to the builder's run (normalised) | logs/V2-R-frprobe-fx.log |
| V2-R-frprobe-b0 | 09:41:06 | 0 | 16.7 | probe output identical to the builder's run (normalised) | logs/V2-R-frprobe-b0.log |
| V2-R-frprobe2-fx | 09:41:23 | 0 | 17.2 | probe output identical to the builder's run (normalised) | logs/V2-R-frprobe2-fx.log |
| V2-R-frprobe2-b0 | 09:41:40 | 0 | 17.8 | probe output identical to the builder's run (normalised) | logs/V2-R-frprobe2-b0.log |

## PIDs

- **`pids.txt` records every PID with its command.** That covers every lane, wrapper, timeout and node PID, plus a line for the
  scratch clones, mcount2 and the `node --check`.
- **I killed nothing.** No process of mine was still running when I finished (checked with `ps`). The processes still running on
  the box belong to other tracks.

## Decisions, with reasons

- **MUST-FIX 1 is rated must-fix, not should-fix.** Three reasons:
  - It is a money path that this commit changed.
  - A one-line regression on it empties an export total, and every check passes.
  - Round 1 rated the same kind of gap a must-fix (the NOT FUNDED walk), and the builder accepted that.
- **The other survivors are rated should-fix or minor.** Each guards words, a key collision that takes one millisecond, a route
  the builder disclosed as not driven, or a legacy opt-in branch. None of them loses money in an export on the fix.
- **The design question is left to the money lens.** The full import takes the user's own board with such a list, "as saved",
  rather than refusing or normalising it. The money is right either way.

## What I did not do

- I did not run the full `audit-import.mjs` or `audit-board.mjs`. The lead runs those alone.
- I did not re-run audit-import's v1.86 block, whose focused build does not compile for the builder either. I did not run
  audit-board's fifth item-83 scenario; the focused build lacks w4Template.
- I did not import, run or count from `mutate.mjs`. I read `mutate.mjs.txt` only as text, through mcount.py.
- I used no Chromium and ran no playwright install.
- I did not probe the file:// sidecar branch.
- I did not edit the builder's suite or board. My proposed checks live only in `h/fx/h-cycreg-plus.mjs`, with the diff in
  `diffs/h-cycreg-plus.diff`.
- **Process slip.** At 9:25 AM ET I ran `node --check h/fx/h-cycreg-plus.mjs`, a syntax check only, without `setsid`/`timeout`
  and without first checking the lock. The lock was absent before and after, and the check finished at once. It is recorded in
  `pids.txt`.
- The helper Python commands (mcount, xread, mkvm2, mkplus) were bounded with timeouts or finished at once. Their PIDs were not
  captured individually.
