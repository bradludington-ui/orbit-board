# CYCREG, round 3: independent adversarial verifier, lens A (data loss and money)

**Verdict: sound-with-issues.** There is no must-fix. The money is exact on every route and shape I could build. That includes
the CLIN and per-service paths, which the CYCREG block does not drive. There is one should-fix (S1), with a tested one-line
sketch, and some minor items.

Written 13 Oct 2026, from 12:59 PM ET. This is the first attempt of this round: `verify-money-r3` did not exist when I started,
so nothing was reused from an earlier attempt of this review.

`<V>` = `/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/cycreg/verify-money-r3`
`<B>` = the builder's directory `.../rec/L6/cycreg`

## What was verified

The builder's proposal is `<B>/fr2/c1`.

| File | Blob |
|---|---|
| board | `59cff8f34a04d656604c352909966b27998f7384` |
| audit-recon | `03b7fda90c0a3dd6f90e02b19d731ebc6d7bd16d` |
| mutate.mjs.txt | `755c298941d34f83c52ee765d931f6345cd8d652` |
| audit-import, audit-board, audit-other | unchanged from base (`4aba2506`, `a7c575e5`, `d89396b0`) |

The base is `<B>/../base`: board `fce8a391`, audit-recon `529e36f7`, mutate `cbc6defc`.

My copies:

| Copy | Contents |
|---|---|
| `<V>/base` | `cp -a` of L6 base, byte-identical |
| `<V>/fix` | `cp -a` of `<B>/fr2/c1`, byte-identical, plus my harness copy `tools/export-audit/h-cycreg.mjs` |
| `<V>/sk1` | the fix plus my sketch for S1: board `9bdd33a893486002126a25bc5d5da5cc0df2f1d4`; diff in `out/sk1-vs-fix-board.diff`; built by `bin/mksk1.py` |

These are identical in base and fix:
- boot.mjs `9c4f49ad`
- runtime-encoding-shim.mjs `6e2ce2e6`
- runner `f851f139` (`bin/runner.mjs`, copied from `<B>/bin/runner.mjs`)

The harness is `h-cycreg.mjs` `26a9ee0c`, the builder's file. I checked with `bin/blockcheck.py` that it is verbatim from the fix's audit-recon:
- the CYCREG block (audit-recon lines 5126–5420) appears in it whole;
- every other line in it is an audit-recon line.

`diff -rq base fix` lists only the board, audit-recon, mutate.mjs.txt and my harness copy. The board diff (`fix-vs-base-board.diff`, 147 lines) is identical to the diff of the builder's own files.

## Hand-worked money (independent of the board)

**The block's fixture.** R1 asks USAF 900, ANG 200, AFRC 0. Pots are 5,000 each and mandatory is 0, so R1 is funded in full. The award is in FYMON[2]. Expected totals:
- USAF 900, ANG 200, all services 1,100;
- the NOT FUNDED Ask, with pots at 0: USAF 900, ANG 200.

**My CLIN fixture (probe/q1.mjs).** Pots are 5,000 each, there is no mandatory, and there are no award dates, so all money sits in NO DATE.
- PRIME_P asks [700, 251, 90], R asks [503, 127, 0] and Q asks [71, 0, 0]; all are funded in full.
- P's CLINs are n1 [401, 251, 31] and n2 [299, 0, 59].
- The pointers are: P on K4, with P's ANG on K2; R on K1, with R's ANG on K2; Q on none. CLIN n1's own choice is K1 and its AFRC is K3.

The rule is that the CLIN wins. Each dollar lands as follows:

| Service | Rows | Total |
|---|---|---|
| USAF | K1 = 401 (n1) + 503 (R) = 904; K4 = 299 (n2, P's own); none = 71 (Q) | 1,274 |
| ANG | K1 = 251 (n1's choice beats P's ANG K2); K2 = 127 (R) | 378 |
| AFRC | K3 = 31 (n1); K4 = 59 (n2) | 90 |
| All services | 1,274 + 378 + 90 | 1,742 |

A list entry only names a combination. Repeating K1 or K4 with other codes, or adding an entry keyed `__none__`, adds no money. Every row sits under the codes of the first entry with its key.

In case W-none-ptr, CLIN n2 points at the entry keyed `__none__` (55555 / EEEEE). Then n2's USAF 299 and AFRC 59 sit under 55555 / EEEEE, and the totals are unchanged.

## Findings

### SHOULD-FIX S1: the full import keeps the user's own board out for a harmless entry in the working plan's list

The trigger is an entry that is not a combination and is not null: `"K9"`, `5` or `[]`.

The fix's own-board mode refuses every non-combination entry in a working plan's list. The draft justifies this with "which every reader of that list stops at". That is true only for `null`.

Reproduction: probe/q2.mjs part A (logs/Q2.log, 1:12 PM ET; re-run with the current probe blob as Q2-fix-rerun.log, 1:23 PM ET, same output). For each of `["K9", K1]`, `[5, K1]` and `[[], K1]` in the working plan, with R1 on K1:
- **On base,** the board holding it renders its 🗂 RCN / EEIC panel. It exports USAF 900, ANG 200 and all services 1,100, matching the hand figures. Its saved file reopens the same way.
- **The fix's ⬅ Import a full board** of that base-saved file into the user's own board returns false. Its alert reads: "“mine.html” was not imported: the RCN / EEIC entry at the saved state.appns.om.rcn[0] is not a combination (“"K9"”); a list holds combinations and nothing else. … No ORBIT makes such an entry, though one before this could take it from a file without a word and save it with its board. Nothing on this board was changed." It offers no remedy, and the whole board stays out of the new version.
- **A fix board holding the same list** reads it without trouble: the panel renders and the export is 900 / 200 / 1,100.
- **The contrast case, `[null, K1]`:** the panel and the export throw "Cannot read properties of null (reading 'k')" on base and on the fix alike. Refusing null is justified.

This is the same class as round 2's S1 (a null entry in a locked cycle's list), which the builder fixed for cycles only. No copy is lost, because nothing is replaced, so this is not a must-fix. The trigger is a hand-made file. It does break principle 1's intent ("a whole board kept out of the new version"), and principle 4: the draft's "which every reader of that list stops at" is false for these shapes.

**Minimal fix (sketch sk1, tested).** It changes one condition in inShapeWhy, plus a comment:

```js
const r=rcnListOdd(o.rcn).filter(function(x){ return x.entry? !(_inRcnOwn && (cy || o.rcn[x.i]!==null)) : !_inRcnOwn; })[0];
```

Evidence that it holds:
- **Q2-sk1 (1:19 PM ET):** the full import takes each of the three boards. Its question says "O&M working plan’s list holds rcn[0], which is not a combination (“"K9"”) …". The board reopens, the panel renders and the export is 900 / 200 / 1,100. After saving and reopening, the export is the same. `[null, K1]` is still refused, word for word as before.
- **VR3-sk1 (1:20 PM ET):** the CYCREG block passes 142 of 142, and its recorded values are byte-identical to the fix's.
- **mcount on sk1:** the base mutate finds 1,328 of 1,328. The fix's mutate finds 1,356 of 1,358: `v200-cycreg-own-takes-entry` and `v200-cycreg-own-cycle-entry-refused` need their finds retargeted to the new line, for example `return x.entry? !_inRcnOwn : !_inRcnOwn;` and `return x.entry || !_inRcnOwn;`. These are the builder's own new entries, not base entries.

The builder should also:
- add a block check: the user's own board with `["K9", K1]` is taken, and it exports 900 / 200 after reopening and after saving and reopening;
- add a mutation that restores `!(_inRcnOwn && cy)`;
- correct the NEXT-VERSION draft's "which every reader of that list stops at" to say null.

### Minor

- **m1, words for a locked cycle's number key.** The full import's sentence "Each requirement reads the first entry with its key" is false when a locked cycle's list holds a key that is not text.
  - Reproduction (Q2 part B): PB27 holds `[{k:1} 11111/AAAAA]`, and R1 is on the number 1 in that cycle.
  - The question names the entry, then says R1 "reads the first entry with its key". In PB27's view the list as read is `[]`, because cycRcnOf leaves the entry out. The screen names R1's combination "(none)", and the sheet prints USAF 900 / ANG 200 as not assigned.
  - The money is right, and the screen and sheet agree with each other and with base. Only the sentence is untrue, and only for a hand-made file.
  - Suggested wording: "(a locked cycle's list leaves out an entry whose key is not text)".
- **m2, the refusal's advice.**
  - (a) For a package, submittal or band ladder, the advice names ⬅ Import a full board. That route says "“return.json” is not a board file" (q3, Q3.log).
  - (b) "can be put right on the board that holds it, in 🗂 RCN / EEIC" is true on this version, where ✕ on a "⚠ repeats row 1" row removes it alone. On an earlier ORBIT, ✕ on the repeated row clears every assignment to that key; its question says so (VR3-base, check "a row that repeats a key · ✕ on row 2").
  - Suggested wording: "…on a board of this version, ✕ on the row marked ⚠ repeats".
- **m3, files sent from a board the full import left with such a list.** Every other board refuses them, and nothing warns at export time. Probe q3 sends a return package from a fix board with `[K1, K1]`; the receiving board refuses it, word for word, with storage unchanged (no keys changed). Nothing is lost. The full import's question does say "which a file handed over is refused for". The builder disclosed this.
- **m4, already disclosed (not re-litigated):**
  - the menu's "N combos" count and the pickers list a repeated key's rows as they are;
  - ppLineAdd can make same-millisecond keys (PPBE totals deduplicate by key: ppKeysOf, read);
  - a null entry in a working plan's list still breaks the panel and the export, as on base;
  - ✕ on the FIRST row of a repeated key clears its assignments, as asked.

## Confirmed independently

- **The CYCREG block.**
  - VR3-fix: ALL CHECKS PASSED, 142 of 142.
  - VR3-base: 86 fail and 56 pass, with USAF 1,800 / ANG 400 / all services 2,200 from the bytes.
  - Both per-check records (`out/VR3-*.checks.jsonl`) are byte-identical to the builder's FX3-fix and FX3-base records.
- **The CLIN and per-service paths, not driven by the block (q1).** Seven cases were each run on three routes: opened directly; ⬅ Import a full board into the user's own board with the same browser reopened; and saved and reopened. The cases are the control and PB27's control, `[K1, K2, K1x, K3, K4, K4x]` and `[…, "__none__"]` in the working plan and in PB27, and `"__none__"` with CLIN n2 pointing at it.
  - **The fix:** 22 of 22 pass against the hand table, the PRIME CONTRACTS section included. Every other sheet of every workbook is identical to its control's. In W-none-ptr only the RCN-EEIC sheet differs, as expected: n2 sits under 55555 / EEEEE, which is where the screen shows it.
  - **The base:** 15 fail. The duplicates give USAF 2,477 and all services 3,255 (K1 904 and K4 299 printed twice, ANG K1 251 twice). `"__none__"` gives USAF 1,345 and all services 1,813 (Q's 71 printed under 55555 and again as not assigned). The `"__none__"` pointer gives USAF 1,644 and AFRC 149 (370 and 59 printed twice).
  - **The words:** the full import's question names each list ("holds the key “K1” twice (rcn[0] and rcn[2]), holds the key “K4” twice (rcn[4] and rcn[5])").
- **Independent XLSX reader.** `bin/q1read.py` uses Python zipfile and xml only, nothing from the board. It read the 42 dumped workbooks (`out/xlsx`). All 21 fix workbooks match the hand literals, NO DATE and TOTAL included. The base ones show the doubled totals above, and its controls match.
- **The task's three mutations,** rebuilt by mkmut.py (text only). Each mutant's blob is identical to the builder's.

  | Mutation | Failing checks of 142 |
  |---|---|
  | `v200-cycreg-keys-repeat` (drop the uniqueness) | 14 |
  | `v200-cycreg-key-as-name` (a key equals the sentinel) | 28 |
  | `v200-cycreg-door-open` (drop the import refusal) | 24 |

  These match the builder's counts.
- **mcount (text only).**
  - The fix's mutate on the fix board finds 1,358 of 1,358 once.
  - The base mutate on the fix board finds 1,328 of 1,328.
  - The fix's mutate on the base board finds 1,329 once; the 29 others are new finds absent from base.
  - The new entries sit right before the line "// v2.00 (R3, Brad 11 Oct): a save that lands under a locked view …".
- **Principle 6.** The diff of every suite file against base removes 0 lines: audit-recon adds 295, mutate adds 91, and the others are unchanged.
- **No leak of the own-board mode.** `_inRcnNext` is set immediately before inboundCheck (fullImportText) or inside inboundCheckOwn, and inboundCheck consumes it on its first line. inWalk and inShapeWhy have no caller outside inboundCheck (grep). A stale 'board' or 'copy' cannot reach a file handed over.
- **No other export or on-screen total doubles.** The 14 `rcnReg()` sites and the direct `MS.rcn` reader (code-length check) were re-read. The SI sheet walks the fixed SI_CODES. cycProjOf carries no RCN. PPBE totals deduplicate by key.
- **The whole audit-recon on the fix** (S-audit-recon-fix, 1:22 PM ET, exit 0, 374.5 s): ALL CHECKS PASSED.

## The lead's six principles, checked literally

1. **Never lose any copy of anyone's work.**
   - Met for every route: a refusal takes nothing and storage is byte-identical (q3; the builder's block); the full import asks before replacing; ✕ on a repeated row removes that row alone, as asked.
   - Exception S1: a user's own board is kept out of the new version for a harmless entry. No copy is lost, but the board cannot come across.
2. **Refuse or ask rather than guess.** Met. The door refuses, and the full import asks and says what it takes.
3. **Money and every export match the computation exactly.** Met on every case and route I built, from the bytes, with two readers.
4. **Every word stays true, including after the operation lands.**
   - Met, except for these:
     - "which every reader of that list stops at" in the draft (S1);
     - the full import's sentence for a cycle's number key (m1);
     - the advice's routes for packages and older boards (m2).
   - All three come from hand-made shapes or narrow cases.
5. **The smallest change that closes the finding.** Broadly met. monSheet is base plus one line used three times, and the naming moved to the caller.
6. **Every existing check, fixture and expected value is preserved.** Met (0 removed lines; base mutate 1,328 of 1,328 on the fix).

## Runs (all through bin/run.sh: `setsid -w timeout -k 10 600`, the lock checked before each; it was never present)

Times are Eastern Daylight Time. Never more than two of my node processes ran at once (checked against the start and end times below).

| Label | Start (ET) | Exit | Wall (s) | Result |
|---|---|---|---|---|
| VR3-fix | 13:05:49 | 0 | 291.6 | ALL CHECKS PASSED, 142 of 142; record identical to the builder's FX3-fix |
| VR3-base | 13:05:51 | 1 | 295.3 | 86 fail, 56 pass; record identical to FX3-base |
| Q1-fix | 13:10:58 | 0 | 61.6 | 22 pass, 0 fail (CLIN, per-service, 7 cases × 3 routes) |
| Q1-base | 13:10:59 | 1 | 58.9 | 7 pass, 15 fail (the doubled totals above) |
| Q2 | 13:12:32 | 0 | 44.3 | S1 and m1 reproduced (probe blob since edited; see Q2-fix-rerun) |
| VR3m-v200-cycreg-keys-repeat | 13:15:02 | 1 | 234.7 | caught, 14 failing |
| VR3m-v200-cycreg-key-as-name | 13:15:03 | 1 | 234.1 | caught, 28 failing |
| VR3m-v200-cycreg-door-open | 13:19:09 | 1 | 181.0 | caught, 24 failing |
| Q2-sk1 | 13:19:10 | 0 | 33.6 | sk1 takes the K9 / 5 / [] boards, still refuses null; 900 / 200 / 1,100 after reopen and save |
| VR3-sk1 | 13:20:36 | 0 | 172.9 | ALL CHECKS PASSED, 142 of 142, values identical to the fix |
| S-audit-recon-fix | 13:22:12 | 0 | 374.5 | the whole audit-recon on the fix: ALL CHECKS PASSED (448 recorded checks, 0 failing) |
| Q2-fix-rerun | 13:23:34 | 0 | 35.7 | the current q2 blob on the fix; output identical to Q2 |
| Q3 | 13:24:35 | 0 | 7.3 | a refused return package: the advice's full import says "not a board file"; storage unchanged |

Python helpers, text only, each run with `setsid -w timeout -k 10`:
- q1read.py (13:12:26, exit 0);
- mcount × 4 (13:14:06) and × 2 on sk1 (13:19:52);
- mkmut × 3;
- mksk1.py and blockcheck.py (`3624eed0`).

Logs are in `<V>/logs`, and per-check records are in `<V>/out/*.checks.jsonl`.

Blobs:
- probe/q1.mjs `abbdf038`
- probe/q2.mjs `a91929e8` (current; Q2 at 13:12 ran an earlier version without the reopen-after-import lines, so Q2-fix-rerun repeats it)
- probe/q3.mjs `345c3392`
- bin/q1read.py `a06d9138`
- bin/mksk1.py `8f925304`
- bin/run.sh `1b6f09ca`
- mutants: door-open `ded823cc`, key-as-name `9c3feec8`, keys-repeat `e0255273`

## PIDs

`<V>/pids.txt` records each run's timeout PID and node PID with its label and command. Nothing was killed.

## Decisions

- **S1 is a should-fix, not a must-fix.** No copy is lost and the trigger is a hand-made file. Round 2 rated the same class for cycle lists a should-fix and the builder fixed it. The tested sketch is one condition.
- **Minor items, not should-fixes:** m1 to m3 are words-only or disclosed workflow limits on hand-made shapes, and no figure is wrong in any of them.
- **Whole audit-recon on sk1 not run.** The sketch changes one condition reachable only through fullImportText. The CYCREG block, which drives that function, passed in full.

## Not done

- The full audit-import.mjs and audit-board.mjs were not run; the lead runs those alone.
- These suites were not re-run, because the board change does not touch their paths and the builder's runs on these blobs passed: audit, audit-other, audit-ppt, audit-hostile, audit-inject, legacy-fsrc, boot-same and npm run check.
- Of the builder's 30 mutants, only the task's three were re-run.
- Chromium was not used.
- mutate.mjs was never imported or run; it was read as text only (mcount.py, mkmut.py).
- Nothing was edited, staged, committed or pushed in /home/user/orbit-board or /home/user/orbit-ui; git was only read (log/show).
- The builder's files were not edited.
