# CYCREG, round 2: independent adversarial verifier, lens A (data loss and money)

**Verdict: sound-with-issues.** One must-fix (M1) is a regression in an exported code. Two should-fixes and some minor items follow.

Written 13 Oct 2026, from 9:32 AM ET. This review was resumed after a usage-limit stop: the earlier attempt ran from 5:49 to 6:00 AM ET, and the container restarted at 9:11 AM ET.

`<V>` = `/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/cycreg/verify-money-r2`
`<B>` = the builder's directory `.../rec/L6/cycreg`

## What was verified

The builder's proposal is the fix-round copy `<B>/fr/c1`:

| File | Blob |
|---|---|
| board | `19e6e508` |
| audit-recon | `08970371` |
| mutate.mjs.txt | `0cfd2487` |
| audit-import, audit-board, audit-other | unchanged from base (`4aba2506`, `a7c575e5`, `d89396b0`) |

The base is L6 base (orbit-board `7ee498a`, product `d66dd60`): board `fce8a391`, audit-recon `529e36f7`, mutate `cbc6defc`.

My copies:

| Copy | Contents | Blob |
|---|---|---|
| `<V>/base` | the base, byte-identical | |
| `<V>/fix` | `<B>/fr/c1` byte-identical, plus my harness copies (below) | |
| `<V>/sk2` | the fix plus my sketch for M1 | board `e72c6406` |
| `<V>/sk1` | the earlier attempt's sketch, superseded (see Decisions) | board `55ea2147` |

The following are identical in all three copies:
- boot.mjs `9c4f49ad`
- runtime-encoding-shim.mjs `6e2ce2e6`
- runner `f851f139`

## Harnesses

- **CYCREG block.** `<V>/harness/h-cycreg.mjs` (`79383d34`) is a copy of `<V>/fix/tools/export-audit/h-cycreg.mjs`. It is the builder's focused harness `393bc9c6` and differs from it only in line 1, the comment naming its source path. It is built verbatim from the fix's audit-recon.
- **audit-board blocks.** The focused harnesses `hb-83.mjs` (`4577d6a8`) and `hb-v197w1.mjs` (`3893ed4b`) were copied unchanged from `<B>/gc/fr/tools/export-audit` into `<V>/fix/tools/export-audit`.

## Hand-worked money (independent of the board)

The fixture:
- Requirement R1 asks USAF 900, ANG 200, AFRC 0.
- Discretionary pots are 5,000 each and mandatory is 0, so R1 is funded in full: USAF 900, ANG 200, AFRC 0.
- The award is single, in FYMON[2], so every dollar sits in that month's column (sheet column 3). Nothing is in NO DATE.

The totals:
- Service totals are USAF 900, ANG 200, AFRC 0.
- All services: 900 + 200 + 0 = 1,100.

A list entry only names a combination. Whatever the list holds, USAF can never exceed 900 and ANG can never exceed 200.

The base reproduces Codex: **USAF 1,800 and ANG 400** (all services 2,200).
- Case C1, PB27 [K1, K1]: K1's row is printed twice.
- Case C2a, [K1, "__none__"] with R1 on no combination: the money is printed under "22222 / BBBBB" and again as not assigned.

This holds through the product's own Import one appropriation and Import a full board, after reopening, and after save and reopen. The XLSX bytes were read with the board's own `xlsxRead`, used only as an observer. Log: logs/pa-base.log.

## Findings

### MUST-FIX M1: the RCN-EEIC sheet files money under the wrong code for a number key or number pointer (a regression against base)

The fix lets in only keys that are text:

```js
const keys=keysOf().filter(function(k,i,a){ return typeof k==='string' && a.indexOf(k)===i; });
```

It still finds a bag by the pointer's name, through `known`. The screen, and the Spend Plan Source sheet in the same workbook, resolve a pointer as `rcnEntry` does: the first entry with `e.k===k`.

Reproduction: probe/pb2.mjs, using ⬅ Import a full board, which the fix takes for the user's own board, and the workbook read from its bytes. Logs: pb2-1.log (5:57 AM ET) and pb2-sk2.log (9:23 AM ET).

| Case | Screen | Spend Plan Source | Base RCN-EEIC sheet | Fix RCN-EEIC sheet |
|---|---|---|---|---|
| B1: list `[{k:1} 11111/AAAAA]`, R1 on the number 1 | 11111 / AAAAA | 11111 / AAAAA | 11111 / AAAAA, 900 | **"— no RCN/EEIC assigned —", 900** |
| B2: list `[{k:1} 11111, {k:"1"} 22222]`, R1 on 1 | 11111 / AAAAA | 11111 / AAAAA | both rows, 1,800 | **22222 / BBBBB, 900** |
| B3: list `[{k:"1"} 22222]`, R1 on 1 | (none) | (none) | 22222 / BBBBB | 22222 / BBBBB (as on base) |

The money totals are right, but the code is wrong, and the workbook contradicts itself. B1 was right on base.

Three statements are false for such a board:
- **The full import's question and its reopened report** say "the RCN-EEIC sheet counts each key once". A number key is counted zero times and its money is moved to not assigned.
- **The NEXT-VERSION draft** says the sheet knows text keys "as the board finds a combination by its text key". `rcnEntry` finds any key by `===`.

These break principles 3 and 4.

The builder's draft lists this under "Not covered", but a known wrong code in an export conflicts with "every exportable product must be 100% correct".

**Minimal fix, tested: sketch 2** (`<V>/bin/mksk2.py`; diff in `<V>/out/sk2-vs-fix-board.diff`). monSheet itself is untouched. The RCN sheet's caller names each combination by where the board finds it:

```js
const rcnAt=function(p){ const L=rcnReg(); if(!p) return ''; for(let i=0;i<L.length;i++) if(L[i] && L[i].k===p) return 'e'+i; return ''; };
```

`keysOf` maps each entry to `rcnAt(e && e.k)`; `labelOf` is `rcnLabel(rcnReg()[i].k)`; `keyOfReq` and `clinOf` wrap their pointer in `rcnAt`.

Evidence that sketch 2 holds:
- **The builder's CYCREG block** passes all 90 checks with byte-identical recorded values (VF-sk2; `cmp` of the checks files gives "same").
- **The whole audit-recon** prints ALL CHECKS PASSED (S-audit-recon-sk2).
- **The focused audit-board blocks** give identical values: v1.97 W1 178, and v1.98 item 83 21 (its fifth scenario lacks `w4Template` on both boards).
- **Mutation finds** match exactly once: mcount gives 1,350 of 1,350 for the fix's mutate and 1,328 of 1,328 for the base mutate.
- **The money** is 900 / 200 / 1,100 in every shape of pa (C1, C2a, C2b and the controls) and of r1/vprobe3 (W1, W2, P1).
- **B1 and B2** now match the screen and the Spend Plan Source; B3 is not assigned, as the screen says.
- **The export no longer throws** for keys named "constructor", "toString" or "valueOf" (pc-sk2).

Adopting sketch 2 has costs for the builder:
- Two of the builder's mutants become equivalent, because no token can equal "__none__" and every token is text. `v200-cycreg-none-is-text` and `v200-cycreg-keys-by-value` both give ALL CHECKS PASSED (VFm-sk2-*). Retarget them at `rcnAt`, for example by making it return the raw pointer, or by setting NONE to `'e1'`.
- `v200-cycreg-keys-repeat` is still caught, with 9 failing checks.
- Add B1 and B2 checks with literal labels. B1 is a regression guard: it passes on base and fails on the fix. B2 fails on base with 1,800 / 400 and on the fix with the wrong label.

The earlier attempt's sketch 1, which changed monSheet itself, is not proposed. It breaks the finds of two existing v1.98 mutations (`v198-roll-unknown-dropped`, `v198-breakout-label`) and three of the builder's.

### SHOULD-FIX S1: the full import refuses the user's own board for a null entry in a locked cycle's list, which every reader already skips

Reproduction: probe/pb.mjs case C (pb-1.log, 5:54 AM ET).
1. A base board takes a cycle whose PB27 list is [null, K1]; base's door passes it.
2. On that base board, the PB27 view and the workbook work: 900 / 200 / 1,100.
3. Base's own full import of that saved board works, and PB27 exports 900 / 200.
4. The fix's ⬅ Import a full board refuses the whole board (every appropriation, cycle and log) with "the RCN / EEIC entry at the saved state.cycDb.byAp.om.cycles.PB|2027.rcn[0] is not a combination (“null”)".

There is no remedy in the product, because a locked list cannot be edited.

The builder's stated reason, "which the board cannot read", is true for the working plan's list but false for a cycle's list: `cycRcnOf` drops entries that are not objects with a text key. This is the r1 M3 class (a user's own board kept out of the new version) for one more shape.

Minimal fix (untested sketch): in the 'board' mode of the inShapeWhy rule, apply the entry rule only to a working plan's list, not a cycle's. Let the question's `rcnSay` line say what the cycle's list holds; rcnListOdd already reports `is not a combination (null)`.

### SHOULD-FIX S2: the refusal's advice sends a one-appropriation file into a whole-board replace

Reproduction: probe/pd.mjs (pd-fix.log and pd-base.log, 9:18:59 AM ET).
1. A fix board holds a repeated key, as the fix's own full import allows; cycLock copies it into PB27. The board holds BAE rows for O&M and OPN, and execution data for O&M and OPN.
2. Its own "O&M only" export is refused by its own door, and by every teammate's.
3. The refusal advises "a board of your own comes across whole ... with 📁 File → ⬅ Import a full board".
4. Taking that file by ⬅ Import a full board replaces this board's BAE list (the OPN row is gone) and its execution data (OPN is gone) with the file's O&M-only subset.

The question does list "The BAE list — 1 row / Execution data — 1 appropriation" under "This REPLACES", so nothing is lost silently. On base, Import one appropriation takes the same file and keeps OPN.

Two minimal fixes:
- Offer the full-import advice only when the refused file is a full board, or say in the advice that a full import replaces this board's BAE list and execution data.
- Optionally warn at export time when a list the receiving door refuses is about to be written.

### Minor (no must-fix)

- **Keys every object answers to.** A key named "constructor", "toString" or "valueOf" in a board's own list makes exportExcel throw "Cannot read properties of undefined (reading 'reduce')" (or reading '0') on both base and fix (pc-base, pc-fix). It can only arrive in a hand-made file opened directly: every door refuses it as "a name every object already answers to" (pc H1, F1). This is pre-existing; sketch 2 also fixes it (pc-sk2).
- **Pickers and the menu.** The menu's "N combos" counts entries (2 for [K1, K1]) although the fix's own words say "a key names one combination". The pickers and the bulk-set options list a repeated key twice with the same label. The builder disclosed this.
- **Same-millisecond keys in PPBE lines (by reading only, not run).** `ppLineAdd` keeps the same-millisecond key pattern that rcnAdd had. PPBE totals deduplicate keys by name (`ppKeysOf`), so no total doubles; the editor would show a duplicated line's figures on two rows.

### Confirmed (the builder's claims, independently)

- **The two Codex shapes are refused at the door.** Import one appropriation refuses both, word for word as drafted. Nothing in storage changes (pa-fix: storage keys changed `[]`).
- **The full import takes the user's own board and says what its lists hold.** The PB27 export after reopening, and after saving and reopening, is 900 / 200 / 1,100. Every sheet of the workbook matches its control (pa-fix).
- **The controls export 900 / 200 on base and on the fix.**
- **The shared-folder routes work.** Folder saves, teammate refresh, Take the pen and teammate saves all land (r1v4-fix, r1v5-fix).
- **The upgrade route works.** A base-saved board with [K1, K1] is taken by the fix's full import (r1v6-fix).
- **✕ on a repeated row removes that row alone**, as its question says (r1v4-fix).
- **No other export or on-screen total walks the registry for money.** The 14 `rcnReg()` sites were read: panel, cycLock, pickers, bulk options, option builder, menu count and the RCN sheet. Other surfaces resolve one pointer with `rcnEntry`. The SI sheet walks the fixed SI_CODES. PPBE totals deduplicate by name. On base, only "RCN-EEIC by Month" differs from the control (pa-base, every sheet compared).
- **Principle 6.** The audit-recon and mutate diffs against base remove nothing (0 removed lines). The base mutate matches 1,328 of 1,328 finds on the fix board; the fix mutate matches 1,350 of 1,350.

## The lead's six principles, checked against the fix as it stands

1. **Never lose work.** Met, except S1: a user's own board is kept out for a harmless null entry in a cycle list.
2. **Refuse or ask.** Met at the door.
3. **Money and exports exact.** Money is exact; the code is wrong for number keys and pointers (M1).
4. **Words true.** "counts each key once" is false for number keys (M1). "as the board finds a combination by its text key" in the draft is false. The S2 advice misleads for a one-appropriation file.
5. **Smallest change.** Broadly met.
6. **Checks preserved.** Met.

## Runs (all through bin/run.sh)

Every run used `setsid -w timeout -k 10 600` and the lock check (the lock was never present). Times are Eastern Daylight Time.

Stopped attempt, reused (same blobs, each with an exit record):

| Label | Start (ET) | Exit | Wall (s) | Result |
|---|---|---|---|---|
| VF-fix | 05:49:22 | 0 | 49.4 | ALL CHECKS PASSED, 90 checks |
| VF-base | 05:49:22 | 1 | 49.5 | 50 failing, USAF 1,800 / ANG 400 |
| pa-fix | 05:50:55 | 0 | 24.0 | |
| pa-base | 05:50:55 | 0 | 24.5 | |
| pb-1 | 05:54:18 | 0 | 31.0 | |
| pb2-1 | 05:57:10 | 0 | 23.9 | |
| pb2-sk1 | 05:58:16 | 0 | 21.0 | |
| pa-sk1 | 05:58:16 | 0 | 29.6 | |
| VF-sk1 | 05:58:16 | 0 | 56.1 | |
| r1v6-fix | 05:59:28 | 0 | 20.3 | |
| r1v4-fix | 05:59:28 | 0 | 25.4 | |
| r1v5-fix | 05:59:28 | 0 | 26.1 | |
| r1v2-fix | 05:59:28 | 0 | 28.2 | |
| r1v3-fix | 05:59:28 | 0 | 34.5 | |

Resumed attempt:

| Label | Start (ET) | Exit | Wall (s) | Result |
|---|---|---|---|---|
| pd-fix | 09:18:59 | 0 | 16.0 | S2 |
| pd-base | 09:18:59 | 0 | 16.2 | |
| pc-base | 09:18:59 | 0 | 17.7 | the export throws for constructor / toString / valueOf |
| pc-fix | 09:18:59 | 0 | 18.3 | the same |
| S-audit-recon-sk2 | 09:23:21 | 0 | 271.8 | ALL CHECKS PASSED |
| S-audit-recon-fix | 09:23:21 | 0 | 279.6 | ALL CHECKS PASSED |
| pb2-sk2 | 09:23:25 | 0 | 16.4 | B1 / B2 / B3 consistent |
| VF-sk2 | 09:23:25 | 0 | 60.5 | ALL CHECKS PASSED, 90 checks, values identical to VF-fix |
| r1v3-sk2 | 09:24:35 | 0 | 36.7 | |
| pa-sk2 | 09:24:35 | 0 | 47.6 | |
| VFm-sk2-v200-cycreg-keys-repeat | 09:25:56 | 1 | 131.9 | caught, 9 failing checks |
| VFm-sk2-v200-cycreg-none-is-text | 09:25:56 | 0 | 132.4 | survives (equivalent under sketch 2) |
| VFm-sk2-v200-cycreg-keys-by-value | 09:25:56 | 0 | 135.9 | survives (equivalent under sketch 2) |
| FRB-hb-83-fix | 09:28:42 | 1 | 12.7 | 21 pass; the block threw on `w4Template` |
| FRB-hb-83-sk2 | 09:28:42 | 1 | 12.9 | identical to the fix |
| FRB-hb-v197w1-fix | 09:28:42 | 0 | 42.3 | 178 pass |
| FRB-hb-v197w1-sk2 | 09:28:42 | 0 | 42.3 | identical |
| pc-sk2 | 09:31:48 | 0 | 7.2 | |

Python helpers, text only, each bounded by setsid/timeout:
- mcount, 09:21:29 ET: fix mutate on the fix board 1,350 of 1,350 once; on sk1 1,345 (five missing).
- mcount, after building sk2: 1,350 of 1,350 and 1,328 of 1,328 on sk2.
- mcount, 09:31:20 ET: base mutate on the fix board 1,328 of 1,328.
- mksk2.py built sk2.
- mkmut.py built three mutants of sk2.

Every log is in `<V>/logs`, and per-check records are in `<V>/out/*.checks.jsonl`.

## PIDs

`<V>/pids.txt` holds each node run's timeout PID and node PID with its command (64 lines). Nothing was killed.

The bounded python3 helper commands (mcount, mkmut, mksk2) and the cp / diff / grep commands were not recorded in pids.txt.

## Decisions

- **Reused the stopped attempt's runs.** Their boards, harness and probes are byte-identical, and each run has an exit record. pd.mjs had been written but never run, so it was run now.
- **Replaced sketch 1 with sketch 2.** Sketch 1 breaks existing v1.98 mutation finds, which violates principle 6. Sketch 2 leaves monSheet byte-identical.
- **Classified M1 as must-fix.** It is a wrong code in an export, a regression against base, and it falsifies the import's own words. A small tested fix exists.
- **Classified S1 and S2 as should-fix.** No money is misstated, nothing is changed silently, and the trigger is a hand-made file.

## Not done

- The full audit-import.mjs and audit-board.mjs were not run; the lead runs those alone.
- audit, audit-other, audit-ppt, boot-same, legacy-fsrc, audit-hostile, audit-inject and npm run check were not re-run. The builder ran them in `<B>/gc/fr`, all exit 0. I re-ran only audit-recon whole, on both the fix and sk2.
- The builder's 22 mutants were not re-run on the fix; the tests-lens verifier covers that. Three of them were run on sk2.
- The S1 fix sketch is untested.
- Chromium was not used.
- mutate.mjs was never imported or run: it was read as text only, through mcount.py and mkmut.py.
- Nothing was edited, staged, committed or pushed in /home/user/orbit-board or /home/user/orbit-ui.
- The builder's files were not edited.
