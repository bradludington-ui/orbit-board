# CYCREG — independent verifier, round 1, LENS B (test adequacy and regressions)

All times Eastern (`TZ=America/New_York date`). Resumed 12 Oct 11:13 PM ET after the usage limit. The earlier attempt of
this verifier (8:42–8:46 PM ET) had built the copies, the focused harness and my mutants, and run F-c1, F-base and part of
one mutant. Its processes were gone (container restarted). Its `logs/` and `out/` are kept in `attempt1/`. **Every result
below was re-run in this session.** Nothing from attempt1 is relied on.

## Verdict
**unsound** until one product defect is fixed, and needs two missing money checks. Details below.
- **MUST-FIX 1 (money, product): the fix still lets ONE combination be counted twice, through Import a full board.**
- **MUST-FIX 2 (tests):** two of the commit's money-bearing changes have no check. A plausible wrong fix of either ships
  doubled money and passes every suite I may run.
- The builder's own claims re-ran exactly as stated (focused 31/31 on c1; 17 pass / 14 fail on base; 6/6 mutants caught;
  mcount 1328/1334). The 14 fail on base with $1,800 / $400. An independent XLSX reader agrees with the suite's reader.

## Copies (mine, read-only inputs untouched)
| copy | board | audit-recon | mutate.mjs.txt | other suites |
|---|---|---|---|---|
| `b0` = `../../base` (7ee498a, product d66dd60) | fce8a391 | 529e36f7 | cbc6defc | import 4aba2506, board a7c575e5, other d89396b0 |
| `c1` = builder's `../c1` (cp -a) | 2f9219a4 | 9c2cdd88 | bfb87708 | unchanged |
`diff -rq ../../base c1` lists only those three files. `diffs/c1-vs-b0-*.diff` (board: 7 lines out, 28 in; audit-recon: 0 out,
128 in; mutate: 0 out, 19 in) are identical in content to the builder's `diffs/c1-*.diff`.
`gc/b0`, `gc/c1`: `git clone --shared /home/user/orbit-board` checked out at 7ee498a, c1's board and audit-recon copied in
(used only for `tools/check.mjs`, which asks git). Never committed to. node_modules is a symlink.

## Existing expectations changed?
None. The audit-recon diff is one hunk of pure additions after `// ==== end v2.00 (U14) ====`; mutate.mjs.txt is pure
additions before the R3 line; no other suite file differs.

## Every new check: fails on base, passes on c1 (my runs V-F-base / V-F-c1)
All 14 non-control checks FAIL on base and PASS on c1; all 17 CONTROL checks pass on both (table in `out/V-F-*.checks.jsonl`,
from the runs at 11:15 PM ET).
The WHOLE c1 audit-recon run against the base board (V-SM-audit-recon-base-board-c1-suite, 11:30:21 PM ET, exit 1, 461.1 s)
fails exactly these 14 checks and nothing else: the block runs inside the full suite and every other block passes on the base. Base got values carry USAF 1800 / ANG 400 / all 2200. Expected values are literals (900/200/0/1100,
the refusal sentences, `[2,2,true]`). Harness `h/c1/h-cycreg.mjs` (blob 2b5161a4): the CYCREG block is byte-for-byte the
block in c1's audit-recon (checked by script), every other line is a line of that suite.

## Independent read of the XLSX bytes (`h/c1/xprobe.mjs` 3f53164f, `bin/xread.py` b0579e48 = python zipfile + XML only)
By hand (the builder's fixture, re-derived): R1 asks USAF 900, ANG 200, AFRC 0; pots 5,000 each, so discretionary funds all
of it (fixture check: `tiers().R1.d=[900,200,0]`, `.m=[0,0,0]`); one award in FYMON[2]. So USAF 900, ANG 200, AFRC 0, all
services 900+200+0 = 1,100, all in the award month, NO DATE 0.
| case | base (USAF / ANG / all) | c1 |
|---|---|---|
| Codex 1 [K1,K1], file opened, PB27 | 1800 / 400 / 2200 (K1 row twice) | 900 / 200 / 1100 |
| Codex 1, Import a full board, reopened | taken; 1800 / 400 / 2200 | refused; user's own PB27 900 / 200 / 1100 |
| Codex 2 [K1,"__none__"], opened | 1800 / 400 / 2200 (22222/BBBBB + not assigned) | 900 / 200 / 1100 |
| Codex 2, imported, reopened | taken; 1800 / 400 / 2200 | refused; 900 / 200 / 1100 |
| control [K1,K2] | 900 / 200 / 1100 | 900 / 200 / 1100 |
| H1 working plan [K1,K1], opened | 1800 / 400 / 2200 | 900 / 200 / 1100 |
| H4 R1 unfunded on K1, working plan [K1,K1], NOT FUNDED Ask | USAF 1800 / ANG 400, K1 row twice | 900 / 200 |
| H5 R1 unfunded, on no combination | sheet present, NOT FUNDED worklist 900 / 200 | same |
| **H7 working plan [{k:1},{k:"1"}], R1 on "1", Import a full board, reopened** | taken; 1800 / 400 / 2200 | **taken; 1800 / 400 / 2200** |
| H7, saved and reopened | 1800 / 400 / 2200 | **1800 / 400 / 2200** |
| H7 control [{k:"1"},K2] | 900 / 200 / 1100 | 900 / 200 / 1100 |
| H2 door [K1,K2,K1] | passes | refused "(rcn[0] and rcn[2])" |
| H3 door "__x" | passes | refused "“__x” begins with two underscores" |
`out/xsum-c1-base.txt`, `out/xsum-holes.txt`, workbooks in `out/xlsx/`.

## MUST-FIX 1 — a number key and the same text key are one combination counted twice (c1 still exports $1,800 / $400)
The door's new check skips any key that is not text (`if(typeof k!=='string') continue;`), and monSheet's uniqueness is by
`indexOf` (strict), while the money is filed in `bag[g][k]` and `known[k]`, whose property names are text. So `1` and `"1"`
are two keys to the uniqueness test and ONE bag to the sheet. Reproduction (`h/c1/xprobe2.mjs` 7e0b2a3e, run XP-xprobe2-c1,
11:23:19 PM ET, exit 0): the user's board [K1]; a file whose working plan's list is `[{k:1,…},{k:"1",…}]` with R1 on `"1"`;
`inboundCheck` returns ""; `fullImportText` returns true; the same browser reopened and the saved file reopened both export
(read by xread.py): "44444 / DDDDD" 900 twice, **USAF TOTAL 1800, ANG TOTAL 400, ALL SERVICES 2200**, breakout totals the same.
(A locked cycle is safe: cycRcnOf keeps text keys only.) This is Codex's finding (one bag counted twice, via an import the
door accepts) surviving the fix, and it makes the drafts' "the RCN-EEIC sheet counts each key once" untrue.
**Minimal fix (verified, `mut/fixv/fixv.html` 7f718773, `diffs/fixv-vs-c1.diff`):**
- monSheet: unique by the bag's own name — `const seenK=Object.create(null), keys=keysOf().filter(function(k){ const s=String(k); if(seenK[s]) return false; seenK[s]=1; return true; });`
- door: `if(k===undefined || k===null) continue; if(typeof k!=='string') return 'the RCN / EEIC key at '+path+'.rcn['+i+'].k is not text ('+inShow(JSON.stringify(k))+'), and a key is text';`
On fixv: H7 import refused with those words, H7 opened 900/200/1100, Codex cases and controls unchanged, CYCREG block 31/31
(V-F-fixv, 11:27:59 PM, exit 0). Add an H7 case (refused at the door; opened → 900/200/1,100) and a mutation reverting each
half. (`v200-cycreg-keys-repeat`'s find must then follow the new line.)

## MUST-FIX 2 — two money paths the commit changed have no check (mutants survive every suite I may run)
- **NOT FUNDED (vm-pk-dup):** reverting only `const pk=keys.filter(…)` to `keysOf()` passes the CYCREG block (31/31) and the
  full audit-recon (V-SM-audit-recon-vm-pk-dup, 11:29:53 PM ET, exit 0, ALL CHECKS PASSED), yet with the list [K1,K1] and R1 unfunded the NOT FUNDED Ask is
  **USAF 1,800 / ANG 400**, K1's row twice (xread of `out/xlsx/xprobe-vm-pk-dup/h4-notfunded-dup-opened.xlsx`). The base does
  the same (1,800 / 400) and c1 gives 900 / 200, so this is a second doubled export of the same defect that the fix corrects
  with no check failing on the base.
- **The working plan's own list (vm-dedupe-at-view):** making the list unique in cycRcnOf (the cycle view) instead of in
  monSheet passes the block (31/31) and the full audit-recon (V-SM-audit-recon-vm-dedupe-at-view, 11:29:53 PM ET, exit 0), yet a file opened with the working plan's list [K1,K1] exports
  **1800 / 400 / 2200** (`out/xlsx/xprobe-vm-dedupe-at-view/h1-plan-dup-opened.xlsx`; base the same; c1 900/200/1100). The block
  checks the working plan's list only at the door.
**Minimal fix:** in the CYCREG block add (i) the file opened with the working plan's list [K1,K1] → 900/200/1,100 (and
saved-reopened), (ii) R1 unfunded on K1 with [K1,K1] → NOT FUNDED Ask 900 / 200, K1 row once — each with an ordinary-key
control; and mutation entries `v200-cycreg-notfunded-repeat` (pk walk back to keysOf) and a working-plan one. Both fail on base.

## SHOULD-FIX
- **vm-anymoney-pend-unseen survives everything:** dropping `|| !!p[NONE]` makes a board whose only requirement is unfunded and
  on no combination lose its RCN-EEIC sheet (the NOT FUNDED worklist) — base and c1 print it. Passes the block, full
  audit-recon, audit and audit-other. The Symbol made this clause load-bearing; only the bag half is pinned
  (`-none-money-unseen`). Add H5 as a check plus a mutation.
- **Door breadth untested:** vm-door-adjacent (repeat only when next to each other) and vm-door-eq-sentinel (refuse only
  exactly "__none__") survive. c1 refuses [K1,K2,K1] and "__x" correctly (H2, H3); add both as checks.

## MINOR
- vm-none-text-excluded (keep '__none__' text, leave it out of the key walk) survives; it is the alternative the builder
  rejected for the words, not the money. A case with R1 assigned TO an entry keyed "__none__" on an opened board would pin
  the builder's reason.
- The block reads the bytes with the board's own `xlsxRead` (through the suite's existing w6Book). My independent reader
  agreed on every row, so no defect, but the suite has no independent read here.
- Drafts (NEXT-VERSION, ledger, commit message) say the sheet "counts each key once" — untrue until MUST-FIX 1; "What users
  may see" does not mention the NOT FUNDED Ask figure falling.

## Mutants
Builder's six (built by me with mkmut.py earlier; blobs equal the builder's `mut/c1`): all caught —
keys-repeat 2, none-is-text 2, door-repeat 3, door-underscores 2, none-money-unseen 8, add-key-reused 1 (same counts as the builder).
Mine (`bin/mkvm.py` caf5ba73, each find matched once on c1; `diffs/mut-*.diff`):
| id | plausible wrong fix | result |
|---|---|---|
| vm-rollup-dup | rollup walks the list as is | caught 2 (Codex 1 opened, opened-saved) |
| vm-breakout-dup | breakout walks the list as is | caught 2 (same) |
| vm-pk-dup | NOT FUNDED walks the list as is | **SURVIVES** (block 31/31, full audit-recon) — NOT FUNDED Ask 1,800/400 |
| vm-dedupe-at-view | unique in the cycle view, not the sheet | **SURVIVES** (block, full audit-recon) — working plan 1,800/400 |
| vm-anymoney-pend-unseen | is-there-money misses pending not-assigned | **SURVIVES** (block, audit-recon, audit, audit-other) — sheet absent |
| vm-none-text-excluded | '__none__' text kept, left out of the key walk | survives (money right; words) |
| vm-door-eq-sentinel | refuse only "__none__" | **SURVIVES** |
| vm-door-adjacent | repeat only when adjacent | **SURVIVES** |
| vm-door-cycles-only | door checks cycle lists only | caught 1 (working plan at the door) |
| vm-door-plan-only | door checks the working plan only | caught 4 |
| vm-import-carries-on | Import a full board alerts but carries on | caught 2 |
| vm-add-plus-one | rcnAdd starts at length+1, no step | caught 1 |

## mcount (text only, rec/bin/mcount.py; mutate.mjs never imported or run)
base mutate on base 1328/1328 once; c1 mutate on c1 1334/1334 once (six new 1 each); base mutate on c1 1328/1328 once.
New entries sit before the R3 line (4289–4304; R3 comment 4307). mutate.mjs's SUITES include audit-recon, so they are reachable.

## Suites, c1 vs base (my copies; check.mjs in gc/)
audit-recon, audit, audit-ppt, audit-other, audit-hostile, audit-inject: ALL CHECKS PASSED on both; boot-same and
legacy-fsrc print their pass lines on both; check: "all checks passed" on both. Output identical line for line apart from
timings (check.mjs differs only in the board's line count). Not run: audit-import, audit-board (the lead's).

## Every run (label | start ET | exit | wall s | log) — see logs/runs.txt (copied below at the end of the session)
| label | start (ET) | exit | wall s | log | result |
|---|---|---|---|---|---|
| V-F-c1 | 2026-10-12 23:15:26 | 0 | 17.6 | logs/V-F-c1.log | ALL CHECKS PASSED |
| V-M-v200-cycreg-keys-repeat | 2026-10-12 23:15:26 | 1 | 18.1 | logs/V-M-v200-cycreg-keys-repeat.log | 2 FAILING CHECK(S) |
| V-F-base | 2026-10-12 23:15:44 | 1 | 12.8 | logs/V-F-base.log | 14 FAILING CHECK(S) |
| V-M-v200-cycreg-none-is-text | 2026-10-12 23:15:44 | 1 | 13.3 | logs/V-M-v200-cycreg-none-is-text.log | 2 FAILING CHECK(S) |
| V-M-v200-cycreg-door-repeat | 2026-10-12 23:15:57 | 1 | 10.7 | logs/V-M-v200-cycreg-door-repeat.log | 3 FAILING CHECK(S) |
| V-M-v200-cycreg-door-underscores | 2026-10-12 23:16:08 | 1 | 11.6 | logs/V-M-v200-cycreg-door-underscores.log | 2 FAILING CHECK(S) |
| V-M-v200-cycreg-none-money-unseen | 2026-10-12 23:16:20 | 1 | 12.6 | logs/V-M-v200-cycreg-none-money-unseen.log | 8 FAILING CHECK(S) |
| V-M-vm-pk-dup | 2026-10-12 23:16:29 | 0 | 18.7 | logs/V-M-vm-pk-dup.log | ALL CHECKS PASSED |
| V-M-vm-door-plan-only | 2026-10-12 23:16:29 | 1 | 19.9 | logs/V-M-vm-door-plan-only.log | 4 FAILING CHECK(S) |
| V-M-v200-cycreg-add-key-reused | 2026-10-12 23:16:32 | 1 | 18.4 | logs/V-M-v200-cycreg-add-key-reused.log | 1 FAILING CHECK(S) |
| V-M-vm-breakout-dup | 2026-10-12 23:16:48 | 1 | 13.6 | logs/V-M-vm-breakout-dup.log | 2 FAILING CHECK(S) |
| V-M-vm-anymoney-pend-unseen | 2026-10-12 23:16:49 | 0 | 13.6 | logs/V-M-vm-anymoney-pend-unseen.log | ALL CHECKS PASSED |
| V-M-vm-rollup-dup | 2026-10-12 23:17:02 | 1 | 13.8 | logs/V-M-vm-rollup-dup.log | 2 FAILING CHECK(S) |
| V-M-vm-dedupe-at-view | 2026-10-12 23:17:03 | 0 | 13.6 | logs/V-M-vm-dedupe-at-view.log | ALL CHECKS PASSED |
| V-M-vm-none-text-excluded | 2026-10-12 23:17:16 | 0 | 14.1 | logs/V-M-vm-none-text-excluded.log | ALL CHECKS PASSED |
| V-M-vm-add-plus-one | 2026-10-12 23:17:17 | 1 | 13.5 | logs/V-M-vm-add-plus-one.log | 1 FAILING CHECK(S) |
| V-M-vm-door-eq-sentinel | 2026-10-12 23:17:30 | 0 | 12.5 | logs/V-M-vm-door-eq-sentinel.log | ALL CHECKS PASSED |
| V-M-vm-door-adjacent | 2026-10-12 23:17:30 | 0 | 12.6 | logs/V-M-vm-door-adjacent.log | ALL CHECKS PASSED |
| V-M-vm-import-carries-on | 2026-10-12 23:17:43 | 1 | 12.3 | logs/V-M-vm-import-carries-on.log | 2 FAILING CHECK(S) |
| V-M-vm-door-cycles-only | 2026-10-12 23:17:42 | 1 | 12.9 | logs/V-M-vm-door-cycles-only.log | 1 FAILING CHECK(S) |
| XP-c1 | 2026-10-12 23:20:03 | 0 | 43.3 | logs/XP-c1.log | probe done |
| XP-base | 2026-10-12 23:20:46 | 0 | 46.7 | logs/XP-base.log | probe done |
| V-S-audit-recon-base | 2026-10-12 23:18:38 | 0 | 199.1 | logs/V-S-audit-recon-base.log | ALL CHECKS PASSED |
| V-SM-audit-recon-vm-anymoney-pend-unseen | 2026-10-12 23:18:38 | 0 | 232.7 | logs/V-SM-audit-recon-vm-anymoney-pend-unseen.log | ALL CHECKS PASSED |
| V-S-audit-recon-c1 | 2026-10-12 23:18:38 | 0 | 234.9 | logs/V-S-audit-recon-c1.log | ALL CHECKS PASSED |
| XP-xprobe2-c1 | 2026-10-12 23:23:19 | 0 | 12.5 | logs/XP-xprobe2-c1.log | probe done |
| V-S-audit-c1 | 2026-10-12 23:23:19 | 0 | 19.5 | logs/V-S-audit-c1.log | ALL CHECKS PASSED |
| XP-xprobe2-base | 2026-10-12 23:23:31 | 0 | 10.9 | logs/XP-xprobe2-base.log | probe done |
| V-S-audit-base | 2026-10-12 23:23:38 | 0 | 19.8 | logs/V-S-audit-base.log | ALL CHECKS PASSED |
| XP-xprobe-vm-pk-dup | 2026-10-12 23:23:42 | 0 | 28.9 | logs/XP-xprobe-vm-pk-dup.log | probe done |
| V-SM-audit-vm-anymoney-pend-unseen | 2026-10-12 23:23:58 | 0 | 17.8 | logs/V-SM-audit-vm-anymoney-pend-unseen.log | ALL CHECKS PASSED |
| V-S-audit-other-c1 | 2026-10-12 23:23:19 | 0 | 63.6 | logs/V-S-audit-other-c1.log | ALL CHECKS PASSED |
| V-S-audit-ppt-c1 | 2026-10-12 23:24:16 | 0 | 8.2 | logs/V-S-audit-ppt-c1.log | ALL CHECKS PASSED |
| V-S-audit-ppt-base | 2026-10-12 23:24:24 | 0 | 8.9 | logs/V-S-audit-ppt-base.log | ALL CHECKS PASSED |
| XP-xprobe-vm-dedupe-at-view | 2026-10-12 23:24:11 | 0 | 27.5 | logs/XP-xprobe-vm-dedupe-at-view.log | probe done |
| XP-xprobe-vm-anymoney-pend-unseen | 2026-10-12 23:24:39 | 0 | 20.9 | logs/XP-xprobe-vm-anymoney-pend-unseen.log | probe done |
| V-S-audit-other-base | 2026-10-12 23:24:22 | 0 | 42.2 | logs/V-S-audit-other-base.log | ALL CHECKS PASSED |
| V-SM-audit-other-vm-anymoney-pend-unseen | 2026-10-12 23:25:05 | 0 | 43.9 | logs/V-SM-audit-other-vm-anymoney-pend-unseen.log | ALL CHECKS PASSED |
| V-S-boot-same-base | 2026-10-12 23:25:52 | 0 | 22.4 | logs/V-S-boot-same-base.log | every page, source, save and error list is identical either way |
| V-S-boot-same-c1 | 2026-10-12 23:25:52 | 0 | 22.6 | logs/V-S-boot-same-c1.log | every page, source, save and error list is identical either way |
| V-S-legacy-fsrc-c1 | 2026-10-12 23:26:15 | 0 | 7.2 | logs/V-S-legacy-fsrc-c1.log | every legacy Force setting computes exactly as before |
| V-S-legacy-fsrc-base | 2026-10-12 23:26:15 | 0 | 8.2 | logs/V-S-legacy-fsrc-base.log | every legacy Force setting computes exactly as before |
| XP-xprobe-fixv | 2026-10-12 23:26:55 | 0 | 44.0 | logs/XP-xprobe-fixv.log | probe done |
| XP-xprobe2-fixv | 2026-10-12 23:27:39 | 0 | 19.2 | logs/XP-xprobe2-fixv.log | probe done |
| V-F-fixv | 2026-10-12 23:27:59 | 0 | 56.1 | logs/V-F-fixv.log | ALL CHECKS PASSED |
| V-S-audit-hostile-c1 | 2026-10-12 23:26:22 | 0 | 152.7 | logs/V-S-audit-hostile-c1.log | ALL CHECKS PASSED |
| V-S-audit-hostile-base | 2026-10-12 23:26:23 | 0 | 154.7 | logs/V-S-audit-hostile-base.log | ALL CHECKS PASSED |
| V-S-audit-inject-base | 2026-10-12 23:28:58 | 0 | 27.0 | logs/V-S-audit-inject-base.log | ALL CHECKS PASSED |
| V-S-audit-inject-c1 | 2026-10-12 23:28:55 | 0 | 30.1 | logs/V-S-audit-inject-c1.log | ALL CHECKS PASSED |
| V-check-base | 2026-10-12 23:29:25 | 0 | 7.5 | logs/V-check-base.log | all checks passed |
| V-check-c1 | 2026-10-12 23:29:25 | 0 | 8.5 | logs/V-check-c1.log | all checks passed |
| V-SM-audit-recon-vm-pk-dup | 2026-10-12 23:29:53 | 0 | 457.4 | logs/V-SM-audit-recon-vm-pk-dup.log | ALL CHECKS PASSED |
| V-SM-audit-recon-vm-dedupe-at-view | 2026-10-12 23:29:53 | 0 | 459.8 | logs/V-SM-audit-recon-vm-dedupe-at-view.log | ALL CHECKS PASSED |
| V-SM-audit-recon-base-board-c1-suite | 2026-10-12 23:30:21 | 1 | 461.1 | logs/V-SM-audit-recon-base-board-c1-suite.log | 14 FAILING CHECK(S) |

## PIDs
`pids.txt`: every wrapper (`w.sh`, its own PID) and every `setsid -w timeout -k 10 600` PID with its node child, as run.sh
records them. I killed nothing.

## What I did not do
- No full audit-import or audit-board. No Chromium, no playwright install. mutate.mjs never imported or run (text only).
- Nothing edited, staged, committed or pushed in /home/user/orbit-board or /home/user/orbit-ui; the builder's files untouched.
- The other import routes (Import, several boards, folder copies, shared state) were checked by reading only: each calls
  inboundCheck before use (L8576, L10114, L17743, L26743, L31623/31630).
- Bounding: every node run was inside run.sh's `setsid -w timeout -k 10 600`. The three wrappers that started the first
  audit-recon runs (11:18 PM) were `w.sh` → run.sh without their own setsid/timeout (the Bash tool's 660 s cap bounded them);
  all later wrappers were `setsid -w timeout -k 10 600 w.sh …`. Read-only ls/cat/grep/diff/git hash-object were not wrapped.
