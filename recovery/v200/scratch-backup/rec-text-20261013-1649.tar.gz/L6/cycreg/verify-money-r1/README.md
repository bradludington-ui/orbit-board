# CYCREG: independent adversarial verification, round 1, lens A (data loss and money)

The verifier worked in this directory only. Times are Eastern. The first session ran from about 8:40 PM to 8:47 PM ET on 12 Oct and stopped at the usage limit. Work resumed at 11:13 PM ET, and this README was written at about 11:45 PM ET.

**Verdict: unsound.** There are three must-fixes. Each is reproduced through the product's own paths and read from the actual XLSX bytes or from the board's own words.

## Identities (git hash-object)

| what | blob |
|---|---|
| base board (`base/`, copy of rec/L6/base, d66dd60 / 7ee498a) | fce8a391bd8a248d5185e199d22190c1687eaea0 |
| base audit-recon / mutate.mjs.txt | 529e36f7… / cbc6defc… |
| builder's c1 board (`c1/`, byte-identical to ../c1) | 2f9219a4b33b7d147eb64cd5ee367939899c84c8 |
| c1 audit-recon / mutate.mjs.txt / audit-import | 9c2cdd88… / bfb87708… / 4aba2506… |
| verifier sketch v1 (c1 + export by text keys) | 02a9422d4451cc502446aeb39862ccda59d2d71e |
| verifier sketch v2 (c1 + export once by name + door refuses a non-text key) | 648b67c1ffcfd6484d6c075739d6a8bdede36c1d |
| verifier sketch v3 (v2 + shared-folder reads exempt from the list rule) | fded687ac67d281832b2f933b49c1c77e785f306 |
| probe/vprobe.mjs … vprobe6.mjs | 3f06a07b, 35366793, 6c44dea9, 805d7239, 1ee09b91, 910e2fe1 |
| hv/h-cycreg.mjs (focused audit-recon CYCREG block + guard, verbatim) | eb76ab46f9586992aa176a8dbd1c81d08eb22e6f |
| hv/hi-w1.mjs (focused audit-import "v1.95 W1" block, built with mkfocused-u2.py) | 310b30b831e82f87cac80e305cad689a72c4f291 |
| bin/run.sh / bin/runner.mjs | 990f6852… / f851f139… |

The v1, v2 and v3 copies are sketches that show a minimal fix closes each finding. They are not proposed commits. Their diffs are in `out/v1-board.diff`, `out/v2-board.diff` and `out/v3-vs-v2-board.diff`.

## The money, by hand (every probe uses it)

- The appropriation is O&M, with services USAF, ANG and AFRC.
- There is one requirement, R1. It asks USAF 900, ANG 200 and AFRC 0.
- Each service has a discretionary pot of 5,000, so R1 is funded in full: USAF 900, ANG 200, AFRC 0. The fixture checks this each time: `[[900,200,0],[0,0,0]]`.
- The award is single, in FYMON[2], so every dollar is in that month's column (sheet column 3) and none is in NO DATE.
- The service totals are USAF 900, ANG 200 and AFRC 0. All services total 900 + 200 + 0 = 1,100.
- A list entry is only a name. Whatever the list holds, USAF cannot be more than 900 and ANG cannot be more than 200.

## Findings

### M1. MONEY: the export still doubles on c1, for keys that are equal as names but not as values

**The defect**
- In monSheet, `bag[g]` is a plain object, so each key's money is found by the key's name.
- c1 makes keys unique with `a.indexOf(k)===i`, which is strict equality. The numbers 1 and the text "1" are two keys to that test but one bag.
- The door skips any key that is not text (`if(typeof k!=='string') continue;`).
- `cycRcnOf` drops non-text keys from a locked cycle's own list. A cycle locked before v1.99, however, reads today's list.

**Reproduction** (vprobe3, run vprobe3-c1-1 at 11:20 PM ET, log `logs/vprobe3-c1-1.log`; also vprobe-c1-1 at 8:40 PM ET)
- Each case went through Import a full board into the user's own board. The case passed the door and the import took it.
- PB27 was then viewed or the working plan was exported, and the workbook was read from its XLSX bytes.
- The result on c1, on every route (imported and reopened, saved and reopened, the file opened), was USAF 1,800 / ANG 400 / all services 2,200. The base gives the same.

| case | c1 export |
|---|---|
| W1: working plan `[{k:1},{k:"1"}]`, R1 on "1" | 1,800 / 400 / 2,200 |
| W2: `[{no k},{k:"undefined"}]` | 1,800 / 400 / 2,200 |
| N2–N4: `["K1"]`/"K1", `null`/"null", `true`/"true" | 1,800 / 400 / 2,200 |
| P1: PB27 locked the pre-v1.99 way (it reads today's list), today `[{k:1},{k:"1"}]` (the imported-cycle route) | 1,800 / 400 / 2,200 |

- R1's money is printed under both 11111/AAAAA and 22222/BBBBB, while the screen labels R1 22222/BBBBB.
- The controls give 900 / 200 / 1,100 on both boards.

**Claims this falsifies:** "the export can never count one bag twice", and the NEXT-VERSION draft's "a list the board already holds … is counted right as well".

**Minimal fix** (sketch v2, tested)
- In monSheet, keep each key once by name: `const seen=Object.create(null); const keys=keysOf().filter(function(k){ const s=String(k); return seen[s]? false : (seen[s]=true); });`
- At the door, refuse a key that is present but not text: `if(k===undefined) continue; if(typeof k!=='string') return '…is not text…';`

**Results on v2**
- All shapes export 900 / 200 / 1,100. The door refuses W1, N1–N4 and P1, and storage is unchanged.
- The builder's focused block passes all 31 checks (VF2-v2, exit 0, 11:31 PM ET).
- v1, which keeps only text keys and builds `known` from them, also gives 900/200 everywhere and 31/31 (VF2-v1).

**Tests needed:** the shapes above, through import, reopen and opening the file, asserting the literal 900/200/1,100. Add a mutation that reverts to the strict `indexOf` test.

### M2. DATA (regression vs base): one board holding such a list freezes the team's shared-folder copy

This comes from vprobe4 and vprobe5: runs vprobe4-c1-1 (11:26 PM), vprobe4-base-1 (11:27 PM), vprobe5-c1-1 (11:28 PM) and vprobe5-base-1 (11:29 PM). The folder is the stand-in from audit-import's W1H helpers, copied verbatim.

**What happens on c1.** A board holding `[K1,K1]` or `[K1,"__none__"]` (a file opened as the board, or any board that took such a file before this change) is connected to the shared folder.
1. Save 1, to an empty folder, writes the list there.
2. Every later Save is refused: "⛔ The shared folder's copy of O&M FY27 could not be read — a copy in the shared folder was refused: the RCN / EEIC list at the file.store.rcn holds the key “K1” twice … Nothing was written". The work stays unsaved (DIRTY true) and the folder still holds "FIRST".
3. A teammate's refresh is refused, Take the pen is refused ("Could not read who holds the pen …"), and the teammate's Save is refused.
4. Repairing the list on the board, using Remove, which also cleared R1's K1 assignment, does not help. Save 3 is still refused, because the copy that is checked is the folder's.
5. The board's own advice, "put an earlier one back", has no earlier copy to restore.

**What happens on base.** Every save lands, and the teammate loads, takes the pen and saves.

**Principles broken**
- (1): the team's own work cannot reach the shared copy.
- (4): the words are false. The builder's draft says "refused by another board's door **until the list is corrected**", but correcting the list does not unblock the folder.

**Minimal fix** (sketch v3, tested)
- The shared-folder read (driveParse) does not apply the new list rule. Folder copies carry `store: pkgStrip(MS)` and no cycles, so Codex's cycle route is not affected.
- The export is right because of M1 and c1. A plain on-board notice for a list that repeats a key is the "say" part.
- On v3, all saves land, and the teammate loads, takes the pen and saves (vprobe4-v3-1, vprobe5-v3-1).
- The focused audit-import "v1.95 W1" folder block passes 53/53 on c1 (FW1-c1) and on v3 (FW1-v3).
- The import refusals are unchanged (vprobe3-v3-1).

### M3. WORDS and the upgrade route: the refusal says ORBIT never writes what ORBIT wrote

This comes from vprobe6, run vprobe6-c1-1 at 11:43 PM ET.
1. The base board, BUILD "v2.00 (11 Oct 2026)", imports a Codex-shaped file through its own door, and the door accepts it.
2. It saves its own board file.
3. On c1, Import a full board of that file (Brad's v1.86 upgrade route) refuses the whole board: "…holds the key “K1” twice …. A board, a PMO copy, a package or a submittal written by ORBIT never carries that, so the file is damaged or was not written by ORBIT."
4. That is false for this rule. Every earlier door passed these lists. c1 also writes them itself: from a file opened as the board, to its own file and to the folder (M2, save 1).
5. The user's whole board, every appropriation, cycle and log, cannot be carried forward. A locked cycle's list cannot be repaired in the product.

This happens both for PB27's list `[K1,K1]` and for the working plan's `[K1,K1]`. The control `[K1,K2]` imports.

**Minimal fix** (the lead decides how)
- At the least, give these reasons true words, not the generic tail.
- Under principle (1) ("only if refusing would lose a user's own work, normalize with a plain statement"), the full import of an ORBIT-written board should take the file and say plainly what the list holds. A lossless option is to give the repeated entry a key of its own, with assignments kept where every reader already resolved them (the first entry).
- The export is right in any case once M1 is fixed.

## Should-fix

- **S1. A list entry that is null** (`[null, K1]`) passes the door on base and on c1. On the importing board, the workbook, the RCN panel and `rcnLabel` all throw "Cannot read properties of null (reading 'k')" (vprobe2-c1-2 and vprobe2-base-2, X1). This is not new, but c1's door now walks these entries and skips that one.
- **S2. On a board holding a repeated key, the only repair loses an assignment.** Remove clears every assignment to the key. Removing the 22222/BBBBB duplicate cleared R1's assignment, although the screen showed R1 on 11111/AAAAA (vprobe4-c1-1). The panel also says each duplicate row is "Used by 1". The builder documented this, but no lossless repair exists. Together with M2 and M3, these boards have no clean way out.
- **S3. The legacy sidecar route** (opt-in `spmtSidecar=1`) maps a refused file to null. The board then says "No shared state file found next to the board — use 💾 Save to create one", which is untrue for a refused file. The wording is not new, but the new rule adds refusals that reach it.

## Minor

- The new refusal names a key through `inShow`. A non-text key under the v2 sketch reads “1”, so a check with a fix should say plainly that the key is not text.
- In the test block, the refused cases' "imported, reopened" checks re-export the user's own unchanged board. They prove nothing changed, but they do not exercise the reopened import.

## Runs (all through bin/run.sh: lock checked, then `setsid -w timeout -k 10 600`)

| label | start (ET, 12 Oct) | exit | wall s | result |
|---|---|---|---|---|
| vprobe-c1-1 | 8:40:52 PM | 0 | 13.4 | N1–N4 on c1: the door passes and the export is 1,800/400/2,200; D1 is refused; the control is 900/200 |
| vprobe-base-1 | 8:41:17 PM | 0 | 15.6 | the same shapes on base |
| VF-c1 / VF2-c1 | 8:43:38 / 8:44:01 PM | 0 / 0 | 16.0 / 14.2 | the builder's block (31 checks): ALL PASSED on c1 |
| VF2-base | 8:44:15 PM | 1 | 13.5 | 14 checks fail on base (1,800/400), the same as the builder's |
| vprobe2-c1-1 / base-1 | 8:46:06 / 8:46:16 PM | 1 / 1 | 10.6 / 9.8 | the probe itself threw on X1 (null entry); fixed and rerun |
| vprobe2-c1-2 / base-2 | 8:46:40 / 8:46:53 PM | 0 / 0 | 13.7 / 15.1 | X1 throws on both boards; X4 `["__none__"]` is 1,800/400 on base and refused on c1 |
| vprobe3-c1-1 / base-1 | 11:20:08 / 11:20:47 PM | 0 / 0 | 38.6 / 44.2 | M1: 1,800/400/2,200 on c1 and on base (W1, W2, P1); controls 900/200 |
| vprobe3-v1-1, vprobe-v1-1, VF2-v1 | 11:22:14–11:22:59 PM | 0 | 26.1 / 18.7 / 31.3 | v1: 900/200 everywhere; the builder's block passes 31/31 |
| vprobe4-c1-1 / base-1 | 11:26:27 / 11:27:30 PM | 0 / 0 | 29.5 / 27.3 | M2: save 2 and save 3 refused on c1; all land on base |
| vprobe5-c1-1 / base-1 | 11:28:40 / 11:29:03 PM | 0 / 0 | 23.1 / 26.0 | M2: the teammate's refresh, pen and save are refused on c1; all work on base |
| vprobe3-v2-1, VF2-v2, vprobe-v2-1 | 11:31:07–11:35:53 PM | 0 | 50.9 / 83.3 / 60.3 | v2: refused at the door; opened gives 900/200; 31/31 |
| vprobe3-v3-1, VF2-v3 | 11:33:21 / 11:34:21 PM | 0 | 59.8 / 91.5 | v3: the same as v2; 31/31 |
| vprobe4-v3-1 / vprobe5-v3-1 | 11:36:53 / 11:37:34 PM | 0 | 40.4 / 30.7 | v3: every folder save, refresh, pen and teammate save lands |
| FW1-c1 / FW1-v3 | 11:38:49 / 11:40:33 PM | 0 / 0 | 104.0 / 89.9 | audit-import "v1.95 W1" focused: 53/53 on both |
| vprobe6-c1-1 | 11:43:04 PM | 0 | 24.8 | M3: c1 refuses the base-written board, saying ORBIT never writes it |
| mcount (text only, python3 -I) | 11:44:12 PM | 0 | – | c1: 1334/1334 once, including the 6 v200-cycreg entries |

All logs are in `logs/`, the run records in `logs/runs.txt`, and the check records in `out/*.jsonl`. Every timeout PID and node PID is in `pids.txt`, with its command. Nothing was killed.

## Decisions

- The verifier proposed sketches rather than only describing fixes, so that "minimal" was shown and not claimed. They are not commits.
- The folder evidence uses audit-import's own W1H stand-in, copied verbatim, so the save, pull and pen code paths are the product's.
- M3 is classed must-fix because the false sentence is shown to users in the refusal itself. The lead may treat the normalization part as a design choice. The wording part is not optional under principle (4).

## Not done

- No full audit-import or audit-board run, no mutation sweep, and no new mutants. The builder's six were counted as text only.
- No Chromium.
- Nothing in /home/user/orbit-board or orbit-ui was edited. The only use was read-only `git log` and `git show` there, wrapped in setsid and timeout.
- Nothing was committed, staged or pushed.
- Not all commands were wrapped. Read-only shell commands (ls, cat, grep, sed, diff, git hash-object) and the small python3 -I patch scripts on the verifier's own copies ran unwrapped. Every node run and mcount went through `setsid -w timeout -k 10 600`.
- Not probed: the other import routes besides Import a full board and the door; PMO packages from a board holding such a list. By reading, a package is rebuilt from the board, so it unblocks once the list is repaired.
