<!-- Draft for NEXT-VERSION.md, under "### v2.00", after the U14 bullet and before "- **Unresolved after R1–R5 (11 Oct).**".
     Fix round 3 of 13 Oct: SUPERSEDES drafts/fr2/NEXT-VERSION-entry.md (fix round 2), drafts/fr/NEXT-VERSION-entry.md (fix
     round 1) and drafts/NEXT-VERSION-entry.md (12 Oct). The lead commits; <sha> is the commit's. -->
- **U32 and U33 — an RCN / EEIC list that repeats a key, or holds "__none__" or a key that is not text, never counts money
  twice; a file handed over with one is refused, and the user's own board comes across saying what it holds** (Codex's
  review of `main`, as Brad supplied it, 12 Oct, about 6:05 PM ET: "Duplicate K1 registry entries." and "One registry entry
  named __none__." "Both accept an imported cycle and export USAF $1,800 / ANG $400 from independently expected $900 /
  $200."). The RCN-EEIC by Month sheet printed a row for every entry of an RCN / EEIC list and found each row's money by the
  entry's key, as text. A list that named K1 twice -- a locked cycle's, which a cycle in an imported file brought with it,
  or the working plan's -- printed K1's row twice and put its money twice into each service total, the grand total and the
  NOT FUNDED Ask: on the synthetic fixture USAF $1,800 and ANG $400, where the money is $900 and $200. An entry keyed
  "__none__", the name the sheet used for money on no combination, printed that money under its own codes and again as not
  assigned. The number 1 beside the text "1" was one name printed twice as well; a requirement on "1" with only the number 1
  listed was printed under the number's codes, which the screen does not show it on; and an entry keyed "constructor" made
  the workbook's export fail. Now the sheet names each combination by where the board finds it -- the first entry whose key
  is the requirement's (or the CLIN's) pointer exactly, as the screen and the Spend Plan Source find it -- and counts each
  once; the not-assigned row is a name no entry can take, and a requirement on no combination is never filed under an entry
  keyed "". The door every file handed over passes (⬅ Import one appropriation, ⇊ several boards, packages, submittals, band
  ladders) refuses an RCN / EEIC list that repeats a key, holds a key beginning with two underscores, a key that is not
  text, an entry with no key, or an entry that is not one; it says which list, what it holds and why, in words (a key such
  as "constructor" included), takes nothing, and no longer says that ORBIT never writes such a list: an ORBIT before this
  one took one without a word, and could save it. Its advice says how such a list is put right on a board of this version
  (✕ on a row marked ⚠ repeats removes that row alone) and that ⬅ Import a full board replaces this board's whole BAE list
  and execution data, so it is not the way to take one appropriation. ⬅ Import a full board -- the user's own board, Brad's
  way onto a new version -- takes those lists as the file holds them and says what each holds in the question asked before
  anything is replaced and again once the board has reopened, including that a locked cycle's list leaves out an entry
  whose key is not text; it refuses only a null entry in the working plan's list, which every reader of that list stops at
  (anything else there that is not an entry, such as "K9" or 5, is read past as before; a locked cycle's list is read
  without such entries, as since v1.99). A full import that stops early -- not a board, or answered no -- leaves the next
  file handed over held to the whole rule. The shared folder's copy and the sidecar beside the board are read as before,
  a null entry included: refusing them froze the team's folder, every later Save refused. On the 🗂 RCN / EEIC panel a row
  that repeats an earlier row's key says so, and ✕ on it removes that row alone, changing no assignment, and is saved. Add
  RCN / EEIC no longer gives a new entry a key still in use.
  - **What users may see:** a board that holds such a list exports each combination once -- its RCN-EEIC totals and NOT
    FUNDED Ask fall by what was doubled, money on no combination reads as not assigned, and every requirement is printed
    under the codes the screen shows it on. A file handed over with such a list is refused: "⚠ Nothing imported —
    “cycle.html” was refused: the RCN / EEIC list at the saved state.cycDb.byAp.om.cycles.PB|2027.rcn holds the key “K1”
    twice (rcn[0] and rcn[1]); a key names one combination.", with an alert ending "An RCN / EEIC list names each
    combination once, by a text key of its own. An ORBIT before this one took such a list without a word and could save it
    with its board. A list that is not a locked cycle’s can be put right on a board of this version, in 🗂 RCN / EEIC, where
    ✕ on a row marked ⚠ repeats removes that row alone, and the file saved again. A whole board of your own comes across
    with its lists as they are by 📁 File → ⬅ Import a full board, which says first what they hold. That replaces this
    board’s whole BAE list and execution data with the file’s, when it carries them, so it is not the way to take one
    appropriation. Nothing on this board was changed." A full import's question, and the reopened board, add "RCN / EEIC
    lists as the file holds them, which a file handed over is refused for: O&M PB27’s list holds the key “K1” twice (rcn[0]
    and rcn[1]). Each requirement reads the first entry with its key, as the ORBIT that saved the file did, and the RCN-EEIC
    sheet counts each key once and money on no combination only as not assigned" (or "… O&M working plan’s list holds
    rcn[0], which is not a combination (“"K9"”) …"; when a locked cycle's list holds a key that is not text, "… as the ORBIT
    that saved the file did (a locked cycle’s list leaves out an entry whose key is not text, as every ORBIT since v1.99
    has), and …"). The panel's "Used by" on a repeated row reads "⚠ repeats row 1".
  - **Test:** audit-recon "v2.00 (U32, U33) — an RCN / EEIC list that repeats a key, or holds “__none__” or a key that is not
    text, never counts money twice: a file handed over with one is refused, and the user’s own board comes across saying
    what it holds" (165 checks). Codex's two shapes in PB27's own list, R1 on K1 and on none, and on the entry named
    "__none__"; PB27 [K1, K1, "__none__"]; PB27 [null, K1]; PB27 [the number 1] with R1 on the number 1; the working plan's
    list [K1, K1], on one code and on two; [1, "1"] with R1 on "1" and on the number 1, in the working plan and as read by
    PB27 locked before v1.99; [1] with R1 on the number 1 and on "1"; ["K9", K1]; [K1, an entry keyed ""] with R1 on none; a
    hand-made file with an entry keyed "constructor"; R1 unfunded on [K1, K1]; and a control on ordinary distinct keys beside
    each. Each through the door, ⬅ Import one appropriation, ⇊ Import several boards, ⬅ Import a full board into the user's
    own board with the same browser reopened and then saved and reopened, and the file opened directly and then saved and
    reopened, as each case needs. The RCN-EEIC sheet is read from the workbook's bytes against literals worked by hand:
    USAF 900 and ANG 200 in the award month and in TOTAL, all services 1,100, every service total in the breakout, each
    under the codes the board shows R1 on, and the NOT FUNDED Ask USAF 900 / ANG 200. Every refusal and every statement is
    checked word for word, browser storage byte-identical where nothing is taken. Also: a null entry in the working plan's
    list (refused at the door and by the full import); the door on a key repeated apart, three times, beginning with two
    underscores, missing and not text, on keys every object answers to (refused in words) and on "constructor" twice; a
    full import that stops early, then a file handed over; the shared folder's copy and the sidecar read with [K1, K1] and
    with [null, K1]; ✕ on the second and on the first of two rows with one key, and the second reopened; Add RCN / EEIC in
    one millisecond after removals. 96 checks fail on the board before the change (USAF 1,800, ANG 400, all services 2,200;
    NOT FUNDED Ask 1,800 / 400; the door passing every list; the full import silent; the "constructor" export failing; ✕
    clearing R1's assignment). The 69 that pass there are the fixtures, the controls and the money of the four guards
    (cases that board printed right); the guards' door, full-import and statement checks fail there.
  - **Mutations:** `v200-cycreg-keys-repeat`, `-keys-cycle-only`, `-notfunded-repeat`, `-key-as-name`, `-at-by-name`,
    `-at-text-only`, `-req-by-name`, `-clin-by-name`, `-door-open`, `-door-repeat`, `-door-adjacent`,
    `-door-underscores`, `-door-sentinel-only`, `-door-not-text`, `-several-own-board`, `-own-takes-entry`,
    `-own-cycle-entry-refused`, `-own-board-refused`, `-own-board-unsaid`, `-say-first-only`, `-say-entry-garbled`,
    `-folder-refused`, `-sidecar-refused`, `-refusal-untrue`, `-advice-unwarned`, `-repeat-row-clears`,
    `-first-row-alone`, `-repeat-row-unsaid`, `-add-key-reused`, `-add-steps-once`, `-own-entry-any`, `-at-empty-matches`,
    `-folder-as-own`, `-sidecar-as-own`, `-mode-sticks`, `-odd-plain-object`, `-del-unsaved`, `-say-cycle-unsaid` and
    `-advice-any-board` (39); each is caught by this block, except `-clin-by-name`, which audit-recon's own v1.98 item 83 and
    v1.99 item 88 checks catch. A repeated key read at its LAST entry is not an entry: the row's label comes from rcnLabel,
    which finds the first entry with that key, so the sheet is the same either way.
  - **Not covered:** a board whose working plan's list already holds a null entry (taken before this change, or a file
    opened directly, which no door checks) still cannot export its workbook or show its RCN / EEIC panel, as before, and the
    full import's refusal of such a file says what is wrong but not how to put it right. A locked cycle's list cannot be put
    right in the product: a file handed over that carries a repeated key or one of the other shapes is refused, and only ⬅
    Import a full board carries it. A board the full import left holding such a list sends files every other board refuses,
    and nothing warns at export time. ✕ on the FIRST row of a repeated key clears every assignment to that key, as its
    question says. The pickers and the menu's "N combos" list a repeated key's rows as they are. An entry keyed "" passes the
    door; no pointer can reach it (a pointer of "" means none). Packages, submittals and band ladders run the same door but
    are not driven by this block, and their refusal's advice names ⬅ Import a full board, which takes a board file only; the
    sidecar's file:// branch is not driven (jsdom takes the fetch branch). The SI sheet walks the fixed SI code list and was
    never affected. The PPBE view's "+ add an RCN / EEIC line" still takes its key from the time and the list's length, as
    Add RCN / EEIC did; PPBE totals count each key once, so no total doubles (read, not run).
