<!-- Text to APPEND to the rows of recovery/v200/UNRESOLVED-LEDGER.md (rows U32 and U33 exist at orbit-board 60336a0).
     <sha> = the lead's commit; <time> = when the lead commits, in ET. Appended to the "Evidence so far" cell and the
     "Status" cell as marked. Fix round 3 of 13 Oct: SUPERSEDES drafts/fr2/LEDGER-append.md (fix round 2) and the earlier
     drafts. The "Evidence so far" text keeps fix rounds 1 and 2's and adds the last sentence of each; the "Status" text is
     fix round 2's with what round 3 changed. -->

U32, "Evidence so far" cell, append:
 **Reproduced** (cycreg track, 12 Oct, 7:40 PM ET) on `d66dd60` (board `fce8a391`) through the product's own Import a full
 board into the user's own board, the same browser reopened, PB27 viewed and the workbook read from its bytes: USAF $1,800,
 ANG $400, all services $2,200 against $900, $200 and $1,100 worked by hand (K1's row printed twice; every service total in
 the breakout doubled too). The same file opened directly, and each saved and reopened, gives the same. The door passed it.
 Controls (K1, K2) gave $900 / $200. Add RCN / EEIC gave two entries the same key when two adds came in one millisecond
 after a removal. Verification round 1 (12 Oct, evening) found the same doubling for the working plan's own
 list, for its NOT FUNDED Ask (USAF $1,800 / ANG $400), and for a list holding the number 1 beside the text "1" (still
 $1,800 / $400 on the 12 Oct build). Verification round 2 (13 Oct, morning) found that fix round 1's sheet, which
 counted only text keys, printed a requirement on the number 1 as not assigned (beside [1]) or under "1"'s codes (beside
 [1, "1"]) while the screen and the Spend Plan Source showed 11111 / AAAAA; `d66dd60` got the first right. Verification
 round 3 (13 Oct, afternoon) found no wrong figure; it found an unchecked line (a requirement on no combination would be
 filed under an entry keyed "" without it), the full import keeping a user's board out for an entry such as "K9" that every
 reader reads past, and four unchecked rules (the team's copies' mode, the mode after a full import that stops early, a
 "constructor" key at the door, ✕ on a repeated row saved).

U32, "Status" cell, append:
 **Fixed in `<sha>` (<time> ET)**: the RCN-EEIC sheet names each combination by where the board finds it -- the first entry
 whose key is the pointer exactly, as the screen and the Spend Plan Source find it -- and counts each once; no pointer is on
 no combination; Add RCN / EEIC never reuses a key. A file handed over with a list that repeats a key, holds a key that is
 not text, or an entry that is not one is refused, naming the list, what it holds and where, in true words that say how a
 board of this version puts it right and what a full import would replace; nothing is taken and browser storage is
 unchanged. ⬅ Import a full board takes the user's own board with such a list and says what it holds, before and after (a
 locked cycle's list leaving out an entry whose key is not text, said); it refuses only a null entry in the working plan's
 list. The shared folder's copy and the sidecar are read as before. ✕ on a row that repeats a key removes that row alone,
 and is saved. audit-recon "v2.00 (U32, U33) …": 96 of its 165 checks fail before, all pass after; the fixtures, the
 controls and the four guards' money checks pass on both. Mutations `v200-cycreg-keys-repeat`, `-keys-cycle-only`,
 `-notfunded-repeat`, `-at-by-name`, `-at-text-only`, `-at-empty-matches`, `-req-by-name`, `-clin-by-name`, `-door-open`,
 `-door-repeat`, `-door-adjacent`, `-door-not-text`, `-several-own-board`, `-own-takes-entry`, `-own-entry-any`,
 `-own-cycle-entry-refused`, `-own-board-refused`, `-own-board-unsaid`, `-say-first-only`, `-say-entry-garbled`,
 `-say-cycle-unsaid`, `-folder-refused`, `-sidecar-refused`, `-folder-as-own`, `-sidecar-as-own`, `-mode-sticks`,
 `-odd-plain-object`, `-refusal-untrue`, `-advice-unwarned`, `-advice-any-board`, `-repeat-row-clears`, `-first-row-alone`,
 `-repeat-row-unsaid`, `-del-unsaved`, `-add-key-reused` and `-add-steps-once` are caught (`-clin-by-name` by audit-recon's
 v1.98 item 83 and v1.99 item 88 checks). Still open: a locked cycle's list cannot be put right in the product; a board
 whose working plan's list holds a null entry cannot export, as before.

U33, "Evidence so far" cell, append:
 **Reproduced** (cycreg track, 12 Oct, 7:40 PM ET) on `d66dd60` the same way, with the list [K1, "__none__"] and R1 on no
 combination: USAF $1,800 and ANG $400 ($900 under the "__none__" entry's codes, 22222 / BBBBB, and $900 again as not
 assigned) against $900 and $200 by hand. The control (K1, K2, R1 on none) gave $900 / $200. With R1 on the entry named
 "__none__" itself the same file gave the same $1,800 / $400 (fix round, 13 Oct, 4:26 AM ET). A list entry keyed
 "constructor", in a file opened directly, made `d66dd60`'s workbook export fail (verification round 2, 13 Oct).

U33, "Status" cell, append:
 **Fixed in `<sha>` (<time> ET)**: the RCN-EEIC sheet's rows are named 'e' and the row of the entry the board finds, never
 an entry's key, so no entry can be the not-assigned row ("__none__") or a name every object answers to; the money on no
 combination is counted once, as not assigned. A file handed over with a key beginning with two underscores is refused,
 naming where it sits, and one keyed "constructor" is refused in words; the user's own board is taken and says so (U32).
 Same block as U32. Mutations `v200-cycreg-key-as-name`, `-door-underscores` and `-door-sentinel-only` are caught.
