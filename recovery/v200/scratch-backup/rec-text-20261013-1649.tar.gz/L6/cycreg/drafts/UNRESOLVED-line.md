<!-- NEXT-VERSION.md, "Unresolved after R1–R5 (11 Oct)": the base has NO line for U32/U33 (searched: no "U32", "U33",
     "registry", "__none__" in that list). Proposed NEW line, after the U14 line: -->
  - **U32 and U33: built as one commit** (Codex's review of `main`, as Brad supplied it, 12 Oct, about 6:05 PM ET): an
    RCN / EEIC list that repeats a key or holds "__none__" is refused at the door, and the RCN-EEIC sheet counts each key
    once (above). A board that took such a list before this change opens and exports correctly but says nothing about the
    list, and its saved file is refused by another board's door until the list is corrected.
