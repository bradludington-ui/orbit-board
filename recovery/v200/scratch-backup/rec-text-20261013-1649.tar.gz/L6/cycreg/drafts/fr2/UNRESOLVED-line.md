<!-- NEXT-VERSION.md, "Unresolved after R1–R5 (11 Oct)": the base has NO line for U32/U33 (searched: no "U32", "U33",
     "registry", "__none__" in that list), so this is a proposed NEW line, after the U14 line. Fix round 2 of 13 Oct:
     SUPERSEDES drafts/fr/UNRESOLVED-line.md (fix round 1) and drafts/UNRESOLVED-line.md (12 Oct). -->
  - **U32 and U33: built as one commit** (Codex's review of `main`, as Brad supplied it, 12 Oct, about 6:05 PM ET): an
    RCN / EEIC list that repeats a key, or holds "__none__" or a key that is not text, never counts money twice; a file
    handed over with one is refused, and the user's own board comes across saying what it holds (above). Open for Brad: a
    locked cycle's list cannot be put right in the product, so a file handed over whose locked cycle carries such a list
    (one appropriation, a consolidated file, several boards) is refused, and only ⬅ Import a full board, which replaces the
    whole board -- its BAE list and execution data with the file's -- brings it across.
