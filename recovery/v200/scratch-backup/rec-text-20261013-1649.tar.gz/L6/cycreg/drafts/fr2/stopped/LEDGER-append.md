<!-- Text to APPEND to the rows of recovery/v200/UNRESOLVED-LEDGER.md (rows U32 and U33 exist at orbit-board 60336a0).
     <sha> = the lead's commit; <time> = when the lead commits, in ET. Appended to the "Evidence so far" cell and the
     "Status" cell as marked. Fix round 2 of 13 Oct: SUPERSEDES drafts/fr/LEDGER-append.md (fix round 1), whose "Fixed" text
     described a sheet that counted only text keys -- verification round 2 found it printed a requirement on the number 1
     under the wrong codes, or as not assigned -- and a Symbol bucket this commit no longer has. The "Evidence so far" text
     keeps fix round 1's and adds the last sentence of each. -->

U32, "Evidence so far" cell, append:
 **Reproduced** (cycreg track, 12 Oct, 7:40 PM ET) on `d66dd60` (board `fce8a391`) through the product's own Import a full
 board into the user's own board, the same browser reopened, PB27 viewed and the workbook read from its bytes: USAF $1,800,
 ANG $400, all services $2,200 against $900, $200 and $1,100 worked by hand (K1's row printed twice; every service total in
 the breakout doubled too). The same file opened directly, and each saved and reopened, gives the same. The door passed it.
 Controls (K1, K2) gave $900 / $200. Add RCN / EEIC gave two entries the same key when two adds came in one millisecond
 after a removal. Verification round 1 (12 Oct, 11:13 PM–11:45 PM ET) found the same doubling for the working plan's own
 list, for its NOT FUNDED Ask (USAF $1,800 / ANG $400), and for a list holding the number 1 beside the text "1" (still
 $1,800 / $400 on the 12 Oct build). Verification round 2 (13 Oct, 5:49–9:44 AM ET) found that fix round 1's sheet, which
 counted only text keys, printed a requirement on the number 1 as not assigned (beside [1]) or under "1"'s codes (beside
 [1, "1"]) while the screen and the Spend Plan Source showed 11111 / AAAAA; `d66dd60` got the first right.

U32, "Status" cell, append:
 **Fixed in `<sha>` (<time> ET)**: the RCN-EEIC sheet names each combination by where the board finds it -- the first entry
 whose key is the pointer exactly, as the screen and the Spend Plan Source find it -- and counts each once; Add RCN / EEIC
 never reuses a key. A file handed over with a list that repeats a key, holds a key that is not text, or an entry that is
 not one is refused, naming the list, what it holds and where, in true words that say what a full import would replace;
 nothing is taken and browser storage is unchanged. ⬅ Import a full board takes the user's own board with such a list and
 says what it holds, before and after (a null entry in a locked cycle's list included); the shared folder's copy and the
 sidecar are read as before. ✕ on a row that repeats a key removes that row alone. audit-recon "v2.00 (CYCREG) …": 86 of its
 142 checks fail before, all pass after; the controls and two guards pass on both. Mutations `v200-cycreg-keys-repeat`,
 `-keys-cycle-only`, `-notfunded-repeat`, `-at-by-name`, `-at-text-only`, `-at-last`, `-req-by-name`, `-clin-by-name`,
 `-door-open`, `-door-repeat`, `-door-adjacent`, `-door-not-text`, `-several-own-board`, `-own-takes-entry`,
 `-own-cycle-entry-refused`, `-own-board-refused`, `-own-board-unsaid`, `-say-first-only`, `-say-entry-garbled`,
 `-folder-refused`, `-sidecar-refused`, `-refusal-untrue`, `-advice-unwarned`, `-repeat-row-clears`, `-first-row-alone`,
 `-repeat-row-unsaid`, `-add-key-reused` and `-add-steps-once` are caught. Still open: a locked cycle's list cannot be put
 right in the product.

U33, "Evidence so far" cell, append:
 **Reproduced** (cycreg track, 12 Oct, 7:40 PM ET) on `d66dd60` the same way, with the list [K1, "__none__"] and R1 on no
 combination: USAF $1,800 and ANG $400 ($900 under the "__none__" entry's codes, 22222 / BBBBB, and $900 again as not
 assigned) against $900 and $200 by hand. The control (K1, K2, R1 on none) gave $900 / $200. With R1 on the entry named
 "__none__" itself the same file gave the same $1,800 / $400 (fix round, 13 Oct, 4:26 AM ET). A list entry keyed
 "constructor", in a file opened directly, made `d66dd60`'s workbook export fail (verification round 2, 13 Oct).

U33, "Status" cell, append:
 **Fixed in `<sha>` (<time> ET)**: the RCN-EEIC sheet's rows are named 'e' and the row of the entry the board finds, never
 an entry's key, so no entry can be the not-assigned row ("__none__") or a name every object answers to; the money on no
 combination is counted once, as not assigned. A file handed over with a key beginning with two underscores is refused,
 naming where it sits; the user's own board is taken and says so (U32). Same block as U32. Mutations
 `v200-cycreg-key-as-name`, `-door-underscores` and `-door-sentinel-only` are caught.
