<!-- Text to APPEND to the rows of recovery/v200/UNRESOLVED-LEDGER.md (rows U32 and U33 exist at orbit-board 60336a0).
     <sha> = the lead's commit; <time> = when the lead commits, in ET. Appended to the "Evidence so far" cell and the
     "Status" cell as marked. Fix round of 13 Oct: SUPERSEDES drafts/LEDGER-append.md (its "Fixed" text described the
     12 Oct build, which the verifiers found still doubled money for a number key beside the same text and froze the
     shared folder). The "Evidence so far" text is unchanged from it except the last sentence of each. -->

U32, "Evidence so far" cell, append:
 **Reproduced** (cycreg track, 12 Oct, 7:40 PM ET) on `d66dd60` (board `fce8a391`) through the product's own Import a full
 board into the user's own board, the same browser reopened, PB27 viewed and the workbook read from its bytes: USAF $1,800,
 ANG $400, all services $2,200 against $900, $200 and $1,100 worked by hand (K1's row printed twice; every service total in
 the breakout doubled too). The same file opened directly, and each saved and reopened, gives the same. The door passed it.
 Controls (K1, K2) gave $900 / $200. Add RCN / EEIC gave two entries the same key when two adds came in one millisecond
 after a removal. Verification round 1 (12 Oct, 11:13 PM–11:45 PM ET) found the same doubling for the working plan's own
 list, for its NOT FUNDED Ask (USAF $1,800 / ANG $400), and for a list holding the number 1 beside the text "1" (still
 $1,800 / $400 on the 12 Oct build).

U32, "Status" cell, append:
 **Fixed in `<sha>` (<time> ET)**: the RCN-EEIC sheet counts each key once, and only a key that is text; Add RCN / EEIC
 never reuses a key. A file handed over with a list that repeats a key, holds a key that is not text, or an entry that is
 not one is refused, naming the list, what it holds and where, in true words; nothing is taken and browser storage is
 unchanged. ⬅ Import a full board takes the user's own board with such a list and says what it holds, before and after;
 the shared folder's copy and the sidecar are read as before. ✕ on a row that repeats a key removes that row alone.
 audit-recon "v2.00 (CYCREG) …": 50 of its 90 checks fail before, all pass after. Mutations `v200-cycreg-keys-repeat`,
 `-keys-by-value`, `-keys-cycle-only`, `-notfunded-repeat`, `-door-open`, `-door-repeat`, `-door-adjacent`,
 `-door-not-text`, `-own-takes-entry`, `-own-board-refused`, `-own-board-unsaid`, `-folder-refused`, `-sidecar-refused`,
 `-refusal-untrue`, `-repeat-row-clears`, `-repeat-row-unsaid` and `-add-key-reused` are caught. Still open: a locked
 cycle's list cannot be put right in the product.

U33, "Evidence so far" cell, append:
 **Reproduced** (cycreg track, 12 Oct, 7:40 PM ET) on `d66dd60` the same way, with the list [K1, "__none__"] and R1 on no
 combination: USAF $1,800 and ANG $400 ($900 under the "__none__" entry's codes, 22222 / BBBBB, and $900 again as not
 assigned) against $900 and $200 by hand. The control (K1, K2, R1 on none) gave $900 / $200. With R1 on the entry named
 "__none__" itself the same file gave the same $1,800 / $400 (fix round, 13 Oct, 4:26 AM ET).

U33, "Status" cell, append:
 **Fixed in `<sha>` (<time> ET)**: the sheet's not-assigned bucket is a Symbol, which no list key can equal, so an entry
 keyed "__none__" is an ordinary combination there and the money on no combination is counted once, as not assigned. A file
 handed over with a key beginning with two underscores is refused, naming where it sits; the user's own board is taken and
 says so (U32). Same block as U32. Mutations `v200-cycreg-none-is-text`, `-none-money-unseen`, `-none-ask-unseen`,
 `-door-underscores` and `-door-sentinel-only` are caught.
