<!-- Draft for NEXT-VERSION.md, under "### v2.00", after the U14 bullet and before "- **Unresolved after R1–R5 (11 Oct).**".
     Fix round of 13 Oct: SUPERSEDES drafts/NEXT-VERSION-entry.md (the builder's of 12 Oct). The lead commits; <sha> is the commit's. -->
- **U32 and U33 — an RCN / EEIC list that repeats a key, or holds "__none__" or a key that is not text, never counts money
  twice; a file handed over with one is refused, and the user's own board comes across saying what it holds** (Codex's
  review of `main`, as Brad supplied it, 12 Oct, about 6:05 PM ET: "Duplicate K1 registry entries." and "One registry entry
  named __none__." "Both accept an imported cycle and export USAF $1,800 / ANG $400 from independently expected $900 /
  $200."). The RCN-EEIC by Month sheet printed a row for every entry of an RCN / EEIC list. A list that named K1 twice --
  a locked cycle's, which a cycle in an imported file brought with it, or the working plan's -- printed K1's row twice and
  put its money twice into each service total, the grand total and the NOT FUNDED Ask: on the synthetic fixture USAF $1,800
  and ANG $400, where the money is $900 and $200. An entry keyed "__none__", the name the sheet used for money on no
  combination, printed that money under its own codes and again as not assigned. The sheet found money by a key's NAME, so
  a list holding the number 1 beside the text "1" was one combination printed twice as well. Now the sheet counts each key
  once and only a key that is text, as the board finds a combination by its text key; money on no combination is a bucket
  no key can name. The door every file handed over passes (⬅ Import one appropriation, ⇊ several boards, packages,
  submittals, band ladders) refuses an RCN / EEIC list that repeats a key, holds a key beginning with two underscores, a key
  that is not text, an entry with no key, or an entry that is not one; it says which list, what it holds and why, takes
  nothing, and no longer says that ORBIT never writes such a list: an ORBIT before this one took one without a word, and
  could save it. ⬅ Import a full board -- the user's own board, Brad's way onto a new version -- takes those lists as the
  file holds them, says what each holds in the question asked before anything is replaced and again once the board has
  reopened, and refuses only an entry that is not one, which every reader of the list stops at. The shared folder's copy and
  the sidecar beside the board are read as before: refusing them froze the team's folder, every later Save refused. On the
  🗂 RCN / EEIC panel a row that repeats an earlier row's key says so, and ✕ on it removes that row alone, changing no
  assignment. Add RCN / EEIC no longer gives a new entry a key still in use.
  - **What users may see:** a board that holds such a list exports each combination once -- its RCN-EEIC totals and NOT
    FUNDED Ask fall by what was doubled, money on no combination reads as not assigned, and a requirement on the text key
    "1" is printed under that entry's codes, the ones the screen shows. A file handed over with such a list is refused: "⚠
    Nothing imported — “cycle.html” was refused: the RCN / EEIC list at the saved state.cycDb.byAp.om.cycles.PB|2027.rcn
    holds the key “K1” twice (rcn[0] and rcn[1]); a key names one combination.", with an alert ending "An RCN / EEIC list
    names each combination once, by a text key of its own. An ORBIT before this one took such a list without a word and
    could save it with its board: a board of your own comes across whole, its lists as they are, with 📁 File → ⬅ Import a
    full board, which says what they hold; a list that is not a locked cycle’s can be put right on the board that holds it,
    in 🗂 RCN / EEIC. Nothing on this board was changed." A full import's question, and the reopened board, add "RCN / EEIC
    lists as the file holds them, which a file handed over is refused for: O&M PB27’s list holds the key “K1” twice (rcn[0]
    and rcn[1]). Each requirement reads the first entry with its key, as the ORBIT that saved the file did, and the RCN-EEIC
    sheet counts each key once and money on no combination only as not assigned". The panel's "Used by" on a repeated row
    reads "⚠ repeats row 1".
  - **Test:** audit-recon "v2.00 (CYCREG) — an RCN / EEIC list that repeats a key, or holds “__none__” or a key that is not
    text, never counts money twice: a file handed over with one is refused, and the user’s own board comes across saying
    what it holds" (90 checks). Codex's two shapes in PB27's own list, R1 on K1 and on none, and on the entry named
    "__none__"; the working plan's list [K1, K1]; [1, "1"] in the working plan and as read by PB27 locked before v1.99; R1
    unfunded on [K1, K1]; and a control on ordinary distinct keys beside each. Each through the door, ⬅ Import one
    appropriation, ⬅ Import a full board into the user's own board with the same browser reopened and then saved and
    reopened, and the file opened directly and then saved and reopened, as each case needs. The RCN-EEIC sheet is read from
    the workbook's bytes against literals worked by hand: USAF 900 and ANG 200 in the award month and in TOTAL, all
    services 1,100, every service total in the breakout, and the NOT FUNDED Ask USAF 900 / ANG 200. Every refusal and
    every statement is checked word for word, browser storage byte-identical where nothing is taken. Also: an entry that is
    not one (refused at the door and by the full import), the door on a key repeated apart, three times, beginning with two
    underscores, missing and not text; the shared folder's copy and the sidecar read with their list; ✕ on a repeated row;
    Add RCN / EEIC in one millisecond after a removal. 50 checks fail on the board before the change (USAF 1,800, ANG 400,
    all services 2,200; NOT FUNDED Ask 1,800 / 400; the door passing every list; ✕ clearing R1's assignment); the 40
    controls and fixtures pass on both.
  - **Mutations:** `v200-cycreg-keys-repeat`, `-keys-by-value`, `-keys-cycle-only`, `-notfunded-repeat`,
    `-none-is-text`, `-none-money-unseen`, `-none-ask-unseen`, `-door-open`, `-door-repeat`, `-door-adjacent`,
    `-door-underscores`, `-door-sentinel-only`, `-door-not-text`, `-own-takes-entry`, `-own-board-refused`,
    `-own-board-unsaid`, `-folder-refused`, `-sidecar-refused`, `-refusal-untrue`, `-repeat-row-clears`,
    `-repeat-row-unsaid` and `-add-key-reused`; each caught by the focused block (full-suite sensitivity runs in the
    final-tree queue).
  - **Not covered:** a board that already holds an entry that is not one (taken before this change, or a file opened
    directly, which no door checks) still cannot export its workbook or show its RCN / EEIC panel, as before. A locked
    cycle's list cannot be put right in the product: a file handed over that carries it is refused, and ⬅ Import a full
    board carries it. ✕ on the FIRST row of a repeated key clears every assignment to that key, as its question says. The
    pickers and the menu's "N combos" list a repeated key's rows as they are. An assignment that is a number, which only a
    hand-made file holds, is filed under the text key of the same name, or as not assigned when there is none, while the
    screen reads it against a number-keyed entry. ⇊ Import several boards, packages, submittals and band ladders run the
    same door but are not driven by this block. The SI sheet walks the fixed SI code list and was never affected.
