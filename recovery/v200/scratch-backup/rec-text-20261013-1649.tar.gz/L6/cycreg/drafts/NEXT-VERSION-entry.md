<!-- Draft for NEXT-VERSION.md, under "### v2.00", after the U14 bullet and before "- **Unresolved after R1–R5 (11 Oct).**".
     The lead commits; <sha> is the commit's. -->
- **U32 and U33 — an RCN / EEIC list that repeats a key, or holds "__none__", is refused at the door; the RCN-EEIC sheet
  counts each key once** (Codex's review of `main`, as Brad supplied it, 12 Oct, about 6:05 PM ET: "Duplicate K1 registry
  entries." and "One registry entry named __none__." "Both accept an imported cycle and export USAF $1,800 / ANG $400 from
  independently expected $900 / $200."). A locked cycle carries the RCN / EEIC list it was locked with (item 88), and a cycle
  in an imported file came across with whatever list it held. The RCN-EEIC by Month sheet printed a row for every entry of
  the list, so a cycle whose list named K1 twice printed K1's row twice and put its money twice into each service total and
  the grand total: on the synthetic fixture USAF $1,800 and ANG $400, where the money is $900 and $200. An entry keyed
  "__none__", the name the sheet used for money on no combination, took that money: it was printed under the entry's codes
  and again as not assigned, doubled the same way. Now the import door refuses a file whose RCN / EEIC list (the working
  plan's or a locked cycle's) holds a key twice or a key beginning with two underscores, and says which list, which key and
  why; nothing of the file is taken. The sheet counts each key once, and its not-assigned row is a value no list entry can
  equal, so a list the board already holds (a file opened as the board, which no door checks) is counted right as well.
  Add RCN / EEIC no longer gives a new entry a key still in use (two adds in the same millisecond after a removal did).
  - **What users may see:** a file carrying such a list is refused, the board unchanged: "⚠ Nothing imported — “cycle.html”
    was refused: the RCN / EEIC list at the saved state.cycDb.byAp.om.cycles.PB|2027.rcn holds the key “K1” twice (rcn[0]
    and rcn[1]); a key names one combination." or "… the RCN / EEIC key at the saved
    state.cycDb.byAp.om.cycles.PB|2027.rcn[1].k “__none__” begins with two underscores, which the board keeps for its own
    bookkeeping.", with the same words in the alert. A board that already holds such a list exports each combination once:
    its totals fall by the doubled amount, and money on no combination reads as not assigned instead of under a "__none__"
    entry's codes.
  - **Test:** audit-recon "v2.00 (CYCREG) — a cycle whose RCN / EEIC list repeats a key or holds “__none__” is refused at
    the door, and the RCN-EEIC sheet counts each key once" (31 checks): Codex's two shapes and two ordinary-key controls (K1
    and K2, with R1 on K1 and on none), each through the door, a full import into the user's own board with the same browser
    reopened and then saved and reopened, and the file opened directly and then saved and reopened. PB27's RCN-EEIC sheet is
    read from the workbook's bytes against literals worked by hand: USAF 900 and ANG 200 in the award month and in TOTAL,
    all services 1,100, and every service total in the breakout. The refusal words are checked literally, with browser
    storage byte-identical. Also the working plan's own list at the door (with a control), and Add RCN / EEIC in one
    millisecond after a removal. 14 checks fail on the board before the change (USAF 1,800, ANG 400, all services 2,200);
    the 17 controls pass on both.
  - **Mutations:** `v200-cycreg-keys-repeat`, `-none-is-text`, `-door-repeat`, `-door-underscores`,
    `-none-money-unseen` and `-add-key-reused`; each caught by the focused block (full-suite sensitivity runs in the
    final-tree queue).
  - **Not covered:** a board that already holds such a list (taken before this change) is not told so when it opens. Its
    export is right, but its RCN / EEIC panel still lists a repeated key's rows, and Remove on one of them clears every
    assignment to that key, as its question says. Its saved file is refused by another board's door until the list is
    corrected. The other import routes (Import, one appropriation, several boards at once, folder copies, the shared state
    file) run the same door but are not driven by this block. The pickers and the menu's "N combos" count list a repeated
    key's rows as they are. The SI sheet walks the fixed SI code list and was never affected.
