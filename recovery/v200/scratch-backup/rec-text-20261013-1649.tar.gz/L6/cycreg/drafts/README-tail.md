## Drafts for the lead
- `drafts/NEXT-VERSION-entry.md`: the v2.00 entry (U13/U1/U14 style), to go after the U14 bullet.
- `drafts/UNRESOLVED-line.md`: there is NO existing line for U32/U33 in "Unresolved after R1–R5" on the base (searched),
  so this is a proposed NEW line, not a replacement.
- `drafts/LEDGER-append.md`: text to append to rows U32 and U33 of `recovery/v200/UNRESOLVED-LEDGER.md` (the rows exist at
  orbit-board `60336a0`), with `<sha>` and `<time>` placeholders.
- `drafts/COMMIT-MSG.txt`: the commit message (the attribution lines are the lead's to add).

## PIDs
`pids.txt`: every timeout PID and its child, recorded by `bin/run.sh` and `bin/bx.sh` with the command; also the three
background wrappers (`batch-wrapper`, `final-focused-wrapper`, `recon-final-wrapper`). I killed nothing. Every run ended
on its own (exit codes above), and no run hit its 600 s cap.

## What I did NOT do
- I did not run the full `audit-import.mjs` or `audit-board.mjs` (the lead's). Instead I ran focused audit-import
  harnesses, built verbatim with `rec/L2/u2impl/mkfocused-u2.py`, from the two blocks that put the board's own saved files
  through `inboundCheck` ("v1.96 review" and "v1.97 W1"). They pass on base and c1. audit-board's RCN blocks (v1.97 W1
  rcnSet, v1.98 item 83 CLIN grid) touch neither the door, monSheet nor rcnAdd (checked by reading), so they were not run.
  audit-import's full-import tests (files written by v1.80–v1.87, through `git show`) go through the new door and were not
  run. A file from those versions with a repeated or `__`-prefixed RCN key would now be refused; rcnAdd in those versions
  wrote `r…` keys.
- I did not import, execute or run `mutate.mjs`. It was read as text only (mcount.py / mkmut.py), and the scratch clones
  keep the repository's own mutate.mjs untouched and unrun.
- Nothing is edited, staged, committed or pushed in /home/user/orbit-board or /home/user/orbit-ui. The scratch clones
  (`gc/base`, `gc/c1`, `git clone --shared`) were never committed to.
- No playwright install, and no Chromium run (none was needed: every check is jsdom).
- The board file stays the empty template. Synthetic data exists only at run time.
- Not built: a notice when a board that already holds a repeated or `__` key opens, a way to repair such a list, or a
  guard on Remove for a repeated row (Remove clears every assignment to that key, as its question already says). These
  are proposed follow-ups for the lead, not part of this fix.
- The other import routes (Import, one appropriation, several boards, folder copies, the shared state file, band import)
  run the same `inboundCheck`, but this block drives only the door itself and Import a full board.

## Notes on the runs (read before trusting a line above)
- **Suites: base and c1 match.** Every allowed suite passes on both. boot-same, legacy-fsrc and `npm run check` print
  their own pass lines ("every page, source, save and error list is identical either way", "every legacy Force setting
  computes exactly as before", "all checks passed"), found in both logs, and exit 0. audit, audit-ppt, audit-other,
  audit-recon, audit-hostile and audit-inject print ALL CHECKS PASSED on both.
- **S-audit-recon-c1 (7:53 PM) ran audit-recon blob `3616efcb`.** That is the block before a comment-only edit (the
  "FAILS ON" line now names `d66dd60` and the 14/31 count). The final blob `9c2cdd88` was re-run whole as
  **S-audit-recon-c1-final** (8:00 PM ET, exit 0, 295.9 s, ALL CHECKS PASSED). The focused F1-* and M-* runs used the
  harness before that edit (`02b53ec8`). The F2-* runs are the final ones (harness `e4770166`, built verbatim from the
  final suite): c1 31/31; base 17 pass, 14 fail; every mutant caught.
- The first FI-* runs exited 1 in about 2 s, before any check, because jsdom could not be found from the harness folder.
  A `node_modules` symlink was added to `harness/c1/`, and FI2-* are the real runs.
- probe-base-1 exited 1 on purpose-free grounds: the probe called buildSavedHtml while the locked view was on screen.
  The probe was fixed to leave the view, and probe-base-2 is the reproduction.
- The AUDIT_IMPORT_RUNNING lock was never present, so no run waited.
- **Deviations from "every command bounded by setsid -w timeout -k 10 600":** three non-node commands. The first look
  at this folder (ls/cat/grep, 7:31 PM) was unbounded. Two wait loops (`timeout 1500 bash -c 'until grep …'` and
  `timeout 290/580/170 bash -c …`, sleeping on file checks) were bounded by `timeout` but not by setsid, and one ran past
  600 s of cap. The background batch wrappers were capped at 7000 s and 3000 s around many 600 s runs. Every node run
  itself went through run.sh. The PIDs I could see are in `pids.txt`.
