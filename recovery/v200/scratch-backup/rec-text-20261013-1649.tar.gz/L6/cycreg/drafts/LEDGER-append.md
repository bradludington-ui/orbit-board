<!-- Text to APPEND to the rows of recovery/v200/UNRESOLVED-LEDGER.md (rows U32 and U33 exist at orbit-board 60336a0).
     <sha> = the lead's commit; <time> = when the lead commits, in ET. Appended to the "Evidence so far" cell and the
     "Status" cell as marked. -->

U32, "Evidence so far" cell, append:
 **Reproduced** (cycreg track, 12 Oct, 7:40 PM ET) on `d66dd60` (board `fce8a391`) through the product's own Import a full
 board into the user's own board, the same browser reopened, PB27 viewed and the workbook read from its bytes: USAF $1,800,
 ANG $400, all services $2,200 against $900, $200 and $1,100 worked by hand (K1's row printed twice; every service total in
 the breakout doubled too). The same file opened directly, and each saved and reopened, gives the same. The door passed it.
 Controls (K1, K2) gave $900 / $200. Add RCN / EEIC gave two entries the same key when two adds came in one millisecond
 after a removal.

U32, "Status" cell, append:
 **Fixed in `<sha>` (<time> ET)**: the import door refuses a list holding a key twice (the working plan's or a locked
 cycle's), naming the list, the key and both places; nothing is taken and browser storage is unchanged. The RCN-EEIC sheet
 walks each key once; Add RCN / EEIC never reuses a key. audit-recon "v2.00 (CYCREG) …": 14 of its 31 checks fail before,
 all pass after. Mutations `v200-cycreg-keys-repeat`, `-door-repeat` and `-add-key-reused` are caught. Still open: a board
 that took such a list before the fix is not told on opening.

U33, "Evidence so far" cell, append:
 **Reproduced** (cycreg track, 12 Oct, 7:40 PM ET) on `d66dd60` the same way, with the list [K1, "__none__"] and R1 on no
 combination: USAF $1,800 and ANG $400 ($900 under the "__none__" entry's codes, 22222 / BBBBB, and $900 again as not
 assigned) against $900 and $200 by hand. The control (K1, K2, R1 on none) gave $900 / $200.

U33, "Status" cell, append:
 **Fixed in `<sha>` (<time> ET)**: the import door refuses an RCN / EEIC key that begins with two underscores ("__none__"
 among them), naming where it sits; nothing is taken. The sheet's not-assigned bucket is now a Symbol, which no list key
 can equal, so a "__none__" entry the board already holds is an ordinary combination there and the money on no
 combination is counted once. Same block as U32. Mutations `v200-cycreg-none-is-text`, `-door-underscores` and
 `-none-money-unseen` are caught.
