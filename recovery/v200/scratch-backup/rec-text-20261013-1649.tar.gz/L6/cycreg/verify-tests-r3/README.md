# CYCREG, round 3: independent adversarial verifier, lens B (test adequacy and regressions)

Written 13 Oct 2026, from 2:16 PM ET; last edited at 3:12 PM ET (all times Eastern, from `TZ=America/New_York date`). This is the first attempt of this
review: `verify-tests-r3` did not exist when I started (1:20 PM ET), so nothing was reused from an earlier attempt of it.
I edited none of the builder's files and nothing in `/home/user/orbit-board` or `/home/user/orbit-ui`; I staged, committed and
pushed nothing. mutate.mjs was never imported or run (text only, through `rec/bin/mcount.py` and `rec/bin/mkmut.py`).

`<V>` = this folder, `.../rec/L6/cycreg/verify-tests-r3`; `<B>` = the builder's folder `.../rec/L6/cycreg`.

**Verdict: sound-with-issues.** The product change does what the builder says on every route the block drives. Every builder
run I repeated gives the same result, check for check. The three mutations the task names are caught with the builder's
counts. The suites I may run pass on the fix as they do on the base, but one: the whole audit-recon never completed under this
machine's load and memory (OOM-killed once, at the 600 s cap twice). Six of my twelve own plausible wrong fixes pass all
142 CYCREG checks, and one of them misfiles money in the workbook:

- **MUST-FIX 1 (money).** rcnAt's empty-pointer guard (`if(!p) return '';`, new in this commit) has no check. Delete it and every
  CYCREG check still passes, yet the XLSX files R1's USAF $900 / ANG $200 under an entry keyed "" (33333 / CCCCC) instead of
  "— no RCN/EEIC assigned —". The screen shows R1 on no combination. The minimal fix is one CONTROL case and one mutation
  entry, written and run below.
- **S1–S4 (should-fix).** S1: nothing tells the team's own copies ('copy') from the user's own board ('board'). S2: the door's
  mode can outlive a full import that stops early. S3: the door can throw instead of refusing for "constructor" keys. S4: ✕ on
  a repeated row is never checked as saved. Proposed checks for each are written, fail on the base where the rule is new, pass
  on the fix, and catch the mutant.

## Identities (git hash-object)

| file | base `<V>/b0` (= `rec/L6/base`, 7ee498a, product d66dd60) | fix `<V>/fx` (= `<B>/fr2/c1`) |
|---|---|---|
| prioritization-board-grid.html | fce8a391bd8a248d5185e199d22190c1687eaea0 | 59cff8f34a04d656604c352909966b27998f7384 |
| tools/export-audit/audit-recon.mjs | 529e36f7c20e635b2722ea53b6a4f44b4ed328af | 03b7fda90c0a3dd6f90e02b19d731ebc6d7bd16d |
| tools/export-audit/mutate.mjs.txt | cbc6defc6803851e847844848fc9b186daeeb268 | 755c298941d34f83c52ee765d931f6345cd8d652 |
| audit-import / audit-board / audit-other | 4aba2506 / a7c575e5 / d89396b0 | unchanged |
| boot.mjs | 9c4f49ad | unchanged |

- `diff -rq rec/L6/base <V>/b0` and `diff -rq <B>/fr2/c1 <V>/fx` are both empty. `diff -rq b0 fx` lists only the board,
  audit-recon.mjs and mutate.mjs.txt.
- The focused harness `<V>/h/h-cycreg.mjs` is the builder's `fr2/harness/h-cycreg.mjs` (26a9ee0c). `bin/chkverb.py` shows its
  CYCREG block is byte-identical to the fix's audit-recon block (295 lines), and every other line in it, but the FOCUSED header
  comment, is an audit-recon line. The runner is the builder's `bin/runner.mjs` (f851f139), unchanged.
- Scratch clone `<V>/gc/fx`: `git clone --shared /home/user/orbit-board` at detached 7ee498a, with the fix's board, audit-recon
  and mutate.mjs.txt copied in, the node_modules symlink and runtime-encoding-shim.mjs. Never committed to. It also holds the
  builder's focused audit-import / audit-board harnesses, copied unchanged (blobs below).
- All my blobs are in `out/blobs.txt` and `out/blobs-final.txt` (scripts and outputs written after the first list).

## Suite diffs against the base: no existing expectation changed (principle 6)

- `diffs/audit-recon.diff`: one hunk, **+295 −0**. It is the block `// ==== v2.00 (CYCREG): …` to `// ==== end v2.00 (CYCREG) ====`,
  after `end v2.00 (U14)` and before the scenario-ran guard.
- `diffs/mutate.diff`: one hunk, **+91 −0**. 30 `v200-cycreg-*` entries and one comment line, directly before
  `// v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.`
- `diffs/board.diff`: 17 hunks, +101 −14 (identical in content to the builder's `diffs/fr2-c1-board.diff`).
- **No existing check, fixture or expected value is changed** in any suite file: audit-recon and mutate are pure additions, and
  the other suites are byte-identical to the base.
- House style: async wrapper, `bootMark()` / `bootRelease(__bm, [])` / `settleBoards()` (audit-recon has no `keepBoards`; 24
  base blocks use `bootRelease(__bm, [])`), the two-space `  const name = '…'` line (its quotes are U+2019, never an ASCII
  apostrophe), and the `// ====` markers. The guard sees the scenario (no "never ran" failure on either board).

## Every new expected value is a literal; every new check fails on the base

- Every `want` in the block is a hand-written literal or a concatenation of literal constants (`ROWS`, `WANT`, `WANT_NF`,
  `NF_HEAD`, `SAYS`, `LIST_TAIL`, `ENTRY_TAIL`, `AT_PB`, `AT_WP`, `TWICE`, `NOT_TEXT`, `WP_NT`, `ON_*`). Board helpers appear only
  on the observed side.
- **Base: 86 fail, 56 pass** (V3-F-b0), exactly the builder's FX3-base: the same 142 (check, verdict) pairs in the same order
  and the same observed values, string for string. I classified the 56 passes by name: 22 fixtures, 27 CONTROL checks
  and 7 GUARD money checks. No other check passes on the base.
- **The base failures show the doubling, read from the XLSX bytes.** Codex 1 prints `11111 / AAAAA` twice per service:
  USAF TOTAL 1,800 and ANG TOTAL 400. Codex 2 prints `22222 / BBBBB` and `— no RCN/EEIC assigned —` at 900 each, which also
  gives USAF 1,800 / ANG 400. Both shapes do this after import and reopen, after save and reopen, and when the file is opened
  directly.
- **Fix: 142 of 142 pass** (V3-F-fx), the same values as the builder's FX3-fix.
- What the block reads from the bytes: the award-month cell (column 3), NO DATE and TOTAL of every row before the breakout,
  every `<SERVICE> TOTAL` (summary and breakout), `ALL SERVICES — TOTAL BY MONTH`, and the NOT FUNDED Ask. It asserts USAF 900,
  ANG 200, AFRC 0 and all services 1,100 literally, as the task asks.

## mcount (text only, `python3 -I rec/bin/mcount.py`; 1:23 PM ET)

| mutate | board | entries | found once | missing |
|---|---|---|---|---|
| fix | fix | 1,358 | 1,358 | none |
| base | fix | 1,328 | 1,328 | none: every existing entry still applies |
| fix | base | 1,358 | 1,329 | the 29 new finds that are new code; `v200-cycreg-several-own-board`'s find is a base line, as the builder says |
| base | base | 1,328 | 1,328 | none |
| fix + my 5 proposed entries | fix | 1,363 | 1,363 | none |

## The builder's runs, repeated

| builder's run | mine | same? |
|---|---|---|
| FX3-base: 86 fail / 56 pass | V3-F-b0: 86 / 56 | yes: every (check, verdict, observed value) identical |
| FX3-fix: 142 / 142 | V3-F-fx: 142 / 142 | yes, identical |
| FX3-mut-v200-cycreg-keys-repeat: 14 fail | V3-M-v200-cycreg-keys-repeat: 14 | yes, the same 14 checks (mutant blob e0255273 = the builder's) |
| FX3-mut-v200-cycreg-key-as-name: 28 | V3-M-v200-cycreg-key-as-name: 28 | yes, the same 28 (9c3feec8) |
| FX3-mut-v200-cycreg-door-open: 24 | V3-M-v200-cycreg-door-open: 24 | yes, the same 24 (ded823cc) |
| S-audit-recon-fr2r-mut-clin-by-name: 11 fail in the whole audit-recon | S3-audit-recon-mut-clin-by-name (2:36:17 PM ET, exit 1, 403.2 s) | yes: 11 failing, the same 11 checks with the same failure text as the builder's log (7 in v1.98 item 83, 4 in v1.99 item 88); mutant blob 015d4457 = the builder's |
| mcount 1,358 / 1,328 / 1,329 | out/mcount-*.txt | yes |
| suites on fr2 (boot-same, audit, audit-ppt, audit-other, audit-recon, legacy-fsrc, audit-hostile, audit-inject, check) | S3-*-fx in `gc/fx` | yes for every suite but audit-recon: boot-same, audit, audit-ppt, legacy-fsrc, audit-hostile, audit-other, audit-inject and check all pass. The whole audit-recon did not finish in any of my three tries (below), so I cannot repeat the builder's S-audit-recon-fr2r pass myself |
| focused audit-import hi-w2 242, hi-w1 53, hi-v200 167, hi-v197w3 111, hi-v197w1 15; audit-board hb-v197w1 178 | V3-F-hi-w2-fx, -hi-w1-fx, -hi-v200-fx, -hi-v197w3-fx, -hi-v197w1-fx, -hb-v197w1-fx | yes: all pass, with the same per-scenario counts (242, 53, 167, 111, 15, 178). Harness blobs are identical to the builder's files (see M1 below) |

**The whole audit-recon on the fix did not finish in any of my three tries.** None of them failed a check:
- S3-audit-recon-fx (2:08:44 PM ET) was killed by the memory cgroup's OOM killer at 576 s (exit 137; dmesg: "Killed process 2488
  (node)", my node PID). It had 306 recorded checks, none failing.
- S3b-audit-recon-fx (2:43:04 PM ET) hit the 600 s cap (exit 124). It had 433 recorded checks, none failing, including 127 of the
  CYCREG block's 142.
- S3c-audit-recon-fx (3:00:41 PM ET) hit the cap as well (exit 124, load average about 46). It had 282 recorded checks, none
  failing.
- Each ran alone; no other node process of mine was running.
- Recorded checks are those that go through w5Chk; the older blocks' chk failures are printed only at the end. So these
  partial runs are not a pass.

What stands in their place:
- The builder's S-audit-recon-fr2r (exit 0, 593.5 s).
- My V3-F-fx: the CYCREG block, 142 of 142.
- My **S3-audit-recon-mut-clin-by-name, which did finish (403.2 s).** Its board differs from the fix by one line, a CLIN pointer.
  It failed exactly the 11 CLIN checks the builder reports, with identical failure text. So every other check in the whole
  audit-recon, the CYCREG block included, passed on that board.
- The lead's full runs remain the authority.

The 27 other builder mutants were not re-run; round 2's lens-B verifier re-ran the round-1 set, and the three task mutants
above match the builder's failing-check lists exactly (`fr2/mutant-failures.txt`).

## My own mutants: 12 plausible wrong fixes (`bin/mkvm3.py`, `mut/vm3/`, specs in `mut/vm3/specs.json`)

Each find was checked to match the fix board exactly once; each run is the focused CYCREG block (142 checks).

| mutant (what a wrong fix would do) | CYCREG block | failing checks / what the survivor does |
|---|---|---|
| vm3-label-by-token: label a row by its token, not the entry it names | caught | 44 |
| vm3-breakout-keysOf: the breakout walks the list as it is | caught | 12 (every breakout `<SERVICE> TOTAL` doubled) |
| vm3-rollup-keysOf: the summary walks the list as it is | caught | 12 |
| vm3-say-cycles-dropped: the full import names only working-plan lists | caught | 8 |
| vm3-odd-unsorted: rcnListOdd's findings left in the order found | caught | 3 |
| vm3-mode-not-cleared: inboundCheck never clears the asked-for mode | caught | 1 (only "the team's own copies · the same text, handed over") |
| **vm3-at-no-guard**: rcnAt without `if(!p) return '';` | **survives 142/142** | XLSX: R1's USAF 900 / ANG 200 under "33333 / CCCCC" (an entry keyed "") instead of not assigned |
| **vm3-folder-as-board**: driveParse reads the folder copy as 'board', not 'copy' | **survives 142/142** | a folder copy whose plan list holds a null entry throws "a copy in the shared folder was refused: …" |
| **vm3-sidecar-as-board**: loadShared (fetch) reads the sidecar as 'board' | **survives 142/142** | that sidecar reads as no file (null) |
| **vm3-mode-cleared-by-own**: the mode is cleared by inboundCheckOwn, not inboundCheck (two edits) | **survives 142/142** | after a full import of a non-board, or one answered No, the next file handed over with K1 twice passes the door ('') |
| **vm3-at-plain-object**: rcnListOdd indexes keys in `{}` | **survives 142/142** | the door throws "at[k].push is not a function" for a "constructor" / "toString" key instead of refusing in words |
| **vm3-del-nosave**: ✕ on a repeated row without save() | **survives 142/142** | the same browser reopened has the removed row back |

## Findings

### MUST-FIX 1 (tests, money): rcnAt's empty-pointer guard has no check

- **The line.** `const rcnAt=function(p){ const L=rcnReg(); if(!p) return ''; for(…`. It is new in this commit (exportExcel). It
  keeps a requirement or CLIN on no combination (pointer `''`) out of any entry and in the not-assigned row.
- **Reproduction.**
  - V3-M-vm3-at-no-guard (1:32:18 PM ET, exit 0): with that guard deleted (blob 15b95438), all 142 CYCREG checks pass.
  - V3-P-vm3-at-no-guard (2:03:53 PM ET, exit 1): the fixture is the working plan's list [K1, {k:"", 33333 / CCCCC}] with R1 on no
    combination. That list passes the door: "" is text, appears once and has no leading underscores. The file is opened
    directly and exported, and the sheet is read from the XLSX bytes:
    - on the mutant, `["USAF","33333 / CCCCC",900,0,900] … ["ANG","33333 / CCCCC",200,0,200]`;
    - on the fix (V3-P2-fx) and on the base (V3-P2-b0), `— no RCN/EEIC assigned —` at 900 / 200, the place the screen shows R1.
  - Totals stay 900 / 200 / 1,100, but the money is printed on a line of accounting R1 is not on.
- **Why it is a must-fix.** It is the round-2 MUST-FIX 1 shape: a money line this commit added, where a one-line regression
  makes the export disagree with the computation (principle 3), and every check passes.
  - By grep, no suite file has an RCN entry keyed "", so no suite can catch it. I tried the whole audit-recon on the mutant
    twice: `S3-audit-recon-mut-vm3-at-no-guard` (2:18:53 PM ET) and `S3b-…` (2:53:04 PM ET). The memory cgroup's OOM killer
    stopped both (exit 137; dmesg names my node PIDs 10985 and 14651) after 296 and 298 recorded checks, none failing. So
    "whole suite" rests on the grep, not on a completed run.
- **Minimal fix (tests only; no product change).** Add one CONTROL case to the block. The case passes on d66dd60 and on the fix
  (V3-P2-b0, V3-P2-fx) and fails on the mutant (V3-P-vm3-at-no-guard). It is in `h/h-prop.mjs` as V3-P4:
  ```js
  const F = make({ asg: '', plan: [K1, E('', '33333', 'CCCCC')] }), O = boot({ html: F.file });
  w5Chk(name, 'an entry keyed “” · the file opened', 'CONTROL (as d66dd60) — … R1 on no combination is not assigned, USAF 900, ANG 200, 1,100',
    await sheet(O.w, O.ev, ''), WANT('the working plan', ON_NONE));
  ```
  Add the mutation entry `v200-cycreg-at-empty-matches` (`out/proposed-entries.mjs.txt`). Its find is
  `const rcnAt=function(p){ const L=rcnReg(); if(!p) return ''; for(`, which matches the fix board once and the base board 0
  times. mcount on the mutate text plus my entries gives 1,363 entries, each found once. The mutant mkmut.py builds from that
  entry is byte-identical to vm3-at-no-guard.

### SHOULD-FIX

- **S1 (data loss): nothing tells the team's own copies ('copy') from the user's own board ('board').**
  - The block's copies check uses [K1, K1], which both modes read. vm3-folder-as-board and vm3-sidecar-as-board pass all 142
    checks.
  - Under them, a folder copy whose working plan list holds a null entry is refused: driveParse throws "a copy in the shared
    folder was refused: the RCN / EEIC entry at the file.store.rcn[0] is not a combination (“null”) …". A sidecar with one
    reads as no file (null).
  - The base reads both. This is the round-1 M2 folder freeze ("every later Save refused"; the board's own comment at
    inboundCheckOwn) back for lists with an entry that is not one. I did not drive the freeze itself; I observed the refusal.
  - `S3-audit-hostile-mut-vm3-folder-as-board` (the whole audit-hostile, which reads folder copies through driveParse) passes
    on the mutant (2:13:54 PM ET, exit 0, 298.3 s). No suite file has a null RCN entry in a folder copy (grep).
  - Why not must-fix: a board whose list holds such an entry already cannot render its RCN / EEIC panel or export (as on the
    base, disclosed by the builder).
  - Proposed: V3-P3, two CONTROL checks (driveParse and loadShared on [null, K1]: read, `[null,"K1"]`). Both pass on base and
    fix and catch both mutants. Add entries `v200-cycreg-folder-as-own` and `v200-cycreg-sidecar-as-own`.
- **S2 (refuse, not take): the door's 'board' mode can outlive a full import that stops early.**
  - vm3-mode-cleared-by-own (clear in inboundCheckOwn rather than at the start of inboundCheck) passes all 142 checks.
  - After ⬅ Import a full board of a file that is not a board, or one answered No, the next file handed over with PB27
    [K1, K1] passes the door (`''`). The money is still right, because the sheet counts each key once, but the file is taken
    where it must be refused.
  - Proposed: V3-P2's two checks. They fail on the base (no rule), pass on the fix, and catch the mutant (2 fail). The mutant
    needs two edits, so it cannot be one mutate entry. These checks also catch the existing one-edit vm3-mode-not-cleared,
    which today only one check catches.
- **S3 (words true): the door can throw instead of refusing.**
  - vm3-at-plain-object (`at={}` in rcnListOdd) passes all 142 checks.
  - With a list keyed "constructor" or "toString", the door throws "at[k].push is not a function" instead of refusing in words.
    Importers then show nothing at all.
  - On the fix and the base such a key is refused by the existing key-value rule: "the k at the file.rcn[1] is “constructor”, a
    name the board keeps for itself or every object already answers to". rcnListOdd runs on the list before that rule reaches
    the entry.
  - The block's "constructor" case has only the 'opened' routes.
  - Proposed: V3-P1, a CONTROL with that refusal, plus "“constructor” twice" (the repeat message; it fails on base, which gives
    the generic one). Both catch the mutant. Add entry `v200-cycreg-odd-plain-object`.
- **S4: ✕ on a row that repeats a key is never checked as saved.**
  - vm3-del-nosave passes all 142 checks. The same browser reopened has the row back.
  - Proposed: V3-P5. It fails on the base, because d66dd60's ✕ clears R1, and passes on the fix. Add entry
    `v200-cycreg-del-unsaved`.

All the proposed checks together: V3-P2-fx 9/9 pass. V3-P2-b0: 4 fail (the three new-rule checks and P5) and 5 CONTROLs pass.
Every survivor fails at least one of them (V3-P-*, V3-P2-vm3-at-plain-object). One correction made along the way: my first
P1 control expected the "constructor" list to pass the door. Both boards refuse it with the existing key-value rule
(V3-P-fx, 1 fail), so P1's want was corrected to that literal refusal and re-run (V3-P2-*).

### MINOR

- **M1.** The builder's README (fix round 2 identities, lines 986–987) names four harness blobs under the wrong files. Their
  run logs show the right blobs were run: hi-v197w1 b9a3e852, hi-v197w3 e231e09f, hi-v200 edd74fd9, hb-v197w1 3893ed4b.
- **M2.** "the controls, fixtures and two guards pass on both" appears in the NEXT-VERSION "Test" text, the commit message and
  the U32 ledger cell. It is true of the two GUARD cases' money checks (7). Their door, full-import and statement checks
  fail on d66dd60, which has no list rule (6 of the 86; the GUARD cases have 13 non-fixture checks, 7 pass on the base).
- **M3.** The board comments read `// v2.00 (CYCREG …)`. The house prefix is the ledger id, `// v2.00 (Uxx): …`; the ledger rows
  and the commit title use U32 / U33.
- **M4 (product, for the money lens).** The door refuses an entry with no key but takes an entry keyed "". No pointer can reach
  that entry: a pointer of "" means none.

## Every run

Every node run went through `bin/run.sh` (49 runs). It checks the `AUDIT_IMPORT_RUNNING` lock first; the lock was never present, so no run
waited. It then runs `setsid -w timeout -k 10 600` and records the timeout PID and its node child, with the command, in
`pids.txt`. At most two node processes of mine ran at once: two serial lanes, computed from the start times and wall seconds
below. `npm run check` was run as its own script line (`node tools/check.mjs prioritization-board-grid.html`) so that npm did not
add a third node process. Text helpers (mcount, mkmut, mkvm3, mkprop, chkverb, runtable) ran under `timeout` and are in
`pids.txt`, or finished at once.

| label | start (ET, 13 Oct) | exit | wall s | result | log |
|---|---|---|---|---|---|
| V3-F-b0 | 13:22:55 | 1 | 180.9 | 86 FAILING CHECK(S) ; 56p/86f | logs/V3-F-b0.log |
| V3-F-fx | 13:22:55 | 0 | 181.5 | ALL CHECKS PASSED ; 142p/0f | logs/V3-F-fx.log |
| V3-M-vm3-at-plain-object | 13:27:38 | 0 | 139.4 | ALL CHECKS PASSED ; 142p/0f | logs/V3-M-vm3-at-plain-object.log |
| V3-M-vm3-folder-as-board | 13:27:38 | 0 | 139.6 | ALL CHECKS PASSED ; 142p/0f | logs/V3-M-vm3-folder-as-board.log |
| V3-M-vm3-sidecar-as-board | 13:29:58 | 0 | 137.6 | ALL CHECKS PASSED ; 142p/0f | logs/V3-M-vm3-sidecar-as-board.log |
| V3-M-vm3-mode-cleared-by-own | 13:29:58 | 0 | 140.4 | ALL CHECKS PASSED ; 142p/0f | logs/V3-M-vm3-mode-cleared-by-own.log |
| V3-M-vm3-mode-not-cleared | 13:32:16 | 1 | 198.6 | 1 FAILING CHECK(S) ; 141p/1f | logs/V3-M-vm3-mode-not-cleared.log |
| V3-M-vm3-at-no-guard | 13:32:18 | 0 | 206.1 | ALL CHECKS PASSED ; 142p/0f | logs/V3-M-vm3-at-no-guard.log |
| V3-M-v200-cycreg-key-as-name | 13:35:35 | 1 | 191.2 | 28 FAILING CHECK(S) ; 114p/28f | logs/V3-M-v200-cycreg-key-as-name.log |
| V3-M-vm3-del-nosave | 13:35:45 | 0 | 186.7 | ALL CHECKS PASSED ; 142p/0f | logs/V3-M-vm3-del-nosave.log |
| V3-M-v200-cycreg-keys-repeat | 13:38:52 | 1 | 271.9 | 14 FAILING CHECK(S) ; 128p/14f | logs/V3-M-v200-cycreg-keys-repeat.log |
| V3-M-v200-cycreg-door-open | 13:38:46 | 1 | 278.3 | 24 FAILING CHECK(S) ; 118p/24f | logs/V3-M-v200-cycreg-door-open.log |
| V3-M-vm3-odd-unsorted | 13:43:24 | 1 | 400.6 | 3 FAILING CHECK(S) ; 139p/3f | logs/V3-M-vm3-odd-unsorted.log |
| V3-M-vm3-breakout-keysOf | 13:43:25 | 1 | 407.9 | 12 FAILING CHECK(S) ; 130p/12f | logs/V3-M-vm3-breakout-keysOf.log |
| V3-M-vm3-label-by-token | 13:50:05 | 1 | 495.1 | 44 FAILING CHECK(S) ; 98p/44f | logs/V3-M-vm3-label-by-token.log |
| V3-M-vm3-say-cycles-dropped | 13:50:13 | 1 | 490.1 | 8 FAILING CHECK(S) ; 134p/8f | logs/V3-M-vm3-say-cycles-dropped.log |
| V3-P-fx | 13:58:29 | 1 | 63.2 | 1 FAILING CHECK(S) ; 8p/1f | logs/V3-P-fx.log |
| V3-P-b0 | 13:59:33 | 1 | 62.8 | 5 FAILING CHECK(S) ; 4p/5f | logs/V3-P-b0.log |
| V3-P-vm3-at-plain-object | 14:00:36 | 1 | 44.4 | 2 FAILING CHECK(S) ; 7p/2f | logs/V3-P-vm3-at-plain-object.log |
| V3-P-vm3-folder-as-board | 14:01:20 | 1 | 52.9 | 2 FAILING CHECK(S) ; 7p/2f | logs/V3-P-vm3-folder-as-board.log |
| V3-P-vm3-sidecar-as-board | 14:02:13 | 1 | 53.8 | 2 FAILING CHECK(S) ; 7p/2f | logs/V3-P-vm3-sidecar-as-board.log |
| V3-P-vm3-mode-cleared-by-own | 14:03:07 | 1 | 44.8 | 3 FAILING CHECK(S) ; 6p/3f | logs/V3-P-vm3-mode-cleared-by-own.log |
| V3-P-vm3-at-no-guard | 14:03:53 | 1 | 47.1 | 2 FAILING CHECK(S) ; 7p/2f | logs/V3-P-vm3-at-no-guard.log |
| V3-M-vm3-rollup-keysOf | 13:58:21 | 1 | 398.4 | 12 FAILING CHECK(S) ; 130p/12f | logs/V3-M-vm3-rollup-keysOf.log |
| V3-P-vm3-del-nosave | 14:04:40 | 1 | 46.8 | 2 FAILING CHECK(S) ; 7p/2f | logs/V3-P-vm3-del-nosave.log |
| V3-P2-fx | 14:06:03 | 0 | 52.1 | ALL CHECKS PASSED ; 9p/0f | logs/V3-P2-fx.log |
| S3-boot-same-fx | 14:06:04 | 0 | 52.9 | every page, source, save and error list is identical either way | logs/S3-boot-same-fx.log |
| S3-audit-fx | 14:06:57 | 0 | 54.1 | ALL CHECKS PASSED | logs/S3-audit-fx.log |
| V3-P2-b0 | 14:06:56 | 1 | 55.7 | 4 FAILING CHECK(S) ; 5p/4f | logs/V3-P2-b0.log |
| S3-audit-ppt-fx | 14:07:51 | 0 | 26.6 | ALL CHECKS PASSED | logs/S3-audit-ppt-fx.log |
| S3-legacy-fsrc-fx | 14:08:18 | 0 | 19.1 | every legacy Force setting computes exactly as before | logs/S3-legacy-fsrc-fx.log |
| V3-P2-vm3-at-plain-object | 14:07:52 | 1 | 51.9 | 2 FAILING CHECK(S) ; 7p/2f | logs/V3-P2-vm3-at-plain-object.log |
| S3-audit-hostile-fx | 14:08:37 | 0 | 299.0 | ALL CHECKS PASSED | logs/S3-audit-hostile-fx.log |
| S3-check-fx | 14:13:36 | 0 | 14.0 | all checks passed | logs/S3-check-fx.log |
| S3-audit-recon-fx | 14:08:44 | 137 | 576.1 | KILLED by the memory cgroup OOM killer -- incomplete ; recorded so far 306p/0f | logs/S3-audit-recon-fx.log |
| S3-audit-hostile-mut-vm3-folder-as-board | 14:13:54 | 0 | 298.3 | ALL CHECKS PASSED | logs/S3-audit-hostile-mut-vm3-folder-as-board.log |
| S3-audit-other-fx | 14:18:20 | 0 | 173.8 | ALL CHECKS PASSED | logs/S3-audit-other-fx.log |
| S3-audit-inject-fx | 14:21:14 | 0 | 48.9 | every hostile value checked is drawn as text, the structural and key guards hold, an | logs/S3-audit-inject-fx.log |
| S3-audit-recon-mut-vm3-at-no-guard | 14:18:53 | 137 | 525.7 | KILLED by the memory cgroup OOM killer -- incomplete ; recorded so far 296p/0f | logs/S3-audit-recon-mut-vm3-at-no-guard.log |
| V3-F-hi-w2-fx | 14:22:13 | 0 | 368.0 | ALL CHECKS PASSED ; 242p/0f | logs/V3-F-hi-w2-fx.log |
| V3-F-hi-w1-fx | 14:27:45 | 0 | 175.3 | ALL CHECKS PASSED ; 53p/0f | logs/V3-F-hi-w1-fx.log |
| V3-F-hi-v200-fx | 14:28:21 | 0 | 313.6 | ALL CHECKS PASSED ; 167p/0f | logs/V3-F-hi-v200-fx.log |
| V3-F-hi-v197w1-fx | 14:33:35 | 0 | 30.6 | ALL CHECKS PASSED ; 15p/0f | logs/V3-F-hi-v197w1-fx.log |
| V3-F-hi-v197w3-fx | 14:30:41 | 0 | 269.7 | ALL CHECKS PASSED ; 111p/0f | logs/V3-F-hi-v197w3-fx.log |
| V3-F-hb-v197w1-fx | 14:35:11 | 0 | 66.2 | ALL CHECKS PASSED ; 178p/0f | logs/V3-F-hb-v197w1-fx.log |
| S3-audit-recon-mut-clin-by-name | 14:36:17 | 1 | 403.2 | 11 FAILING CHECK(S) ; 444p/4f | logs/S3-audit-recon-mut-clin-by-name.log |
| S3b-audit-recon-fx | 14:43:04 | 124 | 600.7 | TIMED OUT at the 600 s cap -- incomplete ; recorded so far 433p/0f | logs/S3b-audit-recon-fx.log |
| S3b-audit-recon-mut-vm3-at-no-guard | 14:53:04 | 137 | 455.1 | KILLED by the memory cgroup OOM killer -- incomplete ; recorded so far 298p/0f | logs/S3b-audit-recon-mut-vm3-at-no-guard.log |
| S3c-audit-recon-fx | 15:00:41 | 124 | 600.7 | TIMED OUT at the 600 s cap -- incomplete ; recorded so far 282p/0f | logs/S3c-audit-recon-fx.log |

Base suite results are reused from round 2's lens-B verifier (`verify-tests-r2/logs/S2-*-b0.log`). Its `b0` is byte-identical to
mine, and its `gc/b0` is the same 7ee498a with board fce8a391 and audit-recon 529e36f7. All passed: boot-same, audit,
audit-ppt, legacy-fsrc, audit-inject, audit-other, audit-hostile, audit-recon, check.

## PIDs

`pids.txt` lists every PID with its command and start time.
- **I killed no run.** Three of my node processes (2488, 10985, 14651) were killed by the memory cgroup's OOM killer, not by me
  (dmesg; noted in `pids.txt`).
- I stopped one of my own waiting loops through TaskStop (`bin/rlane.sh`, PID 11061, recorded first). It was only sleeping
  and had started no run. It was replaced by `bin/rlane2.sh`, so that two whole audit-recons would never run at once.
- When I finished, no process of mine was still running (checked with `ps`).

## Decisions, with reasons

- **MUST-FIX 1 is rated must-fix; S1 is rated should-fix.** Both are one-line regressions on new code that every check misses.
  - MUST-FIX 1 makes a healthy board's workbook print money under a combination the requirement is not on.
  - S1's precondition, a list holding an entry that is not one, is a board that already cannot render its RCN panel or export.
- **The equivalence of `at-last` holds.** labelOf names a row by `rcnLabel(e.k)`, which finds the first entry with the key, so
  the builder's removal of it is right.
- **I did not re-run the builder's probes** (pa, pb, pb2, pc, pd, vprobe3, p2) or FX4-r1. They are money-lens evidence. The
  block's own XLSX reads cover the same shapes, and they matched check for check.

## What I did not do

- I did not run the full `audit-import.mjs` or `audit-board.mjs`: the lead runs those. audit-import's v1.86 block was not run.
  The builder's focused audit-import and audit-board harnesses were re-run on the fix.
- I did not import, run or count from `mutate.mjs`, only `mutate.mjs.txt` as text. No Chromium, no playwright install.
- I did not edit the builder's files or the suites. My proposed checks live only in `h/h-prop.mjs` (built by `bin/mkprop.py`
  from the block's own helpers) and `out/proposed-entries.mjs.txt`.
- I did not drive the folder freeze end to end (S1). I observed driveParse's refusal and the sidecar's null.
- I did not re-run the fix's audit-recon with BOARD = base (the builder's S-audit-recon-fr2r-suite-on-base-board). The
  focused block on the base matched FX3-base check for check, and the rest of audit-recon is the base's, which passes on the
  base (S2-audit-recon-b0).
- I did not re-run the 27 other builder mutants.
- **I did not get a complete whole-audit-recon run on the fix.** It was OOM-killed once and hit the 600 s cap twice under load
  (see above). The whole audit-recon on vm3-at-no-guard was OOM-killed twice. These are re-runs for the lead or a quieter
  machine, not failures of the change.
