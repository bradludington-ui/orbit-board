<!-- DRAFT for the lead (U10 builder, fix round 2 of 13 Oct). SUPERSEDES drafts/NEXT-VERSION-U10-fix.md (fix round 1) and
drafts/NEXT-VERSION-U10.md (the build); both are kept for the record. U10 is now FOUR commits: 1 and 2 are fix round 1's,
unchanged in code (c1r, c2); 3 is the round-2 test review's proposal, adopted unchanged (c3); 4 is this round's (c4).
Pieces: (1)-(4) the four commit entries, to go under "v2.00" after the U14 entry and before "- **Unresolved after R1–R5
(11 Oct).**", in this order; (5) the replacement for U10's two lines in that list, with the texts to use if fewer commits land.
Entries (1) and (2) are fix round 1's with the corrections the round-2 reviews asked for (marked in README.md, "Fix round 2").
Nothing here is committed. Every figure was measured (README.md); the full-suite sensitivity of the mutations is the lead's
final-tree queue. -->

(1) Commit 1

- **U10 (1 of 4) — a refusal in a locked cycle's view puts back the whole view, not the year alone** (a release blocker
  the lead chose to fix on Brad's word of 12 Oct, about 5:30 PM ET: "Don't wait for me. Let's keep pressing throughout to
  get this next version published."). With a locked cycle on screen, a write the view refuses put back the year on screen
  and nothing beside it. An edit that changes what the board holds beside that year stayed on the view's copy after the
  board said "the change was not kept", and every export taken from the view carried it: 77777 typed into PB27's RCN field
  filed PB27's dollars under 77777 / AAAAA in RCN-EEIC by Month, the Spend Plan Source and the ACE tie-out, all labelled
  LOCKED VIEW (the review of `main` `f9b4413`; reproduced on `e635775`, `4a6f7c7` and `7ee498a`). The same held for an
  EEIC, a title, a ✕, + Add, a service box, a PMO renamed, a held year's pointers cleared by a ✕, the list of a cycle locked
  before v1.99 (which reads today's), the band ladder, the funds-flow settings, a PPBE position, and a CCaR Records file
  imported in the view (its titles and OPRs are kept beside the years, in the records index, and the Spend Plan Source
  printed them). Now a refusal makes the view's copy again, exactly as the view made it, in one place: the working plan set
  aside, with the cycle's years, its base year and the RCN / EEIC list it kept, on the year that is on screen. The working
  plan and the stored cycle are not written by a refusal. What lives outside the view's copy -- the lists every
  appropriation shares, the Spend Plan's choices, other appropriations' boards, browser storage written directly, files
  handed out -- this commit does not reach: commits 2 to 4 do.
  - **What users may see:** in a locked view, a refused change to something the board keeps with its plan (the RCN / EEIC
    list, the PMO list, the band ladder, the funds-flow layout, axis and years shown, a PPBE position, the CCaR records
    index) now goes back at once, as the status line already said; before, it stayed on the view's copy until the view was
    left (and, for codes, offices, band names, the funds-flow cut, positions and CCaR titles, in every export taken from
    it). To export a locked cycle under other funds-flow settings, set them on the working plan and then view the cycle.
  - **Test:** audit-recon "v2.00 (U10) — a refused edit in a locked cycle’s view changes no code any export carries"
    (27 checks, on v1.98 item 83's board with a second held year and an office ZED): each edit made through the control
    the board renders for it, from a fresh view of PB27; after each, RCN-EEIC by Month (summary, requirements, prime
    contracts), the Spend Plan Source (amount, CLIN, EEIC, RCN, PMO), the ACE tie-out (alignment breakout and mapping, both
    years) and the whole workbook are read from their bytes against the cycle's own codes, typed in the block; FY28 on
    screen; the record's own steps (saved, reopened, viewed, 77777 typed); a cycle locked before v1.99. The status line is
    read at once after each edit (the "Not kept" mark lasts 1.5 s). And "v2.00 (U10) — a refusal in a locked view puts back
    the plan’s settings, the year on screen, the CCaR records and the cycle’s base year" (9 checks): band 0 renamed and
    the funds-flow axis set to destinations, read in the workbook and the funds-flow export; a held FY28 that differs from
    FY27 (R on K4), read in RCN-EEIC by Month; a CCaR Records file, read in the Spend Plan Source; the cycle's FYDP window
    after a refusal when the working base year has moved on. Controls in both: nothing changed, a refused edit to the
    year's own assignments, the cycle store and browser storage byte for byte, leaving the view, an allowed edit on the
    working plan (55555) and the same CCaR file on the working plan, which every export carries. On `7ee498a`, 18 + 4
    checks fail and the 9 + 5 controls pass. (A PPBE position refused in a view is read by commit 3's block.)
  - **Mutations:** `v200-u10-reapply-year-only`, `-keeps-list`, `-keeps-years`, `-keeps-pmos`, `-first-year`,
    `-older-keeps-list`, `-wrong-year`, `-keeps-plan-settings` and `-working-base`; each caught by the focused blocks
    (full-suite sensitivity runs in the final-tree queue).
  - **Not covered:** what lives outside the view's copy (commits 2 to 4). The forecast-view export, the PMO Matrix and the
    PowerPoint exports are not read by the blocks (they print offices, which the blocks read in the workbook, the Spend Plan
    Source and the ACE tie-out, and no RCN or EEIC).

(2) Commit 2

- **U10 (2 of 4) — a cost estimate, a BAE list, CCaR records or a destination change is refused in a locked view before
  anything is kept** (the same release blocker, from its review of 13 Oct). The cost estimates, the BAE budget list and
  the destination list are kept once for every appropriation, outside a locked view's copy. Each of their doors wrote its
  list first and then saved, which the view refused: the board said "Not kept" and kept it, in browser storage and in
  every plan. A 2027 cost estimate imported while PB27 was on screen replaced the approved one after "An approved cost
  estimate should not change. Replace it?", and the ACE tie-out and the FYDP Spend Plan then read $4,321,000 instead of
  $900, in the view and on the working plan; a BAE list put its budget names into the Spend Plan Source; a destination
  renamed in the view was renamed everywhere; one removed in the view ("Nothing points at it", asked of the view's copy)
  left the working plan's requirements pointing at nothing, so the funds flow put their money under "not yet assigned".
  Now each of these doors -- Import cost estimate, Import BAE budget list, Import CCaR records, and Setup › Destinations'
  name, kind and terms fields, + add, ✕ and reset -- is refused while a locked cycle is on screen, before the file is read
  or a question asked, and says so ("🔒 Importing a cost estimate is off while PB27 is on screen … the change was not
  kept"), as the service list already was. The CCaR records index was already put back by commit 1; its door is refused
  up front so the status line no longer counts titles found and says "Save to bake this into the file". (An import started
  on the working plan while a view is put on screen during its read is refused once the file is read: commit 4.)
  - **What users may see:** with a locked cycle on screen, these imports and the destination list are refused with that
    line, as Save and the service list are; leave the view to use them. On the working plan nothing changes.
  - **Test:** audit-recon "v2.00 (U10) — a cost estimate, a BAE list, CCaR records or a destination change is refused in
    a locked view before anything is kept" (27 checks), on a board of two AV requirements with an approved 2027 estimate
    and the funds flow cut by destination: each of the seven doors used with PB27 on screen (the file pickers' handlers
    with workbooks the board builds; the destination doors through the controls Setup › Destinations renders); after each,
    the status line, the questions asked, the three lists in the board and in browser storage, the panel, and the cells of
    the ACE tie-out, the FYDP Spend Plan, the Spend Plan Source and the funds flow, in the view and again on the working
    plan after leaving, every figure typed in the block. Controls: PB27 viewed with nothing done, the working plan with
    nothing done, and each kind of door open on the working plan (the approved estimate replaced after its question, the
    BAE list kept, a destination added and named), which every export carries. On `7ee498a` 21 checks fail and the 6
    controls pass; on commit 1 the same 21 fail. (A destination's kind changed in a view is read by commit 3's block; that
    the three imports are refused before their file is read is read by commit 4's.)
  - **Mutations:** `v200-u10-ace-import-in-view`, `-bae-import-in-view`, `-ccar-import-in-view`,
    `-dest-change-in-view`, `-dest-change-no-redraw`, `-dest-add-in-view`, `-dest-remove-in-view` and
    `-dest-reset-in-view`; each caught by the focused blocks (full-suite sensitivity runs in the final-tree queue).
  - **Not covered:** a destination's match terms (the same gate as its name and kind; read by code, no block types one).

(3) Commit 3 (the round-2 test review's proposal, adopted unchanged: `rec/L6/u10/verify-tests-r2/c3`)

- **U10 (3 of 4) — a Spend Plan choice is refused in a locked view before anything is kept** (the same release blocker,
  from its round-2 test review of 13 Oct). The Spend Plan's choices -- its Cost data (the estimate the ACE tie-out ties
  out), By PMO / By Service, the two prior years, the PMO and service filters and the PMO drill's service -- were set on
  the page first and then saved, which a locked view refuses. The board said "the change was not kept" and kept the
  choice on the page: with PB27 on screen, 2026ACE chosen as the Cost data made the ACE tie-out taken from the view tie
  out 2026ACE ($333 against A's $1,100, where PB27's 2027ACE is $900), and back on the working plan its ACE tie-out still
  tied out 2026ACE, even after a save, while browser storage kept 2027ACE (so the export no longer matched what the board
  keeps). The same on `7ee498a` and on U10 1 and 2. Now each of the six choices is refused while a locked cycle is on
  screen, before it is set, and says so ("🔒 Changing the spend plan is off while PB27 is on screen … the change was not
  kept"), as the imports and the destination list are.
  - **What users may see:** with a locked cycle on screen, the Spend Plan's choices (Cost data, By PMO / By Service,
    ◀ prior 2 FY, the PMO and service filters, the PMO drill's service) are refused with that line; leave the view to
    change them. They stay as the working plan had them. On the working plan nothing changes.
  - **Test:** audit-recon "v2.00 (U10) — a spend-plan choice, a PPBE position or a destination’s kind refused in a
    locked view leaves no trace" (9 checks), on a board of two AV requirements with two approved estimates (2027ACE $900,
    2026ACE $333) and USAF's FY27 PPBE position logged at $1,000: each choice made through the control the Spend Plan
    renders (the filters and the drill through the handlers their controls call), then the Spend Plan as drawn, the ACE
    tie-out's mapping and reconciliation cells, in the view and on the working plan after leaving, and browser storage.
    It also reads two things U10 1 and 2 put right that no block read: a PPBE position typed in the view (the FYDP Spend
    Plan's By Service position cell) and a destination's kind changed in Setup › Destinations (the list and browser
    storage). Controls: PB27 viewed with nothing chosen; the Cost data choice on the working plan, kept and tied out
    ($333); no jsdom errors. On `7ee498a` 6 checks fail and the 3 controls pass; on U10 2 of 4 the 4 Spend Plan checks
    fail.
  - **Mutations:** `v200-u10-sp-choice-in-view`, `-sp-ace-in-view`, `-sp-by-in-view`, `-sp-pmo-in-view`,
    `-sp-svc-in-view`, `-sp-prior-in-view`, `-sp-drill-in-view`, `-sp-no-redraw`, `-reapply-keeps-ppbe` and
    `-dest-kind-in-view`; each caught by the focused blocks (full-suite sensitivity in the final-tree queue).
  - **Not covered:** a destination's match terms (as commit 2).

(4) Commit 4

- **U10 (4 of 4) — a file, a package, the band ladder or a shared copy is refused in a locked view before anything is
  kept** (the same release blocker, from its round-2 reviews of 13 Oct and the builder's second door scan). Each of these
  doors wrote something that is no part of a locked view's copy -- this appropriation's browser storage, another
  appropriation's board, a list every appropriation shares, the copy kept aside, the shared folder's record -- or handed a
  file out, and only then met the view's refusal, so the board said "Not kept" and kept it. With PB27 on screen:
  - a manager's returned package taken through File › Import one appropriation asked its conflict question of the view's
    copy, wrote the package into this appropriation's browser storage, and said "🔒 Not kept … 📥 Merged O&M package #1 …
    Your local changes were discarded, as confirmed." Reopened, the board carried the package: RCN-EEIC by Month and the
    Spend Plan Source printed 77777 for K1 (11111 in none), and the work typed after the last save was in no copy;
  - a state file carrying cost estimates beside its years kept them (the ACE tie-out read $4,321,000 for $900), and a
    PMO submittal added its destination to the list every appropriation shares;
  - ⇉ Copy to the other appropriations replaced Full Fund's own band ladder, kept nowhere, so its banded requirements
    became unbanded;
  - a package issued, the baselines pushed, a manager's return saved, or an appropriation sent back from the
    consolidated handed out the locked cycle as the board's package (the return under the issue's own number and
    signature, though "Not kept" was said);
  - loading the shared state file kept the locked cycle aside as this browser's work ("put it back" would make it the
    working plan);
  - a Live refresh that found a colleague's newer copy in the shared folder kept the locked cycle aside in place of this
    browser's unsaved work, and recorded the folder's copy as the one the work came from, saved: the first refresh after
    leaving the view then loaded the colleague's copy over that work, which was kept nowhere;
  - and a cost estimate, BAE list or CCaR file whose import started on the working plan, with the view put on screen while
    the file was read, was kept as the other imports were before commit 2 (the approved estimate replaced: $4,321,000
    for $900).
  Now Import one appropriation is refused while a locked cycle is on screen before the file is read, and again once it is
  read, as Import full board and Import several boards are; the three workbook imports are refused again once their file
  is read; the ladder copy, the four package doors and loading the shared state file are refused up front; and a refresh
  from the shared folder changes nothing while a locked cycle is on screen (a Connect says so; the Live timer says
  nothing), and the first refresh after leaving the view decides afresh. Each refusal says so ("🔒 Importing a file is off
  while PB27 is on screen … the change was not kept").
  - **What users may see:** with a locked cycle on screen, File › Import one appropriation, ⇉ Copy to the other
    appropriations, ⬆ Issue, Push baselines, the return and send-back packages, and "load the shared one" are refused with
    that line; leave the view to use them. A colleague's newer copy in the shared folder is loaded by the first refresh
    after leaving the view (with this browser's unsaved work kept aside first, as on the working plan). On the working plan
    nothing changes.
  - **Test:** audit-recon "v2.00 (U10) — a file, a package, the band ladder or a shared copy is refused in a locked view
    before anything is kept" (28 checks), on boards of two AV requirements (A on RCN 11111 / EEIC AAAAA, confirmed on WBS
    1.1; an approved 2027ACE of $900), PB27 locked and then A described on the working plan: the returned package (K1 →
    77777) taken in the view, then on the working plan with the view put on screen while it is read -- the status line,
    the questions, browser storage, RCN-EEIC by Month and the Spend Plan Source after leaving, and the board reopened over
    its saved file; a state file carrying a 2028 estimate -- the estimates in the board and in browser storage, and the
    ACE tie-out; each workbook import with the view on screen (the file is read 0 times) and started on the working plan
    with the view put on screen during the read -- the lists and the ACE tie-out; the ladder copy -- Full Fund's stored
    ladder and the ladder held for it; the four package doors -- the files handed out and the package record; the shared
    state file and a Live refresh from a fake shared folder -- what is kept aside, browser storage and the unsaved-work
    flag, then leaving the view and the next refresh. Every figure is typed in the block. Controls: on the working plan
    the return merges (asked first) and every export carries 77777; the state file is taken with its estimate; each
    package door hands out the working plan; the ladder copies; the shared state file loads with the work kept aside
    first; no jsdom errors. On `7ee498a` the 22 non-control checks fail and the 6 controls pass; on U10 3 of 4, 19 fail
    (the three workbook imports refused before their file is read already pass there).
  - **Mutations:** `v200-u10-state-import-in-view`, `-state-import-race`, `-ace-import-race`, `-bud-import-race`,
    `-ccar-import-race`, `-ladder-copy-in-view`, `-pkg-issue-in-view`, `-pkg-push-in-view`, `-pkg-sendback-in-view`,
    `-pkg-return-in-view`, `-shared-load-in-view`, `-folder-pull-in-view` and `-folder-connect-quiet`; each caught by the
    focused blocks (full-suite sensitivity in the final-tree queue). Commit 2's three import entries stay caught (the
    block reads that their file is never read in a view).
  - **Not covered:** the PMO submittal and the consolidated file's take through Import one appropriation (the same
    gate; not typed in the block); the Live refresh's pulls of the folder's execution data and reprogramming log while a
    view is on screen (other people's saved lists, not an edit; read, not measured -- ledger row U<n>). A full board import
    started on the working plan with a view put on screen during its read lands as on the working plan, after its own
    questions, which still name the working plan's changes (measured; not a refused edit, not changed).

(5) Replacement for these two lines of "Unresolved after R1–R5":
  - **U10 (P2): a refused edit changes a locked-cycle export's codes.** A refused RCN edit in a locked view still
    exports under the edited code.

with, if all four commits land:
  - **U10 (P2): built as four commits** (a release blocker, fixed on Brad's word of 12 Oct, "keep pressing"): a refusal in
    a locked view makes the view's copy again, whole (U10 1 of 4); the imports and the destination list, which every
    appropriation shares, are refused in a view before anything is kept (2 of 4); so are the Spend Plan's choices (3 of 4),
    and Import one appropriation, the ladder copy, the package doors, the shared state file and the shared folder's refresh,
    with every import refused again once its file is read (4 of 4). Two neighbouring cases stay open in the ledger:
    edits a view allows and keeps (U<n>), and a locked cycle's offices (U<n+1>).

or, if only commits 1–3 land:
  - **U10 (P2): partly built** (U10 1–3 of 4, above). Still open, each measured and drafted as commit 4: in a locked view,
    a returned package or a state file taken through Import one appropriation is written to browser storage (the board
    reopens on 77777 for K1, and work typed after the last save is lost); the ladder copy replaces Full Fund's ladder; a
    package issued, returned or sent back carries the cycle as the board; the shared state file and a Live refresh keep
    the cycle aside as this browser's work, and the refresh after leaving the view then loads a colleague's copy over the
    unsaved work, kept nowhere; an import started on the working plan with the view put on screen during its read is kept.

or, if only commits 1–2 land: as above, and also: the Spend Plan's Cost data chosen in a view is kept, and the ACE tie-out
ties out the refused estimate, in the view and on the working plan after leaving (drafted as commit 3).
<!-- The line "Both U9 and U10 were reproduced ..." is shared with U9 and is left for the lead. -->
