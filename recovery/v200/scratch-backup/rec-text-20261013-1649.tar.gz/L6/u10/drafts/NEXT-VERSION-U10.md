<!-- DRAFT for the lead (U10 builder, 12 Oct). Two pieces. (1) The entry: insert under "v2.00", after the U14 entry and before
"- **Unresolved after R1–R5 (11 Oct).**". (2) The replacement for U10's two lines in that list. Nothing here is committed. -->

- **U10 — a refused edit in a locked cycle's view changes no code any export carries** (a release blocker the lead chose to
  fix on Brad's word of 12 Oct, about 5:30 PM ET: "Don't wait for me. Let's keep pressing throughout to get this next version
  published."). With a locked cycle on screen, a write the view refuses put back the year on screen and nothing beside it. An
  edit that changes what the board holds beside that year stayed on the view's copy after the board said "the change was not
  kept", and every export taken from the view carried it: 77777 typed into PB27's RCN field filed PB27's dollars under
  77777 / AAAAA in RCN-EEIC by Month, the Spend Plan Source and the ACE tie-out, all labelled LOCKED VIEW (the review of
  `main` `f9b4413`; reproduced on `e635775`, `4a6f7c7` and `7ee498a`). The same held for an EEIC, a title, a ✕, + Add, a
  service box, a PMO renamed, a held year's pointers cleared by a ✕, and the list of a cycle locked before v1.99 (which reads
  today's). Now a refusal makes the view's copy again, exactly as the view made it, in one place: the working plan set aside,
  with the cycle's years, its base year and the RCN / EEIC list it kept, on the year that is on screen. The stored cycle, the
  working plan and browser storage were never changed by a refused edit, and still are not.
  - **What users may see:** in a locked view, a refused change to something the board keeps with its plan (the RCN / EEIC
    list, the PMO list, the band ladder, the funds-flow layout, axis and years shown) now goes back at once, as the status
    line already said; before, it stayed on the view's copy until the view was left (and, for codes and offices, in every
    export taken from it). To export a locked cycle under other funds-flow settings, set them on the working plan and then
    view the cycle. The Spend Plan's service selector keeps its choice in a view, as before (its PMO and estimate selectors
    are set the same way).
  - **Test:** audit-recon "v2.00 (U10) — a refused edit in a locked cycle’s view changes no code any export carries"
    (27 checks), on v1.98 item 83's board with a second held year and an office ZED: each edit made through the control the
    board renders for it, from a fresh view of PB27; after each, RCN-EEIC by Month (summary, requirements, prime contracts),
    the Spend Plan Source (amount, CLIN, EEIC, RCN, PMO), the ACE tie-out (alignment breakout and mapping, both years) and
    the whole workbook are read from their bytes against the cycle's own codes, typed in the block; FY28 on screen; the
    record's own steps (saved, reopened, viewed, 77777 typed); and a cycle locked before v1.99. Controls: nothing typed, a
    refused edit to the year's own assignments, the cycle store and browser storage byte for byte, leaving the view, and an
    allowed edit on the working plan (55555), which every export carries. 18 checks fail on `7ee498a`; the 9 controls pass on
    both.
  - **Mutations:** `v200-u10-reapply-year-only`, `-keeps-list`, `-keeps-years`, `-keeps-pmos`, `-first-year` and
    `-older-keeps-list`; each caught by the focused block (full-suite sensitivity runs in the final-tree queue).
  - **Not covered:** the lists every appropriation shares are not part of a locked view: a destination renamed while one is
    on screen is kept, in this board and the others, while the status line says "the change was not kept" (measured, not
    changed here; ledger). The forecast-view export, the PMO Matrix and the PowerPoint exports are not read by the block
    (they print offices, which the block reads in the workbook, the Spend Plan Source and the ACE tie-out, and no RCN or
    EEIC). A Spend Plan selector chosen in a view is still on screen after leaving it (as before).

<!-- (2) Replacement for these two lines of "Unresolved after R1–R5":
  - **U10 (P2): a refused edit changes a locked-cycle export's codes.** A refused RCN edit in a locked view still
    exports under the edited code.
with: -->
  - **U10 (P2): built as its own commit** (a release blocker, fixed on Brad's word of 12 Oct, "keep pressing"): a refused
    edit in a locked cycle's view changes no code any export carries; a refusal makes the view's copy again, whole (above).
    An edit to a list every appropriation shares, made while a view is on screen, is kept while the board says it was not;
    that is recorded in the ledger and not changed here.
<!-- The line "Both U9 and U10 were reproduced ..." is shared with U9 and is left for the lead. -->
