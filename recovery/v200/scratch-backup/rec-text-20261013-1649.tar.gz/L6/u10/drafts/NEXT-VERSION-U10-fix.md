<!-- DRAFT for the lead (U10 builder, fix round of 13 Oct). SUPERSEDES drafts/NEXT-VERSION-U10.md (kept for the record).
Three pieces. (1) and (2) are the two commit entries: insert them under "v2.00", after the U14 entry and before
"- **Unresolved after R1–R5 (11 Oct).**", in this order. (3) The replacement for U10's two lines in that list -- one text if
both commits land, one if commit 1 lands alone. Nothing here is committed. Every figure below was measured in this fix round
(README.md, "Fix round"); the full-suite sensitivity of the mutations is the lead's final-tree queue. -->

(1) Commit 1

- **U10 (1 of 2) — a refusal in a locked cycle's view puts back the whole view, not the year alone** (a release blocker
  the lead chose to fix on Brad's word of 12 Oct, about 5:30 PM ET: "Don't wait for me. Let's keep pressing throughout to
  get this next version published."). With a locked cycle on screen, a write the view refuses put back the year on screen
  and nothing beside it. An edit that changes what the board holds beside that year stayed on the view's copy after the
  board said "the change was not kept", and every export taken from the view carried it: 77777 typed into PB27's RCN field
  filed PB27's dollars under 77777 / AAAAA in RCN-EEIC by Month, the Spend Plan Source and the ACE tie-out, all labelled
  LOCKED VIEW (the review of `main` `f9b4413`; reproduced on `e635775`, `4a6f7c7` and `7ee498a`). The same held for an
  EEIC, a title, a ✕, + Add, a service box, a PMO renamed, a held year's pointers cleared by a ✕, the list of a cycle locked
  before v1.99 (which reads today's), the band ladder, the funds-flow settings, and a CCaR Records file imported in the view
  (its titles and OPRs are kept beside the years, in the records index, and the Spend Plan Source printed them). Now a
  refusal makes the view's copy again, exactly as the view made it, in one place: the working plan set aside, with the
  cycle's years, its base year and the RCN / EEIC list it kept, on the year that is on screen. The working plan and the
  stored cycle are not written by a refusal. The lists every appropriation shares (cost estimates, the BAE list, the
  destination list) are not part of a view's copy, so this commit does not reach them: commit 2 does.
  - **What users may see:** in a locked view, a refused change to something the board keeps with its plan (the RCN / EEIC
    list, the PMO list, the band ladder, the funds-flow layout, axis and years shown, the CCaR records index) now goes back
    at once, as the status line already said; before, it stayed on the view's copy until the view was left (and, for
    codes, offices, band names, the funds-flow cut and CCaR titles, in every export taken from it). To export a locked
    cycle under other funds-flow settings, set them on the working plan and then view the cycle. The Spend Plan's service
    selector keeps its choice in a view, as before.
  - **Test:** audit-recon "v2.00 (U10) — a refused edit in a locked cycle’s view changes no code any export carries"
    (27 checks, on v1.98 item 83's board with a second held year and an office ZED): each edit made through the control
    the board renders for it, from a fresh view of PB27; after each, RCN-EEIC by Month (summary, requirements, prime
    contracts), the Spend Plan Source (amount, CLIN, EEIC, RCN, PMO), the ACE tie-out (alignment breakout and mapping, both
    years) and the whole workbook are read from their bytes against the cycle's own codes, typed in the block; FY28 on
    screen; the record's own steps (saved, reopened, viewed, 77777 typed); a cycle locked before v1.99. The status line is
    read at once after each edit (the "Not kept" mark lasts 1.5 s). And "v2.00 (U10) — a refusal in a locked view puts back
    the plan’s settings, the year on screen, the CCaR records and the cycle’s base year" (9 checks): band 0 renamed and
    the funds-flow axis set to destinations, read in the workbook and the funds-flow export; a held FY28 that differs from
    FY27 (R on K4), read in RCN-EEIC by Month; a CCaR Records file, read in the Spend Plan Source; the cycle's FYDP window
    after a refusal when the working base year has moved on. Controls in both: nothing changed, a refused edit to the
    year's own assignments, the cycle store and browser storage byte for byte, leaving the view, an allowed edit on the
    working plan (55555) and the same CCaR file on the working plan, which every export carries. On `7ee498a`, 18 + 4
    checks fail and the 9 + 5 controls pass.
  - **Mutations:** `v200-u10-reapply-year-only`, `-keeps-list`, `-keeps-years`, `-keeps-pmos`, `-first-year`,
    `-older-keeps-list`, `-wrong-year`, `-keeps-plan-settings` and `-working-base`; each caught by the focused blocks
    (full-suite sensitivity runs in the final-tree queue).
  - **Not covered:** the lists every appropriation shares (commit 2). The forecast-view export, the PMO Matrix and the
    PowerPoint exports are not read by the blocks (they print offices, which the blocks read in the workbook, the Spend Plan
    Source and the ACE tie-out, and no RCN or EEIC). A Spend Plan selector chosen in a view is still on screen after
    leaving it (as before).

(2) Commit 2

- **U10 (2 of 2) — a cost estimate, a BAE list, CCaR records or a destination change is refused in a locked view before
  anything is kept** (the same release blocker, from its review of 13 Oct). The cost estimates, the BAE budget list and
  the destination list are kept once for every appropriation, outside a locked view's copy. Each of their doors wrote its
  list first and then saved, which the view refused: the board said "Not kept" and kept it, in browser storage and in
  every plan. A 2027 cost estimate imported while PB27 was on screen replaced the approved one after "An approved cost
  estimate should not change. Replace it?", and the ACE tie-out and the FYDP Spend Plan then read $4,321,000 instead of
  $900, in the view and on the working plan; a BAE list put its budget names into the Spend Plan Source; a destination
  renamed in the view was renamed everywhere; one removed in the view ("Nothing points at it", asked of the view's copy)
  left the working plan's requirements pointing at nothing, so the funds flow put their money under "not yet assigned".
  Now each of these doors -- Import cost estimate, Import BAE budget list, Import CCaR records, and Setup › Destinations'
  name, kind and terms fields, + add, ✕ and reset -- is refused while a locked cycle is on screen, before the file is read
  or a question asked, and says so ("🔒 Importing a cost estimate is off while PB27 is on screen … the change was not
  kept"), as the service list already was. The CCaR records index was already put back by commit 1; its door is refused
  up front so the status line no longer counts titles found and says "Save to bake this into the file".
  - **What users may see:** with a locked cycle on screen, these imports and the destination list are refused with that
    line, as Save and the service list are; leave the view to use them. On the working plan nothing changes.
  - **Test:** audit-recon "v2.00 (U10) — a cost estimate, a BAE list, CCaR records or a destination change is refused in
    a locked view before anything is kept" (27 checks), on a board of two AV requirements with an approved 2027 estimate
    and the funds flow cut by destination: each of the seven doors used with PB27 on screen (the file pickers' handlers
    with workbooks the board builds; the destination doors through the controls Setup › Destinations renders); after each,
    the status line, the questions asked, the three lists in the board and in browser storage, the panel, and the cells of
    the ACE tie-out, the FYDP Spend Plan, the Spend Plan Source and the funds flow, in the view and again on the working
    plan after leaving, every figure typed in the block. Controls: PB27 viewed with nothing done, the working plan with
    nothing done, and each kind of door open on the working plan (the approved estimate replaced after its question, the
    BAE list kept, a destination added and named), which every export carries. On `7ee498a` 21 checks fail and the 6
    controls pass; on commit 1 the same 21 fail.
  - **Mutations:** `v200-u10-ace-import-in-view`, `-bae-import-in-view`, `-ccar-import-in-view`,
    `-dest-change-in-view`, `-dest-change-no-redraw`, `-dest-add-in-view`, `-dest-remove-in-view` and
    `-dest-reset-in-view`; each caught by the focused block (full-suite sensitivity runs in the final-tree queue).
  - **Not covered (ledger):** edits a view allows and keeps while its banner says "nothing changed here is kept": a CCaR
    QPE (execution) import, a reprogramming row, and unlocking or deleting another cycle -- deleting the one the working
    plan compares against also says "the change was not kept" (row U<n>). A locked cycle keeps no PMO list of its own, so
    an office deleted on the working plan after the lock moves that cycle's money in its exports (row U<n+1>).

(3) Replacement for these two lines of "Unresolved after R1–R5":
  - **U10 (P2): a refused edit changes a locked-cycle export's codes.** A refused RCN edit in a locked view still
    exports under the edited code.

with, if both commits land:
  - **U10 (P2): built as two commits** (a release blocker, fixed on Brad's word of 12 Oct, "keep pressing"): a refusal in
    a locked view makes the view's copy again, whole (U10 1 of 2); and the imports and the destination list, which every
    appropriation shares, are refused in a view before anything is kept (2 of 2). Two neighbouring cases stay open in the
    ledger: edits a view allows and keeps (U<n>), and a locked cycle's offices (U<n+1>).

or, if commit 1 lands alone:
  - **U10 (P2): partly built** (U10 1 of 2, above): a refusal makes the view's copy again, whole, so codes, offices, the
    band ladder, the funds-flow settings and CCaR titles refused in a view reach no export. Still open: a cost estimate, a
    BAE list or a destination change made in a view is kept, in every plan, while the board says it was not, and an
    approved estimate can be replaced that way.
<!-- The line "Both U9 and U10 were reproduced ..." is shared with U9 and is left for the lead. -->
