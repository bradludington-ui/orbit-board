# U10 — independent verifier, round 1, LENS B (test adequacy and regressions)

Verifier of the U10 builder's result (`rec/L6/u10`, board `4a8b0be3`, audit-recon `47c8520a`, mutate text `d245868c`).
Work done only in this directory, on my own copies. Nothing in `/home/user/orbit-board` or `/home/user/orbit-ui` was edited,
staged, committed or pushed. `mutate.mjs` was never imported or run (read as text only, through `rec/bin/mcount.py` and
`rec/bin/mkmut.py`, with `python3 -I`). No Playwright, no Chromium. The board files stay the empty template; every fixture is
synthetic and made at run time.

Two sessions: the first ran from about 12:09 AM to 12:50 AM ET on 13 Oct and stopped at a usage limit; the second (this one,
resumed on the user's word) started at 4:27 AM ET. Every time below is Eastern, from `TZ=America/New_York date`.

## Verdict

**unsound as it stands (tests), sound board change.** The board change (`cycCopy` + `cycReapply` rebuilding the whole copy)
is right on every case I measured, including two the builder did not name (a refused CCaR Records import and the funds-flow /
band settings), and every suite I may run gives the same output on base and c1. But the new tests do not hold the change:

1. **MUST-FIX 1 — two of the block's checks read the status line after three exports, so they pass only when the exports
   finish within 1.5 s of the refusal.** On the correct board c1, the builder's block with a 2 s clock step before those
   exports (nothing else changed) fails exactly those two checks (run VFS-on-c1, exit 1, 2 of 38). Seen once without any
   injection, under load (VFX3-mut-vt-field-codes: `["fired",false,...]` on a mutant that does not touch the status).
2. **MUST-FIX 2 — a refusal that puts the wrong held year's plan on screen passes everything.** The block's FY28 is a copy
   of FY27. Mutant `vt-wrong-year-state` (refusal while FY28 is on screen loads FY27's plan into FY28) passes the U10 block
   (0/38), the whole audit-recon (exit 0), audit-board PPBE (0/141) and audit-import R3 (0/12). With FY28 holding R on K4,
   that mutant files R's USAF $503 under 11111 / AAAAA in RCN-EEIC by Month (K1 $904 / K4 $299 instead of $401 / $802).
3. **MUST-FIX 3 — the settings kept with the plan and the CCaR records index are untested.** A field-by-field put-back of
   the list, the years and the PMOs (`vt-field-codes`), or a whole rebuild that keeps the refused band ladder
   (`vt-keeps-bands`), funds-flow settings (`vt-keeps-flow`) or CCaR index (`vt-keeps-ccaridx`), passes the U10 block, the
   whole audit-recon, audit-other, audit, audit-ppt, audit-board PPBE and audit-import R3 (and W3 for field-codes). On the
   base each of these leaks into an export from the view: the workbook names band 0 "RENAMED BAND", the funds-flow export is
   cut by destination, and the Spend Plan Source titles R and Q "REFUSED TITLE R / Q" with OPR "REFUSED OPR". The builder's
   draft promises the band / funds-flow behaviour to users ("What users may see") with no check behind it, and its findings
   say CCaR records "are year state and were already put back" -- the Title and OPR come from `MS.ccarIdx`, beside the years.

All three have a minimal fix written and run here (below): it fails on the base where it should, passes on c1, and catches
every mutant listed, through the focused harness and through the whole owning suite.

## Identities (git hash-object)

| what | blob |
|---|---|
| base board (7ee498a, product d66dd60) | `fce8a391bd8a248d5185e199d22190c1687eaea0` |
| base audit-recon / audit-import / audit-board / audit-other / mutate.mjs.txt | `529e36f7` / `4aba2506` / `a7c575e5` / `d89396b0` / `cbc6defc` |
| c1 board (builder) | `4a8b0be32608ac9b44cf301b7381a359a9e19111` |
| c1 audit-recon (builder) | `47c8520aa453fed08226ce20534d23fd04db6dde` |
| c1 mutate.mjs.txt (builder) | `d245868c0016e0a5261879cb2333b1271b4a9bf2` |
| my copies `base/`, `c1/` | byte-identical to the builder's (same blobs; checked at 4:28 AM ET) |
| orbit-board HEAD at 4:28 AM ET | `674b6c5` (records only since 7ee498a; board still `fce8a391`, audit-recon `529e36f7`, mutate `cbc6defc`) |
| proposal copy `c1p/` audit-recon | `cf8aa87a93abd7cf0fed6d4dccc0a4055139b312` (c1 + the two moved reads + the proposal block) |
| proposal copy `c1p/` mutate.mjs.txt | `3d6b378a4aed36587833eb1b8b12aeee6bb5a7b9` (c1 + 4 proposed entries) |
| proposal block `harness/vt-block-settings2.mjs.txt` | `bd1087aac1abfd3f3900bdd384dd072b7e5000eb` (87 lines) |
| proposed entries `harness/vt-entries2.mjs.txt` | `27063b36cf99ec20c7670351779cabdd5691d497` |
| focused harnesses | `harness/c1/focused-u10.mjs` `0d476cbc` (builder block + item 83 + item 88, verbatim); `focused-u10-plus2.mjs` `5a732942` (+ proposal); `focused-u10-slow.mjs`, `focused-u10-fixread.mjs`, `focused-u10-fixread-slow.mjs` |

Diffs: `diffs/c1-vs-base.*.diff` (the builder's change), `diffs/c1p-vs-c1.*.diff` (my proposal on top of it).

## What I checked, and what came out

### Re-runs of the builder's reported runs (all reproduce)

| builder's claim | my run | result |
|---|---|---|
| P3 reproduction: base 22 pass / 4 fail (all defect), c1 26 / 0 | VP3-evidence-on-base, -on-c1 | same: 22/4 (4 defect, 0 control); c1 exit 0 |
| F3 focused U10 on base: 18 fail, all defect; 9 controls pass | VF-u10-on-base | same: 18 of 38 fail, every one a non-CONTROL check |
| F3 on c1: 38/38 | VF-u10-on-c1 | same |
| builder's 6 mutants through F3: 18 / 16 / 5 / 2 / 1 / 1 | VF-mut-v200-u10-* | same counts |
| v199-cyc-view-today / -note-silent / -view-silent: 23 / 1 / 1 | VF-mut-v199-* | same |
| view-refused-edit-stays / -shares-cycle-years / -shares-store / -leave-keeps-copy / -title-unmarked: 1/2/2/6/1 of 141 | VB2-mut-* | same |
| v200-cyc-title-html through audit-inject: exit 1 | VS-audit-inject-c1-mut-v200-cyc-title-html | exit 1 (it passes F3 and B2, as the builder said: audit-inject owns it) |
| mcount base 1328 / c1 1334, each once | out/mcount/base.json, c1.json | same |
| suite and mutate diffs only add lines | diffs/c1-vs-base.* | audit-recon +189 −0, mutate +20 −0; no existing expectation changed |
| boot-same, audit, audit-ppt, audit-other, audit-recon, legacy-fsrc, audit-hostile, audit-inject: exit 0 on both, same output | VS-*-base / VS-*-c1 | all exit 0; output identical after masking timings and paths (0 differing lines each) |
| audit-board PPBE 141/141, audit-import W3 111/111, R3 12/12 on both | VB2-, VIW3-, VIR3-on-base/-on-c1 | same |
| npm run check passes on both | VN-check-base, VN-check-c1 | exit 0 both |

Every new expected value in the builder's block is a literal typed in the block (LOCKED, ALIGN, MAP, LIST, PANEL, the
working-plan control's figures, the older cycle's list; `v198Lab` maps the suite's own literal table). Every non-CONTROL check
fails on the base; the 9 CONTROLs pass on both by design.

### My own mutants of the change (12, each a plausible wrong fix) — `bin/vtmuts.py`, `bin/vtmuts2.py`

| mutant | what it does | builder's U10 block (VF, 38) | whole audit-recon | other suites / harnesses | with the proposal (VFX3, 47) |
|---|---|---|---|---|---|
| vt-noapply | copy rebuilt, the edited screen year put back | caught 5 | – | – | – |
| vt-field-rcn | put back the year and the RCN list only | caught 5 | – | – | – |
| vt-reopen-view | leave quietly and view afresh | caught 1 | – | – | – |
| vt-inline-no-kept-list | copy rebuilt inline without item 88's kept list | caught 19 | – | – | – |
| vt-shallow-stash | cycCopy made with a shallow copy | caught 1 | – | – | – |
| vt-rcnset-upfront | refuse rcnSet up front, year-only put-back left | caught 8 | – | – | – |
| **vt-field-codes** | put back list + years + PMOs, nothing else | **survives 0** | **exit 0** | audit-other, audit, audit-ppt exit 0; B2 0/141; IR3 0/12; IW3 0/111 | caught 4 (3 proposal + 1 timing, see must-fix 1) |
| **vt-keeps-bands** | rebuild, refused band ladder kept | **survives 0** | **exit 0** | audit-other, audit, audit-ppt exit 0; B2 0; IR3 0 | caught 1 |
| **vt-keeps-flow** | rebuild, refused funds-flow settings kept | **survives 0** | **exit 0** | same, all pass | caught 1 |
| **vt-keeps-ccaridx** | rebuild, refused CCaR index kept | **survives 0** | **exit 0** | same, all pass | caught 1 |
| **vt-inline-no-base** | rebuilt inline without the cycle's base year | **survives 0** | **exit 0** | same, all pass | caught 1 (a CONTROL on the base) |
| **vt-wrong-year-state** | rebuild on the year on screen, but FY27's plan loaded into it | **survives 0** | **exit 0** | B2 0/141; IR3 0/12 | caught 1 |

6 of 12 survive the builder's tests and every suite this verifier may run.

## MUST-FIX 1 — two status reads made after the exports (timing-dependent checks)

c1 `tools/export-audit/audit-recon.mjs` (blob `47c8520a`):

- line 5280–5282, "the record's steps: saved, reopened, PB27 viewed, 77777 typed":
  `const rx = await exportsOf(R.w);` then `J([rv, /the change was not kept|Not kept/.test(R.ev(...shareStat...)), rx])`
- line 5302–5304, "a cycle locked before v1.99, viewed · RCN 77777 typed":
  `const fo = fire('K1', 'rcn', '77777'), o = await exportsNow();` then `J([fo, notKept(), ...])`

`setStat` (board line 6811) adds "🔒 Not kept — PB27 is a locked view." to a message only within 1500 ms of a refusal. The
last export each check runs, `exportAceTieout`, writes "📈 ACE Tie-Out workbook exported — …". So the check sees "Not kept"
only when RCN-EEIC by Month, the Spend Plan Source and the ACE tie-out are all built within 1.5 s of the refusal.

Reproduction:
- `probe/vt-flaky.mjs` on c1 (VP5-flaky-on-c1, 4:45:40 AM, exit 0): the builder's steps verbatim; read at once: true; after
  the three exports at normal speed (93 ms): true; after a real 1.6 s wait, or with the page clock 2 s on: **false** (status
  "📈 ACE Tie-Out workbook exported — 2027ACE, FY27. …").
- `harness/c1/focused-u10-slow.mjs` = the builder's harness with one clock step (2 s) inserted before each of those export
  runs and nothing else: on c1 (VFS-on-c1, 4:46:46 AM) **exit 1, 2 of 38 fail, exactly these two checks**, both got
  `"fired",false`.
- Seen without injection: VFX3-mut-vt-field-codes (4:41:27 AM, two lanes and other sessions running) got
  `["fired",false,…]` on the record's-steps check; the same mutant board read true in VF, VFX and VFX2.

Effect: on a loaded machine the owning suite can fail on the correct board; in a mutation sweep the check can "catch" a
mutant by timing alone.

Minimal fix (in the new block only; `diffs/c1p-vs-c1.audit-recon.mjs.diff`, first two hunks): read the status right after
the edit, before the exports.

```
+    const rk = /the change was not kept|Not kept/.test(R.ev(`(document.getElementById('shareStat')||{}).textContent||''`));
     const rx = await exportsOf(R.w);
-      J([rv, /the change was not kept|Not kept/.test(R.ev(`(document.getElementById('shareStat')||{}).textContent||''`)), rx]),
+      J([rv, rk, rx]),
-    view(); const fo = fire('K1', 'rcn', '77777'), o = await exportsNow();
+    view(); const fo = fire('K1', 'rcn', '77777'), fk = notKept(), o = await exportsNow();
-      J([fo, notKept(), reg(), o.summary.filter(r => r[0] === 'USAF').map(r => r[1])]),
+      J([fo, fk, reg(), o.summary.filter(r => r[0] === 'USAF').map(r => r[1])]),
```

Shown: VFR-on-c1 0/38 fail; VFRS-on-c1 (fixed reads + the same 2 s clock steps) 0/38 fail; VFR-on-base 18/38 fail
(unchanged); the builder's mutants that these checks catch still caught: year-only 18, keeps-list 16, older-keeps-list 1.

## MUST-FIX 2 — the held-year checks cannot tell FY28 from FY27

The block makes FY28 a copy of FY27 (`MS.years[MS.cur+1]=JSON.parse(JSON.stringify(S))`), so "a refusal while FY28 is on
screen puts the copy back on FY28" is checked only by `MS.cur` and `FYMON`. A refusal that keeps FY28 on screen but loads
FY27's plan into it (`vt-wrong-year-state`, also proposed as entry `v200-u10-reapply-wrong-year`) passes the block, the
whole audit-recon (VS-audit-recon-mut-vt-wrong-year-state, exit 0, 230 s), B2 and IR3.

Minimal fix: the proposal's FY28 case — PB27 locked with FY28 holding R on K4 (FY27 files it on K1), FY28 on screen, 77777
typed into K1's field; expected by hand (item 83's table): USAF K1 401, K4 802, none 71, total 1274, still FY28, refused.
Fails on the base (77777 leaks), passes on c1, catches the mutant (got K1 904 / K4 299).

## MUST-FIX 3 — settings kept with the plan, and the CCaR records index

Measured (probes run on both trees):
- band 0 renamed in PB27's view (`bandSet`, refused): base — the workbook's Decision Bands names RENAMED BAND (4 cells
  VP-settings; 5 in the proposal's read); c1 — Net Funding Available, as locked.
- funds-flow axis set to destinations in the view (`flowSetAxis`, refused): base — the funds-flow export is cut by
  destination (Lockheed Martin, Pratt & Whitney, …); c1 — by what the money buys.
- a CCaR Records file imported in the view (`importCcarRecs`: writes `MS.ccarIdx`, board line 14483, then `save()`, which
  refuses): base — the Spend Plan Source from the view prints Title "REFUSED TITLE R" / "REFUSED TITLE Q" and OPR "REFUSED
  OPR" on 3 rows (VP4-ccar-on-base); c1 — "Ev R" / "Ev Q", OPR blank (VP4-ccar-on-c1); the `vt-keeps-ccaridx` mutant leaks
  exactly as the base does (VP4-ccar-on-mut-vt-keeps-ccaridx). The Spend Plan Source reads it through `ccarTitleOf` /
  `ccarOprOf` (`srcRowsOf`, lines 17202 and 17222). The menu item is open in a view (line 26116); nothing refuses it up front.

The c1 board fixes all three; no check holds them. Minimal fix: the proposal block (`harness/vt-block-settings2.mjs.txt`,
placed after "// ==== end v2.00 (U10) ====", the house shape: async wrapper, bootMark/bootRelease/settleBoards, the
two-space `  const name = '...'` line, start/end markers), 9 checks:

| check | base | c1 |
|---|---|---|
| CONTROL — PB27 viewed, nothing changed: band 0 as locked, funds flow cut by what the money buys | pass | pass |
| band 0 renamed RENAMED BAND (refused): refused and said so; workbook still names band 0 as locked | **fail** | pass |
| funds-flow axis set to destinations (refused): refused and said so; export still cut by what the money buys | **fail** | pass |
| FY28 (R on K4) on screen, 77777 typed into K1: refused; still FY28; RCN-EEIC by Month as FY28 holds it | **fail** | pass |
| CONTROL — PB27 viewed, nothing imported: Spend Plan Source titles R and Q by their own names, OPR blank | pass | pass |
| CCaR Records file imported (refused): refused and said so; Spend Plan Source unchanged | **fail** | pass |
| CONTROL — the same file imported on the working plan (allowed): Title and OPR printed | pass | pass |
| CONTROL — working base year moved to FY28 after the lock; the view keeps FY27–FY31 after a refusal | pass | pass |
| CONTROL — no jsdom script errors | pass | pass |

Proposed mutation entries (`harness/vt-entries2.mjs.txt`, inserted before the R3 line; mcount on c1 + these: 1338 entries,
each once): `v200-u10-reapply-wrong-year`, `v200-u10-reapply-keeps-plan-settings`, `v200-u10-reapply-keeps-ccar-index`,
`v200-u10-reapply-working-base`. Through VFX3 (the builder's block + the proposal): caught 1 / 2 / 1 / 1. My six survivors:
caught 4 / 1 / 1 / 1 / 1 / 1. The builder's six: still caught 22 / 17 / 5 / 2 / 2 / 1.

Whole owning suite with the proposal (`c1p`, audit-recon `cf8aa87a`, run from `c1p/`, `BOARD` set for the others):

| run | start (ET) | exit | wall s | checks | failing |
|---|---|---|---|---|---|
| VSP-audit-recon-c1 (board c1) | 4:51:24 | 0 | 253.5 | 342 | 0 |
| VSP-audit-recon-base (board fce8a391) | 4:51:25 | 1 | 256.9 | 342 | 22, all in U10 (18) + proposal (4); none elsewhere |
| VSP-audit-recon-mut-vt-keeps-ccaridx | 5:03:54 | 1 | 401.3 | 342 | 1 (CCaR import) |
| VSP-audit-recon-mut-vt-inline-no-base | 5:02:28 | 1 | 483.1 | 342 | 1 (base year) |
| VSP-audit-recon-mut-vt-field-codes-r2 | 5:10:54 | 1 | 250.6 | 342 | 3 (band, funds flow, CCaR) |
| VSP-audit-recon-mut-vt-wrong-year-state-r2 | 5:15:05 | 1 | 215.0 | 342 | 1 (FY28 R on K4) |

The first field-codes and wrong-year runs (started 4:55:41 and 4:55:38) were killed at 406 s and 496 s with exit 137 by the
container's memory-cgroup OOM killer (dmesg: "Memory cgroup out of memory", the machine shared with other sessions, 1.6 GB
free); they are incomplete and were re-run one at a time (-r2) once memory was free.

## SHOULD-FIX

- **vt-inline-no-base** (refusal rebuilds on the working plan's base year) survives everything; risk is lower now that
  `cycCopy` is the one place, so the proposal guards it with a CONTROL (passes on the base by design) and entry
  `v200-u10-reapply-working-base`.
- **The builder's findings and draft about CCaR records are wrong.** "exportCoa prints CCaR records, which are year state
  and were already put back": the Title, OPR and Control No come from `MS.ccarIdx`. The base leaked a refused import into the
  Spend Plan Source; c1 closes it. The NEXT-VERSION entry should name it (what was wrong, what users may see: a CCaR Records
  file imported in a locked view is dropped at once).
- **The status after a refused CCaR import is not true on c1**: "🔒 Not kept — PB27 is a locked view. 📇 ccar-records.xlsx —
  2 records indexed on CCaR No. On this board 0 of 3 requirements … now find a Title and OPR. 💾 Save to bake this into the
  file." The index is gone and Save refuses in a view (the base said "2 of 3", true only on the throwaway copy). Principle 4:
  either refuse the import up front in a view (`cycBlock('Importing CCaR records')`, like the service list) or record it in
  the ledger.
- **A sentence in the draft is contradicted by the builder's own new ledger row**: "The stored cycle, the working plan and
  browser storage were never changed by a refused edit, and still are not." A destination renamed in a view is written to
  browser storage while the board says it was not kept. Qualify it: "… by a refused edit to the plan or the cycle (the lists
  every appropriation shares are another matter: ledger row U<n>)".

## MINOR

- The new ledger row says "The cost-estimate import says what it did over the refusal." By code (`importAce`, lines
  14522–14544): it stores the estimate in `ACEDB` (`persistAce`, kept), then `persist()` refuses and `setStat` prefixes "🔒 Not
  kept — PB27 is a locked view." to "📈 <key> loaded and 🔒 locked …" — kept, while saying not kept: the same shape as the
  destination rename. Name `importAce` in that row. (Not measured.)
- The 9 CONTROLs in the builder's block pass on the base: by design (the finding asks for controls), not a defect.
- The proposal block's name says "band rename or funds-flow axis"; if adopted, the lead should rename it in the house style
  ("v2.00 (U10) — …") and keep the `const name` line in step.

## Decisions, with reasons

- **Resumed, not restarted.** The first session's copies, mutants, logs and harnesses were checked (blobs above) and kept;
  only the new work was run in this session. Nothing from the first session was re-run except where a result needed it.
- **Must-fix 1 is a must** because it can fail the owning suite on the correct board and can credit a mutant by timing;
  shown deterministically (VFS) and seen once naturally. The fix moves two reads; no expectation changes.
- **Must-fixes 2 and 3 are musts** because they are export and money correctness (the can't-fails), each with a plausible
  wrong fix that every suite passes, and with the c1 behaviour already promised in the draft. The proposal is the fix, not
  a request for new design.
- **No board change proposed.** The c1 board is right on every case measured.
- **The CCaR index case was probed, not assumed**: base leaks, c1 does not, the mutant does (VP4).

## Every run (this verifier)

Label | start (ET) | exit | wall s | log — from `logs/runs.txt` (generated table below). PIDs with commands: `pids.txt`.

| label | start (ET) | exit | wall s | log |
|---|---|---|---|---|
| VF-u10-on-c1 | 13 Oct 00:10:11 | 0 | 34.6 | `logs/VF-u10-on-c1.log` |
| VF-u10-on-base | 13 Oct 00:10:46 | 1 | 26.5 | `logs/VF-u10-on-base.log` |
| VS-audit-recon-c1 | 13 Oct 00:11:33 | 0 | 155.7 | `logs/VS-audit-recon-c1.log` |
| VF-mut-vt-noapply | 13 Oct 00:15:22 | 1 | 24.5 | `logs/VF-mut-vt-noapply.log` |
| VS-audit-recon-base | 13 Oct 00:14:08 | 0 | 106.5 | `logs/VS-audit-recon-base.log` |
| VF-mut-vt-field-rcn | 13 Oct 00:15:47 | 1 | 22.3 | `logs/VF-mut-vt-field-rcn.log` |
| VS-boot-same-c1 | 13 Oct 00:16:10 | 0 | 15.8 | `logs/VS-boot-same-c1.log` |
| VS-audit-c1 | 13 Oct 00:16:26 | 0 | 15.6 | `logs/VS-audit-c1.log` |
| VF-mut-vt-field-codes | 13 Oct 00:16:09 | 0 | 33.8 | `logs/VF-mut-vt-field-codes.log` |
| VS-audit-ppt-c1 | 13 Oct 00:16:41 | 0 | 6.5 | `logs/VS-audit-ppt-c1.log` |
| VF-mut-vt-keeps-bands | 13 Oct 00:16:43 | 0 | 30.6 | `logs/VF-mut-vt-keeps-bands.log` |
| VS-audit-other-c1 | 13 Oct 00:16:48 | 0 | 49.7 | `logs/VS-audit-other-c1.log` |
| VS-legacy-fsrc-c1 | 13 Oct 00:17:38 | 0 | 5.7 | `logs/VS-legacy-fsrc-c1.log` |
| VF-mut-vt-keeps-flow | 13 Oct 00:17:14 | 0 | 31.2 | `logs/VF-mut-vt-keeps-flow.log` |
| VF-mut-vt-reopen-view | 13 Oct 00:17:45 | 1 | 33.3 | `logs/VF-mut-vt-reopen-view.log` |
| VP-settings-on-c1 | 13 Oct 00:18:36 | 0 | 6.6 | `logs/VP-settings-on-c1.log` |
| VP-settings-on-base | 13 Oct 00:18:42 | 0 | 6.4 | `logs/VP-settings-on-base.log` |
| VF-mut-vt-inline-no-kept-list | 13 Oct 00:18:19 | 1 | 34.2 | `logs/VF-mut-vt-inline-no-kept-list.log` |
| VS-audit-hostile-c1 | 13 Oct 00:17:43 | 0 | 85.9 | `logs/VS-audit-hostile-c1.log` |
| VF-mut-vt-inline-no-base | 13 Oct 00:18:53 | 0 | 34.3 | `logs/VF-mut-vt-inline-no-base.log` |
| VS-audit-inject-c1 | 13 Oct 00:19:09 | 0 | 23.4 | `logs/VS-audit-inject-c1.log` |
| VS-boot-same-base | 13 Oct 00:19:33 | 0 | 19.1 | `logs/VS-boot-same-base.log` |
| VF-mut-vt-shallow-stash | 13 Oct 00:19:27 | 1 | 32.8 | `logs/VF-mut-vt-shallow-stash.log` |
| VS-audit-base | 13 Oct 00:19:52 | 0 | 17.4 | `logs/VS-audit-base.log` |
| VS-audit-ppt-base | 13 Oct 00:20:09 | 0 | 7.3 | `logs/VS-audit-ppt-base.log` |
| VF-mut-vt-rcnset-upfront | 13 Oct 00:20:00 | 1 | 32.7 | `logs/VF-mut-vt-rcnset-upfront.log` |
| VS-audit-other-base | 13 Oct 00:20:17 | 0 | 45.9 | `logs/VS-audit-other-base.log` |
| VF-mut-vt-keeps-ccaridx | 13 Oct 00:20:33 | 0 | 29.5 | `logs/VF-mut-vt-keeps-ccaridx.log` |
| VS-legacy-fsrc-base | 13 Oct 00:21:03 | 0 | 4.3 | `logs/VS-legacy-fsrc-base.log` |
| VB2-on-c1 | 13 Oct 00:21:55 | 0 | 11.1 | `logs/VB2-on-c1.log` |
| VS-audit-hostile-base | 13 Oct 00:21:07 | 0 | 61.6 | `logs/VS-audit-hostile-base.log` |
| VB2-on-base | 13 Oct 00:22:06 | 0 | 17.0 | `logs/VB2-on-base.log` |
| VS-audit-inject-base | 13 Oct 00:22:09 | 0 | 18.8 | `logs/VS-audit-inject-base.log` |
| VIR3-on-c1 | 13 Oct 00:22:23 | 0 | 19.0 | `logs/VIR3-on-c1.log` |
| VN-check-base | 13 Oct 00:22:38 | 0 | 5.6 | `logs/VN-check-base.log` |
| VN-check-c1 | 13 Oct 00:22:43 | 0 | 5.3 | `logs/VN-check-c1.log` |
| VIR3-on-base | 13 Oct 00:22:42 | 0 | 20.0 | `logs/VIR3-on-base.log` |
| VP3-evidence-on-base | 13 Oct 00:23:01 | 1 | 8.8 | `logs/VP3-evidence-on-base.log` |
| VB2-mut-vt-field-codes | 13 Oct 00:23:02 | 0 | 16.8 | `logs/VB2-mut-vt-field-codes.log` |
| VP-paths-on-base | 13 Oct 00:23:10 | 0 | 16.3 | `logs/VP-paths-on-base.log` |
| VP2-side-on-base | 13 Oct 00:23:26 | 0 | 8.4 | `logs/VP2-side-on-base.log` |
| VB2-mut-vt-keeps-bands | 13 Oct 00:23:19 | 0 | 15.6 | `logs/VB2-mut-vt-keeps-bands.log` |
| VP3-evidence-on-c1 | 13 Oct 00:23:35 | 0 | 10.0 | `logs/VP3-evidence-on-c1.log` |
| VB2-mut-vt-keeps-flow | 13 Oct 00:23:35 | 0 | 15.5 | `logs/VB2-mut-vt-keeps-flow.log` |
| VP-paths-on-c1 | 13 Oct 00:23:45 | 0 | 15.3 | `logs/VP-paths-on-c1.log` |
| VB2-mut-vt-inline-no-base | 13 Oct 00:23:51 | 0 | 16.0 | `logs/VB2-mut-vt-inline-no-base.log` |
| VP2-side-on-c1 | 13 Oct 00:24:00 | 0 | 7.5 | `logs/VP2-side-on-c1.log` |
| VB2-mut-vt-keeps-ccaridx | 13 Oct 00:24:07 | 0 | 12.2 | `logs/VB2-mut-vt-keeps-ccaridx.log` |
| VIR3-mut-vt-field-codes | 13 Oct 00:24:19 | 0 | 14.1 | `logs/VIR3-mut-vt-field-codes.log` |
| VS-audit-recon-mut-vt-field-codes | 13 Oct 00:22:04 | 0 | 155.7 | `logs/VS-audit-recon-mut-vt-field-codes.log` |
| VIR3-mut-vt-keeps-bands | 13 Oct 00:24:33 | 0 | 11.3 | `logs/VIR3-mut-vt-keeps-bands.log` |
| VIR3-mut-vt-keeps-flow | 13 Oct 00:24:45 | 0 | 12.2 | `logs/VIR3-mut-vt-keeps-flow.log` |
| VIR3-mut-vt-inline-no-base | 13 Oct 00:24:57 | 0 | 12.1 | `logs/VIR3-mut-vt-inline-no-base.log` |
| VIR3-mut-vt-keeps-ccaridx | 13 Oct 00:25:09 | 0 | 13.0 | `logs/VIR3-mut-vt-keeps-ccaridx.log` |
| VF-mut-v200-u10-reapply-year-only | 13 Oct 00:25:22 | 1 | 19.5 | `logs/VF-mut-v200-u10-reapply-year-only.log` |
| VF-mut-v200-u10-reapply-keeps-list | 13 Oct 00:25:42 | 1 | 16.9 | `logs/VF-mut-v200-u10-reapply-keeps-list.log` |
| VF-mut-v200-u10-reapply-keeps-years | 13 Oct 00:25:59 | 1 | 22.6 | `logs/VF-mut-v200-u10-reapply-keeps-years.log` |
| VS-audit-recon-mut-vt-keeps-bands | 13 Oct 00:24:40 | 0 | 103.8 | `logs/VS-audit-recon-mut-vt-keeps-bands.log` |
| VFX-observe-on-c1 | 13 Oct 00:26:06 | 1 | 22.2 | `logs/VFX-observe-on-c1.log` |
| VF-mut-v200-u10-reapply-keeps-pmos | 13 Oct 00:26:21 | 1 | 16.0 | `logs/VF-mut-v200-u10-reapply-keeps-pmos.log` |
| VF-mut-v200-u10-reapply-first-year | 13 Oct 00:26:38 | 1 | 20.5 | `logs/VF-mut-v200-u10-reapply-first-year.log` |
| VFX-on-c1 | 13 Oct 00:26:47 | 0 | 23.6 | `logs/VFX-on-c1.log` |
| VF-mut-v200-u10-reapply-older-keeps-list | 13 Oct 00:26:58 | 1 | 19.6 | `logs/VF-mut-v200-u10-reapply-older-keeps-list.log` |
| VFX-on-base | 13 Oct 00:27:11 | 1 | 26.9 | `logs/VFX-on-base.log` |
| VF-mut-v199-cyc-view-today | 13 Oct 00:27:18 | 1 | 29.4 | `logs/VF-mut-v199-cyc-view-today.log` |
| VFX-mut-vt-keeps-bands | 13 Oct 00:27:43 | 1 | 34.2 | `logs/VFX-mut-vt-keeps-bands.log` |
| VF-mut-v199-cyc-note-silent | 13 Oct 00:27:47 | 1 | 32.6 | `logs/VF-mut-v199-cyc-note-silent.log` |
| VS-audit-recon-mut-vt-keeps-flow | 13 Oct 00:26:24 | 0 | 153.8 | `logs/VS-audit-recon-mut-vt-keeps-flow.log` |
| VF-mut-v199-cyc-view-silent | 13 Oct 00:28:20 | 1 | 46.7 | `logs/VF-mut-v199-cyc-view-silent.log` |
| VFX-mut-vt-keeps-flow | 13 Oct 00:28:17 | 1 | 50.6 | `logs/VFX-mut-vt-keeps-flow.log` |
| VF-mut-v200-cyc-title-html | 13 Oct 00:29:07 | 0 | 49.3 | `logs/VF-mut-v200-cyc-title-html.log` |
| VFX-mut-vt-field-codes | 13 Oct 00:29:08 | 1 | 53.1 | `logs/VFX-mut-vt-field-codes.log` |
| VB2-mut-view-refused-edit-stays | 13 Oct 00:29:56 | 1 | 29.4 | `logs/VB2-mut-view-refused-edit-stays.log` |
| VB2-mut-view-shares-cycle-years | 13 Oct 00:30:26 | 1 | 32.2 | `logs/VB2-mut-view-shares-cycle-years.log` |
| VB2-mut-view-shares-store | 13 Oct 00:30:58 | 1 | 26.7 | `logs/VB2-mut-view-shares-store.log` |
| VB2-mut-view-leave-keeps-copy | 13 Oct 00:31:25 | 1 | 24.1 | `logs/VB2-mut-view-leave-keeps-copy.log` |
| VB2-mut-view-title-unmarked | 13 Oct 00:31:49 | 1 | 27.1 | `logs/VB2-mut-view-title-unmarked.log` |
| VB2-mut-v200-cyc-title-html | 13 Oct 00:32:17 | 0 | 27.8 | `logs/VB2-mut-v200-cyc-title-html.log` |
| VS-audit-inject-c1-mut-v200-cyc-title-html | 13 Oct 00:32:44 | 1 | 26.6 | `logs/VS-audit-inject-c1-mut-v200-cyc-title-html.log` |
| VS-audit-recon-mut-vt-inline-no-base | 13 Oct 00:28:57 | 0 | 280.7 | `logs/VS-audit-recon-mut-vt-inline-no-base.log` |
| VFX-mut-vt-wrong-year-state | 13 Oct 00:34:11 | 0 | 49.0 | `logs/VFX-mut-vt-wrong-year-state.log` |
| VFX2-on-c1 | 13 Oct 00:35:29 | 0 | 61.0 | `logs/VFX2-on-c1.log` |
| VFX2-on-base | 13 Oct 00:36:37 | 1 | 68.2 | `logs/VFX2-on-base.log` |
| VS-audit-recon-mut-vt-keeps-ccaridx | 13 Oct 00:33:38 | 0 | 293.0 | `logs/VS-audit-recon-mut-vt-keeps-ccaridx.log` |
| VFX2-mut-vt-wrong-year-state | 13 Oct 00:37:46 | 1 | 57.6 | `logs/VFX2-mut-vt-wrong-year-state.log` |
| VIW3-on-c1 | 13 Oct 00:33:24 | 0 | 321.9 | `logs/VIW3-on-c1.log` |
| VFX2-mut-vt-keeps-bands | 13 Oct 00:38:43 | 1 | 58.2 | `logs/VFX2-mut-vt-keeps-bands.log` |
| VS-audit-other-mut-vt-field-codes | 13 Oct 00:38:31 | 0 | 78.5 | `logs/VS-audit-other-mut-vt-field-codes.log` |
| VFX2-mut-vt-keeps-flow | 13 Oct 00:39:42 | 1 | 46.5 | `logs/VFX2-mut-vt-keeps-flow.log` |
| VS-audit-other-mut-vt-keeps-bands | 13 Oct 00:39:50 | 0 | 61.9 | `logs/VS-audit-other-mut-vt-keeps-bands.log` |
| VFX2-mut-vt-field-codes | 13 Oct 00:40:28 | 1 | 38.3 | `logs/VFX2-mut-vt-field-codes.log` |
| VS-audit-other-mut-vt-keeps-flow | 13 Oct 00:40:52 | 0 | 55.2 | `logs/VS-audit-other-mut-vt-keeps-flow.log` |
| VFX2-mut-v200-u10-reapply-first-year | 13 Oct 00:41:07 | 1 | 41.7 | `logs/VFX2-mut-v200-u10-reapply-first-year.log` |
| VS-audit-other-mut-vt-inline-no-base | 13 Oct 00:41:47 | 0 | 67.9 | `logs/VS-audit-other-mut-vt-inline-no-base.log` |
| VIW3-on-base | 13 Oct 00:38:46 | 0 | 287.5 | `logs/VIW3-on-base.log` |
| VF-mut-vt-wrong-year-state | 13 Oct 00:43:03 | 0 | 57.5 | `logs/VF-mut-vt-wrong-year-state.log` |
| VS-audit-other-mut-vt-keeps-ccaridx | 13 Oct 00:42:55 | 0 | 82.6 | `logs/VS-audit-other-mut-vt-keeps-ccaridx.log` |
| VS-audit-mut-vt-field-codes | 13 Oct 00:44:18 | 0 | 19.0 | `logs/VS-audit-mut-vt-field-codes.log` |
| VF-mut-v200-u10-reapply-keeps-plan-settings | 13 Oct 00:44:00 | 0 | 42.9 | `logs/VF-mut-v200-u10-reapply-keeps-plan-settings.log` |
| VS-audit-mut-vt-keeps-bands | 13 Oct 00:44:37 | 0 | 18.0 | `logs/VS-audit-mut-vt-keeps-bands.log` |
| VS-audit-mut-vt-keeps-flow | 13 Oct 00:44:55 | 0 | 14.1 | `logs/VS-audit-mut-vt-keeps-flow.log` |
| VFX2-mut-v200-u10-reapply-keeps-plan-settings | 13 Oct 00:44:43 | 1 | 36.7 | `logs/VFX2-mut-v200-u10-reapply-keeps-plan-settings.log` |
| VS-audit-mut-vt-inline-no-base | 13 Oct 00:45:09 | 0 | 20.1 | `logs/VS-audit-mut-vt-inline-no-base.log` |
| VB2-mut-vt-wrong-year-state | 13 Oct 00:45:20 | 0 | 22.9 | `logs/VB2-mut-vt-wrong-year-state.log` |
| VS-audit-mut-vt-keeps-ccaridx | 13 Oct 00:45:29 | 0 | 23.3 | `logs/VS-audit-mut-vt-keeps-ccaridx.log` |
| VS-audit-ppt-mut-vt-field-codes | 13 Oct 00:45:52 | 0 | 12.0 | `logs/VS-audit-ppt-mut-vt-field-codes.log` |
| VIR3-mut-vt-wrong-year-state | 13 Oct 00:45:43 | 0 | 32.9 | `logs/VIR3-mut-vt-wrong-year-state.log` |
| VS-audit-ppt-mut-vt-keeps-bands | 13 Oct 00:46:04 | 0 | 15.8 | `logs/VS-audit-ppt-mut-vt-keeps-bands.log` |
| VS-audit-ppt-mut-vt-keeps-flow | 13 Oct 00:46:20 | 0 | 15.0 | `logs/VS-audit-ppt-mut-vt-keeps-flow.log` |
| VS-audit-ppt-mut-vt-inline-no-base | 13 Oct 00:46:35 | 0 | 15.4 | `logs/VS-audit-ppt-mut-vt-inline-no-base.log` |
| VS-audit-ppt-mut-vt-keeps-ccaridx | 13 Oct 00:46:51 | 0 | 15.5 | `logs/VS-audit-ppt-mut-vt-keeps-ccaridx.log` |
| VIW3-mut-vt-field-codes | 13 Oct 00:43:33 | 0 | 311.3 | `logs/VIW3-mut-vt-field-codes.log` |
| VS-audit-recon-mut-vt-wrong-year-state | 13 Oct 00:46:16 | 0 | 230.4 | `logs/VS-audit-recon-mut-vt-wrong-year-state.log` |
| VP4-ccar-on-base | 13 Oct 04:31:02 | 0 | 7.1 | `logs/VP4-ccar-on-base.log` |
| VP4-ccar-on-c1 | 13 Oct 04:31:09 | 0 | 8.2 | `logs/VP4-ccar-on-c1.log` |
| VP4-ccar-on-mut-vt-keeps-ccaridx | 13 Oct 04:31:18 | 0 | 7.4 | `logs/VP4-ccar-on-mut-vt-keeps-ccaridx.log` |
| VFX3-on-c1 | 13 Oct 04:33:38 | 0 | 38.7 | `logs/VFX3-on-c1.log` |
| VFX3-on-base | 13 Oct 04:34:23 | 1 | 41.6 | `logs/VFX3-on-base.log` |
| VFX3-mut-vt-keeps-ccaridx | 13 Oct 04:35:24 | 1 | 46.4 | `logs/VFX3-mut-vt-keeps-ccaridx.log` |
| VFX3-mut-v200-u10-reapply-keeps-plan-settings | 13 Oct 04:35:24 | 1 | 47.5 | `logs/VFX3-mut-v200-u10-reapply-keeps-plan-settings.log` |
| VFX3-mut-v200-u10-reapply-keeps-ccar-index | 13 Oct 04:36:11 | 1 | 37.7 | `logs/VFX3-mut-v200-u10-reapply-keeps-ccar-index.log` |
| VFX3-mut-v200-u10-reapply-wrong-year | 13 Oct 04:36:12 | 1 | 39.6 | `logs/VFX3-mut-v200-u10-reapply-wrong-year.log` |
| VFX3-mut-vt-inline-no-base | 13 Oct 04:36:49 | 1 | 76.1 | `logs/VFX3-mut-vt-inline-no-base.log` |
| VFX3-mut-v200-u10-reapply-year-only | 13 Oct 04:36:52 | 1 | 79.7 | `logs/VFX3-mut-v200-u10-reapply-year-only.log` |
| VFX3-mut-v200-u10-reapply-working-base | 13 Oct 04:38:05 | 1 | 81.9 | `logs/VFX3-mut-v200-u10-reapply-working-base.log` |
| VFX3-mut-v200-u10-reapply-keeps-list | 13 Oct 04:38:12 | 1 | 79.9 | `logs/VFX3-mut-v200-u10-reapply-keeps-list.log` |
| VFX3-mut-vt-keeps-bands | 13 Oct 04:39:27 | 1 | 46.6 | `logs/VFX3-mut-vt-keeps-bands.log` |
| VFX3-mut-v200-u10-reapply-keeps-years | 13 Oct 04:39:32 | 1 | 42.9 | `logs/VFX3-mut-v200-u10-reapply-keeps-years.log` |
| VFX3-mut-vt-keeps-flow | 13 Oct 04:40:14 | 1 | 70.4 | `logs/VFX3-mut-vt-keeps-flow.log` |
| VFX3-mut-v200-u10-reapply-keeps-pmos | 13 Oct 04:40:15 | 1 | 73.3 | `logs/VFX3-mut-v200-u10-reapply-keeps-pmos.log` |
| VFX3-mut-vt-field-codes | 13 Oct 04:41:24 | 1 | 86.5 | `logs/VFX3-mut-vt-field-codes.log` |
| VFX3-mut-v200-u10-reapply-first-year | 13 Oct 04:41:28 | 1 | 84.9 | `logs/VFX3-mut-v200-u10-reapply-first-year.log` |
| VFX3-mut-vt-wrong-year-state | 13 Oct 04:42:51 | 1 | 69.7 | `logs/VFX3-mut-vt-wrong-year-state.log` |
| VFX3-mut-v200-u10-reapply-older-keeps-list | 13 Oct 04:42:54 | 1 | 71.9 | `logs/VFX3-mut-v200-u10-reapply-older-keeps-list.log` |
| VP5-flaky-on-c1 | 13 Oct 04:45:40 | 0 | 11.4 | `logs/VP5-flaky-on-c1.log` |
| VFS-on-c1 | 13 Oct 04:46:46 | 1 | 52.2 | `logs/VFS-on-c1.log` |
| VFR-on-c1 | 13 Oct 04:47:38 | 0 | 30.6 | `logs/VFR-on-c1.log` |
| VFRS-on-c1 | 13 Oct 04:48:09 | 0 | 31.6 | `logs/VFRS-on-c1.log` |
| VFR-on-base | 13 Oct 04:48:40 | 1 | 19.9 | `logs/VFR-on-base.log` |
| VFR-mut-v200-u10-reapply-year-only | 13 Oct 04:49:00 | 1 | 14.3 | `logs/VFR-mut-v200-u10-reapply-year-only.log` |
| VFR-mut-v200-u10-reapply-keeps-list | 13 Oct 04:49:15 | 1 | 16.1 | `logs/VFR-mut-v200-u10-reapply-keeps-list.log` |
| VFR-mut-v200-u10-reapply-older-keeps-list | 13 Oct 04:49:31 | 1 | 48.4 | `logs/VFR-mut-v200-u10-reapply-older-keeps-list.log` |
| VSP-audit-recon-c1 | 13 Oct 04:51:24 | 0 | 253.5 | `logs/VSP-audit-recon-c1.log` |
| VSP-audit-recon-base | 13 Oct 04:51:25 | 1 | 256.9 | `logs/VSP-audit-recon-base.log` |
| VSP-audit-recon-mut-vt-field-codes | 13 Oct 04:55:41 | 137 | 406.1 | `logs/VSP-audit-recon-mut-vt-field-codes.log` | TIMED OUT = incomplete
| VSP-audit-recon-mut-vt-wrong-year-state | 13 Oct 04:55:38 | 137 | 496.2 | `logs/VSP-audit-recon-mut-vt-wrong-year-state.log` | TIMED OUT = incomplete
| VSP-audit-recon-mut-vt-inline-no-base | 13 Oct 05:02:28 | 1 | 483.1 | `logs/VSP-audit-recon-mut-vt-inline-no-base.log` |
| VSP-audit-recon-mut-vt-keeps-ccaridx | 13 Oct 05:03:54 | 1 | 401.3 | `logs/VSP-audit-recon-mut-vt-keeps-ccaridx.log` |
| VSP-audit-recon-mut-vt-field-codes-r2 | 13 Oct 05:10:54 | 1 | 250.6 | `logs/VSP-audit-recon-mut-vt-field-codes-r2.log` |
| VSP-audit-recon-mut-vt-wrong-year-state-r2 | 13 Oct 05:15:05 | 1 | 215.0 | `logs/VSP-audit-recon-mut-vt-wrong-year-state-r2.log` |

Unwrapped commands: short read-only shell and text commands (cat, grep, sed, diff, git hash-object, python3 -I text helpers
outside bx.sh) ran directly. One `node --check harness/c1/focused-u10-plus2.mjs` (syntax only) ran at about 4:33 AM ET under
`setsid -w timeout -k 10 60` but not through run.sh, so its PID was not recorded (noted in pids.txt). Every other node run
went through `run.sh` (600 s cap, lock check, PIDs). The audit-import lock was never set when a run started.

## What I did not do

- Did not run the full audit-import or audit-board (the lead runs those); only focused harnesses built verbatim from their
  blocks (B2 = audit-board PPBE blocks, IR3 / IW3 = audit-import v2.00 R3 / v1.97 W3 blocks).
- Did not import or run `mutate.mjs`; no full mutation sweep; mutant boards were made from its text by `mkmut.py`.
- Did not run Playwright or Chromium.
- Did not measure the ACE-import wording (by code only) or the destination-edit family beyond the builder's probe.
- Did not run the proposal against audit-other / audit / audit-ppt (it adds checks to audit-recon only; the board is c1's).
- Did not edit, stage, commit or push anything outside this directory.

## Files

- `out/mutants.txt` — every mutant run, one line each (exit, failing checks); `out/VFX3-failing-checks.txt` — which checks
  catch each mutant under the builder's block + the proposal; `out/suites-summary.txt` — every whole-suite run.
- `out/*.checks.jsonl` — every check of every focused run (SUITE_CHECKS), verdict and observed value.
- `probe/` — u10-paths.mjs (every RCN panel edit and the PMO rename, each export), u10-probe-evidence.mjs (the record's steps),
  u10-side.mjs (the builder's side probe), vt-plan-settings.mjs (band and funds-flow), vt-ccar.mjs (CCaR import), vt-flaky.mjs
  (status read timing). Their outputs: `out/VP*.json`.
- `harness/` — the focused harnesses, the proposal block and entries, the mutate text with the proposed entries.
- `mut/` — my mutant boards (`vt-*`, proposed `v200-u10-*`) and the builder's (`mut/b/`, made by mkmut.py from c1's text).
- `c1p/` — the proposal copy: c1 + the two moved reads + the proposal block in audit-recon, + the 4 entries in mutate.mjs.txt.

Written 13 Oct 2026, finished at 5:19 AM ET.
