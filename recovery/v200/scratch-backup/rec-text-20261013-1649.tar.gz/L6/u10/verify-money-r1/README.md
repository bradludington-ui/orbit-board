# U10 — independent adversarial verifier, round 1, lens A (data loss and money)

Verifier of the U10 builder's result (`rec/L6/u10`, one proposed commit, copy `c1`). Work only in this directory; the
builder's files, `/home/user/orbit-board` and `/home/user/orbit-ui` were only read. Nothing committed, staged or pushed.
mutate.mjs was never imported or run (text only, through `rec/bin/mcount.py` / `mkmut.py`, `python3 -I`). No playwright
install, no Chromium run. Full audit-import / audit-board were not run (the lead's). Times are Eastern (EDT).

Resumed after a usage-limit stop: before the stop only `base/` and `c1/` had been copied here (blobs re-checked below);
every run below was made after the resume, starting 11:20 PM ET on 12 Oct.

## Identities (git hash-object)

| what | base (`7ee498a`) | c1 (builder) |
|---|---|---|
| prioritization-board-grid.html | `fce8a391` (= `git show 7ee498a:` in orbit-board) | `4a8b0be3` |
| tools/export-audit/audit-recon.mjs | `529e36f7` (= 7ee498a) | `47c8520a` |
| tools/export-audit/mutate.mjs.txt | `cbc6defc` (= 7ee498a's mutate.mjs) | `d245868c` |
| audit-import / audit-board / audit-other | `4aba2506` / `a7c575e5` / `d89396b0` | unchanged |

My copies `base/`, `c1/` are byte-identical to `rec/L6/base` and `rec/L6/u10/c1` (checked 11:13 PM ET). Diff sizes c1 vs
base: board +22 −10, audit-recon +189 −0, mutate +20 −0 (no existing expectation changed).

Files of mine: `probe/vprobe.mjs` `b2e05134`, `probe/vprobe2.mjs` `4919044b`, `harness/c1/focused-u10.mjs` `47e747c0`
(made by the builder's `bin/mkfocused-u10.py` `76abf73c` from c1's audit-recon, blocks item 83 | item 88 | U10; it differs
from the builder's only in line 1's path comment), `runner.mjs` `f851f139` (the builder's, unchanged), `run.sh` `f69287e9`
(the builder's, pointed here), `mutrun.sh` `fd50ae57`. Extra mutants of mine: `mut/c1/vx-keeps-bands.html` `392ec8c5`,
`mut/c1/vx-keeps-flow.html` `e967e747`. Prototype of the proposed must-fix: `proto/c1fix/prioritization-board-grid.html`
`98c9dc0b`, diff `proto/c1fix-vs-c1.diff` `22b9d780`.

## Every run (all through run.sh: setsid -w timeout -k 10 600, lock checked first, PIDs in pids.txt)

| label | start ET | exit | wall s | result |
|---|---|---|---|---|
| VF-u10-on-c1 | 23:20:40 | 0 | 54.6 | focused item 83/88/U10: 38/38 pass (U10 27, item 88 11) |
| VF-u10-on-base | 23:21:35 | 1 | 42.5 | U10 18 fail (all defect checks), 9 controls pass; item 88 11/11 |
| VP1-on-c1 | 23:25:14 | 0 | 31.7 | first probe version; its working-plan snapshot was taken before the exports' lazy `S.whatif` default — superseded by VP2 |
| VP2-on-c1 | 23:26:35 | 0 | 66.7 | A: 20 refused edits, whole view MS and all 15 exports identical to a fresh view; B: destination data loss; C: PMO list |
| VP2-on-base | 23:27:42 | 0 | 62.3 | A: 17 of 20 edits leave the view's MS changed, 8 change exports (the 3 year-level controls do neither); B, C as on c1 |
| VP3-on-c1 | 23:30:26 | 0 | 24.0 | D/E/F shared lists in a view (rename, ACE import, BAE import) |
| VP3-on-base | 23:31:02 | 0 | 24.0 | identical to c1 (pre-existing) |
| VM-v200-u10-reapply-year-only | 23:33:01 | 1 | 78.8 | 18 of 38 checks fail (caught) |
| VM-v200-u10-reapply-keeps-list | 23:34:20 | 1 | 80.8 | 16 of 38 (caught) |
| VM-v200-u10-reapply-keeps-years | 23:35:41 | 1 | 79.6 | 5 of 38 (caught) |
| VM-v200-u10-reapply-keeps-pmos | 23:37:00 | 1 | 70.3 | 2 of 38 (caught) |
| VM-v200-u10-reapply-first-year | 23:38:15 | 1 | 63.4 | 1 of 38 (caught) |
| VM-v200-u10-reapply-older-keeps-list | 23:39:19 | 1 | 60.9 | 1 of 38 (caught) |
| VM-vx-keeps-bands (mine) | 23:40:20 | 0 | 48.9 | 0 of 38 — SURVIVES the U10 block |
| VM-vx-keeps-flow (mine) | 23:41:09 | 0 | 60.2 | 0 of 38 — SURVIVES the U10 block |
| VS-audit-recon-c1 (owning suite, full) | 23:42:38 | 0 | 353.7 | ALL CHECKS PASSED |
| VS-audit-recon-base | 23:48:39 | 0 | 377.0 | ALL CHECKS PASSED |
| VP2-on-proto | 23:50:50 | 0 | 82.0 | A unchanged (all same); B: the delete refused up front, nothing lost |
| VP3-on-proto | 23:52:12 | 0 | 26.0 | D/E/F refused up front: no storage write, no export change |
| VF-u10-on-proto | 23:52:51 | 0 | 86.3 | 38/38 pass |
| VS-audit-other-c1 | 23:54:56 | 0 | 95.0 | ALL CHECKS PASSED |
| VS-boot-same-c1 | 23:56:31 | 0 | 28.4 | identical either way |
| VS-audit-other-base | 23:57:19 | 0 | 81.7 | ALL CHECKS PASSED |
| VS-boot-same-base | 23:58:40 | 0 | 24.0 | identical either way |
| VS-audit-recon-c1-mut-vx-keeps-bands (full owning suite, BOARD = my mutant) | 23:59:04 | 0 | 219.3 | ALL CHECKS PASSED — the mutant SURVIVES the whole suite |
| VS-audit-recon-c1-mut-year-only-control (same mechanism, the builder's mutant) | 00:03:06 (13 Oct) | 1 | 133.1 | 18 FAILING CHECK(S): the BOARD route works, so the survival above is real |

Runs started after this table was written are appended in `logs/runs.txt` (each line: label, start, exit, wall, log).

mcount (text only, `out/mcount/`): base 1328 entries, 1328 once; c1 1334 entries, 1334 once; none missing, multiple or
unparsed. The six new finds each match c1 exactly once (mkmut.py).

## What was confirmed

- The defect on base and its absence on c1 (VF runs; VP2 A). The builder's counts all reproduce: 18/27 fail on base with the
  9 controls passing; 27/27 on c1; mutants 18/16/5/2/1/1 failing checks.
- Stronger than the block: for 20 kinds of refused edit in a view (RCN set/delete/add/service box, PMO rename/delete/move/add/
  reset, band ladder, funds-flow layout/axis/upl, the cycle reference, and year-level controls), c1 leaves the view's WHOLE
  `MS` byte-identical to a fresh view's, and all 15 exports (exportExcel, Src, AceTieout, CSV, Coa, Plans, FydpPlan, FcView,
  Flow, PPT, ProposedOrder, RlgPlan, Reprog, CycCompare, ExView; content handed to buildXlsx/buildPptx and text Blobs,
  clock text blanked) identical; the working plan after leaving is byte-identical and its exports unchanged; browser storage
  and CYCDB unchanged. Base: band rename leaks into exportExcel and exportCSV, flow axis into exportFlow, PMO delete/reset
  into 11 exports.
- No regression found in the change itself (identity of MS swapped per refusal: callers that write after save() were looked
  for by the builder's scan and by reading; aceWithYear's temporary year switch restores onto the new copy correctly).

## What was found (details in the structured verdict)

1. **Data loss on the changed board, next to the change (pre-existing; identical on base).** A destination the WORKING plan
   uses, deleted while a locked cycle is on screen: the board asks "Remove Depot X? Nothing points at it." (it counts the
   view's copy and other stores, never the set-aside working plan), removes it from the list every appropriation shares and
   from browser storage, and says "🔒 Not kept — PB27 is a locked view. 📍 Removed Depot X." After leaving, R points at a
   destination that no longer exists (not OGC, unassigned); after ONE ordinary save of the working plan and a reopen, Depot X
   is gone for good and R's assignment is lost (VP2 B). The working plan's in-memory list is written too: `MS.flow.ents` is
   the same array as `DESTDB.ents`.
2. **Refused-and-said-"Not kept" writes that change code- and money-carrying exports (pre-existing; identical on base).**
   Cost-estimate import in a view: 2027ACE replaced (AV 1.1 $900 → AV '' $4,321,000), stored, the ACE tie-out and the FYDP
   plan change in the view AND on the working plan after leaving; status "🔒 Not kept — PB27 is a locked view. 📈 2027ACE
   loaded and 🔒 locked …". BAE budget import: the Spend Plan Source changes in both; "🔒 Not kept — … 💰 BAE.xlsx … 1 added".
   Destination rename: stored, said not kept (the builder's case E).
3. The drafts' sentence "The stored cycle, the working plan and browser storage were never changed by a refused edit, and
   still are not" (NEXT-VERSION draft; README's "Nothing else changes") is false as measured (1, 2). The drafted new ledger
   row names only the rename and frames it as a decision; it omits the data loss and the import routes.
4. Test gap: the draft promises the band ladder and the funds-flow settings snap back in a view; two mutants that keep them
   from the refused copy pass the U10 block (VM-vx-*).
5. Adjacent, pre-existing: a locked cycle does not keep its PMO list. Delete office ZED on the working plan after the lock
   (Q moved out first) and PB27's view files Q under AV in every export (VP2 C: exportSrc carries no ZED); the cycle store
   still says Q:ZED.

## Proposed minimal fix for 1–2 (prototype, not a commit)

`proto/c1fix` = c1 + six lines: `if(cycBlock('Changing the destination list')){ render(); return; }` at the top of
flowSetEnt, flowAddEnt, flowDelEnt, flowResetEnts; `if(cycBlock('Importing a cost estimate')){ inp.value=''; return; }` in
importAce and `if(cycBlock('Importing a budget list')){ inp.value=''; return; }` in importBud, after the file check — the
same up-front refusal svcSaveList already uses. Measured: no question asked, nothing deleted or stored, no export changes,
status "🔒 Changing the destination list is off while PB27 is on screen … the change was not kept." (true), the 20-edit
whole-state probe unchanged, the U10 focused harness 38/38. Not run on it: full suites, audit-import's view blocks, tests
or mutations for the six lines (each needs one).

## Not done

- No full audit-import / audit-board, no mutation sweep (lead's). The audit-board PPBE and audit-import W3/R3 focused
  harnesses were not re-run by me (the builder's runs stand unverified by me).
- The prototype has no suite block or mutation entries; it is evidence that a six-line refusal closes routes 1–2.
- Funds-flow money under "not yet assigned" was not shown in exportFlow: the fixture holds no execution data, so the flow
  export carried no destination rows either way; the loss is shown in the state (R's pointer, destIsOgc, the stored list)
  and after a save and reopen.
- Short read-only text commands (grep, sed, awk, diff, git hash-object/show/log, python3 -I mcount/mkmut/text checks) ran
  without the setsid/timeout wrapper; every node run went through run.sh.

## Resumed again, 13 Oct from 4:12 AM ET (after a second usage-limit stop)

Re-checked first (4:13 AM ET): the builder's files are unchanged since my copies (c1 board `4a8b0be3`, audit-recon `47c8520a`,
mutate `d245868c`); the audit-import lock was not set. Every node run below went through `run.sh` (lock check, setsid -w timeout
-k 10 600, PIDs in pids.txt) and is also in `logs/runs.txt`.

New files: `bin/mkfocused-board.py` `cbe6ceb2` and `bin/mkfocused-import.py` `252c00ef` (the builder's, copied unchanged);
harnesses made by them from MY c1 copy's suites -- `harness/c1/focused-board-ppbe.mjs` `9c4f49ad`, `focused-import-w3.mjs`
`560f65b7`, `focused-import-r3.mjs` `dba2c1d7` (each identical to the builder's after line 1); `probe/vprobe3.mjs` `e607c156`
(the cells behind vprobe2's E and F, and E2: an APPROVED estimate replaced from a view); `probe/vprobe4.mjs` `b2dc50e5` (two more
shared stores written from a view: a CCaR QPE import and a reprogramming row); `stream-w3.sh` `6288f741`,
`stream-proto-suites.sh` `daec3c98` (each just a sequence of run.sh calls).

| label | start ET (13 Oct) | exit | wall s | result |
|---|---|---|---|---|
| VB-ppbe-on-c1 | 04:16:41 | 0 | 9.9 | audit-board PPBE blocks, focused: 141/141 (confirms the builder's B2) |
| VB-ppbe-on-proto | 04:16:50 | 0 | 10.8 | 141/141 on the prototype (`98c9dc0b`) |
| VI-r3-on-c1 | 04:17:01 | 0 | 12.9 | audit-import v2.00 R3 blocks, focused: 12/12 |
| VI-r3-on-proto | 04:17:14 | 0 | 12.5 | 12/12 |
| VI-w3-on-c1 | 04:17:43 | 0 | 227.5 | audit-import v1.97 W3 blocks, focused: 111/111 |
| VS-audit-recon-proto (full) | 04:17:43 | 0 | 130.1 | ALL CHECKS PASSED |
| VS-audit-other-proto | 04:19:53 | 0 | 55.0 | ALL CHECKS PASSED |
| VP4-on-c1 | 04:19:44 | 0 | 8.2 | E1/E2/F cells below |
| VP4-on-proto | 04:20:08 | 0 | 10.9 | all three refused up front; no cell, store or estimate changes |
| VP4-on-base | 04:20:19 | 0 | 14.6 | identical to c1 (pre-existing) |
| VS-boot-same-proto | 04:20:48 | 0 | 15.6 | identical either way |
| VS-audit-inject-proto | 04:21:04 | 0 | 21.9 | ALL CHECKS PASSED |
| VS-audit-hostile-proto | 04:21:26 | 0 | 80.8 | ALL CHECKS PASSED |
| VP5-on-c1 | 04:22:49 | 0 | 7.0 | G/H below |
| VP5-on-base | 04:22:56 | 0 | 6.3 | identical to c1 (pre-existing) |

| VI-w3-on-proto | 04:21:31 | 0 | 262.3 | audit-import v1.97 W3 blocks, focused, on the prototype: 111/111 |

### What the new runs show

- **E1, a cost estimate imported while PB27 (locked) is on screen** (base = c1): the status reads "🔒 Not kept — PB27 is a
  locked view. 📈 2027ACE loaded and 🔒 locked … 💾 Save to bake it into this file." The estimate is replaced and stored
  (`prio27acedb`). ACE tie-out, in the view AND on the working plan after leaving: Mapping by Requirement, Req A
  `"Confirmed - exact line", "1.1", 1100, 900, 200` becomes `"Confirmed", "1.1", 1100, 0, 1100`; Reconciliation by PMO, AV
  `900, 1730, 830` becomes `4321000, 1730, -4319270`; the FYDP Spend Plan's estimate column carries 4,321,000 where it carried
  900 (By Requirement, By PMO, By Service).
- **E2, the same with an APPROVED (locked) estimate already held**: the board asks "⚠ 2027ACE is already loaded and LOCKED …
  An approved cost estimate should not change. Replace it?"; answered OK, it replaces the approved copy (file "2027 ACE
  approved.xlsx", AV 1.1 $900 → "2027 ACE.xlsx", AV '' $4,321,000), stores it, and then says "🔒 Not kept — PB27 is a locked
  view." After leaving the view the approved estimate is gone from the board and from browser storage.
- **F, a BAE list imported in the view**: "🔒 Not kept — … 💾 Save to bake this into the file." The Spend Plan Source's
  O&M Raw Data rows for A ($200, RCN 11111 / EEIC AAAAA) and R ($127) now carry the budget name "USAF O&M - ANG CAM ZZ9
  Discretionary AV" in the view and on the working plan; the list is stored (`prio27buddb`).
- **The prototype** (`proto/c1fix`, c1 + six `cycBlock` lines) refuses all three up front: the estimate stays "2027 ACE
  approved.xlsx" AV 1.1 $900, nothing is stored, no tie-out / FYDP / Source cell changes, and the status says "🔒 Importing a
  cost estimate is off while PB27 is on screen … the change was not kept." It passes audit-recon (full), audit-other,
  boot-same, audit-inject, audit-hostile, the focused U10 harness (38/38), audit-board PPBE (141/141) and audit-import R3
  (12/12). No suite calls the six routes inside a view (grep: audit-import's W2 list and destination blocks call them on the
  working plan only), so no existing expectation changes.
- **G, H (adjacent, not refused edits, pre-existing, base = c1)**: a CCaR QPE imported in the view is stored
  (`prio27execdb`) and changes exportSrc and exportFlow in the view and on the working plan; a reprogramming row added in the
  view with $1.5M typed ("⚖ Recorded 1.5 $M: $1,500,000.") is stored (`prio27reprog`) and is in the working plan's ATR/BTR
  log export after leaving. Nothing says "not kept" here, but the view's banner says "Read only: nothing changed here is
  kept, and nothing can be saved, loaded, locked or sent as the board".

### Verdict (13 Oct, written at about 4:27 AM ET)

**sound-with-issues; not committable as drafted.** The change itself holds: on c1 no refused edit of the 20 probed leaves a
trace in the view's state, its 15 exports, the working plan, the cycle store or browser storage; every suite passes and no
expectation changed. But the track's own scope ("every edit path that a locked view refuses") is not closed, and the drafts
claim it is:

- MUST 1: a cost estimate or BAE list imported in a view is refused-and-said ("🔒 Not kept") but stored, and it changes the
  ACE tie-out (Req A's line 1.1: confirmed estimate $900 to $0; AV estimate $900 to $4,321,000), the FYDP plan's estimate column
  and the Spend Plan Source's budget names, in the view and on the working plan; an APPROVED estimate is replaced this way.
- MUST 2: the destination list edited in a view is refused-and-said but kept; a delete asks "Nothing points at it" while the
  working plan points at it, and one ordinary save later the working plan's assignment is lost.
- MUST 3: the drafts' sentences "a refused edit … changes no code any export carries", "The stored cycle, the working plan and
  browser storage were never changed by a refused edit, and still are not" and the ledger draft's "The cost-estimate import
  says what it did over the refusal" are false as measured.
- Minimal fix measured: six `cycBlock` lines (`proto/c1fix-vs-c1.diff`), passing every suite I may run; it still needs its
  own suite checks and mutation entries.

### Not done (this resumption)

- No suite block or mutation entries were written for the six-line prototype; it is evidence, not a commit.
- The CCaR records import in a view was read in code only (c1 now puts `MS.ccarIdx` back; its status line still ends "💾 Save
  to bake this into the file" after "Not kept"), not run.
- npm run check and the audit / audit-ppt / legacy-fsrc suites were not re-run by me (the builder's runs stand).
- Full audit-import / audit-board and the mutate.mjs sweep: not run (the lead's). mutate.mjs was only read as text.
