# U10 — a refused edit never changes what any export carries (builder, L6, resumed 12 Oct)

ONE proposed commit. Copy `c1/` = base `7ee498a` (product `d66dd60`, U14) + this commit. Nothing was committed, staged or
pushed anywhere; `/home/user/orbit-board` and `/home/user/orbit-ui` were only read. The board file stays the empty template;
every run boots it in memory with synthetic data.

**Proposed commit 1:** `v2.00 (U10): a refused edit in a locked cycle's view changes no code any export carries`
| copy `c1/` | board `4a8b0be32608ac9b44cf301b7381a359a9e19111` | audit-recon `47c8520aa453fed08226ce20534d23fd04db6dde`
| mutate `d245868c0016e0a5261879cb2333b1271b4a9bf2` (as `tools/export-audit/mutate.mjs`; the copy holds it as `mutate.mjs.txt`).
Unchanged in the commit: audit-import `4aba2506`, audit-board `a7c575e5`, audit-other `d89396b0`, boot.mjs `9c4f49ad`,
package.json `7cf8186f`, NEXT-VERSION.md `65265c13` (its entry is drafted in `drafts/`, for the lead to place).

> **Fix round, 13 Oct (section at the end): this build is superseded in part.** Commit 1 is revised (copy `c1r/`: two
> timing-dependent status reads fixed, a second test block and three entries added; board unchanged) and a commit 2 is
> added (copy `c2/`: the imports and the destination list refused in a view). The drafts in `drafts/` named `*-fix.md`
> replace the ones below. Results below are kept as they were measured; where a later run replaces one, the Fix round says so.

## The finding, reproduced on the base first

Ledger row U10 (P2, export correctness): with PB27 locked on 11111 / AAAAA and the working codes moved to 99999 / ZZZZZ,
viewing PB27 and typing 77777 into the RCN field says "the change was not kept", and RCN-EEIC by Month then exports USAF
$900 and ANG $200 under 77777 / AAAAA, labelled LOCKED VIEW.

- `probe/u10-probe-evidence.mjs` (the record's steps; saved, reopened, the panel's own input fired; literal expectations):
  base `fce8a391`: **22 passed / 4 failed, all 4 defect, 0 control** (run P3-evidence-on-base, 20:10:00 ET, exit 1;
  the earlier attempt's P-evidence-on-base, 18:02:35 ET, gave the same). The four: the view still carries 77777 after the
  refusal; USAF $900 and ANG $200 under 77777 / AAAAA; four cells of the sheet name 77777. c1: 26 / 0 (P3-evidence-on-c1).
- `probe/u10-paths.mjs` (the earlier attempt's, kept; exit records present, same board blobs): every edit the RCN / EEIC
  panel offers, a PMO rename and FY28, base vs c1 (`out/P-paths-on-*.json`; `bin/cmpruns.py`). On base each edit changes the
  exports; on c1 none does, and the allowed working-plan edit (55555) is carried.
- **Cause (code):** `cycReapply` (called by every refusal, through `cycRefuse`) put back `c.years[MS.cur]` alone. An edit
  that writes beside the year first — `rcnSet`/`rcnDel`/`rcnAdd`/`rcnToggleSvc` on `MS.rcn` (and `rcnDel` on every year's
  pointers), `pmoRename` on `MS.pmos` and every year's offices, the band ladder, the funds-flow settings — stayed on the view's
  copy, and every export from the view read it.

## The change (board: +22 −10 lines)

`cycView`'s copy is built in one place, `cycCopy(c)` (the same lines, moved verbatim), and `cycReapply` builds it again from
the set-aside working plan and the locked cycle, then stays on the year on screen. Nothing else changes: the working plan
(`_cycStash`), the stored cycle (`CYCDB`) and browser storage were never written by a refused edit, and still are not.

```diff
--- a/prioritization-board-grid.html
+++ b/prioritization-board-grid.html
@@ -20128,7 +20128,7 @@
 // and MS.years every other year goes through -- there is no second renderer, and no reader has
 // to know it is looking at a lock. Nothing edited on the copy can reach the working plan, because
 // the working plan is not on the page; and nothing edited can LOOK kept, because every write
-// funnels through save() or persist(), which refuse and put the pristine year back. The file
+// funnels through save() or persist(), which refuse and put the pristine copy back. The file
 // builder, a load, a lock and the live push refuse as well: a copy of the past must never leave
 // this machine dressed as the board.
 // CYCVIEW, _cycStash and _cycRefusedAt are declared beside MS, because save(), persist(),
@@ -20146,14 +20146,8 @@
   MS.years[MS.cur]=S;
   _cycStash={MS:MS, S:S, dirty:DIRTY, title:document.title};
   CYCVIEW=key;
-  const V=JSON.parse(JSON.stringify(_cycStash.MS));     // a throwaway copy: MS-level edits die with it
-  V.years=JSON.parse(JSON.stringify(c.years));
-  if(c.base) V.base=wholeOr(c.base, V.base);
-  // v1.99 (item 88): the RCN / EEIC list it was locked with, when it kept one. A cycle locked before v1.99 kept none:
-  // its pointers are read against today's list, and the view, the cycle's line and the RCN-EEIC tab say so.
   const kept=cycRcnOf(c);
-  if(kept) V.rcn=kept;
-  MS=V;
+  MS=cycCopy(c);                                        // v2.00 (U10): made in one place, and made again by a refusal
   const y= MS.years[_cycStash.MS.cur]? +_cycStash.MS.cur : held[0];
   MS.cur=y; FYMON=fyMonths(y); applyState(MS.years[y]); MS.years[y]=S;
   document.title=_cycStash.title+' — '+blLblTxt(key)+' LOCKED VIEW';
@@ -20165,6 +20159,18 @@
     +'as the board until you <button class="qb" onclick="cycLeave()">↩ leave the view</button>.'
     +(kept? '' : ' <span style="color:var(--amber)">⚠ '+esc(CYC_RCN_TODAY)+'</span>'));
 }
+// v2.00 (U10): THE VIEW'S COPY, MADE IN ONE PLACE. cycView puts it on screen and a refused write puts it back
+// (cycReapply): the working plan set aside, with the cycle's years, its base year and the RCN / EEIC list it kept.
+function cycCopy(c){
+  const V=JSON.parse(JSON.stringify(_cycStash.MS));     // a throwaway copy: MS-level edits die with it
+  V.years=JSON.parse(JSON.stringify(c.years));
+  if(c.base) V.base=wholeOr(c.base, V.base);
+  // v1.99 (item 88): the RCN / EEIC list it was locked with, when it kept one. A cycle locked before v1.99 kept none:
+  // its pointers are read against today's list, and the view, the cycle's line and the RCN-EEIC tab say so.
+  const kept=cycRcnOf(c);
+  if(kept) V.rcn=kept;
+  return V;
+}
 // The RCN / EEIC list a cycle was locked with (v1.99, item 88): a copy of its entries, or null when it kept none --
 // locked before v1.99, or a list that is not a list. An entry that is not one is left out, as rcnReg's readers would.
 const CYC_RCN_TODAY='Its RCN / EEIC codes are read against today’s list: it was locked before v1.99, which did not keep the list with a cycle.';
@@ -20189,10 +20195,16 @@
   const tag=document.getElementById('fyTag'); if(tag) tag.textContent=FYL();
   const fh=document.getElementById('fcTitle'); if(fh) fh.textContent='📅 '+FYL()+' PROJECTED SPEND PLAN FORECAST — OCT '+(MS.cur-1)+' – SEP '+MS.cur;
 }
-// The pristine year, put back. A refused write must not leave its edit on screen looking kept.
+// The pristine copy, put back. A refused write must not leave its edit on screen looking kept.
+// v2.00 (U10): THE WHOLE COPY, NOT THE YEAR ALONE. A write the view refuses can first change what the board holds beside
+// the year on screen -- the RCN / EEIC list, the PMO list, another year's pointers -- and only the year was put back: 77777
+// typed into PB27's RCN field said "the change was not kept", and RCN-EEIC by Month then filed PB27's dollars under 77777.
+// The copy is made again, exactly as cycView made it, and stays on the year on screen.
 function cycReapply(){
   const c=blGet(CYCVIEW); if(!c || !c.years || !c.years[MS.cur]) return;
-  applyState(JSON.parse(JSON.stringify(c.years[MS.cur]))); MS.years[MS.cur]=S;
+  const y=+MS.cur;
+  MS=cycCopy(c); MS.cur=y;
+  applyState(MS.years[y]); MS.years[y]=S;
 }
 function cycRefuse(what){
   cycReapply();
```

### Every export that carries a code, and every edit path a view refuses (how they were found)

- **Exports** (`bin/` text scans, then the board read): file-writing entry points that reach an RCN / EEIC reader are
  `exportExcel` (RCN-EEIC by Month, and the whole workbook), `exportSrc` (Spend Plan Source: CLIN, EEIC, RCN, PMO) and
  `exportAceTieout` (alignment breakout and mapping: RCN, EEIC, PMO). `exportCoa` prints CCaR records (year state, put back
  before U10 too). `buildSavedHtml`, `exportOneAppn`, `exportIdsReq`, `saveInPlace*` refuse in a view. The forecast-view
  export, the PMO Matrix and PowerPoint print offices, no RCN / EEIC. The block reads the first three from their bytes.
- **Edit paths:** every refusal goes through `cycRefuse` → `cycReapply` (save(), persist() and the `cycBlock` gates). Text
  scans (`bin/savefns.py`, `bin/nosave.py`, `bin/aftersave.py`; outputs in `probe2/`): 179 functions call save()/persist();
  the state they can write before a refused save() is the year (`S`, put back before), `MS` (now put back whole), globals
  rebuilt by `applyState` (`DATA.items`, `GROUPS` via `pmoSync`), and the side lists every appropriation shares (`DESTDB`,
  `ACEDB`, `BUDDB`, `RPDB`, `EXDB`), which are not part of a view (below). No handler writes the plan without saving; no
  save()-calling function writes the plan after its save() (the 10 hits are other branches). The service list is refused
  up front (`svcSaveList`'s `cycBlock`). Timers: `liveTick` returns in a view.

### What users may see (measured, `probe2/u10-side.mjs`, P2-side-on-base / -c1, 19:40 ET)

| in PB27's view | base `fce8a391` | c1 `4a8b0be3` |
|---|---|---|
| A. cycle locked before v1.99 (no list kept), 77777 typed | view and RCN-EEIC tab read 77777 / ZZZZZ | 99999 / ZZZZZ (today's list, as it is) |
| B. funds-flow layout set to Sankey | stays Sankey in the view; "not kept" said | goes back at once; "not kept" said |
| C. Spend Plan service selector set to ANG | ANG (global and copy) | ANG on screen (global); the copy's stored value goes back |
| D. band 0 renamed | renamed in the view | goes back at once |
| E. a destination renamed (side list) | **kept**, stored, still renamed after leaving; "not kept" said | the same (not changed by U10) |

E is a separate, pre-existing finding (drafted as a new ledger row, `drafts/LEDGER-U10.md`): the side lists are shared by
every appropriation and are not part of a view by design, so U10's fix does not touch them; whether to refuse them in a
view or say they were kept is a decision for Brad (principle 2: asked, not guessed).

## The test (audit-recon, +189 lines, after the U14 block)

Block `block-u10.mjs.txt` (blob `b2e658b8`), scenario "v2.00 (U10) — a refused edit in a locked cycle’s view changes no
code any export carries", 27 checks, house style of the v2.00 blocks (async wrapper, bootMark / bootRelease(__bm, []) /
settleBoards, the two-space `const name` line, `// ==== ... ====` markers). Fixture: v1.98 item 83's board (`v198Board`),
a second held year (FY28) and an office ZED holding Q; PB27 locked; the working list moved on as item 88's is. Each edit is
fired through the control the board renders. Every expected code and figure is a hand-written literal (item 83's table).
Controls: nothing typed; + Add and a service box (no export prints them); an edit to the year's own assignments; CYCDB and
browser storage byte for byte; leaving the view; the allowed working-plan edit 55555 carried by every export; no jsdom errors.
Added in this session to the earlier attempt's block: the cycle locked before v1.99 (one check; it fails on base, and only
it catches the new mutation `v200-u10-reapply-older-keeps-list`). Expected-value changes to existing checks: **none**
(the suite diff and the mutate diff only add lines: +189 −0, +20 −0).

| focused harness (verbatim from c1's audit-recon: item 83, item 88, U10 blocks) | U10 checks | result |
|---|---|---|
| F3-u10-on-base (board fce8a391, 19:43:26 ET) | 27 | **18 fail (every one a defect check), 9 controls pass**; item 88: 11/11 pass; exit 1 |
| F3-u10-on-c1 (board 4a8b0be3, 19:43:02 ET) | 27 | 27 pass; item 88 11/11; ALL CHECKS PASSED, exit 0 |

The full audit-recon (S2-audit-recon-c1v2) runs the block among all the others: ALL CHECKS PASSED (its scenario-ran guard
would fail if it had not run).

## Mutations (+20 lines in the mutate text, before the R3 "landed-view" entry)

```diff
--- a/tools/export-audit/mutate.mjs.txt
+++ b/tools/export-audit/mutate.mjs.txt
@@ -4285,6 +4285,26 @@
   { id: "v200-u14-notice-plural-it", area: "flowHtml", what: "the panel's notice says \"keeps it\" however many saved years the board cannot answer for: FY24 and FY26 \"stay in the saved selection\", and switching a year \"keeps it\"",
     find: "switching a year on or off keeps '+(F.unavail.length===1?'it':'them')+'.</div>'",
     repl: "switching a year on or off keeps it.</div>'" },
+  // v2.00 (U10, the review of main f9b4413; fixed on Brad's word of 12 Oct, "keep pressing"): a refused edit in a locked cycle's
+  // view changes no code any export carries.
+  { id: "v200-u10-reapply-year-only", area: "cycReapply", what: "a refused write puts back the year on screen alone, as before U10: 77777 typed into PB27's RCN field says the change was not kept, and RCN-EEIC by Month, the Spend Plan Source and the ACE tie-out then file PB27's dollars under 77777",
+    find: "  MS=cycCopy(c); MS.cur=y;\n  applyState(MS.years[y]); MS.years[y]=S;",
+    repl: "  applyState(JSON.parse(JSON.stringify(c.years[y]))); MS.years[y]=S;" },
+  { id: "v200-u10-reapply-keeps-list", area: "cycReapply", what: "the view's copy is made again but keeps the refused copy's RCN / EEIC list: a code typed, a title, a ✕, a + Add or a service box, refused, stays in the view and in every export that prints the code",
+    find: "  MS=cycCopy(c); MS.cur=y;",
+    repl: "  const L0=MS.rcn; MS=cycCopy(c); MS.cur=y; MS.rcn=L0;" },
+  { id: "v200-u10-reapply-keeps-years", area: "cycReapply", what: "the view's copy is made again but keeps the refused copy's other years: K3's ✕, refused on FY27, has still cleared FY28's pointers, so FY28's exports put CLIN 0001's AFRC $31 on K1",
+    find: "  MS=cycCopy(c); MS.cur=y;",
+    repl: "  const Y0=MS.years; MS=cycCopy(c); MS.cur=y; Object.keys(Y0).forEach(function(k){ if(+k!==y) MS.years[k]=Y0[k]; });" },
+  { id: "v200-u10-reapply-keeps-pmos", area: "cycReapply", what: "the view's copy is made again but keeps the refused copy's PMO list: ZED renamed WRK, refused, leaves WRK on the list, Q filed under AV in FY27 and WRK in FY28, and every export moves Q's $71 out of ZED",
+    find: "  MS=cycCopy(c); MS.cur=y;",
+    repl: "  const P0=MS.pmos; MS=cycCopy(c); MS.cur=y; MS.pmos=P0;" },
+  { id: "v200-u10-reapply-first-year", area: "cycReapply", what: "a refusal while FY28 is on screen puts the copy back on the year the view opened on: the board reads FY27 while FY28's plan and months are on screen",
+    find: "  MS=cycCopy(c); MS.cur=y;",
+    repl: "  MS=cycCopy(c);" },
+  { id: "v200-u10-reapply-older-keeps-list", area: "cycReapply", what: "the view's copy is made again, but a cycle locked before v1.99 (no list kept, so its view reads today's) keeps the refused copy's list: 77777 typed into its RCN field stays in the view and RCN-EEIC by Month prints 77777 / ZZZZZ",
+    find: "  MS=cycCopy(c); MS.cur=y;",
+    repl: "  const L0=MS.rcn; MS=cycCopy(c); MS.cur=y; if(!cycRcnOf(c)) MS.rcn=L0;" },
   // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.
   { id: "v200-r3-landed-view-unsaid", area: "_driveStorePushRun", what: "a folder save that lands while a locked view is on screen says “🔒 Not kept — PB27 is a locked view. ✅ Saved …” again, naming no plan (or, quiet, leaves persist's refusal on screen)",
     find: "  if(CYCVIEW){ _cycRefusedAt=0; setStat('✅ <b>Saved the working plan</b> of '+esc(APPN_LBL[ap]||ap)+' FY'+(fy%100)+' to the shared folder — '\n    +Math.round(body.length/1024)+' KB, built before '+blLbl(CYCVIEW)+' was put on screen. '+blLbl(CYCVIEW)+' is a locked view: nothing in it '\n    +'is saved. Everyone sees the working plan on their next refresh.'+penNote+lateNote); render(); return true; }\n",
```

mcount (text only, `out/mcount/`): base 1328 entries, 1328 match once; c1 1334 entries, 1334 match once (no missing, no
multiple, no unparsed). Mutants were made with `mkmut.py` (text only); mutate.mjs was never imported or run.

Every new mutant caught (F3 = the U10 focused harness); the nine existing entries whose find lies in the changed lines,
still caught by their owners on c1:

| mutant | harness | exit | failing checks |
|---|---|---|---|
| v200-u10-reapply-year-only | F3 | 1 | 18 of 38 |
| v200-u10-reapply-keeps-list | F3 | 1 | 16 of 38 |
| v200-u10-reapply-keeps-years | F3 | 1 | 5 of 38 |
| v200-u10-reapply-keeps-pmos | F3 | 1 | 2 of 38 |
| v200-u10-reapply-first-year | F3 | 1 | 1 of 38 |
| v200-u10-reapply-older-keeps-list | F3 | 1 | 1 of 38 |
| v199-cyc-view-today / -note-silent / -view-silent (existing) | F3 | 1 / 1 / 1 | 23 / 1 / 1 of 38 |
| view-refused-edit-stays / -shares-cycle-years / -shares-store / -leave-keeps-copy / -title-unmarked (existing) | B2 (audit-board PPBE blocks) | 1 each | 1 / 2 / 2 / 6 / 1 of 141 |
| v200-cyc-title-html (existing) | F3, B2: not caught (0 fail); **audit-inject** (its owner, BOARD = the mutant) | 1 | 1: "the window title of a locked view uses the text label" |

Failing checks, mutant by mutant:

- **B2-c1v2-mut-v200-cyc-title-html** — 0 of 141 checks fail (not caught here; see its owner)
- **B2-c1v2-mut-view-leave-keeps-copy** — 6 of 141 checks fail:
  - [PPBE cycles — a locked view is read-only…] leave | the working plan is back, byte for byte
  - [PPBE cycles — a locked view is read-only…] leave | on the year it was on
  - [PPBE cycles — a locked view is read-only…] leave | B as the working plan has it
  - [PPBE cycles — a locked view is read-only…] leave | an edit to the board’s own settings made while viewing did not survive
  - [PPBE cycles — a locked view is read-only…] leave | and journals that edit alone — no phantom entries carrying the lock’s values
  - [PPBE cycles — a locked view is read-only…] open | and leaving returns to the year that was on screen
- **B2-c1v2-mut-view-refused-edit-stays** — 1 of 141 checks fail:
  - [PPBE cycles — a locked view is read-only…] writes | an edit is refused and reverts on screen
- **B2-c1v2-mut-view-shares-cycle-years** — 2 of 141 checks fail:
  - [PPBE cycles — a locked view is read-only…] writes | an edit is refused and reverts on screen
  - [PPBE cycles — a locked view is read-only…] writes | the lock itself is untouched
- **B2-c1v2-mut-view-shares-store** — 2 of 141 checks fail:
  - [PPBE cycles — a locked view is read-only…] leave | the working plan is back, byte for byte
  - [PPBE cycles — a locked view is read-only…] leave | an edit to the board’s own settings made while viewing did not survive
- **B2-c1v2-mut-view-title-unmarked** — 1 of 141 checks fail:
  - [PPBE cycles — a locked view is read-only…] view | the title says so, for every export that prints it
- **F3-c1v2-mut-v199-cyc-note-silent** — 1 of 38 checks fail:
  - [v1.99 item 88 — a locked cycle’s view an…] a cycle locked before v1.99 | the RCN-EEIC tab’s title says so
- **F3-c1v2-mut-v199-cyc-view-silent** — 1 of 38 checks fail:
  - [v1.99 item 88 — a locked cycle’s view an…] a cycle locked before v1.99 | its view says its codes are read against today’s list
- **F3-c1v2-mut-v199-cyc-view-today** — 23 of 38 checks fail:
  - [v1.99 item 88 — a locked cycle’s view an…] the cycle’s view · RCN-EEIC by Month | every dollar on the code it was locked on: K1 still 11111 / AAAAA, K3 still 33333 / CCCCC
  - [v1.99 item 88 — a locked cycle’s view an…] the cycle’s view · Spend Plan Source | every line’s EEIC and RCN as locked
  - [v1.99 item 88 — a locked cycle’s view an…] saved and reopened, the cycle’s view | still every code as locked
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed, nothing typed | CONTROL — every export carries the cycle’s own codes
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · RCN 77777 typed into K1’s field | refused and said so; the list in the view, and the panel redrawn on screen, are the cycle’s: K1-K4 as locked
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · RCN 77777 typed into K1’s field | every export carries the cycle’s own codes, as before the edit
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · EEIC YYYYY typed into K1’s field | refused and said so; the list in the view, and the panel redrawn on screen, are the cycle’s: K1-K4 as locked
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · EEIC YYYYY typed into K1’s field | every export carries the cycle’s own codes, as before the edit
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · title “Renamed” typed into K4’s field | refused and said so; the list in the view, and the panel redrawn on screen, are the cycle’s: K1-K4 as locked
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · title “Renamed” typed into K4’s field | every export carries the cycle’s own codes, as before the edit
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · K3 removed with its ✕, answered OK | refused and said so; the list in the view, and the panel redrawn on screen, are the cycle’s: K1-K4 as locked
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · K3 removed with its ✕, answered OK | every export carries the cycle’s own codes, as before the edit
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · + Add RCN / EEIC | refused and said so; the list in the view, and the panel redrawn on screen, are the cycle’s: K1-K4 as locked
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · + Add RCN / EEIC | CONTROL — every export carries the cycle’s own codes, as before the edit
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · K1’s ANG box switched off | refused and said so; the list in the view, and the panel redrawn on screen, are the cycle’s: K1-K4 as locked
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · K1’s ANG box switched off | CONTROL — every export carries the cycle’s own codes, as before the edit
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · K3 removed on FY27, then FY28 on screen | FY28 still holds CLIN 0001’s AFRC on K3, and the list is the cycle’s
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · K3 removed on FY27, then FY28 on screen | every export of FY28 carries the cycle’s own codes
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · FY28 on screen, RCN 77777 typed into K1’s field | refused; still FY28, on FY28’s months; the list and the panel are the cycle’s
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · FY28 on screen, RCN 77777 typed into K1’s field | every export of FY28 carries the cycle’s own codes
  - … and 3 more
- **F3-c1v2-mut-v200-cyc-title-html** — 0 of 38 checks fail (not caught here; see its owner)
- **F3-c1v2-mut-v200-u10-reapply-first-year** — 1 of 38 checks fail:
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · FY28 on screen, RCN 77777 typed into K1’s field | refused; still FY28, on FY28’s months; the list and the panel are the cycle’s
- **F3-c1v2-mut-v200-u10-reapply-keeps-list** — 16 of 38 checks fail:
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · RCN 77777 typed into K1’s field | refused and said so; the list in the view, and the panel redrawn on screen, are the cycle’s: K1-K4 as locked
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · RCN 77777 typed into K1’s field | every export carries the cycle’s own codes, as before the edit
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · EEIC YYYYY typed into K1’s field | refused and said so; the list in the view, and the panel redrawn on screen, are the cycle’s: K1-K4 as locked
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · EEIC YYYYY typed into K1’s field | every export carries the cycle’s own codes, as before the edit
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · title “Renamed” typed into K4’s field | refused and said so; the list in the view, and the panel redrawn on screen, are the cycle’s: K1-K4 as locked
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · title “Renamed” typed into K4’s field | every export carries the cycle’s own codes, as before the edit
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · K3 removed with its ✕, answered OK | refused and said so; the list in the view, and the panel redrawn on screen, are the cycle’s: K1-K4 as locked
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · K3 removed with its ✕, answered OK | every export carries the cycle’s own codes, as before the edit
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · + Add RCN / EEIC | refused and said so; the list in the view, and the panel redrawn on screen, are the cycle’s: K1-K4 as locked
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · K1’s ANG box switched off | refused and said so; the list in the view, and the panel redrawn on screen, are the cycle’s: K1-K4 as locked
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · K3 removed on FY27, then FY28 on screen | FY28 still holds CLIN 0001’s AFRC on K3, and the list is the cycle’s
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · K3 removed on FY27, then FY28 on screen | every export of FY28 carries the cycle’s own codes
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · FY28 on screen, RCN 77777 typed into K1’s field | refused; still FY28, on FY28’s months; the list and the panel are the cycle’s
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · FY28 on screen, RCN 77777 typed into K1’s field | every export of FY28 carries the cycle’s own codes
  - [v2.00 (U10) — a refused edit in a locked…] the record’s steps: saved, reopened, PB27 viewed, 77777 typed | refused; RCN-EEIC by Month, the Spend Plan Source and the ACE tie-out (on its own year, FY27, as a reopened board shows 
  - [v2.00 (U10) — a refused edit in a locked…] a cycle locked before v1.99, viewed · RCN 77777 typed into K1’s field | refused; the view’s list and RCN-EEIC by Month are today’s list as it is
- **F3-c1v2-mut-v200-u10-reapply-keeps-pmos** — 2 of 38 checks fail:
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · ZED renamed WRK with its ✎ | refused and said so; the list on screen still ends ZED; Q is in ZED in FY27 and FY28
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · ZED renamed WRK with its ✎ | every export carries the cycle’s own offices and codes: Q’s $71 under ZED
- **F3-c1v2-mut-v200-u10-reapply-keeps-years** — 5 of 38 checks fail:
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · K3 removed with its ✕, answered OK | every export carries the cycle’s own codes, as before the edit
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · K3 removed on FY27, then FY28 on screen | FY28 still holds CLIN 0001’s AFRC on K3, and the list is the cycle’s
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · K3 removed on FY27, then FY28 on screen | every export of FY28 carries the cycle’s own codes
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · ZED renamed WRK with its ✎ | refused and said so; the list on screen still ends ZED; Q is in ZED in FY27 and FY28
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · ZED renamed WRK with its ✎ | every export carries the cycle’s own offices and codes: Q’s $71 under ZED
- **F3-c1v2-mut-v200-u10-reapply-older-keeps-list** — 1 of 38 checks fail:
  - [v2.00 (U10) — a refused edit in a locked…] a cycle locked before v1.99, viewed · RCN 77777 typed into K1’s field | refused; the view’s list and RCN-EEIC by Month are today’s list as it is
- **F3-c1v2-mut-v200-u10-reapply-year-only** — 18 of 38 checks fail:
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · RCN 77777 typed into K1’s field | refused and said so; the list in the view, and the panel redrawn on screen, are the cycle’s: K1-K4 as locked
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · RCN 77777 typed into K1’s field | every export carries the cycle’s own codes, as before the edit
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · EEIC YYYYY typed into K1’s field | refused and said so; the list in the view, and the panel redrawn on screen, are the cycle’s: K1-K4 as locked
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · EEIC YYYYY typed into K1’s field | every export carries the cycle’s own codes, as before the edit
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · title “Renamed” typed into K4’s field | refused and said so; the list in the view, and the panel redrawn on screen, are the cycle’s: K1-K4 as locked
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · title “Renamed” typed into K4’s field | every export carries the cycle’s own codes, as before the edit
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · K3 removed with its ✕, answered OK | refused and said so; the list in the view, and the panel redrawn on screen, are the cycle’s: K1-K4 as locked
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · K3 removed with its ✕, answered OK | every export carries the cycle’s own codes, as before the edit
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · + Add RCN / EEIC | refused and said so; the list in the view, and the panel redrawn on screen, are the cycle’s: K1-K4 as locked
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · K1’s ANG box switched off | refused and said so; the list in the view, and the panel redrawn on screen, are the cycle’s: K1-K4 as locked
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · K3 removed on FY27, then FY28 on screen | FY28 still holds CLIN 0001’s AFRC on K3, and the list is the cycle’s
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · K3 removed on FY27, then FY28 on screen | every export of FY28 carries the cycle’s own codes
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · FY28 on screen, RCN 77777 typed into K1’s field | refused; still FY28, on FY28’s months; the list and the panel are the cycle’s
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · FY28 on screen, RCN 77777 typed into K1’s field | every export of FY28 carries the cycle’s own codes
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · ZED renamed WRK with its ✎ | refused and said so; the list on screen still ends ZED; Q is in ZED in FY27 and FY28
  - [v2.00 (U10) — a refused edit in a locked…] PB27 viewed · ZED renamed WRK with its ✎ | every export carries the cycle’s own offices and codes: Q’s $71 under ZED
  - [v2.00 (U10) — a refused edit in a locked…] the record’s steps: saved, reopened, PB27 viewed, 77777 typed | refused; RCN-EEIC by Month, the Spend Plan Source and the ACE tie-out (on its own year, FY27, as a reopened board shows 
  - [v2.00 (U10) — a refused edit in a locked…] a cycle locked before v1.99, viewed · RCN 77777 typed into K1’s field | refused; the view’s list and RCN-EEIC by Month are today’s list as it is

## Suites and npm run check, base and c1 (each run alone in its own process group, 600 s cap)

| suite | base `fce8a391` | c1 `4a8b0be3` |
|---|---|---|
| boot-same | exit 0, identical either way | exit 0, identical either way |
| audit | ALL CHECKS PASSED | ALL CHECKS PASSED |
| audit-ppt | ALL CHECKS PASSED | ALL CHECKS PASSED |
| audit-other | ALL CHECKS PASSED | ALL CHECKS PASSED |
| audit-recon (owning suite, full) | ALL CHECKS PASSED (206 s) | ALL CHECKS PASSED (241 s, with the U10 block) |
| legacy-fsrc | exit 0 | exit 0 |
| audit-hostile | ALL CHECKS PASSED | ALL CHECKS PASSED |
| audit-inject | ALL CHECKS PASSED | ALL CHECKS PASSED |
| audit-board PPBE blocks (focused, B2) | 141/141 | 141/141 |
| audit-import v1.97 W3 blocks (focused, 111 checks; views a cycle during a batch import) | 111/111 | 111/111 |
| audit-import v2.00 R3 blocks (focused, 12 checks; a save landing under a view) | 12/12 | 12/12 |
| npm run check (scratch clone `gitclone/`, `git clone --shared`, files copied over, never committed) | all checks passed | all checks passed |

Each suite's output is identical at base and c1 apart from boot-same's timings and check.mjs's line counts (+12).

## Decisions, with reasons (the lead's principles)

1. **Never lose a copy of anyone's work.** The fix rebuilds only the throwaway copy on screen, from the set-aside working
   plan and the locked cycle; neither is written. A refused edit was never kept (the board said so); nothing that was kept
   is lost. The block checks CYCDB and browser storage byte for byte, and leaving the view gives back the working plan.
2. **Refuse or ask rather than guess.** The view already refused; now it refuses completely instead of half. The side-list
   case (E), where a kept edit is said to be not kept, is put to Brad as a question, not changed.
3. **Money and every export match the computation.** No money logic is touched. Every figure and code an export prints from
   a view after a refusal is the cycle's own, checked against literals; the allowed edit on the working plan still flows.
4. **Every word stays true.** "The change was not kept" is now true for codes, offices and every held year; the view's
   comment now says "the pristine copy". The one exception measured (E) is recorded, not hidden.
5. **Smallest change that closes the finding.** One function extracted verbatim and a three-line `cycReapply`. Restoring
   field by field (the list, the PMOs, the years) was rejected: it would have left every other plan-level field (bands,
   funds-flow settings, ACE alignment, the CCaR index ...) leaking the same way, and a second copy-building path to drift.
6. **Every existing check, fixture and expected value preserved.** Suite and mutate diffs only add lines; all 1328 existing
   finds still match once; the nine existing mutations in the changed lines are still caught; every allowed suite passes
   at both. No expectation was changed, so there is no file:line to list.

Behaviour change to say plainly: in a view, a refused change to a setting kept with the plan (funds-flow layout, axis and
years shown, band ladder) now goes back at once instead of lasting until the view is left (side probe B, D). The
audit-board check "an edit to the board's own settings made while viewing did not survive" is unaffected (it edits without
saving, and checks after leaving).

## Kept from the earlier attempt, and re-run

The earlier builder (stopped about 6:16 PM ET by a usage limit) left `c1/`, the probes, the block, the entries, harnesses,
mutants and logs, and no README. Checked before building on it: c1's board equals base + `bin/edit-board.py` +
`bin/edit-board2.py` exactly (re-applied to a fresh copy of the base: same blob `4a8b0be3`); c1 differed from the base only
in the board, audit-recon and mutate text; the block and entries in c1 matched the saved texts once each.
- **Kept as is:** the board change; the probes and their results (P-evidence, P-paths: exit records present, same blobs);
  the helpers in `bin/`; `run.sh`, `bx.sh`, `runner.mjs`.
- **Changed:** the block gained the pre-v1.99 cycle check (and its header lines); one mutation entry added
  (`v200-u10-reapply-older-keeps-list`). The earlier texts are kept as `block-u10.v1-earlier-attempt.mjs.txt` (`7a773183`)
  and `entries-u10.v1-earlier-attempt.mjs.txt` (`928cdedb`). c1's audit-recon and mutate text were rebuilt from the base
  with `bin/insert-block.py` / `bin/insert-before.py`.
- **Re-run in this session:** the reproduction (P3), the focused U10 harness (F3, superseding F1/F2), the audit-board PPBE
  harness (B2, superseding B1), every mutant (from fresh mutants in `mut/c1v2/`, superseding `mut/c1/`), mcount, all
  suites on both trees (S2, superseding the earlier S- runs; its S-audit-other-base log was unfinished, no exit record), npm
  run check. New: the side probe (P2), the audit-import focused runs (I-r3, I-w3), audit-inject on the title mutant.

## Every run (label, start ET, exit, wall s, log)

The earlier attempt's runs are listed first, as it recorded them; its F1/F2/B1 results were on the earlier block and board
`4a8b0be3`. All times 12 Oct, Eastern.

| session | label | start (ET) | exit | wall s | log |
|---|---|---|---|---|---|
| earlier attempt (stopped) | P-evidence-on-base | 18:02:35 | 1 | 4.5 | `logs/P-evidence-on-base.log` |
| earlier attempt (stopped) | P-paths-on-base | 18:02:39 | 0 | 8.1 | `logs/P-paths-on-base.log` |
| earlier attempt (stopped) | P-evidence-on-c1 | 18:04:53 | 0 | 5.4 | `logs/P-evidence-on-c1.log` |
| earlier attempt (stopped) | P-paths-on-c1 | 18:04:59 | 0 | 8.9 | `logs/P-paths-on-c1.log` |
| earlier attempt (stopped) | F1-u10-on-c1 | 18:08:22 | 1 | 14.2 | `logs/F1-u10-on-c1.log` |
| earlier attempt (stopped) | F2-u10-on-c1 | 18:08:57 | 0 | 13.8 | `logs/F2-u10-on-c1.log` |
| earlier attempt (stopped) | F2-u10-on-base | 18:09:16 | 1 | 13.1 | `logs/F2-u10-on-base.log` |
| earlier attempt (stopped) | F2-c1-mut-v200-u10-reapply-year-only | 18:10:37 | 1 | 11.8 | `logs/F2-c1-mut-v200-u10-reapply-year-only.log` |
| earlier attempt (stopped) | F2-c1-mut-v200-u10-reapply-keeps-list | 18:10:48 | 1 | 11.7 | `logs/F2-c1-mut-v200-u10-reapply-keeps-list.log` |
| earlier attempt (stopped) | F2-c1-mut-v200-u10-reapply-keeps-years | 18:11:00 | 1 | 11.6 | `logs/F2-c1-mut-v200-u10-reapply-keeps-years.log` |
| earlier attempt (stopped) | F2-c1-mut-v200-u10-reapply-keeps-pmos | 18:11:12 | 1 | 10.8 | `logs/F2-c1-mut-v200-u10-reapply-keeps-pmos.log` |
| earlier attempt (stopped) | F2-c1-mut-v200-u10-reapply-first-year | 18:11:23 | 1 | 11.4 | `logs/F2-c1-mut-v200-u10-reapply-first-year.log` |
| earlier attempt (stopped) | F2-c1-mut-view-refused-edit-stays | 18:11:41 | 1 | 12.6 | `logs/F2-c1-mut-view-refused-edit-stays.log` |
| earlier attempt (stopped) | F2-c1-mut-view-shares-cycle-years | 18:11:53 | 1 | 11.6 | `logs/F2-c1-mut-view-shares-cycle-years.log` |
| earlier attempt (stopped) | F2-c1-mut-view-shares-store | 18:12:05 | 0 | 12.3 | `logs/F2-c1-mut-view-shares-store.log` |
| earlier attempt (stopped) | F2-c1-mut-v199-cyc-view-today | 18:12:17 | 1 | 11.3 | `logs/F2-c1-mut-v199-cyc-view-today.log` |
| earlier attempt (stopped) | F2-c1-mut-v199-cyc-view-silent | 18:12:29 | 1 | 11.5 | `logs/F2-c1-mut-v199-cyc-view-silent.log` |
| earlier attempt (stopped) | B1-ppbe-on-c1 | 18:13:17 | 0 | 6.2 | `logs/B1-ppbe-on-c1.log` |
| earlier attempt (stopped) | B1-ppbe-on-base | 18:13:23 | 0 | 7.8 | `logs/B1-ppbe-on-base.log` |
| earlier attempt (stopped) | B1-c1-mut-view-shares-store | 18:13:37 | 1 | 6.9 | `logs/B1-c1-mut-view-shares-store.log` |
| earlier attempt (stopped) | B1-c1-mut-view-shares-cycle-years | 18:13:44 | 1 | 7.9 | `logs/B1-c1-mut-view-shares-cycle-years.log` |
| earlier attempt (stopped) | B1-c1-mut-view-refused-edit-stays | 18:13:52 | 1 | 7.8 | `logs/B1-c1-mut-view-refused-edit-stays.log` |
| earlier attempt (stopped) | B1-c1-mut-v200-u10-reapply-year-only | 18:13:59 | 0 | 8.4 | `logs/B1-c1-mut-v200-u10-reapply-year-only.log` |
| earlier attempt (stopped) | B1-c1-mut-v200-u10-reapply-keeps-list | 18:14:08 | 0 | 10.2 | `logs/B1-c1-mut-v200-u10-reapply-keeps-list.log` |
| earlier attempt (stopped) | B1-c1-mut-v200-u10-reapply-keeps-years | 18:14:18 | 0 | 9.7 | `logs/B1-c1-mut-v200-u10-reapply-keeps-years.log` |
| earlier attempt (stopped) | B1-c1-mut-v200-u10-reapply-keeps-pmos | 18:14:28 | 0 | 12.3 | `logs/B1-c1-mut-v200-u10-reapply-keeps-pmos.log` |
| earlier attempt (stopped) | B1-c1-mut-v200-u10-reapply-first-year | 18:14:40 | 0 | 12.9 | `logs/B1-c1-mut-v200-u10-reapply-first-year.log` |
| earlier attempt (stopped) | S-boot-same-base | 18:16:05 | 0 | 11.5 | `logs/S-boot-same-base.log` |
| earlier attempt (stopped) | S-audit-base | 18:16:17 | 0 | 11.5 | `logs/S-audit-base.log` |
| earlier attempt (stopped) | S-audit-ppt-base | 18:16:28 | 0 | 5.5 | `logs/S-audit-ppt-base.log` |
| this session | P2-side-on-base | 19:40:07 | 0 | 4.5 | `logs/P2-side-on-base.log` |
| this session | P2-side-on-c1 | 19:40:12 | 0 | 4.5 | `logs/P2-side-on-c1.log` |
| this session | F3-u10-on-c1 | 19:43:02 | 0 | 24.3 | `logs/F3-u10-on-c1.log` |
| this session | F3-u10-on-base | 19:43:26 | 1 | 24.4 | `logs/F3-u10-on-base.log` |
| this session | B2-ppbe-on-c1 | 19:44:31 | 0 | 10.6 | `logs/B2-ppbe-on-c1.log` |
| this session | B2-ppbe-on-base | 19:44:42 | 0 | 10.0 | `logs/B2-ppbe-on-base.log` |
| this session | F3-c1v2-mut-v200-u10-reapply-year-only | 19:45:02 | 1 | 23.5 | `logs/F3-c1v2-mut-v200-u10-reapply-year-only.log` |
| this session | F3-c1v2-mut-v200-u10-reapply-keeps-list | 19:45:26 | 1 | 23.3 | `logs/F3-c1v2-mut-v200-u10-reapply-keeps-list.log` |
| this session | F3-c1v2-mut-v200-u10-reapply-keeps-years | 19:45:49 | 1 | 17.5 | `logs/F3-c1v2-mut-v200-u10-reapply-keeps-years.log` |
| this session | F3-c1v2-mut-v200-u10-reapply-keeps-pmos | 19:46:07 | 1 | 22.1 | `logs/F3-c1v2-mut-v200-u10-reapply-keeps-pmos.log` |
| this session | F3-c1v2-mut-v200-u10-reapply-first-year | 19:46:29 | 1 | 31.7 | `logs/F3-c1v2-mut-v200-u10-reapply-first-year.log` |
| this session | F3-c1v2-mut-v200-u10-reapply-older-keeps-list | 19:47:01 | 1 | 33.7 | `logs/F3-c1v2-mut-v200-u10-reapply-older-keeps-list.log` |
| this session | F3-c1v2-mut-v199-cyc-view-today | 19:47:34 | 1 | 26.8 | `logs/F3-c1v2-mut-v199-cyc-view-today.log` |
| this session | F3-c1v2-mut-v199-cyc-note-silent | 19:48:01 | 1 | 29.1 | `logs/F3-c1v2-mut-v199-cyc-note-silent.log` |
| this session | F3-c1v2-mut-v199-cyc-view-silent | 19:48:30 | 1 | 23.8 | `logs/F3-c1v2-mut-v199-cyc-view-silent.log` |
| this session | F3-c1v2-mut-v200-cyc-title-html | 19:48:54 | 0 | 23.4 | `logs/F3-c1v2-mut-v200-cyc-title-html.log` |
| this session | B2-c1v2-mut-view-refused-edit-stays | 19:49:18 | 1 | 13.7 | `logs/B2-c1v2-mut-view-refused-edit-stays.log` |
| this session | B2-c1v2-mut-view-shares-cycle-years | 19:49:32 | 1 | 14.7 | `logs/B2-c1v2-mut-view-shares-cycle-years.log` |
| this session | B2-c1v2-mut-view-shares-store | 19:49:46 | 1 | 16.3 | `logs/B2-c1v2-mut-view-shares-store.log` |
| this session | B2-c1v2-mut-view-leave-keeps-copy | 19:50:03 | 1 | 18.1 | `logs/B2-c1v2-mut-view-leave-keeps-copy.log` |
| this session | B2-c1v2-mut-view-title-unmarked | 19:50:21 | 1 | 27.4 | `logs/B2-c1v2-mut-view-title-unmarked.log` |
| this session | B2-c1v2-mut-v200-cyc-title-html | 19:50:48 | 0 | 27.1 | `logs/B2-c1v2-mut-v200-cyc-title-html.log` |
| this session | S2-boot-same-base | 19:51:41 | 0 | 32.6 | `logs/S2-boot-same-base.log` |
| this session | S2-audit-base | 19:52:14 | 0 | 27.8 | `logs/S2-audit-base.log` |
| this session | I-r3-on-c1 | 19:52:14 | 0 | 41.9 | `logs/I-r3-on-c1.log` |
| this session | S2-audit-ppt-base | 19:52:42 | 0 | 15.3 | `logs/S2-audit-ppt-base.log` |
| this session | I-r3-on-base | 19:52:56 | 0 | 44.8 | `logs/I-r3-on-base.log` |
| this session | S2-audit-other-base | 19:52:57 | 0 | 88.0 | `logs/S2-audit-other-base.log` |
| this session | S2-audit-recon-base | 19:54:25 | 0 | 206.4 | `logs/S2-audit-recon-base.log` |
| this session | S2-legacy-fsrc-base | 19:57:51 | 0 | 9.1 | `logs/S2-legacy-fsrc-base.log` |
| this session | I-w3-on-c1 | 19:53:40 | 0 | 295.9 | `logs/I-w3-on-c1.log` |
| this session | S2-audit-hostile-base | 19:58:01 | 0 | 133.0 | `logs/S2-audit-hostile-base.log` |
| this session | S2-audit-inject-base | 20:00:14 | 0 | 26.7 | `logs/S2-audit-inject-base.log` |
| this session | S2-boot-same-c1v2 | 20:00:41 | 0 | 23.9 | `logs/S2-boot-same-c1v2.log` |
| this session | S2-audit-c1v2 | 20:01:05 | 0 | 26.7 | `logs/S2-audit-c1v2.log` |
| this session | S2-audit-ppt-c1v2 | 20:01:31 | 0 | 14.0 | `logs/S2-audit-ppt-c1v2.log` |
| this session | S2-audit-other-c1v2 | 20:01:45 | 0 | 68.9 | `logs/S2-audit-other-c1v2.log` |
| this session | N-check-base | 20:03:03 | 0 | 8.9 | `logs/N-check-base.log` |
| this session | N-check-c1v2 | 20:03:19 | 0 | 7.8 | `logs/N-check-c1v2.log` |
| this session | I-w3-on-base | 19:58:36 | 0 | 294.5 | `logs/I-w3-on-base.log` |
| this session | S2-audit-recon-c1v2 | 20:02:54 | 0 | 240.7 | `logs/S2-audit-recon-c1v2.log` |
| this session | S2-legacy-fsrc-c1v2 | 20:06:55 | 0 | 5.4 | `logs/S2-legacy-fsrc-c1v2.log` |
| this session | S2-audit-hostile-c1v2 | 20:07:01 | 0 | 101.3 | `logs/S2-audit-hostile-c1v2.log` |
| this session | S2-audit-inject-c1v2 | 20:08:42 | 0 | 19.4 | `logs/S2-audit-inject-c1v2.log` |
| this session | S2-audit-inject-c1v2-mut-v200-cyc-title-html | 20:09:18 | 1 | 27.1 | `logs/S2-audit-inject-c1v2-mut-v200-cyc-title-html.log` |
| this session | P3-evidence-on-base | 20:10:00 | 1 | 13.8 | `logs/P3-evidence-on-base.log` |
| this session | P3-evidence-on-c1 | 20:10:14 | 0 | 15.0 | `logs/P3-evidence-on-c1.log` |

Batch scripts: `mutruns.sh` (through `bx.sh`, 19:45:02–19:51:15 ET), `suites2.sh` (base 19:51:41–20:00:41 ET, c1
20:00:41–20:09:01 ET; each suite inside it through `run.sh`). The audit-import lock was absent at every check (`run.sh`
checks before each node run; none waited).

## PIDs (this session; the timeout PID and its child per run, in `pids.txt` with the full command)

pids.txt has the earlier attempt's 112 lines first, then this session's from the marker "resumed builder". This session:
153 rows. Nothing was killed by anyone in this session; every run ended by itself (no exit 124/137).

```
    24798 19:40:07 EDT timeout P2-side-on-base
    24800 19:40:07 EDT node P2-side-on-base
    24883 19:40:12 EDT timeout P2-side-on-c1
    24885 19:40:12 EDT node P2-side-on-c1
    27056 19:41:50 EDT gone bx:ins-block
    27058 19:41:50 EDT gone bx:ins-block
    27070 19:41:50 EDT timeout bx:ins-entries
    27075 19:41:50 EDT gone bx:ins-entries
    27252 19:41:55 EDT timeout bx:reapply1
    27255 19:41:55 EDT python3 bx:reapply1
    27263 19:41:55 EDT timeout bx:reapply2
    27266 19:41:55 EDT python3 bx:reapply2
    27522 19:42:05 EDT timeout bx:mcount-base
    27524 19:42:05 EDT python3 bx:mcount-base
    27546 19:42:07 EDT timeout bx:mcount-c1
    27548 19:42:07 EDT python3 bx:mcount-c1
    27827 19:42:27 EDT gone bx:mkfocused-c1v2
    27830 19:42:27 EDT gone bx:mkfocused-c1v2
    28005 19:42:42 EDT timeout bx:ins-block-2
    28008 19:42:42 EDT python3 bx:ins-block-2
    28016 19:42:43 EDT gone bx:mkfocused-c1v2b
    28019 19:42:43 EDT gone bx:mkfocused-c1v2b
    19:42:52 EDT NOTE: one 'node
    28163 19:43:02 EDT timeout F3-u10-on-c1
    28166 19:43:02 EDT node F3-u10-on-c1
    28431 19:43:26 EDT timeout F3-u10-on-base
    28434 19:43:27 EDT node F3-u10-on-base
    29219 19:44:09 EDT timeout bx:inregion
    29221 19:44:09 EDT python3 bx:inregion
    29493 19:44:22 EDT gone bx:mkfocused-board-c1v2
    29497 19:44:22 EDT gone bx:mkfocused-board-c1v2
    29509 19:44:22 EDT timeout bx:mkmut-v200-u10-reapply-year-only
    29511 19:44:22 EDT python3 bx:mkmut-v200-u10-reapply-year-only
    29521 19:44:22 EDT timeout bx:mkmut-v200-u10-reapply-keeps-list
    29523 19:44:22 EDT python3 bx:mkmut-v200-u10-reapply-keeps-list
    29546 19:44:22 EDT timeout bx:mkmut-v200-u10-reapply-keeps-years
    29548 19:44:22 EDT python3 bx:mkmut-v200-u10-reapply-keeps-years
    29558 19:44:22 EDT timeout bx:mkmut-v200-u10-reapply-keeps-pmos
    29561 19:44:23 EDT python3 bx:mkmut-v200-u10-reapply-keeps-pmos
    29570 19:44:23 EDT timeout bx:mkmut-v200-u10-reapply-first-year
    29572 19:44:23 EDT python3 bx:mkmut-v200-u10-reapply-first-year
    29582 19:44:23 EDT timeout bx:mkmut-v200-u10-reapply-older-keeps-list
    29584 19:44:23 EDT python3 bx:mkmut-v200-u10-reapply-older-keeps-list
    29594 19:44:23 EDT timeout bx:mkmut-view-refused-edit-stays
    29596 19:44:23 EDT python3 bx:mkmut-view-refused-edit-stays
    29606 19:44:23 EDT timeout bx:mkmut-view-shares-cycle-years
    29608 19:44:23 EDT python3 bx:mkmut-view-shares-cycle-years
    29618 19:44:23 EDT timeout bx:mkmut-view-shares-store
    29620 19:44:23 EDT python3 bx:mkmut-view-shares-store
    29630 19:44:24 EDT timeout bx:mkmut-view-leave-keeps-copy
    29632 19:44:24 EDT python3 bx:mkmut-view-leave-keeps-copy
    29642 19:44:24 EDT timeout bx:mkmut-view-title-unmarked
    29644 19:44:24 EDT python3 bx:mkmut-view-title-unmarked
    29654 19:44:24 EDT timeout bx:mkmut-v199-cyc-view-today
    29656 19:44:24 EDT python3 bx:mkmut-v199-cyc-view-today
    29673 19:44:24 EDT timeout bx:mkmut-v199-cyc-note-silent
    29676 19:44:24 EDT python3 bx:mkmut-v199-cyc-note-silent
    29686 19:44:24 EDT timeout bx:mkmut-v199-cyc-view-silent
    29688 19:44:24 EDT python3 bx:mkmut-v199-cyc-view-silent
    29699 19:44:25 EDT timeout bx:mkmut-v200-cyc-title-html
    29701 19:44:25 EDT python3 bx:mkmut-v200-cyc-title-html
    29829 19:44:31 EDT timeout B2-ppbe-on-c1
    29832 19:44:31 EDT node B2-ppbe-on-c1
    30290 19:44:42 EDT timeout B2-ppbe-on-base
    30293 19:44:42 EDT node B2-ppbe-on-base
    30647 19:45:02 EDT timeout bx:mutruns
    30655 19:45:02 EDT timeout F3-c1v2-mut-v200-u10-reapply-year-only
    30649 19:45:02 EDT mutruns.sh bx:mutruns
    30661 19:45:02 EDT node F3-c1v2-mut-v200-u10-reapply-year-only
    31071 19:45:26 EDT timeout F3-c1v2-mut-v200-u10-reapply-keeps-list
    31073 19:45:26 EDT node F3-c1v2-mut-v200-u10-reapply-keeps-list
    31589 19:45:49 EDT timeout F3-c1v2-mut-v200-u10-reapply-keeps-years
    31591 19:45:49 EDT node F3-c1v2-mut-v200-u10-reapply-keeps-years
    31960 19:46:07 EDT timeout F3-c1v2-mut-v200-u10-reapply-keeps-pmos
    31963 19:46:07 EDT node F3-c1v2-mut-v200-u10-reapply-keeps-pmos
    32673 19:46:29 EDT timeout F3-c1v2-mut-v200-u10-reapply-first-year
    32675 19:46:29 EDT node F3-c1v2-mut-v200-u10-reapply-first-year
    679 19:47:01 EDT timeout F3-c1v2-mut-v200-u10-reapply-older-keeps-list
    682 19:47:01 EDT node F3-c1v2-mut-v200-u10-reapply-older-keeps-list
    1008 19:47:34 EDT timeout F3-c1v2-mut-v199-cyc-view-today
    1010 19:47:34 EDT node F3-c1v2-mut-v199-cyc-view-today
    1530 19:48:01 EDT timeout F3-c1v2-mut-v199-cyc-note-silent
    1533 19:48:01 EDT node F3-c1v2-mut-v199-cyc-note-silent
    1784 19:48:30 EDT timeout F3-c1v2-mut-v199-cyc-view-silent
    1787 19:48:30 EDT node F3-c1v2-mut-v199-cyc-view-silent
    1957 19:48:54 EDT timeout F3-c1v2-mut-v200-cyc-title-html
    1959 19:48:54 EDT node F3-c1v2-mut-v200-cyc-title-html
    2174 19:49:18 EDT timeout B2-c1v2-mut-view-refused-edit-stays
    2177 19:49:18 EDT node B2-c1v2-mut-view-refused-edit-stays
    2586 19:49:32 EDT timeout B2-c1v2-mut-view-shares-cycle-years
    2588 19:49:32 EDT node B2-c1v2-mut-view-shares-cycle-years
    2995 19:49:46 EDT timeout B2-c1v2-mut-view-shares-store
    2997 19:49:46 EDT node B2-c1v2-mut-view-shares-store
    3721 19:50:03 EDT timeout B2-c1v2-mut-view-leave-keeps-copy
    3724 19:50:03 EDT node B2-c1v2-mut-view-leave-keeps-copy
    4541 19:50:21 EDT timeout B2-c1v2-mut-view-title-unmarked
    4543 19:50:21 EDT node B2-c1v2-mut-view-title-unmarked
    5804 19:50:48 EDT timeout B2-c1v2-mut-v200-cyc-title-html
    5806 19:50:49 EDT node B2-c1v2-mut-v200-cyc-title-html
    7104 19:51:41 EDT timeout S2-boot-same-base
    7112 19:51:41 EDT node S2-boot-same-base
    7280 19:51:51 EDT timeout bx:mkfocused-imp-w3
    7282 19:51:51 EDT python3 bx:mkfocused-imp-w3
    7331 19:51:55 EDT timeout bx:mkfocused-imp-r3
    7334 19:51:55 EDT python3 bx:mkfocused-imp-r3
    7575 19:52:14 EDT timeout S2-audit-base
    7546 19:52:14 EDT timeout I-r3-on-c1
    7577 19:52:14 EDT node S2-audit-base
    7549 19:52:14 EDT node I-r3-on-c1
    7918 19:52:42 EDT timeout S2-audit-ppt-base
    7920 19:52:42 EDT node S2-audit-ppt-base
    8085 19:52:56 EDT timeout I-r3-on-base
    8089 19:52:56 EDT node I-r3-on-base
    8122 19:52:57 EDT timeout S2-audit-other-base
    8124 19:52:57 EDT node S2-audit-other-base
    8500 19:53:40 EDT timeout I-w3-on-c1
    8501 19:53:41 EDT node I-w3-on-c1
    8963 19:54:25 EDT timeout S2-audit-recon-base
    8967 19:54:25 EDT node S2-audit-recon-base
    11671 19:57:52 EDT timeout S2-legacy-fsrc-base
    11674 19:57:52 EDT node S2-legacy-fsrc-base
    11831 19:58:01 EDT timeout S2-audit-hostile-base
    11833 19:58:01 EDT node S2-audit-hostile-base
    12208 19:58:36 EDT timeout I-w3-on-base
    12210 19:58:36 EDT node I-w3-on-base
    13914 20:00:14 EDT timeout S2-audit-inject-base
    13917 20:00:14 EDT node S2-audit-inject-base
    14344 20:00:41 EDT timeout S2-boot-same-c1v2
    14346 20:00:41 EDT node S2-boot-same-c1v2
    14680 20:01:05 EDT timeout S2-audit-c1v2
    14682 20:01:05 EDT node S2-audit-c1v2
    15278 20:01:31 EDT timeout S2-audit-ppt-c1v2
    15281 20:01:32 EDT node S2-audit-ppt-c1v2
    15530 20:01:46 EDT timeout S2-audit-other-c1v2
    15533 20:01:46 EDT node S2-audit-other-c1v2
    16703 20:02:54 EDT timeout S2-audit-recon-c1v2
    16706 20:02:55 EDT node S2-audit-recon-c1v2
    16800 20:03:04 EDT timeout N-check-base
    16802 20:03:04 EDT npm N-check-base
    17001 20:03:19 EDT timeout N-check-c1v2
    17003 20:03:19 EDT npm run
    19808 20:06:55 EDT timeout S2-legacy-fsrc-c1v2
    19811 20:06:55 EDT node S2-legacy-fsrc-c1v2
    19912 20:07:01 EDT timeout S2-audit-hostile-c1v2
    19914 20:07:01 EDT node S2-audit-hostile-c1v2
    22837 20:08:42 EDT timeout S2-audit-inject-c1v2
    22839 20:08:42 EDT node S2-audit-inject-c1v2
    23823 20:09:18 EDT timeout S2-audit-inject-c1v2-mut-v200-cyc-title-html
    23826 20:09:18 EDT node S2-audit-inject-c1v2-mut-v200-cyc-title-html
    24831 20:10:00 EDT timeout P3-evidence-on-base
    24833 20:10:00 EDT node P3-evidence-on-base
    25271 20:10:14 EDT timeout P3-evidence-on-c1
    25274 20:10:14 EDT node P3-evidence-on-c1
```

## Plainly not done

- Not run: the full audit-import and audit-board (the lead's), the mutate.mjs sweep (never imported or run), the
  full-suite sensitivity of the new mutations (final-tree queue), verify:grid and Chromium (no layout or UI change).
- Not read by the block: the forecast-view export, the PMO Matrix and PowerPoint (no RCN / EEIC; offices are read in the
  workbook, the Spend Plan Source and the ACE tie-out).
- Not fixed: side-list edits in a view (E above; drafted as a new ledger row). Not tested in the suite: the band ladder and
  funds-flow settings in a view (measured by the side probe only).
- Not wrapped: short read-only shell and text commands (cat, grep, diff, sed, ls, cp, ln, git hash-object, several
  `python3 -I` text scans and tallies) ran directly, not through `setsid -w timeout`; one `node --check` (syntax only) of
  c1's audit-recon ran directly at about 7:42 PM ET (noted in pids.txt). Every other node run went through `run.sh`.
- No merge check against the other L6 tracks: their board changes (u9, u19, u20u30) touch other lines (none in
  20120–20215); cycreg had no diff yet when looked at, between 7:31 and 7:40 PM ET.

## Drafts for the lead

- `drafts/NEXT-VERSION-U10.md`: the v2.00 entry (after U14) and the replacement for U10's line under "Unresolved after R1–R5".
- `drafts/LEDGER-U10.md`: the text to append to row U10 (`<sha>`, `<time>` placeholders) and a new row for finding E.

## The suite diff (audit-recon, +189 −0)

```diff
--- a/tools/export-audit/audit-recon.mjs
+++ b/tools/export-audit/audit-recon.mjs
@@ -5123,6 +5123,195 @@
   await settleBoards();
 })();
 // ==== end v2.00 (U14) ====
+// ==== v2.00 (U10): a refused edit in a locked cycle's view changes no code any export carries ====
+// The review of main (Codex), as Brad supplied it on 11 Oct: lock PB27 with RCN / EEIC 11111 / AAAAA, move the working codes on,
+// view PB27 and type 77777 in the enabled RCN field. Save said "the change was not kept", and RCN-EEIC by Month then exported
+// PB27's dollars under 77777 / AAAAA, labelled LOCKED VIEW: a refused write put back the year on screen and nothing beside it.
+// On v1.98 item 83's board (K1-K4, P's two CLINs, the ACE set), with a second held year (FY28, a copy of FY27) and an office ZED
+// holding Q. PB27 is locked; the working list then moves on as v1.99 item 88's does (K1 renumbered 99999 / ZZZZZ, K3 removed).
+// Each edit is made through the control the board renders for it -- the RCN / EEIC panel's three fields, its ✕ (answered OK),
+// its + Add and a service box, and Setup › PMOs' ✎ (answered WRK) -- from a fresh view of PB27. After each, every export that
+// carries a code is read from its bytes: RCN-EEIC by Month (summary, requirements, prime contracts), the Spend Plan Source
+// (amount, CLIN, EEIC, RCN, PMO), the ACE tie-out (alignment breakout and mapping, FY27 and FY28) and the whole workbook (no
+// cell names a code the cycle does not hold; the office ZED is everywhere it was). Every expected code and figure is the
+// cycle's own, typed here: item 83's table. The record's own steps (saved, reopened, viewed, 77777 typed) are checked as well,
+// and so is a cycle locked before v1.99, which kept no list: its view reads today's list (item 88), and a refusal leaves it so.
+// FAILS ON 7ee498a (board fce8a391, U14's): each edit stays on the view's copy -- 77777, YYYYY and "Renamed" in every export
+// that prints the code; K3 removed, so CLIN 0001's AFRC $31 is on no combination in FY27 and falls to K1 in FY28; ZED renamed,
+// so Q's $71 is filed under AV; the older cycle's RCN-EEIC tab prints 77777 / ZZZZZ. CONTROLS: an edit to the year's own
+// assignments (put back before as well), the cycle store and browser storage byte for byte, leaving the view, and an allowed
+// edit on the working plan, which every export carries.
+await (async () => {
+  const name = 'v2.00 (U10) — a refused edit in a locked cycle’s view changes no code any export carries';
+  const { bootMark, bootRelease, settleBoards } = await import('./boot.mjs');
+  const __bm = bootMark();
+  try {
+    const J = JSON.stringify;
+    const ST = `S.rcnAsg={PRIME_P:'K4', R:'K1'}; S.rcnSvc={PRIME_P:{ANG:'K2'}, R:{ANG:'K2'}};
+      S.clinRcn={PRIME_P:{n1:'K1'}}; S.clinRcnSvc={PRIME_P:{n1:{AFRC:'K3'}}};
+      S.wbs={R:[{w:'2.2', v:[]}]}; S.aceMap={PRIME_P:{w:['1.1'], ok:true}, R:{w:['2.2'], ok:true}};
+      ACEDB.sets={'2027ACE':{lines:[{ap:mySlug(), pmo:'AV', wbs:'1.1', v:{}}, {ap:mySlug(), pmo:'AV', wbs:'2.2', v:{}}]}};
+      ACEDB.sets['2027ACE'].lines[0].v[MS.cur]=900; ACEDB.sets['2027ACE'].lines[1].v[MS.cur]=600; aceYr='all';
+      MS.pmos=GROUPS.concat(['ZED']); S.grp={Q:'ZED'};`;
+    const X = v198Board(ST);
+    const ev = c => { try { return X.ev(c); } catch (e) { return 'threw: ' + String((e && e.message) || e).slice(0, 100); } };
+    const key = ev(`window.confirm=function(){ return true; }; window.prompt=function(){ return 'WRK'; };
+      MS.base=MS.cur; MS.years[MS.cur]=S; MS.years[MS.cur+1]=JSON.parse(JSON.stringify(S)); save();
+      blCyc='PB'; blYr=MS.cur; cycLock(); blKey('PB', MS.cur)`);
+    w5Chk(name, 'fixture', 'CONTROL — PB27 is locked, holding FY27 and FY28, with the list K1-K4; Q is in ZED',
+      J([key, ev(`JSON.stringify([!!(blGet('PB|2027')||{}).locked, Object.keys((blGet('PB|2027')||{}).years||{})])`), ev(`GROUPS.indexOf('ZED')>=0`), ev(`grpOf(itemById('Q'))`)]),
+      J(['PB|2027', '[true,["2027","2028"]]', true, 'ZED']));
+    // the working list moves on after the lock (item 88's own change)
+    ev(`(function(){ var L=rcnReg(), i=L.findIndex(function(e){ return e.k==='K1'; }); rcnSet(i,'rcn','99999'); rcnSet(i,'eeic','ZZZZZ');
+      rcnDel(rcnReg().findIndex(function(e){ return e.k==='K3'; })); })(); 'ok'`);
+    const reg = () => JSON.parse(ev(`JSON.stringify(rcnReg().map(function(e){ return [e.rcn, e.eeic, e.t, (e.svc||[]).join('+')]; }))`));
+    w5Chk(name, 'fixture', 'CONTROL — the working list is now 99999 / ZZZZZ, 22222 / BBBBB, 44444 / DDDDD',
+      J(reg()), J([['99999', 'ZZZZZ', '', 'USAF+ANG+AFRC'], ['22222', 'BBBBB', '', 'ANG'], ['44444', 'DDDDD', '', 'USAF+ANG+AFRC']]));
+    const cyc0 = ev('JSON.stringify(CYCDB)'), ls0 = ev('localStorage.getItem(_AP.key)');
+    // the panel as drawn on screen: each combination's RCN | EEIC | title | USAF ANG AFRC boxes
+    const panel = () => JSON.parse(ev(`JSON.stringify([].slice.call(document.querySelectorAll('#rcnBody tr')).slice(1).map(function(tr){
+      return [].slice.call(tr.querySelectorAll('input')).map(function(i){ return i.type==='checkbox'? (i.checked?'x':'-') : i.value; }).join('|'); }))`));
+    // a control the panel renders for one combination: its field (typed, change fired), a service box, its ✕, or + Add
+    const fire = (k, kind, value) => ev(`(function(){ if(!rcnOpen) toggleRcn(); var i=rcnReg().findIndex(function(e){ return e.k===${J(k)}; });
+      var els=[].slice.call(document.querySelectorAll('#rcnBody input, #rcnBody button')), on=function(e, a){ return e.getAttribute(a)||''; }, el=null;
+      if(${J(kind)}==='add') el=els.filter(function(e){ return /^rcnAdd\\(/.test(on(e, 'onclick')); })[0];
+      else if(${J(kind)}==='del') el=els.filter(function(e){ return on(e, 'onclick')==='rcnDel('+i+')'; })[0];
+      else if(${J(kind)}==='svc') el=els.filter(function(e){ return on(e, 'onchange').indexOf('rcnToggleSvc('+i+',')===0 && on(e, 'onchange').indexOf(${J(value)})>0; })[0];
+      else el=els.filter(function(e){ return on(e, 'onchange').indexOf('rcnSet('+i+',"'+${J(kind)}+'"')===0; })[0];
+      if(!el) return 'no control';
+      if(${J(kind)}==='add' || ${J(kind)}==='del') el.click();
+      else if(${J(kind)}==='svc'){ el.checked=!el.checked; el.dispatchEvent(new Event('change', {bubbles:true})); }
+      else { el.value=${J(value)}; el.dispatchEvent(new Event('change', {bubbles:true})); }
+      return 'fired'; })()`);
+    const notKept = () => /the change was not kept|Not kept/.test(ev(`(document.getElementById('shareStat')||{}).textContent||''`));
+    // every export that carries a code, read from its bytes
+    const exportsOf = async W => {
+      const bk = JSON.parse(await w6Book(W, 'exportExcel')), rc = bk['RCN-EEIC by Month'] || [];
+      const iReq = rc.findIndex(r => w6Lbl(r) === 'WHICH REQUIREMENTS SIT UNDER EACH COMBINATION'), iPr = rc.findIndex(r => w6Lbl(r) === 'PRIME CONTRACTS, BROKEN OUT BY CLIN');
+      const cells = []; Object.keys(bk).filter(k => !k.startsWith('__')).forEach(sh => (bk[sh] || []).forEach(r => (r || []).forEach(c => cells.push(String(c ?? '').trim()))));
+      const sb = JSON.parse(await w6Book(W, 'exportSrc')), src = (Object.values(sb).find(rs => (rs || []).length > 1) || []).slice(1);
+      const ab = JSON.parse(await w6Book(W, 'exportAceTieout'));
+      const al = ab['Alignment Breakout'] || [], ah = headerRow(al, 'FY', 'PMO', 'Line total');
+      const mp = ab['Mapping by Requirement'] || [], mh = headerRow(mp, 'FY', 'PMO', 'Board funded');
+      return {
+        files: [bk.__err || 'ok', sb.__err || 'ok', ab.__err || 'ok'],
+        summary: v198Sec(rc, 0, iReq).map(r => r.slice(0, 3)), requirements: v198Sec(rc, iReq, iPr), primes: v198Sec(rc, iPr, rc.length).map(r => r.slice(0, 3)),
+        source: src.map(r => [num(r[9]), String(r[25] ?? ''), String(r[26] ?? ''), String(r[27] ?? ''), String(r[18] ?? '')]).sort((a, b) => a[0] - b[0]),
+        alignment: al.slice(ah + 1).filter(r => /^FY\d\d$/.test(w6Lbl(r))).map(r => [w6Lbl(r), String(r[2]), String(r[3] ?? ''), num(r[5]), String(r[colOf(al, ah, 'RCN')] ?? ''), String(r[colOf(al, ah, 'EEIC')] ?? '')]),
+        mapping: mp.slice(mh + 1).filter(r => /^FY\d\d$/.test(w6Lbl(r))).map(r => [w6Lbl(r), String(r[colOf(mp, mh, 'PMO')] ?? ''), String(r[colOf(mp, mh, 'Requirement (CCaR Record Name)')]), String(r[colOf(mp, mh, 'RCN')] ?? ''), String(r[colOf(mp, mh, 'EEIC')] ?? '')]),
+        workbook: [cells.filter(t => /77777|YYYYY|99999|ZZZZZ|Renamed|WRK/.test(t)).length, 'PMO ZED' in bk, cells.filter(t => t === 'ZED').length] };
+    };
+    const exportsNow = () => exportsOf(X.w);
+    const L = v198Lab, N = v198NONE;
+    // THE CYCLE'S OWN CODES, as item 83's table has them; ZED holds Q; no cell names a code PB27 does not hold
+    const ALIGN = fy => [[fy, 'Req PRIME_P', '0001', 652, '11111', 'AAAAA'], [fy, 'Req PRIME_P', '0001', 31, '33333', 'CCCCC'], [fy, 'Req PRIME_P', '0001', 41, '', ''],
+      [fy, 'Req PRIME_P', '0002', 358, '44444', 'DDDDD'], [fy, 'Req R', '', 503, '11111', 'AAAAA'], [fy, 'Req R', '', 127, '22222', 'BBBBB'], [fy, 'Req Q', '', 71, '', '']];
+    const MAP = fy => [[fy, 'AV', 'Req PRIME_P', '(3 combinations)', '(see breakout)'], [fy, 'AV', 'Req R', '(2 combinations)', '(see breakout)'], [fy, 'ZED', 'Req Q', '', '']];
+    const LOCKED = { files: ['ok', 'ok', 'ok'],
+      summary: [['USAF', L('K1'), 904], ['USAF', L('K4'), 299], ['USAF', N, 71], ['USAF', 'USAF TOTAL', 1274], ['ANG', L('K1'), 251], ['ANG', L('K2'), 127], ['ANG', 'ANG TOTAL', 378],
+        ['AFRC', L('K3'), 31], ['AFRC', L('K4'), 59], ['AFRC', 'AFRC TOTAL', 90]],
+      requirements: [['USAF', L('K1') + '   (2 requirements)', 904, null], ['USAF', '#1  Req PRIME_P ⚠', 401, 401], ['USAF', '#2  Req R', 503, 503],
+        ['USAF', L('K4') + '   (1 requirement)', 299, null], ['USAF', '#1  Req PRIME_P ⚠', 299, 299],
+        ['USAF', N + '   — 1 requirement still to assign', 71, null], ['USAF', '#3  Req Q', 71, 71], ['USAF', 'USAF TOTAL', 1274, null],
+        ['ANG', L('K1') + '   (1 requirement)', 251, null], ['ANG', '#1  Req PRIME_P', 251, 251],
+        ['ANG', L('K2') + '   (1 requirement)', 127, null], ['ANG', '#2  Req R', 127, 127], ['ANG', 'ANG TOTAL', 378, null],
+        ['AFRC', L('K3') + '   (1 requirement)', 31, null], ['AFRC', '#1  Req PRIME_P ⚠', 31, 31],
+        ['AFRC', L('K4') + '   (1 requirement)', 59, null], ['AFRC', '#1  Req PRIME_P ⚠', 59, 59], ['AFRC', 'AFRC TOTAL', 90, null]],
+      primes: [['USAF', 'Req PRIME_P   (2 CLINs funded)', 700], ['USAF', 'CLIN 0001   ' + L('K1'), 401], ['USAF', 'CLIN 0002   ' + L('K4'), 299], ['USAF', 'USAF — PRIMES TOTAL', 700],
+        ['ANG', 'Req PRIME_P   (1 CLIN funded)', 251], ['ANG', 'CLIN 0001   ' + L('K1'), 251], ['ANG', 'ANG — PRIMES TOTAL', 251],
+        ['AFRC', 'Req PRIME_P   (2 CLINs funded)', 90], ['AFRC', 'CLIN 0001   ' + L('K3'), 31], ['AFRC', 'CLIN 0002   ' + L('K4'), 59], ['AFRC', 'AFRC — PRIMES TOTAL', 90]],
+      source: [[31, '0001', 'CCCCC', '33333', 'AV'], [41, '0001', '', '', 'AV'], [59, '0002', 'DDDDD', '44444', 'AV'], [71, '', '', '', 'ZED'], [127, '', 'BBBBB', '22222', 'AV'],
+        [251, '0001', 'AAAAA', '11111', 'AV'], [299, '0002', 'DDDDD', '44444', 'AV'], [401, '0001', 'AAAAA', '11111', 'AV'], [503, '', 'AAAAA', '11111', 'AV']],
+      alignment: ALIGN('FY27').concat(ALIGN('FY28')), mapping: MAP('FY27').concat(MAP('FY28')), workbook: [0, true, 8] };
+    const LIST = [['11111', 'AAAAA', '', 'USAF+ANG+AFRC'], ['22222', 'BBBBB', '', 'ANG'], ['33333', 'CCCCC', '', 'AFRC'], ['44444', 'DDDDD', '', 'USAF+ANG+AFRC']];
+    const PANEL = ['11111|AAAAA||x|x|x', '22222|BBBBB||-|x|-', '33333|CCCCC||-|-|x', '44444|DDDDD||x|x|x'];
+    const view = () => ev(`cycView(${J(key)}); 'ok'`), leave = () => ev(`if(rcnOpen) toggleRcn(); if(pmoOpen) togglePmo(); cycLeave(); 'ok'`);
+    // ---- CONTROL: PB27 viewed, nothing typed
+    view();
+    w5Chk(name, 'PB27 viewed, nothing typed', 'CONTROL — every export carries the cycle’s own codes', J(await exportsNow()), J(LOCKED));
+    leave();
+    // ---- EACH EDIT THE RCN / EEIC PANEL OFFERS, refused. `exp`: the exports differed on 7ee498a (a combination with no money,
+    // and the services a combination is set up for, are printed by no export: those two are CONTROLs there)
+    const EDITS = [['RCN 77777 typed into K1’s field', () => fire('K1', 'rcn', '77777'), true], ['EEIC YYYYY typed into K1’s field', () => fire('K1', 'eeic', 'YYYYY'), true],
+      ['title “Renamed” typed into K4’s field', () => fire('K4', 't', 'Renamed'), true], ['K3 removed with its ✕, answered OK', () => fire('K3', 'del'), true],
+      ['+ Add RCN / EEIC', () => fire('K1', 'add'), false], ['K1’s ANG box switched off', () => fire('K1', 'svc', 'ANG'), false]];
+    for (const [what, act, exp] of EDITS) {
+      view(); const fired = act();
+      w5Chk(name, 'PB27 viewed · ' + what, 'refused and said so; the list in the view, and the panel redrawn on screen, are the cycle’s: K1-K4 as locked',
+        J([fired, notKept(), reg(), panel()]), J(['fired', true, LIST, PANEL]));
+      w5Chk(name, 'PB27 viewed · ' + what, (exp ? '' : 'CONTROL — ') + 'every export carries the cycle’s own codes, as before the edit', J(await exportsNow()), J(LOCKED));
+      leave();
+    }
+    // ---- ANOTHER YEAR THE CYCLE HOLDS: K3's ✕ clears its pointers in every year; refused on FY27, FY28 is read next
+    view(); fire('K3', 'del'); ev(`if(rcnOpen) toggleRcn(); switchYear(MS.cur+1); 'ok'`);
+    w5Chk(name, 'PB27 viewed · K3 removed on FY27, then FY28 on screen', 'FY28 still holds CLIN 0001’s AFRC on K3, and the list is the cycle’s',
+      J([ev('MS.cur'), ev(`JSON.stringify(S.clinRcnSvc)`), reg()]), J([2028, J({ PRIME_P: { n1: { AFRC: 'K3' } } }), LIST]));
+    w5Chk(name, 'PB27 viewed · K3 removed on FY27, then FY28 on screen', 'every export of FY28 carries the cycle’s own codes', J(await exportsNow()), J(LOCKED));
+    leave();
+    // ---- A REFUSAL WHILE FY28 IS ON SCREEN puts the copy back on FY28, not on the year the view opened on
+    view(); ev(`switchYear(MS.cur+1); 'ok'`); const f28 = fire('K1', 'rcn', '77777');
+    w5Chk(name, 'PB27 viewed · FY28 on screen, RCN 77777 typed into K1’s field', 'refused; still FY28, on FY28’s months; the list and the panel are the cycle’s',
+      J([f28, notKept(), ev('MS.cur'), ev('FYMON[0][0]'), reg(), panel()]), J(['fired', true, 2028, '2027-10', LIST, PANEL]));
+    w5Chk(name, 'PB27 viewed · FY28 on screen, RCN 77777 typed into K1’s field', 'every export of FY28 carries the cycle’s own codes', J(await exportsNow()), J(LOCKED));
+    leave();
+    // ---- THE PMO LIST: ZED renamed WRK with its ✎, refused (the rename moves every year's offices first)
+    view();
+    const fz = ev(`(function(){ if(!pmoOpen) togglePmo(); var b=[].slice.call(document.querySelectorAll('#pmoList button')).filter(function(e){
+      return (e.getAttribute('onclick')||'')==='pmoRename('+GROUPS.indexOf('ZED')+')'; })[0]; if(!b) return 'no control'; b.click(); return 'fired'; })()`);
+    w5Chk(name, 'PB27 viewed · ZED renamed WRK with its ✎', 'refused and said so; the list on screen still ends ZED; Q is in ZED in FY27 and FY28',
+      J([fz, notKept(), ev(`[].slice.call(document.querySelectorAll('#pmoList .fr > div > b')).map(function(b){ return b.textContent; }).join(',')`), ev(`grpOf(itemById('Q'))`), ev(`JSON.stringify(MS.years[MS.cur+1].grp)`)]),
+      J(['fired', true, 'ATL,PSM,PP,AV,MxS,CDS,TSS,BOP,ZED', 'ZED', J({ Q: 'ZED' })]));
+    w5Chk(name, 'PB27 viewed · ZED renamed WRK with its ✎', 'every export carries the cycle’s own offices and codes: Q’s $71 under ZED', J(await exportsNow()), J(LOCKED));
+    leave();
+    // ---- CONTROL: an edit to the year's own assignments, refused (the year was put back before this version too)
+    view(); ev(`setRcnAsg('Q','K2'); 'ok'`);
+    w5Chk(name, 'PB27 viewed · Q given K2 (the year’s own assignment)', 'CONTROL — refused, and every export carries the cycle’s own codes',
+      J([notKept(), await exportsNow()]), J([true, LOCKED]));
+    leave();
+    // ---- CONTROL: nothing durable moved, and leaving the view gives back the working plan
+    w5Chk(name, 'after every refusal, the view left', 'CONTROL — the cycle store and browser storage are byte for byte as they were; the working list, ZED and Q are the working plan’s',
+      J([ev('JSON.stringify(CYCDB)') === cyc0, ev('localStorage.getItem(_AP.key)') === ls0, ev('CYCVIEW'), reg(), ev(`GROUPS.join(',')`), ev(`grpOf(itemById('Q'))`)]),
+      J([true, true, '', [['99999', 'ZZZZZ', '', 'USAF+ANG+AFRC'], ['22222', 'BBBBB', '', 'ANG'], ['44444', 'DDDDD', '', 'USAF+ANG+AFRC']], 'ATL,PSM,PP,AV,MxS,CDS,TSS,BOP,ZED', 'ZED']));
+    // ---- THE RECORD'S OWN STEPS: the board saved and reopened, PB27 viewed, 77777 typed into the RCN field, Excel exported
+    const R = boot({ html: ev('buildSavedHtml()') });
+    const rv = (() => { try { return R.ev(`cycView(${J(key)}); (function(){ if(!rcnOpen) toggleRcn(); var el=[].slice.call(document.querySelectorAll('#rcnBody input')).filter(function(e){
+      return (e.getAttribute('onchange')||'').indexOf('rcnSet(0,"rcn"')===0; })[0]; if(!el) return 'no control'; el.value='77777'; el.dispatchEvent(new Event('change', {bubbles:true}));
+      return 'fired'; })()`); } catch (e) { return 'threw'; } })();
+    const rx = await exportsOf(R.w);
+    w5Chk(name, 'the record’s steps: saved, reopened, PB27 viewed, 77777 typed', 'refused; RCN-EEIC by Month, the Spend Plan Source and the ACE tie-out (on its own year, FY27, as a reopened board shows it) carry the cycle’s own codes; no cell names 77777',
+      J([rv, /the change was not kept|Not kept/.test(R.ev(`(document.getElementById('shareStat')||{}).textContent||''`)), rx]),
+      J(['fired', true, Object.assign({}, LOCKED, { alignment: ALIGN('FY27'), mapping: MAP('FY27') })]));
+    // ---- CONTROL: the working plan, no view -- an edit is allowed, and every export carries it
+    fire('K4', 'rcn', '55555'); ev(`if(rcnOpen) toggleRcn(); 'ok'`);
+    const w = await exportsNow(), WK = '99999 / ZZZZZ', W5 = '55555 / DDDDD';
+    const WALIGN = fy => [[fy, 'Req PRIME_P', '0001', 724, '99999', 'ZZZZZ'], [fy, 'Req PRIME_P', '0002', 358, '55555', 'DDDDD'], [fy, 'Req R', '', 503, '99999', 'ZZZZZ'],
+      [fy, 'Req R', '', 127, '22222', 'BBBBB'], [fy, 'Req Q', '', 71, '', '']];
+    w5Chk(name, 'the working plan · K4 renumbered 55555 (allowed)', 'CONTROL — every export carries 55555 / DDDDD, and the working list (K3 removed: CLIN 0001’s AFRC on its standard, K1)',
+      J([w.files, w.summary, w.primes, w.source, w.alignment]),
+      J([['ok', 'ok', 'ok'], [['USAF', WK, 904], ['USAF', W5, 299], ['USAF', N, 71], ['USAF', 'USAF TOTAL', 1274], ['ANG', WK, 251], ['ANG', L('K2'), 127], ['ANG', 'ANG TOTAL', 378],
+        ['AFRC', WK, 31], ['AFRC', W5, 59], ['AFRC', 'AFRC TOTAL', 90]],
+        [['USAF', 'Req PRIME_P   (2 CLINs funded)', 700], ['USAF', 'CLIN 0001   ' + WK, 401], ['USAF', 'CLIN 0002   ' + W5, 299], ['USAF', 'USAF — PRIMES TOTAL', 700],
+          ['ANG', 'Req PRIME_P   (1 CLIN funded)', 251], ['ANG', 'CLIN 0001   ' + WK, 251], ['ANG', 'ANG — PRIMES TOTAL', 251],
+          ['AFRC', 'Req PRIME_P   (2 CLINs funded)', 90], ['AFRC', 'CLIN 0001   ' + WK, 31], ['AFRC', 'CLIN 0002   ' + W5, 59], ['AFRC', 'AFRC — PRIMES TOTAL', 90]],
+        [[31, '0001', 'ZZZZZ', '99999', 'AV'], [41, '0001', '', '', 'AV'], [59, '0002', 'DDDDD', '55555', 'AV'], [71, '', '', '', 'ZED'], [127, '', 'BBBBB', '22222', 'AV'],
+          [251, '0001', 'ZZZZZ', '99999', 'AV'], [299, '0002', 'DDDDD', '55555', 'AV'], [401, '0001', 'ZZZZZ', '99999', 'AV'], [503, '', 'ZZZZZ', '99999', 'AV']],
+        WALIGN('FY27').concat(WALIGN('FY28'))]));
+    // ---- A CYCLE LOCKED BEFORE v1.99 kept no list (item 88's own reading of one: the lock's list taken away), so its view reads
+    // today's -- 99999 / ZZZZZ, 22222 / BBBBB, 55555 / DDDDD. 77777 typed into K1's field there is refused like any other.
+    ev(`delete blGet(${J(key)}).rcn; 'ok'`);
+    view(); const fo = fire('K1', 'rcn', '77777'), o = await exportsNow();
+    w5Chk(name, 'a cycle locked before v1.99, viewed · RCN 77777 typed into K1’s field', 'refused; the view’s list and RCN-EEIC by Month are today’s list as it is',
+      J([fo, notKept(), reg(), o.summary.filter(r => r[0] === 'USAF').map(r => r[1])]),
+      J(['fired', true, [['99999', 'ZZZZZ', '', 'USAF+ANG+AFRC'], ['22222', 'BBBBB', '', 'ANG'], ['55555', 'DDDDD', '', 'USAF+ANG+AFRC']], [WK, W5, N, 'USAF TOTAL']]));
+    leave();
+    w5Chk(name, 'harness', 'CONTROL — no jsdom script errors on either board', J([X.errors.length, R.errors.length]), J([0, 0]));
+  } catch (e) {
+    failures.push({ scenario: name, where: 'harness', what: 'the block threw: ' + String((e && e.message) || e).slice(0, 160), got: 'threw', want: 'ran' });
+  }
+  bootRelease(__bm, []);
+  await settleBoards();
+})();
+// ==== end v2.00 (U10) ====
 
 {
   const src = _selfRead(_selfPath(import.meta.url), 'utf8');
```

---

# Fix round (13 Oct 2026, from 9:13 AM ET) — the round-1 reviews' must-fixes, closed

> **Superseded in part by "Fix round 2" (at the end of this file, from 1:41 PM ET):** the commit list is now four commits; the drafts named here are replaced by `drafts/*-fix2.md`; the finding "the refused-but-kept doors are exactly the seven now gated" is withdrawn (a wider scan found more); "07:34–11:37 past 10 AM ET" should read 10:07:34–10:11:37 AM ET. Everything below is kept as it was.

Started 9:13 AM ET on 13 Oct, after the container restart at 9:11 AM ET. **Nothing was kept from a stopped attempt of this round:
there was none.** The directory showed no fix-round work after the build (no copy changed since the builder's recorded blobs —
c1 is still board `4a8b0be3`, audit-recon `47c8520a`, mutate `d245868c` — no new probes, logs or diffs dated after the build,
no "Fix round" section). The only later files were the two reviewers' directories (`verify-money-r1/`, `verify-tests-r1/`)
and `wfstate/`. Everything above this section is the build as it was; **what this round supersedes is marked here, not
edited there.**

## What the reviews found, and what this round did

| review | finding | done |
|---|---|---|
| money MF1 | Importing a cost estimate or a BAE list in a locked view is refused ("🔒 Not kept") yet stored: an approved estimate replaced, ACE tie-out and FYDP Spend Plan $900 → $4,321,000, BAE budget names in the Spend Plan Source — in the view and on the working plan | **Fixed (commit 2):** `importAce` and `importBud` refuse up front in a view (`cycBlock`, as `svcSaveList` does). Tested cell by cell, with working-plan controls. |
| money MF2 | Destination-list edits in a view are refused yet kept; a ✕ asks a false question and loses the working plan's pointer | **Fixed (commit 2):** `flowSetEnt`, `flowAddEnt`, `flowDelEnt`, `flowResetEnts` refuse up front in a view, and redraw. Tested through the panel's own controls. |
| money MF3 | The drafts' words were false ("changes no code any export carries", "browser storage never changed", the new ledger row) | **Fixed:** new drafts `drafts/NEXT-VERSION-U10-fix.md`, `drafts/LEDGER-U10-fix.md`; the builder's drafts are superseded (kept). The drafted ledger row is withdrawn. |
| money SF1 / tests MF3 | No test held the band ladder, the funds-flow settings or the CCaR index; four plausible wrong fixes survived everything | **Fixed (commit 1):** the test reviewer's proposal block adopted (renamed in house style, checks unchanged) and its entries `-wrong-year`, `-keeps-plan-settings`, `-working-base`. `-keeps-ccar-index` **not** adopted: commit 2 makes it equivalent (below). |
| money SF2 | A locked cycle keeps no PMO list | **Ledger row drafted** (pre-existing; a design decision like item 88). |
| money SF3 | Edits a view allows (QPE import, reprogramming rows) are kept while the banner says nothing is kept | **Ledger row drafted**, with a case this round measured: deleting another cycle in a view (below). |
| tests MF1 | Two status-line checks read the line after three exports (the "Not kept" mark lasts 1.5 s): timing-dependent | **Fixed (commit 1):** read at once, the reviewer's exact fix. No expectation changed. |
| tests MF2 | The held-year checks could not tell FY28 from FY27 | **Fixed (commit 1):** the FY28-differs case (in the adopted block) and `-wrong-year`. |
| tests SF | `vt-inline-no-base` survived | **Fixed (commit 1):** the base-year control and `-working-base`. |
| tests SF | The builder's findings/draft said CCaR records were year state; they are in `MS.ccarIdx` | **Corrected** in the drafts and here. |
| tests SF | After a refused CCaR import the status line counted titles and said "Save to bake" | **Fixed (commit 2):** `importCcarRecs` refuses up front in a view. Tested (the status line, literal). |
| tests SF | One NEXT-VERSION sentence contradicted the ledger row | **Fixed** in the new draft. |

## The commits now proposed (CURRENT list)

Copies are cumulative: `c1r/` = base `7ee498a` + commit 1 (revised); `c2/` = `c1r/` + commit 2. The builder's `c1/` is kept
untouched as the record of the superseded commit 1 (its blobs above). Diffs: `diffs/c1r-vs-base.*`, `diffs/c2-vs-c1r.*`,
`diffs/c2-vs-base.*`, and `diffs/c1r-vs-c1.*` (what the revision changed in commit 1).

1. **`v2.00 (U10 1 of 2): a refusal in a locked cycle's view puts back the whole view, not the year alone`** — copy `c1r/`:
   board `4a8b0be32608ac9b44cf301b7381a359a9e19111` (unchanged from the build), audit-recon
   `746dac8360b68b287a7f1050e90f66de124a43af`, mutate (as `tools/export-audit/mutate.mjs`)
   `c6c1ea476a0ab7f5f08cd27c3bc276bc23dccf85`. Board +22 −10, audit-recon +283 −0, mutate +31 −0 against the base.
2. **`v2.00 (U10 2 of 2): a cost estimate, a BAE list, CCaR records or a destination change is refused in a locked view
   before anything is kept`** — copy `c2/`: board `cfc9e14f369653212d9faa6d56b3d602b9210c03`, audit-recon
   `2c4c466a94f4de49b0df59ef1bdead7d58ba983d`, mutate `3a408399940436295efcd1691d1eb0368986456c`. Against c1r: board +17 −0,
   audit-recon +149 −3, mutate +26 −0.

Unchanged in both: audit-import `4aba2506`, audit-board `a7c575e5`, audit-other `d89396b0`, boot.mjs `9c4f49ad`,
package.json `7cf8186f`, NEXT-VERSION.md `65265c13`.

**Why two commits, and why commit 1 is revised rather than kept:** the test review rated commit 1 unsound (two timing-
dependent checks, and too few checks to hold what it fixes), so it should not land as built; its fixes are tests of commit
1's own change, so they go in commit 1. Commit 2 is a separate change (new refusals in the board), with its own block and
entries. Either can be read alone; each passes its suites alone (below).

## Commit 1, revised: what changed from the build (`diffs/c1r-vs-c1.*`: audit-recon +97 −3, mutate +11, board none)

- **The two timing-dependent reads** (tests MF1), the reviewer's fix exactly: in the record's-steps case,
  `const rk = /the change was not kept|Not kept/.test(...)` is read before `exportsOf(R.w)` and `J([rv, rk, rx])` is
  checked; in the pre-v1.99 case, `fk = notKept()` is read between `fire(...)` and `exportsNow()`. **Existing
  expectations: none changed** (these are the builder's own new lines, not yet committed; listed here in full anyway:
  `audit-recon.mjs` U10 block, the record's-steps check and the pre-v1.99 check — old: the status read after three exports;
  new: read at once; expected values unchanged, `true`).
- **A second block**, `// ==== v2.00 (U10, beside the codes): …`, scenario "v2.00 (U10) — a refusal in a locked view puts
  back the plan’s settings, the year on screen, the CCaR records and the cycle’s base year", 9 checks: the test reviewer's
  proposal (`verify-tests-r1/harness/vt-block-settings2.mjs.txt`, blob `bd1087aa`) with its name, markers and header
  comments put in house style; **every check, fixture and expected value is the proposal's, unchanged** (diffed: only the
  `const name` line, two comment paragraphs and the end marker differ). File: `block-u10-beside.mjs.txt` (`45d58a25`).
- **Three entries** (`entries-u10-c1r.mjs.txt`, `5516934c`), before the R3 "landed-view" line, after the builder's six:
  `v200-u10-reapply-wrong-year`, `-keeps-plan-settings`, `-working-base` (the reviewer's texts). **Not adopted:**
  `v200-u10-reapply-keeps-ccar-index`. Commit 2 refuses the only door that writes `MS.ccarIdx` in a view
  (`importCcarRecs`; the board's only other writers are loads, refused in a view), so after commit 2 that mutant changes
  nothing a user can reach; as an entry it would survive the final-tree sweep. It was caught at commit 1 (below), and the
  CCaR check stays in the block.

## Commit 2: the board (+17 −0)

The diff is `diffs/c2-vs-c1r.prioritization-board-grid.html.diff`, made by `bin/edit-board-c2.py` (exact replacements,
each matching once). Seven lines of code and their comments, one per door, each the up-front refusal the service list
already uses:

```js
  if(cycBlock('Importing a BAE budget list')){ inp.value=''; return; }      // importBud, after "if(!f) return;"
  if(cycBlock('Importing CCaR records')){ inp.value=''; return; }           // importCcarRecs, the same place
  if(cycBlock('Importing a cost estimate')){ inp.value=''; return; }        // importAce, the same place
  if(cycBlock('Changing a destination')){ render(); return; }               // flowSetEnt, first line (name, kind, terms)
  if(cycBlock('Adding a destination')){ render(); return; }                 // flowAddEnt, first line
  if(cycBlock('Removing a destination')){ render(); return; }               // flowDelEnt, first line: before its question
  if(cycBlock('Resetting the destination list')){ render(); return; }       // flowResetEnts, first line: before its question
```

`cycBlock` is false off a view, so nothing changes on the working plan. In a view it puts the copy back (commit 1), stamps
the refusal and says "🔒 <door> is off while PB27 is on screen. It is a locked cycle, read only — the change was not kept.
↩ Leave the view to work the plan." The file pickers' value is cleared (as their own paths do); the destination doors
redraw, so a typed name goes back on screen.

**How the doors were found (text scans, `bin/sidewriters.py`, `bin/sidewrites2.py`, read only):** every function that writes
a list kept outside the view's copy (DESTDB, ACEDB, BUDDB, RPDB, EXDB, CYCDB) and whether it also calls `save()`/`persist()`
(which refuse in a view) or a gate. Refused-but-kept: `importBud`, `importAce`, `flowSetEnt`, `flowAddEnt` (it pushes on
`flowEnts()`), `flowDelEnt`, `flowResetEnts`; with `importCcarRecs` (MS-level, put back by commit 1, but its status line was
false) these are the seven doors above. Already gated: `svcSaveList`, `cycLock`. Not a user door in a view: `rpMigrate` (boot),
`destMigrate` (guards `CYCVIEW` itself), loads (refused). **Allowed in a view and kept** (no `save()`, so no refusal, so not
U10's case — ledger row U<n>): `importSrc` (QPE), `rpAddEntry`/`rpSetField`/`rpDelEntry`, `blLock`, and `blDelete`, which
calls `save()` only when the deleted cycle is the working plan's comparison reference — measured below.

**Existing mutations near the change:** no existing find overlaps an inserted line (mcount: every existing entry still
matches once). Five existing entries sit inside the touched functions, after the gate: `v200-bae-depts-raw`,
`v200-fname-ace-raw`, `v200-ace-key-open` (owner audit-inject; run below) and `dest-delete-ignores-elsewhere`,
`dest-delete-one-year` (owner audit-import's v1.86 block, on the working plan with no view; the gate is false there, so
their behaviour is unchanged; not run — that block needs the whole-board fixture V186L, see "Plainly not done").

## Commit 2: the test (audit-recon +145, after the beside-the-codes block)

Block `block-u10-lists.mjs.txt` (`96a0fe0e`), `// ==== v2.00 (U10, the shared lists): …`, scenario "v2.00 (U10) — a cost
estimate, a BAE list, CCaR records or a destination change is refused in a locked view before anything is kept", 27 checks,
house style (async wrapper, `bootMark()` / `bootRelease(__bm, [])` / `settleBoards()` as audit-recon's blocks have it, the
two-space `const name` line, markers). Fixture: A (AV; USAF 900, ANG 200; confirmed on WBS 1.1) and R (AV; USAF 503, ANG
127), an approved 2027 estimate (AV, 1.1, $900), the funds flow cut by destination; PB27 locked with R going to Lockheed
Martin; after the lock the working plan adds Depot X (government activity) and sends R there. Each of the seven doors is
used with PB27 on screen: the imports through the handler their file picker calls, with a workbook the board builds; the
destination doors through the controls Setup › Destinations renders (name field typed and changed, + add, ✕, reset; every
question answered OK). After each, three checks: (a) the status line is the door's own refusal, literal, and no question
was asked; (b) the three lists in the board and in browser storage, the panel's names, and the cells of the ACE tie-out
(mapping and PMO reconciliation), the FYDP Spend Plan (FY27 and FYDP ACE estimate), the Spend Plan Source (CCaR, title,
amount, budget, OPR) and the funds flow (destination, amount, lines), from the view; (c) after leaving, the working plan's
lists, R's destination and every export. Expected values are typed: VIEW and WORK (R's $630 under Lockheed Martin in the
view, under Depot X on the working plan; A's $1,100 not yet assigned; the estimate $900 against $1,100 and $1,730).
Controls (6): PB27 viewed with nothing done; the working plan with nothing done; on the working plan, the estimate imported
(asked first, replaced: AV $4,321,000, tie-out 1,100 / 0 / 1,100 and 4,321,000 / 1,730 / −4,319,270, FYDP 4,321,000), the
BAE list imported (the Source names the ANG budget on the two ANG lines), and a destination added and named Depot Z with R
sent there (R's $630 under it); no jsdom errors. Plus the CCaR comment of the beside block updated (3 lines → 4, comment
only).

## Runs, base vs commit 1 vs commit 2 (each alone in its own process group, 600 s cap; all times 13 Oct, ET)

Focused harnesses are built by `bin/mkfocused-u10.py` (verbatim blocks; unchanged from the build): `harness/c1r/focused-u10.mjs`
(`cec69f35`: item 83, item 88, U10, beside — 47 recorded checks) and `harness/c2/focused-u10.mjs` (`318d7998`: the same and
the shared lists — 74). The harness of commit 2 runs every board.

### The focused results (W = checks recorded by `w5Chk`; item 83's checks use `chk` and count only in the exit code)

| run | board | U10 (27) | beside the codes (9) | shared lists (27) | item 88 (11) | exit |
|---|---|---|---|---|---|---|
| F5-u10-on-c2 (harness c2) | c2 `cfc9e14f` | 27 pass | 9 pass | 27 pass | 11 pass | 0 |
| F5-u10-on-c1r (harness c2) | c1r `4a8b0be3` | 27 pass | 9 pass | **21 fail, 6 controls pass** | 11 pass | 1 |
| F5-u10-on-base (harness c2) | base `fce8a391` | **18 fail, 9 controls pass** | **4 fail, 5 controls pass** | **21 fail, 6 controls pass** | 11 pass | 1 |
| F4c1r-u10-on-c1r (harness c1r) | c1r | 27 pass | 9 pass | — | 11 pass | 0 |
| F4c1r-u10-on-base (harness c1r) | base | **18 fail, 9 pass** | **4 fail, 5 pass** | — | 11 pass | 1 |

Every non-control check of the three blocks fails on the base; every control passes on the base; the shared-lists block's
21 non-controls also fail on commit 1 alone (the doors are commit 2's). F4-u10-on-* (9:30–9:31 ET) were the first runs of
the shared-lists block: there one CONTROL (Depot X renamed Depot Y on the working plan) failed on base and c1r, because the
earlier refused doors had already removed Depot X there; it was replaced by an add-and-name control that does not depend on
them (Depot Z), and F5 superseded F4. Failing checks on base, as the blocks' headers state: band 0 printed RENAMED BAND; the
funds flow cut by destination; FY28's K1 money under 77777; the Source titling R and Q REFUSED TITLE / REFUSED OPR; for the
shared lists, the replaced approved estimate (tie-out 1,100 / 0 / 1,100 and 4,321,000 / 1,730 / −4,319,270), the BAE budget
in the Source, RENAMED DEST 630 in the funds flow, "Remove Depot X? Nothing points at it." asked, and R's $630 not yet
assigned after leaving (`out/fix/F5-u10-on-base.checks.jsonl`).

### Every run of this round (label, start ET 13 Oct, exit, wall s, log)

| label | start (ET) | exit | wall s | log |
|---|---|---|---|---|
| P4-lists-on-c2 | 09:24:09 | 0 | 13.0 | `logs/P4-lists-on-c2.log` |
| P4-lists-on-c1r | 09:24:22 | 0 | 13.8 | `logs/P4-lists-on-c1r.log` |
| P4-lists-on-base | 09:24:36 | 0 | 18.3 | `logs/P4-lists-on-base.log` |
| P5-flowdest-on-c2 | 09:25:47 | 0 | 10.1 | `logs/P5-flowdest-on-c2.log` |
| P5-flowdest-on-base | 09:25:57 | 0 | 12.6 | `logs/P5-flowdest-on-base.log` |
| syn-c1r | 09:30:19 | 0 | 0.1 | `logs/syn-c1r.log` |
| syn-audit-recon-c1r | 09:30:19 | 0 | 0.1 | `logs/syn-audit-recon-c1r.log` |
| syn-c2 | 09:30:20 | 0 | 0.1 | `logs/syn-c2.log` |
| syn-audit-recon-c2 | 09:30:20 | 0 | 0.1 | `logs/syn-audit-recon-c2.log` |
| F4-u10-on-c2 | 09:30:25 | 0 | 25.0 | `logs/F4-u10-on-c2.log` |
| F4-u10-on-base | 09:31:04 | 1 | 29.2 | `logs/F4-u10-on-base.log` |
| F4-u10-on-c1r | 09:31:33 | 1 | 26.3 | `logs/F4-u10-on-c1r.log` |
| F4c1r-u10-on-c1r | 09:31:59 | 0 | 19.2 | `logs/F4c1r-u10-on-c1r.log` |
| F4c1r-u10-on-base | 09:32:18 | 1 | 21.6 | `logs/F4c1r-u10-on-base.log` |
| F5-u10-on-c2 | 09:33:36 | 0 | 42.5 | `logs/F5-u10-on-c2.log` |
| F5-u10-on-base | 09:34:19 | 1 | 42.5 | `logs/F5-u10-on-base.log` |
| F5-u10-on-c1r | 09:35:01 | 1 | 38.7 | `logs/F5-u10-on-c1r.log` |
| F5-c2-mut-v200-u10-ace-import-in-view | 09:36:54 | 1 | 34.8 | `logs/F5-c2-mut-v200-u10-ace-import-in-view.log` |
| F4c1r-c1r-mut-v200-u10-reapply-first-year | 09:38:44 | 1 | 55.0 | `logs/F4c1r-c1r-mut-v200-u10-reapply-first-year.log` |
| F5-c2-mut-v200-u10-bae-import-in-view | 09:38:44 | 1 | 74.8 | `logs/F5-c2-mut-v200-u10-bae-import-in-view.log` |
| F4c1r-c1r-mut-v200-u10-reapply-keeps-list | 09:39:39 | 1 | 54.9 | `logs/F4c1r-c1r-mut-v200-u10-reapply-keeps-list.log` |
| F5-c2-mut-v200-u10-ccar-import-in-view | 09:39:59 | 1 | 70.5 | `logs/F5-c2-mut-v200-u10-ccar-import-in-view.log` |
| F4c1r-c1r-mut-v200-u10-reapply-keeps-plan-settings | 09:40:34 | 1 | 47.8 | `logs/F4c1r-c1r-mut-v200-u10-reapply-keeps-plan-settings.log` |
| F5-c2-mut-v200-u10-dest-add-in-view | 09:41:09 | 1 | 48.4 | `logs/F5-c2-mut-v200-u10-dest-add-in-view.log` |
| F4c1r-c1r-mut-v200-u10-reapply-keeps-pmos | 09:41:22 | 1 | 37.8 | `logs/F4c1r-c1r-mut-v200-u10-reapply-keeps-pmos.log` |
| P6-cycdel-on-c2 | 09:42:03 | 0 | 5.1 | `logs/P6-cycdel-on-c2.log` |
| P6-cycdel-on-base | 09:42:08 | 0 | 5.1 | `logs/P6-cycdel-on-base.log` |
| F4c1r-c1r-mut-v200-u10-reapply-keeps-years | 09:42:00 | 1 | 39.3 | `logs/F4c1r-c1r-mut-v200-u10-reapply-keeps-years.log` |
| F5-c2-mut-v200-u10-dest-change-in-view | 09:41:58 | 1 | 47.5 | `logs/F5-c2-mut-v200-u10-dest-change-in-view.log` |
| F4c1r-c1r-mut-v200-u10-reapply-older-keeps-list | 09:42:39 | 1 | 40.2 | `logs/F4c1r-c1r-mut-v200-u10-reapply-older-keeps-list.log` |
| N2-check-c1r | 09:43:16 | 0 | 7.3 | `logs/N2-check-c1r.log` |
| N2-check-c2 | 09:43:23 | 0 | 7.4 | `logs/N2-check-c2.log` |
| N2-check-base | 09:43:31 | 0 | 7.8 | `logs/N2-check-base.log` |
| F5-c2-mut-v200-u10-dest-change-no-redraw | 09:42:45 | 1 | 58.0 | `logs/F5-c2-mut-v200-u10-dest-change-no-redraw.log` |
| F4c1r-c1r-mut-v200-u10-reapply-working-base | 09:43:20 | 1 | 55.2 | `logs/F4c1r-c1r-mut-v200-u10-reapply-working-base.log` |
| F5-c2-mut-v200-u10-dest-remove-in-view | 09:43:44 | 1 | 71.5 | `logs/F5-c2-mut-v200-u10-dest-remove-in-view.log` |
| F4c1r-c1r-mut-v200-u10-reapply-wrong-year | 09:44:15 | 1 | 53.9 | `logs/F4c1r-c1r-mut-v200-u10-reapply-wrong-year.log` |
| F4c1r-c1r-mut-v200-u10-reapply-year-only | 09:45:09 | 1 | 57.5 | `logs/F4c1r-c1r-mut-v200-u10-reapply-year-only.log` |
| F5-c2-mut-v200-u10-dest-reset-in-view | 09:44:55 | 1 | 76.9 | `logs/F5-c2-mut-v200-u10-dest-reset-in-view.log` |
| F4c1r-c1r-mut-vt-field-codes | 09:46:07 | 1 | 45.8 | `logs/F4c1r-c1r-mut-vt-field-codes.log` |
| F5-c2-mut-v200-u10-reapply-first-year | 09:46:12 | 1 | 60.5 | `logs/F5-c2-mut-v200-u10-reapply-first-year.log` |
| F4c1r-c1r-mut-vt-field-rcn | 09:47:01 | 1 | 41.0 | `logs/F4c1r-c1r-mut-vt-field-rcn.log` |
| F5-c2-mut-v200-u10-reapply-keeps-list | 09:47:21 | 1 | 56.8 | `logs/F5-c2-mut-v200-u10-reapply-keeps-list.log` |
| F4c1r-c1r-mut-vt-inline-no-base | 09:47:42 | 1 | 48.0 | `logs/F4c1r-c1r-mut-vt-inline-no-base.log` |
| F4c1r-c1r-mut-vt-inline-no-kept-list | 09:48:30 | 1 | 50.9 | `logs/F4c1r-c1r-mut-vt-inline-no-kept-list.log` |
| F5-c2-mut-v200-u10-reapply-keeps-plan-settings | 09:48:18 | 1 | 74.7 | `logs/F5-c2-mut-v200-u10-reapply-keeps-plan-settings.log` |
| F4c1r-c1r-mut-vt-keeps-bands | 09:49:21 | 1 | 53.7 | `logs/F4c1r-c1r-mut-vt-keeps-bands.log` |
| F5-c2-mut-v200-u10-reapply-keeps-pmos | 09:49:33 | 1 | 70.2 | `logs/F5-c2-mut-v200-u10-reapply-keeps-pmos.log` |
| F4c1r-c1r-mut-vt-keeps-ccaridx | 09:50:15 | 1 | 56.3 | `logs/F4c1r-c1r-mut-vt-keeps-ccaridx.log` |
| F5-c2-mut-v200-u10-reapply-keeps-years | 09:50:43 | 1 | 79.6 | `logs/F5-c2-mut-v200-u10-reapply-keeps-years.log` |
| F4c1r-c1r-mut-vt-keeps-flow | 09:51:11 | 1 | 55.6 | `logs/F4c1r-c1r-mut-vt-keeps-flow.log` |
| F4c1r-c1r-mut-vt-noapply | 09:52:07 | 1 | 45.0 | `logs/F4c1r-c1r-mut-vt-noapply.log` |
| F5-c2-mut-v200-u10-reapply-older-keeps-list | 09:52:03 | 1 | 60.6 | `logs/F5-c2-mut-v200-u10-reapply-older-keeps-list.log` |
| F4c1r-c1r-mut-vt-rcnset-upfront | 09:52:52 | 1 | 45.8 | `logs/F4c1r-c1r-mut-vt-rcnset-upfront.log` |
| F5-c2-mut-v200-u10-reapply-working-base | 09:53:04 | 1 | 59.9 | `logs/F5-c2-mut-v200-u10-reapply-working-base.log` |
| F4c1r-c1r-mut-vt-reopen-view | 09:53:38 | 1 | 53.3 | `logs/F4c1r-c1r-mut-vt-reopen-view.log` |
| F5-c2-mut-v200-u10-reapply-wrong-year | 09:54:04 | 1 | 66.6 | `logs/F5-c2-mut-v200-u10-reapply-wrong-year.log` |
| F4c1r-c1r-mut-vt-shallow-stash | 09:54:31 | 1 | 50.5 | `logs/F4c1r-c1r-mut-vt-shallow-stash.log` |
| F5-c2-mut-v200-u10-reapply-year-only | 09:55:10 | 1 | 51.7 | `logs/F5-c2-mut-v200-u10-reapply-year-only.log` |
| F5-c2-mut-ow-ace-after-prompt | 09:56:02 | 1 | 61.0 | `logs/F5-c2-mut-ow-ace-after-prompt.log` |
| F5-c2-mut-ow-ccar-quiet | 09:57:03 | 1 | 69.6 | `logs/F5-c2-mut-ow-ccar-quiet.log` |
| S3-audit-recon-c2 | 09:55:30 | 0 | 253.5 | `logs/S3-audit-recon-c2.log` |
| F5-c2-mut-ow-del-after-confirm | 09:59:53 | 1 | 71.0 | `logs/F5-c2-mut-ow-del-after-confirm.log` |
| F5-c2-mut-vt-field-codes | 10:01:04 | 1 | 76.7 | `logs/F5-c2-mut-vt-field-codes.log` |
| F5-c2-mut-vt-field-rcn | 10:02:21 | 1 | 60.6 | `logs/F5-c2-mut-vt-field-rcn.log` |
| S3-audit-recon-c1r | 09:59:53 | 0 | 259.0 | `logs/S3-audit-recon-c1r.log` |
| F5-c2-mut-vt-inline-no-base | 10:03:22 | 1 | 64.2 | `logs/F5-c2-mut-vt-inline-no-base.log` |
| F5-c2-mut-vt-inline-no-kept-list | 10:04:26 | 1 | 63.7 | `logs/F5-c2-mut-vt-inline-no-kept-list.log` |
| F5-c2-mut-vt-keeps-bands | 10:05:30 | 1 | 62.1 | `logs/F5-c2-mut-vt-keeps-bands.log` |
| F5-c2-mut-vt-keeps-ccaridx | 10:06:32 | 0 | 59.2 | `logs/F5-c2-mut-vt-keeps-ccaridx.log` |
| S3-audit-recon-base | 10:04:18 | 0 | 195.8 | `logs/S3-audit-recon-base.log` |
| S3-boot-same-c2 | 10:07:34 | 0 | 25.9 | `logs/S3-boot-same-c2.log` |
| S3-audit-c2 | 10:08:00 | 0 | 21.5 | `logs/S3-audit-c2.log` |
| S3-audit-ppt-c2 | 10:08:21 | 0 | 11.2 | `logs/S3-audit-ppt-c2.log` |
| F5-c2-mut-vt-keeps-flow | 10:07:32 | 1 | 78.7 | `logs/F5-c2-mut-vt-keeps-flow.log` |
| S3-audit-other-c2 | 10:08:33 | 0 | 66.1 | `logs/S3-audit-other-c2.log` |
| S3-legacy-fsrc-c2 | 10:09:46 | 0 | 6.1 | `logs/S3-legacy-fsrc-c2.log` |
| F5-c2-mut-vt-noapply | 10:08:50 | 1 | 67.2 | `logs/F5-c2-mut-vt-noapply.log` |
| F5-c2-mut-vt-rcnset-upfront | 10:09:58 | 1 | 68.0 | `logs/F5-c2-mut-vt-rcnset-upfront.log` |
| S3-audit-hostile-c2 | 10:09:52 | 0 | 104.8 | `logs/S3-audit-hostile-c2.log` |
| S3-audit-inject-c2 | 10:11:37 | 0 | 26.1 | `logs/S3-audit-inject-c2.log` |
| S3-boot-same-base | 10:12:03 | 0 | 24.7 | `logs/S3-boot-same-base.log` |
| F5-c2-mut-vt-reopen-view | 10:11:16 | 1 | 75.7 | `logs/F5-c2-mut-vt-reopen-view.log` |
| S3-audit-other-base | 10:12:28 | 0 | 75.0 | `logs/S3-audit-other-base.log` |
| F5-c2-mut-vt-shallow-stash | 10:12:32 | 1 | 72.4 | `logs/F5-c2-mut-vt-shallow-stash.log` |
| S3-audit-inject-c2-mut-v200-bae-depts-raw | 10:13:54 | 1 | 23.4 | `logs/S3-audit-inject-c2-mut-v200-bae-depts-raw.log` |
| S3-audit-inject-c2-mut-v200-fname-ace-raw | 10:14:17 | 1 | 25.7 | `logs/S3-audit-inject-c2-mut-v200-fname-ace-raw.log` |
| F5-c2-mut-vt-wrong-year-state | 10:13:44 | 1 | 71.5 | `logs/F5-c2-mut-vt-wrong-year-state.log` |
| S3-audit-inject-c2-mut-v200-ace-key-open | 10:14:43 | 1 | 22.9 | `logs/S3-audit-inject-c2-mut-v200-ace-key-open.log` |
| B3-ppbe-on-c2 | 10:14:56 | 0 | 22.8 | `logs/B3-ppbe-on-c2.log` |
| I3-r3-on-c2 | 10:15:19 | 0 | 18.8 | `logs/I3-r3-on-c2.log` |
| I3-w3-on-c2 | 10:15:51 | 0 | 244.9 | `logs/I3-w3-on-c2.log` |

Not in the table: **F5-c2-mut-v200-u10-bae-import-in-view's first run** (started about 9:37:29 ET by the stopped 7000 s
batch; its node run, PIDs 21319/21322, finished on its own, but its run.sh was ended with the batch, so no exit line was
written and the re-run at 9:38:44 overwrote its log; its checks were appended to the same file, which `bin/mutfails.py`
reads from the last run only). The `syn-*` runs are `node --check` (syntax only). Batches: `mutruns-fix.sh` /
`mutruns-fix2.sh` (mutants, in chunks under `bx.sh`, each chunk under 600 s: 9:38:44–9:47:13, 9:38:44–9:46:53, 9:47:01–9:55:22,
9:47:21–9:59:53, 9:59:53–10:11:06 and 10:11:16–10:14:56 ET), `suites3.sh` (suites, in chunks under `bx.sh`). The audit-import
lock was absent at every check (`run.sh` checks before each node run; none waited).

## Mutations

mcount (text only, `out/mcount/`): base 1328 entries, 1328 match once; c1r 1337, 1337 once; **c2 1345, 1345 once** (no
missing, multiple or unparsed). Mutants were made with `mkmut.py` from each copy's mutate text (never imported or run), the
test reviewer's own with a copy of its `vtmuts.py` / `vtmuts2.py` (`bin/vtmuts*.verifier-copy.py`), and this round's own
with `bin/ownmuts.py`. Each ran through the focused harness of the copy it was made from.

| mutant | at c1r (F4c1r, 47) | at c2 (F5, 74) |
|---|---|---|
| **new, commit 1:** v200-u10-reapply-wrong-year | 1 | 1 |
| v200-u10-reapply-keeps-plan-settings | 2 | 2 |
| v200-u10-reapply-working-base | 1 | 1 |
| **new, commit 2:** v200-u10-ace-import-in-view | — | 15 |
| v200-u10-bae-import-in-view | — | 13 |
| v200-u10-ccar-import-in-view | — | 1 |
| v200-u10-dest-change-in-view | — | 9 |
| v200-u10-dest-change-no-redraw | — | 1 |
| v200-u10-dest-add-in-view | — | 8 |
| v200-u10-dest-remove-in-view | — | 5 |
| v200-u10-dest-reset-in-view | — | 2 |
| **the build's six:** -year-only / -keeps-list / -keeps-years / -keeps-pmos / -first-year / -older-keeps-list | 22 / 17 / 5 / 2 / 2 / 1 | 21 / 17 / 5 / 2 / 2 / 1 |
| **the test reviewer's own:** vt-noapply / vt-field-rcn / vt-field-codes / vt-keeps-bands / vt-keeps-flow / vt-reopen-view | 5 / 8 / 3 / 1 / 1 / 2 | 5 / 7 / 2 / 1 / 1 / 2 |
| vt-inline-no-kept-list / vt-inline-no-base / vt-shallow-stash / vt-rcnset-upfront / vt-wrong-year-state | 19 / 1 / 2 / 11 / (= -wrong-year) | 19 / 1 / 2 / 10 / 1 |
| vt-keeps-ccaridx | **1 (caught)** | **0 — equivalent at c2** (no door writes the CCaR index in a view; not an entry, see above) |
| **this round's own:** ow-ccar-quiet (refused silently) / ow-del-after-confirm (✕ refused after its question) / ow-ace-after-prompt (estimate refused after "Replace it?") | — | 2 / 1 / 1 |

Every one of the 11 new entries is caught at c2, and the three of commit 1 at c1r too; the build's six are still caught at
both; of the reviewer's 12, all are caught at c1r and 11 at c2 (the twelfth is the equivalent one). Year-only falls from 22
to 21 at c2 because the CCaR import is refused up front there, so the beside block's CCaR check no longer sees it. The
counts at c2 for the commit-2 entries are higher than one because an import or edit that is kept also changes what the later
doors read (each door reads all three lists). Failing checks, mutant by mutant: `out/fix/mutants-c2-failing.md`,
`out/fix/mutants-c1r-failing.md`; summaries `out/fix/mutants-c2.txt`, `out/fix/mutants-c1r.txt`.

**Existing entries near commit 2** (inside the touched functions, after the gate), at c2 through their owner audit-inject
with `BOARD` = the mutant: `v200-bae-depts-raw` 2 failing, `v200-fname-ace-raw` 2 failing, `v200-ace-key-open` 1 failing
(exit 1 each; S3-audit-inject-c2-mut-*). The two in `flowDelEnt` (`dest-delete-ignores-elsewhere`, `dest-delete-one-year`)
were not run (see Plainly not done).

## Suites and npm run check

| suite | base `fce8a391` | c1r `4a8b0be3` | c2 `cfc9e14f` |
|---|---|---|---|
| audit-recon (owning suite, full) | ALL CHECKS PASSED (195.8 s, S3) | ALL CHECKS PASSED (259.0 s) | ALL CHECKS PASSED (253.5 s) |
| boot-same | identical either way (S3, 24.7 s) | (board = the build's c1: S2-boot-same-c1v2, identical) | identical either way (25.9 s) |
| audit-other | ALL CHECKS PASSED (S3, 75.0 s) | (S2-audit-other-c1v2, passed) | ALL CHECKS PASSED (66.1 s) |
| audit, audit-ppt, legacy-fsrc, audit-hostile, audit-inject | the build's S2 base runs (same base blobs) | (the build's S2 c1v2 runs) | all pass / exit 0 |
| audit-board PPBE blocks (focused) | 141/141 (the build's B2) | (the build's B2 on c1) | **141/141** (B3-ppbe-on-c2) |
| audit-import v2.00 R3 / v1.97 W3 blocks (focused) | passed (the build's I-r3 / I-w3) | (the build's, on c1) | **ALL CHECKS PASSED** both (I3-r3-on-c2, I3-w3-on-c2) |
| npm run check (scratch clone `gitclone/`, files copied over, never committed; base files put back after) | all checks passed | all checks passed | all checks passed |

Output compared after masking timings, clocks and paths (`bin/cmplogs.py`): c2 against base, **0 differing lines** for
boot-same, audit, audit-ppt, audit-other, legacy-fsrc, audit-hostile, audit-inject and audit-recon (13 lines each side;
the suite prints its verdict, the three U10 scenarios are in it and its scenario-ran guard passed). c1r's board is the build's
c1 board, byte for byte, so its other suites are the build's S2-*-c1v2 runs; only its audit-recon and mutate text changed,
and audit-recon was run in full here. The full audit-import and audit-board were not run (the lead's).

## Measured this round (probes, all synthetic, in memory)

- `probe3/u10-lists.mjs` (P4-lists-on-c2 / -c1r / -base, 9:24 ET): every door in the view and on the working plan, the
  state and the export cells observed; the block's expectations were then typed from the fixture by hand and checked
  against c2. On c2 every door in the view leaves the lists, storage and all four exports as they were; on base and c1r
  the imports and destination edits reach them.
- `probe3/u10-flowdest.mjs` (P5-flowdest-on-c2 / -base, 9:25 ET): with the funds flow cut by destination, base prints
  `RENAMED DEST | 630` from the view after a refused rename, and after a refused ✕ of Depot X the working plan's funds flow
  reads `Not yet assigned | 1730 | 4` (R's $630 lost its destination); c2 prints Lockheed Martin 630 in the view and Depot X
  630 on the working plan throughout.
- `probe3/u10-cycdel.mjs` (P6-cycdel-on-c2 / -base, 9:42 ET), **a further case for the ledger, not fixed:** in PB27's view,
  POM27 (the working plan's comparison reference) is unlocked with no message, then deleted after "Delete the POM27 cycle?
  It cannot be recovered."; the status line reads "🔒 Saving is off while PB27 is on screen … the change was not kept", yet
  POM27 is gone from the store and browser storage, and back on the working plan `MS.cycleRef` names a cycle that no longer
  exists. The same on base and c2. Not fixed here because a refusal of cycle deletion and unlocking in a view changes what
  audit-board's PPBE block does (it unlocks the viewed cycle from the view and locks it again), and the existing mutant
  `view-delete-on-screen` would become equivalent under a whole-function gate; whether a view may manage other cycles is
  Brad's call (principle 2).

## Decisions, with reasons (the lead's principles)

1. **Never lose a copy of anyone's work.** Commit 2 closes the two losses the review measured: an approved estimate replaced
   from a view, and a destination removed from a view under the working plan's requirements. Both doors now refuse before
   anything is read, asked or written; nothing kept is touched. The working plan is unchanged (`cycBlock` is false there),
   and the controls show each door still works there.
2. **Refuse or ask rather than guess.** A view is read only; the doors refuse, as Save and the service list already do,
   instead of keeping a change the board calls not kept. The cases that are allowed in a view (QPE, reprogramming, cycle
   unlock/delete) and the cycle's PMO list are put to Brad as ledger rows, not changed.
3. **Money and every export match the computation.** After any refused door, the ACE tie-out, the FYDP Spend Plan, the
   Spend Plan Source and the funds flow read the same cells, typed in the block, in the view and on the working plan; on base
   they move by $4,320,100 (estimate) and $630 (destination). No money logic is touched.
4. **Every word stays true.** Each refusal now names its door and says nothing was kept, and that is so: storage is checked
   in the block. The CCaR import no longer says "Save to bake this into the file" in a view. The drafts no longer claim more
   than the commits do; the remaining false line (deleting the reference cycle) is in the ledger with its words quoted.
5. **Smallest change.** Seven one-line gates with the board's own `cycBlock`; no new mechanism. Rejected: making the
   shared lists part of the view's copy (a much larger change to every reader of DESTDB/ACEDB/BUDDB), and gating cycle
   management (above).
6. **Every existing check, fixture and expected value preserved.** Against the base, the suite and mutate diffs only add
   lines (audit-recon +429 −0, mutate +57 −0). The only changed lines are in the builder's own uncommitted block (the two
   status reads, listed above with old and new) and one comment of commit 1's new block. All 1328 base entries still match
   once; existing suites pass at both commits.

## Plainly not done (this round)

- Not run: the full audit-import and audit-board (the lead's); the mutate.mjs sweep (never imported or run) and the
  full-suite sensitivity of the 11 new entries (each is caught by the focused blocks, which are verbatim from the suite).
- Not run: the two existing `flowDelEnt` entries (`dest-delete-ignores-elsewhere`, `dest-delete-one-year`) through their
  owner (audit-import's v1.86 block, which needs the whole-board fixture V186L that the focused harness leaves out). They
  run on the working plan, where `cycBlock` is false and the gate changes nothing; the lead's full audit-import covers them.
- Not fixed (ledger rows drafted, Brad's decisions): edits a view allows and keeps (QPE import, reprogramming rows, another
  cycle unlocked or deleted — and the false "not kept" when the deleted cycle is the working plan's reference); a locked
  cycle's PMO list. Not investigated: the money review's note that reopening from browser storage before any save brought
  a view-removed destination back under a new key (the door is now refused in a view).
- Tested by code reading only: the `kind` and `terms` fields of a destination (the same `flowSetEnt` gate as the name, which
  is tested); the destination doors' controls in the Funds Flow panel's own editor (the same `flowEntEditor()` as Setup ›
  Destinations, which is tested).
- **The 600 s cap, once exceeded by a batch driver:** at 9:36:54 ET I started the mutant batch `mutruns-fix.sh c2` under
  `setsid -w timeout -k 10 7000` instead of 600 (each node run inside had its own 600 s cap). At about 9:37:30 ET I recorded
  its two child PIDs (20953 timeout, 20954 the script; 20951 setsid was already recorded) and stopped it with TERM to those
  recorded PIDs; the one node run already started inside (21319/21322, recorded by run.sh) finished on its own. Every later
  batch ran in chunks under `bx.sh` (600 s). Nothing else was killed by anyone.
- Not wrapped: short read-only shell and text commands (cat, grep, sed, diff, ls, cp, git hash-object, `python3 -I` text
  scans, tallies and the README build) ran directly; so did a few `until … sleep 5` waits for my own runs' summary lines
  (each bounded by the tool's 600 s limit) and one `sleep 1` / `sleep 5` pause. Every node run went through `run.sh`.
- Nothing committed, staged or pushed anywhere; `/home/user/orbit-board` and `/home/user/orbit-ui` only read. The scratch
  clone `gitclone/` had c1r's, c2's and then the base's files copied in for npm run check and ends holding the base's.

## PIDs (this round; the timeout PID and its child per run, in `pids.txt` with the full command, from the marker "fix round")

```
    # ==== fix round (U10 builder, round 1 fixes) started 2026-10-13 09:18:42 EDT; container restarted 9:11 AM ET, no earlier process running ====
    5553 09:19:35 EDT timeout bx:cp-c1r
    5555 09:19:35 EDT cp bx:cp-c1r
    8175 09:20:43 EDT timeout bx:ins-beside-c1r
    8178 09:20:43 EDT gone bx:ins-beside-c1r
    8995 09:21:13 EDT timeout bx:ins-entries-c1r
    8998 09:21:13 EDT gone bx:ins-entries-c1r
    9007 09:21:13 EDT timeout bx:mcount-c1r
    9010 09:21:13 EDT python3 bx:mcount-c1r
    9865 09:21:45 EDT gone bx:cp-c2
    9868 09:21:45 EDT gone bx:cp-c2
    9877 09:21:45 EDT timeout bx:edit-board-c2
    9879 09:21:45 EDT python3 bx:edit-board-c2
    9972 09:21:52 EDT timeout bx:mcount-c2-pre
    9975 09:21:52 EDT python3 bx:mcount-c2-pre
    12208 09:24:09 EDT timeout P4-lists-on-c2
    12211 09:24:09 EDT node P4-lists-on-c2
    12440 09:24:22 EDT timeout P4-lists-on-c1r
    12442 09:24:22 EDT node P4-lists-on-c1r
    12652 09:24:36 EDT timeout P4-lists-on-base
    12655 09:24:36 EDT node P4-lists-on-base
    13454 09:25:47 EDT timeout P5-flowdest-on-c2
    13457 09:25:47 EDT node P5-flowdest-on-c2
    13715 09:25:58 EDT timeout P5-flowdest-on-base
    13717 09:25:58 EDT node P5-flowdest-on-base
    16518 09:29:34 EDT gone bx:ins-lists-c2
    16851 09:29:56 EDT timeout bx:ins-entries-c2
    16854 09:29:56 EDT gone bx:ins-entries-c2
    16862 09:29:56 EDT timeout bx:mcount-c2
    16864 09:29:56 EDT python3 bx:mcount-c2
    16875 09:29:59 EDT timeout bx:mcount-base-r
    16878 09:29:59 EDT python3 bx:mcount-base-r
    16978 09:30:13 EDT gone bx:mkfocused-c1r
    16980 09:30:13 EDT gone bx:mkfocused-c1r
    16989 09:30:13 EDT timeout bx:mkfocused-c2
    16991 09:30:13 EDT gone bx:mkfocused-c2
    17052 09:30:19 EDT timeout syn-c1r
    17054 09:30:19 EDT node syn-c1r
    17077 09:30:19 EDT timeout syn-audit-recon-c1r
    17079 09:30:19 EDT node syn-audit-recon-c1r
    17101 09:30:20 EDT timeout syn-c2
    17104 09:30:20 EDT node syn-c2
    17125 09:30:20 EDT timeout syn-audit-recon-c2
    17128 09:30:20 EDT node syn-audit-recon-c2
    17204 09:30:25 EDT timeout F4-u10-on-c2
    17207 09:30:25 EDT node F4-u10-on-c2
    17498 09:31:04 EDT timeout F4-u10-on-base
    17500 09:31:04 EDT node F4-u10-on-base
    17752 09:31:33 EDT timeout F4-u10-on-c1r
    17754 09:31:33 EDT node F4-u10-on-c1r
    17889 09:31:59 EDT timeout F4c1r-u10-on-c1r
    17891 09:31:59 EDT node F4c1r-u10-on-c1r
    18102 09:32:18 EDT timeout F4c1r-u10-on-base
    18104 09:32:18 EDT node F4c1r-u10-on-base
    18619 09:33:28 EDT timeout bx:mkfocused-c2b
    18621 09:33:28 EDT python3 bx:mkfocused-c2b
    18685 09:33:36 EDT timeout F5-u10-on-c2
    18688 09:33:36 EDT node F5-u10-on-c2
    19015 09:34:19 EDT timeout F5-u10-on-base
    19017 09:34:19 EDT node F5-u10-on-base
    19542 09:35:01 EDT timeout F5-u10-on-c1r
    19547 09:35:02 EDT node F5-u10-on-c1r
    20272 09:36:15 EDT timeout bx:mkmut-c2-v200-u10-reapply-wrong-year
    20275 09:36:15 EDT python3 bx:mkmut-c2-v200-u10-reapply-wrong-year
    20283 09:36:15 EDT timeout bx:mkmut-c2-v200-u10-reapply-keeps-plan-settings
    20286 09:36:15 EDT python3 bx:mkmut-c2-v200-u10-reapply-keeps-plan-settings
    20294 09:36:16 EDT timeout bx:mkmut-c2-v200-u10-reapply-working-base
    20296 09:36:16 EDT python3 bx:mkmut-c2-v200-u10-reapply-working-base
    20305 09:36:16 EDT timeout bx:mkmut-c2-v200-u10-ace-import-in-view
    20307 09:36:16 EDT python3 bx:mkmut-c2-v200-u10-ace-import-in-view
    20316 09:36:16 EDT timeout bx:mkmut-c2-v200-u10-bae-import-in-view
    20318 09:36:16 EDT python3 bx:mkmut-c2-v200-u10-bae-import-in-view
    20327 09:36:16 EDT timeout bx:mkmut-c2-v200-u10-ccar-import-in-view
    20329 09:36:16 EDT python3 bx:mkmut-c2-v200-u10-ccar-import-in-view
    20338 09:36:17 EDT timeout bx:mkmut-c2-v200-u10-dest-change-in-view
    20340 09:36:17 EDT python3 bx:mkmut-c2-v200-u10-dest-change-in-view
    20349 09:36:17 EDT timeout bx:mkmut-c2-v200-u10-dest-change-no-redraw
    20351 09:36:17 EDT python3 bx:mkmut-c2-v200-u10-dest-change-no-redraw
    20360 09:36:17 EDT timeout bx:mkmut-c2-v200-u10-dest-add-in-view
    20363 09:36:17 EDT python3 bx:mkmut-c2-v200-u10-dest-add-in-view
    20371 09:36:17 EDT timeout bx:mkmut-c2-v200-u10-dest-remove-in-view
    20374 09:36:17 EDT python3 bx:mkmut-c2-v200-u10-dest-remove-in-view
    20382 09:36:17 EDT timeout bx:mkmut-c2-v200-u10-dest-reset-in-view
    20384 09:36:17 EDT python3 bx:mkmut-c2-v200-u10-dest-reset-in-view
    20393 09:36:17 EDT timeout bx:mkmut-c2-v200-u10-reapply-year-only
    20396 09:36:17 EDT python3 bx:mkmut-c2-v200-u10-reapply-year-only
    20404 09:36:18 EDT timeout bx:mkmut-c2-v200-u10-reapply-keeps-list
    20407 09:36:18 EDT python3 bx:mkmut-c2-v200-u10-reapply-keeps-list
    20415 09:36:18 EDT timeout bx:mkmut-c2-v200-u10-reapply-keeps-years
    20417 09:36:18 EDT python3 bx:mkmut-c2-v200-u10-reapply-keeps-years
    20426 09:36:18 EDT timeout bx:mkmut-c2-v200-u10-reapply-keeps-pmos
    20428 09:36:18 EDT python3 bx:mkmut-c2-v200-u10-reapply-keeps-pmos
    20437 09:36:18 EDT timeout bx:mkmut-c2-v200-u10-reapply-first-year
    20440 09:36:18 EDT python3 bx:mkmut-c2-v200-u10-reapply-first-year
    20448 09:36:18 EDT timeout bx:mkmut-c2-v200-u10-reapply-older-keeps-list
    20450 09:36:18 EDT python3 bx:mkmut-c2-v200-u10-reapply-older-keeps-list
    20461 09:36:19 EDT timeout bx:mkmut-c1r-v200-u10-reapply-wrong-year
    20463 09:36:19 EDT python3 bx:mkmut-c1r-v200-u10-reapply-wrong-year
    20472 09:36:19 EDT timeout bx:mkmut-c1r-v200-u10-reapply-keeps-plan-settings
    20474 09:36:19 EDT python3 bx:mkmut-c1r-v200-u10-reapply-keeps-plan-settings
    20483 09:36:19 EDT timeout bx:mkmut-c1r-v200-u10-reapply-working-base
    20485 09:36:19 EDT python3 bx:mkmut-c1r-v200-u10-reapply-working-base
    20494 09:36:19 EDT timeout bx:mkmut-c1r-v200-u10-reapply-year-only
    20496 09:36:19 EDT python3 bx:mkmut-c1r-v200-u10-reapply-year-only
    20509 09:36:19 EDT timeout bx:mkmut-c1r-v200-u10-reapply-keeps-list
    20511 09:36:19 EDT python3 bx:mkmut-c1r-v200-u10-reapply-keeps-list
    20520 09:36:19 EDT timeout bx:mkmut-c1r-v200-u10-reapply-keeps-years
    20522 09:36:19 EDT python3 bx:mkmut-c1r-v200-u10-reapply-keeps-years
    20531 09:36:20 EDT timeout bx:mkmut-c1r-v200-u10-reapply-keeps-pmos
    20534 09:36:20 EDT python3 bx:mkmut-c1r-v200-u10-reapply-keeps-pmos
    20546 09:36:20 EDT timeout bx:mkmut-c1r-v200-u10-reapply-first-year
    20549 09:36:20 EDT python3 bx:mkmut-c1r-v200-u10-reapply-first-year
    20560 09:36:20 EDT timeout bx:mkmut-c1r-v200-u10-reapply-older-keeps-list
    20562 09:36:20 EDT python3 bx:mkmut-c1r-v200-u10-reapply-older-keeps-list
    20584 09:36:20 EDT timeout bx:vtmuts-c2
    20587 09:36:20 EDT python3 bx:vtmuts-c2
    20603 09:36:21 EDT timeout bx:vtmuts2-c2
    20605 09:36:21 EDT python3 bx:vtmuts2-c2
    20618 09:36:21 EDT timeout bx:vtmuts-c1r
    20621 09:36:21 EDT python3 bx:vtmuts-c1r
    20822 09:36:35 EDT timeout bx:ownmuts-c2
    20824 09:36:35 EDT python3 bx:ownmuts-c2
    20951 09:36:54 EDT timeout mutruns-fix.sh
    20963 09:36:54 EDT timeout F5-c2-mut-v200-u10-ace-import-in-view
    20967 09:36:54 EDT node F5-c2-mut-v200-u10-ace-import-in-view
    20953 09:37:28 EDT timeout child
    20954 09:37:28 EDT mutruns-fix.sh child
    21319 09:37:29 EDT timeout F5-c2-mut-v200-u10-bae-import-in-view
    21322 09:37:29 EDT node F5-c2-mut-v200-u10-bae-import-in-view
    09:37:38 EDT STOPPED (TERM) 20954 and 20953, the mutruns-fix.sh c2 batch I started at 09:36:54 with a 7000 s cap; the node run already inside it (20963/20967, its own 600 s cap) was left to finish. Ba
    22301 09:38:44 EDT timeout bx:mutchunk-c2-00
    22303 09:38:44 EDT mutruns-fix.sh bx:mutchunk-c2-00
    22320 09:38:44 EDT timeout bx:mutchunk-c1r-00
    22315 09:38:44 EDT timeout F5-c2-mut-v200-u10-bae-import-in-view
    22322 09:38:44 EDT mutruns-fix.sh bx:mutchunk-c1r-00
    22321 09:38:44 EDT node F5-c2-mut-v200-u10-bae-import-in-view
    22359 09:38:44 EDT timeout F4c1r-c1r-mut-v200-u10-reapply-first-year
    22364 09:38:44 EDT node F4c1r-c1r-mut-v200-u10-reapply-first-year
    23009 09:39:39 EDT timeout F4c1r-c1r-mut-v200-u10-reapply-keeps-list
    23011 09:39:39 EDT node F4c1r-c1r-mut-v200-u10-reapply-keeps-list
    23152 09:39:59 EDT timeout F5-c2-mut-v200-u10-ccar-import-in-view
    23154 09:39:59 EDT node F5-c2-mut-v200-u10-ccar-import-in-view
    23508 09:40:34 EDT timeout F4c1r-c1r-mut-v200-u10-reapply-keeps-plan-settings
    23510 09:40:34 EDT node F4c1r-c1r-mut-v200-u10-reapply-keeps-plan-settings
    23836 09:41:09 EDT timeout F5-c2-mut-v200-u10-dest-add-in-view
    23839 09:41:09 EDT node F5-c2-mut-v200-u10-dest-add-in-view
    24036 09:41:22 EDT timeout F4c1r-c1r-mut-v200-u10-reapply-keeps-pmos
    24039 09:41:22 EDT node F4c1r-c1r-mut-v200-u10-reapply-keeps-pmos
    24404 09:41:58 EDT timeout F5-c2-mut-v200-u10-dest-change-in-view
    24407 09:41:58 EDT node F5-c2-mut-v200-u10-dest-change-in-view
    24482 09:42:00 EDT timeout F4c1r-c1r-mut-v200-u10-reapply-keeps-years
    24485 09:42:00 EDT node F4c1r-c1r-mut-v200-u10-reapply-keeps-years
    24514 09:42:03 EDT timeout P6-cycdel-on-c2
    24516 09:42:03 EDT node P6-cycdel-on-c2
    24603 09:42:08 EDT timeout P6-cycdel-on-base
    24606 09:42:08 EDT node P6-cycdel-on-base
    25183 09:42:39 EDT timeout F4c1r-c1r-mut-v200-u10-reapply-older-keeps-list
    25187 09:42:40 EDT node F4c1r-c1r-mut-v200-u10-reapply-older-keeps-list
    25298 09:42:45 EDT timeout F5-c2-mut-v200-u10-dest-change-no-redraw
    25300 09:42:45 EDT node F5-c2-mut-v200-u10-dest-change-no-redraw
    25773 09:43:16 EDT timeout N2-check-c1r
    25775 09:43:16 EDT node N2-check-c1r
    25870 09:43:20 EDT timeout F4c1r-c1r-mut-v200-u10-reapply-working-base
    25873 09:43:20 EDT node F4c1r-c1r-mut-v200-u10-reapply-working-base
    25918 09:43:23 EDT timeout N2-check-c2
    25924 09:43:23 EDT node N2-check-c2
    26049 09:43:31 EDT timeout N2-check-base
    26052 09:43:31 EDT node N2-check-base
    26222 09:43:44 EDT timeout F5-c2-mut-v200-u10-dest-remove-in-view
    26224 09:43:44 EDT node F5-c2-mut-v200-u10-dest-remove-in-view
    26633 09:44:15 EDT timeout F4c1r-c1r-mut-v200-u10-reapply-wrong-year
    26635 09:44:15 EDT node F4c1r-c1r-mut-v200-u10-reapply-wrong-year
    27125 09:44:55 EDT timeout F5-c2-mut-v200-u10-dest-reset-in-view
    27128 09:44:55 EDT node F5-c2-mut-v200-u10-dest-reset-in-view
    27450 09:45:09 EDT timeout F4c1r-c1r-mut-v200-u10-reapply-year-only
    27452 09:45:09 EDT node F4c1r-c1r-mut-v200-u10-reapply-year-only
    28000 09:46:07 EDT timeout F4c1r-c1r-mut-vt-field-codes
    28003 09:46:07 EDT node F4c1r-c1r-mut-vt-field-codes
    28079 09:46:12 EDT timeout F5-c2-mut-v200-u10-reapply-first-year
    28082 09:46:12 EDT node F5-c2-mut-v200-u10-reapply-first-year
    28839 09:47:01 EDT timeout bx:mutchunk-c1r-01
    28858 09:47:01 EDT timeout F4c1r-c1r-mut-vt-field-rcn
    28843 09:47:01 EDT mutruns-fix2.sh bx:mutchunk-c1r-01
    28860 09:47:01 EDT node F4c1r-c1r-mut-vt-field-rcn
    29197 09:47:21 EDT timeout bx:mutchunk-c2rest-00
    29208 09:47:21 EDT timeout F5-c2-mut-v200-u10-reapply-keeps-list
    29199 09:47:21 EDT mutruns-fix2.sh bx:mutchunk-c2rest-00
    29213 09:47:21 EDT node F5-c2-mut-v200-u10-reapply-keeps-list
    29496 09:47:42 EDT timeout F4c1r-c1r-mut-vt-inline-no-base
    29498 09:47:42 EDT node F4c1r-c1r-mut-vt-inline-no-base
    30097 09:48:18 EDT timeout F5-c2-mut-v200-u10-reapply-keeps-plan-settings
    30101 09:48:18 EDT node F5-c2-mut-v200-u10-reapply-keeps-plan-settings
    30263 09:48:30 EDT timeout F4c1r-c1r-mut-vt-inline-no-kept-list
    30266 09:48:30 EDT node F4c1r-c1r-mut-vt-inline-no-kept-list
    30878 09:49:21 EDT timeout F4c1r-c1r-mut-vt-keeps-bands
    30880 09:49:21 EDT node F4c1r-c1r-mut-vt-keeps-bands
    31005 09:49:33 EDT timeout F5-c2-mut-v200-u10-reapply-keeps-pmos
    31007 09:49:33 EDT node F5-c2-mut-v200-u10-reapply-keeps-pmos
    31603 09:50:15 EDT timeout F4c1r-c1r-mut-vt-keeps-ccaridx
    31607 09:50:15 EDT node F4c1r-c1r-mut-vt-keeps-ccaridx
    31968 09:50:43 EDT timeout F5-c2-mut-v200-u10-reapply-keeps-years
    31970 09:50:43 EDT node F5-c2-mut-v200-u10-reapply-keeps-years
    32306 09:51:11 EDT timeout F4c1r-c1r-mut-vt-keeps-flow
    32308 09:51:11 EDT node F4c1r-c1r-mut-vt-keeps-flow
    761 09:52:03 EDT timeout F5-c2-mut-v200-u10-reapply-older-keeps-list
    765 09:52:03 EDT node F5-c2-mut-v200-u10-reapply-older-keeps-list
    818 09:52:07 EDT timeout F4c1r-c1r-mut-vt-noapply
    822 09:52:07 EDT node F4c1r-c1r-mut-vt-noapply
    1236 09:52:52 EDT timeout F4c1r-c1r-mut-vt-rcnset-upfront
    1239 09:52:52 EDT node F4c1r-c1r-mut-vt-rcnset-upfront
    1406 09:53:04 EDT timeout bx:mutchunk-c2rest-01
    1414 09:53:04 EDT mutruns-fix2.sh bx:mutchunk-c2rest-01
    1431 09:53:04 EDT timeout F5-c2-mut-v200-u10-reapply-working-base
    1434 09:53:04 EDT node F5-c2-mut-v200-u10-reapply-working-base
    1862 09:53:38 EDT timeout F4c1r-c1r-mut-vt-reopen-view
    1865 09:53:38 EDT node F4c1r-c1r-mut-vt-reopen-view
    2235 09:54:04 EDT timeout F5-c2-mut-v200-u10-reapply-wrong-year
    2237 09:54:04 EDT node F5-c2-mut-v200-u10-reapply-wrong-year
    2505 09:54:31 EDT timeout F4c1r-c1r-mut-vt-shallow-stash
    2508 09:54:32 EDT node F4c1r-c1r-mut-vt-shallow-stash
    2970 09:55:10 EDT timeout F5-c2-mut-v200-u10-reapply-year-only
    2972 09:55:10 EDT node F5-c2-mut-v200-u10-reapply-year-only
    3158 09:55:30 EDT timeout bx:suites3-recon-c2
    3181 09:55:31 EDT timeout S3-audit-recon-c2
    3164 09:55:31 EDT suites3.sh bx:suites3-recon-c2
    3187 09:55:31 EDT node S3-audit-recon-c2
    3698 09:56:02 EDT timeout F5-c2-mut-ow-ace-after-prompt
    3700 09:56:02 EDT node F5-c2-mut-ow-ace-after-prompt
    4312 09:57:03 EDT timeout F5-c2-mut-ow-ccar-quiet
    4315 09:57:03 EDT node F5-c2-mut-ow-ccar-quiet
    6233 09:59:53 EDT timeout bx:mutchunk-c2rest-02
    6236 09:59:53 EDT mutruns-fix2.sh bx:mutchunk-c2rest-02
    6243 09:59:53 EDT timeout F5-c2-mut-ow-del-after-confirm
    6246 09:59:53 EDT node F5-c2-mut-ow-del-after-confirm
    6263 09:59:53 EDT timeout bx:suites3-recon-c1r
    6267 09:59:53 EDT suites3.sh bx:suites3-recon-c1r
    6287 09:59:53 EDT timeout S3-audit-recon-c1r
    6289 09:59:53 EDT node S3-audit-recon-c1r
    7049 10:01:04 EDT timeout F5-c2-mut-vt-field-codes
    7054 10:01:04 EDT node F5-c2-mut-vt-field-codes
    7945 10:02:21 EDT timeout F5-c2-mut-vt-field-rcn
    7948 10:02:21 EDT node F5-c2-mut-vt-field-rcn
    8669 10:03:22 EDT timeout F5-c2-mut-vt-inline-no-base
    8672 10:03:22 EDT node F5-c2-mut-vt-inline-no-base
    9282 10:04:18 EDT timeout bx:suites3-recon-base
    9290 10:04:18 EDT timeout S3-audit-recon-base
    9292 10:04:18 EDT node S3-audit-recon-base
    9284 10:04:18 EDT suites3.sh bx:suites3-recon-base
    9374 10:04:26 EDT timeout F5-c2-mut-vt-inline-no-kept-list
    9377 10:04:26 EDT node F5-c2-mut-vt-inline-no-kept-list
    9872 10:05:30 EDT timeout bx:mutchunk-c2rest-03
    9875 10:05:30 EDT mutruns-fix2.sh bx:mutchunk-c2rest-03
    9884 10:05:30 EDT timeout F5-c2-mut-vt-keeps-bands
    9887 10:05:30 EDT node F5-c2-mut-vt-keeps-bands
    10395 10:06:32 EDT timeout F5-c2-mut-vt-keeps-ccaridx
    10397 10:06:32 EDT env F5-c2-mut-vt-keeps-ccaridx
    10886 10:07:32 EDT timeout F5-c2-mut-vt-keeps-flow
    10888 10:07:32 EDT node F5-c2-mut-vt-keeps-flow
    10924 10:07:34 EDT timeout bx:suites3-c2-a
    10932 10:07:34 EDT timeout S3-boot-same-c2
    10934 10:07:34 EDT node S3-boot-same-c2
    10925 10:07:34 EDT suites3.sh bx:suites3-c2-a
    11193 10:08:00 EDT timeout S3-audit-c2
    11197 10:08:00 EDT node S3-audit-c2
    11452 10:08:22 EDT timeout S3-audit-ppt-c2
    11455 10:08:22 EDT node S3-audit-ppt-c2
    11541 10:08:33 EDT timeout S3-audit-other-c2
    11543 10:08:33 EDT node S3-audit-other-c2
    11709 10:08:50 EDT timeout F5-c2-mut-vt-noapply
    11711 10:08:50 EDT node F5-c2-mut-vt-noapply
    12233 10:09:46 EDT timeout bx:suites3-c2-b
    12236 10:09:46 EDT suites3.sh bx:suites3-c2-b
    12241 10:09:46 EDT timeout S3-legacy-fsrc-c2
    12246 10:09:46 EDT node S3-legacy-fsrc-c2
    12382 10:09:52 EDT timeout S3-audit-hostile-c2
    12385 10:09:52 EDT node S3-audit-hostile-c2
    12453 10:09:58 EDT timeout F5-c2-mut-vt-rcnset-upfront
    12456 10:09:58 EDT node F5-c2-mut-vt-rcnset-upfront
    13199 10:11:16 EDT timeout bx:mutchunk-c2rest-04
    13202 10:11:16 EDT mutruns-fix2.sh bx:mutchunk-c2rest-04
    13223 10:11:16 EDT timeout F5-c2-mut-vt-reopen-view
    13229 10:11:16 EDT node F5-c2-mut-vt-reopen-view
    13561 10:11:37 EDT timeout S3-audit-inject-c2
    13563 10:11:37 EDT node S3-audit-inject-c2
    13840 10:12:03 EDT timeout bx:suites3-base-a
    13843 10:12:03 EDT suites3.sh bx:suites3-base-a
    13850 10:12:03 EDT timeout S3-boot-same-base
    13853 10:12:03 EDT node S3-boot-same-base
    14079 10:12:28 EDT timeout S3-audit-other-base
    14085 10:12:28 EDT node S3-audit-other-base
    14147 10:12:32 EDT timeout F5-c2-mut-vt-shallow-stash
    14150 10:12:32 EDT node F5-c2-mut-vt-shallow-stash
    14915 10:13:44 EDT timeout F5-c2-mut-vt-wrong-year-state
    14917 10:13:44 EDT node F5-c2-mut-vt-wrong-year-state
    15024 10:13:52 EDT timeout bx:mkmut-near-v200-bae-depts-raw
    15026 10:13:52 EDT python3 bx:mkmut-near-v200-bae-depts-raw
    15039 10:13:53 EDT timeout bx:mkmut-near-v200-fname-ace-raw
    15042 10:13:53 EDT python3 bx:mkmut-near-v200-fname-ace-raw
    15050 10:13:53 EDT timeout bx:mkmut-near-v200-ace-key-open
    15052 10:13:53 EDT python3 bx:mkmut-near-v200-ace-key-open
    15063 10:13:54 EDT timeout S3-audit-inject-c2-mut-v200-bae-depts-raw
    15066 10:13:54 EDT node S3-audit-inject-c2-mut-v200-bae-depts-raw
    15266 10:14:17 EDT timeout S3-audit-inject-c2-mut-v200-fname-ace-raw
    15269 10:14:17 EDT node S3-audit-inject-c2-mut-v200-fname-ace-raw
    15549 10:14:43 EDT timeout S3-audit-inject-c2-mut-v200-ace-key-open
    15551 10:14:43 EDT node S3-audit-inject-c2-mut-v200-ace-key-open
    15672 10:14:56 EDT timeout B3-ppbe-on-c2
    15675 10:14:56 EDT node B3-ppbe-on-c2
    15895 10:15:19 EDT timeout I3-r3-on-c2
    15898 10:15:19 EDT node I3-r3-on-c2
    16252 10:15:51 EDT timeout I3-w3-on-c2
    16254 10:15:51 EDT node I3-w3-on-c2
```

## Drafts for the lead (this round; they SUPERSEDE `drafts/NEXT-VERSION-U10.md` and `drafts/LEDGER-U10.md`)

- `drafts/NEXT-VERSION-U10-fix.md`: the entries for commit 1 and commit 2, and the replacement for U10's line under
  "Unresolved after R1–R5" (one text if both land, one if commit 1 lands alone).
- `drafts/LEDGER-U10-fix.md`: the text to append to row U10 (`<sha1>`, `<sha2>`, `<time>` placeholders) and two new rows
  (allowed-and-kept edits in a view; a locked cycle's PMO list). The build's drafted row (a destination renamed in a view,
  put as a decision) is withdrawn: commit 2 refuses it.

## Blobs (git hash-object) of this round's files

| file | blob |
|---|---|
| c1r board / audit-recon / mutate.mjs.txt | `4a8b0be3…` / `746dac83…` / `c6c1ea47…` |
| c2 board / audit-recon / mutate.mjs.txt | `cfc9e14f…` / `2c4c466a…` / `3a408399…` |
| block-u10-beside.mjs.txt (commit 1; in c2 its CCaR comment is 4 lines) | `45d58a25` |
| block-u10-lists.mjs.txt (commit 2) | `96a0fe0e` |
| entries-u10-c1r.mjs.txt / entries-u10-c2.mjs.txt | `5516934c` / `e500a275` |
| harness/c1r/focused-u10.mjs / harness/c2/focused-u10.mjs | `cec69f35` / `318d7998` |
| probe3/u10-lists.mjs / u10-flowdest.mjs / u10-cycdel.mjs | `6470115b` / `d8ac0317` / `8879eb65` |
| bin/edit-board-c2.py / bin/ownmuts.py | `b106448b` / `9251f087` |
| drafts/NEXT-VERSION-U10-fix.md / drafts/LEDGER-U10-fix.md | `df8c2f70` / `4d25e0f5` |

## The diffs of this round, exact (also in `diffs/`)

### `diffs/c1r-vs-c1.audit-recon.mjs.diff`

```diff
--- a/tools/export-audit/audit-recon.mjs
+++ b/tools/export-audit/audit-recon.mjs
@@ -5277,9 +5277,11 @@
     const rv = (() => { try { return R.ev(`cycView(${J(key)}); (function(){ if(!rcnOpen) toggleRcn(); var el=[].slice.call(document.querySelectorAll('#rcnBody input')).filter(function(e){
       return (e.getAttribute('onchange')||'').indexOf('rcnSet(0,"rcn"')===0; })[0]; if(!el) return 'no control'; el.value='77777'; el.dispatchEvent(new Event('change', {bubbles:true}));
       return 'fired'; })()`); } catch (e) { return 'threw'; } })();
+    // the status line is read at once: 'Not kept' is put in front of a message for 1.5 s after a refusal, and the exports write their own
+    const rk = /the change was not kept|Not kept/.test(R.ev(`(document.getElementById('shareStat')||{}).textContent||''`));
     const rx = await exportsOf(R.w);
     w5Chk(name, 'the record’s steps: saved, reopened, PB27 viewed, 77777 typed', 'refused; RCN-EEIC by Month, the Spend Plan Source and the ACE tie-out (on its own year, FY27, as a reopened board shows it) carry the cycle’s own codes; no cell names 77777',
-      J([rv, /the change was not kept|Not kept/.test(R.ev(`(document.getElementById('shareStat')||{}).textContent||''`)), rx]),
+      J([rv, rk, rx]),
       J(['fired', true, Object.assign({}, LOCKED, { alignment: ALIGN('FY27'), mapping: MAP('FY27') })]));
     // ---- CONTROL: the working plan, no view -- an edit is allowed, and every export carries it
     fire('K4', 'rcn', '55555'); ev(`if(rcnOpen) toggleRcn(); 'ok'`);
@@ -5299,9 +5301,9 @@
     // ---- A CYCLE LOCKED BEFORE v1.99 kept no list (item 88's own reading of one: the lock's list taken away), so its view reads
     // today's -- 99999 / ZZZZZ, 22222 / BBBBB, 55555 / DDDDD. 77777 typed into K1's field there is refused like any other.
     ev(`delete blGet(${J(key)}).rcn; 'ok'`);
-    view(); const fo = fire('K1', 'rcn', '77777'), o = await exportsNow();
+    view(); const fo = fire('K1', 'rcn', '77777'), fk = notKept(), o = await exportsNow();
     w5Chk(name, 'a cycle locked before v1.99, viewed · RCN 77777 typed into K1’s field', 'refused; the view’s list and RCN-EEIC by Month are today’s list as it is',
-      J([fo, notKept(), reg(), o.summary.filter(r => r[0] === 'USAF').map(r => r[1])]),
+      J([fo, fk, reg(), o.summary.filter(r => r[0] === 'USAF').map(r => r[1])]),
       J(['fired', true, [['99999', 'ZZZZZ', '', 'USAF+ANG+AFRC'], ['22222', 'BBBBB', '', 'ANG'], ['55555', 'DDDDD', '', 'USAF+ANG+AFRC']], [WK, W5, N, 'USAF TOTAL']]));
     leave();
     w5Chk(name, 'harness', 'CONTROL — no jsdom script errors on either board', J([X.errors.length, R.errors.length]), J([0, 0]));
@@ -5312,6 +5314,98 @@
   await settleBoards();
 })();
 // ==== end v2.00 (U10) ====
+// ==== v2.00 (U10, beside the codes): a refusal in a locked view puts back the plan's settings, the year on screen, the CCaR records and the base year ====
+// The U10 block above reads the codes. A refusal makes the whole copy again, so what the board keeps beside the codes comes back
+// with it, and this block reads that in the exports (the U10 round-1 test review's cases, 13 Oct). On v1.98 item 83's board with
+// every requirement in band 0, PB27 locked and viewed: band 0 renamed (bandSet, the handler the ✎ prompt calls) and the funds-flow
+// axis set to destinations (flowSetAxis), each refused. A held year that is not a copy of the first: PB27's FY28 files R on K4,
+// 77777 typed there. A CCaR Records file imported in the view (its Title and OPR are kept beside the years, in MS.ccarIdx, and the
+// Spend Plan Source prints them). The cycle's own FYDP window after a refusal, when the working plan's base year has moved on.
+// FAILS ON 7ee498a (board fce8a391): the workbook names band 0 RENAMED BAND, the funds-flow export is cut by destination, and the
+// Spend Plan Source titles R and Q REFUSED TITLE R / Q with OPR REFUSED OPR. The FY28 case fails there too (77777 stays in the
+// view's list, and RCN-EEIC by Month files K1's money under 77777). CONTROLS: nothing changed; nothing imported; the same CCaR
+// file imported on the working plan, which the Source prints; the cycle's FYDP window (the year-only put-back never touched the
+// base year); no jsdom errors. Every name, code and figure expected is typed here.
+await (async () => {
+  const name = 'v2.00 (U10) — a refusal in a locked view puts back the plan’s settings, the year on screen, the CCaR records and the cycle’s base year';
+  const { bootMark, bootRelease, settleBoards } = await import('./boot.mjs');
+  const __bm = bootMark();
+  try {
+    const J = JSON.stringify;
+    const X = v198Board(`S.band={PRIME_P:BANDS_LIST()[0].id, R:BANDS_LIST()[0].id, Q:BANDS_LIST()[0].id};`);
+    const ev = c => { try { return X.ev(c); } catch (e) { return 'threw: ' + String((e && e.message) || e).slice(0, 100); } };
+    const key = ev(`window.confirm=function(){ return true; }; MS.base=MS.cur; MS.years[MS.cur]=S; save(); blCyc='PB'; blYr=MS.cur; cycLock(); blKey('PB', MS.cur)`);
+    const notKept = () => /the change was not kept|Not kept/.test(ev(`(document.getElementById('shareStat')||{}).textContent||''`));
+    const bandCells = async () => { const bk = JSON.parse(await w6Book(X.w, 'exportExcel')), o = [];
+      Object.keys(bk).filter(k => !k.startsWith('__')).forEach(sh => (bk[sh] || []).forEach(r => (r || []).forEach(c => {
+        const t = String(c ?? '').trim(); if (/NET FUNDING AVAILABLE|RENAMED/i.test(t)) o.push(sh + ': ' + t); }))); return [bk.__err || 'ok', o]; };
+    const flowSheets = async () => { const bk = JSON.parse(await w6Book(X.w, 'exportFlow')); return [bk.__err || 'ok', Object.keys(bk).filter(k => !k.startsWith('__'))]; };
+    ev(`cycView(${J(key)}); 'ok'`);
+    const b0 = await bandCells(), f0 = await flowSheets();
+    ev(`bandSet(0,'n','RENAMED BAND'); 'ok'`); const nk1 = notKept(), b1 = await bandCells();
+    ev(`flowSetAxis('dest'); 'ok'`); const nk2 = notKept(), f1 = await flowSheets();
+    ev(`cycLeave(); 'ok'`);
+    // band 0 as the workbook prints it, and the funds-flow sheets cut by what the money buys: typed here
+    const BANDS = ['ok', ['Decision Bands: Net Funding Available', 'Decision Bands: BAND 0 — NET FUNDING AVAILABLE  ·  fund in full  ·  counts toward the stoppage gap  ·  organization standard  ·  3 requirements',
+      'Decision Bands: Net Funding Available', 'Decision Bands: Net Funding Available', 'Decision Bands: Net Funding Available']];
+    const FLOW = ['ok', ['Funds Flow', 'Prime Detail', 'OGC Detail', 'Workforce & Travel', 'Depot, Repair & Materiel', 'Software, IT & Cyber', 'Engineering, Projects & Stud', 'Program Operations & Support']];
+    w5Chk(name, 'PB27 viewed, nothing changed', 'CONTROL — the workbook names band 0 as locked, and the funds-flow export is cut by what the money buys', J([b0, f0]), J([BANDS, FLOW]));
+    w5Chk(name, 'PB27 viewed · band 0 renamed RENAMED BAND (refused)', 'refused and said so; the workbook still names band 0 as it was locked', J([nk1, b1]), J([true, BANDS]));
+    w5Chk(name, 'PB27 viewed · funds-flow axis set to destinations (refused)', 'refused and said so; the funds-flow export is still cut by what the money buys', J([nk2, f1]), J([true, FLOW]));
+    // A HELD YEAR THAT DIFFERS FROM THE ONE THE VIEW OPENS ON: PB27's FY28 files R on K4 (FY27 files it on K1). The U10 block's FY28 is a
+    // copy of FY27, so a refusal that put FY27's plan in FY28's place would read the same there. By hand (item 83's table, R on K4 in FY28):
+    // USAF -- K1 401 (CLIN 0001's standard), K4 802 (CLIN 0002's 299 + R's 503), none 71 (Q), total 1274.
+    const Y = v198Board(`S.rcnAsg={PRIME_P:'K4', R:'K1'}; S.rcnSvc={PRIME_P:{ANG:'K2'}, R:{ANG:'K2'}}; S.clinRcn={PRIME_P:{n1:'K1'}};`);
+    const yv = c => { try { return Y.ev(c); } catch (e) { return 'threw: ' + String((e && e.message) || e).slice(0, 100); } };
+    const k2 = yv(`window.confirm=function(){ return true; }; MS.base=MS.cur; MS.years[MS.cur]=S; MS.years[MS.cur+1]=JSON.parse(JSON.stringify(S));
+      MS.years[MS.cur+1].rcnAsg={PRIME_P:'K4', R:'K4'}; save(); blCyc='PB'; blYr=MS.cur; cycLock(); blKey('PB', MS.cur)`);
+    yv(`cycView(${J(k2)}); switchYear(MS.cur+1); if(!rcnOpen) toggleRcn(); (function(){ var i=rcnReg().findIndex(function(e){ return e.k==='K1'; });
+      var el=[].slice.call(document.querySelectorAll('#rcnBody input')).filter(function(e){ return (e.getAttribute('onchange')||'').indexOf('rcnSet('+i+',"rcn"')===0; })[0];
+      el.value='77777'; el.dispatchEvent(new Event('change', {bubbles:true})); })(); 'ok'`);
+    const yk = /the change was not kept|Not kept/.test(yv(`(document.getElementById('shareStat')||{}).textContent||''`)), ycur = yv('MS.cur');
+    const ybk = JSON.parse(await w6Book(Y.w, 'exportExcel')), yrc = ybk['RCN-EEIC by Month'] || [];
+    const yreq = yrc.findIndex(r => w6Lbl(r) === 'WHICH REQUIREMENTS SIT UNDER EACH COMBINATION');
+    const ysum = v198Sec(yrc, 0, yreq).filter(r => r[0] === 'USAF').map(r => r.slice(0, 3));
+    yv(`if(rcnOpen) toggleRcn(); cycLeave(); 'ok'`);
+    w5Chk(name, 'PB27 viewed · FY28 (R on K4) on screen, RCN 77777 typed into K1’s field', 'refused; still FY28, and RCN-EEIC by Month files FY28’s USAF money as FY28 holds it',
+      J([yk, ycur, ysum]), J([true, 2028, [['USAF', '11111 / AAAAA', 401], ['USAF', '44444 / DDDDD', 802], ['USAF', v198NONE, 71], ['USAF', 'USAF TOTAL', 1274]]]));
+    // A CCaR RECORDS FILE IMPORTED WHILE PB27 IS ON SCREEN. R and Q carry CCaR numbers CCR and CCQ (the suite's it()); the import writes
+    // the index the working plan keeps beside its years, then saves, which the view refuses. By hand: the Spend Plan Source's Title column
+    // is the requirement's own name ("Ev R", "Ev Q") and its OPR blank until a records file is kept.
+    const CCAR = (t, o) => J([['CCaR No', 'Title', 'OPR', 'PMO', 'Control No'], ['CCR', t + ' R', o, 'AV', '7001'], ['CCQ', t + ' Q', o, 'AV', '7002']]);
+    const ccarImp = rows => X.w.eval(`(async function(){ var b=buildXlsx([{name:'CCaR', cols:[12,30,14,8,10], rows:${rows}}]);
+      var ab=b.buffer.slice(b.byteOffset, b.byteOffset+b.byteLength);
+      await importCcarRecs({files:[{name:'ccar-records.xlsx', arrayBuffer:async function(){ return ab; }}]}); return 'ok'; })()`);
+    const srcTitles = async () => { const sb = JSON.parse(await w6Book(X.w, 'exportSrc'));
+      const s = Object.keys(sb).filter(k => !k.startsWith('__')).map(k => sb[k]).find(rs => Array.isArray(rs) && rs.length > 1) || [], seen = {};
+      s.slice(1).forEach(r => { const k = String((r || [])[2] ?? ''); if (k === 'CCR' || k === 'CCQ') seen[[k, String(r[3] ?? ''), String(r[12] ?? '')].join(' | ')] = 1; });
+      return [sb.__err || 'ok', String((s[0] || [])[3] ?? ''), String((s[0] || [])[12] ?? ''), Object.keys(seen).sort()]; };
+    ev(`cycView(${J(key)}); 'ok'`);
+    const s0 = await srcTitles();
+    await ccarImp(CCAR('REFUSED TITLE', 'REFUSED OPR')); const nk3 = notKept(), s1 = await srcTitles();
+    ev(`cycLeave(); 'ok'`);
+    await ccarImp(CCAR('RECORD TITLE', 'RECORD OPR')); const s2 = await srcTitles();
+    const SRC0 = ['ok', 'Title', 'OPR', ['CCQ | Ev Q | ', 'CCR | Ev R | ']];
+    w5Chk(name, 'PB27 viewed, nothing imported', 'CONTROL — the Spend Plan Source titles R and Q by their own names, OPR blank', J(s0), J(SRC0));
+    w5Chk(name, 'PB27 viewed · CCaR Records file imported (refused)', 'refused and said so; the Spend Plan Source still titles R and Q by their own names, OPR blank', J([nk3, s1]), J([true, SRC0]));
+    w5Chk(name, 'the working plan · the same file imported (allowed)', 'CONTROL — the Spend Plan Source prints the records’ Title and OPR',
+      J(s2), J(['ok', 'Title', 'OPR', ['CCQ | RECORD TITLE Q | RECORD OPR', 'CCR | RECORD TITLE R | RECORD OPR']]));
+    // THE CYCLE'S OWN BASE YEAR. The working plan's FYDP window moves on after the lock (base FY28); PB27 was locked on FY27.
+    // By hand: the view's window is FY27-FY31 before and after a refusal; the working plan's is FY28-FY32 with FY27 (on screen) beside it.
+    ev(`MS.base=MS.cur+1; save(); cycView(${J(key)}); 'ok'`);
+    const w0 = ev('JSON.stringify(fydpWindow())');
+    ev(`bandSet(0,'n','RENAMED AGAIN'); 'ok'`); const nk4 = notKept(), w1 = ev('JSON.stringify(fydpWindow())');
+    ev(`cycLeave(); 'ok'`); const w2 = ev('JSON.stringify(fydpWindow())');
+    w5Chk(name, 'working base year moved to FY28 · PB27 viewed · band 0 renamed (refused)', 'CONTROL — the view keeps the cycle’s FYDP window FY27–FY31 after the refusal; the working plan’s is FY28–FY32',
+      J([w0, nk4, w1, w2]), J(['[2027,2028,2029,2030,2031]', true, '[2027,2028,2029,2030,2031]', '[2027,2028,2029,2030,2031,2032]']));
+    w5Chk(name, 'harness', 'CONTROL — no jsdom script errors', J([X.errors.length, Y.errors.length]), J([0, 0]));
+  } catch (e) {
+    failures.push({ scenario: name, where: 'harness', what: 'the block threw: ' + String((e && e.message) || e).slice(0, 160), got: 'threw', want: 'ran' });
+  }
+  bootRelease(__bm, []);
+  await settleBoards();
+})();
+// ==== end v2.00 (U10, beside the codes) ====
 
 {
   const src = _selfRead(_selfPath(import.meta.url), 'utf8');
```

### `diffs/c1r-vs-c1.mutate.mjs.txt.diff`

```diff
--- a/tools/export-audit/mutate.mjs.txt
+++ b/tools/export-audit/mutate.mjs.txt
@@ -4305,6 +4305,17 @@
   { id: "v200-u10-reapply-older-keeps-list", area: "cycReapply", what: "the view's copy is made again, but a cycle locked before v1.99 (no list kept, so its view reads today's) keeps the refused copy's list: 77777 typed into its RCN field stays in the view and RCN-EEIC by Month prints 77777 / ZZZZZ",
     find: "  MS=cycCopy(c); MS.cur=y;",
     repl: "  const L0=MS.rcn; MS=cycCopy(c); MS.cur=y; if(!cycRcnOf(c)) MS.rcn=L0;" },
+  // v2.00 (U10, the round-1 test review of 13 Oct): what a refusal puts back beside the codes -- the year on screen, the plan's settings,
+  // the cycle's base year.
+  { id: "v200-u10-reapply-wrong-year", area: "cycReapply", what: "a refusal while FY28 is on screen stays on FY28 but puts the plan of the year the view opened on (FY27) in its place: with R on K4 in PB27's FY28, 77777 typed there leaves RCN-EEIC by Month filing R's USAF $503 under 11111 / AAAAA (USAF K1 $904, K4 $299 instead of $401 and $802)",
+    find: "  MS=cycCopy(c); MS.cur=y;\n  applyState(MS.years[y]); MS.years[y]=S;",
+    repl: "  MS=cycCopy(c); MS.cur=y;\n  applyState(JSON.parse(JSON.stringify(MS.years[+_cycStash.MS.cur]||MS.years[y]))); MS.years[y]=S;" },
+  { id: "v200-u10-reapply-keeps-plan-settings", area: "cycReapply", what: "the view's copy is made again but keeps the refused copy's band ladder and funds-flow settings: band 0 renamed in PB27's view is printed RENAMED BAND in the workbook, and the funds-flow axis set to destinations cuts the funds-flow export by destination, after the board said the change was not kept",
+    find: "  MS=cycCopy(c); MS.cur=y;",
+    repl: "  const B0=MS.bands, F0=MS.flow; MS=cycCopy(c); MS.cur=y; MS.bands=B0; MS.flow=F0;" },
+  { id: "v200-u10-reapply-working-base", area: "cycReapply", what: "the view's copy is made again on the working plan's base year, not the cycle's: with the working base moved to FY28 after PB27 was locked on FY27, a refusal in PB27's view moves its FYDP window to FY28-FY32",
+    find: "  MS=cycCopy(c); MS.cur=y;",
+    repl: "  MS=cycCopy(c); MS.cur=y; MS.base=_cycStash.MS.base;" },
   // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.
   { id: "v200-r3-landed-view-unsaid", area: "_driveStorePushRun", what: "a folder save that lands while a locked view is on screen says “🔒 Not kept — PB27 is a locked view. ✅ Saved …” again, naming no plan (or, quiet, leaves persist's refusal on screen)",
     find: "  if(CYCVIEW){ _cycRefusedAt=0; setStat('✅ <b>Saved the working plan</b> of '+esc(APPN_LBL[ap]||ap)+' FY'+(fy%100)+' to the shared folder — '\n    +Math.round(body.length/1024)+' KB, built before '+blLbl(CYCVIEW)+' was put on screen. '+blLbl(CYCVIEW)+' is a locked view: nothing in it '\n    +'is saved. Everyone sees the working plan on their next refresh.'+penNote+lateNote); render(); return true; }\n",
```

### `diffs/c2-vs-c1r.prioritization-board-grid.html.diff`

```diff
--- a/prioritization-board-grid.html
+++ b/prioritization-board-grid.html
@@ -14204,6 +14204,9 @@
 async function importBud(inp){
   const f=inp.files&&inp.files[0];
   if(!f) return;
+  // v2.00 (U10): REFUSED BEFORE THE FILE IS READ while a locked cycle is on screen. The budget list is every appropriation's and
+  // no part of the view's copy, so a list imported in a view was stored, and reached every export, while the board said "Not kept".
+  if(cycBlock('Importing a BAE budget list')){ inp.value=''; return; }
   try{
     setStat('💰 Reading '+esc(f.name)+'…');
     const sheets=await xlsxRead(await f.arrayBuffer());
@@ -14447,6 +14450,9 @@
 async function importCcarRecs(inp){
   const f=inp.files&&inp.files[0];
   if(!f) return;
+  // v2.00 (U10): refused before the file is read while a locked cycle is on screen. The refusal dropped the index anyway, and the
+  // line then counted titles found and said "Save to bake this into the file".
+  if(cycBlock('Importing CCaR records')){ inp.value=''; return; }
   try{
     setStat('📇 Reading '+esc(f.name)+'…');
     const sheets=await xlsxRead(await f.arrayBuffer());
@@ -14507,6 +14513,10 @@
 async function importAce(inp){
   const f=inp.files&&inp.files[0];
   if(!f) return;
+  // v2.00 (U10): refused before the file is read while a locked cycle is on screen. The estimates are every appropriation's and no
+  // part of the view's copy: one imported in a view was stored -- an approved one replaced -- and every tie-out changed, while the
+  // board said "Not kept".
+  if(cycBlock('Importing a cost estimate')){ inp.value=''; return; }
   try{
     setStat('\ud83d\udcc8 Reading '+esc(f.name)+'\u2026');
     const sheets=await xlsxRead(await f.arrayBuffer());
@@ -15113,6 +15123,10 @@
 function flowEntUseElse(k, M){ return ((M||flowEntUseMap())[k])||{}; }
 function flowEntUseElseTxt(U){ return Object.keys(U).map(function(w){ return w+' ('+U[w]+')'; }).join(', '); }
 function flowSetEnt(i, field, v){
+  // v2.00 (U10): THE DESTINATION LIST IS EVERY APPROPRIATION'S, and no part of a locked view's copy. Each change to it is refused
+  // up front while one is on screen: it was kept while the board said it was not, and a destination removed in a view left the
+  // working plan's requirements pointing at nothing.
+  if(cycBlock('Changing a destination')){ render(); return; }
   const L=flowEnts(), e=L[i]; if(!e) return;
   if(field==='kind'){ e.kind=(v==='prime'?'prime':(v==='gov'?'gov':'other'));
     DESTDB.conflicts=DESTDB.conflicts.filter(function(c){ return c.k!==e.k; }); }
@@ -15120,6 +15134,7 @@
   persistDest(); save(); render();
 }
 function flowAddEnt(){
+  if(cycBlock('Adding a destination')){ render(); return; }   // v2.00 (U10): as flowSetEnt
   const L=flowEnts();
   L.push({k:destNewKey(), n:'New destination', kind:'other', t:''});
   persistDest(); save(); render();
@@ -15128,6 +15143,7 @@
     +'want the chart to recognise it in the source file as well.');
 }
 function flowDelEnt(i){
+  if(cycBlock('Removing a destination')){ render(); return; }   // v2.00 (U10): as flowSetEnt
   const L=flowEnts(), e=L[i]; if(!e) return;
   const used=flowEntUse(e.k), elsewhere=flowEntUseElse(e.k);
   if(Object.keys(elsewhere).length){
@@ -15163,6 +15179,7 @@
        +'<b>not yet assigned</b>.' : '.'));
 }
 function flowResetEnts(){
+  if(cycBlock('Resetting the destination list')){ render(); return; }   // v2.00 (U10): as flowSetEnt
   const keep={}; flowDefEnts().forEach(function(e){ keep[e.k]=1; });
   const UM=flowEntUseMap();
   const busy=flowEnts().filter(function(e){ return !keep[e.k]; })
```

### `diffs/c2-vs-c1r.audit-recon.mjs.diff`

```diff
--- a/tools/export-audit/audit-recon.mjs
+++ b/tools/export-audit/audit-recon.mjs
@@ -5369,9 +5369,10 @@
     yv(`if(rcnOpen) toggleRcn(); cycLeave(); 'ok'`);
     w5Chk(name, 'PB27 viewed · FY28 (R on K4) on screen, RCN 77777 typed into K1’s field', 'refused; still FY28, and RCN-EEIC by Month files FY28’s USAF money as FY28 holds it',
       J([yk, ycur, ysum]), J([true, 2028, [['USAF', '11111 / AAAAA', 401], ['USAF', '44444 / DDDDD', 802], ['USAF', v198NONE, 71], ['USAF', 'USAF TOTAL', 1274]]]));
-    // A CCaR RECORDS FILE IMPORTED WHILE PB27 IS ON SCREEN. R and Q carry CCaR numbers CCR and CCQ (the suite's it()); the import writes
-    // the index the working plan keeps beside its years, then saves, which the view refuses. By hand: the Spend Plan Source's Title column
-    // is the requirement's own name ("Ev R", "Ev Q") and its OPR blank until a records file is kept.
+    // A CCaR RECORDS FILE IMPORTED WHILE PB27 IS ON SCREEN. R and Q carry CCaR numbers CCR and CCQ (the suite's it()); the import wrote
+    // the index the working plan keeps beside its years, then saved, which the view refused (now it is refused before the file is read:
+    // the shared-lists block below). By hand: the Spend Plan Source's Title column is the requirement's own name ("Ev R", "Ev Q") and
+    // its OPR blank until a records file is kept.
     const CCAR = (t, o) => J([['CCaR No', 'Title', 'OPR', 'PMO', 'Control No'], ['CCR', t + ' R', o, 'AV', '7001'], ['CCQ', t + ' Q', o, 'AV', '7002']]);
     const ccarImp = rows => X.w.eval(`(async function(){ var b=buildXlsx([{name:'CCaR', cols:[12,30,14,8,10], rows:${rows}}]);
       var ab=b.buffer.slice(b.byteOffset, b.byteOffset+b.byteLength);
@@ -5406,6 +5407,151 @@
   await settleBoards();
 })();
 // ==== end v2.00 (U10, beside the codes) ====
+// ==== v2.00 (U10, the shared lists): a cost estimate, a BAE list, CCaR records or a destination change is refused in a locked view before anything is kept ====
+// The lists every appropriation shares -- the cost estimates, the BAE budget list, the destination list -- are no part of a locked
+// view's copy, so making the copy again (the blocks above) cannot put them back. On 7ee498a each door wrote its list first and then
+// saved, which the view refused: the board said "Not kept" and kept it (the U10 round-1 money review, 13 Oct). Now each is refused
+// before the file is read or a question asked, and says so. A board of two requirements in AV -- A (USAF 900, ANG 200, confirmed on
+// WBS 1.1) and R (USAF 503, ANG 127) -- with an approved 2027 estimate (AV, 1.1, $900) and the funds flow grouped by where the money
+// goes. PB27 is locked with R going to Lockheed Martin; the working plan then adds Depot X (a government activity) and sends R there.
+// With PB27 on screen, each door is used through the handler its control calls (the file pickers' importAce / importBud /
+// importCcarRecs, with a workbook the board builds) or through the control Setup › Destinations renders (a name typed, + add,
+// ✕ answered OK, reset answered OK). After each, in the view and again on the working plan after leaving: the status line, the
+// questions asked, the three lists in the board and in browser storage, the panel, and the cells of the ACE tie-out, the FYDP
+// Spend Plan, the Spend Plan Source and the funds flow -- every figure typed here. FAILS ON 7ee498a (board fce8a391): the approved
+// estimate is replaced after "should not change. Replace it?" and the tie-out reads $4,321,000; the Source names the BAE budget
+// and the refused CCaR titles; Lockheed Martin is RENAMED DEST in the funds flow; "Remove Depot X? Nothing points at it." is asked
+// and, back on the working plan, R's $630 is not yet assigned. CONTROLS: PB27 viewed, nothing done; on the working plan each door
+// is open -- the estimate replaced (asked first), the BAE list kept, a destination added and named -- and every export carries it.
+await (async () => {
+  const name = 'v2.00 (U10) — a cost estimate, a BAE list, CCaR records or a destination change is refused in a locked view before anything is kept';
+  const { bootMark, bootRelease, settleBoards } = await import('./boot.mjs');
+  const __bm = bootMark();
+  try {
+    const J = JSON.stringify;
+    const X = boot();
+    seed(X.ev, { services: ['USAF', 'ANG', 'AFRC'], items: [it('A', 'AV', [900, 200, 0]), it('R', 'AV', [503, 127, 0])], disc: [5000, 5000, 5000], mand: [0, 0, 0], order: ['A', 'R'] });
+    const ev = c => { try { return X.ev(c); } catch (e) { return 'threw: ' + String((e && e.message) || e).slice(0, 100); } };
+    ev(`BASE_ITEMS.length=0; DATA.items.forEach(function(i){ BASE_ITEMS.push(i); BASE_ASK[i.id]=i.ask.slice(); });
+      S.wbs={A:[{w:'1.1', v:[]}]}; S.aceMap={A:{w:['1.1'], ok:true}}; S.dest={R:{to:'lm'}};
+      ACEDB.sets={'2027ACE':{lines:[{ap:mySlug(), pmo:'AV', wbs:'1.1', v:{}}], locked:true, by:'Approver', ts:1, file:'2027 ACE approved.xlsx'}};
+      ACEDB.sets['2027ACE'].lines[0].v[MS.cur]=900; aceYr='all'; persistAce(); applyState(S); save(); flowSetAxis('dest');
+      globalThis.__wb=function(sheets, name){ var b=buildXlsx(sheets); return {name:name, arrayBuffer: async function(){ return b.buffer.slice(b.byteOffset, b.byteOffset+b.byteLength); }}; };
+      globalThis.__aceRows=function(){ var rows=[[],[],[],[],[]]; rows[4][ACE_COL.y0]=2027; var r=[]; r[ACE_COL.appn]='O&M'; r[ACE_COL.svc]='USAF';
+        r[ACE_COL.managed]='Y'; r[ACE_COL.pmo]='AIR VEHICLE'; r[ACE_COL.y0]=4.321; r[ACE_COL.ce]='CE1'; rows.push(r);
+        rows.forEach(function(x){ for(var i=0;i<x.length;i++) if(x[i]===undefined) x[i]=''; }); return rows; };
+      'ok'`);
+    const key = ev(`window.confirm=function(){ return true; }; MS.base=MS.cur; MS.years[MS.cur]=S; save(); blCyc='PB'; blYr=MS.cur; cycLock(); blKey('PB', MS.cur)`);
+    // after the lock: the working plan adds Depot X, a government activity, and sends R's money there (PB27 still sends it to Lockheed Martin)
+    ev(`flowAddEnt(); (function(){ var L=flowEnts(); flowSetEnt(L.length-1,'n','Depot X'); flowSetEnt(L.length-1,'kind','gov'); })();
+      setDest('R','to',destByName('Depot X').k); 'ok'`);
+    const said = () => ev(`(document.getElementById('shareStat')||{}).textContent||''`);
+    const spy = () => ev(`window.__asked=[]; window.confirm=function(m){ window.__asked.push(String(m).slice(0,70)); return true; };
+      window.alert=function(m){ window.__asked.push('alert: '+String(m).slice(0,70)); }; 'ok'`);
+    const asked = () => JSON.parse(ev(`JSON.stringify(window.__asked||[])`));
+    const lists = () => JSON.parse(ev(`JSON.stringify((function(){ var s=ACEDB.sets['2027ACE'];
+      return [s? [s.file||'', !!s.locked, s.lines.map(function(l){ return [l.pmo, l.wbs, (l.v||{})[MS.cur]]; })] : null,
+        (BUDDB.rows||[]).map(function(b){ return b.n; }), flowEnts().map(function(e){ return e.n; })]; })())`));
+    const stored = () => JSON.parse(ev(`JSON.stringify((function(){ var a=JSON.parse(localStorage.getItem('prio27acedb')||'null'), b=JSON.parse(localStorage.getItem('prio27buddb')||'null'),
+      d=JSON.parse(localStorage.getItem(DEST_KEY)||'null'), s=a&&a.sets&&a.sets['2027ACE'];
+      return [s? [s.file||'', !!s.locked, (s.lines||[]).map(function(l){ return [l.pmo, l.wbs, (l.v||{})[MS.cur]]; })] : null,
+        b? (b.rows||[]).map(function(x){ return x.n; }) : null, d? (d.ents||[]).map(function(e){ return e.n; }) : null]; })())`));
+    // Setup › Destinations as drawn on screen: each destination's name field, A to Z
+    const panel = () => JSON.parse(ev(`(function(){ if(!entOpen) toggleEnt(); return JSON.stringify([].slice.call(document.querySelectorAll('#entBody input')).filter(function(i){
+      return /^flowSetEnt\\(\\d+,"n",/.test(i.getAttribute('onchange')||''); }).map(function(i){ return i.value; })); })()`));
+    // a control Setup › Destinations renders for one destination: its name field (typed, change fired), its ✕, + add, or reset
+    const fireDest = (kind, nm, value) => ev(`(function(){ if(!entOpen) toggleEnt(); var i=flowEnts().findIndex(function(e){ return e.n===${J(nm)}; });
+      var els=[].slice.call(document.querySelectorAll('#entBody input, #entBody button')), on=function(e, a){ return e.getAttribute(a)||''; }, el=null;
+      if(${J(kind)}==='name') el=els.filter(function(e){ return on(e, 'onchange')==='flowSetEnt('+i+',"n",this.value)'; })[0];
+      else if(${J(kind)}==='del') el=els.filter(function(e){ return on(e, 'onclick')==='flowDelEnt('+i+')'; })[0];
+      else el=els.filter(function(e){ return on(e, 'onclick')===${J(kind)}; })[0];
+      if(!el) return 'no control';
+      if(${J(kind)}==='name'){ el.value=${J(value || '')}; el.dispatchEvent(new Event('change', {bubbles:true})); } else el.click();
+      return 'fired'; })()`);
+    const hdr = (rows, ...must) => rows.findIndex(r => must.every(m => (r || []).some(c => String(c ?? '').trim() === m)));
+    const col = (rows, h, n) => (rows[h] || []).findIndex(c => String(c ?? '').trim() === n);
+    // every export that carries the estimate, the budget names, the CCaR titles or the destinations, read from its bytes
+    const exportsNow = async () => {
+      const ab = JSON.parse(await w6Book(X.w, 'exportAceTieout')), mp = ab['Mapping by Requirement'] || [], mh = hdr(mp, 'FY', 'PMO', 'Board funded');
+      const rc = ab['Reconciliation by PMO'] || [], rh = hdr(rc, 'FY', 'PMO', 'Estimate');
+      const fb = JSON.parse(await w6Book(X.w, 'exportFydpPlan')), bp = fb['By PMO'] || [], bh = hdr(bp, 'PMO', 'Requirements');
+      const sb = JSON.parse(await w6Book(X.w, 'exportSrc')), s = Object.keys(sb).filter(k => !k.startsWith('__')).map(k => sb[k]).find(rs => Array.isArray(rs) && rs.length > 1) || [];
+      const ff = JSON.parse(await w6Book(X.w, 'exportFlow'));
+      return {
+        files: [ab.__err || 'ok', fb.__err || 'ok', sb.__err || 'ok', ff.__err || 'ok'],
+        mapping: mp.slice(mh + 1).filter(r => /^FY\d\d$/.test(w6Lbl(r))).map(r => ['Requirement (CCaR Record Name)', 'Match', 'WBS claimed', 'Board funded', 'Estimate', 'Delta'].map(n => r[col(mp, mh, n)] ?? '')),
+        reconciliation: rc.slice(rh + 1).filter(r => w6Lbl(r) === 'FY27' && String(r[1] ?? '') === 'AV').map(r => [r[0], r[1], r[2], r[3], r[4]]),
+        fydp: bp.slice(bh + 1).filter(r => w6Lbl(r) === 'AV').map(r => [r[0], r[col(bp, bh, 'FY27 ACE estimate')], r[col(bp, bh, 'FYDP ACE estimate')]]),
+        source: [String((s[0] || [])[4] ?? ''), String((s[0] || [])[12] ?? ''), s.slice(1).map(r => [String(r[2] ?? ''), String(r[3] ?? ''), num(r[9]), String(r[4] ?? ''), String(r[12] ?? '')]).sort()],
+        flow: (ff['Funds Flow'] || []).filter(r => (r || []).length >= 5 && ['Lockheed Martin', 'Depot X', 'Depot Z', 'Not yet assigned', 'RENAMED DEST', 'New destination'].includes(w6Lbl(r))).map(r => [w6Lbl(r), num(r[1]), num(r[4])]) };
+    };
+    // BY HAND. The view: R goes to Lockheed Martin (PB27's); the working plan: R goes to Depot X. A's $1,100 goes nowhere yet. The
+    // estimate is the approved one: A confirmed on 1.1, $900 against A's $1,100; AV $900 against $1,730 funded. No budget, no records.
+    const MAPPING = [['Req A', 'Confirmed - exact line', '1.1', 1100, 900, 200], ['Req R', 'No match', '', 630, '', '']];
+    const SOURCE = ['Budget', 'OPR', [['CCA', 'Ev A', 200, '', ''], ['CCA', 'Ev A', 900, '', ''], ['CCR', 'Ev R', 127, '', ''], ['CCR', 'Ev R', 503, '', '']]];
+    const VIEW = { files: ['ok', 'ok', 'ok', 'ok'], mapping: MAPPING, reconciliation: [['FY27', 'AV', 900, 1730, 830]], fydp: [['AV', 900, 900]], source: SOURCE,
+      flow: [['Lockheed Martin', 630, 2], ['Depot X', 0, 0], ['Not yet assigned', 1100, 2]] };
+    const WORK = Object.assign({}, VIEW, { flow: [['Lockheed Martin', 0, 0], ['Depot X', 630, 2], ['Not yet assigned', 1100, 2]] });
+    const DEST = ['Lockheed Martin', 'Pratt & Whitney', 'NAWCAD Patuxent River', 'NAWCWD China Lake', 'FRC East, Cherry Point', 'NAWCAD Lakehurst', 'Defense Logistics Agency', 'OC-ALC Oklahoma City', 'Depot X'];
+    const ACE0 = ['2027 ACE approved.xlsx', true, [['AV', '1.1', 900]]];
+    const LISTS = [ACE0, [], DEST], STORED = [ACE0, null, DEST];
+    const PANEL = ['Defense Logistics Agency', 'Depot X', 'FRC East, Cherry Point', 'Lockheed Martin', 'NAWCAD Lakehurst', 'NAWCAD Patuxent River', 'NAWCWD China Lake', 'OC-ALC Oklahoma City', 'Pratt & Whitney'];
+    const OFF = what => '🔒 ' + what + ' is off while PB27 is on screen. It is a locked cycle, read only — the change was not kept. ↩ Leave the view to work the plan.';
+    const view = () => ev(`cycView(${J(key)}); 'ok'`), leave = () => ev(`if(entOpen) toggleEnt(); cycLeave(); 'ok'`);
+    const Rto = () => ev(`flowEntName(destOf(itemById('R')).to)`);
+    // ---- CONTROL: PB27 viewed, nothing done; then the working plan
+    view();
+    w5Chk(name, 'PB27 viewed, nothing done', 'CONTROL — the lists, browser storage and the panel as they are; every export carries PB27’s own figures (R to Lockheed Martin)',
+      J([lists(), stored(), panel(), await exportsNow()]), J([LISTS, STORED, PANEL, VIEW]));
+    leave();
+    w5Chk(name, 'the working plan, nothing done', 'CONTROL — R goes to Depot X, and every export says so', J([Rto(), await exportsNow()]), J(['Depot X', WORK]));
+    // ---- EACH DOOR, with PB27 on screen
+    const DOORS = [
+      ['a cost estimate imported (2027 ACE.xlsx, AV $4.321M; the approved 2027ACE is loaded)', 'Importing a cost estimate', () => ev(`importAce({files:[__wb([{name:'ACE', rows:__aceRows()}], '2027 ACE.xlsx')], value:''})`)],
+      ['a BAE list imported (an ANG budget for AV)', 'Importing a BAE budget list', () => ev(`importBud({files:[__wb([{name:'BAE', rows:[['Budget Name'], ['USAF O&M - ANG CAM ZZ9 Discretionary AV']]}], 'BAE.xlsx')], value:''})`)],
+      ['a CCaR Records file imported (titles and OPR for CCA and CCR)', 'Importing CCaR records', () => ev(`importCcarRecs({files:[__wb([{name:'CCaR', rows:[['CCaR No','Title','OPR','PMO','Control No'],
+        ['CCA','REFUSED TITLE A','REFUSED OPR','AV','7001'], ['CCR','REFUSED TITLE R','REFUSED OPR','AV','7002']]}], 'ccar-records.xlsx')], value:''})`)],
+      ['Lockheed Martin renamed RENAMED DEST in its name field', 'Changing a destination', () => fireDest('name', 'Lockheed Martin', 'RENAMED DEST')],
+      ['+ add a destination', 'Adding a destination', () => fireDest('flowAddEnt()')],
+      ['Depot X removed with its ✕, answered OK', 'Removing a destination', () => fireDest('del', 'Depot X')],
+      ['reset the list, answered OK', 'Resetting the destination list', () => fireDest('flowResetEnts()')]];
+    for (const [what, door, act] of DOORS) {
+      view(); panel(); spy();
+      const r = await act(), st = said(), q = asked(), fired = (r === undefined || r === 'fired') ? 'ran' : String(r);
+      w5Chk(name, 'PB27 viewed · ' + what, 'refused before anything is read or asked, and the status line says so', J([fired, st, q]), J(['ran', OFF(door), []]));
+      w5Chk(name, 'PB27 viewed · ' + what, 'the lists, browser storage and the panel as they were; every export from the view carries PB27’s own figures',
+        J([lists(), stored(), panel(), await exportsNow()]), J([LISTS, STORED, PANEL, VIEW]));
+      leave();
+      w5Chk(name, 'PB27 viewed · ' + what + ' · the view left', 'the working plan’s lists, R’s destination and every export are its own, as before',
+        J([lists(), stored(), Rto(), await exportsNow()]), J([LISTS, STORED, 'Depot X', WORK]));
+    }
+    // ---- CONTROLS: on the working plan each door is open, and every export carries what it did (typed from the files)
+    spy(); await ev(`importAce({files:[__wb([{name:'ACE', rows:__aceRows()}], '2027 ACE.xlsx')], value:''})`);
+    const qa = asked().map(m => m.split('\n')[0]), la = lists(), sa = stored(), xa = await exportsNow();
+    w5Chk(name, 'the working plan · a cost estimate imported (allowed)', 'CONTROL — it asks before replacing the approved 2027ACE, replaces it (AV $4,321,000, no WBS), and the tie-out and FYDP Spend Plan read it',
+      J([qa, la[0], sa[0], xa.mapping, xa.reconciliation, xa.fydp]),
+      J([['⚠ 2027ACE is already loaded and LOCKED.'], ['2027 ACE.xlsx', true, [['AV', '', 4321000]]], ['2027 ACE.xlsx', true, [['AV', '', 4321000]]],
+        [['Req A', 'Confirmed', '1.1', 1100, 0, 1100], ['Req R', 'No match', '', 630, '', '']], [['FY27', 'AV', 4321000, 1730, -4319270]], [['AV', 4321000, 4321000]]]));
+    await ev(`importBud({files:[__wb([{name:'BAE', rows:[['Budget Name'], ['USAF O&M - ANG CAM ZZ9 Discretionary AV']]}], 'BAE.xlsx')], value:''})`);
+    const lb = lists(), sbud = stored(), xb = await exportsNow(), BUD = 'USAF O&M - ANG CAM ZZ9 Discretionary AV';
+    w5Chk(name, 'the working plan · a BAE list imported (allowed)', 'CONTROL — the list is kept, and the Spend Plan Source names the ANG budget on A’s and R’s ANG lines',
+      J([lb[1], sbud[1], xb.source]), J([[BUD], [BUD], ['Budget', 'OPR', [['CCA', 'Ev A', 200, BUD, ''], ['CCA', 'Ev A', 900, '', ''], ['CCR', 'Ev R', 127, BUD, ''], ['CCR', 'Ev R', 503, '', '']]]]));
+    // + add a destination, named Depot Z in its name field, and R sent there: what the view refused, on the working plan
+    const fa = fireDest('flowAddEnt()'), fd = fireDest('name', 'New destination', 'Depot Z');
+    ev(`setDest('R','to',destByName('Depot Z').k); 'ok'`);
+    const pd = panel(), ld = lists(), sd = stored(), xd = await exportsNow();
+    ev(`if(entOpen) toggleEnt(); 'ok'`);
+    w5Chk(name, 'the working plan · + add a destination, named Depot Z, R sent there (allowed)', 'CONTROL — the list, browser storage and the panel carry Depot Z, and the funds flow puts R’s $630 under it',
+      J([fa, fd, pd.includes('Depot Z'), ld[2].slice(-1), sd[2].slice(-1), Rto(), xd.flow.filter(r => r[0] === 'Depot Z' || r[0] === 'Not yet assigned')]),
+      J(['fired', 'fired', true, ['Depot Z'], ['Depot Z'], 'Depot Z', [['Depot Z', 630, 2], ['Not yet assigned', 1100, 2]]]));
+    w5Chk(name, 'harness', 'CONTROL — no jsdom script errors', J(X.errors.length), J(0));
+  } catch (e) {
+    failures.push({ scenario: name, where: 'harness', what: 'the block threw: ' + String((e && e.message) || e).slice(0, 160), got: 'threw', want: 'ran' });
+  }
+  bootRelease(__bm, []);
+  await settleBoards();
+})();
+// ==== end v2.00 (U10, the shared lists) ====
 
 {
   const src = _selfRead(_selfPath(import.meta.url), 'utf8');
```

### `diffs/c2-vs-c1r.mutate.mjs.txt.diff`

```diff
--- a/tools/export-audit/mutate.mjs.txt
+++ b/tools/export-audit/mutate.mjs.txt
@@ -4316,6 +4316,32 @@
   { id: "v200-u10-reapply-working-base", area: "cycReapply", what: "the view's copy is made again on the working plan's base year, not the cycle's: with the working base moved to FY28 after PB27 was locked on FY27, a refusal in PB27's view moves its FYDP window to FY28-FY32",
     find: "  MS=cycCopy(c); MS.cur=y;",
     repl: "  MS=cycCopy(c); MS.cur=y; MS.base=_cycStash.MS.base;" },
+  // v2.00 (U10, the round-1 money review of 13 Oct): the doors that write a list every appropriation shares are refused before anything
+  // is kept while a locked cycle is on screen.
+  { id: "v200-u10-ace-import-in-view", area: "importAce", what: "a cost estimate imported while PB27 is on screen is read and stored, the approved 2027ACE replaced after \"should not change. Replace it?\", and the ACE tie-out and FYDP Spend Plan read $4,321,000 in the view and on the working plan, while the board says \"Not kept\"",
+    find: "  if(cycBlock('Importing a cost estimate')){ inp.value=''; return; }\n",
+    repl: "" },
+  { id: "v200-u10-bae-import-in-view", area: "importBud", what: "a BAE list imported while PB27 is on screen is stored, and the Spend Plan Source names its ANG budget on A's and R's ANG lines in the view and on the working plan, while the board says \"Not kept\"",
+    find: "  if(cycBlock('Importing a BAE budget list')){ inp.value=''; return; }\n",
+    repl: "" },
+  { id: "v200-u10-ccar-import-in-view", area: "importCcarRecs", what: "a CCaR Records file imported while PB27 is on screen is read, and the status line counts the titles it found and says \"Save to bake this into the file\" after \"Not kept\"",
+    find: "  if(cycBlock('Importing CCaR records')){ inp.value=''; return; }\n",
+    repl: "" },
+  { id: "v200-u10-dest-change-in-view", area: "flowSetEnt", what: "a destination renamed while PB27 is on screen is renamed for every appropriation and in browser storage: the funds flow puts R's $630 under RENAMED DEST in the view, while the board says the change was not kept",
+    find: "  if(cycBlock('Changing a destination')){ render(); return; }\n",
+    repl: "" },
+  { id: "v200-u10-dest-change-no-redraw", area: "flowSetEnt", what: "a destination rename refused in PB27's view leaves the typed name in its field on screen, as if it were kept",
+    find: "  if(cycBlock('Changing a destination')){ render(); return; }\n",
+    repl: "  if(cycBlock('Changing a destination')) return;\n" },
+  { id: "v200-u10-dest-add-in-view", area: "flowAddEnt", what: "+ add a destination, while PB27 is on screen, adds New destination for every appropriation and in browser storage, while the board says it was not kept",
+    find: "  if(cycBlock('Adding a destination')){ render(); return; }   // v2.00 (U10): as flowSetEnt\n",
+    repl: "" },
+  { id: "v200-u10-dest-remove-in-view", area: "flowDelEnt", what: "Depot X removed with its ✕ while PB27 is on screen: \"Nothing points at it\" is asked (the working plan's R does), it is removed everywhere, and back on the working plan R's $630 is not yet assigned in the funds flow",
+    find: "  if(cycBlock('Removing a destination')){ render(); return; }   // v2.00 (U10): as flowSetEnt\n",
+    repl: "" },
+  { id: "v200-u10-dest-reset-in-view", area: "flowResetEnts", what: "reset the list, answered OK while PB27 is on screen: Depot X is dropped for every appropriation and in browser storage, and back on the working plan R's $630 is not yet assigned",
+    find: "  if(cycBlock('Resetting the destination list')){ render(); return; }   // v2.00 (U10): as flowSetEnt\n",
+    repl: "" },
   // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.
   { id: "v200-r3-landed-view-unsaid", area: "_driveStorePushRun", what: "a folder save that lands while a locked view is on screen says “🔒 Not kept — PB27 is a locked view. ✅ Saved …” again, naming no plan (or, quiet, leaves persist's refusal on screen)",
     find: "  if(CYCVIEW){ _cycRefusedAt=0; setStat('✅ <b>Saved the working plan</b> of '+esc(APPN_LBL[ap]||ap)+' FY'+(fy%100)+' to the shared folder — '\n    +Math.round(body.length/1024)+' KB, built before '+blLbl(CYCVIEW)+' was put on screen. '+blLbl(CYCVIEW)+' is a locked view: nothing in it '\n    +'is saved. Everyone sees the working plan on their next refresh.'+penNote+lateNote); render(); return true; }\n",
```

The base-relative diffs (`diffs/c1r-vs-base.*`, `diffs/c2-vs-base.*`) are these on top of the build's `diffs/c1-vs-base.*` (above): board +22 −10 (commit 1) and +17 (commit 2); audit-recon +283 −0 and +429 −0; mutate +31 −0 and +57 −0.

# Fix round 2 (13 Oct 2026, from 1:41 PM ET) — the round-2 reviews' must-fixes, and a second, wider door scan

Started 13 Oct, 1:41 PM ET, after both round-2 reviews (`verify-money-r2`, written by about 12:24 PM ET; `verify-tests-r2`,
written about 1:40 PM ET). **Nothing was kept from a stopped attempt:** this directory showed no fix-round-2 work (no copy,
probe, log or diff after fix round 1's last write at 10:28 AM ET apart from the two review folders), so this round started
fresh. Everything above this heading is kept as it was; where this round supersedes it, that is said below.

## What the round-2 reviews found, and what this round did

| review item | what it is | this round |
|---|---|---|
| money MF1 | a returned package taken through Import one appropriation in a view: written to browser storage, reopened on 77777, the work typed after the save lost | **fixed, commit 4** (`importState` refused up front, and again once the file is read) |
| money MF2 | ⇉ Copy to the other appropriations in a view replaces Full Fund's ladder, kept nowhere | **fixed, commit 4** (`bandCopyAll` refused up front) |
| money MF3 | an import started on the working plan with the view put on screen during the read is kept ($4,321,000 for $900) | **fixed, commit 4** (the three workbook imports refused again once read); the review's caution is met: a new check reads that the file is never read in a view, so commit 2's three import entries stay caught (1 failing check each, at c4) |
| money MF4 | the drafts and the summary claimed the seven gated doors were all of them | **fixed**: a wider door scan (below), every door it found either closed (commits 3, 4) or named open with its reproduction (ledger rows U<n>, U<n+1>); the drafts are rewritten (`drafts/*-fix2.md`) |
| money SF1 | a package issued (and Push baselines) from a view hands out the cycle as the board | **fixed, commit 4**, and the same for the two package doors the scan found: a manager's return (`pkgReturn`) and Send back (`pkgSendBack`), measured (P6 G/H) |
| money SF2, SF4 | a PMO submittal / a state file carrying board-wide stores, taken in a view | **fixed, commit 4** by the same `importState` gate; SF4 typed in the block, SF2 not (same gate) |
| money SF3 | tests and entries for all of the above | **done**: block "… a file, a package, the band ladder or a shared copy …" (28 checks) and 13 entries |
| money minor: consolidated take | `consTakePick` in a view | closed by the `importState` gate (read; not typed) |
| money minor: command bar ✓ | `runCmd` says ✓ after a refused save | **not changed**: `runCmd` has no caller and `#cmdOut` does not exist in v2.00 (base and c4, by `grep`; probe P7: `cmdSay` throws on the missing element). No user can reach it. A gate drafted for it was taken out again (principle 5) |
| money minor: `adoptShared` | `sharedKeepMine` runs on the view's copy | **measured and fixed, commit 4** (P6 E: the cycle kept aside as this browser's work under "Loading a board is off") |
| tests MF1 | the Spend Plan's six choices kept in a view; the ACE tie-out ties out the refused estimate | **fixed, commit 3** = the review's proposal `verify-tests-r2/c3`, adopted byte for byte (board `1704bb11`, audit-recon `29654c37`, mutate `b90ce05e`) |
| tests SF1, SF2 | no check reads a PPBE position or a destination's kind | **done, commit 3** (its block reads both; entries `-reapply-keeps-ppbe`, `-dest-kind-in-view`) |
| tests minor (b) | the fix-round-1 summary wrote "07:34–11:37 past 10 AM ET" | corrected here: those suite runs were 10:07:34–10:11:37 AM ET |
| tests minor (c) | commit 1's draft said the Spend Plan's service selector keeps its choice in a view | the sentence is deleted from the draft (commit 3 refuses it) |
| — (found by this round's scan) | **a Live refresh from the shared folder while a view is on screen: DATA LOSS** | **measured (P6 F, the same on `7ee498a` and c3) and fixed, commit 4** (`driveStorePull` changes nothing while a view is on screen) |

## The door scan, widened (`bin/doorscan3.py`, text only; output `fr2/doorscan-c3.json`, blob `f08168a8`)

Fix round 1 scanned only the functions that write DESTDB / ACEDB / BUDDB / RPDB / EXDB / CYCDB; the round-2 reviews found
doors outside that set. This round's scan reads every top-level function of the c3 board (381 have a hit) for: a write to any
page-level global other than `MS` / `S` (assignment, compound assignment, ++/--, push/splice/sort…, delete, on the name or a
member; names the function declares or takes are skipped); a browser-storage write (`lsSet`, `lsAll`,
`localStorage.setItem/removeItem`, `keepAside`, `baseSet`, `pkgPut`, the `persistXxx` writers); a download (`.download=`); and
the first line that calls `save()` / `persist()` (refused in a view) or is gated (`cycBlock`, `CYCVIEW`, `cycRefuse`). Inline
`on…=` handlers were scanned separately (grep): only two save, `S.mc[…]` and `MS.cycleRef` (both in the plan, so put back by
commit 1); the rest set screen state (`…Open`, `laneFilter`, `crMode`, `crBy`, `spFund`, `exFy`, …) without saving, which is
not refused and not kept past the session. Every hit was then triaged by reading, and the ones that could keep a refused write
were measured (probe `probe4/u10-doors3.mjs`, P6, on c3 and the base):

| function(s) | why it is not, or is, a door | outcome |
|---|---|---|
| `setSpAce/By/Pmo/Svc/Prior/DrillSvc` | page global set, then a refused save; the ACE tie-out reads `spAce` | commit 3 |
| `importState` → `pkgApply`, `pmoTake`/`destPkgIn`, `consTakePick/Apply`, `importStores`, `cycTake` | writes this appropriation's storage, PUBS, the destination list, the board-wide stores before `applyStore` refuses | commit 4 (up front + once read) |
| `importAce`, `importBud`, `importCcarRecs` | refused up front by commit 2; the write follows the file's read | commit 4 (once read) |
| `bandCopyAll` | writes the other appropriations' boards and held ladders | commit 4 |
| `pkgIssue`, `pkgPushAll`, `pkgReturn`, `pkgSendBack` | hand out the view's copy as the board (P6 G/H, money VP1 D) | commit 4 |
| `sharedKeepMine` (`adoptShared`, `sharedArrived`) | keeps the view's copy aside (P6 E) | commit 4 |
| `driveStorePull` (Live refresh, Connect) | keeps the view's copy aside, records the folder's copy as the base, clean; the next refresh replaces the unsaved work (P6 F) | commit 4 |
| `importFullBoard` race (view put on screen during its read) | measured (P6b I, c3): lands as on the working plan, after its own CONFLICT question, which still names the working plan's change; the board reopens on the file. Not a refused edit and no false word | not changed (principle 5) |
| `keptPutBack` in a view | swaps, `applyStore` refuses, and the code writes the kept slot back as it was | read; not a door |
| `bootTakeFile` | `applyStore` refuses before any write | read |
| `addReq`, `removeReq` (`DATA.items`) | `applyState` rebuilds `DATA.items` from `BASE_ITEMS` and the year, so commit 1's reapply puts it back | read |
| `flow…` (`flowSel=''`), `applyProposedOrder` (`poOpen`), `posDelete` (`posCmp`), `setAsk`/`resetAsk`/`realignAll`/`zeroSpread`/`setSvc`/`setFsrc` (`open`), `pmoApply` (`PMOPICK`) | screen state; their saved part is in the plan (put back by commit 1) | read |
| `switchYear` (`FYMON`) | moving between the cycle's held years is allowed in a view; `FYMON` is derived | read |
| `exportIdsReq` (`idsLast`) | refused in a locked view by `idsBoardRefusal` | read |
| `runCmd` | no caller, no `#cmdOut` (dead code) | not changed |
| `importSrc` (QPE), `rp…` (reprogramming rows), `blLock`, `blDelete` | allowed in a view and kept (fix round 1's ledger row) | ledger row U<n> (unchanged) |
| `driveExecPull`, `driveRpPull`, `driveAcePull`, `driveRpPush` | shared-folder syncs of other people's saved lists; a Live refresh still runs the first two in a view | read, not measured; named in row U<n> |
| theme / density / menu / `whoAmI` / `pickMyPmo` / `jrnlMarkSeen` / live settings | per-viewer preferences | read |
| `persist…`, `lsSet`, `lsAll`, `keepAside`, `baseSet`, `pkgPut`, `driveBaseSet`, boot and migration functions (`rpMigrate`, `cycMigrateLegacy`, `bandsAdoptPending`, `sideBootCheck`, `destMigrate` (gated)) | helpers or boot-time; their callers are the rows above | read |
| exports (`export…`, `crExport`, `flowPng`, `diagSave`, `keptSaveFile`, `publish…` (gated)) | a download of what is on screen, which a view allows by design (file names carry LOCKED) | read |

Limits, plainly: the scan is text over top-level `function` declarations and simple assignment shapes; a write through an
alias (a local bound to a global object and then written) is seen only where the scan's global-member pattern catches the
call that returns it (the `persist…`/`pkgPut` writers), and functions assigned to variables are not scanned. The triage is by
reading, and only the rows marked measured were run.

## The commits now proposed (CURRENT list; fix round 1's two are unchanged)

| # | title | copy | board | audit-recon | mutate.mjs | vs the previous copy |
|---|---|---|---|---|---|---|
| 1 | v2.00 (U10 1 of 4): a refusal in a locked cycle's view puts back the whole view, not the year alone | `c1r` | `4a8b0be3` | `746dac83` | `c6c1ea47` | vs base: board +22 −10, audit-recon +283, mutate +31 (unchanged from fix round 1) |
| 2 | v2.00 (U10 2 of 4): a cost estimate, a BAE list, CCaR records or a destination change is refused in a locked view before anything is kept | `c2` | `cfc9e14f` | `2c4c466a` | `3a408399` | vs c1r: board +17, audit-recon +149 −3, mutate +26 (unchanged from fix round 1) |
| 3 | v2.00 (U10 3 of 4): a Spend Plan choice is refused in a locked view before anything is kept | `c3` (= `verify-tests-r2/c3`, byte for byte) | `1704bb11` | `29654c37` | `b90ce05e` | vs c2: board +10 −6, audit-recon +99, mutate +32 |
| 4 | v2.00 (U10 4 of 4): a file, a package, the band ladder or a shared copy is refused in a locked view before anything is kept | `c4` | `f726ecfc` | `6d0f396a` | `8f51d4bb` | vs c3: board +23 −0, audit-recon +249 −0, mutate +41 −0 |

audit-import `4aba2506`, audit-board `a7c575e5` and audit-other `d89396b0` are unchanged in every copy. Full blobs: c4 board
`f726ecfc34d9b75de95032cf02bd8b0509a8c579`, audit-recon `6d0f396a5a99cc7792415fbcbf043206d9814eaf`, mutate
`8f51d4bbc597c142491f24ccb11b0e2dd1ad80b8`; c3 board `1704bb11ddc5a60235b7c5c9c05e24a13eafd8cd`, audit-recon
`29654c37e6debcec20ee5d2f214726d53fd95809`, mutate `b90ce05e26404ddace5c470da882e36f8a687aba`. Against the base, c4 is board
+72 −16, audit-recon +777 −0, mutate +130 −0 (`diffs/c4-vs-base.*`).

**Commit 3 is the round-2 test review's proposal, adopted unchanged.** I read its board change (six setters gain
`if(spRefused()) return;` and one helper calls the board's own `cycBlock` and redraws), checked that the six setters are called
only by the controls the Spend Plan renders (grep), and re-ran its block inside this round's harness at c4 (9/9) and its ten
entries at c4 (each caught, below). Its measured base and c2 results are the reviewer's (`verify-tests-r2`, F-c3b-on-base /
-on-c2, 12:31–12:35 PM ET).

## Commit 4: the board (+23 −0; `diffs/c4-vs-c3.prioritization-board-grid.html.diff`)

* `importState` (File › Import one appropriation): `if(CYCVIEW){ cycRefuse('Importing a file'); inp.value=''; return; }` before
  the size check (as `importFullBoard` already has), and the same line first in the reader's `onload` (a view put on screen
  while the file was read; as `importBoards` has since v1.97). Every route behind it -- a returned package (`pkgApply`), a
  submittal (`pmoTake` → `destPkgIn`), a consolidated file (`consTakePick`), a board or state file (`importStores`, the slot
  writes) -- is refused with it.
* `importBud`, `importCcarRecs`, `importAce`: `if(cycBlock(<the same door name>)){ inp.value=''; return; }` right after
  `const sheets=await xlsxRead(await f.arrayBuffer());` (commit 2's gate before the read stays).
* `bandCopyAll`, `pkgIssue`, `pkgPushAll`, `pkgSendBack`, `pkgReturn`: `if(cycBlock('<door>')) return;` first.
* `sharedKeepMine` (both `adoptShared` and an answer arriving late through `sharedArrived`): `if(cycBlock('Loading the shared
  state file')) return false;` first.
* `driveStorePull`: `if(CYCVIEW){ if(!quiet) cycRefuse('Loading from the shared folder'); render(); return false; }` after its
  last wait and its `_saveBusy` check, before anything is kept aside or recorded (the place v2.00 U13 chose for the save-busy
  rule, for the same reason).

Each has a `// v2.00 (U10): …` comment in the house voice. The exact diff is below and in `diffs/`.

## Commit 4: the test (audit-recon +249, after commit 3's block)

Block `// ==== v2.00 (U10, the files, packages, ladder and shared copies): …` (28 checks; `block-u10-doors.mjs.txt`, blob
`fad36e7e`), in the house shape (async wrapper, `bootMark()` / `bootRelease(__bm, [])` / `settleBoards()`, the two-space
`  const name = '…';` line, start and end markers). Expected values are literals typed in the block; board helpers are used
only to observe. Seven sections, on boards booted twice (so each holds requirement data of its own) with A on RCN 11111 /
EEIC AAAAA, an approved 2027ACE of $900, PB27 locked, then WORK DESC A on the working plan:
1. the manager's return (K1 → 77777, MGR DESC R) taken in the view; the view left (RCN-EEIC by Month's summary and the Spend
   Plan Source's [$, EEIC, RCN]); the browser reopened over the file saved before the view (UNSAVED EDIT A, 11111); the same
   return started on the working plan with the view put on screen before the read; CONTROL on the working plan (CONFLICT, then
   Merge; 77777 in storage and every export).
2. a state file carrying 2028ACE ($4,321,000 on 1.1) taken in the view and after leaving (estimates in the board and in
   storage; the ACE tie-out's mapping 1,100 / 900 / 200); CONTROL on the working plan (taken, both estimates kept).
3. each workbook import with the view on screen (read 0 times, nothing asked, lists as they were) -- this keeps commit 2's
   three import entries caught now that a second gate follows the read (the money review's MF3 caution) -- and each started on
   the working plan with the view put on screen during the read (refused once read; the lists and the tie-out); then the
   working plan after the three races.
4. ⇉ Copy to the other appropriations in the view (Full Fund's stored ladder stays ["FF ONLY BAND"], no ladder held for it).
5. `pkgIssue`, `pkgPushAll`, `pkgReturn`, `pkgSendBack` in the view (refused, nothing asked, no file, the package record 0);
   CONTROL on the working plan (each hands out one file carrying WORK DESC A).
6. "load the shared one" in the view (refused; nothing kept aside; the work still unsaved); CONTROL on a board of its own (the
   work kept aside first, the shared copy loaded).
7. a Live refresh (quiet) and a Connect from a fake shared folder holding Colleague C's newer copy, with MY UNSAVED A in
   browser storage only (a new session): nothing loaded, nothing kept aside, still unsaved; the Connect refused in words; after
   leaving, the next refresh keeps MY UNSAVED A aside and loads COLLEAGUE DESC R.
Plus the CONTROL "no jsdom script errors" over every board the block booted. The ladder CONTROL (copied on the working plan)
closes section 4.

### The focused results (harness `harness/c4/focused-u10.mjs`, blob `03410810`: item 83, item 88 and the five U10 blocks, verbatim from c4's audit-recon)

| board | item 88 | U10 (codes) | beside | shared lists | spend plan | files & packages | total failing |
|---|---|---|---|---|---|---|---|
| c4 (F8-u10-on-c4) | 11/11 | 27/27 | 9/9 | 27/27 | 9/9 | 28/28 | 0 of 111 |
| c3 (F8-u10-on-c3) | 11/11 | 27/27 | 9/9 | 27/27 | 9/9 | 9 pass, 19 fail | 19 of 111 |
| base `7ee498a` (F8-u10-on-base) | 11/11 | 9 pass, 18 fail | 5 / 4 | 6 / 21 | 3 / 6 | 6 pass, 22 fail | 71 of 111 |

On the base every non-control check of the new block fails and its 6 controls pass. On c3 the 19 failures are the new doors;
the 9 passes are the 6 controls and the three "read 0 times" checks, which commit 2's up-front gates already satisfy (they exist
to keep commit 2's entries caught). F6 and F7 ran earlier drafts of the block (a command-bar section, a wrong literal for the
AFRC total, a shared-state control on the same board as its view case) and are superseded.

## Mutations (+41 lines in the mutate text, before the R3 "landed-view" entry; `entries-u10-c4.mjs.txt`, blob `1c5d5791`)

13 new entries, ids `v200-u10-…`: `state-import-in-view`, `state-import-race`, `ace-import-race`, `bud-import-race`,
`ccar-import-race`, `ladder-copy-in-view`, `pkg-issue-in-view`, `pkg-push-in-view`, `pkg-sendback-in-view`,
`pkg-return-in-view`, `shared-load-in-view`, `folder-pull-in-view`, `folder-connect-quiet`. mcount (text only, `rec/bin/mcount.py`):
c3 1355 entries, c4 1368, each matching once. Each mutant was made with `rec/bin/mkmut.py` (text only) from c4 and run through
the c4 harness (`mutruns-fr2.sh`); all 26 run are caught:

| entry | failing (of 111) | | entry | failing (of 111) |
|---|---|---|---|---|
| state-import-in-view | 2 | | sp-choice-in-view (commit 3) | 4 |
| state-import-race | 1 | | sp-ace-in-view (commit 3) | 3 |
| ace-import-race | 4 | | sp-by-in-view (commit 3) | 2 |
| bud-import-race | 3 | | sp-pmo-in-view (commit 3) | 1 |
| ccar-import-race | 1 | | sp-svc-in-view (commit 3) | 1 |
| ladder-copy-in-view | 1 | | sp-prior-in-view (commit 3) | 2 |
| pkg-issue-in-view | 1 | | sp-drill-in-view (commit 3) | 1 |
| pkg-push-in-view | 1 | | sp-no-redraw (commit 3) | 2 |
| pkg-sendback-in-view | 1 | | reapply-keeps-ppbe (commit 3) | 1 |
| pkg-return-in-view | 1 | | dest-kind-in-view (commit 3) | 1 |
| shared-load-in-view | 2 | | ace-import-in-view (commit 2) | 1 |
| folder-pull-in-view | 3 | | bae-import-in-view (commit 2) | 1 |
| folder-connect-quiet | 1 | | ccar-import-in-view (commit 2) | 1 |

Commit 3's ten counts equal the round-2 test review's at c3 (of 83). Commit 2's three import entries were caught at c2 by 15 /
13 / 1 checks; at c4 one check each catches them (the "read 0 times" check), since the second gates now refuse the same way --
without that check they would be equivalent (the money review's VM3 measured 0 of 74 on its proto3).

## Measured this round (probes, all synthetic, in memory)

* **P6 (`probe4/u10-doors3.mjs`, blob `328e931a`), on c3 and the base, the same on both** (out/fr2/P6-doors3-on-*.json): E —
  `adoptShared` in the view: "🔒 Loading a board is off …" and the copy kept aside is the view's (A described '', not WORK DESC A),
  still there after leaving. F — a Live refresh in the view: "🔒 Not kept — PB27 is a locked view. ⬇ Loaded O&M FY27 from the
  shared folder — saved by Colleague C just now. This browser held work no saved copy had; it is kept aside", while nothing was
  loaded, the copy kept aside is the view's, the unsaved flag is cleared and the folder's copy recorded as the base; after
  leaving, the next refresh loads Colleague C's copy (WORK DESC A, COLLEAGUE DESC R) over MY UNSAVED A, which is in no plan
  and no kept copy (only the view copy's journal lines mention it). G — `pkgReturn` in the view hands out a return, seq 3,
  signature SIG3, A described '(none)' (the cycle), under "🔒 Not kept"; on the working plan the same carries WORK DESC A. H —
  `pkgSendBack` in the view hands out the cycle, with "Nothing on this board changed" and no lock word. J — a returned package
  started on the working plan with the view put on screen before the read: CONFLICT asked of the view's copy, the package
  written to browser storage (seq 1, MGR DESC R) under "🔒 Not kept"; after leaving the screen shows UNSAVED EDIT A but storage
  holds the package.
* **P6b** (I, the full-import race, re-run with a wait long enough for a megabyte file): it lands as on the working plan --
  CONFLICT names the working plan's own change, then "Import everything …", then "Full board imported … Reopening". Not a
  refused edit; not changed.
* **P7 (`probe4/cmd.mjs`)**: `runCmd('flag Req A as mission critical')` throws "Cannot set properties of null (setting
  'innerHTML')" in `cmdSay`: there is no `#cmdOut`, and nothing calls `runCmd` (grep, base and c4). Exit 1 is the measurement.

## Decisions, with reasons (the lead's principles)

1. **Never lose a copy.** Commit 4 closes the two data-loss doors the round-2 money review measured (a package taken in a view
   wrote browser storage and the work typed after the save was in no copy; the ladder copy replaced Full Fund's ladder) and the
   one this round's scan found (a Live refresh in a view recorded a colleague's newer copy as the base, clean, so the next
   refresh replaced this browser's unsaved work, kept nowhere). Each is refused before anything is read, asked or written;
   the working plan, its browser storage, the copy kept aside and the other appropriations' boards are as they were (typed
   checks). The first refresh after leaving the view keeps the work aside first and loads the colleague's copy, as on the
   working plan: both copies kept.
2. **Refuse or ask rather than guess.** Every door is refused, not re-routed: no question is asked of the view's copy any more
   (the package's CONFLICT question was asked of the cycle's plan). The race case (a view put on screen during a file's read)
   is refused once the file is read, as `importBoards` has done since v1.97.
3. **Money and every export exact.** The block reads export cells typed by hand: RCN-EEIC by Month and the Spend Plan Source
   (11111 for A, never 77777, also after a reopen), the ACE tie-out (A's $1,100 against $900, delta 200, never $4,321,000),
   and the files the package doors hand out (none from a view; the working plan's from the working plan).
4. **Every word stays true.** Each refusal says what was refused and that nothing was kept, and now nothing is. The drafts no
   longer call the gated doors "all of them": the scan, its limits and the doors left open (rows U<n>, U<n+1>) are written
   down. The quiet Live refresh says nothing in a view, as it says nothing when a save is under way; a Connect says it was
   refused. The command bar's "✓" was not changed because nothing can reach the command bar.
5. **Smallest change.** Commit 3 is the test review's measured six one-line guards and one helper, taken byte for byte.
   Commit 4 is 23 added board lines, each the board's own `cycBlock` / `cycRefuse` (no new mechanism), plus comments in the
   house voice; nothing else in the board changes. A cmdSay change was written and then removed (dead code). The full-import
   race was measured and left alone (nothing refused, nothing false).
6. **Every existing check, fixture and expected value preserved.** Against c2, c3 changes six setter lines (no mutation entry
   names them) and only adds to audit-recon and the mutate text; c4 only adds lines to all three files (`diffs/c4-vs-c3.*`:
   board +23 −0, audit-recon +249 −0, mutate +41 −0). No existing check, fixture or expected value was edited. mcount (text
   only): c3 1355 entries, c4 1368, each matching its board exactly once (the base's 1328 included). Commit 2's three import
   entries would have become equivalent with the second gates (the money review's caution, VM3); the new block's "read 0
   times" checks keep each caught (1 failing check each at c4).

## Suites and npm run check at c4 (each through run.sh: its own process group, 600 s cap, lock checked first)

| suite | run | result | against `7ee498a`'s output (`bin/cmplogs.py`; timings, clocks and paths masked) |
|---|---|---|---|
| boot-same | S4-boot-same-c4, 15:21:35 ET, exit 0, 56.9 s | identical either way | 0 differing lines (vs S3-boot-same-base) |
| audit-ppt | S4-audit-ppt-c4, 15:22:32, exit 0, 27.1 s | ALL CHECKS PASSED | 0 (vs S2-audit-ppt-base) |
| legacy-fsrc | S4-legacy-fsrc-c4, 15:22:59, exit 0, 45.3 s | every legacy Force setting computes exactly as before | 0 (vs S2-legacy-fsrc-base) |
| audit-inject | S4-audit-inject-c4, 15:26:42, exit 0, 69.7 s | ALL CHECKS PASSED | 0 (vs S2-audit-inject-base) |
| audit | S4-audit-c4, 15:27:51, exit 0, 60.3 s | ALL CHECKS PASSED | 0 (vs S2-audit-base) |
| audit-other | S4-audit-other-c4, 15:37:05, exit 0, 167.8 s | ALL CHECKS PASSED | 0 (vs S3-audit-other-base) |
| audit-hostile | S4-audit-hostile-c4, 15:37:05, exit 0, 290.3 s | ALL CHECKS PASSED | 0 (vs S2-audit-hostile-base) |
| audit-import v1.97 W3 (focused, verbatim) | I4-w3-on-c4, 15:42:08, exit 0, 402.3 s | ALL CHECKS PASSED | — |
| audit-import v2.00 R3 (focused, verbatim) | I4-r3-on-c4, 15:42:08, exit 0, 61.0 s | ALL CHECKS PASSED | — |
| audit-board PPBE cycles (focused, verbatim) | B4-ppbe-on-c4, 15:43:09, exit 0, 48.1 s | 141 checks, 0 fail | — |
| `npm run check` (scratch clone `gitclone/`, c4's three files copied in, then put back) | N4-check-c4, 15:43:58, exit 0, 17.0 s | all checks passed | clone's files back to `fce8a391` / `529e36f7` / `cbc6defc`; status `?? node_modules` only (`out/fr2/npmcheck4.out`) |
| **audit-recon (the owning suite), full** | **S4f-audit-recon-c4, 16:27:26 ET, exit 0, 599.2 s** (after S4 15:26:42 cap; S4b 15:49:02 and S4c 15:55:58 OOM-killed, 137; S4d 16:04:58 exit 124 at 600.7 s after printing ALL CHECKS PASSED; S4e 16:15:40 exit 124, no verdict) | **ALL CHECKS PASSED** | 0 differing lines against S3-audit-recon-base (13 vs 13 lines) |

**The full audit-recon at c4 passed on its sixth start (S4f: exit 0, 599.2 s, ALL CHECKS PASSED)**, a second inside its cap. The five before it did not finish and are not results: the machine's load average was 24–47 on 4 CPUs and its memory cgroup was killing processes (dmesg shows the OOM killer taking S4b and S4c, and other agents' node and Chromium processes in the same seconds); S4d printed ALL CHECKS PASSED but its exit was cut by the cap. Because S4f ran so close to the cap, the lead's queue may want to re-run it on a quieter machine; the base's own full run took 196–365 s (fix round 1).

## Every run of this round (from `logs/runs.txt`; label, start ET 13 Oct, exit, wall s, result, log)

| label | start (ET, 13 Oct) | exit | wall s | result | log |
|---|---|---|---|---|---|
| P6-doors3-on-c3 | 14:09:37 | 0 | 130.2 | probe output: out/fr2/P6-doors3-on-c3.json | logs/P6-doors3-on-c3.log |
| P6-doors3-on-base | 14:09:36 | 0 | 137.2 | probe output: out/fr2/P6-doors3-on-base.json | logs/P6-doors3-on-base.log |
| P6b-doorsI-on-c3 | 14:12:47 | 0 | 31.3 | probe output: out/fr2/P6b-doorsI-on-c3.json | logs/P6b-doorsI-on-c3.log |
| F6-u10-on-c3 | 14:19:41 | 1 | 257.4 | 25 of 113 w5 checks fail | logs/F6-u10-on-c3.log |
| F6-u10-on-c4 | 14:19:41 | 1 | 263.1 | 5 of 113 w5 checks fail | logs/F6-u10-on-c4.log |
| P7-cmd-on-c4 | 14:24:30 | 1 | 9.5 | probe (log) | logs/P7-cmd-on-c4.log |
| F7-u10-on-c3 | 14:26:37 | 1 | 280.6 | 22 of 111 w5 checks fail | logs/F7-u10-on-c3.log |
| F7-u10-on-c4 | 14:26:37 | 0 | 283.0 | 0 of 111 w5 checks fail | logs/F7-u10-on-c4.log |
| F8-u10-on-c4 | 14:31:59 | 0 | 133.9 | 0 of 111 w5 checks fail | logs/F8-u10-on-c4.log |
| F8-u10-on-base | 14:31:59 | 1 | 146.2 | 71 of 111 w5 checks fail | logs/F8-u10-on-base.log |
| F8-u10-on-c3 | 14:35:12 | 1 | 132.1 | 19 of 111 w5 checks fail | logs/F8-u10-on-c3.log |
| F8-c4-mut-v200-u10-state-import-in-view | 14:35:12 | 1 | 135.5 | 2 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-state-import-in-view.log |
| F8-c4-mut-v200-u10-state-import-race | 14:37:34 | 1 | 131.6 | 1 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-state-import-race.log |
| F8-c4-mut-v200-u10-bud-import-race | 14:37:34 | 1 | 133.7 | 3 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-bud-import-race.log |
| F8-c4-mut-v200-u10-ace-import-race | 14:39:46 | 1 | 119.0 | 4 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-ace-import-race.log |
| F8-c4-mut-v200-u10-ccar-import-race | 14:39:48 | 1 | 119.2 | 1 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-ccar-import-race.log |
| F8-c4-mut-v200-u10-pkg-push-in-view | 14:41:53 | 1 | 101.7 | 1 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-pkg-push-in-view.log |
| F8-c4-mut-v200-u10-ladder-copy-in-view | 14:41:53 | 1 | 107.0 | 1 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-ladder-copy-in-view.log |
| F8-c4-mut-v200-u10-pkg-sendback-in-view | 14:43:35 | 1 | 138.4 | 1 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-pkg-sendback-in-view.log |
| F8-c4-mut-v200-u10-pkg-issue-in-view | 14:43:41 | 1 | 135.2 | 1 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-pkg-issue-in-view.log |
| F8-c4-mut-v200-u10-pkg-return-in-view | 14:46:00 | 1 | 181.5 | 1 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-pkg-return-in-view.log |
| F8-c4-mut-v200-u10-folder-pull-in-view | 14:46:00 | 1 | 187.7 | 3 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-folder-pull-in-view.log |
| F8-c4-mut-v200-u10-shared-load-in-view | 14:49:02 | 1 | 252.0 | 2 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-shared-load-in-view.log |
| F8-c4-mut-v200-u10-folder-connect-quiet | 14:49:08 | 1 | 251.2 | 1 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-folder-connect-quiet.log |
| F8-c4-mut-v200-u10-ccar-import-in-view | 14:53:26 | 1 | 225.2 | 1 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-ccar-import-in-view.log |
| F8-c4-mut-v200-u10-ace-import-in-view | 14:53:26 | 1 | 229.9 | 1 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-ace-import-in-view.log |
| F8-c4-mut-v200-u10-sp-choice-in-view | 14:57:11 | 1 | 247.6 | 4 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-sp-choice-in-view.log |
| F8-c4-mut-v200-u10-bae-import-in-view | 14:57:16 | 1 | 246.8 | 1 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-bae-import-in-view.log |
| F8-c4-mut-v200-u10-sp-ace-in-view | 15:01:33 | 1 | 259.7 | 3 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-sp-ace-in-view.log |
| F8-c4-mut-v200-u10-sp-pmo-in-view | 15:01:33 | 1 | 264.9 | 1 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-sp-pmo-in-view.log |
| F8-c4-mut-v200-u10-sp-prior-in-view | 15:12:30 | 1 | 278.5 | 2 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-sp-prior-in-view.log |
| F8-c4-mut-v200-u10-sp-drill-in-view | 15:12:30 | 1 | 281.2 | 1 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-sp-drill-in-view.log |
| F8-c4-mut-v200-u10-sp-no-redraw | 15:17:17 | 1 | 246.1 | 2 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-sp-no-redraw.log |
| F8-c4-mut-v200-u10-reapply-keeps-ppbe | 15:17:17 | 1 | 251.1 | 1 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-reapply-keeps-ppbe.log |
| S4-boot-same-c4 | 15:21:35 | 0 | 56.9 | identical either way | logs/S4-boot-same-c4.log |
| S4-audit-ppt-c4 | 15:22:32 | 0 | 27.1 | ALL CHECKS PASSED | logs/S4-audit-ppt-c4.log |
| S4-legacy-fsrc-c4 | 15:22:59 | 0 | 45.3 | every legacy Force setting computes exactly as before | logs/S4-legacy-fsrc-c4.log |
| F8-c4-mut-v200-u10-dest-kind-in-view | 15:21:35 | 1 | 299.7 | 1 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-dest-kind-in-view.log |
| S4-audit-inject-c4 | 15:26:42 | 0 | 69.7 | ALL CHECKS PASSED | logs/S4-audit-inject-c4.log |
| S4-audit-c4 | 15:27:51 | 0 | 60.3 | ALL CHECKS PASSED | logs/S4-audit-c4.log |
| S4-audit-recon-c4 | 15:26:42 | none | ~600 |  — TIMED OUT = incomplete (no end line: its driver hit its own 600 s cap first, then the node run its own cap at about 15:36:42 EDT, load average ~47); re-run below | logs/S4-audit-recon-c4.log |
| S4-audit-other-c4 | 15:37:05 | 0 | 167.8 | ALL CHECKS PASSED | logs/S4-audit-other-c4.log |
| S4-audit-hostile-c4 | 15:37:05 | 0 | 290.3 | ALL CHECKS PASSED | logs/S4-audit-hostile-c4.log |
| I4-r3-on-c4 | 15:42:08 | 0 | 61.0 | ALL CHECKS PASSED | logs/I4-r3-on-c4.log |
| B4-ppbe-on-c4 | 15:43:09 | 0 | 48.1 | 0 of 141 w5 checks fail | logs/B4-ppbe-on-c4.log |
| N4-check-c4 | 15:43:58 | 0 | 17.0 | all checks passed | logs/N4-check-c4.log |
| I4-w3-on-c4 | 15:42:08 | 0 | 402.3 | ALL CHECKS PASSED | logs/I4-w3-on-c4.log |
| S4b-audit-recon-c4 | 15:49:02 | 137 | 399.4 |  — killed by the memory-cgroup OOM killer (dmesg), incomplete | logs/S4b-audit-recon-c4.log |
| S4c-audit-recon-c4 | 15:55:58 | 137 | 528.4 |  — killed by the memory-cgroup OOM killer (dmesg), incomplete | logs/S4c-audit-recon-c4.log |
| S4d-audit-recon-c4 | 16:04:58 | 124 | 600.7 | ALL CHECKS PASSED — TIMED OUT at the cap, incomplete (it had printed ALL CHECKS PASSED) | logs/S4d-audit-recon-c4.log |
| S4e-audit-recon-c4 | 16:15:40 | 124 | 600.9 |  — TIMED OUT at the cap, incomplete | logs/S4e-audit-recon-c4.log |
| S4f-audit-recon-c4 | 16:27:26 | 0 | 599.2 | ALL CHECKS PASSED | logs/S4f-audit-recon-c4.log |
| F8-c4-mut-v200-u10-sp-by-in-view | 15:05:53 | 1 (the runner's own "# exit 1 at 3:12:16 PM ET") | ~383 | 2 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-sp-by-in-view.log |
| F8-c4-mut-v200-u10-sp-svc-in-view | 15:05:58 | 1 (the runner's own "# exit 1 at 3:12:20 PM ET") | ~382 | 1 of 111 w5 checks fail | logs/F8-c4-mut-v200-u10-sp-svc-in-view.log |

Notes on the table: run.sh writes "TIMED OUT" for exit 137 too; S4b and S4c were killed by the kernel's OOM killer, not by the
cap (pids.txt). The two sp-by / sp-svc lines are added by hand: their lane driver reached its own 600 s cap while they ran, so
their run.sh parents were stopped and wrote no line; the node runs, in their own process groups under run.sh's own cap,
finished and printed their exit (in each log). F6 and F7 ran earlier drafts of the block and are superseded by F8. P7 exits 1
by design (it measures that `cmdSay` throws). The doorscan runs (python, text only) are in pids.txt: doorscan.py and
doorscan2.py were too slow under load (the first stopped by me through its recorded PIDs, the second at its own cap);
doorscan3.py finished (13:58:26 EDT, 5 min 58 s).

## PIDs (this round)

Every PID of this round is in `pids.txt` after the marker `# ==== fix round 2`, with its command and start time (ET) -- 113
lines and 12 notes; a copy is `fr2/pids-fr2.txt`. The notes record, plainly: the slow scans and
how they stopped; three `node --check` syntax checks (each under a second; two inside `setsid -w timeout`, one not) whose PIDs
were not recorded; the one driver that reached its 600 s cap while two of its mutant runs were going (those runs finished on
their own caps; afterwards one mutant per lane per driver); the full audit-recon's cap and OOM-kill history. I killed nothing
but my own recorded PIDs (2016–2018, the first scan), and never by name or pattern. At most two of my node processes ran at
a time; the `AUDIT_IMPORT_RUNNING` lock was absent at every check (run.sh checks it before each run; none waited or was skipped).

## Plainly not done (fix round 2)

* The full audit-import and audit-board (the lead runs those alone), the `mutate.mjs` sweep (never imported or run; entries
  read as text only), and the full-suite sensitivity of the 23 new entries (the lead's final-tree queue).
* Not typed in the new block, closed by the same gate as a typed case: a PMO submittal and a consolidated file taken through
  Import one appropriation in a view (money SF2 and the consolidated take); `sharedArrived` (an answer arriving while a view
  is on screen) goes through the same `sharedKeepMine` gate as `adoptShared`, which is typed.
* Not measured, read only: the Live refresh's pulls of the folder's execution data and reprogramming log while a view is on
  screen (named in ledger row U<n>); `keptPutBack`, `bootTakeFile`, `addReq`/`removeReq` in a view (read as not doors).
* Mutants not re-run at c4: commit 1's nine and commit 2's five destination entries (caught at c2 in fix round 1 and by the
  round-2 test review at c2 with the same counts; c3 and c4 add gates in other functions and only add blocks). The round-1
  and round-2 reviewers' own mutants were not re-run.
* Not done in Chromium: these handlers have no Chromium tool; all runs are jsdom.
* The doors left open on purpose, for Brad: ledger rows U<n> (edits a view allows and keeps: a QPE import, reprogramming
  rows, unlocking or deleting another cycle, with the false "not kept" when the deleted cycle is the working plan's
  reference) and U<n+1> (a locked cycle keeps no PMO list). Unchanged from fix round 1, with U<n> now also naming the Live
  refresh's two list pulls.
* Nothing was committed, staged or pushed; `/home/user/orbit-board` and `/home/user/orbit-ui` were only read. The scratch
  clone `gitclone/` held c4's files only for `npm run check` and was put back (hashes in `out/fr2/npmcheck4.out`).

## What this round supersedes (earlier results kept above, unchanged)

* Fix round 1's "commits now proposed" (two commits) → four commits (table above); commits 1 and 2 are unchanged in code.
* Fix round 1's drafts `drafts/NEXT-VERSION-U10-fix.md` and `drafts/LEDGER-U10-fix.md` → `drafts/NEXT-VERSION-U10-fix2.md`
  (blob below) and `drafts/LEDGER-U10-fix2.md`. Their claims that the seven gated doors were all of them, that "two neighbouring
  cases stay open", and commit 1's sentence about the Spend Plan's service selector are withdrawn.
* Fix round 1's finding "The refused-but-kept doors are exactly the seven now gated" (its door scan covered only the six side
  lists) → the wider scan above.
* Fix round 1's result line "Other suites at c2, all exit 0 (07:34–11:37 past 10 AM ET)" → 10:07:34–10:11:37 AM ET.

## Drafts for the lead (this round; they SUPERSEDE fix round 1's)

* `drafts/NEXT-VERSION-U10-fix2.md` — the four NEXT-VERSION entries (U10 1–4 of 4), and the replacement for U10's line in
  "Unresolved after R1–R5" with the texts to use if only commits 1–3 or 1–2 land.
* `drafts/LEDGER-U10-fix2.md` — the text to append to ledger row U10 (four `<sha>` / `<time>` placeholders), the two open rows
  U<n> and U<n+1>, and the row to add instead if commit 4 does not land.

## Blobs (git hash-object) of this round's files

* `c3/prioritization-board-grid.html` `1704bb11ddc5a60235b7c5c9c05e24a13eafd8cd`
* `c3/tools/export-audit/audit-recon.mjs` `29654c37e6debcec20ee5d2f214726d53fd95809`
* `c3/tools/export-audit/mutate.mjs.txt` `b90ce05e26404ddace5c470da882e36f8a687aba`
* `c4/prioritization-board-grid.html` `f726ecfc34d9b75de95032cf02bd8b0509a8c579`
* `c4/tools/export-audit/audit-recon.mjs` `6d0f396a5a99cc7792415fbcbf043206d9814eaf`
* `c4/tools/export-audit/mutate.mjs.txt` `8f51d4bbc597c142491f24ccb11b0e2dd1ad80b8`
* `block-u10-doors.mjs.txt` `fad36e7e7a71b482f19e8144685b66ed610186d1`
* `entries-u10-c4.mjs.txt` `1c5d57915092ac28377c6dfb631f7b6ed07b409d`
* `bin/edit-board-c4.py` `9757aafc0007b670f1977b88331b561f10d97457`
* `bin/doorscan.py` `2aaff8fe837089d42787869048223cd481a1c70b`
* `bin/doorscan2.py` `601ebe8b8c5be431e39fa5c696339c38ac5b3dfc`
* `bin/doorscan3.py` `bd78cfd5d5cc9a4360d169427a6a73cc2d713853`
* `fr2/doorscan-c3.json` `f08168a89b3c037d6a433d0b64632c02b982abcb`
* `probe4/u10-doors3.mjs` `328e931a5990e489e6257a22a3a7b579ae1a78a3`
* `probe4/cmd.mjs` `6303991c73c45c733b73187872fd42c4e97cf1da`
* `harness/c4/focused-u10.mjs` `034108101fe427496fa11228774b7d00febb57e5`
* `harness/c4/focused-import-w3.mjs` `e231e09f996ccf940d87ad573c781b37e4d9f533`
* `harness/c4/focused-import-r3.mjs` `dba2c1d7bd54a558c3d2ee4c8ea0a3ac06989c48`
* `harness/c4/focused-board-ppbe.mjs` `3134ffcf17618865d5df7afc9002f46a77a2cc84`
* `mutruns-fr2.sh` `eb91da16dfa19402b767e40346a851569fdf924e`
* `suites4.sh` `32ef0a775d308a9afa2d3458d5ded7d98c19d952`
* `npmcheck4.sh` `8da6e7089b942a2e20b6712a6395aeef936e9f81`
* `diffs/c3-vs-c2.all.diff` `4b7e3fc8cb04d40c2231f10d3cc647ed91c4bd57`
* `diffs/c4-vs-c3.all.diff` `8537a2432290a40fc844378c58624d903382d5d1`
* `diffs/c4-vs-base.all.diff` `3e23e9b6b3eda94cb5c3aef74c002911608c0c36`
* `drafts/NEXT-VERSION-U10-fix2.md` `a1f0244a9ca954f9e5f6107661a4545fa252eed2`
* `drafts/LEDGER-U10-fix2.md` `81f2708e8cbc278d9d03aaa7e132dead97a91429`
* `out/fr2/mutants-c4.txt` `041d67e517027d02dfc8b047c1c77cacbdc48648`
* `fr2/pids-fr2.txt` `71b9edc09dc2aea0eb668c3c34166d2347adebfe`

## The diffs of this round, exact (also in `diffs/`)

### `diffs/c4-vs-c3.all.diff` (commit 4: board, audit-recon, mutate text)

```diff
--- /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/u10/c3/prioritization-board-grid.html	2026-10-13 16:08:39.245398702 +0000
+++ /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/u10/c4/prioritization-board-grid.html	2026-10-13 18:24:57.441884838 +0000
@@ -8446,6 +8446,9 @@
 // v1.96 (item 69, review NR05): before the shared state file replaces the board, work no saved copy has is kept aside --
 // the rule the shared folder's copy has followed since v1.89. Other work already kept, or no room: nothing is loaded.
 function sharedKeepMine(st){
+  // v2.00 (U10): NOT WITH A LOCKED CYCLE ON SCREEN. The copy on screen is the cycle's: it was kept aside as this browser's work,
+  // and then the load was refused -- a kept copy that is nobody's work, and that "put it back" would make the working plan.
+  if(cycBlock('Loading the shared state file')) return false;
   const own=ownUnsaved(MS, st, baseGet());
   const ka=own? keepAside(MS, {why:'sidecar', by:(st&&st.by)||'', ts:+((st&&st.ts)||0)}, baseGet()) : true;
   if(ka==='occupied'){ setStat(keptOccupiedMsg(st&&st.by, +((st&&st.ts)||0), 'the shared state file')); render(); return false; }
@@ -8722,6 +8725,8 @@
 
 // ---------------------------------------------------------------- issue (consolidated -> manager)
 function pkgIssue(ap, quiet){
+  // v2.00 (U10): NOT FROM A LOCKED VIEW. It handed out the cycle on screen as the board's package, and recorded nothing.
+  if(cycBlock('Issuing a package')) return;
   const pack=pkgPackOf(ap);
   let st=pkgStoreOf(ap), fresh=false;
   if(!st && pack){
@@ -8781,6 +8786,7 @@
 // Hand every appropriation this board holds to its manager at once. The per-appropriation issue
 // is unchanged and still the way to re-issue a single one later; this is the one-time seeding.
 function pkgPushAll(){
+  if(cycBlock('Pushing baselines to the managers')) return;   // v2.00 (U10): as pkgIssue
   const all=APPN_SLUGS;
   const have=all.filter(function(ap){ return !!pkgPackOf(ap); });
   const none=all.filter(function(ap){ return !pkgPackOf(ap); });
@@ -8834,6 +8840,7 @@
 // so it carries no signature: the receiving board reads its own journal to say what it changed in
 // the meantime (pkgMineSince), and the ledger number the file carried keeps a newer issue in charge.
 function pkgSendBack(ap){
+  if(cycBlock('Sending a package back')) return;   // v2.00 (U10): as pkgIssue -- it sent the cycle on screen back as the board
   const nm=PKG_NAMES[ap]||ap;
   const st=pkgStoreOf(ap);
   if(!st){ setStat('\u26a0 No '+nm+' on this board to send back.'); return; }
@@ -8854,6 +8861,7 @@
   return (p&&p.ap===mySlug())? p : null;
 }
 function pkgReturn(){
+  if(cycBlock('Saving a return package')) return;   // v2.00 (U10): as pkgIssue -- it returned the cycle on screen as the work
   const src=pkgReturnable();
   const body=pkgStrip(MS);
   const ap=mySlug();
@@ -10099,9 +10107,15 @@
 function importState(inp){
   const f=inp.files&&inp.files[0];
   if(!f) return;
+  // v2.00 (U10): REFUSED BEFORE THE FILE IS READ while a locked cycle is on screen, as Import full board already is -- and again
+  // once it is read, in case one was put on screen meanwhile. A package, a submittal or a state file taken here wrote browser
+  // storage or a list every appropriation shares first, and only then met the view's refusal: the board said "Not kept", and
+  // reopened on what it had refused.
+  if(CYCVIEW){ cycRefuse('Importing a file'); inp.value=''; return; }
   const big=inTooBig(f); if(big){ inRefuse(f.name, big); inp.value=''; return; }
   const r=new FileReader();
   r.onload=()=>{
+    if(CYCVIEW){ cycRefuse('Importing a file'); inp.value=''; return; }
     // THE DOOR (v1.88): a board, a consolidated file, a package, a submittal and a state file all come
     // in here, and all of them are checked whole before any route below reads a field of one.
     const bad=inboundCheck(r.result); if(bad){ inRefuse(f.name, bad); inp.value=''; return; }
@@ -14214,6 +14228,7 @@
   try{
     setStat('💰 Reading '+esc(f.name)+'…');
     const sheets=await xlsxRead(await f.arrayBuffer());
+    if(cycBlock('Importing a BAE budget list')){ inp.value=''; return; }   // v2.00 (U10): and again once it is read -- a view put on screen meanwhile
     const rows=sheets[Object.keys(sheets)[0]]||[];
     if(!rows.length) throw new Error('no rows in that workbook');
     const hdr=(rows[0]||[]).map(function(x){ return String(x||'').trim(); });
@@ -14460,6 +14475,7 @@
   try{
     setStat('📇 Reading '+esc(f.name)+'…');
     const sheets=await xlsxRead(await f.arrayBuffer());
+    if(cycBlock('Importing CCaR records')){ inp.value=''; return; }   // v2.00 (U10): as importBud
     const rows=sheets[Object.keys(sheets)[0]]||[];
     const hdr=(rows[0]||[]).map(function(x){ return String(x||'').trim(); });
     const iC=hdr.indexOf('CCaR No'), iT=hdr.indexOf('Title'), iO=hdr.indexOf('OPR'), iP=hdr.indexOf('PMO');
@@ -14524,6 +14540,7 @@
   try{
     setStat('\ud83d\udcc8 Reading '+esc(f.name)+'\u2026');
     const sheets=await xlsxRead(await f.arrayBuffer());
+    if(cycBlock('Importing a cost estimate')){ inp.value=''; return; }   // v2.00 (U10): as importBud
     const first=Object.keys(sheets)[0];
     if(!first) throw new Error('no sheets in that workbook');
     const label=(f.name.match(/(20\d\d)\s*ACE/i)||[null,''])[1];
@@ -17697,6 +17714,7 @@
   });
 }
 function bandCopyAll(){
+  if(cycBlock('Copying the band ladder')) return;   // v2.00 (U10): it wrote the other appropriations' boards, then said "Not kept"
   const peers=bandPeers();
   if(!peers.length){ setStat('\u26a0 No other appropriation is available in this file to copy to.'); return; }
   const now=peers.filter(p=>p.seen), later=peers.filter(p=>!p.seen);
@@ -26840,6 +26858,11 @@
       +'finished (📡 Live view → ↻ Refresh now, or on its own while Live view is on).');
     render(); return false;
   }
+  // v2.00 (U10): NOT INTO A LOCKED VIEW -- checked after the last wait, before anything is changed. The copy on screen is the
+  // cycle's: it was kept aside in place of the work this browser holds, the load was refused, and the folder's copy was still
+  // recorded as the one the work came from, saved -- so the first refresh after leaving the view replaced that work, kept nowhere.
+  // Nothing is changed; the first refresh after leaving the view decides afresh. A quiet refresh (the Live timer) says nothing.
+  if(CYCVIEW){ if(!quiet) cycRefuse('Loading from the shared folder'); render(); return false; }
   // WORK THIS BROWSER HOLDS THAT NO SAVED COPY HAS is kept aside before the newer copy replaces it
   // (v1.89). DIRTY knows only this session: after a reopen it was false, and the work went unasked.
   const own=ownUnsaved(MS, j.store, baseGet());
--- /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/u10/c3/tools/export-audit/audit-recon.mjs	2026-10-13 16:29:09.049471805 +0000
+++ /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/u10/c4/tools/export-audit/audit-recon.mjs	2026-10-13 18:31:50.968774834 +0000
@@ -5651,6 +5651,263 @@
   await settleBoards();
 })();
 // ==== end v2.00 (U10, the spend plan's choices) ====
+// ==== v2.00 (U10, the files, packages, ladder and shared copies): a file, a package, the ladder or a shared copy is refused in a locked view before anything is kept ====
+// The doors the round-2 reviews of 13 Oct and the builder's second door scan found beside the ones the blocks above close. Each
+// wrote something no part of the view's copy -- this appropriation's browser storage, another appropriation's board, a list every
+// appropriation shares, a kept-aside copy, the shared folder's record -- or handed a file out, and only then met the view's
+// refusal, so the board said "Not kept" and kept it: a returned package taken through Import one appropriation put 77777 for K1
+// into every export once the board reopened, and the work typed after the save was in no copy; a state file carrying cost
+// estimates kept them (the ACE tie-out read $4,321,000 for $900); the band ladder copied to Full Fund replaced its own; a package
+// issued, returned or sent back carried the cycle as the board; the shared state file kept the cycle aside as this browser's work;
+// a Live refresh from the shared folder did the same and recorded the folder's newer copy as the one the work came from, so the
+// first refresh after leaving the view replaced that work, kept nowhere. A cost estimate, BAE list or CCaR file whose import
+// started on the working plan, with PB27 put on screen while it was read, was kept too. Boards of two AV requirements -- A (USAF 900, ANG 200, on RCN 11111 / EEIC AAAAA, confirmed on WBS
+// 1.1) and R (USAF 503, ANG 127, no code) -- with an approved 2027 estimate (AV, 1.1, $900); PB27 locked; then the working plan
+// gives A the description WORK DESC A. Each door is used through the handler its control calls, with PB27 on screen (or put on
+// screen while the file is read), and then the status line, the questions asked, browser storage, the file handed out and the
+// cells of the exports the door reaches are read -- every figure typed here. FAILS ON 7ee498a (board fce8a391) and on U10 1-3.
+// CONTROLS: on the working plan each door is open and does what it did before.
+await (async () => {
+  const name = 'v2.00 (U10) — a file, a package, the band ladder or a shared copy is refused in a locked view before anything is kept';
+  const { bootMark, bootRelease, settleBoards } = await import('./boot.mjs');
+  const __bm = bootMark();
+  const boards = [];
+  try {
+    const J = JSON.stringify;
+    // one board, booted twice so it holds requirement data of its own (not the empty template), PB27 locked, then WORK DESC A
+    const mk = () => {
+      const X0 = boot(); boards.push(X0);
+      seed(X0.ev, { services: ['USAF', 'ANG', 'AFRC'], items: [it('A', 'AV', [900, 200, 0]), it('R', 'AV', [503, 127, 0])], disc: [5000, 5000, 5000], mand: [0, 0, 0], order: ['A', 'R'] });
+      X0.ev(`BASE_ITEMS.length=0; DATA.items.forEach(function(i){ BASE_ITEMS.push(i); BASE_ASK[i.id]=i.ask.slice(); });
+        MS.rcn=[{k:'K1', rcn:'11111', eeic:'AAAAA', t:'', svc:['USAF','ANG','AFRC']}]; S.rcnAsg={A:'K1'};
+        S.wbs={A:[{w:'1.1', v:[]}]}; S.aceMap={A:{w:['1.1'], ok:true}};
+        ACEDB.sets={'2027ACE':{lines:[{ap:mySlug(), pmo:'AV', wbs:'1.1', v:{}}], locked:true, by:'Approver', ts:1, file:'2027 ACE approved.xlsx'}};
+        ACEDB.sets['2027ACE'].lines[0].v[MS.cur]=900; aceYr='all'; persistAce(); applyState(S); save(); 'ok'`);
+      const ls = JSON.parse(X0.ev(`(function(){ var o={}; for(var i=0;i<localStorage.length;i++){ var k=localStorage.key(i); o[k]=localStorage.getItem(k); } return JSON.stringify(o); })()`));
+      const X = boot({ ls }); boards.push(X);
+      const ev = c => { try { return X.ev(c); } catch (e) { return 'threw: ' + String((e && e.message) || e).slice(0, 100); } };
+      ev(`globalThis.__wb=function(sheets, name){ var b=buildXlsx(sheets); return {name:name, arrayBuffer: async function(){ __reads++; return b.buffer.slice(b.byteOffset, b.byteOffset+b.byteLength); }}; };
+        globalThis.__reads=0;
+        globalThis.__aceRows=function(){ var rows=[[],[],[],[],[]]; rows[4][ACE_COL.y0]=2027; var r=[]; r[ACE_COL.appn]='O&M'; r[ACE_COL.svc]='USAF';
+          r[ACE_COL.managed]='Y'; r[ACE_COL.pmo]='AIR VEHICLE'; r[ACE_COL.y0]=4.321; r[ACE_COL.ce]='CE1'; rows.push(r);
+          rows.forEach(function(x){ for(var i=0;i<x.length;i++) if(x[i]===undefined) x[i]=''; }); return rows; };
+        // what a download hands out: the text of every Blob made while the code runs
+        globalThis.__handed=function(code){ var got=[], _B=window.Blob;
+          window.Blob=function(p,o){ try{ (p||[]).forEach(function(x){ if(typeof x==='string' && x.indexOf('spmtPkg')>=0) got.push(x); }); }catch(e){} return new _B(p,o); };
+          try{ (0,eval)(code); }catch(e){ got.push('threw '+String((e&&e.message)||e)); } window.Blob=_B; return JSON.stringify(got); };
+        'ok'`);
+      const key = ev(`window.confirm=function(){ return true; }; MS.base=MS.cur; MS.years[MS.cur]=S; save(); blCyc='PB'; blYr=MS.cur; cycLock(); blKey('PB', MS.cur)`);
+      ev(`setDesc('A','WORK DESC A'); 'ok'`);
+      return { X, ev, key };
+    };
+    const said = ev => ev(`(document.getElementById('shareStat')||{}).textContent||''`);
+    const spy = ev => ev(`window.__asked=[]; window.confirm=function(m){ window.__asked.push(String(m).split('\\n')[0].slice(0,70)); return true; };
+      window.alert=function(m){ window.__asked.push('alert: '+String(m).split('\\n')[0].slice(0,70)); }; 'ok'`);
+    const asked = ev => JSON.parse(ev(`JSON.stringify(window.__asked||[])`));
+    const wait = (X, ms) => X.ev(`new Promise(function(r){ setTimeout(r, ${ms}); })`);
+    const fileOf = (ev, text, nm) => ev(`(function(){ globalThis.__f=new File([${J(text)}], ${J(nm)}, {type:'application/json'}); return 'ok'; })()`);
+    // this appropriation's own copy in browser storage: its RCN codes and its descriptions
+    const own = ev => JSON.parse(ev(`(function(){ var s=JSON.parse(localStorage.getItem(_AP.key)||'null'); if(!s) return 'null';
+      var y=(s.years||{})[String(s.cur)]||{}; return JSON.stringify([(s.rcn||[]).map(function(e){ return e.rcn; }), (y.desc||{}).A||'', (y.desc||{}).R||'']); })()`));
+    const keptAside = ev => ev(`(function(){ var k=localStorage.getItem(_AP.key+'.kept'); if(!k) return 'none'; var i=k.indexOf('\\n'), m=JSON.parse(k.slice(0,i)), s=JSON.parse(k.slice(i+1));
+      var y=(s.years||{})[String(s.cur)]||{}; return JSON.stringify([m.why, (y.desc||{}).A||'']); })()`);
+    const hdr = (rows, ...must) => rows.findIndex(r => must.every(m => (r || []).some(c => String(c ?? '').trim() === m)));
+    const col = (rows, h, n) => (rows[h] || []).findIndex(c => String(c ?? '').trim() === n);
+    // the codes every export carries: RCN-EEIC by Month's summary, and the Spend Plan Source's lines [$, EEIC, RCN]
+    const codes = async W => { const bk = JSON.parse(await w6Book(W, 'exportExcel')), rc = bk['RCN-EEIC by Month'] || [];
+      const iReq = rc.findIndex(r => w6Lbl(r) === 'WHICH REQUIREMENTS SIT UNDER EACH COMBINATION');
+      const sb = JSON.parse(await w6Book(W, 'exportSrc')), src = (Object.values(sb).find(rs => (rs || []).length > 1) || []).slice(1);
+      return [bk.__err || 'ok', sb.__err || 'ok', v198Sec(rc, 0, iReq).map(r => r.slice(0, 3)),
+        src.map(r => [num(r[9]), String(r[26] ?? ''), String(r[27] ?? '')]).sort((a, b) => a[0] - b[0])]; };
+    // the ACE tie-out's Mapping by Requirement: [requirement, match, WBS, board funded, estimate, delta]
+    const tie = async W => { const ab = JSON.parse(await w6Book(W, 'exportAceTieout')), mp = ab['Mapping by Requirement'] || [], mh = hdr(mp, 'FY', 'PMO', 'Board funded');
+      return [ab.__err || 'ok', mp.slice(mh + 1).filter(r => /^FY\d\d$/.test(w6Lbl(r))).map(r => ['Requirement (CCaR Record Name)', 'Match', 'WBS claimed', 'Board funded', 'Estimate', 'Delta'].map(n => r[col(mp, mh, n)] ?? ''))]; };
+    // BY HAND. A's $1,100 sits on 11111 / AAAAA (USAF 900, ANG 200); R's $630 on no code (USAF 503, ANG 127); AFRC carries nothing,
+    // and its section prints a total of 0. The approved 2027ACE ties out A: $900 against $1,100 on 1.1, delta 200.
+    const N = v198NONE, K1 = '11111 / AAAAA';
+    const CODES = ['ok', 'ok', [['USAF', K1, 900], ['USAF', N, 503], ['USAF', 'USAF TOTAL', 1403], ['ANG', K1, 200], ['ANG', N, 127], ['ANG', 'ANG TOTAL', 327], ['AFRC', 'AFRC TOTAL', 0]],
+      [[127, '', ''], [200, 'AAAAA', '11111'], [503, '', ''], [900, 'AAAAA', '11111']]];
+    const TIE = ['ok', [['Req A', 'Confirmed - exact line', '1.1', 1100, 900, 200], ['Req R', 'No match', '', 630, '', '']]];
+    const OFF = what => '🔒 ' + what + ' is off while PB27 is on screen. It is a locked cycle, read only — the change was not kept. ↩ Leave the view to work the plan.';
+
+    // ==== 1. a returned package, through Import one appropriation (MF1), and the same with PB27 put on screen while it is read
+    {
+      const { X, ev, key } = mk();
+      const issued = JSON.parse(ev(`__handed("pkgIssue(mySlug(), true)")`)).map(t => JSON.parse(t))[0];
+      const ret = JSON.parse(J(issued)); ret.dir = 'return'; ret.by = 'Manager M'; ret.ts = Date.now() + 1000;
+      ret.ms.rcn = [{ k: 'K1', rcn: '77777', eeic: 'AAAAA', t: '', svc: ['USAF', 'ANG', 'AFRC'] }];
+      ret.ms.years[String(ret.ms.cur)].desc = Object.assign({}, ret.ms.years[String(ret.ms.cur)].desc || {}, { R: 'MGR DESC R' });
+      const fileHtml = ev(`buildSavedHtml()`);                 // the board saved to its file
+      ev(`setDesc('A','UNSAVED EDIT A'); 'ok'`);                 // then one more edit, in browser storage only
+      const OWN = [['11111'], 'UNSAVED EDIT A', ''];
+      ev(`cycView(${J(key)}); 'ok'`); spy(ev); fileOf(ev, J(ret), 'ORBIT PACKAGE - O&M - return 1.json');
+      ev(`importState({files:[__f], value:''}); 'ok'`); const st1 = said(ev); await wait(X, 2000);
+      w5Chk(name, 'PB27 viewed · the manager’s return (K1 → 77777, MGR DESC R) taken through Import one appropriation', 'refused before the file is read or a question asked, and the status line says so; browser storage still holds 11111 and UNSAVED EDIT A',
+        J([st1, asked(ev), own(ev)]), J([OFF('Importing a file'), [], OWN]));
+      ev(`cycLeave(); 'ok'`);
+      w5Chk(name, 'PB27 viewed · the return refused · the view left', 'the working plan’s exports carry 11111 for A and no 77777; browser storage as it was',
+        J([await codes(X.w), own(ev)]), J([CODES, OWN]));
+      // the same browser, reopened over the file saved before the view
+      const lsNow = JSON.parse(ev(`(function(){ var o={}; for(var i=0;i<localStorage.length;i++){ var k=localStorage.key(i); o[k]=localStorage.getItem(k); } return JSON.stringify(o); })()`));
+      const Y = boot({ html: fileHtml, ls: lsNow }); boards.push(Y);
+      w5Chk(name, 'PB27 viewed · the return refused · the browser reopened over the saved file', 'the board reopens on the work typed after the save (UNSAVED EDIT A), and its exports carry 11111 for A, no 77777',
+        J([Y.ev(`(S.desc||{}).A||''`), await codes(Y.w)]), J(['UNSAVED EDIT A', CODES]));
+      // started on the working plan; PB27 put on screen before the file is read
+      spy(ev); fileOf(ev, J(ret), 'ORBIT PACKAGE - O&M - return 1.json');
+      ev(`importState({files:[__f], value:''}); cycView(${J(key)}); 'ok'`); await wait(X, 2000);
+      w5Chk(name, 'the return taken on the working plan, PB27 put on screen before the file is read', 'refused once it is read, nothing asked; browser storage still holds 11111 and UNSAVED EDIT A',
+        J([said(ev), asked(ev), own(ev)]), J([OFF('Importing a file'), [], OWN]));
+      ev(`cycLeave(); 'ok'`);
+      // CONTROL: on the working plan the return is merged (asked first), and every export carries 77777 for A
+      spy(ev); fileOf(ev, J(ret), 'ORBIT PACKAGE - O&M - return 1.json');
+      ev(`importState({files:[__f], value:''}); 'ok'`); await wait(X, 2000);
+      const q = asked(ev).map(m => m.split(' — ')[0].split(' the returned')[0]);
+      w5Chk(name, 'the working plan · the return taken (allowed)', 'CONTROL — asked (the conflict, then the merge), merged: browser storage and every export carry 77777 for A, and MGR DESC R',
+        J([q, own(ev), await codes(X.w)]),
+        J([['CONFLICT', 'Merge'], [['77777'], 'WORK DESC A', 'MGR DESC R'],
+          ['ok', 'ok', [['USAF', '77777 / AAAAA', 900], ['USAF', N, 503], ['USAF', 'USAF TOTAL', 1403], ['ANG', '77777 / AAAAA', 200], ['ANG', N, 127], ['ANG', 'ANG TOTAL', 327], ['AFRC', 'AFRC TOTAL', 0]],
+            [[127, '', ''], [200, 'AAAAA', '77777'], [503, '', ''], [900, 'AAAAA', '77777']]]]));
+    }
+
+    // ==== 2. a state file carrying a cost estimate beside its years (SF4)
+    {
+      const { X, ev, key } = mk();
+      const stf = JSON.parse(ev(`JSON.stringify(MS)`));
+      stf.aceDb = { sets: { '2028ACE': { lines: [{ ap: 'om', pmo: 'AV', wbs: '1.1', v: { [String(stf.cur)]: 4321000 } }], locked: true, by: 'Someone', ts: 9, file: '2028 ACE.xlsx' } } };
+      const sets = () => ev(`JSON.stringify([Object.keys(ACEDB.sets||{}).sort(), Object.keys((JSON.parse(localStorage.getItem('prio27acedb')||'{}').sets)||{}).sort()])`);
+      ev(`cycView(${J(key)}); 'ok'`); spy(ev); fileOf(ev, J(stf), 'board-state.json');
+      ev(`importState({files:[__f], value:''}); 'ok'`); const st2 = said(ev); await wait(X, 2000);
+      w5Chk(name, 'PB27 viewed · a state file carrying a 2028 estimate ($4,321,000 on 1.1) taken through Import one appropriation', 'refused before the file is read; the estimates in the board and in browser storage are 2027ACE alone, and the ACE tie-out from the view ties out $900',
+        J([st2, asked(ev), sets(), await tie(X.w)]), J([OFF('Importing a file'), [], J([['2027ACE'], ['2027ACE']]), TIE]));
+      ev(`cycLeave(); 'ok'`);
+      w5Chk(name, 'PB27 viewed · the state file refused · the view left', 'the working plan’s estimates are 2027ACE alone, and its ACE tie-out ties out $900',
+        J([sets(), await tie(X.w)]), J([J([['2027ACE'], ['2027ACE']]), TIE]));
+      // CONTROL: on the working plan the state file is taken (asked first) with the estimate it carries
+      spy(ev); ev(`importState({files:[__f], value:''}); 'ok'`); await wait(X, 2000);
+      w5Chk(name, 'the working plan · the state file taken (allowed)', 'CONTROL — asked, taken: the board and browser storage hold 2027ACE and 2028ACE',
+        J([asked(ev).length, sets()]), J([1, J([['2027ACE', '2028ACE'], ['2027ACE', '2028ACE']])]));
+    }
+
+    // ==== 3. the workbook imports: refused before the file is read in a view, and once it is read when a view was put on screen meanwhile
+    {
+      const { X, ev, key } = mk();
+      const lists = () => JSON.parse(ev(`JSON.stringify((function(){ var s=ACEDB.sets['2027ACE'], a=JSON.parse(localStorage.getItem('prio27acedb')||'null'), b=JSON.parse(localStorage.getItem('prio27buddb')||'null'), t=a&&a.sets&&a.sets['2027ACE'];
+        return [s? [s.file||'', s.lines.map(function(l){ return (l.v||{})[MS.cur]; })] : null, t? [t.file||'', t.lines.map(function(l){ return (l.v||{})[MS.cur]; })] : null,
+          (BUDDB.rows||[]).map(function(r){ return r.n; }), b? (b.rows||[]).map(function(r){ return r.n; }) : null]; })())`));
+      const LISTS = [['2027 ACE approved.xlsx', [900]], ['2027 ACE approved.xlsx', [900]], [], null];
+      const FILES = {
+        ace: ['Importing a cost estimate', `importAce({files:[__wb([{name:'ACE', rows:__aceRows()}], '2027 ACE.xlsx')], value:''})`],
+        bud: ['Importing a BAE budget list', `importBud({files:[__wb([{name:'BAE', rows:[['Budget Name'], ['USAF O&M - ANG CAM ZZ9 Discretionary AV']]}], 'BAE.xlsx')], value:''})`],
+        ccar: ['Importing CCaR records', `importCcarRecs({files:[__wb([{name:'CCaR', rows:[['CCaR No','Title','OPR','PMO','Control No'], ['CCA','REFUSED TITLE A','REFUSED OPR','AV','7001']]}], 'ccar-records.xlsx')], value:''})`] };
+      // with PB27 on screen: the file is never read
+      for (const k of ['ace', 'bud', 'ccar']) {
+        const [door, code] = FILES[k];
+        ev(`cycView(${J(key)}); __reads=0; 'ok'`); spy(ev);
+        await ev(code);
+        w5Chk(name, 'PB27 viewed · ' + door.toLowerCase().replace(/^importing /, '') + ' imported', 'refused before the file is read (it is read 0 times, nothing asked); the lists in the board and in browser storage as they were',
+          J([said(ev), ev('__reads'), asked(ev), lists()]), J([OFF(door), 0, [], LISTS]));
+        ev(`cycLeave(); 'ok'`);
+      }
+      // started on the working plan; PB27 put on screen before the file has been read (the import's first wait)
+      for (const k of ['ace', 'bud', 'ccar']) {
+        const [door, code] = FILES[k];
+        spy(ev);
+        await ev(`(function(){ var p=${code}; cycView(${J(key)}); return p; })()`);
+        w5Chk(name, 'an import of ' + door.toLowerCase().replace(/^importing /, '') + ' started on the working plan, PB27 put on screen while the file is read', 'refused once it is read, nothing asked; the lists as they were, and the ACE tie-out from the view ties out $900',
+          J([said(ev), asked(ev), lists(), await tie(X.w)]), J([OFF(door), [], LISTS, TIE]));
+        ev(`cycLeave(); 'ok'`);
+      }
+      w5Chk(name, 'the three races · the view left', 'the working plan’s lists as they were, and its ACE tie-out ties out $900', J([lists(), await tie(X.w)]), J([LISTS, TIE]));
+
+      // ==== 4. the band ladder copied to the other appropriations (MF2): Full Fund's own ladder is "FF ONLY BAND", F1 banded in it
+      ev(`localStorage.setItem(_SLUGMAP.ff.key, JSON.stringify({base:2027, cur:2027, ts:5, years:{'2027':{order:[], band:{F1:'ffb'}}}, bands:[{id:'ffb', n:'FF ONLY BAND', rule:'', c:'#336699'}], bandsTs:5})); 'ok'`);
+      const ff = () => ev(`JSON.stringify([((JSON.parse(localStorage.getItem(_SLUGMAP.ff.key))||{}).bands||[]).map(function(b){ return b.n; }), localStorage.getItem(BAND_PEND_KEY('ff'))===null])`);
+      ev(`cycView(${J(key)}); 'ok'`); spy(ev);
+      ev(`bandCopyAll(); 'ok'`);
+      w5Chk(name, 'PB27 viewed · ⇉ Copy to the other appropriations', 'refused before anything is asked; Full Fund keeps its own ladder, and no ladder is held for it',
+        J([said(ev), asked(ev), ff()]), J([OFF('Copying the band ladder'), [], J([['FF ONLY BAND'], true])]));
+      ev(`cycLeave(); 'ok'`);
+
+      // ==== 5. the packages: issued, pushed, returned, sent back (SF1)
+      ev(`MS.pkg={ap:mySlug(), seq:3, baseSig:'SIG3', by:'Lead L', ts:1}; save(); 'ok'`);
+      const seq = () => ev(`(JSON.parse(localStorage.getItem(_AP.key)||'{}').sync||{}).seq||0`);
+      const PKGS = [['pkgIssue(mySlug(), true)', 'Issuing a package'], ['pkgPushAll()', 'Pushing baselines to the managers'],
+        ['pkgReturn()', 'Saving a return package'], ['pkgSendBack(mySlug())', 'Sending a package back']];
+      for (const [code, door] of PKGS) {
+        ev(`cycView(${J(key)}); 'ok'`); spy(ev);
+        const handed = JSON.parse(ev(`__handed(${J(code)})`)); await wait(X, 600);
+        w5Chk(name, 'PB27 viewed · ' + code, 'refused before anything is asked or handed out; no file, and the package record as it was',
+          J([said(ev), asked(ev), handed.length, seq()]), J([OFF(door), [], 0, 0]));
+        ev(`cycLeave(); 'ok'`);
+      }
+      // CONTROL: on the working plan each hands out the working plan (A described WORK DESC A)
+      spy(ev);
+      const hw = ['pkgIssue(mySlug(), true)', 'pkgReturn()', 'pkgSendBack(mySlug())'].map(c => JSON.parse(ev(`__handed(${J(c)})`)).map(t => { const p = JSON.parse(t);
+        return [p.dir, ((p.ms.years[String(p.ms.cur)] || {}).desc || {}).A || '']; }));
+      w5Chk(name, 'the working plan · a package issued, a return saved, the appropriation sent back (allowed)', 'CONTROL — each hands out one file carrying the working plan (WORK DESC A)',
+        J(hw), J([[['issue', 'WORK DESC A']], [['return', 'WORK DESC A']], [['return', 'WORK DESC A']]]));
+
+      // CONTROL: on the working plan the ladder is copied, and Full Fund takes it
+      ev(`bandCopyAll(); 'ok'`);
+      w5Chk(name, 'the working plan · ⇉ Copy to the other appropriations (allowed)', 'CONTROL — Full Fund’s ladder is now this one (no FF ONLY BAND), and one is held for it',
+        J([JSON.parse(ff())[0].includes('FF ONLY BAND'), JSON.parse(ff())[0].length > 1, JSON.parse(ff())[1]]), J([false, true, false]));
+    }
+
+    // ==== 6. the shared state file loaded (adoptShared), with work in this browser no saved copy has
+    {
+      const { ev, key } = mk();
+      ev(`SHARED=JSON.parse(JSON.stringify(MS)); SHARED.ts=MS.ts+60000; SHARED.by='Colleague C'; SHARED.years[String(MS.cur)].desc={R:'SHARED DESC R'}; baseSet({dirty:true}); DIRTY=false; 'ok'`);
+      ev(`cycView(${J(key)}); 'ok'`); spy(ev); ev(`adoptShared(); 'ok'`);
+      w5Chk(name, 'PB27 viewed · the shared state file loaded (adoptShared)', 'refused, and the status line says so; nothing is kept aside, and the work is still this browser’s unsaved work',
+        J([said(ev), keptAside(ev), own(ev), ev('!!baseGet().dirty')]), J([OFF('Loading the shared state file'), 'none', [['11111'], 'WORK DESC A', ''], true]));
+      ev(`cycLeave(); 'ok'`);
+    }
+    {
+      // CONTROL, on a board of its own: on the working plan the shared state file is loaded, the work kept aside first
+      const { ev } = mk();
+      ev(`SHARED=JSON.parse(JSON.stringify(MS)); SHARED.ts=MS.ts+60000; SHARED.by='Colleague C'; SHARED.years[String(MS.cur)].desc={R:'SHARED DESC R'}; baseSet({dirty:true}); DIRTY=false;
+        adoptShared(); 'ok'`);
+      w5Chk(name, 'the working plan · the shared state file loaded (allowed)', 'CONTROL — the work is kept aside first (WORK DESC A), and the shared copy is loaded (SHARED DESC R)',
+        J([keptAside(ev), own(ev)]), J([J(['sidecar', 'WORK DESC A']), [['11111'], '', 'SHARED DESC R']]));
+    }
+
+    // ==== 7. a Live refresh from the shared folder finding a colleague's newer copy, with work in this browser no saved copy has
+    {
+      const { X, ev, key } = mk();
+      const files = {};
+      const dir = { kind: 'directory', name: 'shared', queryPermission: async () => 'granted', requestPermission: async () => 'granted',
+        getFileHandle: async (n, o) => { if (!(n in files)) { if (o && o.create) files[n] = ''; else { const e = new Error('not found'); e.name = 'NotFoundError'; throw e; } }
+          return { kind: 'file', name: n, getFile: async () => { const c = files[n]; return { text: async () => c }; },
+            createWritable: async () => { let buf = ''; return { write: async x => { buf += String(x); }, close: async () => { files[n] = buf; } }; } }; },
+        getDirectoryHandle: async () => dir, removeEntry: async n => { delete files[n]; },
+        values: async function* () { for (const n of Object.keys(files)) yield { kind: 'file', name: n, getFile: async () => ({ text: async () => files[n] }) }; } };
+      X.w.__fold = dir;
+      ev(`_liveCfg=Object.assign(liveCfg(), {store:true, mode:'drive', on:false}); _driveDir=globalThis.__fold; 'ok'`);
+      const pushed = await X.ev('driveStorePush(false)');
+      const fn = Object.keys(files).find(n => /^spmt-2027-om\.json$/.test(n));
+      const j = JSON.parse(files[fn]); j.store.ts = (+j.store.ts || 0) + 60000; j.ts = j.store.ts; j.by = 'Colleague C'; j.store.by = 'Colleague C';
+      j.store.years[String(j.store.cur)].desc = Object.assign({}, j.store.years[String(j.store.cur)].desc || {}, { R: 'COLLEAGUE DESC R' });
+      files[fn] = J(j);
+      ev(`setDesc('A','MY UNSAVED A'); DIRTY=false; 'ok'`);        // typed, kept in browser storage only; then a new session
+      ev(`cycView(${J(key)}); 'ok'`); spy(ev);
+      const p1 = await X.ev('driveStorePull(true)');
+      w5Chk(name, 'PB27 viewed · a Live refresh finds Colleague C’s newer copy in the shared folder', 'nothing loaded, nothing kept aside, and the work is still this browser’s unsaved work',
+        J([pushed, p1, keptAside(ev), own(ev), ev('!!baseGet().dirty')]), J([true, false, 'none', [['11111'], 'MY UNSAVED A', ''], true]));
+      const p2 = await X.ev('driveStorePull(false)');
+      w5Chk(name, 'PB27 viewed · 📡 Connect (a refresh that speaks)', 'refused, and the status line says so', J([p2, said(ev)]), J([false, OFF('Loading from the shared folder')]));
+      ev(`cycLeave(); 'ok'`);
+      const p3 = await X.ev('driveStorePull(true)');
+      w5Chk(name, 'PB27 viewed · the view left · the next Live refresh', 'the work (MY UNSAVED A) is kept aside first, and Colleague C’s copy is loaded (COLLEAGUE DESC R)',
+        J([p3, keptAside(ev), own(ev)]), J([true, J(['folder', 'MY UNSAVED A']), [['11111'], 'WORK DESC A', 'COLLEAGUE DESC R']]));
+    }
+    w5Chk(name, 'harness', 'CONTROL — no jsdom script errors', J(boards.reduce((n, B) => n + B.errors.length, 0)), J(0));
+  } catch (e) {
+    failures.push({ scenario: name, where: 'harness', what: 'the block threw: ' + String((e && e.message) || e).slice(0, 160), got: 'threw', want: 'ran' });
+  }
+  bootRelease(__bm, []);
+  await settleBoards();
+})();
+// ==== end v2.00 (U10, the files, packages, ladder and shared copies) ====
 
 {
   const src = _selfRead(_selfPath(import.meta.url), 'utf8');
--- /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/u10/c3/tools/export-audit/mutate.mjs.txt	2026-10-13 16:12:08.021945405 +0000
+++ /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/u10/c4/tools/export-audit/mutate.mjs.txt	2026-10-13 18:25:50.823019108 +0000
@@ -4374,6 +4374,47 @@
   { id: "v200-u10-dest-kind-in-view", area: "flowSetEnt", what: "only a destination's name is refused in PB27's view: Lockheed Martin's kind, set to government there, is kept for every appropriation and in browser storage while the board says the change was not kept",
     find: "  if(cycBlock('Changing a destination')){ render(); return; }\n",
     repl: "  if(field==='n' && cycBlock('Changing a destination')){ render(); return; }\n" },
+  // v2.00 (U10, fix round 2 of 13 Oct): a file, a package, the band ladder or a shared copy is refused in a locked view before
+  // anything is kept, and an import a view was put on screen during is refused once its file is read.
+  { id: "v200-u10-state-import-in-view", area: "importState", what: "Import one appropriation takes a returned package while PB27 is on screen: it asks its conflict question of the view's copy, writes the package into browser storage and then says \"Not kept\"; the board reopens on 77777 for K1 and the work typed after the save is gone",
+    find: "  // reopened on what it had refused.\n  if(CYCVIEW){ cycRefuse('Importing a file'); inp.value=''; return; }\n",
+    repl: "  // reopened on what it had refused.\n" },
+  { id: "v200-u10-state-import-race", area: "importState", what: "a returned package whose import started on the working plan is merged into browser storage once its file is read, though PB27 was put on screen meanwhile",
+    find: "  r.onload=()=>{\n    if(CYCVIEW){ cycRefuse('Importing a file'); inp.value=''; return; }\n",
+    repl: "  r.onload=()=>{\n" },
+  { id: "v200-u10-ace-import-race", area: "importAce", what: "a cost estimate whose import started on the working plan replaces the approved 2027ACE once its file is read, though PB27 was put on screen meanwhile ($4,321,000 for $900 in the ACE tie-out)",
+    find: "    if(cycBlock('Importing a cost estimate')){ inp.value=''; return; }   // v2.00 (U10): as importBud\n",
+    repl: "" },
+  { id: "v200-u10-bud-import-race", area: "importBud", what: "a BAE list whose import started on the working plan is stored once its file is read, though PB27 was put on screen meanwhile",
+    find: "    if(cycBlock('Importing a BAE budget list')){ inp.value=''; return; }   // v2.00 (U10): and again once it is read -- a view put on screen meanwhile\n",
+    repl: "" },
+  { id: "v200-u10-ccar-import-race", area: "importCcarRecs", what: "CCaR records whose import started on the working plan are counted and \"Save to bake\" is said once the file is read, though PB27 was put on screen meanwhile",
+    find: "    if(cycBlock('Importing CCaR records')){ inp.value=''; return; }   // v2.00 (U10): as importBud\n",
+    repl: "" },
+  { id: "v200-u10-ladder-copy-in-view", area: "bandCopyAll", what: "the band ladder copied to the other appropriations while PB27 is on screen replaces Full Fund's own ladder (FF ONLY BAND) and holds one for it, then says \"Not kept\"",
+    find: "  if(cycBlock('Copying the band ladder')) return;   // v2.00 (U10): it wrote the other appropriations' boards, then said \"Not kept\"\n",
+    repl: "" },
+  { id: "v200-u10-pkg-issue-in-view", area: "pkgIssue", what: "a package issued while PB27 is on screen hands out the cycle as the board's package, and records nothing",
+    find: "  if(cycBlock('Issuing a package')) return;\n",
+    repl: "" },
+  { id: "v200-u10-pkg-push-in-view", area: "pkgPushAll", what: "Push baselines to the managers asks, and hands out the cycle on screen, while PB27 is on screen",
+    find: "  if(cycBlock('Pushing baselines to the managers')) return;   // v2.00 (U10): as pkgIssue\n",
+    repl: "" },
+  { id: "v200-u10-pkg-sendback-in-view", area: "pkgSendBack", what: "an appropriation sent back from the consolidated while PB27 is on screen carries the cycle as the board, and says nothing on this board changed",
+    find: "  if(cycBlock('Sending a package back')) return;   // v2.00 (U10): as pkgIssue -- it sent the cycle on screen back as the board\n",
+    repl: "" },
+  { id: "v200-u10-pkg-return-in-view", area: "pkgReturn", what: "a manager's return package saved while PB27 is on screen carries the cycle as the manager's work, under the issue's number",
+    find: "  if(cycBlock('Saving a return package')) return;   // v2.00 (U10): as pkgIssue -- it returned the cycle on screen as the work\n",
+    repl: "" },
+  { id: "v200-u10-shared-load-in-view", area: "sharedKeepMine", what: "the shared state file loaded while PB27 is on screen keeps the cycle aside as this browser's work, then the load is refused",
+    find: "  if(cycBlock('Loading the shared state file')) return false;\n",
+    repl: "" },
+  { id: "v200-u10-folder-pull-in-view", area: "driveStorePull", what: "a Live refresh while PB27 is on screen keeps the cycle aside as this browser's work and records the folder's newer copy as the one the work came from, saved; the first refresh after leaving the view replaces that work, kept nowhere",
+    find: "  if(CYCVIEW){ if(!quiet) cycRefuse('Loading from the shared folder'); render(); return false; }\n",
+    repl: "" },
+  { id: "v200-u10-folder-connect-quiet", area: "driveStorePull", what: "a Connect (a refresh that speaks) while PB27 is on screen loads nothing and says nothing",
+    find: "if(CYCVIEW){ if(!quiet) cycRefuse('Loading from the shared folder'); render(); return false; }",
+    repl: "if(CYCVIEW){ render(); return false; }" },
   // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.
   { id: "v200-r3-landed-view-unsaid", area: "_driveStorePushRun", what: "a folder save that lands while a locked view is on screen says “🔒 Not kept — PB27 is a locked view. ✅ Saved …” again, naming no plan (or, quiet, leaves persist's refusal on screen)",
     find: "  if(CYCVIEW){ _cycRefusedAt=0; setStat('✅ <b>Saved the working plan</b> of '+esc(APPN_LBL[ap]||ap)+' FY'+(fy%100)+' to the shared folder — '\n    +Math.round(body.length/1024)+' KB, built before '+blLbl(CYCVIEW)+' was put on screen. '+blLbl(CYCVIEW)+' is a locked view: nothing in it '\n    +'is saved. Everyone sees the working plan on their next refresh.'+penNote+lateNote); render(); return true; }\n",
```

### `diffs/c3-vs-c2.all.diff` (commit 3, the round-2 test review's proposal, adopted byte for byte)

```diff
--- /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/u10/c2/prioritization-board-grid.html	2026-10-13 13:21:45.604803462 +0000
+++ /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/u10/c3/prioritization-board-grid.html	2026-10-13 16:08:39.245398702 +0000
@@ -2545,13 +2545,17 @@
     if(spAce!=='board' && !Object.prototype.hasOwnProperty.call(ACEDB.sets||{}, spAce)) spAce='board';
   }catch(e){}
 }
-function setSpAce(v){ spAce=v; MS.spAce=v; save(); render(); }
-function setSpBy(v){ spBy=v; MS.spBy=v; save(); render(); }
-function setSpPmo(v){ spPmo=v; MS.spPmo=v; save(); render(); }
-function setSpSvc(v){ spSvc=v; MS.spSvc=v; save(); render(); }
-function setSpPrior(v){ spPrior=v; MS.spPrior=v; save(); render(); }
+function setSpAce(v){ if(spRefused()) return; spAce=v; MS.spAce=v; save(); render(); }
+function setSpBy(v){ if(spRefused()) return; spBy=v; MS.spBy=v; save(); render(); }
+function setSpPmo(v){ if(spRefused()) return; spPmo=v; MS.spPmo=v; save(); render(); }
+function setSpSvc(v){ if(spRefused()) return; spSvc=v; MS.spSvc=v; save(); render(); }
+function setSpPrior(v){ if(spRefused()) return; spPrior=v; MS.spPrior=v; save(); render(); }
 // which service the PMO drill is scoped to: 'ALL' for the summary across every service
-function setSpDrillSvc(v){ spDrillSvc=v; MS.spDrillSvc=v; save(); render(); }
+function setSpDrillSvc(v){ if(spRefused()) return; spDrillSvc=v; MS.spDrillSvc=v; save(); render(); }
+// v2.00 (U10): THE SPEND PLAN'S CHOICES ARE REFUSED UP FRONT while a locked cycle is on screen. Each was set on the page first and
+// then saved, which the view refused: the board said "the change was not kept" and kept the choice, so the ACE tie-out taken from
+// the view, and from the working plan after leaving it, tied out the estimate chosen in the view.
+function spRefused(){ if(!cycBlock('Changing the spend plan')) return false; render(); return true; }
 function syncSvc(){
   if(SVC_FROM_DATA) return;
   const v = (typeof MS!=='undefined' && MS && Array.isArray(MS.svc)) ? MS.svc : [];
--- /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/u10/c2/tools/export-audit/audit-recon.mjs	2026-10-13 13:33:28.304845232 +0000
+++ /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/u10/c3/tools/export-audit/audit-recon.mjs	2026-10-13 16:29:09.049471805 +0000
@@ -5552,6 +5552,105 @@
   await settleBoards();
 })();
 // ==== end v2.00 (U10, the shared lists) ====
+// ==== v2.00 (U10, the spend plan's choices): a spend-plan choice, a PPBE position or a destination's kind refused in a locked view leaves no trace ====
+// The Spend Plan's choices -- its Cost data (the estimate the ACE tie-out ties out), By PMO / By Service and the two prior years --
+// were set on the page first and then saved, which the view refused: the board said "the change was not kept" and kept the choice,
+// so the ACE tie-out taken from the view, and from the working plan after leaving it, tied out the estimate chosen in the view (the
+// U10 round-2 test review, 13 Oct). A PPBE position is kept beside the years (MS.ppbe), so only a refusal that makes the whole copy
+// again puts it back (the blocks above read the codes, the bands and the funds flow, not the positions). A destination's kind is
+// changed through a field of its own, which the shared-lists block above does not use (it renames). A board of two AV
+// requirements -- A (USAF 900, ANG 200, confirmed on WBS 1.1) and R (USAF 503, ANG 127) -- with two approved estimates, 2027ACE (AV,
+// 1.1, $900) and 2026ACE (AV, 1.1, $333 for FY27), the Spend Plan on 2027ACE by PMO, and the working plan tagged PB27 with USAF's
+// FY27 position logged at $1,000. PB27 is locked and viewed; each choice is made through the control the Spend Plan renders, and
+// the position through the handler its cell calls. FAILS ON 7ee498a (board fce8a391) and on the U10 commits: the Spend Plan shows
+// 2026ACE by Service with the prior years, and the ACE tie-out from the view and from the working plan ties out 2026ACE ($333);
+// on 7ee498a the FYDP Spend Plan from the view also prints the refused $5,000 position, and Lockheed Martin is kept a government
+// activity for every appropriation and in browser storage. CONTROLS: PB27 viewed, nothing chosen; on
+// the working plan the Cost data choice is open, kept, and the tie-out reads it; no jsdom errors. Every figure is typed here.
+await (async () => {
+  const name = 'v2.00 (U10) — a spend-plan choice, a PPBE position or a destination’s kind refused in a locked view leaves no trace';
+  const { bootMark, bootRelease, settleBoards } = await import('./boot.mjs');
+  const __bm = bootMark();
+  try {
+    const J = JSON.stringify;
+    const X = boot();
+    seed(X.ev, { services: ['USAF', 'ANG', 'AFRC'], items: [it('A', 'AV', [900, 200, 0]), it('R', 'AV', [503, 127, 0])], disc: [5000, 5000, 5000], mand: [0, 0, 0], order: ['A', 'R'] });
+    const ev = c => { try { return X.ev(c); } catch (e) { return 'threw: ' + String((e && e.message) || e).slice(0, 100); } };
+    ev(`BASE_ITEMS.length=0; DATA.items.forEach(function(i){ BASE_ITEMS.push(i); BASE_ASK[i.id]=i.ask.slice(); });
+      S.wbs={A:[{w:'1.1', v:[]}]}; S.aceMap={A:{w:['1.1'], ok:true}};
+      ACEDB.sets={'2027ACE':{lines:[{ap:mySlug(), pmo:'AV', wbs:'1.1', v:{}}], locked:true, by:'Approver', ts:2, file:'2027 ACE approved.xlsx'},
+        '2026ACE':{lines:[{ap:mySlug(), pmo:'AV', wbs:'1.1', v:{}}], locked:true, by:'Approver', ts:1, file:'2026 ACE approved.xlsx'}};
+      ACEDB.sets['2027ACE'].lines[0].v[MS.cur]=900; ACEDB.sets['2026ACE'].lines[0].v[MS.cur]=333; aceYr='all';
+      persistAce(); applyState(S); save(); setSpAce('2027ACE');
+      cycSetWorking('PB', MS.cur); ppCyc='PB'; ppYr=MS.cur; ppLineAdd('USAF'); ppSetV('USAF', ppLines(ppPos(),'USAF')[0].k, MS.cur, 'd', '1000'); 'ok'`);
+    const key = ev(`window.confirm=function(){ return true; }; MS.base=MS.cur; MS.years[MS.cur]=S; save(); blCyc='PB'; blYr=MS.cur; cycLock(); blKey('PB', MS.cur)`);
+    const notKept = () => /the change was not kept|Not kept/.test(ev(`(document.getElementById('shareStat')||{}).textContent||''`));
+    // the Spend Plan as drawn on screen: its Cost data choice, and which of By PMO / By Service / ◀ prior 2 FY is pressed
+    const onScreen = () => JSON.parse(ev(`(function(){ if(!spOpen){ spOpen=true; render(); }
+      var s=[].slice.call(document.querySelectorAll('select')).filter(function(e){ return (e.getAttribute('onchange')||'')==='setSpAce(this.value)'; }).map(function(e){ return e.value; });
+      var b=[].slice.call(document.querySelectorAll('button')).filter(function(e){ return /^setSp(By|Prior)\\(/.test(e.getAttribute('onclick')||'') && e.classList.contains('on'); }).map(function(e){ return e.textContent; });
+      return JSON.stringify([s, b]); })()`));
+    // a control the Spend Plan renders: the Cost data select (a value chosen, change fired) or a button (clicked)
+    const press = (on, value) => ev(`(function(){ if(!spOpen){ spOpen=true; render(); } var el=[].slice.call(document.querySelectorAll('select, button')).filter(function(e){
+      return (e.getAttribute('onchange')||e.getAttribute('onclick')||'')===${J(on)}; })[0]; if(!el) return 'no control';
+      if(el.tagName==='SELECT'){ el.value=${J(value || '')}; el.dispatchEvent(new Event('change', {bubbles:true})); } else el.click(); return 'fired'; })()`);
+    const hdr = (rows, ...must) => rows.findIndex(r => must.every(m => (r || []).some(c => String(c ?? '').trim() === m)));
+    const col = (rows, h, n) => (rows[h] || []).findIndex(c => String(c ?? '').trim() === n);
+    // the ACE tie-out and the FYDP Spend Plan, read from their bytes
+    const tie = async () => { const ab = JSON.parse(await w6Book(X.w, 'exportAceTieout')), mp = ab['Mapping by Requirement'] || [], mh = hdr(mp, 'FY', 'PMO', 'Board funded');
+      const rc = ab['Reconciliation by PMO'] || [], rh = hdr(rc, 'FY', 'PMO', 'Estimate');
+      return [ab.__err || 'ok', w6Lbl(mp[0]), mp.slice(mh + 1).filter(r => /^FY\d\d$/.test(w6Lbl(r))).map(r => ['Requirement (CCaR Record Name)', 'Board funded', 'Estimate', 'Delta'].map(n => r[col(mp, mh, n)] ?? '')),
+        rc.slice(rh + 1).filter(r => w6Lbl(r) === 'FY27' && String(r[1] ?? '') === 'AV').map(r => [r[0], r[1], r[2], r[3], r[4]])]; };
+    const pos = async () => { const fb = JSON.parse(await w6Book(X.w, 'exportFydpPlan')), bs = fb['By Service'] || [], h = hdr(bs, 'Service'), c = col(bs, h, 'FY27 PPBE position');
+      return [fb.__err || 'ok', bs.slice(h + 1).filter(r => ['USAF', 'ANG', 'AFRC', 'TOTAL'].includes(w6Lbl(r))).map(r => [w6Lbl(r), r[c]])]; };
+    const stored = () => ev(`(JSON.parse(localStorage.getItem(_AP.key)||'{}')||{}).spAce||''`);
+    // BY HAND. 2027ACE: A's $1,100 funded against $900 on 1.1 (delta 200); AV $900 against $1,730 funded (A 1,100 + R 630; delta 830).
+    // 2026ACE: $333 against the same (767; 1,397). USAF's FY27 position $1,000; no other service logs one.
+    const T900 = ['ok', 'ACE TIE-OUT - MAPPING BY REQUIREMENT  (2027ACE, FY27)', [['Req A', 1100, 900, 200], ['Req R', 630, '', '']], [['FY27', 'AV', 900, 1730, 830]]];
+    const T333 = ['ok', 'ACE TIE-OUT - MAPPING BY REQUIREMENT  (2026ACE, FY27)', [['Req A', 1100, 333, 767], ['Req R', 630, '', '']], [['FY27', 'AV', 333, 1730, 1397]]];
+    const POS = ['ok', [['USAF', 1000], ['ANG', '—'], ['AFRC', '—'], ['TOTAL', 1000]]];
+    const SCREEN = [['2027ACE'], ['By PMO']];
+    const view = () => ev(`cycView(${J(key)}); 'ok'`), leave = () => ev(`cycLeave(); 'ok'`);
+    // ---- CONTROL: PB27 viewed, nothing chosen
+    view();
+    w5Chk(name, 'PB27 viewed, nothing chosen', 'CONTROL — the Spend Plan shows 2027ACE by PMO; the ACE tie-out ties out 2027ACE ($900); the FYDP Spend Plan prints USAF’s FY27 position, $1,000',
+      J([onScreen(), await tie(), await pos()]), J([SCREEN, T900, POS]));
+    // ---- EACH CHOICE, with PB27 on screen; the status line is read at once ('Not kept' is put in front of a message for 1.5 s only)
+    const fa = press('setSpAce(this.value)', '2026ACE'), ka = notKept();
+    w5Chk(name, 'PB27 viewed · Cost data set to 2026ACE in its select', 'refused and said so; the Spend Plan still shows 2027ACE, and the ACE tie-out taken from the view ties out 2027ACE ($900)',
+      J([fa, ka, onScreen(), await tie()]), J(['fired', true, SCREEN, T900]));
+    const fb = press("setSpBy('svc')"), kb = notKept(), fp = press('setSpPrior(!spPrior)'), kp = notKept();
+    w5Chk(name, 'PB27 viewed · By Service, then ◀ prior 2 FY, pressed', 'each refused and said so; the Spend Plan is still by PMO, without the prior years',
+      J([fb, kb, fp, kp, onScreen()]), J(['fired', true, 'fired', true, SCREEN]));
+    ev(`setSpPmo('AV'); setSpSvc('USAF'); setSpDrillSvc('USAF'); 'ok'`); const kf = notKept();
+    w5Chk(name, 'PB27 viewed · the PMO filter, the service filter and the PMO drill’s service set (the handlers their controls call)', 'each refused and said so; each is still all',
+      J([kf, ev('JSON.stringify([spPmo, spSvc, spDrillSvc])')]), J([true, J(['ALL', 'ALL', 'ALL'])]));
+    ev(`ppCyc='PB'; ppYr=MS.cur; ppSetV('USAF', ppLines(ppPos(),'USAF')[0].k, MS.cur, 'd', '5000'); 'ok'`); const kv = notKept();
+    w5Chk(name, 'PB27 viewed · USAF’s FY27 PPBE position typed as $5,000', 'refused and said so; the FYDP Spend Plan taken from the view prints the position as logged, $1,000',
+      J([kv, await pos()]), J([true, POS]));
+    const fd = ev(`(function(){ if(!entOpen) toggleEnt(); var i=flowEnts().findIndex(function(e){ return e.n==='Lockheed Martin'; });
+      var s=[].slice.call(document.querySelectorAll('#entBody select')).filter(function(e){ return (e.getAttribute('onchange')||'')==='flowSetEnt('+i+',"kind",this.value)'; })[0];
+      if(!s) return 'no control'; s.value='gov'; s.dispatchEvent(new Event('change', {bubbles:true})); return 'fired'; })()`), kd = notKept();
+    const kinds = ev(`JSON.stringify([flowEnts().filter(function(e){ return e.n==='Lockheed Martin'; }).map(function(e){ return e.kind; }),
+      ((JSON.parse(localStorage.getItem(DEST_KEY)||'null')||{}).ents||[]).filter(function(e){ return e.n==='Lockheed Martin'; }).map(function(e){ return e.kind; })])`);
+    ev(`if(entOpen) toggleEnt(); 'ok'`);
+    w5Chk(name, 'PB27 viewed · Lockheed Martin’s kind set to government in Setup › Destinations', 'refused and said so; it is still a prime contractor, in the board and in browser storage',
+      J([fd, kd, kinds]), J(['fired', true, J([['prime'], ['prime']])]));
+    leave();
+    w5Chk(name, 'PB27 viewed · each choice refused · the view left', 'the working plan’s Spend Plan shows 2027ACE by PMO, browser storage keeps 2027ACE, and its ACE tie-out ties out 2027ACE ($900)',
+      J([onScreen(), stored(), await tie()]), J([SCREEN, '2027ACE', T900]));
+    // ---- CONTROL: on the working plan the choice is open, kept, and the tie-out reads it
+    const fw = press('setSpAce(this.value)', '2026ACE');
+    w5Chk(name, 'the working plan · Cost data set to 2026ACE (allowed)', 'CONTROL — the Spend Plan’s Cost data shows 2026ACE, browser storage keeps it, and the ACE tie-out ties out 2026ACE ($333)',
+      J([fw, onScreen()[0], stored(), await tie()]), J(['fired', ['2026ACE'], '2026ACE', T333]));
+    w5Chk(name, 'harness', 'CONTROL — no jsdom script errors', J(X.errors.length), J(0));
+  } catch (e) {
+    failures.push({ scenario: name, where: 'harness', what: 'the block threw: ' + String((e && e.message) || e).slice(0, 160), got: 'threw', want: 'ran' });
+  }
+  bootRelease(__bm, []);
+  await settleBoards();
+})();
+// ==== end v2.00 (U10, the spend plan's choices) ====
 
 {
   const src = _selfRead(_selfPath(import.meta.url), 'utf8');
--- /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/u10/c2/tools/export-audit/mutate.mjs.txt	2026-10-13 13:29:56.644981936 +0000
+++ /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/u10/c3/tools/export-audit/mutate.mjs.txt	2026-10-13 16:12:08.021945405 +0000
@@ -4342,6 +4342,38 @@
   { id: "v200-u10-dest-reset-in-view", area: "flowResetEnts", what: "reset the list, answered OK while PB27 is on screen: Depot X is dropped for every appropriation and in browser storage, and back on the working plan R's $630 is not yet assigned",
     find: "  if(cycBlock('Resetting the destination list')){ render(); return; }   // v2.00 (U10): as flowSetEnt\n",
     repl: "" },
+  // v2.00 (U10, the round-2 test review of 13 Oct): the Spend Plan's choices are refused up front in a locked view, and a refusal puts
+  // back the PPBE positions with the rest of the copy.
+  { id: "v200-u10-sp-choice-in-view", area: "spRefused", what: "the Spend Plan's choices are set and then saved in PB27's view, as before: the board says the change was not kept, the Spend Plan shows 2026ACE by Service, and the ACE tie-out from the view and from the working plan after leaving ties out 2026ACE ($333 for $900)",
+    find: "function spRefused(){ if(!cycBlock('Changing the spend plan')) return false; render(); return true; }",
+    repl: "function spRefused(){ return false; }" },
+  { id: "v200-u10-sp-ace-in-view", area: "setSpAce", what: "the Spend Plan's Cost data, chosen in PB27's view, is kept on the page while the board says it was not: the ACE tie-out from the view and from the working plan after leaving ties out 2026ACE ($333 for $900)",
+    find: "function setSpAce(v){ if(spRefused()) return; ",
+    repl: "function setSpAce(v){ " },
+  { id: "v200-u10-sp-by-in-view", area: "setSpBy", what: "By Service, pressed in PB27's view, is kept on the page while the board says it was not, and the working plan's Spend Plan is by service after leaving",
+    find: "function setSpBy(v){ if(spRefused()) return; ",
+    repl: "function setSpBy(v){ " },
+  { id: "v200-u10-sp-pmo-in-view", area: "setSpPmo", what: "the Spend Plan's PMO filter, set in PB27's view, is kept on the page while the board says it was not",
+    find: "function setSpPmo(v){ if(spRefused()) return; ",
+    repl: "function setSpPmo(v){ " },
+  { id: "v200-u10-sp-svc-in-view", area: "setSpSvc", what: "the Spend Plan's service filter, set in PB27's view, is kept on the page while the board says it was not",
+    find: "function setSpSvc(v){ if(spRefused()) return; ",
+    repl: "function setSpSvc(v){ " },
+  { id: "v200-u10-sp-prior-in-view", area: "setSpPrior", what: "◀ prior 2 FY, pressed in PB27's view, is kept on the page while the board says it was not",
+    find: "function setSpPrior(v){ if(spRefused()) return; ",
+    repl: "function setSpPrior(v){ " },
+  { id: "v200-u10-sp-drill-in-view", area: "setSpDrillSvc", what: "the PMO drill's service, set in PB27's view, is kept on the page while the board says it was not",
+    find: "function setSpDrillSvc(v){ if(spRefused()) return; ",
+    repl: "function setSpDrillSvc(v){ " },
+  { id: "v200-u10-sp-no-redraw", area: "spRefused", what: "a Spend Plan choice refused in PB27's view leaves the chosen estimate in its select on screen, as if it were kept",
+    find: "if(!cycBlock('Changing the spend plan')) return false; render(); return true; }",
+    repl: "if(!cycBlock('Changing the spend plan')) return false; return true; }" },
+  { id: "v200-u10-reapply-keeps-ppbe", area: "cycReapply", what: "the view's copy is made again but keeps the refused copy's PPBE positions: USAF's FY27 position typed as $5,000 in PB27's view is printed by the FYDP Spend Plan taken from the view, for the $1,000 logged",
+    find: "  MS=cycCopy(c); MS.cur=y;",
+    repl: "  const P0=MS.ppbe; MS=cycCopy(c); MS.cur=y; MS.ppbe=P0;" },
+  { id: "v200-u10-dest-kind-in-view", area: "flowSetEnt", what: "only a destination's name is refused in PB27's view: Lockheed Martin's kind, set to government there, is kept for every appropriation and in browser storage while the board says the change was not kept",
+    find: "  if(cycBlock('Changing a destination')){ render(); return; }\n",
+    repl: "  if(field==='n' && cycBlock('Changing a destination')){ render(); return; }\n" },
   // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.
   { id: "v200-r3-landed-view-unsaid", area: "_driveStorePushRun", what: "a folder save that lands while a locked view is on screen says “🔒 Not kept — PB27 is a locked view. ✅ Saved …” again, naming no plan (or, quiet, leaves persist's refusal on screen)",
     find: "  if(CYCVIEW){ _cycRefusedAt=0; setStat('✅ <b>Saved the working plan</b> of '+esc(APPN_LBL[ap]||ap)+' FY'+(fy%100)+' to the shared folder — '\n    +Math.round(body.length/1024)+' KB, built before '+blLbl(CYCVIEW)+' was put on screen. '+blLbl(CYCVIEW)+' is a locked view: nothing in it '\n    +'is saved. Everyone sees the working plan on their next refresh.'+penNote+lateNote); render(); return true; }\n",
```
