# U10 — independent verify, round 2, Lens B (test adequacy and regressions)

Track U10 (ledger row U10, P2, export correctness): "a refused edit never changes what any export carries". This review
covers the builder's fix round of 13 Oct (`rec/L6/u10`, result `wfstate/fix_u10_r1.json`): commit 1 revised as copy
`c1r`, commit 2 new as copy `c2`. Work dir: `rec/L6/u10/verify-tests-r2`. Written 13 Oct 2026, about 1:40 PM ET.

## Verdict: unsound as a close of U10 (the builder's two commits are sound as far as they go)

Every number the builder reports that I re-ran reproduced exactly (table below). The new checks are typed literals, every
non-control check fails on the base and every control passes there, and the suites and `mutate.mjs.txt` only add lines.
But the builder's central claim -- "the refused-but-kept doors are exactly the seven now gated" -- is false, and the
remaining door moves money in an export:

**MF1 (money in an export; principles 3 and 4).** The Spend Plan's six choices (`setSpAce`, `setSpBy`, `setSpPmo`,
`setSpSvc`, `setSpPrior`, `setSpDrillSvc`, board lines 2548-2554 of c2) set a page global first and then `save()`, which a
locked view refuses. The board says "🔒 Saving is off while PB27 is on screen … the change was not kept" and keeps the
choice. `exportAceTieout` reads the global `spAce` (board line 29309), so the ACE tie-out ties out the refused estimate,
in the view AND on the working plan after leaving -- even after an ordinary save there, with browser storage holding the
working plan's choice. Measured with `probe/vt2probe2.mjs` (runs VQ-c2 and VQ-base, 12:04 PM ET, exit 0; VQ-c3 12:56 PM
ET). Steps: two approved estimates, 2027ACE (AV, WBS 1.1, $900) and 2026ACE ($333 for FY27); the working plan's Spend Plan
on 2027ACE; PB27 locked and viewed; 2026ACE chosen in the Spend Plan's "Cost data" select. On c2 (and identically on the
base): status "🔒 Saving is off … the change was not kept"; select shows 2026ACE; ACE tie-out from the view: title
"(2026ACE, FY27)", Req A estimate 333 / delta 767 (should be 900 / 200), AV reconciliation 333 / 1730 / 1397 (should be
900 / 1730 / 830). After leaving: `MS.spAce` and browser storage say 2027ACE, the export still says 2026ACE / $333; after a
save, the same. By Service and the prior years stay pressed on the working plan too. The builder's own draft says only "A
Spend Plan selector chosen in a view is still on screen after leaving it (as before)" and "The Spend Plan's service
selector keeps its choice in a view, as before" -- the money effect is not stated, and U10 is drafted as closed.
**Minimal fix, measured** (copy `c3`, proposed commit "U10 3 of 3"): refuse the six choices up front in a view, the
pattern commit 2 uses (+10 −6 board lines; diff below). With it, VQ-c3: refused with "🔒 Changing the spend plan is off
while PB27 is on screen …", select stays 2027ACE, tie-out 900 / 200 and 900 / 1730 / 830 in the view, after leaving and
after a save. A new 9-check block (6 fail on the base, 4 on c2, 0 on c3; 3 controls pass on all) and 10 mutation
entries, each caught. If the lead does not take it, the drafts must not call U10 closed and the ledger needs the row in
`proposal/DRAFTS-U10-commit3.md` (4).

**SF1 (test gap; commit 1).** A refusal now makes the whole copy again, but the blocks read only the codes, offices,
bands, funds flow, FY28, CCaR index and base year. My mutant `om-reapply-field-list` (a refusal puts back a NAMED list of
seven fields instead of the whole copy -- a plausible "smaller" fix) passes all 74 checks of the builder's harness (OM, 0
of 74). It leaves a PPBE position typed in the view in the FYDP Spend Plan's By Service cell ($5,000 printed for the
$1,000 logged, probe VQ-om-reapply-field-list; the base does the same, VQ-base). My block's PPBE check catches it (OM4, 1
of 83) and so does the proposed entry `v200-u10-reapply-keeps-ppbe` (PM, 1 of 83).

**SF2 (test gap; commit 2).** The shared-lists block tests a destination's NAME only, and its `lists()`/`stored()` read
names only. My mutant `om-dest-gate-name-only` (flowSetEnt's refusal only when `field==='n'`) passes all 74 checks (OM, 0
of 74), and with it a destination's kind changed in the view is kept for every appropriation and in browser storage while
the status line says not kept (probe VP-om-dest-gate-name-only, earlier attempt, 11:38 AM ET: kinds `gov` / stored `gov`).
The builder says this field was "checked by reading the code only". My block's kind check catches it (OM4, 1 of 83; entry
`v200-u10-dest-kind-in-view`, PM, 1 of 83). The match-terms field (`t`) is still untested.

**Minor.** (a) Three of my own mutants survive and I judge them equivalent or near-equivalent: `om-cycblock-no-reapply`
(every one of the board's 27 `cycBlock` calls is the first statement of its function, so nothing has changed to put
back), `om-reapply-no-link` (the year on screen a detached copy of the copy's year; both hold the same content and every
later write goes through `save()`, which makes the copy again), `om-dest-del-after-elsewhere` (only the message differs,
and only when another appropriation uses the destination; nothing is removed either way). (b) The builder's result says
"Other suites at c2, all exit 0 (07:34–11:37 past 10 AM ET)": the times are 10:07:34–10:11:37 AM ET. (c) Commit 1's
NEXT-VERSION "What users may see" sentence "The Spend Plan's service selector keeps its choice in a view, as before" is
contradicted by the line the board shows ("the change was not kept"); it goes with MF1.

### Decision principles, for the proposed commit 3
1. No copy lost: the choice is refused before anything is set; nothing on the working plan or in storage changes.
2. Refuse rather than guess: refused up front, as the imports and the destination list are in commit 2.
3. Money and exports exact: the ACE tie-out ties out PB27's / the working plan's 2027ACE ($900) after the refusal.
4. Words true: "Changing the spend plan is off … the change was not kept" is now true; before, it was not.
5. Smallest change: six one-line guards and one 1-line helper (`spRefused`) using the board's own `cycBlock`.
6. Checks preserved: the suite and `mutate.mjs.txt` diffs only add lines; mcount 1355 entries, each matching once; no
   existing expectation changed. The six setter lines change (no mutation entry names them: mcount confirms).

## Identities (git hash-object)

| copy | board | audit-recon | mutate.mjs.txt | audit-import / audit-board / audit-other |
|---|---|---|---|---|
| base (7ee498a, product d66dd60) | fce8a391 | 529e36f7 | cbc6defc | 4aba2506 / a7c575e5 / d89396b0 |
| c1r (builder, commit 1 revised) | 4a8b0be3 | 746dac83 | c6c1ea47 | unchanged |
| c2 (builder, commit 2) | cfc9e14f | 2c4c466a | 3a408399 | unchanged |
| **c3 (mine: c2 + proposed commit 3)** | **1704bb11** | **29654c37** | **b90ce05e** | unchanged |

My `base`, `c1r`, `c2` copies are byte-identical to `rec/L6/base` and the builder's `c1r` / `c2` (checked by blob). `c3` =
`cp -a c2`, then `bin/mkc3board.py` (board), the block `proposal/block-u10-spend-plan.mjs.txt` (blob 0825d7e5) inserted after
`// ==== end v2.00 (U10, the shared lists) ====`, and `proposal/entries-u10-sp.mjs.txt` (d4924cc4) inserted before the R3
line of `mutate.mjs.txt`. Diffs: `diffs/c3-vs-c2.{prioritization-board-grid.html,audit-recon.mjs,mutate.mjs.txt}.diff` and
`diffs/c3-vs-c2.all.diff` (2768ea82). c2 → c3: board +10 −6, audit-recon +99 −0, mutate +32 −0.

Harnesses (built by `bin/mkfocused-u10.py`, the builder's method, blocks verbatim): `harness/c2/focused-u10.mjs` b4112c05
(item 83, item 88, the three U10 blocks; identical to the builder's `harness/c2` apart from the header path line),
`harness/c1r/focused-u10.mjs` 4ded91af (identical likewise), `harness/c3/focused-u10.mjs` a9f1f007 (those plus my block).
`harness/c3x/`: audit-board PPBE (`mkfocused-board.py`, the builder's, regenerated; 95e7142c), audit-import R3 / W3 (the
builder's c2 files, copied; the suites are the same blobs). `runner.mjs` is the builder's, unchanged but for its header.

## The builder's numbers, re-run

| builder's claim | mine | run(s) |
|---|---|---|
| F5 on c2: 74/74 pass | 0 of 74 fail, exit 0 | F-c2 (earlier attempt, 11:30 AM) |
| F5 on base: U10 18 fail, beside 4, lists 21; every control passes | 43 of 74 fail: 18 / 4 / 21, all non-control; all 20 controls pass; item 88 11/11 | F-c2-on-base (11:32 AM), `bin/basefail.py` |
| F5 on c1r: lists 21 fail, its 6 controls pass | 21 of 74, exactly the lists block's non-controls | F-c2-on-c1r (11:34 AM) |
| F4c1r on c1r 0 fail; on base 18 + 4 | 0 of 47; 22 of 47 (18 + 4, all non-control) | F-c1r, F-c1r-on-base (12:02 PM) |
| mcount base 1328, c1r 1337, c2 1345, each once | same | MC-base/-c1r/-c2 (11:26–11:27 AM) |
| 17 v200-u10 entries at c2 (of 74): year-only 21, keeps-list 17, keeps-years 5, keeps-pmos 2, first-year 2, older-keeps-list 1, wrong-year 1, keeps-plan-settings 2, working-base 1, ace 15, bae 13, ccar 1, dest-change 9, no-redraw 1, dest-add 8, dest-remove 5, dest-reset 2 | identical, every one | BM-* (12:08 PM–1:06 PM) |
| audit-inject with existing entries: bae-depts-raw 2, fname-ace-raw 2, ace-key-open 1 failing | 2 / 2 / 1 failing, exit 1 each | INJ-* (1:12–1:17 PM) |
| full audit-recon c2 and base pass | ALL CHECKS PASSED both; outputs 0 differing lines | S-audit-recon-c2 (12:02), -base (12:08) |
| npm run check c2 and base pass | all checks passed both | N-check-c2, N-check-base (11:37–11:38 AM) |
| other suites same output as base | boot-same, audit, audit-ppt, audit-other, legacy-fsrc, audit-hostile, audit-inject: all exit 0 on base and on c3; c3 vs base 0 differing lines each (`bin/cmplogs.py`, the builder's) | S-*-base, S-*-c3 (12:41–1:12 PM) |
| audit-board PPBE 141/141; audit-import R3 / W3 pass | on c3: B-ppbe-c3, I-r3-c3, I-w3-c3 all exit 0 | (1:11–1:19 PM) |

Not re-run: the builder's 9 entries at c1r (the same entries are caught at c2 by the same blocks), the round-1 reviewers'
12 vt-* and the builder's 3 ow-* mutants, the c1r full audit-recon. The c2 copies of the five suites other than
audit-recon were not re-run (the builder ran them; I ran them on c3, which contains c2).

## Expected values, base failures, changed expectations

* Every expected value in the three new builder blocks is a typed literal or built from the suite's own literal tables
  (`v198K` / `v198Lab`, `v198NONE`, the block's `LOCKED`, `LIST`, `PANEL`, `ALIGN`, `MAP`, `BANDS`, `FLOW`, `MAPPING`,
  `SOURCE`, `DEST`, `ACE0`, and the `OFF(door)` template over a typed door name). Board helpers are used only for observed
  values. Two CONTROLs compare a byte snapshot taken earlier in the block (the cycle store and browser storage), as
  controls.
* On the base, all 43 non-control checks fail and all 20 controls pass (`bin/basefail.py` over F-c2-on-base and F-c2).
* The two status-line reads round 1 found timing-dependent now read at once; I found no other status read after an export.
* Against the base, audit-recon is +429 −0 and mutate.mjs.txt +57 −0; audit-import, audit-board and audit-other are
  unchanged. No existing check, fixture or expected value is changed.

## My own mutants (plausible wrong fixes)

| mutant (spec in `ownmut-spec.json`) | what it is | builder's blocks (of 74) | with my block (of 83) |
|---|---|---|---|
| om-reapply-field-list | a refusal puts back seven named fields, not the whole copy | **0 — survives** | 1 (the PPBE check), on c3 |
| om-dest-gate-name-only | flowSetEnt refuses only a rename | **0 — survives** | 1 (the kind check), on c3 |
| om-reapply-keeps-screen-year | the copy made again around the refused year on screen | 5 | — |
| om-ace-persist-only | importAce reads and keeps the estimate in memory, only the storing refused | 15 | — |
| om-bud-wrong-door | importBud's refusal names the cost-estimate door | 1 | — |
| om-copy-shares-flow | the copy shares the working plan's funds-flow object | 1 | — |
| om-cycblock-no-reapply | an up-front refusal does not make the copy again | 0 (equivalent: every cycBlock call is first in its function) | — |
| om-reapply-no-link | the year on screen a detached copy of the copy's year | 0 (judged equivalent) | 0 |
| om-dest-del-after-elsewhere | flowDelEnt's refusal after the in-use check | 0 (only a message differs, untested case) | 0 |
| proto-sp-resync (a first prototype of a fix, not a mutant) | a refusal re-reads the Spend Plan's choices from the copy | 0 of 74 | not adopted: it puts back spAce but not By Service when the plan never stored one (VQ-proto-sp-resync) |

The proposed entries, run through `harness/c3` against c3 mutants (of 83): sp-choice-in-view 4, sp-ace-in-view 3,
sp-by-in-view 2, sp-pmo-in-view 1, sp-svc-in-view 1, sp-prior-in-view 2, sp-drill-in-view 1, sp-no-redraw 2,
reapply-keeps-ppbe 1, dest-kind-in-view 1. All caught. mcount on c3: 1355 entries, each matching once (MC-c3b).

The proposed block on each board (harness/c3, a9f1f007): c3 0 of 83 fail (F-c3b); c2 4 fail, the four Spend Plan checks
(F-c3b-on-c2); base 49 fail = 43 + its 6 non-controls (F-c3b-on-base); its 3 controls pass everywhere. Full audit-recon
on c3: ALL CHECKS PASSED (S-audit-recon-c3r, 340.5 s), 0 differing lines against the base's output.

## Process notes (plainly)

* The earlier attempt of this review (11:26–11:44 AM ET) ran more than two node processes at once: four recorded runs
  overlapped at 11:37:54 AM ET (F-c2-on-c1r, N-check-c2, OM-om-dest-gate-name-only, VP-base), and F-c1r and
  OM-om-cycblock-no-reapply started later without exit records. Its lane driver batch1 reached its own 600 s cap. Its one
  `node --check` ran outside run.sh (noted in pids.txt at the time). I reused only its runs that have exit records on the
  same blobs, and re-ran F-c1r, F-c1r-on-base and the cycblock mutant.
* In this attempt, from 12:01 PM ET, at most two node processes of mine ran at a time: two lanes, then `qrun.sh` drivers
  that take one shared file lock and count my node processes before each start.
* Two runs lost their run.sh exit record because their lane driver hit its own 600 s cap under load (load average 20–27
  on 4 CPUs): BM-v200-u10-dest-change-no-redraw (12:17 PM; its node finished, "# exit 1 at 12:18:47 PM ET", and it was
  re-run with a record at 12:28 PM) and S-audit-recon-c3 (12:40 PM; its node printed ALL CHECKS PASSED at about 12:49 PM;
  re-run as S-audit-recon-c3r at 1:31 PM by run.sh directly, with a record). Both are noted in pids.txt and runs.txt.
* Superseded runs: F-c3, F-c3-on-c2 and F-c3-on-base used the first version of my block, whose working-plan CONTROL also
  read the By Service button (on c2 and base the refused By Service leaks into it, so that control failed there). The
  control now reads only the Cost data choice; F-c3b, F-c3b-on-c2, F-c3b-on-base are the runs that count.
* The scratch clone `gitclone/` (git clone --shared of orbit-board, checked out at 7ee498a) held c2's and then c3's files
  only for `npm run check`; its own files were put back each time (hashes in logs/npmcheck3.out). Nothing was committed,
  staged or pushed anywhere; /home/user/orbit-board and /home/user/orbit-ui were only read. mutate.mjs was never imported
  or run (text only, through mkmut.py / mcount.py).
* The AUDIT_IMPORT_RUNNING lock was absent at every check (run.sh checks before each run; no run waited or was skipped).

## Not done

* Full audit-import and audit-board (the lead's), and the full-suite sensitivity of any entry.
* The builder's c1r entries, the round-1 vt-* / ow-* mutants and c1r's full audit-recon were not re-run (see above).
* The destination match-terms field (`t`) is not tested by any block (mine included).
* My proposal was not run through Chromium (no Chromium tool covers these handlers); jsdom only.

## Every run (from logs/runs.txt; start times ET, 13 Oct; "result" is the focused harness's failing checks or the log's last line)

Runs from 11:26 to 11:43 AM ET are the earlier attempt's (reused: they have exit records on the same blobs). PIDs of every
run, with its command, are in `pids.txt` (also the notes on the two driver-cap incidents and the resume).

| label | start (ET) | exit | wall s | result | log |
|---|---|---|---|---|---|
| MC-base | 11:26:51 | 0 | 10.8 | {"entries": 1328, "once": 1328, "missing": [], "multiple": [], "unparsed": []} | logs/MC-base.log |
| MC-c1r | 11:27:02 | 0 | 13.7 | {"entries": 1337, "once": 1337, "missing": [], "multiple": [], "unparsed": []} | logs/MC-c1r.log |
| MC-c2 | 11:27:15 | 0 | 10.0 | {"entries": 1345, "once": 1345, "missing": [], "multiple": [], "unparsed": []} | logs/MC-c2.log |
| MK-focused-c2 | 11:29:51 | 0 | 0.3 | written /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scrat | logs/MK-focused-c2.log |
| MK-focused-c1r | 11:29:51 | 0 | 0.2 | written /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scrat | logs/MK-focused-c1r.log |
| F-c2 | 11:30:15 | 0 | 130.6 | 0 of 74 checks fail | logs/F-c2.log |
| OM-make | 11:32:48 | 0 | 2.5 | {"id": "om-dest-del-after-elsewhere", "base": "c2", "matches": [1], "out": "/tmp/claude-0/ | logs/OM-make.log |
| F-c2-on-base | 11:32:25 | 1 | 152.8 | 43 of 74 checks fail | logs/F-c2-on-base.log |
| MK-mutants | 11:36:04 | 0 | 22.4 | 9 | logs/MK-mutants.log |
| VP-c2 | 11:37:03 | 0 | 33.6 | PROBE c2 cfc9e14f369653212d9faa6d56b3d602b9210c03 written /tmp/claude-0/-home-user-Word-Ma | logs/VP-c2.log |
| F-c2-on-c1r | 11:34:58 | 1 | 189.4 | 21 of 74 checks fail | logs/F-c2-on-c1r.log |
| VP-base | 11:37:37 | 0 | 34.5 | PROBE base fce8a391bd8a248d5185e199d22190c1687eaea0 written /tmp/claude-0/-home-user-Word- | logs/VP-base.log |
| N-check-c2 | 11:37:54 | 0 | 19.0 | all checks passed | logs/N-check-c2.log |
| N-check-base | 11:38:13 | 0 | 19.5 | all checks passed | logs/N-check-base.log |
| VP-om-dest-gate-name-only | 11:38:12 | 0 | 40.1 | PROBE om-dest-gate-name-only 41af5972d404d1b5344bc3560b877584f2c3cc66 written /tmp/claude- | logs/VP-om-dest-gate-name-only.log |
| VP-om-reapply-field-list | 11:38:52 | 0 | 36.9 | PROBE om-reapply-field-list 0b2e780bd39961b8e38392347872fe90813c114e written /tmp/claude-0 | logs/VP-om-reapply-field-list.log |
| PROTO-make | 11:39:37 | 0 | 0.9 | {"id": "proto-sp-resync", "base": "c2", "matches": [1], "out": "/tmp/claude-0/-home-user-W | logs/PROTO-make.log |
| OM-om-dest-gate-name-only | 11:36:40 | 0 | 208.7 | 0 of 74 checks fail | logs/OM-om-dest-gate-name-only.log |
| VP-proto-sp-resync | 11:40:01 | 0 | 32.5 | PROBE proto-sp-resync 0ac7bcf54b5936f8d73b910362410f8cdc58d58a written /tmp/claude-0/-home | logs/VP-proto-sp-resync.log |
| OM-om-reapply-field-list | 11:40:09 | 0 | 199.1 | 0 of 74 checks fail | logs/OM-om-reapply-field-list.log |
| F-proto-sp-resync | 11:40:34 | 0 | 198.1 | 0 of 74 checks fail | logs/F-proto-sp-resync.log |
| F-c1r | 12:02:00 | 0 | 20.2 | 0 of 47 checks fail | logs/F-c1r.log |
| F-c1r-on-base | 12:02:21 | 1 | 30.5 | 22 of 47 checks fail | logs/F-c1r-on-base.log |
| VQ-c2 | 12:04:21 | 0 | 17.2 | PROBE2 c2 cfc9e14f369653212d9faa6d56b3d602b9210c03 written /tmp/claude-0/-home-user-Word-M | logs/VQ-c2.log |
| VQ-base | 12:04:48 | 0 | 21.1 | PROBE2 base fce8a391bd8a248d5185e199d22190c1687eaea0 written /tmp/claude-0/-home-user-Word | logs/VQ-base.log |
| VQ-proto-sp-resync | 12:05:09 | 0 | 23.8 | PROBE2 proto-sp-resync 0ac7bcf54b5936f8d73b910362410f8cdc58d58a written /tmp/claude-0/-hom | logs/VQ-proto-sp-resync.log |
| VQ-om-reapply-field-list | 12:05:33 | 0 | 24.6 | PROBE2 om-reapply-field-list 0b2e780bd39961b8e38392347872fe90813c114e written /tmp/claude- | logs/VQ-om-reapply-field-list.log |
| S-audit-recon-c2 | 12:02:01 | 0 | 298.0 | ALL CHECKS PASSED | logs/S-audit-recon-c2.log |
| BM-v200-u10-ace-import-in-view | 12:08:17 | 1 | 112.1 | 15 of 74 checks fail | logs/BM-v200-u10-ace-import-in-view.log |
| MC-c3 | 12:10:10 | 0 | 7.9 | {"entries": 1354, "once": 1354, "missing": [], "multiple": [], "unparsed": []} | logs/MC-c3.log |
| MK-focused-c3 | 12:10:18 | 0 | 0.3 | written /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scrat | logs/MK-focused-c3.log |
| BM-v200-u10-bae-import-in-view | 12:10:09 | 1 | 107.6 | 13 of 74 checks fail | logs/BM-v200-u10-bae-import-in-view.log |
| MC-c3b | 12:12:08 | 0 | 14.8 | {"entries": 1355, "once": 1355, "missing": [], "multiple": [], "unparsed": []} | logs/MC-c3b.log |
| MK-focused-c3b | 12:12:22 | 0 | 0.3 | written /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scrat | logs/MK-focused-c3b.log |
| BM-v200-u10-ccar-import-in-view | 12:11:57 | 1 | 130.3 | 1 of 74 checks fail | logs/BM-v200-u10-ccar-import-in-view.log |
| S-audit-recon-base | 12:08:18 | 0 | 365.5 | ALL CHECKS PASSED | logs/S-audit-recon-base.log |
| BM-v200-u10-dest-add-in-view | 12:14:08 | 1 | 106.9 | 8 of 74 checks fail | logs/BM-v200-u10-dest-add-in-view.log |
| F-c3 | 12:14:30 | 0 | 120.7 | 0 of 83 checks fail | logs/F-c3.log |
| BM-v200-u10-dest-change-in-view | 12:15:55 | 1 | 94.9 | 9 of 74 checks fail | logs/BM-v200-u10-dest-change-in-view.log |
| F-c3-on-c2 | 12:16:31 | 1 | 103.6 | 5 of 83 checks fail | logs/F-c3-on-c2.log |
| BM-v200-u10-dest-change-no-redraw | 12:28:47 | 1 | 121.6 | 1 of 74 checks fail | logs/BM-v200-u10-dest-change-no-redraw.log |
| F-c3-on-base | 12:28:44 | 1 | 148.5 | 50 of 83 checks fail | logs/F-c3-on-base.log |
| BM-v200-u10-dest-remove-in-view | 12:30:53 | 1 | 116.9 | 5 of 74 checks fail | logs/BM-v200-u10-dest-remove-in-view.log |
| F-c3b | 12:31:34 | 0 | 136.8 | 0 of 83 checks fail | logs/F-c3b.log |
| BM-v200-u10-dest-reset-in-view | 12:32:51 | 1 | 113.3 | 2 of 74 checks fail | logs/BM-v200-u10-dest-reset-in-view.log |
| F-c3b-on-c2 | 12:33:56 | 1 | 116.7 | 4 of 83 checks fail | logs/F-c3b-on-c2.log |
| BM-v200-u10-reapply-first-year | 12:34:57 | 1 | 125.9 | 2 of 74 checks fail | logs/BM-v200-u10-reapply-first-year.log |
| F-c3b-on-base | 12:35:54 | 1 | 159.4 | 49 of 83 checks fail | logs/F-c3b-on-base.log |
| BM-v200-u10-reapply-keeps-list | 12:37:19 | 1 | 118.6 | 17 of 74 checks fail | logs/BM-v200-u10-reapply-keeps-list.log |
| PM-v200-u10-dest-kind-in-view | 12:38:41 | 1 | 125.6 | 1 of 83 checks fail | logs/PM-v200-u10-dest-kind-in-view.log |
| BM-v200-u10-reapply-keeps-plan-settings | 12:39:38 | 1 | 115.3 | 2 of 74 checks fail | logs/BM-v200-u10-reapply-keeps-plan-settings.log |
| S-boot-same-c3 | 12:41:36 | 0 | 47.1 | every page, source, save and error list is identical either way | logs/S-boot-same-c3.log |
| PM-v200-u10-reapply-keeps-ppbe | 12:42:29 | 1 | 155.8 | 1 of 83 checks fail | logs/PM-v200-u10-reapply-keeps-ppbe.log |
| S-boot-same-base | 12:45:08 | 0 | 40.4 | every page, source, save and error list is identical either way | logs/S-boot-same-base.log |
| BM-v200-u10-reapply-keeps-pmos | 12:45:54 | 1 | 119.8 | 2 of 74 checks fail | logs/BM-v200-u10-reapply-keeps-pmos.log |
| S-audit-other-c3 | 12:47:56 | 0 | 128.5 | ALL CHECKS PASSED | logs/S-audit-other-c3.log |
| BM-v200-u10-reapply-keeps-years | 12:49:44 | 1 | 156.8 | 5 of 74 checks fail | logs/BM-v200-u10-reapply-keeps-years.log |
| PM-v200-u10-sp-ace-in-view | 12:50:14 | 1 | 182.4 | 3 of 83 checks fail | logs/PM-v200-u10-sp-ace-in-view.log |
| S-audit-c3 | 12:52:25 | 0 | 56.6 | ALL CHECKS PASSED | logs/S-audit-c3.log |
| S-audit-other-base | 12:53:21 | 0 | 160.7 | ALL CHECKS PASSED | logs/S-audit-other-base.log |
| S-audit-ppt-c3 | 12:56:07 | 0 | 21.8 | ALL CHECKS PASSED | logs/S-audit-ppt-c3.log |
| VQ-c3 | 12:56:33 | 0 | 19.4 | PROBE2 c3 1704bb11ddc5a60235b7c5c9c05e24a13eafd8cd written /tmp/claude-0/-home-user-Word-M | logs/VQ-c3.log |
| BM-v200-u10-reapply-older-keeps-list | 12:54:34 | 1 | 145.6 | 1 of 74 checks fail | logs/BM-v200-u10-reapply-older-keeps-list.log |
| S-audit-base | 12:56:57 | 0 | 35.8 | ALL CHECKS PASSED | logs/S-audit-base.log |
| PM-v200-u10-sp-by-in-view | 12:57:00 | 1 | 140.7 | 2 of 83 checks fail | logs/PM-v200-u10-sp-by-in-view.log |
| BM-v200-u10-reapply-working-base | 12:57:34 | 1 | 120.0 | 1 of 74 checks fail | logs/BM-v200-u10-reapply-working-base.log |
| BM-v200-u10-reapply-wrong-year | 13:02:18 | 1 | 102.4 | 1 of 74 checks fail | logs/BM-v200-u10-reapply-wrong-year.log |
| S-legacy-fsrc-c3 | 13:04:02 | 0 | 12.7 |   every legacy Force setting computes exactly as before | logs/S-legacy-fsrc-c3.log |
| PM-v200-u10-sp-choice-in-view | 13:02:16 | 1 | 124.6 | 4 of 83 checks fail | logs/PM-v200-u10-sp-choice-in-view.log |
| S-audit-ppt-base | 13:04:21 | 0 | 16.1 | ALL CHECKS PASSED | logs/S-audit-ppt-base.log |
| BM-v200-u10-reapply-year-only | 13:04:38 | 1 | 123.2 | 21 of 74 checks fail | logs/BM-v200-u10-reapply-year-only.log |
| S-legacy-fsrc-base | 13:06:44 | 0 | 11.9 |   every legacy Force setting computes exactly as before | logs/S-legacy-fsrc-base.log |
| S-audit-hostile-c3 | 13:04:40 | 0 | 200.5 | ALL CHECKS PASSED | logs/S-audit-hostile-c3.log |
| PM-v200-u10-sp-drill-in-view | 13:06:57 | 1 | 137.9 | 1 of 83 checks fail | logs/PM-v200-u10-sp-drill-in-view.log |
| S-audit-inject-c3 | 13:09:19 | 0 | 43.0 | ========================================================================================== | logs/S-audit-inject-c3.log |
| S-audit-hostile-base | 13:08:01 | 0 | 189.2 | ALL CHECKS PASSED | logs/S-audit-hostile-base.log |
| B-ppbe-c3 | 13:11:11 | 0 | 35.1 | ALL CHECKS PASSED | logs/B-ppbe-c3.log |
| PM-v200-u10-sp-no-redraw | 13:10:06 | 1 | 121.9 | 2 of 83 checks fail | logs/PM-v200-u10-sp-no-redraw.log |
| S-audit-inject-base | 13:11:50 | 0 | 33.9 | ========================================================================================== | logs/S-audit-inject-base.log |
| I-r3-c3 | 13:12:09 | 0 | 43.9 | ALL CHECKS PASSED | logs/I-r3-c3.log |
| INJ-v200-bae-depts-raw | 13:12:56 | 1 | 43.6 | ========================================================================================== | logs/INJ-v200-bae-depts-raw.log |
| PM-v200-u10-sp-pmo-in-view | 13:12:27 | 1 | 122.3 | 1 of 83 checks fail | logs/PM-v200-u10-sp-pmo-in-view.log |
| INJ-v200-fname-ace-raw | 13:14:31 | 1 | 36.5 | ========================================================================================== | logs/INJ-v200-fname-ace-raw.log |
| PM-v200-u10-sp-prior-in-view | 13:15:11 | 1 | 111.4 | 2 of 83 checks fail | logs/PM-v200-u10-sp-prior-in-view.log |
| INJ-v200-ace-key-open | 13:17:05 | 1 | 41.7 | ========================================================================================== | logs/INJ-v200-ace-key-open.log |
| I-w3-c3 | 13:13:40 | 0 | 339.0 | ALL CHECKS PASSED | logs/I-w3-c3.log |
| N-check-c3 | 13:19:22 | 0 | 7.5 | all checks passed | logs/N-check-c3.log |
| PM-v200-u10-sp-svc-in-view | 13:17:51 | 1 | 102.2 | 1 of 83 checks fail | logs/PM-v200-u10-sp-svc-in-view.log |
| OM-om-cycblock-no-reapply | 13:19:42 | 0 | 69.4 | 0 of 74 checks fail | logs/OM-om-cycblock-no-reapply.log |
| OM-om-reapply-no-link | 13:20:52 | 0 | 74.6 | 0 of 74 checks fail | logs/OM-om-reapply-no-link.log |
| OM-om-reapply-keeps-screen-year | 13:22:23 | 1 | 76.9 | 5 of 74 checks fail | logs/OM-om-reapply-keeps-screen-year.log |
| OM-om-bud-wrong-door | 13:23:40 | 1 | 79.3 | 1 of 74 checks fail | logs/OM-om-bud-wrong-door.log |
| OM-om-copy-shares-flow | 13:25:04 | 1 | 65.9 | 1 of 74 checks fail | logs/OM-om-copy-shares-flow.log |
| OM-om-ace-persist-only | 13:26:11 | 1 | 52.5 | 15 of 74 checks fail | logs/OM-om-ace-persist-only.log |
| OM-om-dest-del-after-elsewhere | 13:27:07 | 0 | 52.9 | 0 of 74 checks fail | logs/OM-om-dest-del-after-elsewhere.log |
| OM3-om-dest-gate-name-only | 13:28:01 | 1 | 71.1 | 5 of 83 checks fail | logs/OM3-om-dest-gate-name-only.log |
| OM3-om-reapply-field-list | 13:29:28 | 1 | 70.6 | 5 of 83 checks fail | logs/OM3-om-reapply-field-list.log |
| OM-make-c3 | 13:31:19 | 0 | 0.6 | {"id": "om-dest-del-after-elsewhere-c3", "base": "c3", "matches": [1], "out": "/tmp/claude | logs/OM-make-c3.log |
| OM4-om-dest-del-after-elsewhere-c3 | 13:31:30 | 0 | 91.1 | 0 of 83 checks fail | logs/OM4-om-dest-del-after-elsewhere-c3.log |
| OM4-om-dest-gate-name-only-c3 | 13:33:02 | 1 | 98.1 | 1 of 83 checks fail | logs/OM4-om-dest-gate-name-only-c3.log |
| OM4-om-reapply-field-list-c3 | 13:34:51 | 1 | 94.3 | 1 of 83 checks fail | logs/OM4-om-reapply-field-list-c3.log |
| S-audit-recon-c3r | 13:31:20 | 0 | 340.5 | ALL CHECKS PASSED | logs/S-audit-recon-c3r.log |
| OM4-om-reapply-no-link-c3 | 13:36:26 | 0 | 94.1 | 0 of 83 checks fail | logs/OM4-om-reapply-no-link-c3.log |

Probes: `probe/vt2probe.mjs` (6b82e2c4; earlier attempt: VP-c2, VP-base, VP-om-dest-gate-name-only, VP-om-reapply-field-list,
VP-proto-sp-resync; outputs `out/VP-*.json`) and `probe/vt2probe2.mjs` (11f544be; VQ-c2, VQ-base, VQ-proto-sp-resync,
VQ-om-reapply-field-list, VQ-c3; outputs `out/VQ-*.json`). Per-check records of every focused run: `out/checks/<label>.jsonl`.

## The proposed commit 3, exact diff against c2 (`diffs/c3-vs-c2.all.diff`)

```diff
--- /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/u10/verify-tests-r2/c2/prioritization-board-grid.html	2026-10-13 13:21:45.604803462 +0000
+++ /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/u10/verify-tests-r2/c3/prioritization-board-grid.html	2026-10-13 16:08:39.245398702 +0000
@@ -2545,13 +2545,17 @@
     if(spAce!=='board' && !Object.prototype.hasOwnProperty.call(ACEDB.sets||{}, spAce)) spAce='board';
   }catch(e){}
 }
-function setSpAce(v){ spAce=v; MS.spAce=v; save(); render(); }
-function setSpBy(v){ spBy=v; MS.spBy=v; save(); render(); }
-function setSpPmo(v){ spPmo=v; MS.spPmo=v; save(); render(); }
-function setSpSvc(v){ spSvc=v; MS.spSvc=v; save(); render(); }
-function setSpPrior(v){ spPrior=v; MS.spPrior=v; save(); render(); }
+function setSpAce(v){ if(spRefused()) return; spAce=v; MS.spAce=v; save(); render(); }
+function setSpBy(v){ if(spRefused()) return; spBy=v; MS.spBy=v; save(); render(); }
+function setSpPmo(v){ if(spRefused()) return; spPmo=v; MS.spPmo=v; save(); render(); }
+function setSpSvc(v){ if(spRefused()) return; spSvc=v; MS.spSvc=v; save(); render(); }
+function setSpPrior(v){ if(spRefused()) return; spPrior=v; MS.spPrior=v; save(); render(); }
 // which service the PMO drill is scoped to: 'ALL' for the summary across every service
-function setSpDrillSvc(v){ spDrillSvc=v; MS.spDrillSvc=v; save(); render(); }
+function setSpDrillSvc(v){ if(spRefused()) return; spDrillSvc=v; MS.spDrillSvc=v; save(); render(); }
+// v2.00 (U10): THE SPEND PLAN'S CHOICES ARE REFUSED UP FRONT while a locked cycle is on screen. Each was set on the page first and
+// then saved, which the view refused: the board said "the change was not kept" and kept the choice, so the ACE tie-out taken from
+// the view, and from the working plan after leaving it, tied out the estimate chosen in the view.
+function spRefused(){ if(!cycBlock('Changing the spend plan')) return false; render(); return true; }
 function syncSvc(){
   if(SVC_FROM_DATA) return;
   const v = (typeof MS!=='undefined' && MS && Array.isArray(MS.svc)) ? MS.svc : [];
--- /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/u10/verify-tests-r2/c2/tools/export-audit/audit-recon.mjs	2026-10-13 13:33:28.304845232 +0000
+++ /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/u10/verify-tests-r2/c3/tools/export-audit/audit-recon.mjs	2026-10-13 16:29:09.049471805 +0000
@@ -5552,6 +5552,105 @@
   await settleBoards();
 })();
 // ==== end v2.00 (U10, the shared lists) ====
+// ==== v2.00 (U10, the spend plan's choices): a spend-plan choice, a PPBE position or a destination's kind refused in a locked view leaves no trace ====
+// The Spend Plan's choices -- its Cost data (the estimate the ACE tie-out ties out), By PMO / By Service and the two prior years --
+// were set on the page first and then saved, which the view refused: the board said "the change was not kept" and kept the choice,
+// so the ACE tie-out taken from the view, and from the working plan after leaving it, tied out the estimate chosen in the view (the
+// U10 round-2 test review, 13 Oct). A PPBE position is kept beside the years (MS.ppbe), so only a refusal that makes the whole copy
+// again puts it back (the blocks above read the codes, the bands and the funds flow, not the positions). A destination's kind is
+// changed through a field of its own, which the shared-lists block above does not use (it renames). A board of two AV
+// requirements -- A (USAF 900, ANG 200, confirmed on WBS 1.1) and R (USAF 503, ANG 127) -- with two approved estimates, 2027ACE (AV,
+// 1.1, $900) and 2026ACE (AV, 1.1, $333 for FY27), the Spend Plan on 2027ACE by PMO, and the working plan tagged PB27 with USAF's
+// FY27 position logged at $1,000. PB27 is locked and viewed; each choice is made through the control the Spend Plan renders, and
+// the position through the handler its cell calls. FAILS ON 7ee498a (board fce8a391) and on the U10 commits: the Spend Plan shows
+// 2026ACE by Service with the prior years, and the ACE tie-out from the view and from the working plan ties out 2026ACE ($333);
+// on 7ee498a the FYDP Spend Plan from the view also prints the refused $5,000 position, and Lockheed Martin is kept a government
+// activity for every appropriation and in browser storage. CONTROLS: PB27 viewed, nothing chosen; on
+// the working plan the Cost data choice is open, kept, and the tie-out reads it; no jsdom errors. Every figure is typed here.
+await (async () => {
+  const name = 'v2.00 (U10) — a spend-plan choice, a PPBE position or a destination’s kind refused in a locked view leaves no trace';
+  const { bootMark, bootRelease, settleBoards } = await import('./boot.mjs');
+  const __bm = bootMark();
+  try {
+    const J = JSON.stringify;
+    const X = boot();
+    seed(X.ev, { services: ['USAF', 'ANG', 'AFRC'], items: [it('A', 'AV', [900, 200, 0]), it('R', 'AV', [503, 127, 0])], disc: [5000, 5000, 5000], mand: [0, 0, 0], order: ['A', 'R'] });
+    const ev = c => { try { return X.ev(c); } catch (e) { return 'threw: ' + String((e && e.message) || e).slice(0, 100); } };
+    ev(`BASE_ITEMS.length=0; DATA.items.forEach(function(i){ BASE_ITEMS.push(i); BASE_ASK[i.id]=i.ask.slice(); });
+      S.wbs={A:[{w:'1.1', v:[]}]}; S.aceMap={A:{w:['1.1'], ok:true}};
+      ACEDB.sets={'2027ACE':{lines:[{ap:mySlug(), pmo:'AV', wbs:'1.1', v:{}}], locked:true, by:'Approver', ts:2, file:'2027 ACE approved.xlsx'},
+        '2026ACE':{lines:[{ap:mySlug(), pmo:'AV', wbs:'1.1', v:{}}], locked:true, by:'Approver', ts:1, file:'2026 ACE approved.xlsx'}};
+      ACEDB.sets['2027ACE'].lines[0].v[MS.cur]=900; ACEDB.sets['2026ACE'].lines[0].v[MS.cur]=333; aceYr='all';
+      persistAce(); applyState(S); save(); setSpAce('2027ACE');
+      cycSetWorking('PB', MS.cur); ppCyc='PB'; ppYr=MS.cur; ppLineAdd('USAF'); ppSetV('USAF', ppLines(ppPos(),'USAF')[0].k, MS.cur, 'd', '1000'); 'ok'`);
+    const key = ev(`window.confirm=function(){ return true; }; MS.base=MS.cur; MS.years[MS.cur]=S; save(); blCyc='PB'; blYr=MS.cur; cycLock(); blKey('PB', MS.cur)`);
+    const notKept = () => /the change was not kept|Not kept/.test(ev(`(document.getElementById('shareStat')||{}).textContent||''`));
+    // the Spend Plan as drawn on screen: its Cost data choice, and which of By PMO / By Service / ◀ prior 2 FY is pressed
+    const onScreen = () => JSON.parse(ev(`(function(){ if(!spOpen){ spOpen=true; render(); }
+      var s=[].slice.call(document.querySelectorAll('select')).filter(function(e){ return (e.getAttribute('onchange')||'')==='setSpAce(this.value)'; }).map(function(e){ return e.value; });
+      var b=[].slice.call(document.querySelectorAll('button')).filter(function(e){ return /^setSp(By|Prior)\\(/.test(e.getAttribute('onclick')||'') && e.classList.contains('on'); }).map(function(e){ return e.textContent; });
+      return JSON.stringify([s, b]); })()`));
+    // a control the Spend Plan renders: the Cost data select (a value chosen, change fired) or a button (clicked)
+    const press = (on, value) => ev(`(function(){ if(!spOpen){ spOpen=true; render(); } var el=[].slice.call(document.querySelectorAll('select, button')).filter(function(e){
+      return (e.getAttribute('onchange')||e.getAttribute('onclick')||'')===${J(on)}; })[0]; if(!el) return 'no control';
+      if(el.tagName==='SELECT'){ el.value=${J(value || '')}; el.dispatchEvent(new Event('change', {bubbles:true})); } else el.click(); return 'fired'; })()`);
+    const hdr = (rows, ...must) => rows.findIndex(r => must.every(m => (r || []).some(c => String(c ?? '').trim() === m)));
+    const col = (rows, h, n) => (rows[h] || []).findIndex(c => String(c ?? '').trim() === n);
+    // the ACE tie-out and the FYDP Spend Plan, read from their bytes
+    const tie = async () => { const ab = JSON.parse(await w6Book(X.w, 'exportAceTieout')), mp = ab['Mapping by Requirement'] || [], mh = hdr(mp, 'FY', 'PMO', 'Board funded');
+      const rc = ab['Reconciliation by PMO'] || [], rh = hdr(rc, 'FY', 'PMO', 'Estimate');
+      return [ab.__err || 'ok', w6Lbl(mp[0]), mp.slice(mh + 1).filter(r => /^FY\d\d$/.test(w6Lbl(r))).map(r => ['Requirement (CCaR Record Name)', 'Board funded', 'Estimate', 'Delta'].map(n => r[col(mp, mh, n)] ?? '')),
+        rc.slice(rh + 1).filter(r => w6Lbl(r) === 'FY27' && String(r[1] ?? '') === 'AV').map(r => [r[0], r[1], r[2], r[3], r[4]])]; };
+    const pos = async () => { const fb = JSON.parse(await w6Book(X.w, 'exportFydpPlan')), bs = fb['By Service'] || [], h = hdr(bs, 'Service'), c = col(bs, h, 'FY27 PPBE position');
+      return [fb.__err || 'ok', bs.slice(h + 1).filter(r => ['USAF', 'ANG', 'AFRC', 'TOTAL'].includes(w6Lbl(r))).map(r => [w6Lbl(r), r[c]])]; };
+    const stored = () => ev(`(JSON.parse(localStorage.getItem(_AP.key)||'{}')||{}).spAce||''`);
+    // BY HAND. 2027ACE: A's $1,100 funded against $900 on 1.1 (delta 200); AV $900 against $1,730 funded (A 1,100 + R 630; delta 830).
+    // 2026ACE: $333 against the same (767; 1,397). USAF's FY27 position $1,000; no other service logs one.
+    const T900 = ['ok', 'ACE TIE-OUT - MAPPING BY REQUIREMENT  (2027ACE, FY27)', [['Req A', 1100, 900, 200], ['Req R', 630, '', '']], [['FY27', 'AV', 900, 1730, 830]]];
+    const T333 = ['ok', 'ACE TIE-OUT - MAPPING BY REQUIREMENT  (2026ACE, FY27)', [['Req A', 1100, 333, 767], ['Req R', 630, '', '']], [['FY27', 'AV', 333, 1730, 1397]]];
+    const POS = ['ok', [['USAF', 1000], ['ANG', '—'], ['AFRC', '—'], ['TOTAL', 1000]]];
+    const SCREEN = [['2027ACE'], ['By PMO']];
+    const view = () => ev(`cycView(${J(key)}); 'ok'`), leave = () => ev(`cycLeave(); 'ok'`);
+    // ---- CONTROL: PB27 viewed, nothing chosen
+    view();
+    w5Chk(name, 'PB27 viewed, nothing chosen', 'CONTROL — the Spend Plan shows 2027ACE by PMO; the ACE tie-out ties out 2027ACE ($900); the FYDP Spend Plan prints USAF’s FY27 position, $1,000',
+      J([onScreen(), await tie(), await pos()]), J([SCREEN, T900, POS]));
+    // ---- EACH CHOICE, with PB27 on screen; the status line is read at once ('Not kept' is put in front of a message for 1.5 s only)
+    const fa = press('setSpAce(this.value)', '2026ACE'), ka = notKept();
+    w5Chk(name, 'PB27 viewed · Cost data set to 2026ACE in its select', 'refused and said so; the Spend Plan still shows 2027ACE, and the ACE tie-out taken from the view ties out 2027ACE ($900)',
+      J([fa, ka, onScreen(), await tie()]), J(['fired', true, SCREEN, T900]));
+    const fb = press("setSpBy('svc')"), kb = notKept(), fp = press('setSpPrior(!spPrior)'), kp = notKept();
+    w5Chk(name, 'PB27 viewed · By Service, then ◀ prior 2 FY, pressed', 'each refused and said so; the Spend Plan is still by PMO, without the prior years',
+      J([fb, kb, fp, kp, onScreen()]), J(['fired', true, 'fired', true, SCREEN]));
+    ev(`setSpPmo('AV'); setSpSvc('USAF'); setSpDrillSvc('USAF'); 'ok'`); const kf = notKept();
+    w5Chk(name, 'PB27 viewed · the PMO filter, the service filter and the PMO drill’s service set (the handlers their controls call)', 'each refused and said so; each is still all',
+      J([kf, ev('JSON.stringify([spPmo, spSvc, spDrillSvc])')]), J([true, J(['ALL', 'ALL', 'ALL'])]));
+    ev(`ppCyc='PB'; ppYr=MS.cur; ppSetV('USAF', ppLines(ppPos(),'USAF')[0].k, MS.cur, 'd', '5000'); 'ok'`); const kv = notKept();
+    w5Chk(name, 'PB27 viewed · USAF’s FY27 PPBE position typed as $5,000', 'refused and said so; the FYDP Spend Plan taken from the view prints the position as logged, $1,000',
+      J([kv, await pos()]), J([true, POS]));
+    const fd = ev(`(function(){ if(!entOpen) toggleEnt(); var i=flowEnts().findIndex(function(e){ return e.n==='Lockheed Martin'; });
+      var s=[].slice.call(document.querySelectorAll('#entBody select')).filter(function(e){ return (e.getAttribute('onchange')||'')==='flowSetEnt('+i+',"kind",this.value)'; })[0];
+      if(!s) return 'no control'; s.value='gov'; s.dispatchEvent(new Event('change', {bubbles:true})); return 'fired'; })()`), kd = notKept();
+    const kinds = ev(`JSON.stringify([flowEnts().filter(function(e){ return e.n==='Lockheed Martin'; }).map(function(e){ return e.kind; }),
+      ((JSON.parse(localStorage.getItem(DEST_KEY)||'null')||{}).ents||[]).filter(function(e){ return e.n==='Lockheed Martin'; }).map(function(e){ return e.kind; })])`);
+    ev(`if(entOpen) toggleEnt(); 'ok'`);
+    w5Chk(name, 'PB27 viewed · Lockheed Martin’s kind set to government in Setup › Destinations', 'refused and said so; it is still a prime contractor, in the board and in browser storage',
+      J([fd, kd, kinds]), J(['fired', true, J([['prime'], ['prime']])]));
+    leave();
+    w5Chk(name, 'PB27 viewed · each choice refused · the view left', 'the working plan’s Spend Plan shows 2027ACE by PMO, browser storage keeps 2027ACE, and its ACE tie-out ties out 2027ACE ($900)',
+      J([onScreen(), stored(), await tie()]), J([SCREEN, '2027ACE', T900]));
+    // ---- CONTROL: on the working plan the choice is open, kept, and the tie-out reads it
+    const fw = press('setSpAce(this.value)', '2026ACE');
+    w5Chk(name, 'the working plan · Cost data set to 2026ACE (allowed)', 'CONTROL — the Spend Plan’s Cost data shows 2026ACE, browser storage keeps it, and the ACE tie-out ties out 2026ACE ($333)',
+      J([fw, onScreen()[0], stored(), await tie()]), J(['fired', ['2026ACE'], '2026ACE', T333]));
+    w5Chk(name, 'harness', 'CONTROL — no jsdom script errors', J(X.errors.length), J(0));
+  } catch (e) {
+    failures.push({ scenario: name, where: 'harness', what: 'the block threw: ' + String((e && e.message) || e).slice(0, 160), got: 'threw', want: 'ran' });
+  }
+  bootRelease(__bm, []);
+  await settleBoards();
+})();
+// ==== end v2.00 (U10, the spend plan's choices) ====
 
 {
   const src = _selfRead(_selfPath(import.meta.url), 'utf8');
--- /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/u10/verify-tests-r2/c2/tools/export-audit/mutate.mjs.txt	2026-10-13 13:29:56.644981936 +0000
+++ /tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/u10/verify-tests-r2/c3/tools/export-audit/mutate.mjs.txt	2026-10-13 16:12:08.021945405 +0000
@@ -4342,6 +4342,38 @@
   { id: "v200-u10-dest-reset-in-view", area: "flowResetEnts", what: "reset the list, answered OK while PB27 is on screen: Depot X is dropped for every appropriation and in browser storage, and back on the working plan R's $630 is not yet assigned",
     find: "  if(cycBlock('Resetting the destination list')){ render(); return; }   // v2.00 (U10): as flowSetEnt\n",
     repl: "" },
+  // v2.00 (U10, the round-2 test review of 13 Oct): the Spend Plan's choices are refused up front in a locked view, and a refusal puts
+  // back the PPBE positions with the rest of the copy.
+  { id: "v200-u10-sp-choice-in-view", area: "spRefused", what: "the Spend Plan's choices are set and then saved in PB27's view, as before: the board says the change was not kept, the Spend Plan shows 2026ACE by Service, and the ACE tie-out from the view and from the working plan after leaving ties out 2026ACE ($333 for $900)",
+    find: "function spRefused(){ if(!cycBlock('Changing the spend plan')) return false; render(); return true; }",
+    repl: "function spRefused(){ return false; }" },
+  { id: "v200-u10-sp-ace-in-view", area: "setSpAce", what: "the Spend Plan's Cost data, chosen in PB27's view, is kept on the page while the board says it was not: the ACE tie-out from the view and from the working plan after leaving ties out 2026ACE ($333 for $900)",
+    find: "function setSpAce(v){ if(spRefused()) return; ",
+    repl: "function setSpAce(v){ " },
+  { id: "v200-u10-sp-by-in-view", area: "setSpBy", what: "By Service, pressed in PB27's view, is kept on the page while the board says it was not, and the working plan's Spend Plan is by service after leaving",
+    find: "function setSpBy(v){ if(spRefused()) return; ",
+    repl: "function setSpBy(v){ " },
+  { id: "v200-u10-sp-pmo-in-view", area: "setSpPmo", what: "the Spend Plan's PMO filter, set in PB27's view, is kept on the page while the board says it was not",
+    find: "function setSpPmo(v){ if(spRefused()) return; ",
+    repl: "function setSpPmo(v){ " },
+  { id: "v200-u10-sp-svc-in-view", area: "setSpSvc", what: "the Spend Plan's service filter, set in PB27's view, is kept on the page while the board says it was not",
+    find: "function setSpSvc(v){ if(spRefused()) return; ",
+    repl: "function setSpSvc(v){ " },
+  { id: "v200-u10-sp-prior-in-view", area: "setSpPrior", what: "◀ prior 2 FY, pressed in PB27's view, is kept on the page while the board says it was not",
+    find: "function setSpPrior(v){ if(spRefused()) return; ",
+    repl: "function setSpPrior(v){ " },
+  { id: "v200-u10-sp-drill-in-view", area: "setSpDrillSvc", what: "the PMO drill's service, set in PB27's view, is kept on the page while the board says it was not",
+    find: "function setSpDrillSvc(v){ if(spRefused()) return; ",
+    repl: "function setSpDrillSvc(v){ " },
+  { id: "v200-u10-sp-no-redraw", area: "spRefused", what: "a Spend Plan choice refused in PB27's view leaves the chosen estimate in its select on screen, as if it were kept",
+    find: "if(!cycBlock('Changing the spend plan')) return false; render(); return true; }",
+    repl: "if(!cycBlock('Changing the spend plan')) return false; return true; }" },
+  { id: "v200-u10-reapply-keeps-ppbe", area: "cycReapply", what: "the view's copy is made again but keeps the refused copy's PPBE positions: USAF's FY27 position typed as $5,000 in PB27's view is printed by the FYDP Spend Plan taken from the view, for the $1,000 logged",
+    find: "  MS=cycCopy(c); MS.cur=y;",
+    repl: "  const P0=MS.ppbe; MS=cycCopy(c); MS.cur=y; MS.ppbe=P0;" },
+  { id: "v200-u10-dest-kind-in-view", area: "flowSetEnt", what: "only a destination's name is refused in PB27's view: Lockheed Martin's kind, set to government there, is kept for every appropriation and in browser storage while the board says the change was not kept",
+    find: "  if(cycBlock('Changing a destination')){ render(); return; }\n",
+    repl: "  if(field==='n' && cycBlock('Changing a destination')){ render(); return; }\n" },
   // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.
   { id: "v200-r3-landed-view-unsaid", area: "_driveStorePushRun", what: "a folder save that lands while a locked view is on screen says “🔒 Not kept — PB27 is a locked view. ✅ Saved …” again, naming no plan (or, quiet, leaves persist's refusal on screen)",
     find: "  if(CYCVIEW){ _cycRefusedAt=0; setStat('✅ <b>Saved the working plan</b> of '+esc(APPN_LBL[ap]||ap)+' FY'+(fy%100)+' to the shared folder — '\n    +Math.round(body.length/1024)+' KB, built before '+blLbl(CYCVIEW)+' was put on screen. '+blLbl(CYCVIEW)+' is a locked view: nothing in it '\n    +'is saved. Everyone sees the working plan on their next refresh.'+penNote+lateNote); render(); return true; }\n",
```

Drafts for the lead (NEXT-VERSION entry, changes to the builder's drafts, ledger text, and the ledger row to use if commit 3
does not land): `proposal/DRAFTS-U10-commit3.md`.
