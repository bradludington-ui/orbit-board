# U10 — independent adversarial verification, round 2, lens A (data loss and money)

Verifier's own directory: `rec/L6/u10/verify-money-r2` (all paths below are relative to it unless they start with `rec/` or `/`).

* **Session 1** started 13 Oct 2026, 10:28 AM ET; the lead stopped it at about 11:45 AM ET to lower the machine's load. Its work
  is kept and reused here wherever a run finished with an exit record on the same blobs (every blob was re-hashed at 11:57 AM ET
  and is unchanged: table below).
* **Session 2** (this one) started 11:57 AM ET. No process of session 1 was still running (checked: none of the PIDs in
  `pids.txt` was alive, and no node process of this folder was on the machine).

Nothing in `/home/user/orbit-board` or `/home/user/orbit-ui` was edited, staged, committed or pushed. The builder's files
(`rec/L6/u10/{c1r,c2,drafts,...}`) were read only; every run used my own copies (`base/`, `c1r/`, `c2/` = byte copies of the
builder's, and my prototypes `proto/`, `proto2/`, `proto3/`; `cp -a`, node_modules symlink kept). `mutate.mjs` was never imported
or run: entries were read as text only with `rec/bin/mcount.py` and `rec/bin/mkmut.py` (`python3 -I`). Synthetic data only, in
memory; the board files stay the empty template.

## Identities (`git hash-object`, first 8)

| copy | board | audit-recon | mutate.mjs.txt | what |
|---|---|---|---|---|
| base (`7ee498a`, product `d66dd60`) | `fce8a391` | `529e36f7` | `cbc6defc` | read only |
| c1r (builder's commit 1) | `4a8b0be3` | `746dac83` | `c6c1ea47` | = builder's `rec/L6/u10/c1r` |
| c2 (builder's commit 1 + 2) | `cfc9e14f` | `2c4c466a` | `3a408399` | = builder's `rec/L6/u10/c2` |
| proto (session 1) | `552f3058` | `2c4c466a` | `3a408399` | c2 + 4 gates (pkgApply, bandCopyAll, pkgIssue, pkgPushAll) — `diffs/proto-vs-c2.diff` `3fe3a5e0` |
| **proto2** (session 2) | `4c468d33` | `2c4c466a` | `3a408399` | c2 + importState gate + bandCopyAll, pkgIssue, pkgPushAll gates — `diffs/proto2-vs-c2.diff` `ee71ce0a` |
| **proto3** (session 2) | `6044b3fa` | `2c4c466a` | `3a408399` | proto2 + a second gate after the file is read in importAce / importBud — `diffs/proto3-vs-c2.diff` `0e10df91`, `diffs/proto3-vs-proto2.diff` `305f69f6` |

audit-import `4aba2506`, audit-board `a7c575e5`, audit-other `d89396b0` and every other suite file are byte-identical in all
copies. `diffs/c2-vs-base.board.diff` (`5994388d`) is the builder's `diffs/c2-vs-base.prioritization-board-grid.html.diff`
(headers aside). mcount (text only): base 1328 entries, c1r 1337, c2 1345, each matched exactly once; c2's 1345 entries also
each match once on proto, proto2 and proto3 (`out/mcount-*.txt`).

Tools: `run.sh` `dae95d21` (one bounded run: `setsid -w timeout -k 10 600`, lock wait, PIDs to `pids.txt`, a line to
`logs/runs.txt`), `runner.mjs` `f851f139`, focused harness `harness/<copy>/focused-u10.mjs` `f83a2e59` (built by
`bin/mkfocused-u10.py` `76abf73c` verbatim from c2's audit-recon: item 88 + the three U10 blocks + the scenario-ran guard),
`bin/tally.py` `fe8ef998`. Probes: `probe/r2probe.mjs` `2b02c5f8` (VP1), `probe/r2probe-b2.mjs` `ba58707e` (VP2),
`probe/r2probe-race.mjs` `e02a5507` (VP3), `probe/r2probe-doors2.mjs` `b6bea50e` (VP4c; VP4 and VP4b ran earlier versions of
it: v1 booted the empty-template shell, which takes a state file through its own reboot branch, so it measured the wrong route;
v2 boots twice like VP1's board; v3 adds the reopen step — only VP4c is reported).

## Verdict: UNSOUND as drafted — the two commits are right for what they cover, but U10 is not closed and the drafts say it is

What the commits do, they do correctly (measured, sessions 1 and 2): the focused U10 harness passes on c2 (74/74) and fails on
base exactly as the builder says (18 + 4 + 21 failing, every control passing; c1r: the third block's 21 fail); audit-recon
(full), audit-other, boot-same, audit-inject, audit-hostile and `npm run check` (in a scratch clone at `7ee498a`) pass on c2; the
six builder mutants I re-ran on c2 are caught with exactly the builder's counts. I found no export that carries a refused edit made
through a door the two commits cover, and no regression.

But the track's own finding — "a refused edit never changes what any export carries" — is still open through doors next to the
ones gated, and some of them lose work:

### Must fix

**MF1 — DATA LOSS and a refused code in every export: a returned package taken in a view (File › ⬅ Import one appropriation…).**
`importState` has no view gate (its siblings `importFullBoard` and `importBoards` refuse up front). A package goes to `pkgApply`,
whose questions are asked of the VIEW's copy (`pkgStoreOf(mySlug())` is `MS`), which writes the package into this appropriation's
own browser-storage key and `PUBS` (`lsSet(_SLUGMAP[ap].key, …)`), and only then reaches `applyStore`, which the view refuses.
Measured (VP1, VP2; c2 = base, so pre-existing): the line reads "🔒 Not kept — PB27 is a locked view. 📥 Merged O&M package #1
from Manager M. Your local changes were discarded, as confirmed. Use 💾 Save …"; after leaving the view the screen still shows the
working plan (11111, "UNSAVED EDIT A") but browser storage holds the package; reopen the same browser over the file saved before
the view and RCN-EEIC by Month and the Spend Plan Source print **77777** (4 + 2 cells; 11111 in none), and the working plan's
edit "UNSAVED EDIT A" is in no export and has no kept-aside copy. Principles 1, 2, 3, 4 all fail on this path.
*Fix (measured, proto2):* one up-front gate in `importState`, as `importFullBoard` has:
`if(CYCVIEW){ cycRefuse('Importing a file'); inp.value=''; return; }` — proto2: refused before any question, storage
unchanged (11111, "UNSAVED EDIT A"), reopen keeps both; the working-plan control is unchanged (merged, 77777, as before).

**MF2 — DATA LOSS: the band ladder copied to the other appropriations from a view is kept while the board says "Not kept".**
`bandCopyAll` writes Full Fund's stored board and the held ladders (`prio27bands_ff` …) and then `save()` is refused: "🔒 Not
kept — PB27 is a locked view. ⚖ Ladder applied to 1 appropriation and held for 2 not yet opened in this file …". Full Fund's own
ladder ["FF ONLY BAND"] is replaced by O&M's eight bands with no copy kept; its requirement banded in "FF ONLY BAND" becomes
unbanded when Full Fund opens (VP1 C; c2 = base). *Fix (measured, proto/proto2):* `if(cycBlock('Copying the band ladder')) return;`
at the top of `bandCopyAll` — "🔒 Copying the band ladder is off …", Full Fund unchanged; working-plan control unchanged.

**MF3 — MONEY under "Not kept", in a timing window: a cost estimate (or BAE list) import started on the working plan and a view
put on screen while the file is read.** Commit 2's gates run before the first `await`; the writes come after it. Measured (VP3,
c2): `importAce` started, `cycView(PB27)` before its file is read → the approved "2027 ACE approved.xlsx" is replaced after
"⚠ 2027ACE is already loaded and LOCKED … Replace it?", the line reads "🔒 Not kept — PB27 is a locked view. 📈 2027ACE loaded
and 🔒 locked …", and the ACE tie-out and FYDP Spend Plan read **4,321,000** for 900 (AV 4321000 / 1730 / −4319270), in the view
and on the working plan after leaving; `importBud` the same way stores "USAF O&M - ANG CAM ZZ9 Discretionary AV". The house
already requires this for the batch import: audit-import's v1.97 W3 block checks "a locked cycle put on screen meanwhile" for
`importBoards`. *Fix (measured, proto3):* the same gate again right after `const sheets=await xlsxRead(await f.arrayBuffer());`
in `importAce` and `importBud` — refused, 2027ACE 900 kept, tie-out 1100 / 900 / 200, no question asked. **Caution (measured):**
with that second gate, the builder's entry `v200-u10-ace-import-in-view` (and by the same reading `-bae-import-in-view`) is no
longer caught by the focused block (VM3: 0 of 74 checks fail on proto3; 15 fail on c2), because the later gate refuses the same
way. So the fix needs (a) a race case in the U10 lists block (the view put on screen during the read, as W3 does) for the new
gates, and (b) a check that the up-front refusal happens before the file is read (for example the reader never called / "Reading"
never shown) so the existing entries stay caught. Principle 6: no existing check or expected value changes.

**MF4 — the drafts and the builder's summary are false (principle 4).** "Doors were found by text scans … The refused-but-kept
doors are exactly the seven now gated", NEXT-VERSION (3) "Two neighbouring cases stay open in the ledger", and the ledger append
("Not covered: rows U<n> and U<n+1>") are contradicted by MF1–MF3, SF1, SF2 and SF4. Whatever is decided about the gates, the entries must
name these doors: fixed (with tests and entries), or recorded as open with their reproductions.

### Should fix

**SF1 — a package issued (or every baseline pushed) from a view hands out the locked cycle's plan as the board's package #1.**
`pkgIssue(mySlug(), true)` in PB27's view (VP1 D, c2 = base): the downloaded package (file name marked "[PB27 LOCKED]") carries
the cycle's plan (A's description absent; the working plan has "WORK DESC A"), seq 1; the working plan's ledger stays at 0 after
leaving; the line reads "🔒 Not kept … ⬆ Issued O&M package #1. Send it to the manager … ⚠ It could not be written to browser
storage — use 💾 Save now or this issue is not recorded at all" (Save is off in a view). The cycView comment itself says "a copy
of the past must never leave this machine dressed as the board". *Fix (measured, proto/proto2):* `cycBlock` at the top of
`pkgIssue` and `pkgPushAll` (the latter read, not run).

**SF2 — a PMO submittal taken in a view folds its destinations into the list every appropriation shares.** VP4c P: with PB27 on
screen, a submittal naming "Depot NEW" adds it to `DESTDB` and `prio27destdb` (kept after leaving) under "✉ Submittal from AV …
Nothing has been applied." — while the view's banner says nothing changed is kept. No export carried it in my board (no
requirement points at it). The same on the working plan by design. Closed by the MF1 gate (proto2: refused, list unchanged).

**SF4 — MONEY, through a file no current version writes: a state file that carries the board-wide stores beside its years,
imported in a view, keeps its cost estimates, execution data, reprogramming rows and locked cycles while the board says "the
change was not kept".** (Should fix rather than must: every saver in v1.80–v2.00 writes `{appns:…}`, which takes the
consolidated route instead — read with `git show` of 84dcaf9, 68b02e9, a1c3b74, 2d0100d and c2 — so this shape arrives only
from a hand-made file or one I could not trace; `inboundCheck` accepts it.) Same door as MF1:
`importState` runs `importStores(fullSt || st)` — `persistAce()`, `persistExdb()`, `persistRp()`, `persistCyc()` — before
`applyStore` refuses. Measured (VP4c, a twice-booted board that is not the template shell; c2 = base): a state file carrying a
2028ACE estimate (AV 1.1 FY27 $4,321,000) imported with PB27 on screen → "🔒 Loading a board is off while PB27 is on screen …
the change was not kept", yet `ACEDB` and `prio27acedb` now hold 2027ACE **and 2028ACE**, in the view and after leaving; reopen
the browser and the ACE tie-out's Mapping by Requirement reads Req A **Board funded 1,100 · Estimate 4,321,000 · Delta −4,319,900**
(before: 1,100 · 900 · 200). The same as the builder's own money MF for `importAce`, through the import menu's other door.
*Fix:* closed by the same `importState` gate as MF1 (proto2: "🔒 Importing a file is off …", 2027ACE only, reopen 900 / 200; the working
plan still takes the file and its estimate, as before).

**SF3 — tests.** The U10 lists block should cover, in a view: a package and a state file through `importState`, `bandCopyAll`,
`pkgIssue`, and the race of MF3 — each with its export cells typed by hand and a working-plan control — and mutation entries for
each new gate (`v200-u10-…`). None of my prototypes has tests or entries: they are measured prototypes, not commits.

### Minor (read, not run)

* `consTakePick` / `consTakeApply` (a consolidated file through `importState`) in a view: the preview rows are diffed against the
  view's copy, then it writes the slots and reloads — a load the view's banner says cannot happen. Closed by the MF1 gate.
* The command bar's own writes (`S.mc[id]=true; save(); cmdSay('✓ ★ … flagged Mission Critical')`) say "✓" after a refused save
  in a view; commit 1 puts the flag back, so nothing is kept, but the command bar's word is wrong.

## The decision principles, against c2 as drafted

1. Never lose a copy — not met for the track: MF1 (the working plan's edit gone after a reopen, two disagreeing copies and no
   question) and MF2 (Full Fund's ladder replaced). c2 itself loses nothing new (both are the same on base).
2. Refuse or ask rather than guess — not met: MF1 asks its CONFLICT question of the view's copy; MF2, MF3, SF1, SF4 run and then
   say "Not kept".
3. Money and every export exact — the doors c2 gates are exact (measured); MF1 puts a refused 77777 in every export after a
   reopen; MF3 and SF4 move the ACE tie-out's estimate by $4,320,100 (900 → 4,321,000) under "Not kept".
4. Every word true — not met: "Not kept" over kept writes (MF1–MF3, SF1, SF4), and the drafts' closure claims (MF4).
5. Smallest change — met by c2 (board +39 −10 vs base). proto2 adds 7 board lines to c2 (4 gates, one with a 3-line comment); proto3 2 more.
6. Existing checks preserved — met by c2: no existing check, fixture, expected value or mutation entry changed; base's 1328
   entries match once on c2. proto2 keeps every entry matched once and every suite I ran passing; proto3 also, but it makes two
   of the builder's own entries equivalent until the block gains the checks in MF3 (measured, VM3).

## Runs

Every run below went through `run.sh` (one `setsid -w timeout -k 10 600`, its own process group, lock checked first: the
`AUDIT_IMPORT_RUNNING` lock was never present). Start times are ET from the log header; wall seconds from `run.sh`. Runs marked
(S1) are session 1's, reused because they finished with an exit record on blobs that are unchanged.

| label | start ET (13 Oct) | exit | wall s | result | log |
|---|---|---|---|---|---|
| VP1-on-c2 (S1) | 10:38:28 | 0 | 66.7 | B/C/D as MF1, MF2, SF1 | logs/VP1-on-c2.log |
| VP1-on-base (S1) | 10:40:27 | 0 | 67.1 | same as c2 (pre-existing) | logs/VP1-on-base.log |
| VP2-on-c2 (S1) | 10:44:33 | 0 | 35.7 | MF1 with codes: reopened 77777 ×6, 11111 ×0 | logs/VP2-on-c2.log |
| VF-u10-on-c2 (S1) | 10:46:12 | 0 | 128.9 | 74/74 pass | logs/VF-u10-on-c2.log |
| VF-u10-on-base (S1) | 10:48:21 | 1 | 97.1 | 18 + 4 + 21 fail, all controls pass | logs/VF-u10-on-base.log |
| VF-u10-on-c1r (S1) | 10:49:58 | 1 | 114.1 | third block 21 fail, controls pass | logs/VF-u10-on-c1r.log |
| VP1-on-proto (S1) | 10:52:54 | 0 | 41.4 | B/C/D refused; controls unchanged | logs/VP1-on-proto.log |
| VP2-on-proto (S1) | 10:53:36 | 0 | 29.0 | refused; reopened 11111 | logs/VP2-on-proto.log |
| VF-u10-on-proto (S1) | 10:54:13 | 0 | 127.3 | 74/74 pass | logs/VF-u10-on-proto.log |
| VS-boot-same-c2 (S1) | 10:56:21 | 0 | 43.3 | identical either way | logs/VS-boot-same-c2.log |
| VS-audit-inject-c2 (S1) | 10:57:04 | 0 | 45.1 | all clear | logs/VS-audit-inject-c2.log |
| VS-audit-hostile-c2 (S1) | 10:57:49 | 0 | 198.4 | all pass | logs/VS-audit-hostile-c2.log |
| VS-boot-same-proto (S1) | 11:01:08 | 0 | 34.7 | identical | logs/VS-boot-same-proto.log |
| VS-audit-inject-proto (S1) | 11:01:42 | 0 | 43.7 | all clear | logs/VS-audit-inject-proto.log |
| VS-audit-hostile-proto (S1) | 11:02:26 | 0 | 191.4 | all pass | logs/VS-audit-hostile-proto.log |
| VS-audit-other-c2 (S1) | 11:05:57 | 0 | 158.9 | all pass | logs/VS-audit-other-c2.log |
| VS-audit-other-proto (S1) | 11:08:36 | 0 | 149.1 | all pass | logs/VS-audit-other-proto.log |
| VS-audit-recon-c2 (S1) | 11:11:11 | 0 | 577.1 | ALL CHECKS PASSED | logs/VS-audit-recon-c2.log |
| VP3-race-on-c2 (S1) | 11:11:59 | 0 | 18.0 | MF3: 4,321,000 under "Not kept" | logs/VP3-race-on-c2.log |
| VP2-on-base (S1) | 11:21:04 | 0 | 37.3 | same as c2 (pre-existing) | logs/VP2-on-base.log |
| VM-v200-u10-reapply-year-only (S1) | 11:21:41 | 1 | 142.1 | caught: 18 + 3 fail | logs/VM-v200-u10-reapply-year-only.log |
| VM-v200-u10-dest-remove-in-view (S1) | 11:24:04 | 1 | 128.9 | caught: 5 fail | logs/VM-v200-u10-dest-remove-in-view.log |
| VM-v200-u10-ace-import-in-view (S1) | 11:26:20 | 1 | 127.5 | caught: 15 fail | logs/VM-v200-u10-ace-import-in-view.log |
| VM-v200-u10-dest-change-no-redraw (S1) | 11:28:27 | 1 | 123.1 | caught: 1 fail | logs/VM-v200-u10-dest-change-no-redraw.log |
| VM-v200-u10-reapply-keeps-plan-settings (S1) | 11:30:31 | 1 | 126.5 | caught: 2 fail | logs/VM-v200-u10-reapply-keeps-plan-settings.log |
| VS-audit-recon-proto (S1) | 11:32:45 | 124 | 601.2 | TIMED OUT under load (incomplete) — not a result | logs/VS-audit-recon-proto.log |
| VC-check-c2 (S1) | 11:43:16 | 1 | 18.7 | only "tracked by git" failed: the copy is not a git repo — re-run below | logs/VC-check-c2.log |
| VC-check-proto (S1) | 11:43:35 | 1 | 18.2 | same reason | logs/VC-check-proto.log |
| VC-check-base-git | 12:03:15 | 0 | 6.6 | all checks passed (scratch clone at 7ee498a) | logs/VC-check-base-git.log |
| VC-check-c2-git | 12:03:22 | 0 | 7.2 | all checks passed (c2's board, audit-recon, mutate copied over; put back after) | logs/VC-check-c2-git.log |
| VP4-doors2-on-c2 | 12:04:43 | 0 | 24.3 | superseded (v1 probe booted the template shell) | logs/VP4-doors2-on-c2.log |
| VP4b-doors2-on-c2 | 12:05:29 | 0 | 36.4 | superseded by VP4c (no reopen step) | logs/VP4b-doors2-on-c2.log |
| VP4c-doors2-on-c2 | 12:06:30 | 0 | 31.0 | SF4, SF2 | logs/VP4c-doors2-on-c2.log |
| VP4c-doors2-on-proto2 | 12:08:38 | 0 | 34.8 | refused in the view; controls unchanged | logs/VP4c-doors2-on-proto2.log |
| VP4c-doors2-on-base | 12:08:38 | 0 | 37.0 | same as c2 (pre-existing) | logs/VP4c-doors2-on-base.log |
| VP2-on-proto2 | 12:09:27 | 0 | 29.8 | refused; reopened 11111; control 77777 | logs/VP2-on-proto2.log |
| VP1-on-proto2 | 12:09:27 | 0 | 40.7 | B/C/D refused; UNSAVED EDIT A kept; controls unchanged | logs/VP1-on-proto2.log |
| VF-u10-on-proto2 | 12:10:22 | 0 | 105.5 | 74/74 pass | logs/VF-u10-on-proto2.log |
| VS-audit-inject-proto2 | 12:12:14 | 0 | 49.2 | all clear | logs/VS-audit-inject-proto2.log |
| VS-audit-hostile-proto2 | 12:12:14 | 0 | 201.1 | ALL CHECKS PASSED | logs/VS-audit-hostile-proto2.log |
| VP3-race-on-proto3 | 12:17:08 | 0 | 12.4 | refused after the read; 900 kept | logs/VP3-race-on-proto3.log |
| VM3-ace-import-in-view-on-proto3 | 12:17:26 | 0 | 86.4 | builder's entry NOT caught on proto3: 0/74 fail (MF3 caution) | logs/VM3-ace-import-in-view-on-proto3.log |
| VM-v200-u10-bae-import-in-view | 12:19:47 | 1 | 78.1 | caught on c2: 13 fail | logs/VM-v200-u10-bae-import-in-view.log |
| VS-audit-recon-proto3 | 12:19:38 | 0 | 283.8 | ALL CHECKS PASSED (full owning suite, on proto3 = proto2 + the two re-checks) | logs/VS-audit-recon-proto3.log |

Checks counted with `bin/tally.py` on each run's `out/<label>.checks.jsonl` (rows: scenario, where, what, ok, got).

## PIDs

Every node / timeout PID of both sessions is in `pids.txt` with its command and start time (ET). Session 1 started two driver
shells from the Bash tool without a cap of their own (each node run inside had its 600 s cap). In session 2 the paired runs were
started inside `setsid -w timeout -k 10 600 bash -c '… & … & wait'` (two at a time at most), the rest one by one; one later pair
was refused by the harness's safety check before anything ran, and was then run one by one. I killed nothing and nobody's
process; nothing of mine was left running after the last run above (checked 12:24:30 PM ET).

## Not done

* The full audit-import and audit-board (the lead runs those). audit-board does not call `importState`, `bandCopyAll` or
  `pkgIssue`; audit-import calls `importState` only on the working plan, and views a cycle only around `importBoards`,
  `driveStorePush` and `livePublish` (read, not run on the prototypes).
* audit-recon on proto2 by itself (proto3 = proto2 + 2 lines passed the full suite, 12:19:38 ET), audit-other and boot-same on proto2/proto3 (they passed on
  proto in session 1; proto2/proto3 change only `importState`, `pkgIssue`, `pkgPushAll`, `bandCopyAll`, `importAce`, `importBud`).
* Tests and mutation entries for the prototypes (SF3) — they are measured prototypes for the builder, not commits; no
  NEXT-VERSION or ledger text is drafted for them as commits. What the drafts must say instead is in MF4.
* Builder mutants not re-run by me: `-ccar-import-in-view`, `-dest-change-in-view`, `-dest-add-in-view`, `-dest-reset-in-view`,
  `-wrong-year`, `-working-base`, `-keeps-list`, `-keeps-years`, `-keeps-pmos`, `-first-year`, `-older-keeps-list` (6 of the 17
  re-run on c2, each with the builder's count).
* The consolidated-file take in a view and the command bar's "✓" (Minor): read, not run. `adoptShared` (the shared state file)
  in a view: not investigated beyond reading that `sharedKeepMine` runs on the view's copy before `applyStore` refuses.
