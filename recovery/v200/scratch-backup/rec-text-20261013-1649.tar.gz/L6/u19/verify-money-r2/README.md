# U19 verify, lens A (data loss and money), round 2

**Track U19, ORBIT v2.00.** The verifier for the builder's fix round (`rec/L6/u19/fr/c1`). Lens A: data loss and money, and
whether every word stays true. Started 10:27 AM ET, 13 Oct 2026 (`TZ=America/New_York date`), after the container restart at
9:11 AM ET. **No earlier attempt of this review existed:** `verify-money-r2/` did not exist when I started, so nothing was
reused. Every time below is Eastern.

Nothing in `/home/user/orbit-board` or `/home/user/orbit-ui` was edited, staged, committed or pushed. The builder's files
were only read. `mutate.mjs` was never imported or run; its text was read with `mcount.py` and `mkmut.py` only.

## 1. Verdict

**Sound with issues.** The board change does what the lead asked on every route I could drive. S1 is kept and reachable
after the Save and after a reopen on the file routes, on the Live-view route (round 1's M1), with no file handle, and on a new
route I added: the folder holds an older copy, S1B is saved only in the file, then put back with the folder on (X1). No money
figure or export changes: the kept copy exported as a file equals S1's own save, key for key. The other suites and
`npm run check` pass.

I found one must-fix and five should-fixes:

- **The must-fix is a false put-back question** (principle 4). It is newly reachable through the fix's saved swap copy (W1).
  It is words only; no copy is lost. A one-line fix is demonstrated and passes every check.
- **The should-fixes:**
  - a test gap: a data-losing wrong version of the M1 clause passes the whole U19 block (X1 catches it);
  - the drafts overclaim: W4 leaves a newer copy only in Teams version history after HOLD ON OK;
  - the builder's proposed new ledger row duplicates the existing U15;
  - an adjacent, older silent data loss with no put-back (W7), which needs its own ledger row;
  - the locked-view put-back path is now used for saved work, and nothing in the block tests it.

## 2. Identities

| what | blob |
|---|---|
| base board (`rec/L6/base`, 7ee498a) | `fce8a391` |
| fix board (`fr/c1`, copied here as `vfr/`) | `f6ac4b9d` |
| fix audit-import | `cfaeac17` (base `4aba2506`) |
| fix mutate.mjs.txt | `9028eaa8` (base `cbc6defc`) |
| audit-recon / audit-board / audit-other | `529e36f7` / `a7c575e5` / `d89396b0`, unchanged |

- `vbase/` and `vfr/` are `cp -a` copies with the node_modules symlink. `diff -rq` shows only the three files above differ.
- orbit-board HEAD is `cf1e6e1`, and no product or tools file has changed since 7ee498a (`git diff --stat 7ee498a HEAD`
  is empty for them).
- My focused harnesses, built with `mkfocused-u2.py` (copied unchanged from `rec/L2/u2impl`), are byte-identical to the
  builder's: U19 `40356194`, U2 `a1edf6a8`/`32cc5ac7`, v1.89 `49261f6a`/`ed54e613`.

## 3. Findings

### MUST-FIX

**MF-A. The put-back question says what is on screen is "still in the saved file" when it is only in the shared folder.**
This breaks principle 4, the FIX line's "the put-back question … stay[s] true", and the builder's §FR.3 claim. It is reached
through the fix's saved swap copy.

Reproduction (probe W1, file mode):
1. S1 is saved into the board file.
2. ↶ Put back K: S1 is kept, as 'swap'.
3. Connect a shared folder (empty) and 💾 Save: K is written to the folder. The board file still holds S1.
4. ↶ Put back S1. The question says: "What is on screen now is still in the saved file it came from, and 💾 Save will ask
   before writing over that."

K was never written to the board file. Nothing is kept (correctly: K is the folder's own copy), so no copy is lost. The
sentence is false.

- On the base this route does not exist: S1 is not kept, so the probe finds "no button".
- The same sentence is false on the base on the unsaved route W1c (S1 never saved). The defect is older; the fix makes it
  reachable from saved work, the common case.
- **Cause:** `keptWhere(k.meta)` describes the screen by where the KEPT copy came from. For a 'swap' copy that says nothing
  about the screen.

Minimal fix, demonstrated in `vfix/` (board `63092e7c`; `diffs/vfix-board.diff`). In `keptPutBack`'s saved branch:

```
-  : 'What is on screen now is still in '+keptWhere(k.meta)+' it came from, …
+  : 'What is on screen now is still in '+((k.meta.why==='swap' && +MS.ts && driveBaseOf(mySlug())===(+MS.ts||0))? 'the shared folder' : keptWhere(k.meta))+' it came from, …
```

- On `vfix`, W1 and W1c pass.
- Every other probe row is unchanged.
- The U19, U2 and v1.89 harnesses: see §5 (runs `F-v-*`).
- Also needed: a W1 check in the U19 block, and a mutation that reverts it.

### SHOULD-FIX

**SF-1. Test gap: a data-losing wrong version of the M1 clause passes the whole U19 block.** The mutant `vm-base-zero`
replaces `driveBaseOf(mySlug())!==(+MS.ts||0)` with `!driveBaseOf(mySlug())`.

- **U19 block:** 104/104 pass on the mutant (`F-p2-U19.vfr-on-vm-base-zero`, exit 0). Scenario (m) uses an EMPTY folder, so
  the folder base is 0 either way.
- **Probe X1** (`probe/xblock.mjs.txt`) shows the mutant loses data:
  1. S1 is saved to the file and the folder.
  2. Live view is switched off, and S1B is saved only to the file.
  3. Live view is on again; ↶ Put back.
  4. Live view is off; 💾 Save, OK.
  - S1B is then in no copy: 3 rows fail on the mutant.
  - They also fail on the base (3), and pass on the fix (exit 0).

Fix: add X1 to the block, plus an entry such as `v200-u19-putback-folder-base-any`
(find `driveBaseOf(mySlug())!==(+MS.ts||0);` → `!driveBaseOf(mySlug());`).

**SF-2. The drafts overclaim. A newer copy can now end only in Teams version history after a put-back (W4).**

Route (W4):
1. The U19 route: S1 kept, K saved over it with OK.
2. K2 typed and left unsaved.
3. Alice's other browser saves N2 into the file.
4. Reopen.
5. 💾 Save: one HOLD ON ("Alice saved this file … their changes are not on your screen"), answered OK.

What each board does:
- **On the fix:** the reopen refuses N2 ("the newer copy was not loaded and nothing was lost"). After the Save, N2 is in no
  copy the board can reach: K2 ✓, N2 ✗, S1 ✓.
- **On the base:** the reopen loads N2 and keeps K2. The Save asks nothing. K2 ✓, N2 ✓, S1 ✗ (the U19 loss).

So on this route the fix changes which copy is lost; it does not stop the loss. The HOLD ON names Alice's own other-browser
save "their changes" (O1), the same shape the ledger rated data loss for S1.

The builder's "What users may see" describes it accurately. But:
- the Unresolved bullet says "So 💾 Save's HOLD ON answered OK no longer leaves work saved only in the board file in no copy
  this board can reach". W4 is a counter-example: N2 was saved only in the board file;
- neither the bullet nor the ledger text lists W4 as open.

Fix:
- scope that sentence to "the work that was on screen at the put-back";
- add W4 to the open points, for the lead or Brad to accept knowingly. It comes with the lead's "kept aside like the unsaved
  'swap' case": one kept slot.

**SF-3. The builder's proposed new ledger row duplicates U15.** The proposed row, "Reopened with work this browser holds
unsaved … the top bar says 'Saved <time>'", is the existing U15: "Reopening: the header says 'Saved' from `DIRTY` alone",
P2, open. The drafts say "(its own ledger row)" and propose `U<next>`. Fix: point to U15 and append the new evidence
(r1 V2b, VC2, the U19 route) to U15, instead of a new row.

**SF-4. An adjacent, older SILENT data loss with no put-back (W7), not in the ledger. It needs its own row.**

Route:
1. S1 is saved into the board file.
2. 📡 Live view works out of a shared folder where Bob saved F.
3. The refresh (`driveStorePull`) loads F. S1 is "saved", so it is not kept aside.
4. Live view is switched back to "○ Just watching".
5. 💾 Save writes F over S1 and asks nothing. `LASTKNOWN` still names S1's own file save.

S1 is then in no copy the board can reach, after the Save and after a reopen. This is the same on the base and on the fix
(W7 rows fail identically). It is related to U29 (`adoptShared` in file mode) and U17, but not the same path.

Possible minimal fixes (not built):
- when a folder copy replaces work saved only in the board file, keep it aside by the same rule U19 now uses;
- or clear `LASTKNOWN`, so the next file Save asks.

It is not U19's to fix (principle 5), but it is the same false assumption: "saved in the board file" means safe.

**SF-5. The locked-view put-back now runs the swap-and-restore path for saved work, and the U19 block does not test it.**
Under a locked view, `keptPutBack` first writes what `MS` holds (the locked view's copy) into the kept slot. It then relies
on the restore line when `applyStore` refuses.

- On the base, saved work never took this path.
- The mutant `vm-no-restore` (restore line removed) passes the U19 block, 104/104 (`F-p2-U19.vfr-on-vm-no-restore`, exit 0).
- It fails my W6: K is lost, and the slot holds the locked view.
- On the fix, W6 passes: K is kept byte for byte.

Fix: refuse with `cycBlock('Loading a board')` before the question. That also closes the builder's open wording point V5.
Or add W6 and a mutation entry.

### MINOR

- **The `0===0` edge.** `driveBaseOf(mySlug())!==(+MS.ts||0)` treats "no folder base" and "MS.ts 0" as the folder's own
  copy. A screen with no `ts`, with the folder on and never used, would not be kept. By code only; I found no route that
  makes MS.ts 0 with real work. Requiring a nonzero base would be safer.
- **"Stays in the folder whatever Save does next" is too strong.** The comment and drafts lean on the folder history, which
  thins recent copies. Open U30 shows a path where a folder copy leaves the history after one more Save. On the exception
  route I could find, Save's clash and "Save yours over theirs" force a spaced copy, so S1 stays (W2 passes).
- **The new Cancel advice points only to ⬅ Import, which replaces what is on screen (K).** By code it asks first ("CONFLICT …
  will DISCARD these changes of yours"). K is then in no copy, since the slot holds S1. On the base, a reopen loaded S1 and
  kept K. Asked, so principle 1 is met by asking. Worth "⬇ Save a copy first" in the advice.
- **The ledger draft quotes the clause as `driveBaseOf(mySlug())!==MS.ts`.** The code is `(+MS.ts||0)`.
- **W3 (money):** the kept S1 exported as a file has an `appns.om` equal to S1's own save, key for key (no differing key);
  asks and allocations are equal.
- **W2 (the exception, then the Save target switched):** S1 stays reachable in the folder after the Save and after a reopen.
- **W5:** after a reopen, the question for the file's own copy uses the saved branch. That is true.

## 4. The six principles, checked literally

1. **Never lose a copy.** Met for the copy on screen at the put-back on every route I drove: (a)–(r), W2, X1, W6. Not met
   for a NEWER copy on W4 (SF-2), and not met on the older W7 (SF-4, not U19's).
2. **Refuse or ask.** The keep is decided from state, not guessed. W4 and W7: W4 asks (HOLD ON); W7 neither refuses nor asks.
3. **Money and exports.** Unchanged. W3 is equal key for key; audit, audit-ppt and audit-other pass.
4. **Words stay true.** Broken on W1 (MF-A). M2 and MF1 hold (W5; the builder's (f), (p), (q)).
5. **Smallest change.** Yes for the board. MF-A's fix is one expression.
6. **Existing checks.**
   - The three changed expectations are listed with file:line, old → new and why (builder README §5).
   - Crossed runs fail exactly there: U2.base on fix 2 (d) rows; U2.fix on base the same 2; v189.base on fix 1 row.
   - U2 case (c) is unchanged and passes. By code, (c) now keeps S1 after its retry put-back, but no check observes the slot
     there.

## 5. Runs

Every node run went through `bin/run.sh`: `setsid -w timeout -k 10 600`, the lock check, PIDs in `pids.txt`, an end line in
`logs/runs.txt`. The `AUDIT_IMPORT_RUNNING` lock was absent every time; no run waited or was skipped. The machine load
average was 24–30 on 4 CPUs, so wall times are long.

| label | start (ET) | exit | wall s | log |
|---|---|---|---|---|
| F-r1-U19.vfr-on-vfr | 2026-10-13 10:38:27 | 0 | 272.3 | logs/F-r1-U19.vfr-on-vfr.log |
| F-r1-U19.vfr-on-vbase | 2026-10-13 10:42:59 | 1 | 212.8 | logs/F-r1-U19.vfr-on-vbase.log |
| F-r1-U2.vfr-on-vfr | 2026-10-13 10:46:41 | 0 | 139.7 | logs/F-r1-U2.vfr-on-vfr.log |
| F-r1-U2.vbase-on-vbase | 2026-10-13 10:49:01 | 0 | 126.2 | logs/F-r1-U2.vbase-on-vbase.log |
| F-p1-W-on-vfr | 2026-10-13 10:50:12 | 1 | 81.4 | logs/F-p1-W-on-vfr.log |
| F-p1-W-on-vbase | 2026-10-13 10:51:34 | 1 | 79.7 | logs/F-p1-W-on-vbase.log |
| F-r1-U2.vbase-on-vfr | 2026-10-13 10:51:07 | 1 | 137.4 | logs/F-r1-U2.vbase-on-vfr.log |
| F-p2-X-on-vfr | 2026-10-13 10:53:42 | 0 | 24.8 | logs/F-p2-X-on-vfr.log |
| F-p2-X-on-vbase | 2026-10-13 10:54:06 | 1 | 28.9 | logs/F-p2-X-on-vbase.log |
| F-p2-X-on-vm-base-zero | 2026-10-13 10:54:35 | 1 | 27.1 | logs/F-p2-X-on-vm-base-zero.log |
| F-r1-U2.vfr-on-vbase | 2026-10-13 10:53:24 | 1 | 153.2 | logs/F-r1-U2.vfr-on-vbase.log |
| S-boot-same-vfr | 2026-10-13 10:55:41 | 0 | 42.8 | logs/S-boot-same-vfr.log |
| S-audit-vfr | 2026-10-13 10:56:23 | 0 | 42.7 | logs/S-audit-vfr.log |
| F-r1-v189.vfr-on-vfr | 2026-10-13 10:55:58 | 0 | 75.7 | logs/F-r1-v189.vfr-on-vfr.log |
| F-p2-U19.vfr-on-vm-base-zero | 2026-10-13 10:55:03 | 0 | 185.0 | logs/F-p2-U19.vfr-on-vm-base-zero.log |
| F-r1-v189.vbase-on-vfr | 2026-10-13 10:57:14 | 1 | 65.8 | logs/F-r1-v189.vbase-on-vfr.log |
| S-audit-other-vfr | 2026-10-13 10:57:06 | 0 | 122.5 | logs/S-audit-other-vfr.log |
| S-audit-ppt-vfr | 2026-10-13 10:59:09 | 0 | 18.3 | logs/S-audit-ppt-vfr.log |
| F-p2-W-on-vm-no-restore | 2026-10-13 10:58:08 | 1 | 89.6 | logs/F-p2-W-on-vm-no-restore.log |
| S-check-vfr | 2026-10-13 10:59:27 | 0 | 11.4 | logs/S-check-vfr.log |
| F-v-W-on-vfix | 2026-10-13 10:59:37 | 1 | 89.4 | logs/F-v-W-on-vfix.log |
| F-p2-U19.vfr-on-vm-no-restore | 2026-10-13 10:59:37 | 0 | 168.7 | logs/F-p2-U19.vfr-on-vm-no-restore.log |
| F-v-U19.vfr-on-vfix | 2026-10-13 11:01:06 | 0 | 165.2 | logs/F-v-U19.vfr-on-vfix.log |
| F-v-U2.vfr-on-vfix | 2026-10-13 11:03:51 | 0 | 145.8 | logs/F-v-U2.vfr-on-vfix.log |
| F-v-v189.vfr-on-vfix | 2026-10-13 11:06:17 | 0 | 80.5 | logs/F-v-v189.vfr-on-vfix.log |
| F-v-v195kept.vfr-on-vfix | 2026-10-13 11:07:52 | 0 | 61.8 | logs/F-v-v195kept.vfr-on-vfix.log |
| F-v-v195kept.vfr-on-vfr | 2026-10-13 11:08:54 | 0 | 59.1 | logs/F-v-v195kept.vfr-on-vfr.log |
| F-m1-U19.vfr-on-v200-u19-putback-keeps-nothing-saved | 2026-10-13 11:07:38 | 1 | 227.5 | logs/F-m1-U19.vfr-on-v200-u19-putback-keeps-nothing-saved.log |
| F-m1-U19.vfr-on-v200-u19-putback-promise-unkept | 2026-10-13 11:11:26 | 1 | 187.3 | logs/F-m1-U19.vfr-on-v200-u19-putback-promise-unkept.log |
| F-m1-U19.vfr-on-v200-u19-putback-store-at-putback | 2026-10-13 11:14:33 | 1 | 188.3 | logs/F-m1-U19.vfr-on-v200-u19-putback-store-at-putback.log |
| F-m1-U19.vfr-on-v200-u19-cancel-says-reopen | 2026-10-13 11:17:41 | 137 | 170.1 | logs/F-m1-U19.vfr-on-v200-u19-cancel-says-reopen.log |
| F-m1-U19.vfr-on-v200-u19-putback-needs-handle | 2026-10-13 11:20:32 | 1 | 213.0 | logs/F-m1-U19.vfr-on-v200-u19-putback-needs-handle.log |
| F-m2-U19.vfr-on-v200-u19-cancel-says-reopen | 2026-10-13 11:24:22 | 1 | 187.2 | logs/F-m2-U19.vfr-on-v200-u19-cancel-says-reopen.log |

**Results:**
- **U19 block:**
  - on the fix: 104/104;
  - on the base: 50 fail, all non-control; 0 of 54 controls fail. By scenario: (a) 8, (b) 4, (c) 5, (d) 4, (e) 4, (f) 8,
    (g) 3, (h) 1, (m) 4, (o) 4, (p) 2, (q) 1, (r) 2. This matches the builder exactly.
- **U2:** 57/57 on each board's own copy. Crossed, 2 fail each way, both the (d) rows.
- **v1.89:** the fix's copy 40/40 on the fix; the base's copy on the fix, 1 fail ("the file is newer").
- **Probe W** (`probe/wblock.mjs.txt`, harness `W.mjs` `6d0a7b6b`). Rows marked `(observe)` "fail" by design.
  - On the fix: W1 and W1c fail (MF-A); W4 fails (SF-2); W7 fails (SF-4). W2, W3, W5 and W6 pass.
  - On the base: W1c, W3 (nothing kept), W4 (S1 lost), W5 (nothing kept) and W7 fail.
- **Probe X** (`X.mjs` `c26ec369`): fix 0 fail; base 3 fail; `vm-base-zero` 3 fail.
- **Suites** in the scratch clone `git/vfr` (orbit-board 7ee498a plus the fix's board and audit-import): boot-same, audit,
  audit-other and audit-ppt all pass; `npm run check`'s command (`node tools/check.mjs`) reports "all checks passed".
- **mcount** (text only, `python3 -I`): fix 1344/1344 entries match exactly once; base 1328/1328
  (`out/mcount/vfr.txt`, `vbase.txt`).

**Mutants** (made from vfr's board; never through mutate.mjs; one bounded run each, U19 block unless named):

| mutant | how made | blob | result |
|---|---|---|---|
| `v200-u19-putback-keeps-nothing-saved` | builder's entry, `mkmut.py` (text only), 1 match | `f614932f` | caught: 47 fail ((a) 8, (b) 4, (c) 5, (d) 4, (e) 4, (f) 8, (g) 3, (h) 1, (m) 4, (o) 4, (p) 2); 0 controls |
| `v200-u19-putback-promise-unkept` | builder's entry, `mkmut.py`, 1 match | `0586fe1d` | caught: 38 fail; 0 controls |
| `v200-u19-putback-store-at-putback` | builder's entry, `mkmut.py`, 1 match | `aeb9f307` | caught: 4 fail, all (m) |
| `v200-u19-cancel-says-reopen` | builder's entry, `mkmut.py`, 1 match | `95379a7f` | first run (`F-m1`, 11:17 AM) OOM-killed by the memory cgroup at 170 s, exit 137, PID 2002, 83 rows: INCOMPLETE. Re-run `F-m2` (11:24 AM): caught, 2 fail ((p) 1, (q) 1) |
| `v200-u19-putback-needs-handle` | builder's entry, `mkmut.py`, 1 match | `fe616779` | caught: 4 fail, all (o) |
| `vm-base-zero` (mine) | `bin/vmut.py`: `driveBaseOf(mySlug())!==(+MS.ts\|\|0);` → `!driveBaseOf(mySlug());` | `ce43b879` | **SURVIVES the U19 block** (104/104, exit 0). Caught by my X1 (3 fail): S1B in no copy |
| `vm-no-restore` (mine) | `bin/vmut.py`: the restore line on `applyStore` refusal → `if(false){}` | `f10e9128` | **SURVIVES the U19 block** (104/104, exit 0). Caught by my W6 (1 fail): K lost, the slot holds the locked view |

The builder's counts for its five entries are the same: 47, 38, 4, 2, 4.

**The demonstration fix `vfix`** (MF-A, board `63092e7c`): probe W, with W1 and W1c now passing and every other row as on the
fix; U19 104/104; U2 57/57; v1.89 40/40; v1.95 kept 10/10 (also 10/10 on the fix).

**The demonstration copy `vfix`** (MF-A): all four regression harnesses pass on it -- U19 104/104, U2 57/57, v1.89 40/40, v1.95 kept 10/10 -- and probe W shows W1 and W1c passing with every other row as on the fix (runs `F-v-*`).

**Suggested replacement for the Unresolved bullet's overclaim (SF-2):** "So 💾 Save's HOLD ON answered OK no longer leaves the work that was on screen at the put-back in no copy this board can reach, whichever way 📡 Live view's switch is set by the Save. While that copy is kept, a newer copy of the file that would need work kept aside is not loaded (the board says so), and a later 💾 Save answered OK at its HOLD ON leaves that newer copy only in Teams version history (measured: verify-money-r2 W4) -- open for the lead."

## 6. PIDs

`pids.txt` lists each bounded command's `timeout` PID and its child, with the time, label and command; mcount, mkmut and the
clone are there too. **No process was killed.**

## 7. Decisions, and what I did not do

**Decisions:**
- MF-A is a must-fix, not an open wording point. It is the same class as round 1's M2 (a false put-back question made
  reachable by the change), and the FIX line names the put-back question.
- SF-2 is not a must-fix. The lead chose "kept aside, like the unsaved 'swap' case", which means one occupied slot. The board
  says the newer copy was not loaded, and the HOLD ON asks. It needs the lead's explicit acceptance, and true drafts.
- W7 is reported as a should-fix (a new ledger row), not as U19's must-fix. It is identical on the base.

**Not done:**
- Not run (the lead's): the full audit-import and audit-board, and the mutation sweep.
- Not run: audit-recon, legacy-fsrc, audit-hostile and audit-inject. The builder ran them; the change does not touch their
  areas.
- Not run: Chromium and Playwright.
- Not tested: a second tab (U20); real Teams or disk version history.
- I did not import `vfix` into any suite. It is a demonstration, not for commit.

**Deviations:**
- One `node --check` of `W.mjs` ran with `timeout 60`, without `setsid -w` and without the lock check, at about 10:49 AM ET.
  The lock was absent before and after.
- Read-only commands (`cat`, `grep`, `sed`, `diff`, `git hash-object`, `ls`, `date`) and `python3 -I` text tools on my own
  files ran unwrapped.
- The `cp -a` copies and `mkdir`/`ln -s` of my own directories also ran unwrapped.
- Background chains of bounded steps were sequenced by unwrapped shells.
- The waits were `until … sleep` loops, run in the background or with a tool timeout.

This README was written from 11:03 AM ET and last edited at 11:28 AM ET, 13 Oct 2026 (read from the clock when written).
