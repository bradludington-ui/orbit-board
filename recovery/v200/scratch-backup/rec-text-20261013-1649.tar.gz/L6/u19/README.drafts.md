
## 12. Drafts for the lead (the lead commits; I did not)

### 12.1 NEXT-VERSION.md, under v2.00, after the U14 entry and before "Unresolved after R1–R5"

```
- **U19 — ↶ Put back after a board-file save keeps what it replaces** (Brad, 12 Oct, about 5:30 PM ET: "Don't wait for me.
  Let's keep pressing throughout to get this next version published."; the lead's decision to fix the release blockers).
  With work saved into the board file (S1), ↶ Put back of the work kept aside (K) kept nothing in S1's place, because S1 was
  "still in the saved file it came from, and 💾 Save will ask before writing over that". Save did ask (its HOLD ON), but
  answered OK it wrote K over S1, and then S1 was in no copy this board could reach: not on screen, not kept aside, not in
  browser storage, not in a byte of the file, after the Save and after a reopen. It was left only in Teams version history,
  outside the board, where the file has one. The shared folder keeps the copy a save replaces in its history; a board file
  keeps none. Now, when 💾 Save writes to a board file, what is on screen is kept aside in the kept work's place whether or
  not it is saved, as unsaved work always was, with the checkpoint it came from. Putting it back later restores it, and Save
  asks again before writing over the file. The question adds "It is also kept aside in its place, so it is not lost if Save
  does." With no room in browser storage to keep it, nothing is put back and nothing changes, as for unsaved work. The words
  for a copy kept at a put-back no longer call it work no saved copy had or say a saved copy replaced it: the top bar's
  ↶ work kept aside says "What was on screen when other work was put back, kept aside …", 📁 File says "kept … · what was on
  screen when other work was put back", and putting such a copy back says "💾 Save will ask before it writes over a copy saved
  after the one this work came from." The shared folder is unchanged. The HOLD ON's words are unchanged.
  - **What users may see:** after ↶ Put back on a board file, the top bar keeps offering ↶ work kept aside (what was on
    screen) until it is put back, saved as a file or discarded. While it is kept, a newer copy that would need work kept
    aside is not loaded, and the board says so, as it already did for unsaved work. This includes reopening the file
    before any Save after the put-back: K stays on screen, unsaved, and the file's copy (S1, the very copy kept aside) is
    not loaded ("… the newer copy was not loaded and nothing was lost"); before, S1 opened and K was kept. A put-back in a
    browser whose storage is full is now refused, with "nothing was changed", where it used to go ahead.
  - **Test:** audit-import "v2.00 (U19) — put back after a board-file save keeps what it replaces" (71 checks). It drives the
    routes through the page's own buttons and menus: put back once S1's save has landed; put back while it writes (refused,
    U2) and again once it has landed; through 📁 File and the note editor; with no file handle remembered (the picker); and
    between two writers, each with their own key (✍ Take the pen, both ways). Each route then runs 💾 Save with the HOLD ON
    answered OK and a reopen. It also covers S1 put back again before any Save, a reopen before any Save, and no room in
    browser storage. The controls are the HOLD ON answered Cancel, S1 never saved, the shared folder and ordinary editing.
    34 checks fail on the board before the change, all in the eight changed scenarios; every control passes on both.
  - **Existing expectations changed (3, each listed with old → new in the builder's record):** v1.89 "the file is newer",
    "one click puts it back": the kept slot was empty after the put-back and now holds the colleague's copy. "v2.00 (U2) — put
    back waits for a save to finish", case (d), the board file: "put back again" kept nothing (`null`) and now keeps S1
    (`'S1'`), and the reopen then shows K with S1 kept (`['K','S1']`, was `['S1','K']`).
  - **Mutations:** `v200-u19-putback-keeps-nothing-saved`, `-putback-promise-unkept`, `-putback-question-unsaid`,
    `-swap-status-names-saver`, `-swap-title-unsaved` and `-swap-menu-replaced`; each caught by the focused block (full-suite
    sensitivity runs in the final-tree queue).
  - **Not covered:** the file's own Change journal after K's Save keeps no trace of S1; S1 and its journal are in the kept
    copy. The HOLD ON still calls the person's own save "their changes" (the triage's O1), and after a take-the-pen route
    the put-back status still names the writer the kept work came from ("which Bob saved after it"); both are wording points,
    not changed here. Reopened before any Save, the top bar says "Saved" while the work on screen is unsaved by the record;
    this is the board's existing opening behaviour, now reached on this route too. A HOLD ON answered OK over another
    writer's file copy, not after a put-back, still leaves that copy only in Teams version history. A second tab of the same
    browser (U20) and a real browser (Chromium) were not run.
```

### 12.2 "Unresolved after R1–R5 (11 Oct)" (NEXT-VERSION.md)

The U2 bullet's last sentence, "Its separate reopening and adoption findings stay open in the ledger (U15–U20).", becomes:

```
    Its separate reopening and adoption findings stay open in the ledger (U15–U18 and U20); U19 is built (below).
```

Add a new bullet after the U14 bullet:

```
  - **U19: built as its own commit** (the lead's decision under Brad's "Don't wait for me", 12 Oct, about 5:30 PM ET): a
    ↶ Put back after a board-file save keeps what it replaces aside, so 💾 Save's HOLD ON answered OK no longer leaves it in
    no copy this board can reach (above). Three wording points stay open: the HOLD ON's "their changes" for the person's own
    save (O1); the put-back status naming the earlier writer after a take-the-pen route; and the top bar's "Saved" on a
    reopen before any Save while the work on screen is unsaved by the record.
```

### 12.3 UNRESOLVED-LEDGER.md

Append to the Status cell of the first U19 row:

```
 **Built as its own commit `<sha>` (<time> ET)** under the lead's decision of 12 Oct (Brad, about 5:30 PM ET: "Don't wait
 for me."): board `8cf14d7e`, audit-import `a1a3e32c`, mutate `67ec010f`. `keptPutBack` keeps what is on screen aside in the
 kept work's place whenever 💾 Save writes to a board file (`!driveStoreOn()`), saved or not, as unsaved work always was.
 The question says so, and the words for a copy kept at a put-back ('swap') no longer call it unsaved or replaced, in the top
 bar, 📁 File and the put-back status. Focused block "v2.00 (U19)": 71 checks, 34 fail on the board before (`fce8a391`, product d66dd60), all
 pass after; every control passes on both. It covers five routes: file-after, file-retry, ui-after (📁 File and the note
 editor), picker-after and pen-after (two keys, ✍ Take the pen both ways). The checker's probes on the fixed copy find S1
 reachable after the Save and after reopening on all five. Three existing expectations changed: v1.89 "the file is newer",
 and two in U2 put back waits case (d). Each is listed old → new in the builder's README (`rec/L6/u19`). Six mutations,
 each caught by the block. The folder route is unchanged. Open:
 - the HOLD ON's "their changes" for her own save (O1), and the put-back status naming the earlier writer after a
   take-the-pen route (wording);
 - the top bar's "Saved" on a reopen before any Save while the record says unsaved (the existing opening behaviour, now on
   this route);
 - the file's Change journal keeps no trace of S1 (S1 is in the kept copy).
 The full audit-import and audit-board runs, and the final-tree mutation queue, are the lead's.
```

Append to the Status cell of the P1 table's U19 row:

```
 Built: see the U19 row (`<sha>`).
```
