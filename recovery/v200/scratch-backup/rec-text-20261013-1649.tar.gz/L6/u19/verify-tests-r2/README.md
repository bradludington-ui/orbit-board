# U19 verify, round 2, lens B (test adequacy and regressions)

This is the independent adversarial verifier for ORBIT v2.00 track U19, round 2, lens B. It checks the fix round's revised
commit, the builder's `fr/c1`. All times are Eastern (ET).

This attempt resumed one stopped by the lead at about 11:45 AM ET on 13 Oct, which was running too many processes at once.
- I read that attempt's folder first. None of its recorded PIDs was still running when I started (checked at 11:57 AM ET).
- I reused every run of it that finished with an exit record on the same blobs (§3).
- I re-ran the one run the lead's stop killed (exit 137).
- This attempt ran at most two node processes of mine at a time, in two sequential lanes.

## 1. Verdict

**sound-with-issues; two must-fixes.** The revised board does what the builder says on every route the block drives. Every
builder run I re-ran matches theirs row for row, observed values included. Every new expected value is a hand-written
literal. Every new non-control check fails on the base board: 50 of 50 fail, and all 54 controls pass on both boards. The
existing suites pass on c1 as on the base (§7). mcount, read as text only, gives 1344 of 1344 entries matching exactly once.

The tests have gaps:
- **MF-T1 (data loss, test gap).** A plausible wrong version of the fix's M1 clause, `!driveBaseOf(mySlug())` in place of
  `driveBaseOf(mySlug())!==(+MS.ts||0)`, passes the whole U19 block (104/104) and both U2 blocks (57/57).
  - On a real route it leaves S1 in no copy the board can reach, after the Save and after a reopen.
  - My probe scenario VY-A catches it.
  - The money verifier found the same mutant as its SF-1. I rate it a must-fix for this lens: it is the release's can't-fail,
    and the block's own M1 scenario (m) uses an empty folder, so it pins the clause only where the folder base is 0.
- **MF-T2 (false words, test gap).** The block's (r) presses the very put-back whose question is false: "What is on screen now
  is still in the saved file it came from" when what is on screen (K) is only in the shared folder. The block checks only the
  number of questions there.
  - My probe VY-E reproduces it on c1.
  - It is the money verifier's MF-A (principle 4). The block needs the board fix and a check of the words.
- **Should-fixes.** Three more of my 13 mutants survive the block, each a words-only defect, and each is caught by a VY
  scenario that passes on c1: the Cancel advice with work kept by an opening; a fresh page; an edit after a saved put-back.
  Some entries are caught by a single check only.

## 2. Identities

| what | path (all mine unless said) | blob |
|---|---|---|
| base board / audit-import / mutate | `base/` (cp -a of `rec/L6/base`, 7ee498a) | `fce8a391` / `4aba2506` / `cbc6defc` |
| c1 board / audit-import / mutate | `c1/` (rebuilt from base with the builder's own text scripts, `bin/build.sh`; `diff -rq` against the builder's `fr/c1`: identical) | `f6ac4b9d` / `cfaeac17` / `9028eaa8` |
| build's superseded c1 (crossed runs only) | `bc1/` | `8cf14d7e` / `a1a3e32c` / `67ec010f` |
| audit-recon / audit-board / audit-other | same in all three | `529e36f7` / `a7c575e5` / `d89396b0` |
| U19 block as inserted (c1 L7804–8213) | `out/u19-block.c1.txt`, byte-identical to the builder's `fr/block-u19.fr.mjs.txt` | `cf0f971d` |
| focused harnesses (built verbatim by `mkfocused-u2.py`, copied unchanged from `rec/L2/u2impl`) | `h/src-*`, `h/run-*` | U19 `40356194`, U2.c1 `a1edf6a8`, U2.base `32cc5ac7`, v189.c1 `49261f6a`, v189.base `ed54e613`, v195kept `f2adbb73` (each the builder's own blob, from their logs' IDS lines) |
| my probe VY (5 scenarios) | `vy/vy-block.mjs.txt` → `h/run-*/VY.mjs` | block `3dce36fd`, harness `48b9720a` |
| my mutants | `mut/mkvt2.py` → `mut/vt2-mutants.mjs.txt` (13 entries, text only) | `f04930b8` → `25b777e1` |
| runner | `bin/runner.mjs` (imports the copy's shim, then its boot.mjs; BOARD asserted) | `f720ce18` |
| scratch clones (never committed in) | `git/c1` (7ee498a + c1's board and audit-import), `git/base` (7ee498a as is) | board `f6ac4b9d` / `fce8a391` |

Each mutant board is in `mut/c1/<id>.html`, with its blob in `mut/blobs.r2.txt`. Each differs from c1's board in exactly one
line: one changed line, or the one removed line of `v200-u2-putback-while-saving`.

## 3. Reused from the stopped attempt (same blobs, each with an exit record)

The stopped attempt left these complete runs, each on the blobs in §2:
- the focused U19 (on c1 and on bc1), U2, v1.89 and v1.95-kept harnesses, and the crossed runs;
- probe VY on c1 and on the base;
- `vt2-keep-folder-unused` through U19 and through U2;
- `v200-u19-putback-store-at-putback` through U19.

They are the `F-r1-*`, `F-p1-*`, `M-vt2-vt2-keep-folder-unused-*` and `M-frA-...store-at-putback` rows of Appendix A.

The one run the lead's stop killed was `F-r1-U19.c1-on-base` (exit 137 at 240.7 s, incomplete). I re-ran it as
`F-r2-U19.c1-on-base`.

## 4. The builder's runs, re-run and compared

`bin/cmprows.py` compares my check record with the builder's, row by row: place, claim and verdict, then every observed value.

| run (mine vs the builder's) | mine | builder | rows and observed values |
|---|---|---|---|
| U19 block on c1 (`F-r1-U19.c1-on-c1` vs `F-fr2-U19.frc1-on-frc1`) | 104, 0 fail | 104, 0 fail | SAME / SAME |
| U19 block on base (`F-r2-U19.c1-on-base` vs `F-fr2-…-on-base`) | 104, 50 fail | 104, 50 fail | SAME / SAME |
| U19 block on the build's c1 (`F-r1-U19.c1-on-bc1` vs `F-fr2-…-on-c1`) | 104, 8 fail: (f) 2, (m) 4, (p) 1, (q) 1 | 8 fail | SAME / SAME |
| U2 blocks on c1 | 57, 0 fail | 57, 0 | SAME / SAME |
| U2 base text on c1 | 57, 2 fail ((d)) | 2 | SAME / SAME |
| U2 c1 text on base | 57, 2 fail ((d)) | 2 | SAME / SAME |
| v1.89 on c1 / base text on c1 / c1 text on base | 40/0, 40/1, 40/1 | same | SAME / SAME |
| v1.95 kept on c1 and base (one harness, identical text) | 10/0 each | same | — |
| mcount c1, base, crossed (text only, §8) | 1344/1344; 1328/1328; c1 text on base 1328 once, the 16 U19 ids missing; base text on c1 1328/1328 | same | — |

The builder's mutant counts are re-run in §6. The suites are re-run in §7.

## 5. Literals, base failures and changed existing expectations

**Literals.** `bin/lastargs.py` lists the last argument of each of the block's 62 `chk(` calls (`out/u19-block.c1.txt`):
- Every expected value is `J([...])` of hand-written literals and the block's literal constants (`K`, `S1`, `N`, `'file'`,
  `'swap'`, `true`/`false`/`null`, numbers, `K + ' RETYPED'`), or a bare literal.
- Board helpers appear only on the observed side.
- The word constants (`PUTQ`, `UNSAVEDQ`, `PUTAGAINQ`, `CANCEL_IMPORT`, `CANCELLED_IMPORT`, `SWAPSAID`, `SWAPMENU`, the
  `holdOn`/`SWAPTITLE` patterns) are hand-written strings.
- The v1.89 change keeps its literal `'BRAD NOTE||true'`.

**Every new check fails on the base, controls aside** (`F-r2-U19.c1-on-base`):
- 104 checks: 50 fail and 54 pass.
- Every one of the 54 passing checks is labelled a CONTROL, either "(a CONTROL)" in its claim or "CONTROL:" in its scenario.
- No control fails on either board.
- Fails by place: (a) 8, (b) 4, (c) 5, (d) 4, (e) 4, (f) 8, (g) 3, (h) 1, (m) 4, (o) 4, (p) 2, (q) 1, (r) 2.

**The suite diffs against the base.**
- **mutate.mjs.txt** gains only the 51 inserted lines: 16 entries and 2 comment lines, before the R3 line. Lines 1–4285 and
  the tail are byte-identical.
- **audit-recon, audit-board and audit-other** are unchanged.
- **audit-import** has the U19 block inserted after the U13 end marker, plus these changed existing lines, all disclosed in
  the builder's README §FR table:

| # | file:line (base → c1) | old | new | crossed runs |
|---|---|---|---|---|
| 1 | audit-import.mjs L3512 → L3512 (new comment) + L3513–3514 | v1.89 "the file is newer", check 'one click puts it back': observed `…+String(kept===null)`, want `'BRAD NOTE||true'` | check '… and what was on screen (the colleague's copy, saved only in the file) is kept aside in its place': observed `…+String(/COLLEAGUE NOTE/ in kept && !/BRAD NOTE/ in kept)`, want unchanged | old text fails on c1 (1), new text fails on base (1) |
| 2 | L7326 → L7328 | comment "(`was`: null when S1 is saved)" | "…or if it is saved only in a board file (v2.00, U19) (`was`: null when S1 is saved in the folder)" | comment only |
| 3a | L7396–7397 → L7400–7401 | U2 "put back waits", (d): want `[1,'K',true,true,true,null]` | want `[1,'K',true,true,true,'S1']` | old fails on c1, new fails on base |
| 3b | L7398 → L7402 | `afterFile(…, ['S1','K'])` | `afterFile(…, ['K','S1'])` | the second (d) failure, both ways |

There are no other changed lines in the suites. The first U2 block's case (c) (base ~L7228–7244) runs the file-retry route,
and its observations are unchanged: 0 failures in the crossed runs. The fix does keep S1 there, but no check of (c) reads the
kept slot after its retry.
## 6. Mutants: the builder's 16 entries, 3 existing put-back entries, and my 13

Each cell is failing checks / checks. U19 cells also give the places that fail.
- Every mutant board was made by `rec/bin/mkmut.py` from text (mutate.mjs.txt, or my `mut/vt2-mutants.mjs.txt`), and its find
  matched once on c1.
- It ran with `BOARD` set to the mutant, through the harnesses named; "—" means not run through that harness.
- `M-frA/frB/frC` are the builder's (fix-round, build, existing) and `M-vt2` are mine.
- The VY column's (VY-E) row fails on c1 itself (MF-T2), so only the other VY row counts there.

| mutant | U19 | U2 | v189 | v195kept | VY |
|---|---|---|---|---|---|
| `vt2-keep-folder-unused` | 0/104 | 0/57 | 0/40 | 0/10 | 4/13 (VY-A)3,(VY-E)1 |
| `v200-u19-putback-store-at-putback` | 4/104 (m)4 | — | — | — | — |
| `v200-u19-putback-keeps-nothing-saved` | 47/104 (a)8,(b)4,(c)5,(d)4,(e)4,(f)8,(g)3,(h)1,(m)4,(o)4,(p)2 | 2/57 | 1/40 | — | — |
| `vt2-keep-own-only` | 0/104 | — | 1/40 | — | — |
| `v200-u19-putback-promise-unkept` | 38/104 (a)7,(b)3,(c)4,(d)3,(e)3,(f)7,(g)2,(h)1,(m)3,(o)3,(p)2 | 2/57 | 1/40 | — | — |
| `vt2-kept-the-wrong-copy` | 41/104 (a)5,(b)3,(c)3,(d)3,(e)3,(f)6,(g)2,(j)3,(m)3,(o)3,(p)2,(q)2,(r)3 | — | — | — | — |
| `vt2-swap-not-twice` | 7/104 (a)2,(f)5 | — | — | — | — |
| `vt2-swap-base-of-kept` | 1/104 (f)1 | — | — | — | — |
| `v200-u19-putback-question-unsaid` | 10/104 (a)2,(b)1,(c)1,(d)1,(e)1,(f)1,(g)1,(m)1,(o)1 | — | — | — | — |
| `vt2-question-by-store` | 1/104 (m)1 | — | — | — | — |
| `v200-u19-swap-status-names-saver` | 3/104 (a)1,(f)1,(r)1 | — | — | — | — |
| `vt2-cancel-swap-only` | 0/104 | 0/57 | 0/40 | 0/10 | 2/13 (VY-B)1,(VY-E)1 |
| `v200-u19-swap-title-unsaved` | 4/104 (a)3,(r)1 | — | — | — | — |
| `vt2-putsavedgen-init0` | 0/104 | 0/57 | 0/40 | 0/10 | 2/13 (VY-C)1,(VY-E)1 |
| `v200-u19-swap-menu-replaced` | 3/104 (a)1,(c)1,(r)1 | — | — | — | — |
| `v200-u19-putback-folder-keeps-nothing` | 7/104 (m)4,(r)3 | 7/57 | — | — | — |
| `vt2-asput-ignores-edits` | 0/104 | 0/57 | 0/40 | 0/10 | 2/13 (VY-D)1,(VY-E)1 |
| `vt2-saved-always` | 1/104 (f)1 | — | — | — | — |
| `v200-u19-putback-needs-handle` | 4/104 (o)4 | — | 1/40 | — | — |
| `vt2-swap-saved-asput-only` | 2/104 (f)2 | — | — | — | — |
| `vt2-cancel-status-reopen` | 2/104 (p)1,(q)1 | — | — | — | — |
| `v200-u19-putback-again-unsaved-said` | 2/104 (f)2 | — | — | — | — |
| `vt2-question-kept-always` | 1/104 (k)1 | — | — | — | — |
| `v200-u19-putback-again-any` | 2/104 (f)2 | — | — | — | — |
| `v200-u19-swap-saved-forgotten` | 1/104 (f)1 | — | — | — | — |
| `v200-u19-cancel-says-reopen` | 2/104 (p)1,(q)1 | — | — | — | — |
| `v200-u19-swap-status-by-kept` | 2/104 (a)1,(r)1 | — | — | — | — |
| `v200-u19-swap-title-any-kind` | 1/104 (r)1 | — | — | — | — |
| `v200-u19-swap-menu-any-kind` | 1/104 (r)1 | — | — | — | — |
| `putback-drops-screen` | 5/104 (f)4,(j)1 | 0/57 | — | 0/10 | — |
| `v200-u2-putback-gen` | 0/104 | 1/57 | — | — | — |
| `v200-u2-putback-while-saving` | 7/104 (b)7 | 35/57 | — | — | — |

**The builder's counts are all reproduced exactly:**
- frA: `store-at-putback` 4, `folder-keeps-nothing` 7 + U2 7, `needs-handle` 4 + v189 1, `again-unsaved-said` 2,
  `again-any` 2, `swap-saved-forgotten` 1, `cancel-says-reopen` 2, `swap-status-by-kept` 2, `swap-title-any-kind` 1,
  `swap-menu-any-kind` 1.
- frB: `keeps-nothing-saved` 47/2/1, `promise-unkept` 38/2/1, `question-unsaid` 10, `swap-status-names-saver` 3,
  `swap-title-unsaved` 4, `swap-menu-replaced` 3.
- frC: `putback-drops-screen` U19 5, U2 0, v195kept 0 (the coverage shift the builder documented); `v200-u2-putback-gen`
  U2 1, U19 0; `v200-u2-putback-while-saving` U2 35, U19 7.

Three entries (`swap-status-by-kept`, `swap-title-any-kind`, `swap-menu-any-kind`) are caught only through (r)'s CONTROL
row. That still catches them.

**My 13 mutants** (each a plausible wrong fix; text in `mut/vt2-mutants.mjs.txt`):
- **Caught by the U19 block (8):** `kept-the-wrong-copy` 41, `swap-not-twice` 7, `swap-saved-asput-only` 2,
  `cancel-status-reopen` 2, `swap-base-of-kept` 1, `question-by-store` 1, `saved-always` 1, `question-kept-always` 1 (the (k)
  CONTROL).
- **Caught only by the changed v1.89 row (1):** `keep-own-only`.
- **Not caught by any focused harness I may run (4):** U19, U2, v1.89 and v1.95-kept all pass on them.
  - `keep-folder-unused` loses data (MF-T1).
  - `cancel-swap-only`, `putsavedgen-init0` and `asput-ignores-edits` give false words (SF-T1).
  - Each is caught by its VY scenario.
  - I did not run the full audit-import (the lead's), so another block of it could still catch one. Nothing in the blocks
    I read drives these routes.

## 7. Suites on the final copy and on the base

All ran in the scratch clones (`git/c1`, `git/base`), one bounded run each:
- audit-recon, boot-same, audit, audit-ppt, audit-other, legacy-fsrc, audit-hostile and audit-inject;
- npm run check, run as its own script, `node tools/check.mjs prioritization-board-grid.html`, so npm's own node is not added.

Results:
- Every one exits 0 on both copies.
- With timings masked, each suite's output is identical on c1 and the base.
- The one exception is check's line count: 31699 vs 31672 lines; main script 29677 vs 29650; +27 = 37 added − 10 removed.
- The builder's suite results on fr/c1 (all pass) are reproduced.

## 8. mcount (text only; `rec/bin/mcount.py`, never mutate.mjs itself)

| mutate text | board | result |
|---|---|---|
| c1 (`9028eaa8`) | c1 | 1344 entries, 1344 once |
| base (`cbc6defc`) | base | 1328, 1328 once |
| c1 | base | 1328 once; missing exactly the 16 v200-u19 ids |
| base | c1 | 1328, 1328 once: every existing entry still matches once on the fixed board |
| mine (`mut/vt2-mutants.mjs.txt`) | c1 / base | 13 of 13 once / 1 once (the rest are the new code) |

## 9. Findings

### MUST-FIX

**MF-T1. A data-losing wrong version of the M1 clause passes the whole U19 block and both U2 blocks.**

Mutant `vt2-keep-folder-unused` (`mut/vt2-mutants.mjs.txt`, board `ce43b879`):

```
-  const keepScreen=nowUnsaved || !driveStoreOn() || driveBaseOf(mySlug())!==(+MS.ts||0);
+  const keepScreen=nowUnsaved || !driveStoreOn() || !driveBaseOf(mySlug());
```

It is a plausible "simplification": keep unless the folder holds the screen's copy, approximated as "the folder has any base".

Results:
- **U19 block:** 104/104 pass (`M-vt2-vt2-keep-folder-unused-U19.c1-on-c1`, exit 0).
- **U2 blocks:** 57/57 pass (`…-U2.c1-on-c1`, exit 0).

Why the block misses it: its M1 scenario (m) connects an EMPTY folder, so `driveBaseOf` is 0 either way. Scenarios (k) and
(r) only test base == MS.ts. So the clause is pinned at its two ends only.

**Reproduction** (probe VY-A, `vy/vy-block.mjs.txt`, run through `h/run-c1/VY.mjs` with `BOARD` = the mutant):
1. The opening keeps K and opens N.
2. A folder is connected. S0 is typed and saved to the folder: nothing asked.
3. 📡 Live view's own switch is turned to ○ Just watching.
4. S1 is typed and saved into the board file only: nothing asked.
5. Working out of the folder again (`connect`), ↶ Put back is pressed.
6. The switch is turned back. 💾 Save: HOLD ON, answered OK.
7. Reopen.

What each board does:
- **On the mutant** (`M-vy-vt2-keep-folder-unused-VY-on-c1`, exit 1), nothing is kept at the put-back:
  `got ["clicked",1,false,"U19-K-KEPTWORK",null]`.
  - After the Save, S1 is in no byte of browser storage, the board file or the folder (its history included): `got [null,false]`.
  - After the reopen, the same: `got ["U19-K-KEPTWORK",null,false]`.
  - That is U19's data loss, back.
- **On c1** these rows pass (`F-p1-VY-on-c1`).
- **On the base** they fail (`F-p1-VY-on-base`, 3 rows).

**Minimal fix:** add the scenario to the U19 block as (s), drafted in the block's own helpers in
`proposal/u19-block-additions.mjs.txt`. Add the entry `v200-u19-putback-folder-base-any` (`proposal/mutate-entries.txt`; its
find is the keepScreen line, matched once on c1).

The money verifier rated the same gap its SF-1. I rate it a must-fix for this lens: it is the can't-fail (DATA LOSS), on the
clause the fix round added to close M1, and the block claims the M1 route covered.

**MF-T2. The block's (r) runs the put-back whose question is false, and does not read the question.**

Probe VY-E reproduces it on c1 (`F-p1-VY-on-c1`, exit 1):
1. S1 is saved into the file.
2. ↶ Put back K: S1 is kept as 'swap'.
3. A folder is connected. 💾 Save writes K to the folder; the file still holds S1.
4. ↶ Put back S1.

The question says "What is on screen now is still in the saved file it came from, and 💾 Save will ask before writing over
that." (`got ["clicked",1,true,…]`). K is only in the shared folder.

Coverage of it today:
- The block's (r) reaches the same question by "Save yours over theirs" and checks only `qs` count, screen, kept slot and status.
- No U19 entry or mutant touches the sentence.
- It is the money verifier's MF-A (principle 4). That verifier demonstrated a one-line board fix (its `vfix`).

**Minimal fix:** take that board fix, and make (r)'s last check read the question's sentence (sketch in
`proposal/u19-block-additions.mjs.txt`), with an entry that reverts it.

### SHOULD-FIX

**SF-T1. Three words-only mutants survive the U19 block.** Each is caught by a probe scenario that passes on c1:

| mutant | what it breaks | U19 block | probe that catches it | base |
|---|---|---|---|---|
| `vt2-cancel-swap-only` (`reo=!(_keptMeta && _keptMeta.why==='swap')`) | with work kept by an OPENING ('file'), the HOLD ON's Cancel line and the status still name a reopen, which there does not load the file's copy | 104/104 | VY-B (1 row: `got [1,true,false,false,true,…]`) | VY-B fails on base: the base's own false advice, which the fix corrects but the block never drives |
| `vt2-putsavedgen-init0` (`let _putSavedGen=0;`) | on a freshly opened page, before any change, ↶ Put back says what is on screen "was put back and has not been saved since" | 104/104 | VY-C (1 row) | VY-C passes on base (a control for the new M2 words) |
| `vt2-asput-ignores-edits` (`asPut=nowUnsaved && _putSavedGen>=0`) | after a saved copy is put back and then EDITED, ↶ Put back still says it "was put back and has not been saved since" | 104/104 | VY-D (1 row) | VY-D fails on base |

**Fix:** add VY-B, VY-C (as a CONTROL) and VY-D to the block, and the three entries in `proposal/mutate-entries.txt`.

**SF-T2. Thin catches.**
- Several entries and mutants are caught by one check only:
  - `vt2-question-by-store`: (m) 1;
  - `vt2-swap-base-of-kept`: (f) 1, the last Save of (f);
  - `vt2-saved-always`: (f) 1;
  - `vt2-question-kept-always`: only the (k) CONTROL.
- `vt2-keep-own-only` (keep saved work only when its saver is the person on screen) passes the U19 block 104/104. Only the
  changed v1.89 row catches it (1 of 40). Every S1 in the U19 block is Alice's own save, so the colleague's-copy route is
  pinned by a changed existing row alone.
- A colleague-copy scenario in the U19 block would make that catch independent of the v1.89 edit.

### MINOR

- **Drafts.** The NEXT-VERSION draft's "Existing expectations changed (3, each listed with old → new in the builder's record)"
  points to the README for file:line. Principle 6 asks for file:line with the change itself. Copy the four rows of §5 into the
  entry. The NEXT-VERSION "Test" and ledger texts also say "Sixteen mutations, each caught by the block". That is true (§6),
  but once MF-T1, MF-T2 and SF-T1 are added the counts change: 104 checks and 16 entries will both grow.
- **Coverage shift (documented by the builder, confirmed).** `putback-drops-screen` is now caught only by the U19 block
  (5; U2 0, v195kept 0). The builder's added `v200-u19-putback-folder-keeps-nothing` restores a U2 catch (7). No action
  beyond keeping the builder's note.
- **The first U2 block's case (c)** runs the file-retry route and now keeps S1, but reads nothing of the kept slot after the
  retry. The U19 block's (b) covers that route, so this is not a gap. It is noted because the lead's brief named (c).

## 10. How the change meets the lead's principles (as tested)

1. **Never lose a copy.** Every route the block drives keeps S1 reachable after the Save and after a reopen (§4: 104/104).
   The test of this is incomplete: MF-T1 is a data-losing variant that passes.
2. **Refuse or ask.** Unchanged: HOLD ON still asks, and a put-back with no room is refused, (h).
3. **Money and exports.** No suite output changed (§7).
4. **Words stay true.** Broken on one route (MF-T2, the money verifier's MF-A). Three word fixes are untested on some of
   their routes (SF-T1).
5. **Smallest change.** The board diff is 37 lines added and 10 removed against the base. Not judged further by this lens.
6. **Existing checks preserved.** Exactly three expectations and one comment changed, each listed (§5) and each crossed both
   ways.

## 11. Decisions, with reasons

- **I rebuilt c1 from the base with the builder's own text scripts** instead of only copying it, and confirmed it identical
  to `fr/c1` (`diff -rq`). The copy proves the scripts and the copy agree.
- **I reused the stopped attempt's finished runs.** They are on identical blobs and each has an exit record. I re-ran only the
  killed one, which saved about 20 minutes of machine time on a loaded machine (load 15–28).
- **MF-T1 is rated a must-fix,** where the money verifier rated the same gap a should-fix. This lens is test adequacy, and a
  silent return of the very data loss the track closes, on the M1 route the block claims to cover, is the one gap the
  can't-fail rule does not allow.
- **MF-T2 is listed here as well as by the money verifier.** It is the same defect, and from this lens a check that drives
  the false sentence without reading it.
- **The 54 controls pass on the base by design.** Each is labelled. I counted them as complying with "every new test fails
  on the base", as the earlier v2.00 blocks do.

## 12. What I did not do

- **Not run (the lead's):**
  - the full audit-import or audit-board;
  - the mutation sweep;
  - mutate.mjs itself, which was read only as text, by mkmut.py and mcount.py;
  - Chromium, Playwright or verify:grid.
- **I wrote no fix.** The proposals in `proposal/` are text only, applied to no copy:
  - VY-A as block scenario (s);
  - (r)'s word check;
  - VY-B, VY-C and VY-D;
  - four mutation entries.
  - Their behaviour is evidenced by probe VY on c1, base and the mutants, not by a rebuilt block.
- **Nothing in /home/user/orbit-board or /home/user/orbit-ui was edited, staged, committed or pushed.** The clones `git/c1`
  and `git/base` are `--shared` scratch clones, never committed in.
- **Deviations:**
  - The lane shells (`bin/lane.sh`, and the wait loops that started them) ran as background tool commands bounded by the
    tool's own timeout, not by `setsid -w timeout -k 10 600`. Every node run inside them was bounded by `run.sh`, and every
    text helper by `bx.sh`.
  - Read-only commands (cat, grep, diff, git hash-object, ps), my own small python3 -I analyses of my own records, and
    `mkdir`/`ln`/`cp` of my own files ran unwrapped.
  - A `tail -F` monitor of my runs.txt was stopped through the task tool. It was not a recorded PID.
  - No process was killed by me.
  - The AUDIT_IMPORT_RUNNING lock was never present at a run's start, so nothing waited or was skipped.

## Appendix A. Every run (logs/runs.txt, in finishing order), with its check tally

| label | start (ET) | exit | wall s | result | log |
|---|---|---|---|---|---|
| F-r1-U2.c1-on-c1 | 2026-10-13 11:32:52 | 0 | 187.9 | 57 checks, 0 fail | logs/F-r1-U2.c1-on-c1.log |
| F-r1-U19.c1-on-c1 | 2026-10-13 11:32:50 | 0 | 243.1 | 104 checks, 0 fail | logs/F-r1-U19.c1-on-c1.log |
| F-r1-U2.base-on-c1 | 2026-10-13 11:36:00 | 1 | 264.9 | 57 checks, 2 fail ((d) 2) | logs/F-r1-U2.base-on-c1.log |
| F-r1-U19.c1-on-base | 2026-10-13 11:36:54 | 137 | 240.7 | 88 checks, 41 fail ((a) 8, (b) 4, (c) 5, (d) 4, (e) 4, (f) 8, (g) 3, (h) 1, (m) 4) TIMED OUT = incomplete | logs/F-r1-U19.c1-on-base.log |
| F-p1-VY-on-c1 | 2026-10-13 11:40:22 | 1 | 112.7 | 13 checks, 1 fail ((VY-E) 1) | logs/F-p1-VY-on-c1.log |
| M-vt2-vt2-keep-folder-unused-U19.c1-on-c1 | 2026-10-13 11:37:45 | 0 | 338.3 | 104 checks, 0 fail | logs/M-vt2-vt2-keep-folder-unused-U19.c1-on-c1.log |
| F-p1-VY-on-base | 2026-10-13 11:42:15 | 1 | 103.0 | 13 checks, 8 fail ((VY-A) 3, (VY-B) 1, (VY-D) 2, (VY-E) 2; 2 of them CONTROL rows) | logs/F-p1-VY-on-base.log |
| F-r1-U2.c1-on-base | 2026-10-13 11:40:25 | 1 | 234.6 | 57 checks, 2 fail ((d) 2) | logs/F-r1-U2.c1-on-base.log |
| F-r1-U19.c1-on-bc1 | 2026-10-13 11:40:54 | 1 | 241.1 | 104 checks, 8 fail ((f) 2, (m) 4, (p) 1, (q) 1) | logs/F-r1-U19.c1-on-bc1.log |
| M-vt2-vt2-keep-folder-unused-U2.c1-on-c1 | 2026-10-13 11:43:24 | 0 | 130.4 | 57 checks, 0 fail | logs/M-vt2-vt2-keep-folder-unused-U2.c1-on-c1.log |
| M-frA-v200-u19-putback-store-at-putback-U19.c1-on-c1 | 2026-10-13 11:42:51 | 1 | 166.7 | 104 checks, 4 fail ((m) 4) | logs/M-frA-v200-u19-putback-store-at-putback-U19.c1-on-c1.log |
| F-r1-U2.base-on-base | 2026-10-13 11:44:20 | 0 | 103.3 | 57 checks, 0 fail | logs/F-r1-U2.base-on-base.log |
| F-r1-v189.c1-on-c1 | 2026-10-13 11:46:03 | 0 | 39.7 | 40 checks, 0 fail | logs/F-r1-v189.c1-on-c1.log |
| F-r1-v189.base-on-c1 | 2026-10-13 11:46:43 | 1 | 35.9 | 40 checks, 1 fail (v1.89 row 1) | logs/F-r1-v189.base-on-c1.log |
| F-r1-v189.c1-on-base | 2026-10-13 11:47:19 | 1 | 30.9 | 40 checks, 1 fail (v1.89 row 1) | logs/F-r1-v189.c1-on-base.log |
| F-r1-v189.base-on-base | 2026-10-13 11:47:50 | 0 | 28.2 | 40 checks, 0 fail | logs/F-r1-v189.base-on-base.log |
| F-r1-v195kept.c1-on-c1 | 2026-10-13 11:48:18 | 0 | 20.1 | 10 checks, 0 fail | logs/F-r1-v195kept.c1-on-c1.log |
| F-r1-v195kept.base-on-base | 2026-10-13 11:48:38 | 0 | 22.1 | 10 checks, 0 fail | logs/F-r1-v195kept.base-on-base.log |
| M-frB-v200-u19-putback-keeps-nothing-saved-U19.c1-on-c1 | 2026-10-13 12:02:41 | 1 | 113.2 | 104 checks, 47 fail ((a) 8, (b) 4, (c) 5, (d) 4, (e) 4, (f) 8, (g) 3, (h) 1, (m) 4, (o) 4, (p) 2) | logs/M-frB-v200-u19-putback-keeps-nothing-saved-U19.c1-on-c1.log |
| F-r2-U19.c1-on-base | 2026-10-13 12:02:41 | 1 | 115.4 | 104 checks, 50 fail ((a) 8, (b) 4, (c) 5, (d) 4, (e) 4, (f) 8, (g) 3, (h) 1, (m) 4, (o) 4, (p) 2, (q) 1, (r) 2) | logs/F-r2-U19.c1-on-base.log |
| M-frB-v200-u19-putback-keeps-nothing-saved-U2.c1-on-c1 | 2026-10-13 12:04:35 | 1 | 145.2 | 57 checks, 2 fail ((d) 2) | logs/M-frB-v200-u19-putback-keeps-nothing-saved-U2.c1-on-c1.log |
| M-vt2-vt2-keep-own-only-U19.c1-on-c1 | 2026-10-13 12:04:37 | 0 | 155.9 | 104 checks, 0 fail | logs/M-vt2-vt2-keep-own-only-U19.c1-on-c1.log |
| M-frB-v200-u19-putback-keeps-nothing-saved-v189.c1-on-c1 | 2026-10-13 12:07:00 | 1 | 39.1 | 40 checks, 1 fail (v1.89 row 1) | logs/M-frB-v200-u19-putback-keeps-nothing-saved-v189.c1-on-c1.log |
| M-vt2-vt2-keep-own-only-v189.c1-on-c1 | 2026-10-13 12:07:13 | 1 | 38.4 | 40 checks, 1 fail (v1.89 row 1) | logs/M-vt2-vt2-keep-own-only-v189.c1-on-c1.log |
| M-frB-v200-u19-putback-promise-unkept-U19.c1-on-c1 | 2026-10-13 12:07:39 | 1 | 146.5 | 104 checks, 38 fail ((a) 7, (b) 3, (c) 4, (d) 3, (e) 3, (f) 7, (g) 2, (h) 1, (m) 3, (o) 3, (p) 2) | logs/M-frB-v200-u19-putback-promise-unkept-U19.c1-on-c1.log |
| M-vt2-vt2-kept-the-wrong-copy-U19.c1-on-c1 | 2026-10-13 12:07:51 | 1 | 147.0 | 104 checks, 41 fail ((a) 5, (b) 3, (c) 3, (d) 3, (e) 3, (f) 6, (g) 2, (j) 3, (m) 3, (o) 3, (p) 2, (q) 2, (r) 3; 5 of them CONTROL rows) | logs/M-vt2-vt2-kept-the-wrong-copy-U19.c1-on-c1.log |
| M-frB-v200-u19-putback-promise-unkept-U2.c1-on-c1 | 2026-10-13 12:10:06 | 1 | 146.8 | 57 checks, 2 fail ((d) 2) | logs/M-frB-v200-u19-putback-promise-unkept-U2.c1-on-c1.log |
| M-vt2-vt2-swap-not-twice-U19.c1-on-c1 | 2026-10-13 12:10:18 | 1 | 164.8 | 104 checks, 7 fail ((a) 2, (f) 5) | logs/M-vt2-vt2-swap-not-twice-U19.c1-on-c1.log |
| M-frB-v200-u19-putback-promise-unkept-v189.c1-on-c1 | 2026-10-13 12:12:32 | 1 | 59.4 | 40 checks, 1 fail (v1.89 row 1) | logs/M-frB-v200-u19-putback-promise-unkept-v189.c1-on-c1.log |
| M-vt2-vt2-swap-base-of-kept-U19.c1-on-c1 | 2026-10-13 12:13:03 | 1 | 177.7 | 104 checks, 1 fail ((f) 1) | logs/M-vt2-vt2-swap-base-of-kept-U19.c1-on-c1.log |
| M-frB-v200-u19-putback-question-unsaid-U19.c1-on-c1 | 2026-10-13 12:13:32 | 1 | 159.4 | 104 checks, 10 fail ((a) 2, (b) 1, (c) 1, (d) 1, (e) 1, (f) 1, (g) 1, (m) 1, (o) 1) | logs/M-frB-v200-u19-putback-question-unsaid-U19.c1-on-c1.log |
| M-vt2-vt2-question-by-store-U19.c1-on-c1 | 2026-10-13 12:16:01 | 1 | 138.0 | 104 checks, 1 fail ((m) 1) | logs/M-vt2-vt2-question-by-store-U19.c1-on-c1.log |
| M-frB-v200-u19-swap-status-names-saver-U19.c1-on-c1 | 2026-10-13 12:16:11 | 1 | 136.8 | 104 checks, 3 fail ((a) 1, (f) 1, (r) 1) | logs/M-frB-v200-u19-swap-status-names-saver-U19.c1-on-c1.log |
| M-vt2-vt2-cancel-swap-only-U19.c1-on-c1 | 2026-10-13 12:18:19 | 0 | 97.9 | 104 checks, 0 fail | logs/M-vt2-vt2-cancel-swap-only-U19.c1-on-c1.log |
| M-frB-v200-u19-swap-title-unsaved-U19.c1-on-c1 | 2026-10-13 12:18:28 | 1 | 92.8 | 104 checks, 4 fail ((a) 3, (r) 1) | logs/M-frB-v200-u19-swap-title-unsaved-U19.c1-on-c1.log |
| M-vt2-vt2-putsavedgen-init0-U19.c1-on-c1 | 2026-10-13 12:19:57 | 0 | 116.2 | 104 checks, 0 fail | logs/M-vt2-vt2-putsavedgen-init0-U19.c1-on-c1.log |
| M-frB-v200-u19-swap-menu-replaced-U19.c1-on-c1 | 2026-10-13 12:20:01 | 1 | 112.4 | 104 checks, 3 fail ((a) 1, (c) 1, (r) 1) | logs/M-frB-v200-u19-swap-menu-replaced-U19.c1-on-c1.log |
| M-frA-v200-u19-putback-folder-keeps-nothing-U19.c1-on-c1 | 2026-10-13 12:21:53 | 1 | 94.8 | 104 checks, 7 fail ((m) 4, (r) 3; 1 of them CONTROL rows) | logs/M-frA-v200-u19-putback-folder-keeps-nothing-U19.c1-on-c1.log |
| M-vt2-vt2-asput-ignores-edits-U19.c1-on-c1 | 2026-10-13 12:21:53 | 0 | 99.3 | 104 checks, 0 fail | logs/M-vt2-vt2-asput-ignores-edits-U19.c1-on-c1.log |
| M-frA-v200-u19-putback-folder-keeps-nothing-U2.c1-on-c1 | 2026-10-13 12:23:28 | 1 | 79.7 | 57 checks, 7 fail ((d) 1, (b) 2, (c) 2, (g) 2; 1 of them CONTROL rows) | logs/M-frA-v200-u19-putback-folder-keeps-nothing-U2.c1-on-c1.log |
| M-vt2-vt2-saved-always-U19.c1-on-c1 | 2026-10-13 12:23:32 | 1 | 96.1 | 104 checks, 1 fail ((f) 1) | logs/M-vt2-vt2-saved-always-U19.c1-on-c1.log |
| M-frA-v200-u19-putback-needs-handle-U19.c1-on-c1 | 2026-10-13 12:24:48 | 1 | 115.5 | 104 checks, 4 fail ((o) 4) | logs/M-frA-v200-u19-putback-needs-handle-U19.c1-on-c1.log |
| M-vt2-vt2-swap-saved-asput-only-U19.c1-on-c1 | 2026-10-13 12:25:09 | 1 | 125.5 | 104 checks, 2 fail ((f) 2) | logs/M-vt2-vt2-swap-saved-asput-only-U19.c1-on-c1.log |
| M-frA-v200-u19-putback-needs-handle-v189.c1-on-c1 | 2026-10-13 12:26:43 | 1 | 56.4 | 40 checks, 1 fail (v1.89 row 1) | logs/M-frA-v200-u19-putback-needs-handle-v189.c1-on-c1.log |
| M-vt2-vt2-cancel-status-reopen-U19.c1-on-c1 | 2026-10-13 12:27:14 | 1 | 167.2 | 104 checks, 2 fail ((p) 1, (q) 1) | logs/M-vt2-vt2-cancel-status-reopen-U19.c1-on-c1.log |
| M-frA-v200-u19-putback-again-unsaved-said-U19.c1-on-c1 | 2026-10-13 12:27:40 | 1 | 165.1 | 104 checks, 2 fail ((f) 2) | logs/M-frA-v200-u19-putback-again-unsaved-said-U19.c1-on-c1.log |
| M-vt2-vt2-question-kept-always-U19.c1-on-c1 | 2026-10-13 12:30:01 | 1 | 175.7 | 104 checks, 1 fail ((k) 1; 1 of them CONTROL rows) | logs/M-vt2-vt2-question-kept-always-U19.c1-on-c1.log |
| M-frA-v200-u19-putback-again-any-U19.c1-on-c1 | 2026-10-13 12:30:25 | 1 | 170.2 | 104 checks, 2 fail ((f) 2) | logs/M-frA-v200-u19-putback-again-any-U19.c1-on-c1.log |
| M-vy-vt2-keep-folder-unused-VY-on-c1 | 2026-10-13 12:33:07 | 1 | 61.6 | 13 checks, 4 fail ((VY-A) 3, (VY-E) 1) | logs/M-vy-vt2-keep-folder-unused-VY-on-c1.log |
| M-vy-vt2-cancel-swap-only-VY-on-c1 | 2026-10-13 12:34:09 | 1 | 54.6 | 13 checks, 2 fail ((VY-B) 1, (VY-E) 1) | logs/M-vy-vt2-cancel-swap-only-VY-on-c1.log |
| M-frA-v200-u19-swap-saved-forgotten-U19.c1-on-c1 | 2026-10-13 12:33:15 | 1 | 146.3 | 104 checks, 1 fail ((f) 1) | logs/M-frA-v200-u19-swap-saved-forgotten-U19.c1-on-c1.log |
| M-vy-vt2-putsavedgen-init0-VY-on-c1 | 2026-10-13 12:35:03 | 1 | 62.1 | 13 checks, 2 fail ((VY-C) 1, (VY-E) 1) | logs/M-vy-vt2-putsavedgen-init0-VY-on-c1.log |
| M-vy-vt2-asput-ignores-edits-VY-on-c1 | 2026-10-13 12:36:06 | 1 | 78.1 | 13 checks, 2 fail ((VY-D) 1, (VY-E) 1) | logs/M-vy-vt2-asput-ignores-edits-VY-on-c1.log |
| M-frA-v200-u19-cancel-says-reopen-U19.c1-on-c1 | 2026-10-13 12:35:42 | 1 | 188.4 | 104 checks, 2 fail ((p) 1, (q) 1) | logs/M-frA-v200-u19-cancel-says-reopen-U19.c1-on-c1.log |
| M-frA-v200-u19-swap-status-by-kept-U19.c1-on-c1 | 2026-10-13 12:38:50 | 1 | 160.0 | 104 checks, 2 fail ((a) 1, (r) 1; 1 of them CONTROL rows) | logs/M-frA-v200-u19-swap-status-by-kept-U19.c1-on-c1.log |
| S-r2-audit-recon-c1 | 2026-10-13 12:37:24 | 0 | 389.9 | ALL CHECKS PASSED | logs/S-r2-audit-recon-c1.log |
| S-r2-boot-same-c1 | 2026-10-13 12:43:54 | 0 | 49.1 | every page, source, save and error list is identical either way | logs/S-r2-boot-same-c1.log |
| M-frA-v200-u19-swap-title-any-kind-U19.c1-on-c1 | 2026-10-13 12:41:30 | 1 | 192.6 | 104 checks, 1 fail ((r) 1; 1 of them CONTROL rows) | logs/M-frA-v200-u19-swap-title-any-kind-U19.c1-on-c1.log |
| S-r2-audit-c1 | 2026-10-13 12:44:43 | 0 | 35.1 | ALL CHECKS PASSED | logs/S-r2-audit-c1.log |
| S-r2-audit-ppt-c1 | 2026-10-13 12:45:18 | 0 | 20.3 | ALL CHECKS PASSED | logs/S-r2-audit-ppt-c1.log |
| M-frA-v200-u19-swap-menu-any-kind-U19.c1-on-c1 | 2026-10-13 12:44:43 | 1 | 179.6 | 104 checks, 1 fail ((r) 1; 1 of them CONTROL rows) | logs/M-frA-v200-u19-swap-menu-any-kind-U19.c1-on-c1.log |
| S-r2-audit-other-c1 | 2026-10-13 12:45:38 | 0 | 126.0 | ALL CHECKS PASSED | logs/S-r2-audit-other-c1.log |
| S-r2-legacy-fsrc-c1 | 2026-10-13 12:47:45 | 0 | 14.3 |   every legacy Force setting computes exactly as before | logs/S-r2-legacy-fsrc-c1.log |
| M-frC-putback-drops-screen-U19.c1-on-c1 | 2026-10-13 12:47:43 | 1 | 191.0 | 104 checks, 5 fail ((f) 4, (j) 1; 1 of them CONTROL rows) | logs/M-frC-putback-drops-screen-U19.c1-on-c1.log |
| S-r2-audit-hostile-c1 | 2026-10-13 12:47:59 | 0 | 244.9 | ALL CHECKS PASSED | logs/S-r2-audit-hostile-c1.log |
| S-r2-audit-inject-c1 | 2026-10-13 12:52:04 | 0 | 59.3 | ========================================================================================== | logs/S-r2-audit-inject-c1.log |
| M-frC-putback-drops-screen-U2.c1-on-c1 | 2026-10-13 12:50:54 | 0 | 199.5 | 57 checks, 0 fail | logs/M-frC-putback-drops-screen-U2.c1-on-c1.log |
| M-frC-putback-drops-screen-v195kept.c1-on-c1 | 2026-10-13 12:54:13 | 0 | 57.8 | 10 checks, 0 fail | logs/M-frC-putback-drops-screen-v195kept.c1-on-c1.log |
| M-frC-v200-u2-putback-gen-U2.c1-on-c1 | 2026-10-13 12:55:11 | 1 | 158.9 | 57 checks, 1 fail ((d) 1) | logs/M-frC-v200-u2-putback-gen-U2.c1-on-c1.log |
| M-frC-v200-u2-putback-gen-U19.c1-on-c1 | 2026-10-13 12:57:50 | 0 | 155.5 | 104 checks, 0 fail | logs/M-frC-v200-u2-putback-gen-U19.c1-on-c1.log |
| M-frC-v200-u2-putback-while-saving-U2.c1-on-c1 | 2026-10-13 13:00:26 | 1 | 112.3 | 57 checks, 35 fail ((a) 4, (b) 5, (c) 5, (d) 4, (e) 4, (f) 4, (g) 5, (h) 4) | logs/M-frC-v200-u2-putback-while-saving-U2.c1-on-c1.log |
| M-frC-v200-u2-putback-while-saving-U19.c1-on-c1 | 2026-10-13 13:02:18 | 1 | 154.1 | 104 checks, 7 fail ((b) 7; 3 of them CONTROL rows) | logs/M-frC-v200-u2-putback-while-saving-U19.c1-on-c1.log |
| M-vt2-vt2-keep-folder-unused-v189.c1-on-c1 | 2026-10-13 13:05:11 | 0 | 74.7 | 40 checks, 0 fail | logs/M-vt2-vt2-keep-folder-unused-v189.c1-on-c1.log |
| M-vt2-vt2-keep-folder-unused-v195kept.c1-on-c1 | 2026-10-13 13:06:25 | 0 | 42.1 | 10 checks, 0 fail | logs/M-vt2-vt2-keep-folder-unused-v195kept.c1-on-c1.log |
| M-vt2-vt2-cancel-swap-only-U2.c1-on-c1 | 2026-10-13 13:07:08 | 0 | 150.1 | 57 checks, 0 fail | logs/M-vt2-vt2-cancel-swap-only-U2.c1-on-c1.log |
| M-vt2-vt2-cancel-swap-only-v189.c1-on-c1 | 2026-10-13 13:09:38 | 0 | 59.7 | 40 checks, 0 fail | logs/M-vt2-vt2-cancel-swap-only-v189.c1-on-c1.log |
| M-vt2-vt2-cancel-swap-only-v195kept.c1-on-c1 | 2026-10-13 13:10:37 | 0 | 41.0 | 10 checks, 0 fail | logs/M-vt2-vt2-cancel-swap-only-v195kept.c1-on-c1.log |
| S-r2-audit-recon-base | 2026-10-13 13:05:09 | 0 | 381.6 | ALL CHECKS PASSED | logs/S-r2-audit-recon-base.log |
| S-r2-boot-same-base | 2026-10-13 13:11:31 | 0 | 35.4 | every page, source, save and error list is identical either way | logs/S-r2-boot-same-base.log |
| S-r2-audit-base | 2026-10-13 13:12:06 | 0 | 29.9 | ALL CHECKS PASSED | logs/S-r2-audit-base.log |
| S-r2-audit-ppt-base | 2026-10-13 13:12:36 | 0 | 18.9 | ALL CHECKS PASSED | logs/S-r2-audit-ppt-base.log |
| M-vt2-vt2-putsavedgen-init0-U2.c1-on-c1 | 2026-10-13 13:11:18 | 0 | 127.9 | 57 checks, 0 fail | logs/M-vt2-vt2-putsavedgen-init0-U2.c1-on-c1.log |
| M-vt2-vt2-putsavedgen-init0-v189.c1-on-c1 | 2026-10-13 13:13:26 | 0 | 52.4 | 40 checks, 0 fail | logs/M-vt2-vt2-putsavedgen-init0-v189.c1-on-c1.log |
| S-r2-audit-other-base | 2026-10-13 13:12:55 | 0 | 104.8 | ALL CHECKS PASSED | logs/S-r2-audit-other-base.log |
| S-r2-legacy-fsrc-base | 2026-10-13 13:14:40 | 0 | 9.9 |   every legacy Force setting computes exactly as before | logs/S-r2-legacy-fsrc-base.log |
| M-vt2-vt2-putsavedgen-init0-v195kept.c1-on-c1 | 2026-10-13 13:14:19 | 0 | 36.8 | 10 checks, 0 fail | logs/M-vt2-vt2-putsavedgen-init0-v195kept.c1-on-c1.log |
| M-vt2-vt2-asput-ignores-edits-U2.c1-on-c1 | 2026-10-13 13:14:56 | 0 | 126.2 | 57 checks, 0 fail | logs/M-vt2-vt2-asput-ignores-edits-U2.c1-on-c1.log |
| S-r2-audit-hostile-base | 2026-10-13 13:14:50 | 0 | 170.5 | ALL CHECKS PASSED | logs/S-r2-audit-hostile-base.log |
| M-vt2-vt2-asput-ignores-edits-v189.c1-on-c1 | 2026-10-13 13:17:02 | 0 | 55.3 | 40 checks, 0 fail | logs/M-vt2-vt2-asput-ignores-edits-v189.c1-on-c1.log |
| S-r2-audit-inject-base | 2026-10-13 13:17:41 | 0 | 38.8 | ========================================================================================== | logs/S-r2-audit-inject-base.log |
| M-vt2-vt2-asput-ignores-edits-v195kept.c1-on-c1 | 2026-10-13 13:17:57 | 0 | 38.4 | 10 checks, 0 fail | logs/M-vt2-vt2-asput-ignores-edits-v195kept.c1-on-c1.log |
| S-r2-check-c1 | 2026-10-13 13:18:50 | 0 | 7.4 | all checks passed | logs/S-r2-check-c1.log |
| S-r2-check-base | 2026-10-13 13:18:58 | 0 | 5.7 | all checks passed | logs/S-r2-check-base.log |


## Appendix B. PIDs

Every bounded command of this review is in `pids.txt`, with the PID of its `timeout` and of its child, the time (ET) and the
command:
- lines 1–64 are the stopped attempt's;
- the rest are this attempt's.

Node runs went through `run.sh`, which checks the lock first and applies the 600 s cap. Text helpers (mkmut, mcount, mkvt2,
clone) went through `bx.sh`. I killed no process.

The lead's stop killed one run of the stopped attempt (`F-r1-U19.c1-on-base`, exit 137).
