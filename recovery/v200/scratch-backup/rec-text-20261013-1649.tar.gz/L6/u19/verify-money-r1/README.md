# U19 — independent adversarial verification, round 1, lens A (data loss and money)

Verifier's directory: `rec/L6/u19/verify-money-r1` (all paths below are relative to it unless absolute).
Started 13 Oct 2026, about 12:34 AM ET; stopped by the usage limit after the run that began 12:48:51 AM ET; resumed 4:12 AM ET;
this README written 4:40–4:42 AM ET. Nothing in `/home/user/orbit-board` or `/home/user/orbit-ui` was edited, staged,
committed or pushed. `tools/export-audit/mutate.mjs` was never imported or run: mutants were built from `mutate.mjs.txt`
as text with `rec/bin/mkmut.py` (`python3 -I`).

## Verdict

**unsound as built — one must-fix data-loss route (M1) and one must-fix false sentence (M2).** The builder's claims that I
checked all hold (table below): the five named routes are closed, the controls are unchanged, the three changed
expectations are the only ones and are listed, the six mutations are caught with the counts claimed. But the fix decides
whether to keep what is on screen from where 💾 Save goes *at the moment of the put-back* (`!driveStoreOn()`), and the
Live view's own switch ("● Working out of this folder" / "○ Just watching" — the board's comment calls it "THE SWITCH THAT
MOVES WHERE SAVE GOES") can move Save between the put-back and the Save. Then S1 is again written over with no copy this
board can reach — the U19 loss itself, on a sixth route. A one-clause correction (built here as `vc2`, not for commit)
closes it and keeps every builder check passing.

## Copies (blob = `git hash-object`)

| copy | board | audit-import | mutate.mjs.txt | note |
|---|---|---|---|---|
| `vbase` = `rec/L6/base` | fce8a391bd8a… | 4aba2506a7ea… | cbc6defc6803… | read-only base (7ee498a; product d66dd60) |
| `vc1` = builder's `c1` | 8cf14d7e6baf8fa6f590e3082a2ed429458c3490 | a1a3e32c67ca632ce9fb5e8f69ddae5f7881d3e4 | 67ec010fe747ce2c1fb02987f19a1a4f48429aac | byte-identical to `rec/L6/u19/c1` |
| `vc2` = vc1 + verifier's sketch | 608df876f309098837c2990ef4581f143c0bcf1e | a1a3e32c (same) | 67ec010f (same) | M1 correction only, NOT for commit |

audit-board a7c575e5, audit-recon 529e36f7, audit-other d89396b0 are unchanged in all three.

Diffs (each reproduced from the copies with `diff -u`): `diffs/prioritization-board-grid.html.diff` (fbfcfa39, vbase→vc1,
18 added / 6 removed), `diffs/audit-import.mjs.diff` (6d67a515), `diffs/mutate.mjs.txt.diff` (1aae4a90),
`diffs/vc2-sketch-board.diff` (8286e1a9, vc1→vc2).

The vc2 sketch, the whole change:

```diff
-  const keepScreen=nowUnsaved || !driveStoreOn();
+  // VERIFIER'S SKETCH (not for commit): the folder's history holds what is on screen only if it IS the folder's copy -- the
+  // store can be on now and off at the Save, and a copy saved only in the board file is then written over with none kept.
+  const keepScreen=nowUnsaved || !driveStoreOn() || driveBaseOf(mySlug())!==(+MS.ts||0);
```

(`driveBaseOf(ap)` is the time of the folder copy the work on screen was last loaded from or written to; a folder save sets
it to `wroteTs` = `MS.ts`, a folder load sets it to the copy's `store.ts` and applies that store. So equality means "what is
on screen is the shared folder's own copy, which the folder's history keeps when Save replaces it". Anything else is kept.
It only ever adds a keep; it never removes one.)

## Harnesses and helpers

- `bin/run.sh` (6e947210): one run, `setsid -w timeout -k 10 600`, waits for `AUDIT_IMPORT_RUNNING` (20 s polls, 30 min),
  records start ET, exit, wall seconds and both PIDs. `bin/frun.sh` (86d54df3), `bin/mrun.sh` (f5aa6886, mutant = `BOARD`
  set to `mut/<id>.html`), `bin/bx.sh` (89af9680, bounded non-node commands), `bin/runner.mjs` (f720ce18), `bin/tally.py`.
- Focused harnesses cut VERBATIM from the copy's own audit-import with `bin/mkfocused-u2.py` (252c00ef; the L2 tool, block
  range only): `U19.vc1` (7e20c582), `U2.vbase` (32cc5ac7), `U2.vc1` (a1edf6a8), `v189.vbase` (ed54e613), `v189.vc1`
  (49261f6a), `v195kept` (f2adbb73, identical text on both). Every audit-import line that calls `keptPutBack` or clicks
  `.keptbtn` (L3511, L4039, L7184–L7329, L7842–L7949) lies inside one of these.
- My probe: `probe/vblock.mjs.txt` (247b3936) inserted after the U19 end marker (`bin/mkprobe.py`), cut as `h/src/VP4.mjs`
  (b0018bec). Expected values are hand-written literals from principles 1 and 4; rows named "(observed)" record text and
  always "fail" by design. `VP.mjs`/`VP3.mjs` are earlier versions (VP3 never run, superseded by VP4).
- Mutants (`mut/`, built by mkmut.py from vc1's `mutate.mjs.txt`, each diff checked to be the single intended line):
  putback-drops-screen 54373179, v200-u19-putback-keeps-nothing-saved cbd88dc6, -putback-promise-unkept acb9d348,
  -putback-question-unsaid d4a756aa, -swap-menu-replaced 8b195f25, -swap-status-names-saver 1107a7a0, -swap-title-unsaved 9fefcad9.

## Every run (all node runs through `bin/run.sh`; lock never present; none timed out)

| label | start ET | exit | wall s | result | log |
|---|---|---|---|---|---|
| F-r1-U19.vc1-on-vbase | 12:36:45 AM | 1 | 85.7 | 71 checks, 34 fail (a 8, b 4, c 5, d 4, e 4, f 5, g 3, h 1), 0 CONTROL | logs/F-r1-U19.vc1-on-vbase.log |
| F-r1-U19.vc1-on-vc1 | 12:38:11 AM | 0 | 78.8 | 71/71 | logs/F-r1-U19.vc1-on-vc1.log |
| F-p1-VP-on-vbase / -on-vc1 | 12:41:30 / 12:42:03 AM | 1 / 1 | 33.4 / 41.2 | probe v1 (V4 harness threw on vc1: fixed in v2) | logs/F-p1-VP-*.log |
| F-p2-VP-on-vbase / -on-vc1 | 12:43:18 / 12:44:10 AM | 1 / 1 | 52.0 / 39.9 | probe v2 (same findings as v4 for V1–V4) | logs/F-p2-VP-*.log |
| F-r1-U2.vbase-on-vbase | 12:45:38 AM | 0 | 103.5 | 57/57 | logs/F-r1-U2.vbase-on-vbase.log |
| F-r1-U2.vc1-on-vc1 | 12:47:21 AM | 0 | 89.2 | 57/57 | logs/F-r1-U2.vc1-on-vc1.log |
| F-r1-U2.vbase-on-vc1 | 12:48:51 AM | — | — | INCOMPLETE: cut off by the usage limit (no end record; PIDs 32224/32230 not alive at 4:13 AM). Re-run as F-r2 below | logs/F-r1-U2.vbase-on-vc1.log |
| F-r2-U2.vbase-on-vc1 | 4:18:17 AM | 1 | 54.1 | 55/57: case (d) "put back again" got `[1,"K",true,true,true,"S1"]`, reopen `["K","S1",…]` | logs/F-r2-U2.vbase-on-vc1.log |
| F-r2-U2.vc1-on-vbase | 4:19:11 AM | 1 | 51.8 | 55/57: the same two rows, `null` and `["S1","K",…]` | logs/F-r2-U2.vc1-on-vbase.log |
| F-r2-v189.vc1-on-vc1 | 4:20:11 AM | 0 | 28.0 | 40/40 | logs/F-r2-v189.vc1-on-vc1.log |
| F-r2-v189.vc1-on-vbase | 4:20:39 AM | 1 | 26.5 | 39/40: "the file is newer / one click puts it back…" got `BRAD NOTE||false` | logs/F-r2-v189.vc1-on-vbase.log |
| F-r2-v189.vbase-on-vc1 | 4:21:06 AM | 1 | 25.9 | 39/40: "one click puts it back" got `BRAD NOTE||false` | logs/F-r2-v189.vbase-on-vc1.log |
| F-r2-v195kept.vc1-on-vc1 | 4:21:40 AM | 0 | 20.8 | 10/10 | logs/F-r2-v195kept.vc1-on-vc1.log |
| F-p4-VP4-on-vbase | 4:22:01 AM | 1 | 31.3 | 16 fail: V1 ×2, V3 (S1 lost), V4 (nothing to export), V6 setup, observe rows | logs/F-p4-VP4-on-vbase.log |
| F-p4-VP4-on-vc1 | 4:22:32 AM | 1 | 29.1 | **V1 ×2 (S1 lost), V6 (false question)**, V2a/V2b header rows, observe rows | logs/F-p4-VP4-on-vc1.log |
| F-p4-VP4-on-vc2 | 4:24:15 AM | 1 | 50.5 | **V1 passes** (only its setup "record" row differs: S1 now kept); V6 still fails; V2/observe rows as vc1 | logs/F-p4-VP4-on-vc2.log |
| F-r2-U19.vc1-on-vc2 | 4:25:05 AM | 0 | 63.8 | 71/71 | logs/F-r2-U19.vc1-on-vc2.log |
| F-r2-U2.vc1-on-vc2 | 4:26:09 AM | 0 | 77.8 | 57/57 | logs/F-r2-U2.vc1-on-vc2.log |
| F-r2-v189.vc1-on-vc2 | 4:27:27 AM | 0 | 34.2 | 40/40 | logs/F-r2-v189.vc1-on-vc2.log |
| F-r2-v195kept.vc1-on-vc2 | 4:28:02 AM | 0 | 22.2 | 10/10 | logs/F-r2-v195kept.vc1-on-vc2.log |
| M-U19.vc1-v200-u19-putback-keeps-nothing-saved | 4:29:37 AM | 1 | 40.6 | caught, 34 fail | logs/M-U19.vc1-*.log |
| M-U19.vc1-v200-u19-putback-promise-unkept | 4:30:18 AM | 1 | 43.7 | caught, 27 | 〃 |
| M-U19.vc1-v200-u19-putback-question-unsaid | 4:31:02 AM | 1 | 48.4 | caught, 8 | 〃 |
| M-U19.vc1-v200-u19-swap-status-names-saver | 4:31:50 AM | 1 | 48.1 | caught, 2 | 〃 |
| M-U19.vc1-v200-u19-swap-title-unsaved | 4:32:39 AM | 1 | 46.1 | caught, 3 | 〃 |
| M-U19.vc1-v200-u19-swap-menu-replaced | 4:33:25 AM | 1 | 48.1 | caught, 2 | 〃 |
| M-U19.vc1-putback-drops-screen | 4:34:14 AM | 1 | 49.6 | caught, 2 (scenario (f) + the (j) CONTROL) | 〃 |
| M-v195kept.vc1-putback-drops-screen | 4:38:31 AM | 0 | 40.2 | 10/10 — confirms the builder's coverage shift (v1.95 block no longer catches it) | logs/M-v195kept.vc1-putback-drops-screen.log |

mcount (text only, `out/mcount/`): vc1 1334 entries, 1334 match exactly once; vbase 1328/1328.
PIDs: every run's wrapper and node PID, with command, in `pids.txt` (116 lines). I killed nothing.

## Findings

### M1 — MUST FIX (data loss, principle 1): the Live view's Save switch moved between put-back and Save
Route (VP4 "V1", file mode): the opening keeps K aside; S1 is typed and saved into the board file. 📡 Live view → switch to
"● Working out of this folder" (an empty folder, or any folder that does not hold S1). ↶ Put back: one question,
"…still in the saved file it came from, and 💾 Save will ask before writing over that." — no "also kept aside"; nothing is
kept (observed `[1,"U19-K-KEPTWORK",null]`). Switch back to "○ Just watching" (the button calls `liveSet("store",false)`).
💾 Save: one HOLD ON; OK writes K into the board file (observed `[1,true,"U19-K-KEPTWORK"]`). S1 is then in no byte of
browser storage, the kept slot, the board file, the folder or its history — after the Save and after a reopen (both rows
`false` on vbase AND vc1). The finding's own bar ("a later Save that writes K cannot leave S1 nowhere") is not met.
Control V1b (switch left on, Save writes the folder): S1 stays in the board file — passes on both.
Minimal fix: the vc2 clause above. Verified: V1 passes on vc2; U19 71/71, U2 57/57, v1.89 40/40, v1.95 10/10 unchanged on vc2.
Needed with it: a V1 scenario in the U19 block (fails on c1, passes fixed); a mutation that drops the new clause; the find
of `v200-u19-putback-keeps-nothing-saved` updated (its line changes); the code comment and the drafts reworded — "when 💾 Save
writes to a board file" is decided at the put-back, so say "unless what is on screen is the shared folder's own copy".

### M2 — MUST FIX (principle 4, a false sentence the change makes reachable; no copy lost)
Route (VP4 "V6", file mode, S1 saved): ↶ Put back K (S1 kept), ↶ Put back S1 (K kept), ↶ Put back again. Before the third
press S1 on screen is the board file's copy (observed `true`), yet the question says "What is on screen now has changes no
saved copy has, so it is kept aside in its place — nothing is lost." and the header says "Unsaved changes · ↶ work kept
aside". On vbase this route cannot arise (nothing is kept after the first put-back). The builder's scenario (f) stops one
press short. Minimal fix (not built): record on the 'swap' meta whether what was kept was saved (`saved:!nowUnsaved`); after
putting back such a copy remember `_saveGen` (every edit moves it through save()); while it has not moved, use a sentence
true either way, e.g. "What is on screen now was put back and has not been saved since, so it is kept aside in its place —
nothing is lost." Keep the existing sentence otherwise, so the (j) CONTROL's words are unchanged. Add the third press to
scenario (f) and a mutation for it.

### Should fix
- S1. Drafts overclaim while M1 stands: NEXT-VERSION "when 💾 Save writes to a board file, what is on screen is kept
  aside…", "The shared folder is unchanged"; Unresolved bullet "Save's HOLD ON answered OK no longer leaves it in no copy
  this board can reach"; ledger "whenever 💾 Save writes to a board file (`!driveStoreOn()`)". And the builder's
  "three lines … reworded because otherwise they would become false" misses M2.
- S2. Reopen before any Save (U19 (g), my V2a): the kept-occupied message names S1 twice as two different things — "Alice
  saved a newer copy to the saved file (…) [= S1, not loaded], but this browser already keeps earlier work aside (kept …)
  [= S1 itself] and holds new work besides". All copies survive; the words are confusing at best. Lead/Brad to word it.
- S3. The 'swap' copy now lingers after every board-file put-back until put back, saved as a file or discarded. While it
  is kept, every newer copy that would need unsaved work kept aside is refused (opening, sidecar, folder), and the next
  💾 Save asks HOLD ON over that newer copy (OK leaves it only in Teams version history). VP4 "V3": vbase opens N2 and keeps
  K2 (but S1 is already lost); vc1 keeps K2 on screen, S1 kept, N2 in the file, not loaded — nothing lost at the reopen.
  "What users may see" mentions the refusal, not the HOLD ON that follows it.
- S4. The "Saved <time>" header on a reopen with unsaved work is NOT specific to this route: my V2b control (ordinary
  editing, no put-back, reopen before Save) shows the same header with the record unsaved on the BASE board (board text
  "Saved 8:22 AM", the jsdom harness's UTC clock = 4:22 AM ET). It is a pre-existing defect for its own ledger row, not a
  U19 open point.
- S5. V6's header "Unsaved changes" with S1 identical to the file (U2's rule: a put-back counts as a change) — newly
  reachable; the lead to decide whether that stays.

### Minor
- VP4 "V5": ↶ Put back pressed with a locked cycle on screen still asks its question first — now adding "It is also kept
  aside in its place" — and then the view refuses ("Loading a board is off while PB27 is on screen…"). K is kept byte for
  byte and no locked-view copy is kept (verified on both boards). Pre-existing order; a `cycBlock` before the question would
  keep the promise out of it.
- `keptWhere(k.meta)` says "still in the shared folder it came from" for a copy kept from the folder even when what is on
  screen was saved only to the board file (pre-existing; with M1's fix it is joined by "It is also kept aside").
- The new comment's "No room to keep it: nothing is changed, as before" — "as before" is true only for unsaved work; a
  saved screen used to be put back without room (the drafts do disclose this).

## What I checked and found true
U19 block 34/71 fail on the base (all in (a)–(h), 0 CONTROL), 71/71 on c1; the three changed expectations are the only
edits outside the new block and each fails on the other board (U2 case (d) 2 rows, v1.89 1 row); U2 case (c) unchanged; all
six new mutants caught with the builder's counts; `putback-drops-screen` still caught by U19 (2) and no longer by v1.95
(0); mutation entries are `{id, area, what, find, repl}`, before the R3 line, areas name the enclosing functions
(keptPutBack, saveStateShow, syncBtns); mcount 1334/1334. Money/exports (VP4 "V4", vc1): ⬇ Save work kept aside as a file
after the U19 route exports a board file whose years and data pack equal S1's own save exactly and whose asks equal
(appns.om present in both, so the comparison is not vacuous). No money computation is touched by the diff. All keepAside
callers treat 'occupied' as "not loaded" (L6465, L8456, L26825, L27009, L27152), so the lingering slot loses nothing silently.

## Not done
- Full audit-import / audit-board runs and the mutation sweep (the lead's); mutate.mjs never executed.
- Other suites (audit, audit-ppt, audit-other, audit-recon, legacy-fsrc, audit-hostile, audit-inject, boot-same) and
  `npm run check` were not re-run by me (the builder reports them; none calls `keptPutBack`).
- No Chromium/Playwright; no scratch git clone (no suite needing git was run).
- M2's fix was not built; the vc2 sketch has no test block, mutation or wording change of its own.
- Read-only inspection commands (cat, grep, sed, ls, ps, free, uptime, cmp, git hash-object, `python3 -I bin/tally.py`)
  and small file writes ran without the setsid/timeout wrapper; every node run and every copy/mutant build was bounded.
- A real browser's second tab (U20) and real Teams/disk version history were not tested.
