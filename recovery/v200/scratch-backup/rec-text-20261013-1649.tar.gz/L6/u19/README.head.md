# U19 builder: ↶ Put back after a board-file save keeps what it replaces

**Track U19, ORBIT v2.00 release.** One commit is proposed: `c1/` = the read-only base (`rec/L6/base`, git archive of
orbit-board `7ee498a`, product `d66dd60`) plus that commit. Nothing was committed, staged or pushed anywhere, and nothing
in `/home/user/orbit-board` or `/home/user/orbit-ui` was edited. Every time below is Eastern, read from
`TZ=America/New_York date`.

This session resumed the track at 7:31 PM ET on 12 Oct. An earlier builder had been stopped at about 6:16 PM ET by a usage
limit. This README was written from 7:50 PM ET.

## 1. In short

- **The defect is reproduced on the base.** The earlier builder's probe runs on `rec/L6/base` give 77 pass and 4 fail,
  and the 4 fails are the four U19 PROPERTY rows. The checker's variants give 66 pass and 18 fail, all U19 rows plus the two
  refuted H0 calibration rows, the same shape as the L4 triage. The checker's pen route (two writer keys) is new here. On
  the base it reproduces U19 too (§8).
- **The fix (board).** `keptPutBack` now keeps what is on screen aside in the kept work's place whenever 💾 Save writes to a
  board file (`!driveStoreOn()`), saved or not, as unsaved work always was. The question says so. The words for a copy
  kept at a put-back (`why:'swap'`) no longer call it unsaved work or work a saved copy replaced: the top bar's button
  title, the 📁 File line and the put-back status. The shared folder is unchanged. 18 lines are added and 6 removed.
- **The tests (audit-import).** The new block "v2.00 (U19)" sits right after the U13 block's end marker. It has 71 checks
  over five routes (file-after, file-retry, ui-after, picker-after, pen-after), three edge cases and four controls.
  - On the base, 34 checks fail, all in the eight changed scenarios. Every CONTROL row passes.
  - On c1, all 71 pass.
  - **Three existing expectations change** (§5), each shown failing on one board and passing on the other.
- **Mutations.** Six new entries are in the `mutate.mjs` text, and each is caught by the focused block (§7). mcount (text
  only) gives c1 1334 of 1334 entries matching exactly once, and the base 1328 of 1328.
- **The other suites.** On c1, every suite this track may run passes: boot-same, audit, audit-ppt, audit-other, audit-recon,
  legacy-fsrc, audit-hostile and audit-inject, and `npm run check` (all checks passed). The base runs are in §9.
- **Not run (the lead's):** the full audit-import and audit-board. No Chromium or Playwright was run.

## 2. What I kept from the earlier attempt, and what I re-ran

I read everything in this directory first. The lead had confirmed at 7:30 PM ET that none of the earlier processes was
still running. Every earlier run in `logs/runs.txt` has an exit record: 29 runs, from 5:59:56 PM to 6:17:40 PM ET.

**Kept, after re-checking:**
- **The base reproduction** (`out/probe-base/`, `logs/p-base-*`, `x-base-*`, `chk-base`, `xchk-base*`, all exit 0).
  - The probe `probe/u19probe.mjs` (`80b848ab`) and `probe/x19.mjs` (`cbca9776`) are byte-identical to the L4 originals.
  - `probe/check.mjs` and `probe/xcheck.mjs` differ from theirs in the board-blob literal only: L4's `98eed7e8` became the
    L6 base `fce8a391`. I checked this with `diff`.
  - Results: 77 pass / 4 fail, and 66 pass / 18 fail (§1).
- **The board change** (`bin/edit-board.py`). `recheck/recheck.sh` rebuilt the board from the read-only base with it, and
  the result is byte-identical to the earlier `c1/prioritization-board-grid.html` (`8cf14d7e`). I reviewed it against the
  proposal and the checker's notes (§3), and kept it unchanged.
- **The suite edit script** (`bin/edit-import.py`): the block insertion after the U13 end marker, and the three changed
  expectations. The rebuild matched the earlier c1 audit-import (`0ad25df2`) byte for byte. I kept the script unchanged.
- **The harness tools.**
  - `bin/mkfocused-u2.py` is byte-identical to `rec/L2/u2impl/mkfocused-u2.py`.
  - `bin/runner.mjs` is byte-identical to `rec/L2/u2impl/runner.mjs`.
  - The run wrappers are `run.sh`, `bx.sh`, `mk-harness.sh` and `focused-runs.sh`.
  - The rebuilt base harnesses are byte-identical to the earlier ones.

**Changed or added by me:**
- **The suite block.** It is now `v2/block-u19.v2.mjs.txt`, made from the earlier `block-u19.mjs.txt` by `v2/mkblock2.py`
  (text only). I added the pen route as case (e), with distinct writer keys and ✍ Take the pen both ways, because the
  checker found the same-key fixture an unlisted shortcut (CHECK §9.2). Cases (e)–(k) became (f)–(l), and the header names
  the new route. Nothing else changed.
- **c1 was rebuilt from the base** by `v2/build-c1.sh`, using the board script, the import script with the new block, and
  the new `bin/edit-mutate.py` (the six mutation entries). The earlier c1 had no mutation entries.
- **New items:** diffs, mcount, every mutant run, the suites, the pen probe, the drafts and this README.

**Re-run rather than trusted:** every focused run (the earlier r1 set was against the older block), as tag r2 on the
current blobs.

## 3. The drafted proposal, evaluated against the checker's notes

The L4 PROPOSAL keys the keep on `nowUnsaved || !driveStoreOn()`. That is the right test: it is exactly "Save does not
write to the shared folder", the one place that keeps the copy a save replaces. I kept it. For each of the checker's
points (CHECK §5, §8, §9):

| checker's point | decision | why |
|---|---|---|
| It fixes the kept-slot side: S1's whole state, its journal included, goes into the kept slot. | kept | Principle 1: S1 is reachable after the Save and after a reopen. This is measured on five routes. |
| The file's Change journal after K's Save keeps no trace of S1. | not changed; said under "Not covered" | S1 and its journal are whole in the kept copy, so nothing is lost. Writing S1 into K's journal would be a new design: it would guess (principle 2) and grow the change (principle 5). |
| Risk 1: a sticky kept slot; a reopen before any Save takes the "occupied" path. | measured (case (g)) and accepted | The reopen keeps K on screen (unsaved), with S1 kept and in the file, and says "… the newer copy was not loaded and nothing was lost". Every word holds: S1 is newer than the copy K came from, the kept work is never replaced, and nothing was lost. It refuses rather than guesses (principle 2). |
| Risk 3: no room to keep S1, so the put-back is refused. | measured (case (h)) and accepted | It fails safe through the existing "There is no room … nothing was changed" path. Nothing on screen or kept moves (principle 1). |
| Risk 5: `!driveStoreOn()` also holds with no file handle (the picker) and with a download-only browser. | measured (picker, case (d)); download-only by code | Keeping a copy aside is harmless there, and the words claim only "kept aside". |
| The proposal's question wording: "saved in the file, and also kept aside … if 💾 Save writes over the file". | the earlier builder's wording kept instead | The base sentence stays as it was ("still in the saved file it came from, and 💾 Save will ask before writing over that.") and one sentence is added: "It is also kept aside in its place, so it is not lost if Save does." That is the smallest true change (principles 4 and 5). |
| Words for the copy kept at a put-back (not in the proposal). | changed (the earlier builder's) | Principle 4: after the fix, the old words become false on reachable routes (below). |
| The HOLD ON calls her own save "their changes" (O1), and the status's "which Bob saved after it" is stale after a take-the-pen (§9.3.1). | not changed; listed | The fix makes neither false or truer, and the lead's brief says the HOLD ON words stay as they are. These are wording points for Brad. |

**Why the three wording edits are needed, not optional (principle 4).** Each old line would say something untrue on a
route the fix opens or makes common.
- **The top bar's title** said "Work this browser held that no saved copy had". After the fix, a copy kept at a put-back can
  be S1 while S1 is still the file's copy, so the line would be false at once. On the base, a swap copy was always unsaved.
- **The put-back status for a swap copy** said "💾 Save will ask before it writes over the saved file, which Alice saved
  after it". Case (f) (K put back, then S1 put back before any Save) shows nobody saved after S1's copy and Save asks
  nothing. The new words state the rule Save follows, which holds either way. By code, the old words were already false on
  the base's unsaved-swap route; that was not measured.
- **The 📁 File line** said "from before the saved file replaced it". No saved copy replaces a copy kept at a put-back.

Only the swap kind gets new words; the words for 'file', 'folder' and 'sidecar' kept copies are unchanged.

## 4. How the change meets each decision principle

1. **Never lose any copy.** After the put-back, the Save with OK and a reopen, S1 is kept aside on every file route: (a),
   (b), (c), (d) and (e). K is on screen and in the file. Putting S1 back keeps K in its place (cases (a) and (f)). No copy
   is dropped anywhere: when there is no room, nothing changes (h).
2. **Refuse or ask rather than guess.** Nothing is merged or chosen silently.
   - The HOLD ON still asks.
   - A reopen before any Save refuses to load over the kept work and says so (g).
   - When there is no room, the put-back is refused and said (h).
3. **Money and exports.** None is touched. The board's money paths, exports and the export suites are unchanged, and pass
   on c1: audit, audit-ppt, audit-other, audit-recon, boot-same and legacy-fsrc.
4. **Every word stays true after the operation lands.** The question now says S1 is also kept aside. The top bar, 📁 File
   and the status say what a swap copy is, and what Save will do. The HOLD ON's words are unchanged and still true: her
   file copy is overwritten, and it is not on screen. Each new word is checked by literal, and each has a mutation.
5. **Smallest change.** One condition (`keepScreen`) replaces `nowUnsaved` at the keep, plus one added sentence and three
   swap-only wording branches. There is no new state, storage key or path.
6. **Existing checks preserved.** Three existing expectations change, because each encoded the defect: a put-back of
   file-saved work kept nothing. They are listed in §5 with file:line, old, new and why. Every other existing check in
   the blocks that drive this function passes unchanged on c1:
   - the rest of v1.89;
   - both U2 blocks, including "work put back during a save stays unsaved" case (c);
   - the v1.95 "work kept aside is never replaced" block;
   - every suite run in §9.

## 5. Existing expectations changed (never silently)

Line numbers are the base `audit-import.mjs` (`4aba2506`) and c1's (`a1a3e32c`).

| # | where (base → c1) | old | new | why |
|---|---|---|---|---|
| 1 | v1.89 "saving never silently overwrites somebody's work", scenario "the file is newer": base L3512 → c1 L3512–3514 (one comment line added) | check "one click puts it back", got `note A|note B|String(kept===null)`, want `'BRAD NOTE||true'` (nothing kept after the put-back) | check "one click puts it back, and what was on screen (the colleague's copy, saved only in the file) is kept aside in its place", got `note A|note B|String(/COLLEAGUE NOTE/ in kept && !/BRAD NOTE/ in kept)`, want `'BRAD NOTE||true'` (literal unchanged) | This is the U19 shape itself. The colleague's copy is saved only in the board file, and the next Save with OK would write Brad's work over it. It is now kept aside. |
| 2 | "v2.00 (U2) — put back waits for a save to finish", the `retry` helper's comment: base L7325–7326 → c1 L7327–7328 | "… kept in its place if no saved copy has it (`was`: null when S1 is saved)." | "… if no saved copy has it, or if it is saved only in a board file (v2.00, U19) (`was`: null when S1 is saved in the folder)." | Comment only; no check changes. |
| 3a | same block, case (d) "the board file: put back while S1's save writes; the save goes in": base L7396–7397 → c1 L7398–7401 (two comment lines added) | "put back again: one question; K on screen, unsaved; nothing kept in its place (S1 is saved)", want `[1,'K',true,true,true,null]` | "put back again: one question; K on screen, unsaved; S1 kept aside in its place (saved only in the board file: v2.00, U19)", want `[1,'K',true,true,true,'S1']` | This is the route the lead's brief names (~L7396). S1 is saved only in the file, so it is now kept aside. |
| 3b | same case: base L7398 → c1 L7402 | `await afterFile(A, f, sc, ['S1', 'K'])`: reopened, S1 on screen and K kept | `await afterFile(A, f, sc, ['K', 'S1'])`: reopened, K on screen and S1 kept | This is the reopen before any Save with S1 kept (risk 1, measured in U19 case (g)). The file's newer copy is the very copy kept aside, so it is not loaded over K. Both are still each in a copy (the check's other two values, `true,true`, are unchanged). |

**Each shown both ways** (focused harnesses, §6):
- **c1's expectations on the base fail exactly there:** v189.c1 on base 1 fail (row 1), U2.c1 on base 2 fail (3a, 3b).
- **The base's expectations on c1 fail exactly there:** v189.base on c1 1 fail, U2.base on c1 2 fail.
- **Each set passes on its own board:** v189 40/40, U2 57/57.

**Observed differently, no expectation changed.** "v2.00 (U2) — work put back during a save stays unsaved", case (c),
around base L7228–7244. When U2 refuses the put-back during the save, the case puts back afterwards with S1 saved. On c1,
S1 is then also kept aside, but the case checks only that K is written, and it passes unchanged.

