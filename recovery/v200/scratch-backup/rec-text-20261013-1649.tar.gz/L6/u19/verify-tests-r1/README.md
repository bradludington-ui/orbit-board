# U19 verifier, round 1, lens B (test adequacy and regressions)

Independent check of the U19 builder's result (`rec/L6/u19`, board `8cf14d7e`, audit-import `a1a3e32c`, mutate `67ec010f`).
I worked only in this directory, on my own copies. Nothing was committed, staged or pushed. Nothing in `/home/user/orbit-board`
or `/home/user/orbit-ui` was edited; the two scratch clones in `git/` are `--shared` and were never committed in. The builder's
files were only read. Every time is Eastern, from `TZ=America/New_York date`. This session started at 4:43 AM ET on 13 Oct.
No earlier work existed in this directory, so nothing was resumed. This README was written at about 5:37 AM ET.

**Verdict: sound, with issues.** The fix closes the data loss on every route I drove, including one the builder's block does
not drive. Every builder number reproduced exactly: same counts, and the same failing rows. One issue must be fixed first
(§4.1): on the U19 route the commit makes the HOLD ON's Cancel advice false. The lead's brief requires those words to stay true.

## 1. Identities

- **My copies.** `base/` is `cp -a` of `rec/L6/base`. `c1/` is rebuilt from it by `bin/build.sh`, using the builder's three
  edit scripts and block, copied here unchanged. `diff -rq` against the builder's `c1/` is **IDENTICAL**.
- **Blobs.** Board `fce8a391` → `8cf14d7e`; audit-import `4aba2506` → `a1a3e32c`; mutate.mjs.txt `cbc6defc` → `67ec010f`.
  audit-recon `529e36f7`, audit-board `a7c575e5` and audit-other `d89396b0` are unchanged.
- **Diffs** (`diffs/`). Each is byte-identical to the builder's, after the two header lines.
  - Board: +18 −6.
  - audit-import: +299 −5.
  - mutate: +19.
- **Harnesses.** Built by `bin/mkfocused-u2.py`; each matches the builder's blob: U19.c1 `7e20c582`, U2.c1 `a1edf6a8`,
  U2.base `32cc5ac7`, v189.c1 `49261f6a`, v189.base `ed54e613`, v195kept `f2adbb73` (both suites).
- **Mutant boards** (`mut/blobs.txt`). The builder's 6 and the 3 existing ones each match the builder's blob.
- **Probes** (`probe/`). Each is byte-identical to the builder's.

## 2. Re-runs of everything the builder reports (all compared row by row)

| what | mine | builder | same failing rows |
|---|---|---|---|
| U19 block on base | 34 / 71 fail, 0 CONTROL | 34 / 71 | yes |
| U19 block on c1 | 0 / 71 | 0 / 71 | yes |
| U2 c1-on-base, base-on-c1 | 2 / 57 each, case (d) | 2 each | yes |
| U2 own board, both | 0 / 57 | 0 | yes |
| v189 crossed, both | 1 / 40 each | 1 each | yes |
| v189 own board, both | 0 / 40 | 0 | yes |
| v195kept, both | 0 / 10 | 0 | yes |
| 6 new mutants on U19 | 34, 27, 8, 2, 3, 2 | same | yes |
| keeps-nothing / promise-unkept on U2, v189 | 2, 1 / 2, 1 | same | yes |
| putback-drops-screen on c1: U19, U2, v195kept, v189 | 2, 7, **0**, 0 | same | yes |
| putback-drops-screen on base: U2, v195kept, v189 | 11, 1, 0 | same | yes |
| v200-u2-putback-gen on c1: U2, U19 | 1, 0 | same | yes |
| v200-u2-putback-while-saving on c1: U2, U19 | 35, 7 | same | yes |
| probes, base: check / xcheck / xcheck-pen | 77/4, 66/18, 73/4 | same | yes |
| probes, c1: check / xcheck / xcheck-pen | 70/11, 56/28, 69/8 | same | yes |
| mcount (text only): c1 | 1334 / 1334 once | same | — |
| mcount: base | 1328 / 1328 | same | — |
| mcount: c1 text on base | 1328, the 6 new missing | same | — |
| mcount: base text on c1 | 1328 / 1328 | — | — |

**Suites, scratch clones at 7ee498a** (`git/base`, and `git/c1` with c1's board and audit-import). I ran boot-same, audit,
audit-ppt, audit-other, audit-recon, legacy-fsrc, audit-hostile, audit-inject and npm run check. **Every one passes, exit 0,
on both** (`out/suites-summary.txt`). I did not run audit-import or audit-board.

## 3. Test adequacy

- **Literals.** All 43 chk call sites in the new block take a literal expected value, or literal constants (K, N, S1, PUTQ,
  SWAP*). None calls the board. The three changed existing expectations are literals too.
- **Fail on the base.** On the base, all 34 non-CONTROL checks fail and all 37 CONTROL checks pass. Every changed existing
  expectation fails on the other board, as the table in §2 shows.
- **Changed existing expectations.** These are exactly the builder's list, and the line numbers are right:
  - v1.89 base L3512 → c1 L3512–3514;
  - U2 comment, base L7325–7326 → c1 L7327–7328;
  - U2 (d), base L7396–7397 → c1 L7398–7401;
  - U2 (d) reopen, base L7398 → c1 L7402.
  No other existing line in any suite changed.
- **Who else calls `keptPutBack`.** No other suite does: audit-board, audit-other, audit-recon and the rest have none, so
  only audit-import blocks are touched.

### My ten mutants: plausible wrong fixes, text only (`mut/vt-mutants.mjs.txt`, each find exactly once on c1)

| id | wrong fix | U19 block | U2 / v189 / v195kept | my probe block VX |
|---|---|---|---|---|
| vt-keep-handle-only | keep only when a file handle is in memory | **0 (survives)** | 0 / **1** (v1.89 changed row) / 0 | VA 3 |
| vt-keep-why-file | keep S1 but mark it 'file' | 16 | — | — |
| vt-status-swapped | status words keyed on `swapped` | **0** | 0 / 0 / 0 | VD 1, VF 1 |
| vt-title-notfile | swap title for every kind but 'file' | **0** | 0 / 0 / 0 | VE 1 |
| vt-keep-always | keep in the folder too | 1 ((k) CONTROL) | — | — |
| vt-noroom-saved-goes-ahead | no room: put back anyway when saved | 1 ((h)) | — | — |
| vt-question-always | question claims "kept" in the folder too | 1 ((k) CONTROL) | — | — |
| vt-menu-notfile | swap menu words for every kind but 'file' | **0** | 0 / 0 / 0 | VE 1 |
| vt-keep-if-kept-from-file | keep only when K was kept by a file opening | 2 ((a)) | — | — |
| vt-save-clears-swap | a file Save drops the copy kept at a put-back | 16 | — | — |

## 4. Findings

### 4.1 MUST FIX: on the U19 route, the HOLD ON's Cancel advice is false

**The words.** The HOLD ON says "Cancel — don't save (then use ⬅ Import on the current file, **or reopen it**, to pick up
their changes first)". After Cancel, the board says "**Reopen** or ⬅ Import this file to load their version".

**What happens.** My probe block VX, scenario (VB): S1 saved, then ↶ Put back, then 💾 Save, then Cancel, then reopen.
- **On c1:** K stays on screen and S1 is not loaded. The board says "…the newer copy was not loaded…".
- **On the base:** the reopen loads S1.

| check (VF4 runs) | base | c1 | c1 + suggested fix |
|---|---|---|---|
| (VB) WORDS: "a reopen is named only where a reopen picks up their changes" | pass | **FAIL** | pass |

The brief says "the put-back question and the HOLD ON words stay true". The builder's §4 says "The HOLD ON's words are
unchanged and still true". Both are refuted here.

**This is broader than U19:**
- (VB2) The base already has the same false advice on its unsaved-'swap' route: it fails on base and on c1.
- (VB3) So does the classic route, where this browser's own copy is newer: it fails everywhere and is not fixed below.

**Minimal fix** (`diffs/demo-c1fix-board.diff`, in the demonstration copy `c1fix/`, not proposed as final text). In
`_saveInPlaceFileRun`, set `const reo=!_keptMeta;`. Then the Cancel line reads "on the current file'+(reo? ', or reopen
it,' : '')+' to pick up…", and the status reads "(reo? 'Reopen or ⬅ Import' : '⬅ Import')".
- On c1fix: WORDS (VB) and (VB2) pass. The U19 block is 71/71, U2 57/57, v189 40/40 and v195kept 10/10.
- No existing check or mutation names these words (grep).
- Add a U19 (i) check for the words after Cancel and a reopen, and a mutation (`reo=true`).

### 4.2 Should fix

1. **The top bar says "Saved" on a reopen before any Save.** The route is (VC) / the builder's (g): put back, then reopen.
   - On c1 the top bar reads "Saved 8:54 AM · ↶ work kept aside" while the record is unsaved and K is not in the file.
   - On the base this route showed S1, saved, so the header was true.
   - The same false "Saved" already shows on the base's browser-newer opening (VC2 fails on both), so the defect is older
     than U19 and the change reaches it.
   - On this route the occupied message also calls S1 both "a newer copy" and the "earlier work" kept aside, and calls K
     "new work".
   - The builder disclosed the header. Decide whether to fix it, or ledger it with this evidence.
2. **No test puts work back with no file handle in memory.** That is the state of every reopened page until its first Save.
   - Case (d) is called "no file handle remembered", but S1's save sets FH before the put-back.
   - The data-loss wrong fix vt-keep-handle-only passes all 71 U19 checks. Only the changed v1.89 row catches it.
   - Add VA (3 checks: base fails 3, c1 passes).
3. **Nothing guards the commit's three `why==='swap'` word branches for other kinds of kept copy.** The exception is U19
   (a)'s 'file'-kind title control.
   - vt-status-swapped, vt-title-notfile and vt-menu-notfile survive U19, U2, v189 and v195kept.
   - Under vt-status-swapped, a folder put-back copy is called "the saved file, which Alice saved after it".
   - Add VD (the 'file'-kind status words), VE (a 'folder' kept copy's title and menu) and VF (a folder swap copy put back
     with nothing kept).

### 4.3 Minor

- Three wrong fixes are each caught by a single check: vt-keep-always and vt-question-always by the (k) CONTROL, and
  vt-noroom-saved-goes-ahead by (h).
- The coverage shift is confirmed: putback-drops-screen is caught by v1.95 kept 1 on the base and 0 on c1. U2 and U19 still
  catch it.
- After §4.1 is fixed, the drafts should list the Cancel advice on the classic route (VB3) as open.

## 5. My runs

117 runs. Each went through `run.sh`, with a 600 s cap and a lock check; none timed out, waited or was skipped. The full
table is in `out/runs-table.md` (label, start ET, exit, wall s, log) and the raw records are in `logs/runs.txt`. Exit 1 on a
focused or mutant run means checks failed, as described above. All runs fell between 4:49 and 5:36 AM ET.

**VX versions.** VX is my probe block, `vx/scenarios.txt`. Four versions ran, and each run's harness blob is in its log:
- VF: `99b17928`, 24 checks;
- VF2 and the VM VX runs: `c3243779`, 27 checks;
- VF3: `5117d06a`, 30 checks;
- VF4: `4231c8d9`, 33 checks.

**PIDs.** `pids.txt` has every bounded command's timeout PID and its child, with time, label and command. I killed nothing.

## 6. Deviations and what I did not do

**Not bounded by `setsid -w timeout`:**
- read-only commands (cat, sed, grep, ls, diff, wc, awk, git hash-object, rev-parse, log and status, uptime, ps);
- `mkdir`, `cp` and `chmod` of my own files;
- `python3 -I` analysis of my own outputs;
- writes made with the editor tool;
- one `node --check h/src-c1/VX.mjs`, a syntax check of my harness at about 4:54 AM ET, with no lock check. The lock was
  absent at 4:49 AM ET and at every later check.

**Unwrapped sequencing.** Several background commands ran two or more bounded steps in sequence from an unwrapped shell:
batches 2–3, the suite pairs, and the probe parts. Each step was bounded at 600 s.

**Mutate text in the c1 clone.** The c1 clone holds c1's mutate text as `mutate.mjs`. It was never run, and no suite reads it.

**Not run:**
- audit-import and audit-board in full;
- the mutate sweep;
- Chromium and the grid tools;
- U20 (a second tab);
- real version history.
