# U19 builder: ↶ Put back after a board-file save keeps what it replaces

**Track U19, ORBIT v2.00 release.** This README has three parts. **Fix round 2 (13 Oct, from 1:21 PM ET)** comes first and
is the current state: it revises the one proposed commit again. **Fix round 1 (13 Oct, from 9:13 AM ET)** and **the build
record (12 Oct)** follow, each kept exactly as it was, with its results. Where a later round supersedes something earlier,
§F2.12 (and, for the build, §FR.12) lists it. Nothing was committed, staged or pushed anywhere, and nothing in
`/home/user/orbit-board` or `/home/user/orbit-ui` was edited. Every time is Eastern, read from `TZ=America/New_York date`.

# Fix round 2 (13 Oct 2026, from 1:21 PM ET)

## F2.0 Resume check

Fix round 2 started at 1:21 PM ET. First I looked for an earlier attempt of THIS round, because the lead had stopped an
attempt of the tests verifier's round at about 11:45 AM ET. Nothing in this directory was dated after fix round 1's last
write (10:26 AM ET) except the verifiers' own directories (`verify-money-r2/`, `verify-tests-r2/`) and the workflow's
`wfstate/` files. There was no "Fix round 2" section, and no `fr2/` copy, probe, log or diff. **So there was no stopped
attempt of fix round 2 to keep or redo.** Fix round 1 (`fr/`, its runs and its README sections below) and the build record
are kept as they were. The copies `c1/` (build) and `fr/c1/` (fix round 1) are left exactly as the verifiers checked them;
this round's copy is the new `fr2/c1/`. `/home/user/orbit-board` HEAD is now `6f5fc1b`; `git diff --stat 7ee498a HEAD` shows
no change to the board, `tools/` or `package.json`, so the base (7ee498a) is still the right one.

## F2.1 In short

- **The commit, revised again (it supersedes fix round 1's `fr/c1` and the build's `c1`):** `fr2/c1/` = the read-only base
  + one commit. Board `7a6e29cb`, audit-import `424cd9ae`, mutate.mjs.txt `07b53964`. audit-recon `529e36f7`, audit-board
  `a7c575e5` and audit-other `d89396b0` are unchanged. Built from the base by text scripts only (`fr2/build.sh`).
- **Every must-fix is fixed.**
  - **Money MF-A = tests MF-T2 (false words):** when what is on screen is the shared folder's own copy and the kept copy
    was kept at a put-back, the question said it was "still in the saved file it came from" (it never was). It now names
    the shared folder: the money verifier's own expression (its `vfix`, board `63092e7c`), as one named constant
    `scrWhere`. Checked in (r) (the folder) and in the new (t) (from the board file); entry `-putback-words-swap-file`.
  - **Tests MF-T1 (test gap, data loss):** a wrong M1 clause that keeps nothing once the folder holds ANY copy of this
    browser's passed the whole block. New scenario (s) (the tests verifier's VY-A, the money verifier's X1 shape): the folder
    holds an older copy S0, S1 is saved only in the file, put back with the folder on, switched back, Save OK, reopened.
    Entry `-putback-folder-base-any` is caught by (s), 4 checks.
- **The should-fixes, all done:**
  - tests SF-T1: (u) Cancel's advice with work kept by an opening (VY-B), (v) a freshly opened page (VY-C, a CONTROL), (w)
    a saved copy put back and then changed (VY-D), with the three entries proposed; each is caught;
  - tests SF-T2: (x) a colleague's copy on screen (Bob's, through ✍ Take the pen), with `-putback-keeps-own-only`, now
    caught by the U19 block itself;
  - money SF-1: closed by (s) (the same gap as MF-T1);
  - money SF-2: the drafts no longer overclaim; W4 (a newer copy saved into the file after the put-back's Save is left only in
    Teams version history by the next HOLD ON's OK) is listed as open, for the lead or Brad to accept knowingly;
  - money SF-3: fix round 1's proposed new ledger row is withdrawn; it is U15, and the evidence is appended there;
  - money SF-4: W7 (a folder copy loaded over work saved only in the file, then Save writes over it unasked) is drafted as
    its own new ledger row; it is identical on the base, not U19's to fix;
  - money SF-5: ↶ Put back is now refused at once while a locked cycle is on screen, as Save is: nothing is asked and the
    kept work is not touched. New scenario (y); entry `-putback-locked-asks`.
  - Minors done: the NEXT-VERSION entry now carries file:line for each changed expectation; counts updated; the ledger
    draft quotes the keep clause exactly; the code comment no longer says the folder's own copy "stays in the folder whatever
    Save does next" (it now says a Save there first keeps it in the folder's history, whose thinning is U30's).
- **Tests:** the U19 block grows from 104 to 136 checks (68 controls). On the base, 68 fail, every one outside the controls,
  and all 68 controls pass. On fix round 1's `fr/c1`, exactly 3 fail: (r) and (t) (MF-A's words) and (y) (the locked view).
  On `fr2/c1`, 136 of 136 pass. The same harness (`h/run-*/U19.fr2c1.mjs`, blob `ce6a1ff6`) ran on all three.
- **Regression harnesses on `fr2/c1`:** U2 57/57, v1.89 40/40, v1.95-kept 10/10. Crossed: the base's U2 harness fails only
  case (d)'s two rows and the base's v1.89 harness only "one click puts it back": the build's three changed expectations,
  nothing new.
- **Mutations:** seven entries added (23 U19 entries in all); mcount, text only, 1351 of 1351 match exactly once on
  `fr2/c1`. Each of the seven is caught by the U19 block in a clean run: folder-base-any (s) 4, words-swap-file (r)+(t) 2,
  cancel-swap-only (u) 1, putsavedgen-zero (v) 1, asput-ignores-edits (w) 1, keeps-own-only (x) 3 (and v1.89's changed row),
  locked-asks (y) 1. Nine older entries were re-run on `fr2/c1`; every count is fix round 1's or higher. Ten older
  entries were not re-run (machine load; §F2.6). Six mutant runs were killed from outside by the shared memory limit and
  re-run (§F2.6, §F2.13).
- **Memory, for the lead:** the U19 block peaks at 2.75 GB on its own (U2's two blocks: 1.09 GB). A measured variant that
  closes each finished scenario's boards peaks at 1.18 GB and passes 136/136. I did not adopt it, because it departs from
  the v2.00 block template; it is ready if the lead wants it (§F2.13).
- **A probe (P2, not a suite block) confirmed two more wording points, identical on the base:** for work kept by an opening,
  the question says "still in the saved file" when what is on screen was saved only to the shared folder; for work kept by
  Load theirs, "still in the shared folder" when it was saved only to the board file. Neither loses a copy. Both are listed
  open; changing them is not the smallest change that closes MF-A (§F2.3).

## F2.2 Each verifier finding, and what was done

| finding (lens) | what it said | done | where |
|---|---|---|---|
| MF-A (money) = MF-T2 (tests) | the question says K is "still in the saved file" when K is only in the shared folder (route W1 / VY-E) | **fixed**: `scrWhere` names the shared folder for a 'swap' kept copy when what is on screen is the folder's own copy (the verifier's expression, unchanged) | board; (r) new check; new (t); entry `-putback-words-swap-file` |
| MF-T1 (tests) | `!driveBaseOf(mySlug())` in place of `driveBaseOf(mySlug())!==(+MS.ts||0)` passes the block, and loses S1 (VY-A) | **fixed**: scenario (s), the verifier's VY-A in the block's own helpers | new (s); entry `-putback-folder-base-any` |
| SF-1 (money) | the same gap, by route X1 | closed by (s) (same shape: the folder holds an older copy, S1/S1B saved only in the file) | (s) |
| SF-2 (money) | the drafts overclaim; W4 (N2 lost after the put-back's Save) is not listed | **done**: the Unresolved sentence is scoped to "the work that was on screen at the put-back"; W4 is in "What users may see", the Unresolved bullet and the ledger text as open, to accept knowingly | drafts |
| SF-3 (money) | the proposed new "Saved" ledger row duplicates U15 | **done**: withdrawn; the evidence is appended to U15 | ledger draft |
| SF-4 (money) | W7, an older silent loss with no put-back, has no ledger row | **done**: drafted as a new row (`U<next>`), measured identical before and after U19 by the verifier; not U19's to fix (principle 5) | ledger draft |
| SF-5 (money) | under a locked view the put-back now runs swap-then-restore for saved work, untested | **fixed** the verifier's first way: `if(cycBlock('Loading a board')) return;` before the question. Nothing is asked, the kept slot is never touched | board; new (y); entry `-putback-locked-asks` |
| SF-T1 (tests) | three words-only mutants survive (cancel-swap-only, putsavedgen-init0, asput-ignores-edits) | **done**: (u), (v), (w) and the three entries | new (u), (v), (w) |
| SF-T2 (tests) | thin catches; keep-own-only caught only by the changed v1.89 row | **done** for keep-own-only: (x), a colleague's copy, and its entry. The other thin catches stay caught (one check is a catch); not widened | new (x) |
| minor (tests) | NEXT-VERSION should carry file:line itself | done | NEXT-VERSION draft |
| minor (tests) | counts in the drafts will change | done: 136 checks, 68 controls, 23 mutations | drafts |
| minor (tests) | `putback-drops-screen` now caught only by U19 | unchanged and still so; `-putback-folder-keeps-nothing` keeps U2's catch (fix round 1) | — |
| minor (tests) | U2 case (c) keeps S1 but reads nothing of the kept slot | left: (b) covers that route, as the verifier notes | — |
| minor (money) | `0===0`: no folder base and MS.ts 0 count as the folder's own copy | **not changed**: `persist()` sets `MS.ts=Date.now()` on every change (board L6774 area), so real work never has MS.ts 0; a screen with ts 0 is an untouched template. An untestable clause would add a mutation nobody can catch. The words' expression keeps the verifier's `+MS.ts &&` guard | — |
| minor (money) | "stays in the folder whatever Save does next" is too strong | **done**: the comment now says a Save there first keeps it in the folder's history | board comment |
| minor (money) | the new Cancel advice points to ⬅ Import, which replaces K after its own CONFLICT question | **not changed** (Brad's wording; asked, so principle 1 holds by asking); listed open | drafts |
| minor (money) | the ledger draft quotes the clause as `!==MS.ts` | **done**: quoted exactly | ledger draft |

## F2.3 The board change in this round, and the six principles

Three edits to `keptPutBack` (fix round 1's other edits stand), exact diff in §F2.15:

1. After the U2 "save under way" refusal, before anything is asked:
   `if(cycBlock('Loading a board')) return;` with a three-line comment. Under a locked cycle a load is always refused
   (`applyStore` → `cycRefuse('Loading a board')`); now it is refused first, with the same message, instead of asking a
   question about the locked view, writing the view into the kept slot and restoring the kept work after the refusal.
2. `const scrWhere=(k.meta.why==='swap' && +MS.ts && driveBaseOf(mySlug())===(+MS.ts||0))? 'the shared folder' : keptWhere(k.meta);`
   with a three-line comment, and the saved branch of the question uses `scrWhere` in place of `keptWhere(k.meta)`.
3. The keep test's comment: "which stays in the folder whatever Save does next" → "which a Save there first keeps in the
   folder's history".

Why not a place word taken from the screen for every kind of kept copy, which would also close P2-a and P2-b: such a rule
says "the saved file" whenever the folder base does not match what is on screen, and I have not checked every path that
loads a folder copy onto the screen for whether it records the folder base. A wrong base there would turn a true "shared
folder" into a false "saved file", on routes the block does not drive. The verifier's 'swap'-only rule is the smallest
change that closes MF-A, and it changes no sentence for the other kinds of kept copy. The other two cases are older,
identical on the base (P2, §F2.7), and listed for Brad.

The six principles, for this round's changes:

1. **Never lose a copy.** The keep decision itself is unchanged from fix round 1; the locked-view refusal touches nothing
   (the kept work is byte for byte the same, (y)); (s) and (x) pin two more routes where S1 or a colleague's copy is kept and
   reachable after the Save and after a reopen. W4 (one slot) is said plainly as open.
2. **Refuse or ask, never guess.** Under a locked view the put-back is refused at once, as Save and every load are there.
3. **Money and exports.** Not touched: no figure, export or save path changes; the money verifier's W3 (the kept S1 exported
   equals S1's own save, key for key) stands. audit, audit-ppt and audit-other pass on `fr2/c1` (§F2.8).
4. **Every word true, also after the operation lands.** The question no longer says "the saved file" for the folder's own
   copy (MF-A); no question is asked about a locked view that will refuse anyway. Two older wording points of the same
   sentence (P2) are listed, not hidden.
5. **Smallest change.** Two code lines (one guard, one constant) and one comment line, each with a short comment; the
   verifier's own expression is used as written.
6. **Every existing check preserved.** No committed expectation changes in this round; the build's three changed
   expectations and one comment stand as listed (§F2.5). Fix round 1's (r) check is restructured to keep the question it
   already counted (same value), and one check is added after it.

## F2.4 The tests: the U19 block, 104 → 136 checks

New scenarios, after (r), each driven through the page's own buttons and menus, in the block's own helpers (`inFile`,
`savedS1`, `putBackK`, `saveK`, `reopen`, `cancelSave`, `liveSwitchOff`, `takePenBtn`), and one helper constant, `FOLDQ`.
Every expected value is a hand-written literal or a literal constant (`K`, `N`, `S1`, `S0`, `N2`, `S1E`, the sentence
constants); board helpers only read what is observed.

- **(s)** the shared folder holds S0, an older copy of this browser's; 📡 Live view switched back; S1 saved only in the
  board file; working out of the folder again; ↶ Put back; switched back; 💾 Save, HOLD ON answered OK; reopened. S1 kept
  and reachable after the Save and after the reopen.
- **(t)** from the board file: S1 saved; K put back (S1 kept); a folder connected and 💾 Save writes K there (the file
  still holds S1); ↶ Put back S1: the question names the shared folder; nothing kept (K is the folder's own copy); 💾 Save
  refused with the choice; "Save yours over theirs" writes S1 and keeps K in the folder's history.
- **(r)**, one check added: the question S1's put-back asks names the shared folder.
- **(u)** K kept by the opening; S1 unsaved; Alice's other browser saves N2; 💾 Save, HOLD ON answered Cancel: the Cancel
  line and the status name ⬅ Import only; reopened, N2 is not loaded over S1 (a CONTROL: the advice is true).
- **(v)** CONTROL: a freshly opened page on this browser's newer unsaved copy; ↶ Put back at once says S1 has changes no
  saved copy has. It passes on the base by design; it pins `_putSavedGen`'s start value (`-putsavedgen-zero`).
- **(w)** S1 saved; K put back; S1 put back; S1 edited; ↶ Put back: the question says it has changes no saved copy has; the
  edited S1 is kept.
- **(x)** Bob's copy N on screen (Bob took the pen and wrote it); Alice puts K back: N is kept; her Save is refused (Bob
  holds the pen); ✍ Take the pen… asks its question, then the HOLD ON naming Bob, OK writes K; N kept after the Save and
  after the reopen.
- **(y)** a cycle locked, S1 saved, the locked cycle on screen; ↶ Put back: refused at once, nothing asked, the kept work
  byte for byte, "Loading a board is off while PB27 is on screen" said; the view left: S1 on screen and in the file, K kept
  byte for byte (a CONTROL).

Results by scenario (runs `F-f2a-U19.fr2c1-on-base`, `F-f2a-U19.fr2c1-on-frc1`, `F-f2b-U19.fr2c1-on-fr2c1`; harness
`ce6a1ff6` on all three; "controls" = checks whose label says CONTROL):

| scenario | checks | controls | fail on base | fail on fr/c1 | fail on fr2/c1 |
|---|---|---|---|---|---|
| (a) | 13 | 5 | 8 | 0 | 0 |
| (b) | 7 | 3 | 4 | 0 | 0 |
| (c) | 7 | 2 | 5 | 0 | 0 |
| (d) | 8 | 4 | 4 | 0 | 0 |
| (e) | 7 | 3 | 4 | 0 | 0 |
| (f) | 10 | 2 | 8 | 0 | 0 |
| (g) | 6 | 3 | 3 | 0 | 0 |
| (h) | 3 | 2 | 1 | 0 | 0 |
| (i) | 4 | 4 | 0 | 0 | 0 |
| (j) | 3 | 3 | 0 | 0 | 0 |
| (k) | 4 | 4 | 0 | 0 | 0 |
| (l) | 3 | 3 | 0 | 0 | 0 |
| (m) | 8 | 4 | 4 | 0 | 0 |
| (n) | 3 | 3 | 0 | 0 | 0 |
| (o) | 8 | 4 | 4 | 0 | 0 |
| (p) | 4 | 2 | 2 | 0 | 0 |
| (q) | 2 | 1 | 1 | 0 | 0 |
| (r) | 5 | 2 | 3 | 1 | 0 |
| (s) | 6 | 2 | 4 | 0 | 0 |
| (t) | 8 | 2 | 6 | 1 | 0 |
| (u) | 2 | 1 | 1 | 0 | 0 |
| (v) | 2 | 2 | 0 | 0 | 0 |
| (w) | 4 | 2 | 2 | 0 | 0 |
| (x) | 5 | 2 | 3 | 0 | 0 |
| (y) | 4 | 3 | 1 | 1 | 0 |
| all | 136 | 68 | 68 | 3 | 0 |

On the base: controls failing 0; non-control checks passing 0.

`(r)` gains one check (its question's words); every other row of (a)–(r) is unchanged from fix round 1. On the base, all 68
non-control checks fail and all 68 controls pass. On fix round 1's copy only the three new words/locked-view checks fail.

## F2.5 Existing expectations

No committed expectation changes in this round. The build's three changed expectations and one comment stand, now with
their file:line in the NEXT-VERSION entry itself (the tests verifier's minor; line numbers in `fr2/c1`'s audit-import, same as
`fr/c1`'s, since this round's block grows after them):

| file:line (before → after) | old expectation | new expectation | why |
|---|---|---|---|
| audit-import L3512 → L3512–3514 (v1.89 "the file is newer", "one click puts it back") | kept slot empty after the put-back: `String(localStorage.getItem(_AP.key+'.kept')===null)` → `'true'` | the slot holds the colleague's copy, not Brad's: `/COLLEAGUE NOTE/.test(s) && !/BRAD NOTE/.test(s)` → `'true'` | the colleague's save was in no other copy this board could reach once Save's HOLD ON was answered OK |
| L7326 → L7328 (U2 put back waits, `retry` helper comment) | "kept in its place if no saved copy has it (`was`: null when S1 is saved)" | "… or if it is saved only in a board file (v2.00, U19) (`was`: null when S1 is saved in the folder)" | comment only |
| L7396–7397 → L7400–7401 (U2 put back waits, case (d)) | `J([1, 'K', true, true, true, null])` | `J([1, 'K', true, true, true, 'S1'])` | S1 was saved only in the board file |
| L7398 → L7402 (case (d), reopened) | `afterFile(A, f, sc, ['S1', 'K'])` | `afterFile(A, f, sc, ['K', 'S1'])` | the file is newer than K's copy, K is unsaved and S1 is kept, so the file's copy is not loaded over K |

Crossed again on the final board (§F2.7): the base's U2 harness on `fr2/c1` fails only case (d)'s two rows
(`F-f2b-U2.base-on-fr2c1`), and the base's v1.89 harness only "one click puts it back" (`F-f2b-v189.base-on-fr2c1`). The
other direction (new text on the base) is fix round 1's, unchanged (§FR.7: the harness blobs `a1edf6a8` and `49261f6a` are
the same in this round).

Fix round 1's own (r) check (uncommitted) is restructured, not changed: it counted the questions as
`qs(A.ev).length - q3`; it now keeps them (`qr`) and counts `qr.length`, the same value, so the new check can read them.

## F2.6 Mutations (text only: `rec/bin/mkmut.py` builds each mutant from `fr2/c1`'s mutate.mjs.txt; nothing imports or runs mutate.mjs)

Set f2A: the seven entries this round adds (f2A2: their re-runs after a run was killed from outside). Set f2B: fix round
1's and the build's U19 entries, re-run on `fr2/c1`. Set f2C: the existing put-back entries. Every mutant board differs
from `fr2/c1`'s board in the one intended place (`fr2/mutdiff.txt`).

| set | mutation id | harness | checks | failing | failing scenarios | exit | caught | mutant board |
|---|---|---|---|---|---|---|---|---|
| f2A | `v200-u19-putback-folder-base-any` | U19 | 136 | 4 | (s) 4 | 1 | yes | `361cc1e9` |
| f2A | `v200-u19-putback-words-swap-file` | U19 | 136 | 2 | (r) 1, (t) 1 | 1 | yes | `343040b5` |
| f2A | `v200-u19-cancel-swap-only` | U19 | 136 | 1 | (u) 1 | 1 | yes | `39242a6d` |
| f2A | `v200-u19-putsavedgen-zero` | U19 | 136 | 1 | (v) 1 | 1 | yes | `fa47e6ce` |
| f2A | `v200-u19-putback-keeps-own-only` | U19 | 100 | 0 |  | 137 | incomplete: killed (exit 137, not by me); re-run below | `f83dd884` |
| f2A | `v200-u19-asput-ignores-edits` | U19 | (overwritten) | | its log and checks were overwritten by the re-run below under the same label (see the notes) | 137 | killed (exit 137, not by me) | `0c316365` |
| f2A | `v200-u19-asput-ignores-edits` | U19 | 136 | 1 | (w) 1 | 137 | yes, all checks recorded; run then killed (exit 137, not by me) | `0c316365` |
| f2A2 | `v200-u19-putback-keeps-own-only` | U19 | 136 | 3 | (x) 3 | 1 | yes | `f83dd884` |
| f2A | `v200-u19-putback-locked-asks` | U19 | 74 | 0 |  | 137 | incomplete: killed (exit 137, not by me); re-run below | `e2a9b5e5` |
| f2A2 | `v200-u19-putback-locked-asks` | U19 | 136 | 1 | (y) 1 | 1 | yes | `e2a9b5e5` |
| f2A | `v200-u19-putback-keeps-own-only` | v189 | 40 | 1 | the file is newer 1 | 1 | yes | `f83dd884` |
| f2A2 | `v200-u19-asput-ignores-edits` | U19 | 136 | 1 | (w) 1 | 1 | yes | `0c316365` |
| f2B | `v200-u19-putback-keeps-nothing-saved` | U19 | 136 | 62 | (a) 8, (b) 4, (c) 5, (d) 4, (e) 4, (f) 8, (g) 3, (h) 1, (m) 4, (o) 4, (p) 2, (s) 4, (t) 6, (w) 2, (x) 3 | 1 | yes | `627c95d8` |
| f2B | `v200-u19-putback-promise-unkept` | U19 | 136 | 51 | (a) 7, (b) 3, (c) 4, (d) 3, (e) 3, (f) 7, (g) 2, (h) 1, (m) 3, (o) 3, (p) 2, (s) 3, (t) 5, (w) 2, (x) 3 | 1 | yes | `32c409a2` |
| f2B | `v200-u19-putback-question-unsaid` | U19 | 136 | 13 | (a) 2, (b) 1, (c) 1, (d) 1, (e) 1, (f) 1, (g) 1, (m) 1, (o) 1, (s) 1, (t) 1, (x) 1 | 1 | yes | `6999ff72` |
| f2B | `v200-u19-swap-status-names-saver` | U19 | 136 | 3 | (a) 1, (f) 1, (r) 1 | 1 | yes | `f1872228` |
| f2B | `v200-u19-swap-title-unsaved` | U19 | 94 | 3 | (a) 3 | 137 | killed (exit 137, not by me) before the end | `78119423` |
| f2B3 | `v200-u19-swap-title-unsaved` | U19var | 136 | 4 | (a) 3, (r) 1 | 1 | yes | `78119423` |
| f2B | `v200-u19-putback-store-at-putback` | U19var | 136 | 8 | (m) 4, (s) 4 | 1 | yes | `19851a8b` |
| f2B | `v200-u19-putback-folder-keeps-nothing` | U2 | 57 | 7 | (b) 2, (c) 2, (d) 1, (g) 2 | 1 | yes | `1744614c` |
| f2B | `v200-u19-cancel-says-reopen` | U19var | 136 | 3 | (p) 1, (q) 1, (u) 1 | 1 | yes | `0aa00b7e` |
| f2C | `putback-drops-screen` | U19var | 136 | 7 | (f) 4, (j) 1, (v) 1, (w) 1 | 1 | yes | `f295ab67` |

**Reading the table.**
- **Every one of the seven new entries is caught by the U19 block through the block's own harness, with a clean run**
  (exit 1, all 136 checks recorded): `-putback-folder-base-any` (s) 4; `-putback-words-swap-file` (r) 1, (t) 1;
  `-cancel-swap-only` (u) 1; `-putsavedgen-zero` (v) 1, a CONTROL row by design; `-asput-ignores-edits` (w) 1 (f2A2);
  `-putback-keeps-own-only` (x) 3 (f2A2), and also v1.89's changed row (1); `-putback-locked-asks` (y) 1 (f2A2).
- **Six runs killed from outside (exit 137 before the 600 s cap, or no end record):** the first runs of `-putback-keeps-own-only`
  (2:05 PM ET, 100 checks recorded, none failing yet: it was killed before (x)), `-asput-ignores-edits` (2:05 PM ET, killed
  at 121 checks during (v); its log and checks file were then overwritten by the 2:11 PM re-run under the same label; that
  re-run recorded all 136 checks, (w) failing, and was killed before printing its summary), `-putback-locked-asks` (2:23 PM
  ET, 74 checks) and `-swap-title-unsaved` (2:57 PM ET, 94 checks, (a) 3 failing). Each was re-run; the clean re-runs are the
  results. `dmesg` shows the memory-cgroup OOM killer working in the cgroup that every agent's shell shares
  (`…/claude-code-bash`), killing other agents' `node` and `chrome` processes at 3:10 PM ET; the entries for my own kills had
  already left the kernel's buffer (`fr2/dmesg-killed.txt`). One more run, `M-f2B2-v200-u19-swap-title-unsaved-U19var` (3:04
  PM ET), lost its wrapper too: it has no end record in `logs/runs.txt` (its log, kept as `*.noend.log`, stops after the IDS
  line; 128 checks recorded, (a) 3 and (r) 1 failing); its third try (`M-f2B3-…`, 3:15 PM ET) is clean.
- **The f2B/f2B2/f2B3 runs from 3:04 PM ET use `U19var.mjs`**, the measurement variant of the same block (the same 136 checks
  and expected values; it only closes the boards of each finished scenario: §F2.13), because the block's own harness peaks
  at 2.75 GB and was being killed. On `fr2/c1` itself the variant passes 136/136 (`F-f2c-rss-U19var-on-fr2c1`).
- **Re-run in this round, from fix round 1's sixteen and the existing entries** (count on `fr2/c1` vs fix round 1's on
  `fr/c1`, §FR.6): `-putback-keeps-nothing-saved` 62 (47), `-putback-promise-unkept` 51 (38), `-putback-question-unsaid`
  13 (10), `-swap-status-names-saver` 3 (3, now (a), (f), (r)), `-swap-title-unsaved` 4 (4, now (a) 3, (r) 1),
  `-putback-store-at-putback` 8 (4: (m) 4 and now (s) 4), `-cancel-says-reopen` 3 (2: (p), (q) and now (u)),
  `-putback-folder-keeps-nothing` through U2 7 (7, the same rows), and the existing `putback-drops-screen` 7 (5: now also
  (v) and (w)). No catch is lost; the new scenarios add catches. (`putback-drops-screen`'s 7 failing rows include 2 control
  rows, (j) and (v): a mutant that drops what is on screen breaks the controls too, as it should.)
- **Not re-run in this round** (machine load: each U19 run took 7–9 minutes from 3 PM ET, close to the 600 s cap, and the
  memory killer was active): `-swap-menu-replaced`, `-putback-needs-handle`, `-putback-again-unsaved-said`,
  `-putback-again-any`, `-swap-saved-forgotten`, `-swap-status-by-kept`, `-swap-title-any-kind`, `-swap-menu-any-kind`,
  `-putback-folder-keeps-nothing` through U19, and U2's own `v200-u2-putback-gen` and `v200-u2-putback-while-saving`.
  Each was caught on `fr/c1` (§FR.6; the tests verifier reproduced every count). Their lines and the scenarios that catch
  them are unchanged in this round, and mcount shows each find still matches exactly once on `fr2/c1`. The lead's
  final-tree mutation queue runs them all.

## F2.7 Every run in this round (`logs/runs.txt`; each log ends with its exit and wall time)

| label | start (ET) | exit | wall s | log |
|---|---|---|---|---|
| F-f2a-U19.fr2c1-on-fr2c1 | 13:32:11 | 0 | 170.9 | `logs/F-f2a-U19.fr2c1-on-fr2c1.log` |
| F-f2a-U19.fr2c1-on-base | 13:32:11 | 1 | 174.5 | `logs/F-f2a-U19.fr2c1-on-base.log` |
| F-f2a-U2.fr2c1-on-fr2c1 | 13:35:28 | 0 | 109.1 | `logs/F-f2a-U2.fr2c1-on-fr2c1.log` |
| F-f2a-U19.fr2c1-on-frc1 | 13:35:28 | 1 | 169.0 | `logs/F-f2a-U19.fr2c1-on-frc1.log` |
| F-f2b-P2-on-fr2c1 | 13:38:56 | 1 | 22.3 | `logs/F-f2b-P2-on-fr2c1.log` |
| F-f2b-P2-on-base | 13:40:04 | 1 | 32.4 | `logs/F-f2b-P2-on-base.log` |
| F-f2b-U19.fr2c1-on-fr2c1 | 13:38:56 | 0 | 250.2 | `logs/F-f2b-U19.fr2c1-on-fr2c1.log` |
| F-f2b-v189.fr2c1-on-fr2c1 | 13:43:24 | 0 | 78.9 | `logs/F-f2b-v189.fr2c1-on-fr2c1.log` |
| F-f2b-v195kept.fr2c1-on-fr2c1 | 13:44:43 | 0 | 62.8 | `logs/F-f2b-v195kept.fr2c1-on-fr2c1.log` |
| F-f2b-U2.fr2c1-on-fr2c1 | 13:43:23 | 0 | 201.3 | `logs/F-f2b-U2.fr2c1-on-fr2c1.log` |
| F-f2b-v189.base-on-fr2c1 | 13:47:02 | 1 | 87.6 | `logs/F-f2b-v189.base-on-fr2c1.log` |
| F-f2b-U2.base-on-fr2c1 | 13:47:02 | 1 | 229.3 | `logs/F-f2b-U2.base-on-fr2c1.log` |
| M-f2A-v200-u19-putback-folder-base-any-U19.fr2c1-on-fr2c1 | 13:51:05 | 1 | 444.6 | `logs/M-f2A-v200-u19-putback-folder-base-any-U19.fr2c1-on-fr2c1.log` |
| M-f2A-v200-u19-putback-words-swap-file-U19.fr2c1-on-fr2c1 | 13:51:05 | 1 | 466.1 | `logs/M-f2A-v200-u19-putback-words-swap-file-U19.fr2c1-on-fr2c1.log` |
| M-f2A-v200-u19-cancel-swap-only-U19.fr2c1-on-fr2c1 | 13:59:20 | 1 | 336.6 | `logs/M-f2A-v200-u19-cancel-swap-only-U19.fr2c1-on-fr2c1.log` |
| M-f2A-v200-u19-putsavedgen-zero-U19.fr2c1-on-fr2c1 | 13:59:20 | 1 | 350.4 | `logs/M-f2A-v200-u19-putsavedgen-zero-U19.fr2c1-on-fr2c1.log` |
| M-f2A-v200-u19-putback-keeps-own-only-U19.fr2c1-on-fr2c1 | 14:05:23 | 137 TIMED OUT = incomplete | 217.9 | `logs/M-f2A-v200-u19-putback-keeps-own-only-U19.fr2c1-on-fr2c1.log` |
| M-f2A-v200-u19-asput-ignores-edits-U19.fr2c1-on-fr2c1 | 14:05:23 | 137 TIMED OUT = incomplete | 333.2 | `logs/M-f2A-v200-u19-asput-ignores-edits-U19.fr2c1-on-fr2c1.log` |
| M-f2A-v200-u19-asput-ignores-edits-U19.fr2c1-on-fr2c1 | 14:11:16 | 137 TIMED OUT = incomplete | 338.4 | `logs/M-f2A-v200-u19-asput-ignores-edits-U19.fr2c1-on-fr2c1.log` |
| M-f2A2-v200-u19-putback-keeps-own-only-U19.fr2c1-on-fr2c1 | 14:17:14 | 1 | 367.6 | `logs/M-f2A2-v200-u19-putback-keeps-own-only-U19.fr2c1-on-fr2c1.log` |
| M-f2A-v200-u19-putback-locked-asks-U19.fr2c1-on-fr2c1 | 14:23:30 | 137 TIMED OUT = incomplete | 140.7 | `logs/M-f2A-v200-u19-putback-locked-asks-U19.fr2c1-on-fr2c1.log` |
| M-f2A2-v200-u19-putback-locked-asks-U19.fr2c1-on-fr2c1 | 14:25:58 | 1 | 339.2 | `logs/M-f2A2-v200-u19-putback-locked-asks-U19.fr2c1-on-fr2c1.log` |
| F-f2c-rss-U19.fr2c1-on-fr2c1 | 14:31:58 | 0 | 158.7 | `logs/F-f2c-rss-U19.fr2c1-on-fr2c1.log` |
| F-f2c-rss-U2.fr2c1-on-fr2c1 | 14:35:15 | 0 | 101.2 | `logs/F-f2c-rss-U2.fr2c1-on-fr2c1.log` |
| F-f2c-rss-U19var-on-fr2c1 | 14:35:14 | 0 | 239.1 | `logs/F-f2c-rss-U19var-on-fr2c1.log` |
| M-f2A-v200-u19-putback-keeps-own-only-v189.fr2c1-on-fr2c1 | 14:39:31 | 1 | 43.5 | `logs/M-f2A-v200-u19-putback-keeps-own-only-v189.fr2c1-on-fr2c1.log` |
| M-f2A2-v200-u19-asput-ignores-edits-U19.fr2c1-on-fr2c1 | 14:39:30 | 1 | 140.0 | `logs/M-f2A2-v200-u19-asput-ignores-edits-U19.fr2c1-on-fr2c1.log` |
| M-f2B-v200-u19-putback-keeps-nothing-saved-U19.fr2c1-on-fr2c1 | 14:42:01 | 1 | 121.2 | `logs/M-f2B-v200-u19-putback-keeps-nothing-saved-U19.fr2c1-on-fr2c1.log` |
| S-audit-recon-fr2c1 | 14:42:01 | 0 | 232.8 | `logs/S-audit-recon-fr2c1.log` |
| M-f2B-v200-u19-putback-promise-unkept-U19.fr2c1-on-fr2c1 | 14:44:10 | 1 | 172.9 | `logs/M-f2B-v200-u19-putback-promise-unkept-U19.fr2c1-on-fr2c1.log` |
| S-boot-same-fr2c1 | 14:47:16 | 0 | 40.6 | `logs/S-boot-same-fr2c1.log` |
| S-audit-fr2c1 | 14:48:06 | 0 | 42.4 | `logs/S-audit-fr2c1.log` |
| M-f2B-v200-u19-putback-question-unsaid-U19.fr2c1-on-fr2c1 | 14:47:17 | 1 | 321.7 | `logs/M-f2B-v200-u19-putback-question-unsaid-U19.fr2c1-on-fr2c1.log` |
| S-audit-ppt-fr2c1 | 14:52:49 | 0 | 20.4 | `logs/S-audit-ppt-fr2c1.log` |
| S-audit-other-fr2c1 | 14:53:18 | 0 | 139.8 | `logs/S-audit-other-fr2c1.log` |
| M-f2B-v200-u19-swap-status-names-saver-U19.fr2c1-on-fr2c1 | 14:52:50 | 1 | 283.0 | `logs/M-f2B-v200-u19-swap-status-names-saver-U19.fr2c1-on-fr2c1.log` |
| S-legacy-fsrc-fr2c1 | 14:57:45 | 0 | 14.7 | `logs/S-legacy-fsrc-fr2c1.log` |
| M-f2B-v200-u19-swap-title-unsaved-U19.fr2c1-on-fr2c1 | 14:57:46 | 137 TIMED OUT = incomplete | 189.9 | `logs/M-f2B-v200-u19-swap-title-unsaved-U19.fr2c1-on-fr2c1.log` |
| S-audit-hostile-fr2c1 | 14:58:10 | 0 | 262.9 | `logs/S-audit-hostile-fr2c1.log` |
| S-audit-inject-fr2c1 | 15:02:41 | 0 | 70.4 | `logs/S-audit-inject-fr2c1.log` |
| S-check-fr2c1 | 15:04:02 | 0 | 15.4 | `logs/S-check-fr2c1.log` |
| M-f2B3-v200-u19-swap-title-unsaved-U19var-on-fr2c1 | 15:15:46 | 1 | 530.2 | `logs/M-f2B3-v200-u19-swap-title-unsaved-U19var-on-fr2c1.log` |
| M-f2B-v200-u19-putback-store-at-putback-U19var-on-fr2c1 | 15:24:51 | 1 | 545.6 | `logs/M-f2B-v200-u19-putback-store-at-putback-U19var-on-fr2c1.log` |
| M-f2B-v200-u19-putback-folder-keeps-nothing-U2.fr2c1-on-fr2c1 | 15:34:14 | 1 | 187.8 | `logs/M-f2B-v200-u19-putback-folder-keeps-nothing-U2.fr2c1-on-fr2c1.log` |
| M-f2B-v200-u19-cancel-says-reopen-U19var-on-fr2c1 | 15:34:13 | 1 | 476.4 | `logs/M-f2B-v200-u19-cancel-says-reopen-U19var-on-fr2c1.log` |
| M-f2C-putback-drops-screen-U19var-on-fr2c1 | 15:37:30 | 1 | 463.6 | `logs/M-f2C-putback-drops-screen-U19var-on-fr2c1.log` |

Exit 1 on a focused run on the base or on `fr/c1`, on a probe run, or on a mutant run means checks failed, as intended.
Exit 137 ("TIMED OUT = incomplete" is run.sh's label for 124/137) came before the 600 s cap: the run was killed from
outside, not by me and not by its timeout; each such run was re-run (§F2.6, §F2.13). One run has no line here:
`M-f2B2-v200-u19-swap-title-unsaved-U19var-on-fr2c1` (start 3:04:49 PM ET; its PIDs are in `pids.txt`), whose wrapper was
killed from outside before it wrote its end line; its log is kept as `logs/…-U19var-on-fr2c1.noend.log` (§F2.6).

**Probe P2** (`fr2/probe/p2-block.mjs.txt`, blob `20a3c829`; harness `P2.mjs` `32a4c3b7`, built VERBATIM by
`bin/mkfocused-u2.py` from a copy of `fr2/c1`'s audit-import with the probe block inserted after the U19 end marker by the
tests verifier's unchanged `vy/mkvy.py`). Not a suite block; it records two wording points, with hand-written expected
values, on the base and on `fr2/c1` (`F-f2b-P2-on-base`, `F-f2b-P2-on-fr2c1`; exit 1 on both, by design):

| route | base | fr2/c1 |
|---|---|---|
| P2-a: K kept by the opening ('file'); N edited to N′ and saved to a shared folder only (the file holds N); ↶ Put back K | question: "What is on screen now is still in the saved file it came from …" (false: N′ is only in the folder); nothing kept, N′ in the folder | the same words; nothing kept (N′ is the folder's own copy), N′ in the folder |
| P2-b: K kept by Load theirs ('folder'); 📡 Live view switched back to the file; S1 saved into the board file only; ↶ Put back K | question: "What is on screen now is still in the shared folder it came from …" (false: S1 is only in the board file); nothing kept | the same place words, plus "It is also kept aside in its place …"; S1 kept aside |

Neither route loses a copy on `fr2/c1`. On the base, P2-b's S1 is not kept (the U19 loss itself). Both sentences come from
`keptWhere(k.meta)`, which this round leaves as it is for these two kinds of kept copy (§F2.3).

## F2.8 The other suites and npm run check, on `fr2/c1` (scratch clone `git/fr2c1` at 7ee498a, `fr2/mkclone.sh`)

- S-audit-recon-fr2c1 | ALL CHECKS PASSED | exit: 0
- S-boot-same-fr2c1 | every page, source, save and error list is identical either way | exit: 0
- S-audit-fr2c1 | ALL CHECKS PASSED | exit: 0
- S-audit-ppt-fr2c1 | ALL CHECKS PASSED | exit: 0
- S-audit-other-fr2c1 | ALL CHECKS PASSED | exit: 0
- S-legacy-fsrc-fr2c1 | every legacy Force setting computes exactly as before | exit: 0
- S-audit-hostile-fr2c1 | ALL CHECKS PASSED | exit: 0
- S-audit-inject-fr2c1 | ALL CHECKS PASSED | exit: 0
- S-check-fr2c1 | all checks passed | exit: 0

The base results are the build's (§9 of the build record): the base board and suites are unchanged.

## F2.9 mcount (text only, `rec/bin/mcount.py`, `python3 -I`; `out/fr2-mcount/`)

- `fr2c1`: `{"entries": 1351, "once": 1351, "missing": [], "multiple": [], "unparsed": []}`
- `base`: `{"entries": 1328, "once": 1328, "missing": [], "multiple": [], "unparsed": []}`
- `fr2c1mut-on-base`: `{"entries": 1351, "once": 1328, "missing": ["v200-u19-putback-keeps-nothing-saved", "v200-u19-putback-promise-unkept", "v200-u19-putback-question-unsaid", "v200-u19-swap-status-names-saver", "v200-u19-swap-title-unsaved", "v200-u19-swap-menu-replaced", "v200-u19-putback-store-at-putback", "v200-u19-putback-folder-keeps-nothing", "v200-u19-putback-needs-handle", "v200-u19-putback-again-unsaved-said", "v200-u19-putback-again-any", "v200-u19-swap-saved-forgotten", "v200-u19-cancel-says-reopen", "v200-u19-swap-status-by-kept", "v200-u19-swap-title-any-kind", "v200-u19-swap-menu-any-kind", "v200-u19-putback-folder-base-any", "v200-u19-putback-words-swap-file", "v200-u19-cancel-swap-only", "v200-u19-putsavedgen-zero", "v200-u19-asput-ignores-edits", "v200-u19-putback-keeps-own-only", "v200-u19-putback-locked-asks"], "multiple": [], "unparsed": []}`
- `fr2c1mut-on-frc1`: `{"entries": 1351, "once": 1349, "missing": ["v200-u19-putback-words-swap-file", "v200-u19-putback-locked-asks"], "multiple": [], "unparsed": []}`
- `basemut-on-fr2c1`: `{"entries": 1328, "once": 1328, "missing": [], "multiple": [], "unparsed": []}`

`fr2c1` is fr2/c1's mutate text on its own board; `base` the base's on its own. `fr2c1mut-on-base` and
`fr2c1mut-on-frc1` are fr2/c1's text on the base board and on fix round 1's board: the missing ids find code this commit
adds or this round changes, as expected. `basemut-on-fr2c1`: every existing entry still matches exactly once on fr2/c1.

## F2.10 Blobs (`git hash-object`)

| file | base | build c1 | fix round 1 fr/c1 | fix round 2 fr2/c1 |
|---|---|---|---|---|
| `prioritization-board-grid.html` | `fce8a391bd8a248d5185e199d22190c1687eaea0` | `8cf14d7e6baf8fa6f590e3082a2ed429458c3490` | `f6ac4b9d62d528c855a08e0101b98873792f99d5` | `7a6e29cb9908a055c5f8a5b1bfc6f99b938e79d0` |
| `tools/export-audit/audit-import.mjs` | `4aba2506a7ea3bd367fb74436172b188bb4fc887` | `a1a3e32c67ca632ce9fb5e8f69ddae5f7881d3e4` | `cfaeac173615efb6ae1a5e64a696544a4e20754f` | `424cd9ae2b9ecc59247722501bd68a6c1d0781ca` |
| `tools/export-audit/mutate.mjs.txt` | `cbc6defc6803851e847844848fc9b186daeeb268` | `67ec010fe747ce2c1fb02987f19a1a4f48429aac` | `9028eaa8a88fb231b3450415b7d4aaf749d76d4f` | `07b5396407f840b467517b80bba821dfef78e85d` |
| `tools/export-audit/audit-recon.mjs` | `529e36f7c20e635b2722ea53b6a4f44b4ed328af` | `529e36f7c20e635b2722ea53b6a4f44b4ed328af` | `529e36f7c20e635b2722ea53b6a4f44b4ed328af` | `529e36f7c20e635b2722ea53b6a4f44b4ed328af` |
| `tools/export-audit/audit-board.mjs` | `a7c575e5f98452be88f8d0d7f352fd805350e3d7` | `a7c575e5f98452be88f8d0d7f352fd805350e3d7` | `a7c575e5f98452be88f8d0d7f352fd805350e3d7` | `a7c575e5f98452be88f8d0d7f352fd805350e3d7` |
| `tools/export-audit/audit-other.mjs` | `d89396b0cbf7c4b2ea2110acc0a663a23de62760` | `d89396b0cbf7c4b2ea2110acc0a663a23de62760` | `d89396b0cbf7c4b2ea2110acc0a663a23de62760` | `d89396b0cbf7c4b2ea2110acc0a663a23de62760` |
| `tools/export-audit/boot.mjs` | `9c4f49ad8cec537097bdf485458cfd2a09b06594` | `9c4f49ad8cec537097bdf485458cfd2a09b06594` | `9c4f49ad8cec537097bdf485458cfd2a09b06594` | `9c4f49ad8cec537097bdf485458cfd2a09b06594` |

| fix round 2 file | blob |
|---|---|
| `fr2/bin/edit-board-fr2.py` | `05b653242d2f49959cad8f5ef7a558ada9972227` |
| `fr2/bin/edit-mutate-fr2.py` | `4c018a1038281078a7c515cbaf1c8c9afa611058` |
| `fr2/bin/mkblock-fr2.py` | `5bed49c64a916d21c88843bdc33e0ac67e61fc50` |
| `fr2/bin/muttable2.py` | `d8c2a664b95b5202aabd5e192c87d717c545da36` |
| `fr2/bin/scentable.py` | `faa25c70704e3ebdd6db514d4638c4854132b971` |
| `fr2/bin/runner-rss.mjs` | `33711dfeaa4da335ece0f0f0fb6696352d7f1ac9` |
| `fr2/block-u19.fr2.mjs.txt` | `944d7c67a09260f41fbe8756cad38977a5139c45` |
| `fr2/build.sh` | `321587d5aeee3939eaaceb349d34b0d54c6f5e65` |
| `fr2/frun.sh` | `82d63a3b3e1285ee8f34b832ae5437064b59f76d` |
| `fr2/mrun.sh` | `42bfbb5635db2a5363084b8bdd48877ad8d4763c` |
| `fr2/mkclone.sh` | `21e522e9fd65e556ae676fe0a24b5427fc79c2e1` |
| `fr2/mkdiffs.sh` | `e0c0b28f5a1ab8c22ec3d24afa33e8bba72ae96c` |
| `fr2/mutdiff.sh` | `b5a62450d641a3c52af2d2401d664718b9a7cec1` |
| `fr2/mutdiff.txt` | `5c26946ebe16bd499816681d82a81da9a7dad009` |
| `fr2/assemble.sh` | `a9b3d51ee9763961460f6b686e0a1905900456b8` |
| `fr2/README.fr2.head.md` | `bcedb986176e37e5a3d1f9d475e7b181376ec12f` |
| `fr2/README.fr2.body.md` | `19da228170a844149a12aa801ae84446c9653f75` |
| `fr2/README.fr2.mid.md` | `46cbab3f46c31d319b277918075ce0f2a3e316ff` |
| `fr2/README.fr2.tail.md` | `44ffdb683585045b8373f008e06710255db81f3d` |
| `fr2/drafts/NEXT-VERSION-U19.md` | `099d5b88c9e53c40ed9ef109fa6c52106bae9611` |
| `fr2/drafts/UNRESOLVED-U19.md` | `2226a985a4f739eedc8283de6990fd40d1cd9e5e` |
| `fr2/drafts/LEDGER-U19.md` | `2acadde966093c68b57b12d787a0f7e4750a7a96` |
| `fr2/probe/p2-block.mjs.txt` | `20a3c829c4ccdb2d1a30420d43368aa7b48681e6` |
| `fr2/probe/build-p2.sh` | `01274dfbb2595df4aa31a2777c865ba29f1910d8` |
| `fr2/probe/P2.mjs` | `32a4c3b70f037dcd8fa22814a9dd1546f2a286b2` |
| `fr2/probe/var/mkvar.py` | `7b278a8167b27e1b6843f4c3064dda87c73ab59e` |
| `fr2/probe/var/build-var.sh` | `fd2f2b965947c2a6fa622cef577c737f8ecb1136` |
| `fr2/probe/var/block-u19.var.mjs.txt` | `9229f93d2f50b8d0a566475cc0f632fd1e97dfcd` |
| `h/run-fr2c1/U19.fr2c1.mjs` | `ce6a1ff6fbee03d2fab345c7b4923f0bcc0c8e7f` |
| `h/run-fr2c1/U2.fr2c1.mjs` | `a1edf6a8f1f26605483bec1e595ce6b9451bc54d` |
| `h/run-fr2c1/v189.fr2c1.mjs` | `49261f6a8468169e7272f828a4f88a59fec0660d` |
| `h/run-fr2c1/v195kept.fr2c1.mjs` | `f2adbb73140847e201c0858b0147ace0245b7e81` |
| `h/run-fr2c1/U2.base.mjs` | `32cc5ac772e47018425e21dd22ef15064b00e52f` |
| `h/run-fr2c1/v189.base.mjs` | `ed54e6137e0a405f9262e1628ded4e6be6ca796e` |
| `h/run-fr2c1/U19var.mjs` | `3fc427f306d70261bc496ce2ed4b2624efae005c` |
| `fr2/diffs/c1-board.diff` | `f58e6cb722a2e14fd0c781544914828d29199dc7` |
| `fr2/diffs/c1-audit-import.diff` | `36e2faf8dd1f406f9fa57f8bce5ec959b940a2a9` |
| `fr2/diffs/c1-mutate.diff` | `0ab362ad0c73755c386ee286a24033958e8d3b82` |
| `fr2/diffs/c1-all.diff` | `75a920a62e1e9288df03c5b9477a9e0d60b4d4b6` |
| `fr2/diffs/fr1-to-fr2-board.diff` | `aa83a00ea47d8151fb902bbe593e77b23cc84465` |
| `fr2/diffs/fr1-to-fr2-audit-import.diff` | `bbc601340a93d6a1a41bea03cb36ecd9c03f8c51` |
| `fr2/diffs/fr1-to-fr2-mutate.diff` | `313d81425677645facb67809e99a23e4a07fbc13` |
| `fr2/diffs/fr1-to-fr2-all.diff` | `cf62241e69296af2c4290efcbb518f7c0c3de5a1` |
| `README.fr1.md` | `62c31d31083e18779a6afc5f724be06136d713d8` |

Unchanged and reused: `bin/edit-board.py`, `bin/edit-import.py`, `bin/edit-mutate.py` (the build's), `fr/bin/edit-board-fr.py`,
`fr/bin/edit-mutate-fr.py` and `fr/block-u19.fr.mjs.txt` (fix round 1's; each applied in order, then this round's script),
`bin/runner.mjs`, `bin/mkfocused-u2.py`, `bin/tally.py`, `bin/fails.py`, `bin/runstable.py`, `run.sh`, `bx.sh`, `mk-harness.sh`,
`suites.sh`, `verify-tests-r2/vy/mkvy.py` (the tests verifier's insert script, used unchanged for probe P2).

## F2.11 Drafts for the lead (the lead commits; I did not). They supersede fix round 1's §FR.11 and the build's §12.

### F2.11.1 NEXT-VERSION.md, under v2.00, after the U14 entry and before "Unresolved after R1–R5" (`fr2/drafts/NEXT-VERSION-U19.md`)

```
- **U19 — ↶ Put back after a board-file save keeps what it replaces** (Brad, 12 Oct, about 5:30 PM ET: "Don't wait for me.
  Let's keep pressing throughout to get this next version published."; the lead's decision to fix the release blockers).
  With work saved into the board file (S1), ↶ Put back of the work kept aside (K) kept nothing in S1's place, because S1 was
  "still in the saved file it came from, and 💾 Save will ask before writing over that". Save did ask (its HOLD ON), but
  answered OK it wrote K over S1, and then S1 was in no copy this board could reach: not on screen, not kept aside, not in
  browser storage, not in a byte of the file, after the Save and after a reopen. It was left only in Teams version history,
  outside the board, where the file has one. The shared folder keeps the copy a save replaces in its history; a board file
  keeps none. Now ↶ Put back keeps what is on screen aside in the kept work's place, with the checkpoint it came from,
  whether or not it is saved, as unsaved work always was. The one exception is when 💾 Save writes to the shared folder at
  the put-back and what is on screen is the folder's own copy (the one last loaded from or written to the folder): that copy
  is in the folder, and a Save there keeps the copy it replaces in the folder's history. The choice is made at the put-back,
  so switching 📡 Live view from "● Working out of this folder" back to "○ Just watching" before the Save cannot leave work
  saved only in the board file unkept, also when the folder holds an older copy of the same browser's work. Whoever saved
  what is on screen, it is kept: the person's own save or a colleague's. Putting the kept copy back later restores it, and
  Save asks again before writing over the file. The question adds "It is also kept aside in its place, so it is not lost if
  Save does." When what is on screen is the shared folder's own copy and the work kept aside was kept at a put-back, the
  question now says it is "still in the shared folder it came from"; it said "the saved file", which never held that copy.
  A copy kept this way that was saved, then put back and not changed since, is not said to have "changes no saved copy
  has": the question says "What is on screen now was put back and has not been saved since, so it is kept aside in its
  place — nothing is lost." Changed after that, or on a freshly opened page, it is said to have changes no saved copy has,
  as before. With no room in browser storage to keep what is on screen, nothing is put back and nothing changes, as for
  unsaved work. While a locked cycle is on screen, ↶ Put back is refused at once, as every load and Save are there
  ("🔒 Loading a board is off while … is on screen."): nothing is asked and the kept work is not touched. Before, it asked
  its question about the locked view, kept the view aside in the kept work's place, and put the kept work back once the load
  was refused. The words for a copy kept at a put-back no longer call it work no saved copy had or say a saved copy replaced
  it: the top bar's ↶ work kept aside says "What was on screen when other work was put back, kept aside …", 📁 File says
  "kept … · what was on screen when other work was put back", and putting such a copy back says "💾 Save will ask before it
  writes over a copy saved after the one this work came from." While work is kept aside, a reopen does not load the file's
  copy over unsaved work on screen, so the HOLD ON's Cancel line then reads "Cancel — don't save (then use ⬅ Import on the
  current file to pick up their changes first)." and the status after Cancel "… ⬅ Import this file to load their version,
  then redo your edits.", without "or reopen it" and "Reopen or", which were not true there: on the board before this
  change the old advice was already untrue after a put-back of unsaved work and after an opening that kept work aside
  (both now checked). With nothing kept aside, both read as before.
  - **What users may see:** after ↶ Put back, the top bar keeps offering ↶ work kept aside (what was on screen) until it is
    put back, saved as a file or discarded. In the shared folder too, when what was on screen was not the folder's own copy.
    While it is kept, a newer copy that would need work kept aside is not loaded, and the board says so, as it already did
    for unsaved work. The next 💾 Save then asks HOLD ON before writing over that newer copy in the file; answered OK, that
    copy is left only in Teams version history, as with any HOLD ON answered OK. This includes reopening the file before any
    Save after the put-back: K stays on screen, unsaved, and the file's copy (S1, the very copy kept aside) is not loaded
    ("… the newer copy was not loaded and nothing was lost"); before, S1 opened and K was kept. It also includes a newer
    copy saved into the file AFTER the put-back's Save, from another browser (N2): the reopen does not load N2 over new work
    (K2) while S1 is kept, and the next Save's HOLD ON, answered OK, writes K2 over N2, which is then only in Teams version
    history. On the board before this change, that reopen loaded N2 and kept K2, and S1 was the copy lost. The board keeps
    one copy aside: U19 spends it on the copy a put-back replaces. On a reopen the top bar says "Saved <time> · ↶ work kept
    aside" while the work on screen is unsaved by this browser's record. That is the board's existing opening behaviour
    (U15 in the ledger), now reached on this route too. After a saved copy is put back, the top bar says "Unsaved changes"
    though the file holds it: a put-back counts as a change (v2.00, U2). A put-back in a browser whose storage is full is
    now refused, with "nothing was changed", where it used to go ahead when what was on screen was saved. ↶ Put back pressed
    while a locked cycle is on screen asks nothing and says loading is off there.
  - **Test:** audit-import "v2.00 (U19) — put back after a board-file save keeps what it replaces" (136 checks). It drives
    the routes through the page's own buttons and menus: put back once S1's save has landed; put back while it writes
    (refused, U2) and again once it has landed; through 📁 File and the note editor; with no file handle remembered (the
    picker); between two writers, each with their own key (✍ Take the pen, both ways); with 📡 Live view working out of a
    folder at the put-back and switched back to the file before the Save, with the folder empty and with the folder holding
    an older copy of the same browser's work; on a reopened page with no file handle in memory; and with a colleague's copy
    on screen (Bob's, written through ✍ Take the pen). Each route then runs 💾 Save with the HOLD ON answered OK and a
    reopen. It also covers K and S1 put back in turn before any Save; a saved copy put back and then changed; a reopen
    before any Save; no room in browser storage; the HOLD ON answered Cancel while work is kept aside (S1 saved, S1 never
    saved, and work kept by the opening); the question's words when what is on screen is the shared folder's own copy, in
    the folder and from the board file; the words for each kind of kept copy in the shared folder; and a locked cycle on
    screen. The controls are the HOLD ON answered Cancel, S1 never saved, the shared folder, 📡 Live view left on at the
    Save, a freshly opened page's put-back question, and ordinary editing. 68 checks fail on the board before the change,
    none of them a control; all 68 control checks pass on both.
  - **Existing expectations changed (3 checks and 1 comment, in tools/export-audit/audit-import.mjs; line numbers before →
    after):**
    - L3512 → L3512–3514, v1.89 "the file is newer", "one click puts it back": the kept slot was empty after the put-back
      (`String(localStorage.getItem(_AP.key+'.kept')===null)` → `'true'`); it now holds the colleague's copy and not Brad's
      (`/COLLEAGUE NOTE/.test(s) && !/BRAD NOTE/.test(s)` → `'true'`). Why: the colleague's save was in no other copy this
      board could reach once Save's HOLD ON was answered OK.
    - L7326 → L7328, "v2.00 (U2) — put back waits for a save to finish", the `retry` helper's comment: what is kept is now
      also work saved only in a board file. Comment only.
    - L7396–7397 → L7400–7401, the same block, case (d) (the board file): "put back again" kept nothing (`null`) and now
      keeps S1 (`'S1'`). Why: S1 was saved only in the board file.
    - L7398 → L7402, case (d): the reopen after the Save showed S1 with K kept (`['S1', 'K']`) and now shows K with S1 kept
      (`['K', 'S1']`). Why: the file is newer than the copy K came from, K is unsaved and S1 is kept, so the file's copy is
      not loaded over K.
    Each was run both ways: the old text fails on the new board, and the new text fails on the board before.
  - **Mutations (23):** `v200-u19-putback-keeps-nothing-saved`, `-putback-promise-unkept`, `-putback-question-unsaid`,
    `-swap-status-names-saver`, `-swap-title-unsaved`, `-swap-menu-replaced`, `-putback-store-at-putback`,
    `-putback-folder-keeps-nothing`, `-putback-needs-handle`, `-putback-again-unsaved-said`, `-putback-again-any`,
    `-swap-saved-forgotten`, `-cancel-says-reopen`, `-swap-status-by-kept`, `-swap-title-any-kind`, `-swap-menu-any-kind`,
    `-putback-folder-base-any`, `-putback-words-swap-file`, `-cancel-swap-only`, `-putsavedgen-zero`,
    `-asput-ignores-edits`, `-putback-keeps-own-only` and `-putback-locked-asks`; each caught by the focused block (the
    seven new ones and eight older ones on the final copy; the other eight on the previous round's copy, where the same
    checks ran); full-suite sensitivity runs in the final-tree queue.
  - **Not covered:** the file's own Change journal after K's Save keeps no trace of S1; S1 and its journal are in the kept
    copy. The HOLD ON still calls the person's own save "their changes" (the triage's O1), and after a take-the-pen route
    the put-back status still names the writer the kept work came from ("which Bob saved after it"). Reopened before any Save
    after a put-back, the "newer copy was not loaded" message calls S1 both "a newer copy" and the "earlier work" kept aside.
    For work kept by an opening or by Load theirs, the question still names the place by the kind of the kept copy: "still
    in the saved file it came from" when what is on screen was then saved only to the shared folder, and "still in the
    shared folder" when it was saved only to the board file. On the classic route, where this browser's own copy is the
    newer one and nothing is kept aside, the HOLD ON's Cancel line still names a reopen, which does not load the file's copy
    there. The Cancel line's ⬅ Import replaces the work on screen after its own "CONFLICT … will DISCARD" question, while the
    slot holds the other copy. All of these are wording points for Brad, not changed here. The restore of the kept work after
    a load refused for another reason (a kept copy built for a different service list) is not driven by a check. A newer copy
    from another browser, arriving in the file after the put-back's Save, is lost on the HOLD ON's OK (above). A HOLD ON
    answered OK over another writer's file copy, not after a put-back, still leaves that copy only in Teams version history.
    A second tab of the same browser (U20) and a real browser (Chromium) were not run.
```

### F2.11.2 "Unresolved after R1–R5" (`fr2/drafts/UNRESOLVED-U19.md`)

"Unresolved after R1–R5 (11 Oct)" (NEXT-VERSION.md) -- fix round 2's text, superseding fix round 1's (§FR.11.2) and the
build's 12.2.

The U2 bullet's last sentence, "Its separate reopening and adoption findings stay open in the ledger (U15–U20).", becomes:

```
    Its separate reopening and adoption findings stay open in the ledger (U15–U18 and U20); U19 is built (below).
```

Add a new bullet after the U14 bullet:

```
  - **U19: built as its own commit** (the lead's decision under Brad's "Don't wait for me", 12 Oct, about 5:30 PM ET):
    ↶ Put back keeps what is on screen aside in the kept work's place, saved or not and whoever saved it, unless 💾 Save
    writes to the shared folder at the put-back and what is on screen is the folder's own copy. So 💾 Save's HOLD ON answered
    OK no longer leaves the work that was on screen at the put-back in no copy this board can reach, whichever way 📡 Live
    view's switch is set by the Save (above). While work is kept aside, the HOLD ON's Cancel advice names ⬅ Import, not a
    reopen; while a locked cycle is on screen, ↶ Put back is refused at once. Open, for the lead or Brad to accept knowingly:
    the board keeps one copy aside, so a newer copy saved into the file from another browser after the put-back's Save is not
    loaded on a reopen while that copy is kept, and the next Save's HOLD ON answered OK leaves it only in Teams version
    history (on the board before, the same route lost the copy the put-back replaced instead). Open, as wording points for
    Brad: the HOLD ON's "their changes" for the person's own save (O1); the put-back status naming the earlier writer after a
    take-the-pen route; the "newer copy was not loaded" message naming S1 twice on a reopen before any Save; the put-back
    question naming the place by the kind of the kept copy for work kept by an opening or by Load theirs; the HOLD ON's Cancel
    line still naming a reopen on the classic route, where this browser's own copy is the newer one; and the top bar's
    "Unsaved changes" after a saved copy is put back. The top bar's "Saved" on a reopen while the work on screen is unsaved by
    the record is the board's existing opening behaviour (U15).
```

### F2.11.3 UNRESOLVED-LEDGER.md (`fr2/drafts/LEDGER-U19.md`)

UNRESOLVED-LEDGER.md -- fix round 2's text, superseding fix round 1's (§FR.11.3) and the build's 12.3. `<sha>` and `<time>`
are the lead's. Fix round 1's proposed new row for the top bar's "Saved" is WITHDRAWN: it is the existing U15 (the money
verifier's SF-3); the new evidence is appended to U15 below instead.

Append to the Status cell of the first U19 row:

```
 **Built as its own commit `<sha>` (<time> ET)** under the lead's decision of 12 Oct (Brad, about 5:30 PM ET: "Don't wait
 for me."): board `7a6e29cb`, audit-import `424cd9ae`, mutate `07b53964`. `keptPutBack` keeps what is on screen aside in the
 kept work's place, saved or not and whoever saved it, as unsaved work always was, unless 💾 Save writes to the shared
 folder at the put-back and what is on screen is the folder's own copy
 (`const keepScreen=nowUnsaved || !driveStoreOn() || driveBaseOf(mySlug())!==(+MS.ts||0);`): decided at the put-back, so
 📡 Live view's switch turned back to "○ Just watching" before the Save cannot leave S1 unkept, with the folder empty or
 holding an older copy of the same browser's work. The question says so; when what is on screen is the folder's own copy
 and the kept copy was kept at a put-back, it names the shared folder, not the saved file. A saved copy kept this way and
 put back unchanged is not said to have "changes no saved copy has". The words for a copy kept at a put-back ('swap') no
 longer call it unsaved or replaced, in the top bar, 📁 File and the put-back status. While work is kept aside, the HOLD
 ON's Cancel line and the status after Cancel name ⬅ Import only, not a reopen, which there does not load the file's copy
 (also the board's earlier routes: unsaved work put back, and work kept by an opening). While a locked cycle is on screen,
 ↶ Put back is refused at once ("Loading a board is off …"): nothing asked, the kept work not touched. Focused block
 "v2.00 (U19)": 136 checks; 68 fail on the board before (`fce8a391`, product d66dd60), none of them a control; all pass
 after; all 68 controls pass on both. Routes: file-after, file-retry, ui-after (📁 File and the note editor), picker-after,
 pen-after (two keys, ✍ Take the pen both ways), a colleague's copy on screen, Live view switched between the put-back and
 the Save (empty folder; folder holding an older copy), and a reopened page with no file handle in memory; S1 is kept and
 reachable after the Save and after reopening on each. Three existing expectations and one comment changed, each listed
 file:line old → new in the NEXT-VERSION entry: v1.89 "the file is newer" (audit-import L3512 → L3512–3514), and U2 put
 back waits (L7326 → L7328, comment; case (d) L7396–7398 → L7400–7402). Twenty-three mutations, each caught by the block
 (fifteen of them re-run on this copy, the other eight on the previous round's).
 Open, for the lead or Brad to accept knowingly: the board keeps one copy aside, so after the put-back's Save a newer copy
 saved into the file from another browser (N2) is not loaded on a reopen while S1 is kept, and the next Save's HOLD ON
 answered OK writes the new work over N2, which is then only in Teams version history (the money verifier's W4,
 `rec/L6/u19/verify-money-r2`, F-p1-W-on-vfr; on the board before, the same route lost S1 instead). Open, as wording points:
 - the HOLD ON's "their changes" for her own save (O1), and the put-back status naming the earlier writer after a
   take-the-pen route;
 - on a reopen before any Save after a put-back, the "newer copy was not loaded" message calls S1 both the newer copy and
   the earlier work kept aside;
 - the HOLD ON's Cancel line still names a reopen on the classic route (this browser's own copy the newer, nothing kept);
   with work kept aside its ⬅ Import replaces the work on screen after its own "CONFLICT" question;
 - the top bar says "Unsaved changes" after a saved copy is put back (a put-back counts as a change, U2);
 - for work kept by an opening or by Load theirs, the question names the place by the kind of the kept copy: "still in the
   saved file" when what is on screen was then saved only to the shared folder, "still in the shared folder" when only to
   the board file (the builder's probe P2, `rec/L6/u19/fr2/probe`);
 - the file's Change journal keeps no trace of S1 (S1 is in the kept copy).
 Not driven by a check: the restore of the kept work after a load refused for another reason (a kept copy built for a
 different service list). The full audit-import and audit-board runs, and the final-tree mutation queue, are the lead's.
```

Append to the Status cell of the P1 table's U19 row:

```
 Built: see the U19 row (`<sha>`).
```

Append to the Status cell of the first U15 row (new evidence; not U19's to fix):

```
 More evidence (12–13 Oct, U19 track, `rec/L6/u19`): on the board before U19 (`fce8a391`), ordinary editing then a reopen
 before any Save shows "Saved <time>" with base.dirty true (verify-money-r1, V2b); the browser-newer opening does the same
 on both boards (verify-tests-r1, VC2); and after U19's put-back, a reopen before any Save shows "Saved <time> · ↶ work kept
 aside" with K on screen, unsaved by the record (verify-money-r1 V2a, verify-tests-r1 VC; the U19 block's scenario (g)
 checks the record, not the header). The record and the next Save treat the work as unsaved; only the header is wrong.
```

A NEW ROW, proposed for the lead (not U19's to fix, principle 5; found by U19's money verifier, round 2, probe W7; identical
on the board before U19 and after it):

```
| U<next> | **A folder copy loaded over work saved only in the board file, then 💾 Save to the file, writes over that work without asking.** With S1 saved into the board file, 📡 Live view working out of a shared folder where Bob saved F, the refresh (`driveStorePull`) loads F (S1 is "saved", so it is not kept aside); Live view switched back to "○ Just watching"; 💾 Save writes F over S1 and asks nothing, because `LASTKNOWN` still names S1's own file save. S1 is then in no copy the board can reach, after the Save and after a reopen. Related to U29 (`adoptShared` in file mode) and U17, but a different path. Possible fixes (not built): keep that work aside by U19's rule when a folder copy replaces it, or clear `LASTKNOWN` so the next file Save asks. | U19 money verifier r2, probe W7 (`rec/L6/u19/verify-money-r2/probe/wblock.mjs.txt`), 13 Oct | Measured on the board before U19 (`fce8a391`, F-p1-W-on-vbase) and on U19's fix round 1 copy (`f6ac4b9d`, F-p1-W-on-vfr): identical; by code unchanged at `7a6e29cb` | Open |
```

and its P table row:

```
| U<next> | P1 | S1 saved into the board file; a Live view refresh loads a folder copy over it (nothing kept); Live view switched off; 💾 Save writes over S1 without asking; S1 in no copy the board can reach. | Measured on `fce8a391` and `f6ac4b9d` (W7); by code at `7a6e29cb`. | Open. |
```

## F2.12 What this round supersedes (fix round 1 and the build record are kept as they were; read them with this list)

- **The commit's copy and blobs.** Fix round 1's `fr/c1` (board `f6ac4b9d`, audit-import `cfaeac17`, mutate `9028eaa8`)
  and the build's `c1` are superseded by `fr2/c1`: board `7a6e29cb`, audit-import `424cd9ae`, mutate `07b53964`. Both older
  copies stay on disk unchanged, as their verifiers checked them.
- **§FR.1 and §FR.3, "every word the board says stays true after the operation lands".** Refuted by the money verifier's
  W1 / the tests verifier's VY-E (MF-A); fixed here (§F2.3). Two older cases of the same sentence remain, listed (P2).
- **§FR.4's counts** (104 checks, 50 failing on the base, 54 controls) are superseded by 136, 68 and 68 (§F2.4).
- **§FR.6's "All 16 U19 entries are caught"** still holds; there are now 23 entries (§F2.6).
- **§FR.9 mcount** (`fr/c1` 1344/1344) is superseded by `fr2/c1` 1351/1351 (§F2.9).
- **§FR.11 drafts** are superseded by §F2.11. In particular: fix round 1's proposed new ledger row for the top bar's "Saved"
  is withdrawn (it is U15); the Unresolved bullet's "no longer leaves work saved only in the board file in no copy" is
  scoped to the work on screen at the put-back; W4 and W7 are added; the keep clause is quoted exactly.
- **§FR.13's open item "the question asked before a locked view refuses (V5)"** is closed: ↶ Put back is refused at once
  under a locked view (money SF-5).
- **§FR.3's comment wording "stays in the folder whatever Save does next"** is replaced in the code (money minor).

## F2.13 What I did not do, and rule deviations (plainly)

**Not done:**
- **Not run (the lead's):** the full audit-import and audit-board, and the mutate sweep. `mutate.mjs` was read as text only
  (`mcount.py`, `mkmut.py`); nothing imported or ran it.
- **Not run:** Chromium, Playwright and the verify:grid tools.
- **Not changed in the board (open, in the drafts):** the HOLD ON's "their changes" (O1); the put-back status after a
  take-the-pen route; the "newer copy was not loaded" message naming S1 twice; "Unsaved changes" after a saved copy is put
  back; the place word for work kept by an opening or by Load theirs (P2-a, P2-b, identical on the base); the Cancel line's
  reopen advice on the classic route, and its ⬅ Import advice replacing the work on screen after its own question (money
  minor); the file's Change journal (S1 lives in the kept copy); the `0===0` edge (money minor, no route: §F2.2); W4 (one
  kept slot; open for the lead or Brad to accept); W7 (its own row, not U19's).
- **Not tested:** the restore of the kept work when a load is refused for another reason than a locked view (a kept copy
  built for a different service list, through `svcGuardImport`): the money verifier's `vm-no-restore` would now survive the
  U19 block, since (y) no longer reaches the restore line. On the base that line already guarded unsaved work the same way.
- **Memory (a decision for the lead, not changed):** the U19 block opens about 90 boards and holds them until its end, as
  every v2.00 block holds its own. Measured with `fr2/bin/runner-rss.mjs` (bin/runner.mjs plus one line that prints the
  process's peak resident memory): the U19 harness peaks at **2752 MB** on `fr2/c1` (`F-f2c-rss-U19.fr2c1-on-fr2c1`), the
  two U2 blocks together at 1086 MB (`F-f2c-rss-U2.fr2c1-on-fr2c1`). A measurement-only variant that closes the boards of
  each finished scenario (`bootRelease(__bm, keepBoards()); await settleBoards();` before each scenario after the first;
  `fr2/probe/var/mkvar.py`, harness `U19var.mjs` blob `3fc427f3`) passes 136/136 and peaks at **1182 MB**
  (`F-f2c-rss-U19var-on-fr2c1`). I did not adopt it: the existing v2.00 blocks each release once, at their end, and the
  rule is to follow them exactly. Under today's machine load (others holding 11–14 GB of 16 GB), six of my U19 mutant
  runs were killed from outside (five with exit 137 well before the 600 s cap, one with its wrapper gone and no end
  record; `dmesg` shows the memory-cgroup OOM killer at work in the shared cgroup; §F2.6); each was re-run. From 3:04 PM ET
  the remaining U19 mutant runs used the variant harness `U19var.mjs` (the same 136 checks; §F2.6).
- **Not re-run on `fr2/c1`:** ten older mutation entries, and `-putback-folder-keeps-nothing` through the U19 block (it was
  re-run through U2) (listed in §F2.6). Their board lines and the scenarios that
  catch them are unchanged; every one was caught on `fr/c1` (§FR.6, reproduced by the tests verifier); the final-tree queue
  is the lead's.
- **Not re-run:** the base-only runs (the base board and harnesses are byte-identical to fix round 1's), and the crossed
  "new text on the base" runs of U2 and v1.89 (harness blobs unchanged).
- **Not touched:** nothing was committed, staged or pushed. The scratch clone `git/fr2c1` is `--shared` and only reads
  orbit-board's objects; it was never committed in. The board stays the empty template; all data is synthetic, made at run
  time.

**Deviations from the run rules, disclosed:**
- **Read-only commands ran without `setsid -w timeout -k 10 600`:** `cat`, `sed -n`, `grep`, `ls`, `diff` to the screen,
  `cmp`, `git hash-object`, `git diff --stat`/`git log` (read-only, in orbit-board), `date`, `nproc`, `uptime`, `free`, `ps`;
  `mkdir -p` of my own directories, `chmod +x`, `ln -s` of my run directory's links, `cp` of harness and log files inside my
  directory. The README parts, drafts and scripts were written with the editor tool or a heredoc. Small `python3 -I` edits of
  my own scripts and drafts (the P2 probe block, `muttable2.py`, `runner-rss.mjs`'s copy) and analyses of my own outputs
  (`bin/tally.py`, `bin/fails.py`, inline tallies, `muttable2.py`, `scentable.py`) ran unwrapped, as did three `sed -i`
  on my own `muttable2.py` and `assemble.sh`, and the read-only `dmesg`, `pgrep` and `awk` used to look for the kills.
- **Every node run went through `run.sh`** (600 s cap, the lock check, PIDs), itself wrapped by `bx.sh`. Every script that
  writes the copy, harnesses, mutants, clone, diffs or mcount went through `bx.sh`.
- **One Bash call ran two bounded runs one after the other** (`F-f2b-v189…` then `F-f2b-v195kept…`); every other run had
  its own call. Each was bounded at 600 s; that pair's sequence was not.
- **Waits** were background `until … sleep 5` loops on my own output files; none was stopped.
- **At most two of my node processes ran at once;** after the first kills (2:09 PM ET) U19 harness runs went one at a time
  until memory freed (2:31 PM ET).
- **No recorded process was killed by me,** by PID, name or pattern. The exit-137 runs were killed from outside my runs.
- **One killed run's log was overwritten by its re-run under the same label** (`M-f2A-v200-u19-asput-ignores-edits…`,
  first run 2:05 PM ET); its record stays in `logs/runs.txt` and `pids.txt`, and it had recorded 121 of 136 checks, none
  failing, when it was killed. Later re-runs used new labels (`M-f2A2-…`), and the killed logs were copied to
  `*.killed137*.log` first.
- **The lock file** `AUDIT_IMPORT_RUNNING` was absent at every run's start; no run waited and none was skipped.

## F2.14 PIDs

`pids.txt` lists every bounded command's `timeout` PID and its child, with the time, the label and the command. Lines 1–277
are the build's, 278–436 fix round 1's, and **437 onward this round's** (1:31 PM ET onward; labels `bx:fr2-*`, `bx:f2*`,
`bx:M-f2*`, `F-f2a-*`, `F-f2b-*`, `F-f2c-*`, `M-f2A-*`, `M-f2A2-*`, `M-f2B-*`, `M-f2B2-*`, `M-f2B3-*`, `M-f2C-*`,
`S-*-fr2c1`). No PID was killed by me.

## F2.15 Appendix: this round's exact diffs

Against the base, the whole commit as it now stands: `fr2/diffs/c1-board.diff`, `fr2/diffs/c1-mutate.diff`,
`fr2/diffs/c1-audit-import.diff` (all three: `fr2/diffs/c1-all.diff`). What this round changed from fix round 1's `fr/c1`:

### fr2/diffs/fr1-to-fr2-board.diff

```diff
--- a/prioritization-board-grid.html
+++ b/prioritization-board-grid.html
@@ -6955,6 +6955,10 @@
   // Nothing is changed: the kept work stays kept and what is on screen stays as it is, to be put back once the save is done.
   // Said in the past tense: a quiet autosave says nothing when it lands, so this line can still be on screen after it.
   if(_saveBusy){ setStat('⏳ <b>Not put back</b>: a save was under way. Nothing was changed: the kept work is still kept, and what is on screen is unchanged. Put it back once the save has finished (\u21b6 work kept aside, in the top bar).'); render(); return; }
+  // v2.00 (U19): NOT WHILE A LOCKED CYCLE IS ON SCREEN. A load is refused there, and what is on screen is the locked view, not
+  // the work: the question spoke of the view, and the view was kept aside in the kept work's place until the refusal put the
+  // kept work back. Refused at once, as Save is: nothing is asked and the kept work is not touched.
+  if(cycBlock('Loading a board')) return;
   // WORK ON SCREEN THAT NO SAVED COPY HAS IS KEPT IN ITS PLACE (v1.95, item 50): putting work back
   // never throws away the work it replaces. The slot it frees takes what is on screen.
   const nowUnsaved=!!(DIRTY || baseGet().dirty);
@@ -6963,7 +6967,7 @@
   // and then the work that was on screen was in no copy this board could reach. The shared folder keeps the copy a save
   // replaces in its history; a board file does not. So what is on screen is kept aside in its place whether or not it is
   // saved, as unsaved work always was -- unless Save writes to the shared folder now and what is on screen IS the folder's
-  // copy (the one it was last loaded from or written to there), which stays in the folder whatever Save does next. Decided
+  // copy (the one it was last loaded from or written to there), which a Save there first keeps in the folder's history. Decided
   // here, at the put-back, not by where Save goes now alone: 📡 Live view's switch can move Save to the board file before the
   // Save, and work saved only in that file was then written over with none kept. No room to keep it: nothing is changed (saved
   // work on screen used to be put back without being kept, so without needing room).
@@ -6971,11 +6975,15 @@
   // v2.00 (U19): a copy kept at a put-back can be saved work. Put back in its turn it counts as a change (U2), though it may
   // have none that no saved copy has: until the next change the question says what is true either way.
   const asPut=nowUnsaved && _putSavedGen===_saveGen;
+  // v2.00 (U19): where what is on screen came from. The kind of the kept copy says so for work kept by an opening or by Load
+  // theirs; a copy kept at a put-back says nothing about it, and what is on screen may then be the shared folder's own copy,
+  // which was never written to the board file.
+  const scrWhere=(k.meta.why==='swap' && +MS.ts && driveBaseOf(mySlug())===(+MS.ts||0))? 'the shared folder' : keptWhere(k.meta);
   if(!confirm('Put back the work this browser kept aside on '+fmtTs(k.meta.t)+'?\n\n'
     +'What is on screen now is replaced by it. '
     +(nowUnsaved? (asPut? 'What is on screen now was put back and has not been saved since, so it is kept aside in its place — nothing is lost.'
                        : 'What is on screen now has changes no saved copy has, so it is kept aside in its place — nothing is lost.')
-                : 'What is on screen now is still in '+keptWhere(k.meta)+' it came from, and 💾 Save will ask before writing over that.'
+                : 'What is on screen now is still in '+scrWhere+' it came from, and 💾 Save will ask before writing over that.'
                   +(keepScreen? ' It is also kept aside in its place, so it is not lost if Save does.' : '')))) return;
   let st; try{ st=JSON.parse(k.raw); }catch(e){ setStat('⚠ The work kept aside could not be read ('+esc(e.message)+'). It is still kept; nothing was changed.'); return; }
   let swapped=null;
```

### fr2/diffs/fr1-to-fr2-mutate.diff

```diff
--- a/tools/export-audit/mutate.mjs
+++ b/tools/export-audit/mutate.mjs
@@ -4336,6 +4336,29 @@
   { id: "v200-u19-swap-menu-any-kind", area: "syncBtns", what: "📁 File calls work kept by Load theirs (the shared folder) “what was on screen when other work was put back”",
     find: "+(_keptMeta.why==='swap'? 'what was on screen when other work was put back'",
     repl: "+(_keptMeta.why!=='file'? 'what was on screen when other work was put back'" },
+  // v2.00 (U19, fix round 2): the folder holding an older copy; the question's words for the folder's own copy; Cancel's advice
+  // with work kept by an opening; the question on a fresh page and after a change; a colleague's copy; a locked cycle on screen.
+  { id: "v200-u19-putback-folder-base-any", area: "keptPutBack", what: "↶ Put back keeps work saved only in the board file only while this browser has never loaded or written a shared-folder copy: once the folder holds an older copy of its own, working out of it at the put-back keeps nothing; the switch turned back to ○ Just watching, Save's HOLD ON answered OK writes the work put back over the file, and the work that was on screen is in no copy this board can reach",
+    find: "  const keepScreen=nowUnsaved || !driveStoreOn() || driveBaseOf(mySlug())!==(+MS.ts||0);",
+    repl: "  const keepScreen=nowUnsaved || !driveStoreOn() || !driveBaseOf(mySlug());" },
+  { id: "v200-u19-putback-words-swap-file", area: "keptPutBack", what: "↶ Put back's question describes what is on screen by the kind of the kept copy: with a copy kept at a put-back, it says what is on screen is “still in the saved file it came from” when it is the shared folder's own copy, never written to the board file",
+    find: "  const scrWhere=(k.meta.why==='swap' && +MS.ts && driveBaseOf(mySlug())===(+MS.ts||0))? 'the shared folder' : keptWhere(k.meta);",
+    repl: "  const scrWhere=keptWhere(k.meta);" },
+  { id: "v200-u19-cancel-swap-only", area: "_saveInPlaceFileRun", what: "the HOLD ON's Cancel line drops the reopen only while a copy kept at a put-back is kept: with work kept by an opening, it still says a reopen picks up their changes, which it does not",
+    find: "        const reo=!_keptMeta;",
+    repl: "        const reo=!(_keptMeta && _keptMeta.why==='swap');" },
+  { id: "v200-u19-putsavedgen-zero", area: "keptPutBack", what: "on a freshly opened page, before any change, ↶ Put back says what is on screen was put back and has not been saved since, though it has changes no saved copy has",
+    find: "let _putSavedGen=-1;",
+    repl: "let _putSavedGen=0;" },
+  { id: "v200-u19-asput-ignores-edits", area: "keptPutBack", what: "after a saved copy is put back and then edited, ↶ Put back still says it was put back and has not been saved since",
+    find: "  const asPut=nowUnsaved && _putSavedGen===_saveGen;",
+    repl: "  const asPut=nowUnsaved && _putSavedGen>=0;" },
+  { id: "v200-u19-putback-keeps-own-only", area: "keptPutBack", what: "↶ Put back keeps saved work only when the person on screen saved it: a colleague's copy, saved only in the board file, is not kept, and Save's HOLD ON answered OK writes the work put back over it",
+    find: "  const keepScreen=nowUnsaved || !driveStoreOn() || driveBaseOf(mySlug())!==(+MS.ts||0);",
+    repl: "  const keepScreen=nowUnsaved || ((MS.by||'')===whoAmI() && (!driveStoreOn() || driveBaseOf(mySlug())!==(+MS.ts||0)));" },
+  { id: "v200-u19-putback-locked-asks", area: "keptPutBack", what: "↶ Put back runs while a locked cycle is on screen: it asks its question about the locked view and keeps the view aside in the kept work's place until the load is refused",
+    find: "  if(cycBlock('Loading a board')) return;\n",
+    repl: "" },
   // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.
   { id: "v200-r3-landed-view-unsaid", area: "_driveStorePushRun", what: "a folder save that lands while a locked view is on screen says “🔒 Not kept — PB27 is a locked view. ✅ Saved …” again, naming no plan (or, quiet, leaves persist's refusal on screen)",
     find: "  if(CYCVIEW){ _cycRefusedAt=0; setStat('✅ <b>Saved the working plan</b> of '+esc(APPN_LBL[ap]||ap)+' FY'+(fy%100)+' to the shared folder — '\n    +Math.round(body.length/1024)+' KB, built before '+blLbl(CYCVIEW)+' was put on screen. '+blLbl(CYCVIEW)+' is a locked view: nothing in it '\n    +'is saved. Everyone sees the working plan on their next refresh.'+penNote+lateNote); render(); return true; }\n",
```

### fr2/diffs/fr1-to-fr2-audit-import.diff

```diff
--- a/tools/export-audit/audit-import.mjs
+++ b/tools/export-audit/audit-import.mjs
@@ -7815,7 +7815,10 @@
 // a reopened page with no file handle in memory. Then: K and S1 put back in turn before any Save, a reopen before any Save,
 // no room to keep what is on screen, the HOLD ON answered Cancel while work is kept aside (its advice names ⬅ Import, not a
 // reopen, which would not load the file's copy), the words for each kind of kept copy, and the controls -- the HOLD ON
-// answered Cancel, S1 never saved, the shared folder, and ordinary editing -- as they were.
+// answered Cancel, S1 never saved, the shared folder, and ordinary editing -- as they were. Fix round 2: the shared folder
+// holding an older copy of this browser's at the put-back; the question's words when what is on screen is the folder's own
+// copy; Cancel's advice with work kept by an opening; the question on a freshly opened page and after a change; a colleague's
+// copy on screen; and a locked cycle on screen, where ↶ Put back is refused at once.
 await (async () => {   // a function, not a bare block: see settleBoards() in boot.mjs
   const __bm = bootMark();
   const name = 'v2.00 (U19) — put back after a board-file save keeps what it replaces';
@@ -7872,6 +7875,9 @@
   const PUTAGAINQ = 'What is on screen now was put back and has not been saved since, so it is kept aside in its place — nothing is lost.';
   const CANCEL_IMPORT = 'Cancel — don’t save (then use ⬅ Import on the current file to pick up their changes first).';
   const CANCELLED_IMPORT = 'Save canceled — Alice’s changes are untouched. ⬅ Import this file to load their version, then redo your edits.';
+  // The question's sentence when what is on screen is the shared folder's own copy: the folder is named, whatever kind of copy
+  // is kept, and nothing is kept in its place.
+  const FOLDQ = 'What is on screen now is still in the shared folder it came from, and 💾 Save will ask before writing over that.';
   // 📡 Live view's own switch, reached through 📁 File → 📡 Live view…: "● Working out of this folder" pressed (it turns to
   // "○ Just watching", and 💾 Save writes the board file again); then the panel's ✕ Close.
   const liveSwitchOff = async ev => { const o = await fileMenu(ev, 'mRun(toggleLive)');
@@ -8201,9 +8207,131 @@
     await clickSave(A.ev); await pause(20); const q2 = qs(A.ev).length; await A.ev(`driveResolve('mine')`); await pause(20);
     chk(name, sc, 'K saved over the folder’s copy: one question; K in the folder, saved; S1 still kept (a CONTROL)',
       J([qs(A.ev).length - q2, fold.note(2027, 'A'), ...unsaved(A.ev), kept(A.ev)]), J([1, K, false, false, false, [S1, 'swap']]));
-    const q3 = qs(A.ev).length; clickPutBack(A.ev);
+    const q3 = qs(A.ev).length; clickPutBack(A.ev); const qr = qs(A.ev).slice(q3);
     chk(name, sc, 'S1 put back: one question; nothing kept in its place (K is the folder’s own copy); the board states the rule Save follows, not who saved after it',
-      J([qs(A.ev).length - q3, scr(A.ev), kept(A.ev), status(A.ev).includes(SWAPSAID), / saved after it\./.test(status(A.ev))]), J([1, S1, null, true, false])); }
+      J([qr.length, scr(A.ev), kept(A.ev), status(A.ev).includes(SWAPSAID), / saved after it\./.test(status(A.ev))]), J([1, S1, null, true, false]));
+    chk(name, sc, 'and the question says K is still in the shared folder it came from -- not the saved file, which K was never written to',
+      qr.length === 1 && qr[0].endsWith(FOLDQ), true); }
+  // (s) THE SHARED FOLDER HOLDS AN OLDER COPY OF THIS BROWSER'S, NOT WHAT IS ON SCREEN. S0 saved to the folder; 📡 Live view
+  // switched back to the file; S1 typed and saved into the board file only; working out of the folder again; ↶ Put back;
+  // switched back; 💾 Save, HOLD ON answered OK; reopened. What is on screen at the put-back is not the folder's copy (S0 is).
+  { const sc = '(s) the board file: the folder holds S0, an older copy; S1 saved only in the file; ↶ Put back with the folder on; switched back; 💾 Save, OK; reopened';
+    const S0 = 'U19-S0-FOLDER';
+    const { A, f } = await inFile();
+    const fold = folder(); connect(A.ev, A.w, fold);
+    A.ev(`setNote('A',${J(S0)}); 'ok'`); await pause(5); let q0 = qs(A.ev).length; await clickSave(A.ev); await pause(20); const qa = qs(A.ev).length - q0;
+    const sw1 = await liveSwitchOff(A.ev);
+    A.ev(`setNote('A',${J(S1)}); 'ok'`); await pause(5); q0 = qs(A.ev).length; await clickSave(A.ev); await pause(20); const qb = qs(A.ev).length - q0;
+    chk(name, sc, 'S0 saved to the folder; switched back; S1 saved into the board file only; nothing asked; saved; K kept aside by the opening (a CONTROL)',
+      J([qa, ...sw1, qb, fold.note(2027, 'A'), fileNote(f.content, 'A'), ...unsaved(A.ev), kept(A.ev)]),
+      J([0, 'clicked', 'clicked', 0, S0, S1, false, false, false, [K, 'file']]));
+    connect(A.ev, A.w, fold);
+    await putBackK(A, sc);
+    const sw2 = await liveSwitchOff(A.ev);
+    q0 = qs(A.ev).length; await clickSave(A.ev); await pause(20); saveK(A, f, sc, qs(A.ev).slice(q0));
+    chk(name, sc, 'switched back before 💾 Save; after it: S1 is kept aside, and its text is in this browser’s storage',
+      J([...sw2, where(A.ev, f, S1), anywhere(A.ev, f, S1)]), J(['clicked', 'clicked', ['kept'], true]));
+    const { B, fB } = await reopen(A, f);
+    chk(name, sc, 'reopened: K on screen and in the file, saved; S1 kept aside', J([scr(B.ev), fileNote(fB.content, 'A'), ...unsaved(B.ev), where(B.ev, fB, S1)]),
+      J([K, K, false, false, false, ['kept']])); }
+  // (t) THE QUESTION'S WORDS WHEN WHAT IS ON SCREEN IS THE SHARED FOLDER'S OWN COPY, from the board file: S1 saved; K put back
+  // (S1 kept); a shared folder connected, and 💾 Save writes K there while the board file still holds S1; ↶ Put back S1. K is
+  // the folder's own copy, so nothing is kept in its place, and the question names the shared folder, not the saved file, which
+  // K was never written to. 💾 Save then asks before it writes S1 over K, and K stays in the folder's history.
+  { const sc = '(t) the board file: S1 saved; K put back; 💾 Save writes K to a shared folder; ↶ Put back S1; 💾 Save, Save yours over theirs';
+    const { A, f } = await inFile();
+    await savedS1(A, f, sc);
+    await putBackK(A, sc);
+    const fold = folder(); connect(A.ev, A.w, fold);
+    let q0 = qs(A.ev).length; await clickSave(A.ev); await pause(20);
+    chk(name, sc, '💾 Save with the folder on: nothing asked; K in the folder, saved; the board file still holds S1; S1 still kept aside',
+      J([qs(A.ev).length - q0, fold.note(2027, 'A'), fileNote(f.content, 'A'), ...unsaved(A.ev), kept(A.ev)]), J([0, K, S1, false, false, false, [S1, 'swap']]));
+    q0 = qs(A.ev).length; const r = clickPutBack(A.ev); const q = qs(A.ev).slice(q0);
+    chk(name, sc, '↶ Put back S1: one question, saying K is still in the shared folder it came from (not the saved file); S1 on screen, unsaved; nothing kept in its place',
+      J([r, q.length, q.length === 1 && q[0].endsWith(FOLDQ), scr(A.ev), ...unsaved(A.ev), kept(A.ev)]), J(['clicked', 1, true, S1, true, true, true, null]));
+    q0 = qs(A.ev).length; await clickSave(A.ev); await pause(20);
+    chk(name, sc, '💾 Save asks before writing S1 over K: refused with the choice, nothing asked, K still the folder’s copy',
+      J([/Nothing was written/.test(status(A.ev)) && /Save yours over theirs/.test(status(A.ev)), qs(A.ev).length - q0, fold.note(2027, 'A')]), J([true, 0, K]));
+    const hist = () => Object.values((fold.root.dirs.history || { files: {} }).files).map(t => { try { return JSON.parse(t).store.years['2027'].notes.A; } catch (e) { return '?'; } });
+    q0 = qs(A.ev).length; await A.ev(`driveResolve('mine')`); await pause(20);
+    chk(name, sc, '"Save yours over theirs": one question; S1 written to the folder, saved; K kept in the folder’s history',
+      J([qs(A.ev).length - q0, fold.note(2027, 'A'), ...unsaved(A.ev), hist().includes(K)]), J([1, S1, false, false, false, true])); }
+  // (u) THE HOLD ON ANSWERED CANCEL WHILE WORK KEPT BY THE OPENING IS KEPT. S1 typed, unsaved; Alice's other browser saves N2
+  // into the file; 💾 Save asks HOLD ON; Cancel. A reopen does not load N2 over S1 while K is kept, so the advice names ⬅ Import.
+  { const sc = '(u) the board file: K kept by the opening; S1 unsaved; another save (N2) lands; 💾 Save, HOLD ON answered Cancel; reopened';
+    const N2 = 'U19-N2-OTHER';
+    const { A, f } = await inFile();
+    A.ev(`setNote('A',${J(S1)}); 'ok'`); await pause(5);
+    const A3 = boot({ html: f.content }); await pause(80); wire(A3.ev, 'Alice', KEY.alice); const f3 = disk(A3.w, f.content);
+    A3.ev(`setNote('A',${J(N2)}); 'ok'`); await pause(5); await A3.ev('saveInPlaceFile()'); await pause(5);
+    f.content = f3.content;   // the other browser's save lands in the same file
+    const c = await cancelSave(A);
+    chk(name, sc, '💾 Save, Cancel: one HOLD ON, whose Cancel line names ⬅ Import only, no reopen; the board says the same; nothing written; K kept',
+      J([...c, fileNote(f.content, 'A'), scr(A.ev), kept(A.ev)]), J([1, true, true, false, N2, S1, [K, 'file']]));
+    const { B, fB } = await reopen(A, f);
+    chk(name, sc, 'reopened: N2 is not loaded over S1 while K is kept, and the board says so (a CONTROL: the advice above is true)',
+      J([scr(B.ev), kept(B.ev), fileNote(fB.content, 'A'), /the newer copy was not loaded and nothing was lost/.test(status(B.ev))]), J([S1, [K, 'file'], N2, true])); }
+  // (v) CONTROL: A FRESHLY OPENED PAGE, NOTHING PUT BACK ON IT. S1 typed, unsaved, after N's save, so this browser's copy is the
+  // newer one; reopened, it shows S1 with K kept. ↶ Put back at once: S1 was never put back, and has changes no saved copy has.
+  { const sc = '(v) CONTROL: reopened on this browser’s newer unsaved copy (S1), K kept; ↶ Put back before any change on the page';
+    const { A, f } = await inFile();
+    A.ev(`setNote('A',${J(S1)}); 'ok'`); await pause(5);
+    const { B } = await reopen(A, f);
+    chk(name, sc, 'reopened: S1 on screen, unsaved by the record; K kept aside (a CONTROL)', J([scr(B.ev), !!flags(B.ev).base.dirty, kept(B.ev)]), J([S1, true, [K, 'file']]));
+    const q0 = qs(B.ev).length; const r = clickPutBack(B.ev); const q = qs(B.ev).slice(q0);
+    chk(name, sc, '↶ Put back: one question saying S1 has changes no saved copy has (not that it was put back); K on screen; S1 kept (a CONTROL)',
+      J([r, q.length, q.length === 1 && q[0].endsWith(UNSAVEDQ), scr(B.ev), kept(B.ev)]), J(['clicked', 1, true, K, [S1, 'swap']])); }
+  // (w) A SAVED COPY PUT BACK, THEN CHANGED: S1 saved; K put back (S1 kept); S1 put back (K kept); S1 edited; ↶ Put back K:
+  // what is on screen now has changes no saved copy has.
+  { const sc = '(w) the board file: S1 saved; K put back; S1 put back; S1 edited; K put back again';
+    const S1E = S1 + ' EDITED';
+    const { A, f } = await inFile();
+    await savedS1(A, f, sc);
+    clickPutBack(A.ev); clickPutBack(A.ev);
+    chk(name, sc, 'K put back, then S1: S1 on screen and in the file; K kept aside', J([fileNote(f.content, 'A'), scr(A.ev), kept(A.ev)]), J([S1, S1, [K, 'swap']]));
+    A.ev(`setNote('A',${J(S1E)}); 'ok'`); await pause(5);
+    const q0 = qs(A.ev).length; const r = clickPutBack(A.ev); const q = qs(A.ev).slice(q0);
+    chk(name, sc, '↶ Put back after the edit: one question saying what is on screen has changes no saved copy has; K on screen; the edited S1 kept',
+      J([r, q.length, q.length === 1 && q[0].endsWith(UNSAVEDQ), scr(A.ev), kept(A.ev)]), J(['clicked', 1, true, K, [S1E, 'swap']])); }
+  // (x) A COLLEAGUE'S COPY ON SCREEN. Bob takes the pen and writes N into the board file; Alice reopens it (K kept aside by the
+  // opening, Bob's N on screen, saved only in the file) and puts K back; her 💾 Save is refused (Bob holds the pen), and its
+  // ✍ Take the pen… writes K once the HOLD ON is answered OK; reopened. N is kept aside in K's place, whoever saved it.
+  { const sc = '(x) the board file: Bob’s copy (N) on screen; ↶ Put back; 💾 Save refused, ✍ Take the pen…, HOLD ON answered OK; reopened';
+    const A0 = boot({ html: F1 }); await pause(80); wire(A0.ev, 'Alice', KEY.alice);
+    A0.ev(`setNote('A',${J(K)}); 'ok'`); await pause(5);
+    const Bb = boot({ html: F1 }); await pause(80); wire(Bb.ev, 'Bob', KEY.bob); const fb = disk(Bb.w, F1);
+    Bb.ev(`setNote('A',${J(N)}); 'ok'`); await pause(5);
+    await clickSave(Bb.ev); await pause(20); const bt = await takePenBtn(Bb.ev, fb);
+    const A = boot({ html: fb.content, ls: lsOf(A0.ev) }); await pause(80); wire(A.ev, 'Alice', KEY.alice); const f = disk(A.w, fb.content);
+    chk(name, sc, 'Bob’s N in the file, writer Bob; Alice reopens it: N on screen, saved; K kept aside by the opening (a CONTROL)',
+      J([bt, fileNote(f.content, 'A'), fileWriter(f.content), scr(A.ev), ...unsaved(A.ev), kept(A.ev)]), J(['clicked', N, 'Bob', N, false, false, false, [K, 'file']]));
+    const q0 = qs(A.ev).length; clickPutBack(A.ev); const q = qs(A.ev).slice(q0);
+    chk(name, sc, '↶ Put back: one question, saying N is also kept aside in its place; K on screen, unsaved; Bob’s N kept aside',
+      J([q.length, q.length === 1 && q[0].endsWith(PUTQ), scr(A.ev), ...unsaved(A.ev), kept(A.ev)]), J([1, true, K, true, true, true, [N, 'swap']]));
+    await clickSave(A.ev); await pause(20); const refused = [f.writes, /Not saved\. Bob holds the pen/.test(status(A.ev))];
+    const q1 = qs(A.ev).length; const at = await takePenBtn(A.ev, f); const q2 = qs(A.ev).slice(q1);
+    chk(name, sc, '💾 Save refused (Bob holds the pen); ✍ Take the pen…: its question, then a HOLD ON naming Bob, OK; K written, writer Alice, saved (a CONTROL)',
+      J([...refused, at, q2.length, /^Take the pen for this board file from Bob/.test(q2[0] || ''), /^⚠ HOLD ON — Bob saved this file at /.test(q2[1] || ''), fileNote(f.content, 'A'), fileWriter(f.content), ...unsaved(A.ev)]),
+      J([0, true, 'clicked', 2, true, true, K, 'Alice', false, false, false]));
+    chk(name, sc, 'after the save: Bob’s N is kept aside, and its text is in this browser’s storage', J([where(A.ev, f, N), anywhere(A.ev, f, N)]), J([['kept'], true]));
+    const { B, fB } = await reopen(A, f);
+    chk(name, sc, 'reopened: K on screen and in the file, saved; Bob’s N kept aside', J([scr(B.ev), fileNote(fB.content, 'A'), ...unsaved(B.ev), where(B.ev, fB, N)]),
+      J([K, K, false, false, false, ['kept']])); }
+  // (y) A LOCKED CYCLE ON SCREEN AT THE PUT-BACK. Loading is off there, so ↶ Put back is refused at once, as a load is: nothing
+  // is asked (what is on screen is the locked view, not the work), and the kept work is not touched. Once the view is left, the
+  // work is on screen as it was.
+  { const sc = '(y) the board file: a cycle locked; S1 saved; the locked cycle on screen; ↶ Put back; the view left';
+    const { A, f } = await inFile();
+    A.ev(`setNote('A','U19-LOCKED'); blCyc='PB'; blYr=2027; cycLock(); 'ok'`); await pause(5);
+    await savedS1(A, f, sc);
+    const k0 = keptRaw(A.ev);
+    A.ev(`cycView('PB|2027'); 'ok'`); await pause(5);
+    const q0 = qs(A.ev).length; const r = clickPutBack(A.ev); const q = qs(A.ev).slice(q0), said = status(A.ev), kv = keptRaw(A.ev);
+    chk(name, sc, '↶ Put back with the locked cycle on screen: refused at once -- nothing asked; the kept work not touched; said',
+      J([A.ev('String(CYCVIEW)'), r, q.length, kv === k0, /U19-LOCKED/.test(kv || ''), /Loading a board is off while PB27 is on screen/.test(said)]), J(['PB|2027', 'clicked', 0, true, false, true]));
+    A.ev(`cycLeave(); 'ok'`); await pause(5);
+    chk(name, sc, 'the view left: S1 on screen and in the file, saved; K kept aside byte for byte (a CONTROL)',
+      J([A.ev('String(CYCVIEW)'), scr(A.ev), fileNote(f.content, 'A'), ...unsaved(A.ev), keptRaw(A.ev) === k0]), J(['', S1, S1, false, false, false, true])); }
   } catch (e) {
     failures.push({ scenario: name, where: 'harness', what: 'the block threw: ' + String((e && e.stack) || e).slice(0, 300), got: 'threw', want: 'ran' });
   }
```

### fr2/diffs/c1-board.diff

```diff
--- a/prioritization-board-grid.html
+++ b/prioritization-board-grid.html
@@ -6944,6 +6944,9 @@
     const i=s.indexOf('\n'); return {meta:JSON.parse(s.slice(0,i)), raw:s.slice(i+1)}; }catch(e){ return null; }
 }
 function keptWhere(m){ return (m&&m.why)==='folder'? 'the shared folder' : 'the saved file'; }
+// v2.00 (U19): the count of changes (_saveGen) just after a copy kept at a put-back, saved when it was kept, was put back in its
+// turn; -1 when the last put-back was of anything else. While the count stays there, what is on screen is that copy, unchanged.
+let _putSavedGen=-1;
 function keptPutBack(){
   const k=keptCopy();
   if(!k){ _keptMeta=null; setStat('Nothing is kept aside in this browser.'); render(); return; }
@@ -6952,17 +6955,40 @@
   // Nothing is changed: the kept work stays kept and what is on screen stays as it is, to be put back once the save is done.
   // Said in the past tense: a quiet autosave says nothing when it lands, so this line can still be on screen after it.
   if(_saveBusy){ setStat('⏳ <b>Not put back</b>: a save was under way. Nothing was changed: the kept work is still kept, and what is on screen is unchanged. Put it back once the save has finished (\u21b6 work kept aside, in the top bar).'); render(); return; }
+  // v2.00 (U19): NOT WHILE A LOCKED CYCLE IS ON SCREEN. A load is refused there, and what is on screen is the locked view, not
+  // the work: the question spoke of the view, and the view was kept aside in the kept work's place until the refusal put the
+  // kept work back. Refused at once, as Save is: nothing is asked and the kept work is not touched.
+  if(cycBlock('Loading a board')) return;
   // WORK ON SCREEN THAT NO SAVED COPY HAS IS KEPT IN ITS PLACE (v1.95, item 50): putting work back
   // never throws away the work it replaces. The slot it frees takes what is on screen.
   const nowUnsaved=!!(DIRTY || baseGet().dirty);
+  // v2.00 (U19): A BOARD FILE KEEPS NO EARLIER COPY THIS BOARD CAN REACH. Work on screen saved only in the board file was not
+  // kept, since the file had it; but the next 💾 Save writes the work put back over that file once its HOLD ON is answered OK,
+  // and then the work that was on screen was in no copy this board could reach. The shared folder keeps the copy a save
+  // replaces in its history; a board file does not. So what is on screen is kept aside in its place whether or not it is
+  // saved, as unsaved work always was -- unless Save writes to the shared folder now and what is on screen IS the folder's
+  // copy (the one it was last loaded from or written to there), which a Save there first keeps in the folder's history. Decided
+  // here, at the put-back, not by where Save goes now alone: 📡 Live view's switch can move Save to the board file before the
+  // Save, and work saved only in that file was then written over with none kept. No room to keep it: nothing is changed (saved
+  // work on screen used to be put back without being kept, so without needing room).
+  const keepScreen=nowUnsaved || !driveStoreOn() || driveBaseOf(mySlug())!==(+MS.ts||0);
+  // v2.00 (U19): a copy kept at a put-back can be saved work. Put back in its turn it counts as a change (U2), though it may
+  // have none that no saved copy has: until the next change the question says what is true either way.
+  const asPut=nowUnsaved && _putSavedGen===_saveGen;
+  // v2.00 (U19): where what is on screen came from. The kind of the kept copy says so for work kept by an opening or by Load
+  // theirs; a copy kept at a put-back says nothing about it, and what is on screen may then be the shared folder's own copy,
+  // which was never written to the board file.
+  const scrWhere=(k.meta.why==='swap' && +MS.ts && driveBaseOf(mySlug())===(+MS.ts||0))? 'the shared folder' : keptWhere(k.meta);
   if(!confirm('Put back the work this browser kept aside on '+fmtTs(k.meta.t)+'?\n\n'
     +'What is on screen now is replaced by it. '
-    +(nowUnsaved? 'What is on screen now has changes no saved copy has, so it is kept aside in its place — nothing is lost.'
-                : 'What is on screen now is still in '+keptWhere(k.meta)+' it came from, and 💾 Save will ask before writing over that.'))) return;
+    +(nowUnsaved? (asPut? 'What is on screen now was put back and has not been saved since, so it is kept aside in its place — nothing is lost.'
+                       : 'What is on screen now has changes no saved copy has, so it is kept aside in its place — nothing is lost.')
+                : 'What is on screen now is still in '+scrWhere+' it came from, and 💾 Save will ask before writing over that.'
+                  +(keepScreen? ' It is also kept aside in its place, so it is not lost if Save does.' : '')))) return;
   let st; try{ st=JSON.parse(k.raw); }catch(e){ setStat('⚠ The work kept aside could not be read ('+esc(e.message)+'). It is still kept; nothing was changed.'); return; }
   let swapped=null;
-  if(nowUnsaved){
-    const m2={t:Date.now(), why:'swap', by:whoIs()||'', ts:+MS.ts||0, base:baseGet()};
+  if(keepScreen){
+    const m2={t:Date.now(), why:'swap', by:whoIs()||'', ts:+MS.ts||0, base:baseGet(), saved:!nowUnsaved || asPut};   // saved: v2.00 (U19)
     const str=JSON.stringify(m2)+'\n'+JSON.stringify(MS);
     try{ localStorage.setItem(_AP.key+'.kept', str); swapped=m2; }
     catch(e){ setStat('⚠ There is no room to keep what is on screen while the kept work is put back, so <b>nothing was changed</b>. '
@@ -6985,8 +7011,12 @@
   // count unmoved and marked the board saved, while the folder or file holds what that save wrote. Now that save finds the
   // count moved, leaves the work put back unsaved and says so, and the next Save writes it.
   persist(); _saveGen++; DIRTY=true; render();
-  setStat('↶ <b>Put back</b> the work kept aside on '+esc(fmtTs(k.meta.t))+'. 💾 Save will ask before it writes over '
-    +esc(keptWhere(k.meta))+', which '+esc(k.meta.by||'someone')+' saved after it.'
+  _putSavedGen=(k.meta.why==='swap' && k.meta.saved===true)? _saveGen : -1;   // v2.00 (U19)
+  // v2.00 (U19): work kept aside at a put-back ('swap') was not replaced by a newer save, and nobody need have saved since: the
+  // rule Save follows is said instead, which holds either way.
+  setStat('↶ <b>Put back</b> the work kept aside on '+esc(fmtTs(k.meta.t))+'. '
+    +(k.meta.why==='swap'? '💾 Save will ask before it writes over a copy saved after the one this work came from.'
+      : '💾 Save will ask before it writes over '+esc(keptWhere(k.meta))+', which '+esc(k.meta.by||'someone')+' saved after it.')
     +(swapped? ' What was on screen is <b>kept aside</b> in its place: <button type="button" class="nb lnk" onclick="keptPutBack()">put that back</button>.' : ''));
 }
 // SAVE THE KEPT WORK AS A FILE (v1.95, item 50): a board file holding it, to open or hand on. Saving it
@@ -8373,8 +8403,11 @@
         const q = LASTKNOWN
           ? '⚠ HOLD ON — '+by+' saved this file at '+fmtTs(fts)+'. That is not the save the copy you are working from came from, so their changes are not on your screen.'
           : '⚠ HOLD ON — this file was last saved by '+by+' at '+fmtTs(fts)+', and this browser cannot tell whether that was before or after the copy you are working from.';
-        if(!confirm(q+'\n\nSaving now will OVERWRITE their changes with yours.\n\nOK — overwrite anyway (their version stays in Teams version history).\nCancel — don’t save (then use ⬅ Import on the current file, or reopen it, to pick up their changes first).')){
-          setStat('Save canceled — '+esc(by)+'’s changes are untouched. Reopen or ⬅ Import this file to load their version, then redo your edits.');
+        // v2.00 (U19): while work is kept aside, a reopen does not load a newer copy over unsaved work on screen (kept work is
+        // never replaced), so then Cancel's advice names ⬅ Import only, not a reopen.
+        const reo=!_keptMeta;
+        if(!confirm(q+'\n\nSaving now will OVERWRITE their changes with yours.\n\nOK — overwrite anyway (their version stays in Teams version history).\nCancel — don’t save (then use ⬅ Import on the current file'+(reo? ', or reopen it,' : '')+' to pick up their changes first).')){
+          setStat('Save canceled — '+esc(by)+'’s changes are untouched. '+(reo? 'Reopen or ⬅ Import' : '⬅ Import')+' this file to load their version, then redo your edits.');
           return;
         }
       }
@@ -25908,7 +25941,8 @@
   // v1.89: while work is kept aside, the header says so -- an opening message can be replaced by the next.
   // v1.91 (item 29): a button -- it was a link with no address, which a keyboard never reaches.
   if(ss && _keptMeta) ss.innerHTML += ' \u00b7 <button type="button" class="keptbtn" onclick="keptPutBack()" '
-    +'title="Work this browser held that no saved copy had, kept aside '+esc(shortTs(_keptMeta.t))+'. Put it back.">\u21b6 work kept aside</button>';
+    +'title="'+(_keptMeta.why==='swap'? 'What was on screen when other work was put back' : 'Work this browser held that no saved copy had')   // v2.00 (U19)
+    +', kept aside '+esc(shortTs(_keptMeta.t))+'. Put it back.">\u21b6 work kept aside</button>';
   if(sb && _sb){
     sb.className='btn pri'; sb.textContent='\u2709 Submit input'; sb.setAttribute('onclick','pmoSubmit()');
     sb.title='Send your office\u2019s changes to the portfolio team as a small submittal file. Your work is already kept in this browser.';
@@ -26237,7 +26271,8 @@
     mi('💾 Save',"mRun(saveInPlace)",false,_SB? 'turned off in a PMO copy \u2014 use \u2709 Submit input' : 'writes back to this file, in place')+
     mi('⬇ Save a copy…',"mRun(publishState)",false,_SB? 'turned off in a PMO copy' : 'downloads a duplicate')+
     // v1.89: work this browser kept aside when a newer saved copy replaced it. Here, unfolded, as long as it is kept.
-    (_keptMeta? mi('\u21b6 Put back work kept aside\u2026',"mRun(keptPutBack)",false,'kept '+shortTs(_keptMeta.t)+' \u00b7 from before '+keptWhere(_keptMeta)+' replaced it')
+    (_keptMeta? mi('\u21b6 Put back work kept aside\u2026',"mRun(keptPutBack)",false,'kept '+shortTs(_keptMeta.t)+' \u00b7 '
+        +(_keptMeta.why==='swap'? 'what was on screen when other work was put back' : 'from before '+keptWhere(_keptMeta)+' replaced it'))   // v2.00 (U19)
       +mi('⬇ Save work kept aside as a file…',"mRun(keptSaveFile)",false,'it stays kept aside')
       +mi('✕ Discard work kept aside…',"mRun(keptDiscard)",false,'cannot be undone') : '')+
     // in a PMO copy, the one way out is unfolded on top
```

---

# Fix round (13 Oct 2026, from 9:13 AM ET)

## FR.0 Resume check

The fix round started at 9:13 AM ET, after the container restart at 9:11 AM ET. I looked for an earlier attempt of this fix
round first. Nothing in this directory is dated after the build's last write (8:11 PM ET, 12 Oct) except the two verifiers'
own directories (`verify-money-r1/`, `verify-tests-r1/`) and the workflow's `wfstate/` files. There was no "Fix round"
section, no new copy, probe, log or diff. **So there was no stopped attempt to keep or redo; this fix round is the first.**
Every build result below the line is kept as it was. The build's copy `c1/` is left exactly as the verifiers checked it.
The revised commit is a new copy, `fr/c1/`. The last run of this round began at 10:24:04 AM ET; this README was assembled
at about 10:26 AM ET. The round made 55 bounded runs (§FR.7).

## FR.1 In short

- **The commit, revised (it supersedes the build's c1):** `fr/c1/` = the read-only base + one commit. Board `f6ac4b9d`,
  audit-import `cfaeac17`, mutate.mjs.txt `9028eaa8`. audit-recon `529e36f7`, audit-board `a7c575e5` and audit-other
  `d89396b0` are unchanged.
- **Both verifiers' must-fixes are fixed:**
  - **M1 (money lens, data loss):** the keep is now decided by whether what is on screen IS the shared folder's own
    copy, not only by where 💾 Save goes at the put-back. Turning 📡 Live view's switch back to the file before the Save
    can no longer leave S1 unkept.
  - **M2 (money lens, false words):** a saved copy kept at a put-back and put back unchanged is no longer said to have
    "changes no saved copy has".
  - **MF1 (tests lens, false words):** while work is kept aside, the HOLD ON's Cancel line and the status after Cancel
    name ⬅ Import only, not a reopen, because a reopen would not load the file's copy there.
- **The cheap, clearly right should-fixes are done too:** the no-file-handle-in-memory route (SF2), the words for each
  kind of kept copy (SF3), the third press in (f), the drafts reworded (money S1, tests SF4), the HOLD ON that follows a
  refusal (money S3), and the "Saved" header moved to its own proposed ledger row (money S4, tests SF1). The rest are listed
  as open (§FR.2).
- **The board delta against the build:** 22 lines added and 7 removed. Against the base: 37 added, 10 removed.
- **The tests:** the U19 block grows from 71 to 104 checks.
  - On the base, 50 fail, and every one is outside the 54 controls. Every control passes on the base.
  - On the build's copy, 8 fail: exactly the M1, M2 and MF1 rows.
  - On `fr/c1`, all 104 pass.
  - The three existing expectations the build changed are the same three. No other existing expectation changes.
- **Mutations:** ten new entries, and the find of `v200-u19-putback-keeps-nothing-saved` follows its changed line. All 16
  U19 entries are caught (§FR.6). mcount (text only): `fr/c1` 1344 of 1344 entries match exactly once.
- **The other suites** this track may run, and `npm run check`, all pass on `fr/c1` (§FR.8).

## FR.2 Each verifier finding, and what was done

| finding | lens | done | how |
|---|---|---|---|
| **M1** Live view's switch moved between the put-back and the Save: S1 in no copy (V1) | money, must-fix | **fixed** | `keepScreen=nowUnsaved \|\| !driveStoreOn() \|\| driveBaseOf(mySlug())!==(+MS.ts\|\|0)`. This is the verifier's clause. It keeps what is on screen unless Save writes to the folder now AND what is on screen is the folder's own copy, which the folder keeps whatever Save does next. It only ever adds a keep. New scenario (m), with its CONTROL (n). New mutations: `v200-u19-putback-store-at-putback`, and `v200-u19-putback-folder-keeps-nothing` for the coverage shift the clause causes (§FR.6). The keeps-nothing-saved find was updated. The comment and the drafts were reworded. |
| **M2** K, S1, K put back in turn: the question calls S1, the file's copy, work with "changes no saved copy has" (V6) | money, must-fix | **fixed** | The 'swap' meta records `saved` (saved when kept, or such a copy put back unchanged). After putting back such a copy, the change count is remembered (`_putSavedGen`). While it is unchanged, the question says "What is on screen now was put back and has not been saved since, so it is kept aside in its place — nothing is lost." That is the verifier's sentence. Otherwise the old sentence stays, so the (j) CONTROL is unchanged. (f) gains K and S1 again and a fifth press answered Cancel. Three mutations. |
| **MF1** The HOLD ON's Cancel advice ("or reopen it", "Reopen or ⬅ Import") is false while work is kept aside (VB) | tests, must-fix | **fixed** | `const reo=!_keptMeta;` in `_saveInPlaceFileRun`. This is the verifier's change. New scenarios (p) (S1 saved, the U19 route) and (q) (S1 never saved, the base's own route, VB2), each with the reopen. New mutation `v200-u19-cancel-says-reopen`. |
| money S1 / tests SF4: the drafts overclaim ("when Save writes to a board file", "HOLD ON words unchanged and still true") | both | **fixed** | The drafts were rewritten (§FR.11). The build's §4 claim about the HOLD ON is marked superseded (§FR.12). |
| money S2: the "newer copy was not loaded" message names S1 twice on a reopen before any Save | money | **open (wording, Brad)** | It is listed under "Not covered", in the Unresolved bullet and in the ledger text. Every copy survives. |
| money S3: the lingering 'swap' copy refuses newer copies, and the next Save's HOLD ON follows | money | **fixed (drafts)** | "What users may see" now says the next 💾 Save asks HOLD ON over that newer copy, and that OK leaves it only in Teams version history. |
| money S4 / tests SF1: the top bar says "Saved" on a reopen with unsaved work | both | **moved to its own proposed ledger row** | The money verifier's V2b control shows it on the base after ordinary editing, so it is not U19's. The drafts say the top bar shows "Saved" there, and propose a new row (§FR.11). Not changed in the board: a fix would change how every opening marks the board, which is not the smallest change for U19. |
| money S5: "Unsaved changes" after a saved copy is put back | money | **open (the lead to decide)** | This is U2's rule (a put-back counts as a change). It is listed in "What users may see" and as open. |
| tests SF2: no case puts back with no file handle in memory | tests | **fixed** | New scenario (o) (VA). New mutation `v200-u19-putback-needs-handle` (the verifier's vt-keep-handle-only). |
| tests SF3: the `why==='swap'` word branches are unguarded for other kinds | tests | **fixed** | (a) gains a CONTROL (VD), and new scenario (r) (VE, VF). Three mutations, the verifier's vt-status-swapped, vt-title-notfile and vt-menu-notfile, become `-swap-status-by-kept`, `-swap-title-any-kind` and `-swap-menu-any-kind`. |
| minor: the comment "as before" | money | **fixed** | The comment now says saved work on screen used to be put back without being kept. |
| minor: (d)'s title, "no file handle remembered", although the handle is in memory by the put-back | tests | **fixed (comment)** | (d)'s comment says so and points to (o). The scenario name is unchanged. |
| minor: the question asks before a locked view refuses (V5) | money | **open** | Existing order. K is kept byte for byte and nothing changes. Listed. |
| minor: `keptWhere` says "the shared folder" for work kept by a folder load when the screen was saved only to the file | money | **open** | Existing words. Listed. |
| minor: three wrong fixes each caught by a single check | tests | **noted** | They are still caught. vt-keep-always and vt-question-always are caught by the (k) CONTROL, and are now also exercised by (n). |
| tests MF1's VB3: the classic route (browser's copy newer, nothing kept) still names a reopen | tests | **open** | The verifier asked for it to be listed, not fixed. It is not U19's route. Listed in the drafts. |

## FR.3 The board change in this round, and the six principles

The exact delta is in `fr/diffs/build-to-fr-board.diff` and in the appendix.
- **`keptPutBack`:**
  - the keep test (M1);
  - `asPut` and the question's sentence (M2);
  - `saved` on the 'swap' meta (M2);
  - `_putSavedGen` set after a put-back, and declared beside `keptWhere` (M2);
  - the comment reworded.
- **`_saveInPlaceFileRun`:** `reo` and the two Cancel lines (MF1).

How it meets each principle:
1. **Never lose any copy.** S1 is kept on the Live-view route (m), and on a reopened page with no handle (o). Each is
   reachable after the Save and after reopening. Nothing that was kept before is kept less: the new clause only adds keeps.
   The folder's own copy is still not kept twice, because the folder keeps it, as the (k) and (r) controls show.
2. **Refuse or ask rather than guess.** The keep test does not guess where Save will go. It keeps unless what is on screen
   is provably the folder's own copy, by the equality of the folder copy's time with the time of the work on screen. The
   Cancel advice names only the step that does what it says.
3. **Money and every export.** No computation or export is touched. The export and money suites pass on `fr/c1` (§FR.8).
4. **Every word stays true, after the operation lands too.**
   - The question on the M1 route now says "It is also kept aside", and it is.
   - The M2 sentence is true whether or not the file still holds the copy.
   - The Cancel lines no longer promise what a reopen will not do.
   - On a reopen after S1 is put back, the opening finds the file's own state on screen and marks it saved. The question
     then uses the saved branch, which is true.
5. **The smallest change.** One clause; one boolean on the kept copy's meta; one in-memory count; one boolean for two lines.
   No new storage key or path.
6. **Existing checks.** No existing expectation changes beyond the build's three. The crossed runs (§FR.5) show them failing
   exactly there and nowhere else.

## FR.4 The tests (audit-import, block "v2.00 (U19)", after the U13 end marker)

The block is `fr/block-u19.fr.mjs.txt`, made from the build's `v2/block-u19.v2.mjs.txt` by `fr/bin/mkblock-fr.py`, as text
only. 104 checks in all.

**What was added:**
- (a): a CONTROL for the words after putting back work kept by an opening (VD).
- (f): K put back again (the question names S1 as put back and not saved since); S1 put back again (K has changes no saved
  copy has); a fifth press answered Cancel (the same sentence, nothing changed). The existing final Save check is unchanged.
- (m): 📡 Live view working out of a folder at the put-back, then switched back through 📁 File → 📡 Live view… → its own
  "● Working out of this folder" button before 💾 Save; HOLD ON answered OK; reopened (M1, V1).
- (n) CONTROL: the switch left on; Save writes the folder and the board file keeps S1 (V1b).
- (o): a reopened page with no file handle in memory; put back; Save through the picker, OK; reopened (SF2, VA).
- (p): the HOLD ON answered Cancel with S1 kept (the U19 route), then reopened (MF1, VB).
- (q): the same with S1 never saved (VB2), then reopened.
- (r): the shared folder: work kept by Load theirs keeps its words (CONTROL); S1 kept at a put-back gets the swap words;
  K saved over theirs; S1 put back keeps nothing (K is the folder's own copy) and states Save's rule (VE, VF).
- The header comment and (d)'s comment.

**Literals.** Every expected value is a hand-written literal or a literal constant (K, N, S1, PUTQ, UNSAVEDQ, PUTAGAINQ,
CANCEL_IMPORT, CANCELLED_IMPORT, SWAP*). Board helpers are used only for observed values.

**Fails on the base, passes on the fix.** On the base, all 50 non-CONTROL checks fail and all 54 CONTROL checks pass. On
`fr/c1`, all 104 pass. On the build's c1, 8 fail: (f) 2 (M2), (m) 4 (M1), (p) 1 and (q) 1 (MF1). Each run is in §FR.7.
The failing rows on the base, by scenario: (a) 8, (b) 4, (c) 5, (d) 4, (e) 4, (f) 8, (g) 3, (h) 1, (m) 4, (o) 4, (p) 2,
(q) 1, (r) 2.

## FR.5 Existing expectations (no new change)

The fix round changes no existing expectation. The build's three, listed with file:line, old → new and why in the build
record §5, are byte-for-byte the same hunks in `fr/c1` (`fr/diffs/c1-audit-import.diff`): base L3512, L7325–7326 and
L7396–7398. Re-run on the revised board:
- **Own expectations:** U2.frc1 57/57, v189.frc1 40/40 and v195kept 10/10 on `fr/c1`.
- **Base expectations on `fr/c1`:** U2.base 2 fail, the two case (d) rows. v189.base 1 fail, "one click puts it back".
  v195kept 10/10.
- **The fix's expectations on the base:** U2 2 fail (the same rows), v189 1 fail, v195kept 10/10.
- The U2 "work put back during a save stays unsaved" case (c) passes unchanged, as in the build.

## FR.6 Mutations (text only: `rec/bin/mkmut.py` builds each mutant from `fr/c1`'s mutate.mjs.txt; nothing imports or runs mutate.mjs)

Set frA: the ten entries this round adds (the tenth, `-putback-folder-keeps-nothing`, run on its own after the chain). Set frB: the build's six, re-run on the revised copy (the find of
`v200-u19-putback-keeps-nothing-saved` follows its changed line). Set frC: the existing put-back entries. Each mutant
board differs from `fr/c1`'s board in the one intended place (`fr/mutdiff.txt`).

| set | mutation id | harness | checks | failing | failing scenarios | exit | caught | mutant board |
|---|---|---|---|---|---|---|---|---|
| frA | `v200-u19-putback-store-at-putback` | U19 | 104 | 4 | (m) 4 | 1 | yes | `aeb9f307` |
| frA | `v200-u19-putback-needs-handle` | U19 | 104 | 4 | (o) 4 | 1 | yes | `fe616779` |
| frA | `v200-u19-putback-needs-handle` | v189 | 40 | 1 | the file is newer 1 | 1 | yes | `fe616779` |
| frA | `v200-u19-putback-again-unsaved-said` | U19 | 104 | 2 | (f) 2 | 1 | yes | `5b16ef1d` |
| frA | `v200-u19-putback-again-any` | U19 | 104 | 2 | (f) 2 | 1 | yes | `51351fa9` |
| frA | `v200-u19-swap-saved-forgotten` | U19 | 104 | 1 | (f) 1 | 1 | yes | `c41e82c2` |
| frA | `v200-u19-cancel-says-reopen` | U19 | 104 | 2 | (p) 1, (q) 1 | 1 | yes | `95379a7f` |
| frA | `v200-u19-swap-status-by-kept` | U19 | 104 | 2 | (a) 1, (r) 1 | 1 | yes | `2c16b002` |
| frA | `v200-u19-swap-title-any-kind` | U19 | 104 | 1 | (r) 1 | 1 | yes | `3037cccc` |
| frA | `v200-u19-swap-menu-any-kind` | U19 | 104 | 1 | (r) 1 | 1 | yes | `f3a48e77` |
| frB | `v200-u19-putback-keeps-nothing-saved` | U19 | 104 | 47 | (a) 8, (b) 4, (c) 5, (d) 4, (e) 4, (f) 8, (g) 3, (h) 1, (m) 4, (o) 4, (p) 2 | 1 | yes | `f614932f` |
| frB | `v200-u19-putback-keeps-nothing-saved` | U2 | 57 | 2 | (d) 2 | 1 | yes | `f614932f` |
| frB | `v200-u19-putback-keeps-nothing-saved` | v189 | 40 | 1 | the file is newer 1 | 1 | yes | `f614932f` |
| frB | `v200-u19-putback-promise-unkept` | U19 | 104 | 38 | (a) 7, (b) 3, (c) 4, (d) 3, (e) 3, (f) 7, (g) 2, (h) 1, (m) 3, (o) 3, (p) 2 | 1 | yes | `0586fe1d` |
| frB | `v200-u19-putback-promise-unkept` | U2 | 57 | 2 | (d) 2 | 1 | yes | `0586fe1d` |
| frB | `v200-u19-putback-promise-unkept` | v189 | 40 | 1 | the file is newer 1 | 1 | yes | `0586fe1d` |
| frB | `v200-u19-putback-question-unsaid` | U19 | 104 | 10 | (a) 2, (b) 1, (c) 1, (d) 1, (e) 1, (f) 1, (g) 1, (m) 1, (o) 1 | 1 | yes | `4a0d988e` |
| frB | `v200-u19-swap-status-names-saver` | U19 | 104 | 3 | (a) 1, (f) 1, (r) 1 | 1 | yes | `95dfcefa` |
| frB | `v200-u19-swap-title-unsaved` | U19 | 104 | 4 | (a) 3, (r) 1 | 1 | yes | `b112c1fd` |
| frB | `v200-u19-swap-menu-replaced` | U19 | 104 | 3 | (a) 1, (c) 1, (r) 1 | 1 | yes | `08b4bbda` |
| frC | `putback-drops-screen` | U19 | 104 | 5 | (f) 4, (j) 1 | 1 | yes | `99e1e910` |
| frC | `putback-drops-screen` | U2 | 57 | 0 |  | 0 | **no** | `99e1e910` |
| frC | `putback-drops-screen` | v195kept | 10 | 0 |  | 0 | **no** | `99e1e910` |
| frC | `v200-u2-putback-gen` | U2 | 57 | 1 | (d) 1 | 1 | yes | `f8639ac5` |
| frC | `v200-u2-putback-gen` | U19 | 104 | 0 |  | 0 | **no** | `f8639ac5` |
| frC | `v200-u2-putback-while-saving` | U2 | 57 | 35 | (a) 4, (b) 5, (c) 5, (d) 4, (e) 4, (f) 4, (g) 5, (h) 4 | 1 | yes | `59a398e6` |
| frC | `v200-u2-putback-while-saving` | U19 | 104 | 7 | (b) 7 | 1 | yes | `59a398e6` |
| frA | `v200-u19-putback-folder-keeps-nothing` | U19 | 104 | 7 | (m) 4, (r) 3 | 1 | yes | `8ece111b` |
| frA | `v200-u19-putback-folder-keeps-nothing` | U2 | 57 | 7 | (b) 2, (c) 2, (d) 1, (g) 2 | 1 | yes | `8ece111b` |
| frA | `v200-u19-putback-folder-keeps-nothing` | v195kept | 10 | 0 |  | 0 | **no** | `8ece111b` |
| frA | `v200-u19-putback-folder-keeps-nothing` | v189 | 40 | 0 |  | 0 | **no** | `8ece111b` |

**Every U19 entry is caught: the ten new ones and the build's six, re-run on the revised copy.** The two existing U2
entries are still caught (`v200-u2-putback-gen` by U2 with 1; `v200-u2-putback-while-saving` by U2 with 35 and U19 with 7).
The mutant boards made from the earlier text of fr/c1's mutate (`efdfddd5`, before the tenth entry was added) are still the
right boards: every one of those entries is unchanged in `9028eaa8`.

**A coverage shift, measured (as the build's v1.95 shift was).** The existing `putback-drops-screen`
(`const nowUnsaved=false;`) is caught on fr/c1 by the U19 block only: 5 failing checks, (f) 4 and the (j) CONTROL 1. U2
and v195kept now catch nothing (0 of 57, 0 of 10). On the build's c1, U2 caught 7 (and on the base, U2 11 and v195kept 1).

The reason is in the board, not a gap in the tests. With M1's clause, unsaved work in the folder is kept even when
`nowUnsaved` is forced false: every edit moves the work's time (`MS.ts`) away from the folder copy's
(`driveBaseOf(...)`). So that mutant no longer drops anything. It changes only the question's sentence and the `saved`
mark, which the U19 block checks. To keep a mutation that does drop the screen in the shared folder, the round adds
`v200-u19-putback-folder-keeps-nothing` (`keepScreen=!driveStoreOn()`). It is caught by U2 with 7 failing checks, the same
folder rows `putback-drops-screen` used to fail on c1, and by U19 with 7, (m) 4 and (r) 3. The full audit-import runs
both blocks.

**Two more measured facts.**
- `v200-u19-putback-needs-handle` is caught by the U19 block's new (o), with 4 failing checks. It is also caught by the
  changed v1.89 row, with 1.
- `v200-u19-putback-store-at-putback`, which drops M1's clause, fails exactly the 4 non-control rows of (m). That is the
  same as the build's c1 on the final block.

## FR.7 Every run in this round (`logs/runs.txt`; each log ends with its exit and wall time)

| label | start (ET) | exit | wall s | log |
|---|---|---|---|---|
| F-fr1-U19.frc1-on-frc1 | 09:26:46 | 0 | 97.2 | `logs/F-fr1-U19.frc1-on-frc1.log` |
| F-fr1-U19.frc1-on-base | 09:28:24 | 1 | 63.1 | `logs/F-fr1-U19.frc1-on-base.log` |
| F-fr1-U19.frc1-on-c1 | 09:29:27 | 1 | 51.2 | `logs/F-fr1-U19.frc1-on-c1.log` |
| F-fr1-U2.frc1-on-frc1 | 09:30:46 | 0 | 38.6 | `logs/F-fr1-U2.frc1-on-frc1.log` |
| F-fr1-v189.frc1-on-frc1 | 09:31:24 | 0 | 13.0 | `logs/F-fr1-v189.frc1-on-frc1.log` |
| F-fr1-v195kept.frc1-on-frc1 | 09:31:37 | 0 | 9.3 | `logs/F-fr1-v195kept.frc1-on-frc1.log` |
| F-fr1-U2.base-on-frc1 | 09:31:46 | 1 | 36.9 | `logs/F-fr1-U2.base-on-frc1.log` |
| F-fr1-v189.base-on-frc1 | 09:32:23 | 1 | 15.0 | `logs/F-fr1-v189.base-on-frc1.log` |
| F-fr1-v195kept.base-on-frc1 | 09:32:38 | 0 | 14.0 | `logs/F-fr1-v195kept.base-on-frc1.log` |
| F-fr1-U2.frc1-on-base | 09:32:52 | 1 | 51.9 | `logs/F-fr1-U2.frc1-on-base.log` |
| F-fr1-v189.frc1-on-base | 09:33:44 | 1 | 22.3 | `logs/F-fr1-v189.frc1-on-base.log` |
| F-fr1-v195kept.frc1-on-base | 09:34:07 | 0 | 17.7 | `logs/F-fr1-v195kept.frc1-on-base.log` |
| F-fr2-U19.frc1-on-frc1 | 09:34:47 | 0 | 59.2 | `logs/F-fr2-U19.frc1-on-frc1.log` |
| F-fr2-U19.frc1-on-base | 09:35:46 | 1 | 43.3 | `logs/F-fr2-U19.frc1-on-base.log` |
| F-fr2-U19.frc1-on-c1 | 09:36:29 | 1 | 48.7 | `logs/F-fr2-U19.frc1-on-c1.log` |
| S-boot-same-frc1 | 09:37:18 | 0 | 13.9 | `logs/S-boot-same-frc1.log` |
| S-audit-frc1 | 09:37:32 | 0 | 18.8 | `logs/S-audit-frc1.log` |
| S-audit-ppt-frc1 | 09:37:51 | 0 | 7.8 | `logs/S-audit-ppt-frc1.log` |
| S-audit-other-frc1 | 09:37:58 | 0 | 50.6 | `logs/S-audit-other-frc1.log` |
| S-audit-recon-frc1 | 09:38:49 | 0 | 207.0 | `logs/S-audit-recon-frc1.log` |
| S-legacy-fsrc-frc1 | 09:42:16 | 0 | 5.0 | `logs/S-legacy-fsrc-frc1.log` |
| S-audit-hostile-frc1 | 09:42:21 | 0 | 99.1 | `logs/S-audit-hostile-frc1.log` |
| S-audit-inject-frc1 | 09:44:00 | 0 | 25.6 | `logs/S-audit-inject-frc1.log` |
| S-check-frc1 | 09:44:26 | 0 | 7.1 | `logs/S-check-frc1.log` |
| M-frA-v200-u19-putback-store-at-putback-U19.frc1-on-frc1 | 09:44:34 | 1 | 106.9 | `logs/M-frA-v200-u19-putback-store-at-putback-U19.frc1-on-frc1.log` |
| M-frA-v200-u19-putback-needs-handle-U19.frc1-on-frc1 | 09:46:21 | 1 | 80.7 | `logs/M-frA-v200-u19-putback-needs-handle-U19.frc1-on-frc1.log` |
| M-frA-v200-u19-putback-needs-handle-v189.frc1-on-frc1 | 09:47:41 | 1 | 29.5 | `logs/M-frA-v200-u19-putback-needs-handle-v189.frc1-on-frc1.log` |
| M-frA-v200-u19-putback-again-unsaved-said-U19.frc1-on-frc1 | 09:48:11 | 1 | 103.0 | `logs/M-frA-v200-u19-putback-again-unsaved-said-U19.frc1-on-frc1.log` |
| M-frA-v200-u19-putback-again-any-U19.frc1-on-frc1 | 09:49:55 | 1 | 104.4 | `logs/M-frA-v200-u19-putback-again-any-U19.frc1-on-frc1.log` |
| M-frA-v200-u19-swap-saved-forgotten-U19.frc1-on-frc1 | 09:51:40 | 1 | 94.0 | `logs/M-frA-v200-u19-swap-saved-forgotten-U19.frc1-on-frc1.log` |
| M-frA-v200-u19-cancel-says-reopen-U19.frc1-on-frc1 | 09:53:14 | 1 | 100.4 | `logs/M-frA-v200-u19-cancel-says-reopen-U19.frc1-on-frc1.log` |
| M-frA-v200-u19-swap-status-by-kept-U19.frc1-on-frc1 | 09:54:55 | 1 | 78.2 | `logs/M-frA-v200-u19-swap-status-by-kept-U19.frc1-on-frc1.log` |
| M-frA-v200-u19-swap-title-any-kind-U19.frc1-on-frc1 | 09:56:13 | 1 | 96.4 | `logs/M-frA-v200-u19-swap-title-any-kind-U19.frc1-on-frc1.log` |
| M-frA-v200-u19-swap-menu-any-kind-U19.frc1-on-frc1 | 09:57:50 | 1 | 91.4 | `logs/M-frA-v200-u19-swap-menu-any-kind-U19.frc1-on-frc1.log` |
| M-frB-v200-u19-putback-keeps-nothing-saved-U19.frc1-on-frc1 | 09:59:22 | 1 | 93.1 | `logs/M-frB-v200-u19-putback-keeps-nothing-saved-U19.frc1-on-frc1.log` |
| M-frB-v200-u19-putback-keeps-nothing-saved-U2.frc1-on-frc1 | 10:00:55 | 1 | 95.6 | `logs/M-frB-v200-u19-putback-keeps-nothing-saved-U2.frc1-on-frc1.log` |
| M-frB-v200-u19-putback-keeps-nothing-saved-v189.frc1-on-frc1 | 10:02:30 | 1 | 32.8 | `logs/M-frB-v200-u19-putback-keeps-nothing-saved-v189.frc1-on-frc1.log` |
| M-frB-v200-u19-putback-promise-unkept-U19.frc1-on-frc1 | 10:03:03 | 1 | 91.3 | `logs/M-frB-v200-u19-putback-promise-unkept-U19.frc1-on-frc1.log` |
| M-frB-v200-u19-putback-promise-unkept-U2.frc1-on-frc1 | 10:04:35 | 1 | 76.3 | `logs/M-frB-v200-u19-putback-promise-unkept-U2.frc1-on-frc1.log` |
| M-frB-v200-u19-putback-promise-unkept-v189.frc1-on-frc1 | 10:05:51 | 1 | 28.2 | `logs/M-frB-v200-u19-putback-promise-unkept-v189.frc1-on-frc1.log` |
| M-frB-v200-u19-putback-question-unsaid-U19.frc1-on-frc1 | 10:06:20 | 1 | 87.9 | `logs/M-frB-v200-u19-putback-question-unsaid-U19.frc1-on-frc1.log` |
| M-frB-v200-u19-swap-status-names-saver-U19.frc1-on-frc1 | 10:07:48 | 1 | 100.9 | `logs/M-frB-v200-u19-swap-status-names-saver-U19.frc1-on-frc1.log` |
| M-frB-v200-u19-swap-title-unsaved-U19.frc1-on-frc1 | 10:09:29 | 1 | 96.4 | `logs/M-frB-v200-u19-swap-title-unsaved-U19.frc1-on-frc1.log` |
| M-frB-v200-u19-swap-menu-replaced-U19.frc1-on-frc1 | 10:11:06 | 1 | 102.0 | `logs/M-frB-v200-u19-swap-menu-replaced-U19.frc1-on-frc1.log` |
| M-frC-putback-drops-screen-U19.frc1-on-frc1 | 10:12:48 | 1 | 104.2 | `logs/M-frC-putback-drops-screen-U19.frc1-on-frc1.log` |
| M-frC-putback-drops-screen-U2.frc1-on-frc1 | 10:14:33 | 0 | 76.4 | `logs/M-frC-putback-drops-screen-U2.frc1-on-frc1.log` |
| M-frC-putback-drops-screen-v195kept.frc1-on-frc1 | 10:15:49 | 0 | 20.2 | `logs/M-frC-putback-drops-screen-v195kept.frc1-on-frc1.log` |
| M-frC-v200-u2-putback-gen-U2.frc1-on-frc1 | 10:16:10 | 1 | 60.8 | `logs/M-frC-v200-u2-putback-gen-U2.frc1-on-frc1.log` |
| M-frC-v200-u2-putback-gen-U19.frc1-on-frc1 | 10:17:11 | 0 | 76.1 | `logs/M-frC-v200-u2-putback-gen-U19.frc1-on-frc1.log` |
| M-frC-v200-u2-putback-while-saving-U2.frc1-on-frc1 | 10:18:27 | 1 | 75.7 | `logs/M-frC-v200-u2-putback-while-saving-U2.frc1-on-frc1.log` |
| M-frC-v200-u2-putback-while-saving-U19.frc1-on-frc1 | 10:19:43 | 1 | 80.6 | `logs/M-frC-v200-u2-putback-while-saving-U19.frc1-on-frc1.log` |
| M-frA-v200-u19-putback-folder-keeps-nothing-U19.frc1-on-frc1 | 10:22:09 | 1 | 59.0 | `logs/M-frA-v200-u19-putback-folder-keeps-nothing-U19.frc1-on-frc1.log` |
| M-frA-v200-u19-putback-folder-keeps-nothing-U2.frc1-on-frc1 | 10:23:08 | 1 | 43.7 | `logs/M-frA-v200-u19-putback-folder-keeps-nothing-U2.frc1-on-frc1.log` |
| M-frA-v200-u19-putback-folder-keeps-nothing-v195kept.frc1-on-frc1 | 10:23:52 | 0 | 12.3 | `logs/M-frA-v200-u19-putback-folder-keeps-nothing-v195kept.frc1-on-frc1.log` |
| M-frA-v200-u19-putback-folder-keeps-nothing-v189.frc1-on-frc1 | 10:24:04 | 0 | 18.0 | `logs/M-frA-v200-u19-putback-folder-keeps-nothing-v189.frc1-on-frc1.log` |

Exit 1 on a focused run on the base or the build's copy, or on a mutant run, means checks failed, as intended.
No run timed out, waited for the lock or was skipped.

## FR.8 The other suites and npm run check, on `fr/c1` (scratch clone `git/frc1` at 7ee498a, `fr/mkclone.sh`)

- S-boot-same-frc1 | every page, source, save and error list is identical either way | exit: 0
- S-audit-frc1 | ALL CHECKS PASSED | exit: 0
- S-audit-ppt-frc1 | ALL CHECKS PASSED | exit: 0
- S-audit-other-frc1 | ALL CHECKS PASSED | exit: 0
- S-audit-recon-frc1 | ALL CHECKS PASSED | exit: 0
- S-legacy-fsrc-frc1 | every legacy Force setting computes exactly as before | exit: 0
- S-audit-hostile-frc1 | ALL CHECKS PASSED | exit: 0
- S-audit-inject-frc1 | ALL CHECKS PASSED | exit: 0
- S-check-frc1 | all checks passed | exit: 0

The base results are the build's (§9 below): the base board and suites are unchanged.

## FR.9 mcount (text only, `rec/bin/mcount.py`, `python3 -I`; `out/fr-mcount/`)

- `frc1`: `{"entries": 1344, "once": 1344, "missing": [], "multiple": [], "unparsed": []}`
- `base`: `{"entries": 1328, "once": 1328, "missing": [], "multiple": [], "unparsed": []}`
- `frc1mut-on-base`: `{"entries": 1344, "once": 1328, "missing": ["v200-u19-putback-keeps-nothing-saved", "v200-u19-putback-promise-unkept", "v200-u19-putback-question-unsaid", "v200-u19-swap-status-names-saver", "v200-u19-swap-title-unsaved", "v200-u19-swap-menu-replaced", "v200-u19-putback-store-at-putback", "v200-u19-putback-folder-keeps-nothing", "v200-u19-putback-needs-handle", "v200-u19-putback-again-unsaved-said", "v200-u19-putback-again-any", "v200-u19-swap-saved-forgotten", "v200-u19-cancel-says-reopen", "v200-u19-swap-status-by-kept", "v200-u19-swap-title-any-kind", "v200-u19-swap-menu-any-kind"], "multiple": [], "unparsed": []}`
- `frc1mut-on-c1`: `{"entries": 1344, "once": 1336, "missing": ["v200-u19-putback-keeps-nothing-saved", "v200-u19-putback-store-at-putback", "v200-u19-putback-folder-keeps-nothing", "v200-u19-putback-needs-handle", "v200-u19-putback-again-unsaved-said", "v200-u19-putback-again-any", "v200-u19-swap-saved-forgotten", "v200-u19-cancel-says-reopen"], "multiple": [], "unparsed": []}`

`frc1` is fr/c1's text on its own board. `frc1mut-on-base` and `frc1mut-on-c1` are fr/c1's text on the base and on the
build's c1 board: the missing ids find code this commit adds or changes, as expected.

## FR.10 Blobs (`git hash-object`)

| file | base | build c1 | fix round fr/c1 |
|---|---|---|---|
| `prioritization-board-grid.html` | `fce8a391bd8a248d5185e199d22190c1687eaea0` | `8cf14d7e6baf8fa6f590e3082a2ed429458c3490` | `f6ac4b9d62d528c855a08e0101b98873792f99d5` |
| `tools/export-audit/audit-import.mjs` | `4aba2506a7ea3bd367fb74436172b188bb4fc887` | `a1a3e32c67ca632ce9fb5e8f69ddae5f7881d3e4` | `cfaeac173615efb6ae1a5e64a696544a4e20754f` |
| `tools/export-audit/mutate.mjs.txt` | `cbc6defc6803851e847844848fc9b186daeeb268` | `67ec010fe747ce2c1fb02987f19a1a4f48429aac` | `9028eaa8a88fb231b3450415b7d4aaf749d76d4f` |
| `tools/export-audit/audit-recon.mjs` | `529e36f7c20e635b2722ea53b6a4f44b4ed328af` | `529e36f7c20e635b2722ea53b6a4f44b4ed328af` | `529e36f7c20e635b2722ea53b6a4f44b4ed328af` |
| `tools/export-audit/audit-board.mjs` | `a7c575e5f98452be88f8d0d7f352fd805350e3d7` | `a7c575e5f98452be88f8d0d7f352fd805350e3d7` | `a7c575e5f98452be88f8d0d7f352fd805350e3d7` |
| `tools/export-audit/audit-other.mjs` | `d89396b0cbf7c4b2ea2110acc0a663a23de62760` | `d89396b0cbf7c4b2ea2110acc0a663a23de62760` | `d89396b0cbf7c4b2ea2110acc0a663a23de62760` |

| fix-round file | blob |
|---|---|
| `fr/bin/edit-board-fr.py` | `50659df458b87214f087776efea63f3e58b33380` |
| `fr/bin/edit-mutate-fr.py` | `4cfb5d9405729acd104bc7af7c80ec877874c8c9` |
| `fr/bin/mkblock-fr.py` | `b5533f52496a8c1cdd5ee2ee8cbdfb2b93f8656a` |
| `fr/bin/muttable.py` | `bb4a0a71fae1afe9eac81810be9893ba88f3422c` |
| `fr/block-u19.fr.mjs.txt` | `cf0f971d33cbefc446444c4b328f478e8bcd2300` |
| `fr/build.sh` | `2a5515f7ba4d873b4fec91b8488af5fd2af13ab9` |
| `fr/frun.sh` | `5166f8c3c3c8400baaeae20afa00b6ef3334d3e7` |
| `fr/mrun.sh` | `cde4963dc72c507ce4fef0d95e1338052a433e4b` |
| `fr/mut-chain.sh` | `41d23d879b17310ec8dd0602b8205758840ad37a` |
| `fr/mkclone.sh` | `f86973d0d0a2083d17f3ea29eb950663bcc3681b` |
| `fr/mkdiffs.sh` | `6cf0455a907f5b60715670184cb768a7f305c57e` |
| `fr/assemble.sh` | `96a0e9440d75136d23c897c12ace6deb26231b92` |
| `fr/README.fr.md` | `4768e02bdbf409865a0212c33583cd4953cef299` |
| `fr/README.fr2.md` | `061fdbc34657b832e8eda324c651a72e7aa18dbd` |
| `fr/mut-notes.md` | `0ecd9006fad69811dbee2a3e9c80414b8e4a09fc` |
| `fr/mutdiff.sh` | `e6cafcca43da215d5e780886eaba888052d71c64` |
| `fr/mutdiff.txt` | `65f541571aa883f585a3a405c22a581b8a95b69f` |
| `fr/drafts/NEXT-VERSION-U19.md` | `049e3b2782b12f439e4e4fd0e3743ad6a97a6e08` |
| `fr/drafts/UNRESOLVED-U19.md` | `40be28a5c56ba438832ff93d5477870fb4bc6caf` |
| `fr/drafts/LEDGER-U19.md` | `c52af727804af67acf013ab3db80ebe952aad84b` |
| `h/src-frc1/U19.frc1.mjs` | `40356194e3193d59d5b7eedeab11fb32e423dc67` |
| `h/src-frc1/U2.frc1.mjs` | `a1edf6a8f1f26605483bec1e595ce6b9451bc54d` |
| `h/src-frc1/v189.frc1.mjs` | `49261f6a8468169e7272f828a4f88a59fec0660d` |
| `h/src-frc1/v195kept.frc1.mjs` | `f2adbb73140847e201c0858b0147ace0245b7e81` |
| `fr/diffs/c1-board.diff` | `8df17e5583b7af36e39ef50399868de7acd03ece` |
| `fr/diffs/c1-audit-import.diff` | `f5fd037b3bf22f8a1cf54ae4b7ccc196fe3ce4f2` |
| `fr/diffs/c1-mutate.diff` | `fe5f634735288894fdf2176fdac9a3f6f1b7d58a` |
| `fr/diffs/c1-all.diff` | `7c2ec5057c8fdf035e8df111fa2d1ad06a0c674c` |
| `fr/diffs/build-to-fr-board.diff` | `9655be901a9c9eb9731535ae86200c6670cf7933` |
| `fr/diffs/build-to-fr-audit-import.diff` | `be4309670cdc878fa5fcc5aad9bea566f172531f` |
| `fr/diffs/build-to-fr-mutate.diff` | `d976961d1aca7e1b94dce471858b42017cc0cada` |
| `fr/diffs/build-to-fr-all.diff` | `f0caf18858ccda56fd165415b2ed53a9436d2949` |
| `README.build.md` | `6965f2897f69ef0c2a0919aa184f27c03ffd38a7` |

Unchanged and reused from the build: `bin/edit-board.py`, `bin/edit-import.py`, `bin/edit-mutate.py` (each applied first,
then the fix round's script), `bin/runner.mjs`, `bin/mkfocused-u2.py`, `bin/tally.py`, `bin/fails.py`, `bin/runstable.py`,
`run.sh`, `bx.sh`, `mk-harness.sh`, `suites.sh` (blobs in the build record §11).

## FR.11 Drafts for the lead (the lead commits; I did not). They supersede the build record's §12.

### FR.11.1 NEXT-VERSION.md, under v2.00, after the U14 entry and before "Unresolved after R1–R5" (`fr/drafts/NEXT-VERSION-U19.md`)

```
- **U19 — ↶ Put back after a board-file save keeps what it replaces** (Brad, 12 Oct, about 5:30 PM ET: "Don't wait for me.
  Let's keep pressing throughout to get this next version published."; the lead's decision to fix the release blockers).
  With work saved into the board file (S1), ↶ Put back of the work kept aside (K) kept nothing in S1's place, because S1 was
  "still in the saved file it came from, and 💾 Save will ask before writing over that". Save did ask (its HOLD ON), but
  answered OK it wrote K over S1, and then S1 was in no copy this board could reach: not on screen, not kept aside, not in
  browser storage, not in a byte of the file, after the Save and after a reopen. It was left only in Teams version history,
  outside the board, where the file has one. The shared folder keeps the copy a save replaces in its history; a board file
  keeps none. Now ↶ Put back keeps what is on screen aside in the kept work's place, with the checkpoint it came from,
  whether or not it is saved, as unsaved work always was. The one exception is when 💾 Save writes to the shared folder at
  the put-back and what is on screen is the folder's own copy (the one last loaded from or written to the folder): that copy
  stays in the folder whatever Save does next. The choice is made at the put-back, so switching 📡 Live view from
  "● Working out of this folder" back to "○ Just watching" before the Save cannot leave work saved only in the board file
  unkept. Putting the kept copy back later restores it, and Save asks again before writing over the file. The question adds
  "It is also kept aside in its place, so it is not lost if Save does." A copy kept this way that was saved, then put back
  and not changed since, is not said to have "changes no saved copy has": the question says "What is on screen now was put
  back and has not been saved since, so it is kept aside in its place — nothing is lost." With no room in browser storage to
  keep what is on screen, nothing is put back and nothing changes, as for unsaved work. The words for a copy kept at a
  put-back no longer call it work no saved copy had or say a saved copy replaced it: the top bar's ↶ work kept aside says
  "What was on screen when other work was put back, kept aside …", 📁 File says "kept … · what was on screen when other work
  was put back", and putting such a copy back says "💾 Save will ask before it writes over a copy saved after the one this
  work came from." While work is kept aside, a reopen does not load the file's copy over unsaved work on screen, so the
  HOLD ON's Cancel line then reads "Cancel — don't save (then use ⬅ Import on the current file to pick up their changes
  first)." and the status after Cancel "… ⬅ Import this file to load their version, then redo your edits.", without
  "or reopen it" and "Reopen or", which were not true there. On the board before this change that was already so after a
  put-back of unsaved work. With nothing kept aside, both read as before.
  - **What users may see:** after ↶ Put back, the top bar keeps offering ↶ work kept aside (what was on screen) until it is
    put back, saved as a file or discarded. In the shared folder too, when what was on screen was not the folder's own copy.
    While it is kept, a newer copy that would need work kept aside is not loaded, and the board says so, as it already did
    for unsaved work. The next 💾 Save then asks HOLD ON before writing over that newer copy in the file; answered OK, that
    copy is left only in Teams version history, as with any HOLD ON answered OK. This includes reopening the file before any
    Save after the put-back: K stays on screen, unsaved, and the file's copy (S1, the very copy kept aside) is not loaded
    ("… the newer copy was not loaded and nothing was lost"); before, S1 opened and K was kept. On that reopen the top bar
    says "Saved <time> · ↶ work kept aside" while the work on screen is unsaved by this browser's record. That is the
    board's existing opening behaviour, also seen after ordinary editing and a reopen, now reached on this route too. After
    a saved copy is put back, the top bar says "Unsaved changes" though the file holds it: a put-back counts as a change
    (v2.00, U2). A put-back in a browser whose storage is full is now refused, with "nothing was changed", where it used to
    go ahead when what was on screen was saved. While work is kept aside, the HOLD ON's Cancel line and the status after
    Cancel name ⬅ Import, not a reopen.
  - **Test:** audit-import "v2.00 (U19) — put back after a board-file save keeps what it replaces" (104 checks). It drives
    the routes through the page's own buttons and menus: put back once S1's save has landed; put back while it writes
    (refused, U2) and again once it has landed; through 📁 File and the note editor; with no file handle remembered (the
    picker); between two writers, each with their own key (✍ Take the pen, both ways); with 📡 Live view working out of a
    folder at the put-back and switched back to the file before the Save; and on a reopened page with no file handle in
    memory. Each route then runs 💾 Save with the HOLD ON answered OK and a reopen. It also covers K and S1 put back in turn
    before any Save, a reopen before any Save, no room in browser storage, the HOLD ON answered Cancel while work is kept
    aside (S1 saved, and S1 never saved), and the words for each kind of kept copy in the shared folder. The controls are the
    HOLD ON answered Cancel, S1 never saved, the shared folder, 📡 Live view left on at the Save, and ordinary editing. 50
    checks fail on the board before the change, none of them a control; all 54 control checks pass on both.
  - **Existing expectations changed (3, each listed with old → new in the builder's record):** v1.89 "the file is newer",
    "one click puts it back": the kept slot was empty after the put-back and now holds the colleague's copy. "v2.00 (U2) — put
    back waits for a save to finish", case (d), the board file: "put back again" kept nothing (`null`) and now keeps S1
    (`'S1'`), and the reopen then shows K with S1 kept (`['K','S1']`, was `['S1','K']`).
  - **Mutations (16):** `v200-u19-putback-keeps-nothing-saved`, `-putback-promise-unkept`, `-putback-question-unsaid`,
    `-swap-status-names-saver`, `-swap-title-unsaved`, `-swap-menu-replaced`, `-putback-store-at-putback`,
    `-putback-folder-keeps-nothing`, `-putback-needs-handle`, `-putback-again-unsaved-said`, `-putback-again-any`,
    `-swap-saved-forgotten`, `-cancel-says-reopen`, `-swap-status-by-kept`, `-swap-title-any-kind` and
    `-swap-menu-any-kind`; each caught by the focused block (full-suite sensitivity runs in the final-tree queue).
  - **Not covered:** the file's own Change journal after K's Save keeps no trace of S1; S1 and its journal are in the kept
    copy. The HOLD ON still calls the person's own save "their changes" (the triage's O1), and after a take-the-pen route
    the put-back status still names the writer the kept work came from ("which Bob saved after it"). Reopened before any Save
    after a put-back, the "newer copy was not loaded" message calls S1 both "a newer copy" and the "earlier work" kept aside.
    The put-back question still asks before a locked view refuses the load, so its "It is also kept aside" can be followed by
    "nothing was put back". For work kept by a folder load, the question says what is on screen is "still in the shared folder
    it came from" even when it was saved only to the board file. On the classic route, where this browser's own copy is the
    newer one and nothing is kept aside, the HOLD ON's Cancel line still names a reopen, which does not load the file's copy
    there. All of these are wording points for Brad, not changed here. The top bar's "Saved" on a reopen with unsaved work is
    the board's existing opening behaviour (its own ledger row). A HOLD ON answered OK over another writer's file copy, not
    after a put-back, still leaves that copy only in Teams version history. A second tab of the same browser (U20) and a real
    browser (Chromium) were not run.
```

### FR.11.2 "Unresolved after R1–R5" (`fr/drafts/UNRESOLVED-U19.md`)

"Unresolved after R1–R5 (11 Oct)" (NEXT-VERSION.md) -- the fix round's text, superseding the build's 12.2.

The U2 bullet's last sentence, "Its separate reopening and adoption findings stay open in the ledger (U15–U20).", becomes:

```
    Its separate reopening and adoption findings stay open in the ledger (U15–U18 and U20); U19 is built (below).
```

Add a new bullet after the U14 bullet:

```
  - **U19: built as its own commit** (the lead's decision under Brad's "Don't wait for me", 12 Oct, about 5:30 PM ET):
    ↶ Put back keeps what is on screen aside in the kept work's place, saved or not, unless 💾 Save writes to the shared
    folder at the put-back and what is on screen is the folder's own copy. So 💾 Save's HOLD ON answered OK no longer leaves
    work saved only in the board file in no copy this board can reach, whichever way 📡 Live view's switch is set by the
    Save (above). While work is kept aside, the HOLD ON's Cancel advice names ⬅ Import, not a reopen. Open, as wording points
    for Brad: the HOLD ON's "their changes" for the person's own save (O1); the put-back status naming the earlier writer
    after a take-the-pen route; the "newer copy was not loaded" message naming S1 twice on a reopen before any Save; the
    HOLD ON's Cancel line still naming a reopen on the classic route, where this browser's own copy is the newer one; and the
    top bar's "Unsaved changes" after a saved copy is put back. The top bar's "Saved" on a reopen while the work on screen is
    unsaved by the record is the board's existing opening behaviour (its own ledger row).
```

### FR.11.3 UNRESOLVED-LEDGER.md (`fr/drafts/LEDGER-U19.md`)

UNRESOLVED-LEDGER.md -- the fix round's text, superseding the build's 12.3. `<sha>` and `<time>` are the lead's.

Append to the Status cell of the first U19 row:

```
 **Built as its own commit `<sha>` (<time> ET)** under the lead's decision of 12 Oct (Brad, about 5:30 PM ET: "Don't wait
 for me."): board `f6ac4b9d`, audit-import `cfaeac17`, mutate `9028eaa8`. `keptPutBack` keeps what is on screen aside in the
 kept work's place, saved or not, as unsaved work always was, unless 💾 Save writes to the shared folder at the put-back and
 what is on screen is the folder's own copy (`nowUnsaved || !driveStoreOn() || driveBaseOf(mySlug())!==MS.ts`): decided at
 the put-back, so 📡 Live view's switch turned back to "○ Just watching" before the Save cannot leave S1 unkept (the money
 verifier's route V1). The question says so. A saved copy kept this way and put back unchanged is not said to have "changes
 no saved copy has" (V6). The words for a copy kept at a put-back ('swap') no longer call it unsaved or replaced, in the top
 bar, 📁 File and the put-back status. While work is kept aside, the HOLD ON's Cancel line and the status after Cancel name
 ⬅ Import only, not a reopen, which there does not load the file's copy (the tests verifier's VB; also the board's earlier
 unsaved route, VB2). Focused block "v2.00 (U19)": 104 checks; 50 fail on the board before (`fce8a391`, product d66dd60),
 none of them a control; all pass after; all 54 controls pass on both. Routes: file-after, file-retry, ui-after (📁 File and
 the note editor), picker-after, pen-after (two keys, ✍ Take the pen both ways), Live view switched between the put-back and
 the Save, and a reopened page with no file handle in memory; S1 is kept and reachable after the Save and after reopening on
 each. Three existing expectations changed: v1.89 "the file is newer", and two in U2 put back waits case (d). Each is listed
 old → new in the builder's README (`rec/L6/u19`). Sixteen mutations, each caught by the block. Open, as wording points:
 - the HOLD ON's "their changes" for her own save (O1), and the put-back status naming the earlier writer after a
   take-the-pen route;
 - on a reopen before any Save after a put-back, the "newer copy was not loaded" message calls S1 both the newer copy and
   the earlier work kept aside;
 - the HOLD ON's Cancel line still names a reopen on the classic route (this browser's own copy the newer, nothing kept);
 - the top bar says "Unsaved changes" after a saved copy is put back (a put-back counts as a change, U2);
 - the put-back question is asked before a locked view refuses the load; "still in the shared folder it came from" for work
   kept by a folder load when the screen was saved only to the board file;
 - the file's Change journal keeps no trace of S1 (S1 is in the kept copy).
 The full audit-import and audit-board runs, and the final-tree mutation queue, are the lead's.
```

Append to the Status cell of the P1 table's U19 row:

```
 Built: see the U19 row (`<sha>`).
```

A NEW ROW, proposed for the lead (not U19's to fix; both verifiers found it, and the money verifier's control shows it on the
board before this change):

```
| U<next> | P2 (words) | Reopened with work this browser holds unsaved (base.dirty true) and nothing newer loaded, the top bar says
"Saved <time>" -- after ordinary editing and a reopen before any Save (verify-money-r1 V2b, on the base board `fce8a391`), on
the browser-newer opening (verify-tests-r1 VC2, both boards), and after U19's put-back and a reopen before any Save (V2a/VC).
The record and the next Save treat the work as unsaved; only the header is wrong. Evidence: rec/L6/u19/verify-money-r1/logs/
F-p4-VP4-on-vbase.log, rec/L6/u19/verify-tests-r1 (VF4 runs). | open |
```

## FR.12 What this round supersedes in the build record below (kept as it was, read with this list)

- **The commit's copy and blobs.** In the build record, c1 is board `8cf14d7e`, audit-import `a1a3e32c` and mutate
  `67ec010f`. These are superseded by `fr/c1`: board `f6ac4b9d`, audit-import `cfaeac17` and mutate `9028eaa8`. The build's
  `c1/` stays on disk unchanged, as the verifiers checked it.
- **Build §1 and §4, "whenever 💾 Save writes to a board file (`!driveStoreOn()`)" and "The shared folder is unchanged".**
  Both are superseded by M1. What is on screen is kept unless Save writes to the folder at the put-back and what is on
  screen is the folder's own copy. So in the folder, a screen that is not the folder's copy is now kept too.
- **Build §3, "That is the right test: it is exactly 'Save does not write to the shared folder'".** This is refuted by the
  money verifier's V1 and superseded as above.
- **Build §4.4, "The HOLD ON's words are unchanged and still true".** This is refuted by the tests verifier's VB. The
  Cancel line now changes while work is kept aside (MF1).
- **Build §3's table, "the three wording edits are needed".** These still hold, and M2 adds a fourth sentence (the
  question's).
- **Build §6 and §7 counts.** The block had 71 checks with 34 failing on the base, and six mutations. These are superseded
  by 104 checks with 50 failing on the base (§FR.4), and 16 mutations (§FR.6). The build's runs and mutant runs are kept as
  the record of the build's copy.
- **Build §7's "putback-drops-screen is still caught by the U2 blocks".** This holds for the build's c1 but not for
  `fr/c1`, where only the U19 block catches it. The reason, and the entry added for it, are in §FR.6.
- **Build §10 mcount** (c1 1334/1334) is superseded by `fr/c1` 1344/1344 (§FR.9).
- **Build §12 drafts (12.1–12.3)** are superseded by §FR.11.
- **Build §13 "Not changed" item "the opening's 'Saved' header … (§8)".** It is now proposed as its own ledger row (§FR.11),
  since it is not U19's.
- **The build's open item "the HOLD ON's wording (O1)"** stays open. The Cancel line's reopen advice is the only HOLD ON
  text this round changes.

## FR.13 What I did not do, and rule deviations (plainly)

**Not done:**
- **Not run (the lead's):** the full audit-import and audit-board, and the mutate sweep. `mutate.mjs` was read as text only,
  through `mcount.py` and `mkmut.py`.
- **Not run:** Chromium, Playwright and the verify:grid tools.
- **Not changed (open, listed in the drafts):**
  - the HOLD ON's "their changes" (O1);
  - the put-back status after a take-the-pen route;
  - the "newer copy was not loaded" message naming S1 twice (money S2);
  - "Unsaved changes" after a saved copy is put back (money S5);
  - the "Saved" header on a reopen with unsaved work (proposed as its own row);
  - the question asked before a locked view refuses (V5);
  - `keptWhere`'s "shared folder" for a folder-kept copy when the screen was saved only to the file;
  - the Cancel line's reopen advice on the classic route (VB3);
  - the file's Change journal (S1 lives in the kept copy).
- **Not re-run:** the base-only runs that nothing in this round touches: the base suites (§9 of the build record) and the
  base probes. The base board and those scripts are byte-identical to the build's.
- **Not re-run on `fr/c1`:** the build's own probes (`probe/*.mjs`). The new block's (a)–(e), (m) and (o) drive every route
  they drive and more.
- **Not tested:** a second tab of the same browser (U20); real disk or Teams version history.
- **Not touched:** nothing was committed, staged or pushed. The scratch clone `git/frc1` is `--shared` and only reads
  orbit-board's objects; it was never committed in. The board stays the empty template; all data is synthetic, made at run
  time.

**Deviations from the run rules, disclosed:**
- **Read-only commands ran without `setsid -w timeout -k 10 600`:** `cat`, `sed`, `grep`, `ls`, `diff` to the screen,
  `cmp`, `git hash-object`, `date`, `nproc`, `uptime` and `free`, plus `mkdir -p` of my own directories, `chmod +x` and
  `ln -s` of my own scripts and run directory, `cp` of harness files into `h/run-frc1/`, and `cp` of the old README to
  `README.build.md`. The README parts and scripts were written with the editor tool or a heredoc.
- **Small `python3 -I` edits ran unwrapped.** Three edited my own scripts (`fr/bin/edit-board-fr.py` twice,
  `fr/bin/mkblock-fr.py` once). Several more were analyses of my own `.checks.jsonl` outputs: `bin/tally.py`,
  `bin/fails.py`, inline tallies and the failing rows. So was the `sed -i` that updated one blob in my own ledger draft.
- **Every node run went through `run.sh`** (600 s cap, the lock check, PIDs). Every script that writes the copies, mutants,
  clone, diffs or mcount went through `bx.sh` (600 s cap, PIDs).
- **Chains were sequenced by an unwrapped shell:** the regression harnesses (fr1), the final U19 runs with the suites and
  mutants (fr2, frA–frC), both in the background, and the tenth entry's four mutant runs, called directly through
  `fr/mrun.sh`. Each step in them was bounded at 600 s; the sequence itself was not.
- **The waits were unwrapped background loops** (`until … sleep 3/5`) and one Monitor (`tail -F` of `logs/runs.txt`). One
  wait, on a line that could never appear, was stopped through the task tool (its own shell, not a recorded PID).
- **No recorded process was killed, by PID, name or pattern.**
- **The lock file** `AUDIT_IMPORT_RUNNING` was absent at 9:20 AM ET and at every run's start, so no run waited and none was
  skipped (`logs/runs.txt` has no "waiting" or "SKIPPED" line for this round).

## FR.14 PIDs

`pids.txt` lists every bounded command's `timeout` PID and its child, with the time, the label and the command.
- Lines 1–277 are the build's.
- Lines 278 onward are this fix round's (9:25 AM ET onward; labels `bx:fr-*`, `F-fr1-*`, `F-fr2-*`, `S-*-frc1`, `M-frA-*`,
  `M-frB-*` and `M-frC-*`).
No PID was killed.

## FR.15 Appendix: the fix round's exact diffs

Against the base, the whole commit as it now stands: `fr/diffs/c1-board.diff`, `fr/diffs/c1-mutate.diff`,
`fr/diffs/c1-audit-import.diff` (all three: `fr/diffs/c1-all.diff`). What this round changed from the build's copy:

### fr/diffs/build-to-fr-board.diff

```diff
--- a/prioritization-board-grid.html
+++ b/prioritization-board-grid.html
@@ -6944,6 +6944,9 @@
     const i=s.indexOf('\n'); return {meta:JSON.parse(s.slice(0,i)), raw:s.slice(i+1)}; }catch(e){ return null; }
 }
 function keptWhere(m){ return (m&&m.why)==='folder'? 'the shared folder' : 'the saved file'; }
+// v2.00 (U19): the count of changes (_saveGen) just after a copy kept at a put-back, saved when it was kept, was put back in its
+// turn; -1 when the last put-back was of anything else. While the count stays there, what is on screen is that copy, unchanged.
+let _putSavedGen=-1;
 function keptPutBack(){
   const k=keptCopy();
   if(!k){ _keptMeta=null; setStat('Nothing is kept aside in this browser.'); render(); return; }
@@ -6958,18 +6961,26 @@
   // v2.00 (U19): A BOARD FILE KEEPS NO EARLIER COPY THIS BOARD CAN REACH. Work on screen saved only in the board file was not
   // kept, since the file had it; but the next 💾 Save writes the work put back over that file once its HOLD ON is answered OK,
   // and then the work that was on screen was in no copy this board could reach. The shared folder keeps the copy a save
-  // replaces in its history; a board file does not. So when Save writes to a board file, what is on screen is kept aside in
-  // its place whether or not it is saved, as unsaved work always was. No room to keep it: nothing is changed, as before.
-  const keepScreen=nowUnsaved || !driveStoreOn();
+  // replaces in its history; a board file does not. So what is on screen is kept aside in its place whether or not it is
+  // saved, as unsaved work always was -- unless Save writes to the shared folder now and what is on screen IS the folder's
+  // copy (the one it was last loaded from or written to there), which stays in the folder whatever Save does next. Decided
+  // here, at the put-back, not by where Save goes now alone: 📡 Live view's switch can move Save to the board file before the
+  // Save, and work saved only in that file was then written over with none kept. No room to keep it: nothing is changed (saved
+  // work on screen used to be put back without being kept, so without needing room).
+  const keepScreen=nowUnsaved || !driveStoreOn() || driveBaseOf(mySlug())!==(+MS.ts||0);
+  // v2.00 (U19): a copy kept at a put-back can be saved work. Put back in its turn it counts as a change (U2), though it may
+  // have none that no saved copy has: until the next change the question says what is true either way.
+  const asPut=nowUnsaved && _putSavedGen===_saveGen;
   if(!confirm('Put back the work this browser kept aside on '+fmtTs(k.meta.t)+'?\n\n'
     +'What is on screen now is replaced by it. '
-    +(nowUnsaved? 'What is on screen now has changes no saved copy has, so it is kept aside in its place — nothing is lost.'
+    +(nowUnsaved? (asPut? 'What is on screen now was put back and has not been saved since, so it is kept aside in its place — nothing is lost.'
+                       : 'What is on screen now has changes no saved copy has, so it is kept aside in its place — nothing is lost.')
                 : 'What is on screen now is still in '+keptWhere(k.meta)+' it came from, and 💾 Save will ask before writing over that.'
                   +(keepScreen? ' It is also kept aside in its place, so it is not lost if Save does.' : '')))) return;
   let st; try{ st=JSON.parse(k.raw); }catch(e){ setStat('⚠ The work kept aside could not be read ('+esc(e.message)+'). It is still kept; nothing was changed.'); return; }
   let swapped=null;
   if(keepScreen){
-    const m2={t:Date.now(), why:'swap', by:whoIs()||'', ts:+MS.ts||0, base:baseGet()};
+    const m2={t:Date.now(), why:'swap', by:whoIs()||'', ts:+MS.ts||0, base:baseGet(), saved:!nowUnsaved || asPut};   // saved: v2.00 (U19)
     const str=JSON.stringify(m2)+'\n'+JSON.stringify(MS);
     try{ localStorage.setItem(_AP.key+'.kept', str); swapped=m2; }
     catch(e){ setStat('⚠ There is no room to keep what is on screen while the kept work is put back, so <b>nothing was changed</b>. '
@@ -6992,6 +7003,7 @@
   // count unmoved and marked the board saved, while the folder or file holds what that save wrote. Now that save finds the
   // count moved, leaves the work put back unsaved and says so, and the next Save writes it.
   persist(); _saveGen++; DIRTY=true; render();
+  _putSavedGen=(k.meta.why==='swap' && k.meta.saved===true)? _saveGen : -1;   // v2.00 (U19)
   // v2.00 (U19): work kept aside at a put-back ('swap') was not replaced by a newer save, and nobody need have saved since: the
   // rule Save follows is said instead, which holds either way.
   setStat('↶ <b>Put back</b> the work kept aside on '+esc(fmtTs(k.meta.t))+'. '
@@ -8383,8 +8395,11 @@
         const q = LASTKNOWN
           ? '⚠ HOLD ON — '+by+' saved this file at '+fmtTs(fts)+'. That is not the save the copy you are working from came from, so their changes are not on your screen.'
           : '⚠ HOLD ON — this file was last saved by '+by+' at '+fmtTs(fts)+', and this browser cannot tell whether that was before or after the copy you are working from.';
-        if(!confirm(q+'\n\nSaving now will OVERWRITE their changes with yours.\n\nOK — overwrite anyway (their version stays in Teams version history).\nCancel — don’t save (then use ⬅ Import on the current file, or reopen it, to pick up their changes first).')){
-          setStat('Save canceled — '+esc(by)+'’s changes are untouched. Reopen or ⬅ Import this file to load their version, then redo your edits.');
+        // v2.00 (U19): while work is kept aside, a reopen does not load a newer copy over unsaved work on screen (kept work is
+        // never replaced), so then Cancel's advice names ⬅ Import only, not a reopen.
+        const reo=!_keptMeta;
+        if(!confirm(q+'\n\nSaving now will OVERWRITE their changes with yours.\n\nOK — overwrite anyway (their version stays in Teams version history).\nCancel — don’t save (then use ⬅ Import on the current file'+(reo? ', or reopen it,' : '')+' to pick up their changes first).')){
+          setStat('Save canceled — '+esc(by)+'’s changes are untouched. '+(reo? 'Reopen or ⬅ Import' : '⬅ Import')+' this file to load their version, then redo your edits.');
           return;
         }
       }
```

### fr/diffs/build-to-fr-mutate.diff

```diff
--- a/tools/export-audit/mutate.mjs
+++ b/tools/export-audit/mutate.mjs
@@ -4287,7 +4287,7 @@
     repl: "switching a year on or off keeps it.</div>'" },
   // v2.00 (U19, Brad 12 Oct): ↶ Put back after a board-file save keeps what it replaces.
   { id: "v200-u19-putback-keeps-nothing-saved", area: "keptPutBack", what: "↶ Put back keeps nothing in place of work on screen that is saved only in the board file, as before: the next 💾 Save, its HOLD ON answered OK, writes the work put back over that file, and the work that was on screen is in no copy this board can reach, after the Save and after a reopen",
-    find: "  const keepScreen=nowUnsaved || !driveStoreOn();",
+    find: "  const keepScreen=nowUnsaved || !driveStoreOn() || driveBaseOf(mySlug())!==(+MS.ts||0);",
     repl: "  const keepScreen=nowUnsaved;" },
   { id: "v200-u19-putback-promise-unkept", area: "keptPutBack", what: "↶ Put back's question says what is on screen, saved only in the board file, is also kept aside, but nothing is kept: the next 💾 Save, OK, leaves it in no copy this board can reach",
     find: "  if(keepScreen){",
@@ -4304,6 +4304,38 @@
   { id: "v200-u19-swap-menu-replaced", area: "syncBtns", what: "📁 File says a copy kept at a put-back is “from before the saved file replaced it”, though no saved copy replaced it",
     find: "+(_keptMeta.why==='swap'? 'what was on screen when other work was put back'",
     repl: "+(false? 'what was on screen when other work was put back'" },
+  // v2.00 (U19, fix round): kept unless it is the folder's own copy; a saved copy put back again; Cancel's advice; the words for
+  // every kind of kept copy.
+  { id: "v200-u19-putback-store-at-putback", area: "keptPutBack", what: "↶ Put back keeps work saved only in the board file only when 💾 Save goes to that file at the put-back: with 📡 Live view working out of a folder that does not hold it, nothing is kept; the switch turned back to ○ Just watching, Save's HOLD ON answered OK writes the work put back over the file, and the work that was on screen is in no copy this board can reach",
+    find: " || driveBaseOf(mySlug())!==(+MS.ts||0);",
+    repl: ";" },
+  { id: "v200-u19-putback-folder-keeps-nothing", area: "keptPutBack", what: "↶ Put back keeps nothing in place of what is on screen while 💾 Save writes to the shared folder, unsaved work included: work no saved copy has is replaced by the work put back and is in no copy this board can reach",
+    find: "  const keepScreen=nowUnsaved || !driveStoreOn() || driveBaseOf(mySlug())!==(+MS.ts||0);",
+    repl: "  const keepScreen=!driveStoreOn();" },
+  { id: "v200-u19-putback-needs-handle", area: "keptPutBack", what: "↶ Put back keeps work saved only in the board file only while a file handle is in memory: on a reopened page, before its first Save, nothing is kept, and Save through the picker, OK, writes the work put back over that file",
+    find: "  const keepScreen=nowUnsaved || !driveStoreOn() || driveBaseOf(mySlug())!==(+MS.ts||0);",
+    repl: "  const keepScreen=nowUnsaved || (!!FH && (!driveStoreOn() || driveBaseOf(mySlug())!==(+MS.ts||0)));" },
+  { id: "v200-u19-putback-again-unsaved-said", area: "keptPutBack", what: "a copy saved in the board file, kept at a put-back and put back in its turn, is said at the next ↶ Put back to have “changes no saved copy has”, though the file holds it",
+    find: "  const asPut=nowUnsaved && _putSavedGen===_saveGen;",
+    repl: "  const asPut=false;" },
+  { id: "v200-u19-putback-again-any", area: "keptPutBack", what: "after ANY put-back, the next ↶ Put back says what is on screen “was put back and has not been saved since” rather than that it has changes no saved copy has -- work kept by an opening, never saved, too",
+    find: "  _putSavedGen=(k.meta.why==='swap' && k.meta.saved===true)? _saveGen : -1;",
+    repl: "  _putSavedGen=_saveGen;" },
+  { id: "v200-u19-swap-saved-forgotten", area: "keptPutBack", what: "a saved copy put back and kept aside again unchanged is recorded as unsaved, so once it is put back again the next ↶ Put back says it has “changes no saved copy has”",
+    find: "saved:!nowUnsaved || asPut};",
+    repl: "saved:!nowUnsaved};" },
+  { id: "v200-u19-cancel-says-reopen", area: "_saveInPlaceFileRun", what: "with work kept aside, the HOLD ON's Cancel line and the status after Cancel still say a reopen picks up their changes; reopened, the file's copy is not loaded over the unsaved work on screen",
+    find: "        const reo=!_keptMeta;",
+    repl: "        const reo=true;" },
+  { id: "v200-u19-swap-status-by-kept", area: "keptPutBack", what: "the status after a put-back keys its words on whether something was kept now, not on what was put back: work kept by an opening, put back over saved work, no longer names the saved file and who saved it after",
+    find: "+(k.meta.why==='swap'? '💾 Save will ask before it writes over a copy saved after the one this work came from.'",
+    repl: "+(swapped? '💾 Save will ask before it writes over a copy saved after the one this work came from.'" },
+  { id: "v200-u19-swap-title-any-kind", area: "saveStateShow", what: "the top bar's ↶ work kept aside calls work kept by Load theirs (the shared folder) “what was on screen when other work was put back”",
+    find: "+'title=\"'+(_keptMeta.why==='swap'? 'What was on screen when other work was put back'",
+    repl: "+'title=\"'+(_keptMeta.why!=='file'? 'What was on screen when other work was put back'" },
+  { id: "v200-u19-swap-menu-any-kind", area: "syncBtns", what: "📁 File calls work kept by Load theirs (the shared folder) “what was on screen when other work was put back”",
+    find: "+(_keptMeta.why==='swap'? 'what was on screen when other work was put back'",
+    repl: "+(_keptMeta.why!=='file'? 'what was on screen when other work was put back'" },
   // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.
   { id: "v200-r3-landed-view-unsaid", area: "_driveStorePushRun", what: "a folder save that lands while a locked view is on screen says “🔒 Not kept — PB27 is a locked view. ✅ Saved …” again, naming no plan (or, quiet, leaves persist's refusal on screen)",
     find: "  if(CYCVIEW){ _cycRefusedAt=0; setStat('✅ <b>Saved the working plan</b> of '+esc(APPN_LBL[ap]||ap)+' FY'+(fy%100)+' to the shared folder — '\n    +Math.round(body.length/1024)+' KB, built before '+blLbl(CYCVIEW)+' was put on screen. '+blLbl(CYCVIEW)+' is a locked view: nothing in it '\n    +'is saved. Everyone sees the working plan on their next refresh.'+penNote+lateNote); render(); return true; }\n",
```

### fr/diffs/build-to-fr-audit-import.diff

```diff
--- a/tools/export-audit/audit-import.mjs
+++ b/tools/export-audit/audit-import.mjs
@@ -7806,13 +7806,16 @@
 // saved file". The next 💾 Save asked HOLD ON, and answered OK it wrote K over S1 -- and then S1 was in no copy this board
 // could reach: not on screen, not kept aside, not in browser storage, not in a byte of the file, after the Save and after a
 // reopen (only in Teams version history, outside the board). The shared folder keeps the copy a save replaces in its history;
-// a board file keeps none. Now, when Save writes to a board file, what is on screen is kept aside in the kept work's place
-// whether or not it is saved, as unsaved work always was, and the question and the board's words say so. Each route below is
-// driven through the page's own buttons and menus: the board file put back once S1's save has landed, put back while it
-// writes (refused, U2) and again once it has landed, through 📁 File and the note editor, with no file handle remembered
-// (the picker), and between two writers who each hold their own key (✍ Take the pen, both ways). Then: S1 put back again
-// before any Save, a reopen before any Save, no room to keep what is on screen, and the controls -- the HOLD ON answered
-// Cancel, S1 never saved, the shared folder, and ordinary editing -- as they were.
+// a board file keeps none. Now what is on screen is kept aside in the kept work's place whether or not it is saved, as unsaved
+// work always was, unless 💾 Save writes to the shared folder and what is on screen is the folder's own copy; and the question
+// and the board's words say so. Each route below is driven through the page's own buttons and menus: the board file put back
+// once S1's save has landed, put back while it writes (refused, U2) and again once it has landed, through 📁 File and the
+// note editor, with no file handle remembered (the picker), between two writers who each hold their own key (✍ Take the pen,
+// both ways), with 📡 Live view working out of a folder at the put-back and switched back to the file before the Save, and on
+// a reopened page with no file handle in memory. Then: K and S1 put back in turn before any Save, a reopen before any Save,
+// no room to keep what is on screen, the HOLD ON answered Cancel while work is kept aside (its advice names ⬅ Import, not a
+// reopen, which would not load the file's copy), the words for each kind of kept copy, and the controls -- the HOLD ON
+// answered Cancel, S1 never saved, the shared folder, and ordinary editing -- as they were.
 await (async () => {   // a function, not a bare block: see settleBoards() in boot.mjs
   const __bm = bootMark();
   const name = 'v2.00 (U19) — put back after a board-file save keeps what it replaces';
@@ -7862,6 +7865,19 @@
   const SWAPTITLE = /^What was on screen when other work was put back, kept aside .+\. Put it back\.$/;
   const SWAPMENU = 'what was on screen when other work was put back';
   const SWAPSAID = '💾 Save will ask before it writes over a copy saved after the one this work came from.';
+  // The question's sentence when what is on screen is unsaved by this browser's record: work no saved copy has; or a copy kept
+  // at a put-back, saved when it was kept, put back and not changed since. The HOLD ON's Cancel line, and the status after
+  // Cancel, while work is kept aside: ⬅ Import only, no reopen.
+  const UNSAVEDQ = 'What is on screen now has changes no saved copy has, so it is kept aside in its place — nothing is lost.';
+  const PUTAGAINQ = 'What is on screen now was put back and has not been saved since, so it is kept aside in its place — nothing is lost.';
+  const CANCEL_IMPORT = 'Cancel — don’t save (then use ⬅ Import on the current file to pick up their changes first).';
+  const CANCELLED_IMPORT = 'Save canceled — Alice’s changes are untouched. ⬅ Import this file to load their version, then redo your edits.';
+  // 📡 Live view's own switch, reached through 📁 File → 📡 Live view…: "● Working out of this folder" pressed (it turns to
+  // "○ Just watching", and 💾 Save writes the board file again); then the panel's ✕ Close.
+  const liveSwitchOff = async ev => { const o = await fileMenu(ev, 'mRun(toggleLive)');
+    const r = ev(`(function(){ var bs=[].slice.call(document.querySelectorAll('#liveBody button')).filter(function(b){ return (b.getAttribute('onclick')||'')==='liveSet("store",false)'; });
+      if(bs.length!==1) return 'switches: '+bs.length; bs[0].click(); var x=document.querySelector('#livePanel h3 button.x'); if(!x) return 'no close'; x.click(); return 'clicked'; })()`);
+    await pause(5); return [o, r]; };
   // THE BOARD FILE. Alice types K, unsaved. Her other browser saves N into the file. She reopens the file: the opening keeps K
   // aside and opens N. `picker`: no file handle is remembered, so the first Save opens the picker (it hands back the same file).
   const inFile = async picker => {
@@ -7904,6 +7920,8 @@
     await savedS1(A, f, sc);
     chk(name, sc, 'the top bar offers K, as work no saved copy had (a CONTROL)', /^Work this browser held that no saved copy had, kept aside .+\. Put it back\.$/.test(keptTitle(A.ev) || ''), true);
     await putBackK(A, sc);
+    chk(name, sc, 'and names the saved file and who saved it after K, as before: K was kept by the opening (a CONTROL)',
+      status(A.ev).includes('💾 Save will ask before it writes over the saved file, which Alice saved after it.'), true);
     chk(name, sc, '↶ Put back: the top bar offers S1, as what was on screen when other work was put back; 📁 File says the same',
       J([SWAPTITLE.test(keptTitle(A.ev) || ''), menuText(A.ev).includes(SWAPMENU), menuText(A.ev).includes('from before the saved file replaced it')]), J([true, true, false]));
     let q0 = qs(A.ev).length; await clickSave(A.ev); await pause(20); saveK(A, f, sc, qs(A.ev).slice(q0));
@@ -7953,6 +7971,7 @@
     const { B, fB } = await reopen(A, f);
     chk(name, sc, 'reopened: K on screen, saved; S1 kept aside', J([scr(B.ev), ...unsaved(B.ev), where(B.ev, fB, S1)]), J([K, false, false, false, ['kept']])); }
   // (d) NO FILE HANDLE REMEMBERED: the first 💾 Save opens the picker (which hands back the same file); the second reuses it.
+  // S1's own save is that first Save, so the handle is in memory by the put-back; (o) puts back with none in memory.
   { const sc = '(d) the board file with no file handle remembered: the first 💾 Save opens the picker; HOLD ON answered OK; reopened';
     const { A, f } = await inFile(true);
     await savedS1(A, f, sc);
@@ -7988,8 +8007,9 @@
     chk(name, sc, 'reopened: K on screen and in the file, saved, writer Alice; S1 kept aside',
       J([scr(B.ev), fileNote(fB.content, 'A'), fileWriter(fB.content), ...unsaved(B.ev), where(B.ev, fB, S1)]), J([K, K, 'Alice', false, false, false, ['kept']])); }
   // (f) S1 PUT BACK AGAIN BEFORE ANY SAVE: the file still holds S1's own save, so Save asks nothing -- and the board does not
-  // say it will. K, unsaved, is kept in S1's place.
-  { const sc = '(f) the board file: K put back, then S1 put back again before any Save; then 💾 Save';
+  // say it will. K, unsaved, is kept in S1's place. Then K and S1 once more, and ↶ Put back answered Cancel: S1 on screen is the
+  // file's own copy, put back and not changed since, so the question does not say it has changes no saved copy has.
+  { const sc = '(f) the board file: K put back, then S1, then K and S1 again before any Save; then 💾 Save';
     const { A, f } = await inFile();
     await savedS1(A, f, sc);
     await putBackK(A, sc);
@@ -7999,6 +8019,15 @@
       J(['clicked', 1, true, S1, true, true, true, [K, 'swap']]));
     chk(name, sc, 'the board says Save asks before writing over a copy saved after S1’s -- not that somebody saved the file after it',
       J([status(A.ev).includes(SWAPSAID), / saved after it\./.test(status(A.ev))]), J([true, false]));
+    const q3 = qs(A.ev).length; const r3 = clickPutBack(A.ev); const qa = qs(A.ev).slice(q3);
+    chk(name, sc, 'K put back again: one question -- S1, the file’s own copy, was put back and has not been saved since (not “changes no saved copy has”); K on screen; S1 kept in its place',
+      J([r3, qa.length, qa.length === 1 && qa[0].endsWith(PUTAGAINQ), fileNote(f.content, 'A'), scr(A.ev), kept(A.ev)]), J(['clicked', 1, true, S1, K, [S1, 'swap']]));
+    const q4 = qs(A.ev).length; clickPutBack(A.ev); const qb = qs(A.ev).slice(q4);
+    chk(name, sc, 'S1 put back again: one question -- K, never saved, has changes no saved copy has; S1 on screen; K kept in its place',
+      J([qb.length, qb.length === 1 && qb[0].endsWith(UNSAVEDQ), scr(A.ev), kept(A.ev)]), J([1, true, S1, [K, 'swap']]));
+    const q5 = qs(A.ev).length; A.ev('globalThis.__yes=false; 0'); const r5 = clickPutBack(A.ev); A.ev('globalThis.__yes=true; 0'); const qc = qs(A.ev).slice(q5);
+    chk(name, sc, '↶ Put back once more, answered Cancel: one question -- S1 was put back and has not been saved since; nothing changed',
+      J([r5, qc.length, qc.length === 1 && qc[0].endsWith(PUTAGAINQ), scr(A.ev), kept(A.ev)]), J(['clicked', 1, true, S1, [K, 'swap']]));
     const q1 = qs(A.ev).length; await clickSave(A.ev); await pause(20);
     chk(name, sc, 'then 💾 Save asks nothing (nobody saved after S1’s copy) and writes S1, saved; K still kept aside',
       J([qs(A.ev).length - q1, fileNote(f.content, 'A'), ...unsaved(A.ev), kept(A.ev)]), J([0, S1, false, false, false, [K, 'swap']])); }
@@ -8084,6 +8113,97 @@
     chk(name, sc, '💾 Save asks nothing; the retyped note in the file, saved; the journal holds S1 → the retyped note; K still kept aside',
       J([qs(A.ev).length - q0, fileNote(f.content, 'A'), ...unsaved(A.ev), A.ev(`(MS.jrnl||[]).some(function(e){ return e.a===${J(S1)} && e.b===${J(K + ' RETYPED')}; })`), kept(A.ev)]),
       J([0, K + ' RETYPED', false, false, false, true, [K, 'file']])); }
+  // (m) 📡 LIVE VIEW'S SWITCH MOVES 💾 SAVE BETWEEN THE PUT-BACK AND THE SAVE. S1 saved into the board file; Alice works out of
+  // a shared folder that does not hold S1, puts K back, switches back to ○ Just watching and presses 💾 Save, which writes the
+  // board file: HOLD ON, OK. What was on screen at the put-back is not the folder's copy, so it was kept.
+  { const sc = '(m) the board file: 📡 Live view working out of a folder at the put-back, switched back before 💾 Save; HOLD ON answered OK; reopened';
+    const { A, f } = await inFile();
+    await savedS1(A, f, sc);
+    const fold = folder(); connect(A.ev, A.w, fold);
+    await putBackK(A, sc);
+    const sw = await liveSwitchOff(A.ev);
+    chk(name, sc, '📡 Live view’s “● Working out of this folder” pressed: 💾 Save writes the board file again; nothing is in the folder (a CONTROL)',
+      J([...sw, A.ev('driveStoreOn()'), fold.raw(2027) == null]), J(['clicked', 'clicked', false, true]));
+    const q0 = qs(A.ev).length; await clickSave(A.ev); await pause(20); saveK(A, f, sc, qs(A.ev).slice(q0));
+    chk(name, sc, 'after 💾 Save: S1 is kept aside, and its text is in this browser’s storage', J([where(A.ev, f, S1), anywhere(A.ev, f, S1)]), J([['kept'], true]));
+    const { B, fB } = await reopen(A, f);
+    chk(name, sc, 'reopened: K on screen and in the file, saved; S1 kept aside', J([scr(B.ev), fileNote(fB.content, 'A'), ...unsaved(B.ev), where(B.ev, fB, S1)]),
+      J([K, K, false, false, false, ['kept']])); }
+  // (n) CONTROL: THE SAME, WITH THE SWITCH LEFT ON. 💾 Save writes K to the folder; the board file keeps S1.
+  { const sc = '(n) CONTROL: the board file, 📡 Live view left working out of the folder; ↶ Put back; 💾 Save';
+    const { A, f } = await inFile();
+    await savedS1(A, f, sc);
+    const fold = folder(); connect(A.ev, A.w, fold);
+    clickPutBack(A.ev); await clickSave(A.ev); await pause(20);
+    chk(name, sc, '💾 Save writes K to the folder; the board file keeps S1', J([fold.note(2027, 'A'), fileNote(f.content, 'A'), scr(A.ev)]), J([K, S1, K])); }
+  // (o) A REOPENED PAGE WITH NO FILE HANDLE IN MEMORY, as every page is until its first Save: S1 saved; reopened; ↶ Put back;
+  // 💾 Save through the picker (which hands back the same file), HOLD ON answered OK; reopened again.
+  { const sc = '(o) the board file: S1 saved; reopened with no file handle in memory; ↶ Put back; 💾 Save through the picker, HOLD ON answered OK; reopened';
+    const { A, f } = await inFile();
+    await savedS1(A, f, sc);
+    const { B, fB } = await reopen(A, f);
+    B.ev(`FH=null; globalThis.__picks=0; window.showSaveFilePicker=async function(){ globalThis.__picks++; return globalThis.__disk; }; 'ok'`);
+    chk(name, sc, 'reopened: S1 on screen and in the file, saved; K kept aside by the opening; no file handle in memory (a CONTROL)',
+      J([scr(B.ev), fileNote(fB.content, 'A'), ...unsaved(B.ev), kept(B.ev), B.ev('FH===null')]), J([S1, S1, false, false, false, [K, 'file'], true]));
+    await putBackK(B, sc);
+    const q0 = qs(B.ev).length; await clickSave(B.ev); await pause(20); saveK(B, fB, sc, qs(B.ev).slice(q0));
+    chk(name, sc, 'after 💾 Save (the picker opened once): S1 is kept aside, and its text is in this browser’s storage',
+      J([B.ev('globalThis.__picks'), where(B.ev, fB, S1), anywhere(B.ev, fB, S1)]), J([1, ['kept'], true]));
+    const { B: C, fB: fC } = await reopen(B, fB);
+    chk(name, sc, 'reopened again: K on screen and in the file, saved; S1 kept aside', J([scr(C.ev), fileNote(fC.content, 'A'), ...unsaved(C.ev), where(C.ev, fC, S1)]),
+      J([K, K, false, false, false, ['kept']])); }
+  // (p) THE HOLD ON ANSWERED CANCEL WHILE WORK IS KEPT ASIDE. A reopen does not load the file's copy over unsaved work while
+  // work is kept aside (kept work is never replaced), so the HOLD ON's Cancel line and the status after it name ⬅ Import only.
+  const cancelSave = async A => { const q0 = qs(A.ev).length; A.ev('globalThis.__yes=false; 0'); await clickSave(A.ev); await pause(20); A.ev('globalThis.__yes=true; 0');
+    const q = qs(A.ev).slice(q0), said = status(A.ev);
+    return [q.length, q.length === 1 && holdOn(q[0]) && q[0].endsWith(CANCEL_IMPORT), said.includes(CANCELLED_IMPORT), /reopen/i.test(q.join('\n') + said)]; };
+  { const sc = '(p) the board file: S1 saved; ↶ Put back; 💾 Save, HOLD ON answered Cancel; reopened';
+    const { A, f } = await inFile();
+    await savedS1(A, f, sc);
+    clickPutBack(A.ev);
+    const c = await cancelSave(A);
+    chk(name, sc, '💾 Save, Cancel: one HOLD ON, whose Cancel line names ⬅ Import only, no reopen; the board says the same; nothing written; S1 kept',
+      J([...c, fileNote(f.content, 'A'), scr(A.ev), kept(A.ev)]), J([1, true, true, false, S1, K, [S1, 'swap']]));
+    const { B, fB } = await reopen(A, f);
+    chk(name, sc, 'reopened: the file’s copy (S1) is not loaded over K while S1 is kept aside, and the board says so',
+      J([scr(B.ev), kept(B.ev), fileNote(fB.content, 'A'), /the newer copy was not loaded and nothing was lost/.test(status(B.ev))]), J([K, [S1, 'swap'], S1, true])); }
+  // (q) THE SAME WITH S1 NEVER SAVED: what is on screen has been kept aside at a put-back since v1.95, and the HOLD ON's Cancel
+  // line named a reopen there too, which does not load N, the file's copy, while S1 is kept.
+  { const sc = '(q) the board file: S1 never saved; ↶ Put back; 💾 Save, HOLD ON answered Cancel; reopened';
+    const { A, f } = await inFile();
+    A.ev(`setNote('A',${J(S1)}); 'ok'`); await pause(5);
+    clickPutBack(A.ev);
+    const c = await cancelSave(A);
+    chk(name, sc, '💾 Save, Cancel: one HOLD ON (N’s save), whose Cancel line names ⬅ Import only, no reopen; the board says the same; nothing written',
+      J([...c, fileNote(f.content, 'A'), scr(A.ev), kept(A.ev)]), J([1, true, true, false, N, K, [S1, 'swap']]));
+    const { B, fB } = await reopen(A, f);
+    chk(name, sc, 'reopened: N, the file’s copy, is not loaded over K while S1 is kept; K, S1 and N each still in a copy here or in the file (a CONTROL)',
+      J([scr(B.ev), kept(B.ev), fileNote(fB.content, 'A'), [K, S1, N].map(m => where(B.ev, fB, m).length > 0)]), J([K, [S1, 'swap'], N, [true, true, true]])); }
+  // (r) THE WORDS FOR EACH KIND OF KEPT COPY, in the shared folder. K kept by Load theirs keeps its own words. S1, unsaved, kept
+  // at a put-back is offered as what was on screen when other work was put back. K saved over the folder's copy ("Save yours
+  // over theirs"), S1 put back: K is the folder's own copy, so nothing is kept in its place, and the board states the rule
+  // Save follows, not who saved after it.
+  { const sc = '(r) the shared folder: K kept by Load theirs; S1, unsaved, kept at a put-back; K saved over theirs; S1 put back';
+    const fold = folder(); const A = boot({ html: F1 }); await pause(80); wire(A.ev, 'Alice', KEY.alice); connect(A.ev, A.w, fold);
+    A.ev(`setNote('A','U19-F0'); 'ok'`); await pause(5); await A.ev('driveStorePush(false)'); await pause(5);
+    A.ev(`setNote('A',${J(K)}); 'ok'`); await pause(5);
+    const A2 = boot({ html: F1 }); await pause(80); wire(A2.ev, 'Alice', KEY.alice); connect(A2.ev, A2.w, fold);
+    await A2.ev('driveStorePull(false)'); await pause(5);
+    A2.ev(`setNote('A',${J(N)}); 'ok'`); await pause(5); await A2.ev('driveStorePush(false)'); await pause(5);
+    await A.ev('saveInPlace()'); await A.ev(`driveResolve('theirs')`); await pause(5);
+    A.ev(`setNote('A',${J(S1)}); 'ok'`); await pause(5);
+    chk(name, sc, 'K kept aside by Load theirs: the top bar and 📁 File say what it is, as before (a CONTROL)',
+      J([kept(A.ev), /^Work this browser held that no saved copy had, kept aside .+\. Put it back\.$/.test(keptTitle(A.ev) || ''), menuText(A.ev).includes('from before the shared folder replaced it')]),
+      J([[K, 'folder'], true, true]));
+    clickPutBack(A.ev);
+    chk(name, sc, 'S1, unsaved, put aside: K on screen; the top bar and 📁 File offer S1 as what was on screen when other work was put back',
+      J([scr(A.ev), kept(A.ev), SWAPTITLE.test(keptTitle(A.ev) || ''), menuText(A.ev).includes(SWAPMENU)]), J([K, [S1, 'swap'], true, true]));
+    await clickSave(A.ev); await pause(20); const q2 = qs(A.ev).length; await A.ev(`driveResolve('mine')`); await pause(20);
+    chk(name, sc, 'K saved over the folder’s copy: one question; K in the folder, saved; S1 still kept (a CONTROL)',
+      J([qs(A.ev).length - q2, fold.note(2027, 'A'), ...unsaved(A.ev), kept(A.ev)]), J([1, K, false, false, false, [S1, 'swap']]));
+    const q3 = qs(A.ev).length; clickPutBack(A.ev);
+    chk(name, sc, 'S1 put back: one question; nothing kept in its place (K is the folder’s own copy); the board states the rule Save follows, not who saved after it',
+      J([qs(A.ev).length - q3, scr(A.ev), kept(A.ev), status(A.ev).includes(SWAPSAID), / saved after it\./.test(status(A.ev))]), J([1, S1, null, true, false])); }
   } catch (e) {
     failures.push({ scenario: name, where: 'harness', what: 'the block threw: ' + String((e && e.stack) || e).slice(0, 300), got: 'threw', want: 'ran' });
   }
```

### fr/diffs/c1-board.diff

```diff
--- a/prioritization-board-grid.html
+++ b/prioritization-board-grid.html
@@ -6944,6 +6944,9 @@
     const i=s.indexOf('\n'); return {meta:JSON.parse(s.slice(0,i)), raw:s.slice(i+1)}; }catch(e){ return null; }
 }
 function keptWhere(m){ return (m&&m.why)==='folder'? 'the shared folder' : 'the saved file'; }
+// v2.00 (U19): the count of changes (_saveGen) just after a copy kept at a put-back, saved when it was kept, was put back in its
+// turn; -1 when the last put-back was of anything else. While the count stays there, what is on screen is that copy, unchanged.
+let _putSavedGen=-1;
 function keptPutBack(){
   const k=keptCopy();
   if(!k){ _keptMeta=null; setStat('Nothing is kept aside in this browser.'); render(); return; }
@@ -6955,14 +6958,29 @@
   // WORK ON SCREEN THAT NO SAVED COPY HAS IS KEPT IN ITS PLACE (v1.95, item 50): putting work back
   // never throws away the work it replaces. The slot it frees takes what is on screen.
   const nowUnsaved=!!(DIRTY || baseGet().dirty);
+  // v2.00 (U19): A BOARD FILE KEEPS NO EARLIER COPY THIS BOARD CAN REACH. Work on screen saved only in the board file was not
+  // kept, since the file had it; but the next 💾 Save writes the work put back over that file once its HOLD ON is answered OK,
+  // and then the work that was on screen was in no copy this board could reach. The shared folder keeps the copy a save
+  // replaces in its history; a board file does not. So what is on screen is kept aside in its place whether or not it is
+  // saved, as unsaved work always was -- unless Save writes to the shared folder now and what is on screen IS the folder's
+  // copy (the one it was last loaded from or written to there), which stays in the folder whatever Save does next. Decided
+  // here, at the put-back, not by where Save goes now alone: 📡 Live view's switch can move Save to the board file before the
+  // Save, and work saved only in that file was then written over with none kept. No room to keep it: nothing is changed (saved
+  // work on screen used to be put back without being kept, so without needing room).
+  const keepScreen=nowUnsaved || !driveStoreOn() || driveBaseOf(mySlug())!==(+MS.ts||0);
+  // v2.00 (U19): a copy kept at a put-back can be saved work. Put back in its turn it counts as a change (U2), though it may
+  // have none that no saved copy has: until the next change the question says what is true either way.
+  const asPut=nowUnsaved && _putSavedGen===_saveGen;
   if(!confirm('Put back the work this browser kept aside on '+fmtTs(k.meta.t)+'?\n\n'
     +'What is on screen now is replaced by it. '
-    +(nowUnsaved? 'What is on screen now has changes no saved copy has, so it is kept aside in its place — nothing is lost.'
-                : 'What is on screen now is still in '+keptWhere(k.meta)+' it came from, and 💾 Save will ask before writing over that.'))) return;
+    +(nowUnsaved? (asPut? 'What is on screen now was put back and has not been saved since, so it is kept aside in its place — nothing is lost.'
+                       : 'What is on screen now has changes no saved copy has, so it is kept aside in its place — nothing is lost.')
+                : 'What is on screen now is still in '+keptWhere(k.meta)+' it came from, and 💾 Save will ask before writing over that.'
+                  +(keepScreen? ' It is also kept aside in its place, so it is not lost if Save does.' : '')))) return;
   let st; try{ st=JSON.parse(k.raw); }catch(e){ setStat('⚠ The work kept aside could not be read ('+esc(e.message)+'). It is still kept; nothing was changed.'); return; }
   let swapped=null;
-  if(nowUnsaved){
-    const m2={t:Date.now(), why:'swap', by:whoIs()||'', ts:+MS.ts||0, base:baseGet()};
+  if(keepScreen){
+    const m2={t:Date.now(), why:'swap', by:whoIs()||'', ts:+MS.ts||0, base:baseGet(), saved:!nowUnsaved || asPut};   // saved: v2.00 (U19)
     const str=JSON.stringify(m2)+'\n'+JSON.stringify(MS);
     try{ localStorage.setItem(_AP.key+'.kept', str); swapped=m2; }
     catch(e){ setStat('⚠ There is no room to keep what is on screen while the kept work is put back, so <b>nothing was changed</b>. '
@@ -6985,8 +7003,12 @@
   // count unmoved and marked the board saved, while the folder or file holds what that save wrote. Now that save finds the
   // count moved, leaves the work put back unsaved and says so, and the next Save writes it.
   persist(); _saveGen++; DIRTY=true; render();
-  setStat('↶ <b>Put back</b> the work kept aside on '+esc(fmtTs(k.meta.t))+'. 💾 Save will ask before it writes over '
-    +esc(keptWhere(k.meta))+', which '+esc(k.meta.by||'someone')+' saved after it.'
+  _putSavedGen=(k.meta.why==='swap' && k.meta.saved===true)? _saveGen : -1;   // v2.00 (U19)
+  // v2.00 (U19): work kept aside at a put-back ('swap') was not replaced by a newer save, and nobody need have saved since: the
+  // rule Save follows is said instead, which holds either way.
+  setStat('↶ <b>Put back</b> the work kept aside on '+esc(fmtTs(k.meta.t))+'. '
+    +(k.meta.why==='swap'? '💾 Save will ask before it writes over a copy saved after the one this work came from.'
+      : '💾 Save will ask before it writes over '+esc(keptWhere(k.meta))+', which '+esc(k.meta.by||'someone')+' saved after it.')
     +(swapped? ' What was on screen is <b>kept aside</b> in its place: <button type="button" class="nb lnk" onclick="keptPutBack()">put that back</button>.' : ''));
 }
 // SAVE THE KEPT WORK AS A FILE (v1.95, item 50): a board file holding it, to open or hand on. Saving it
@@ -8373,8 +8395,11 @@
         const q = LASTKNOWN
           ? '⚠ HOLD ON — '+by+' saved this file at '+fmtTs(fts)+'. That is not the save the copy you are working from came from, so their changes are not on your screen.'
           : '⚠ HOLD ON — this file was last saved by '+by+' at '+fmtTs(fts)+', and this browser cannot tell whether that was before or after the copy you are working from.';
-        if(!confirm(q+'\n\nSaving now will OVERWRITE their changes with yours.\n\nOK — overwrite anyway (their version stays in Teams version history).\nCancel — don’t save (then use ⬅ Import on the current file, or reopen it, to pick up their changes first).')){
-          setStat('Save canceled — '+esc(by)+'’s changes are untouched. Reopen or ⬅ Import this file to load their version, then redo your edits.');
+        // v2.00 (U19): while work is kept aside, a reopen does not load a newer copy over unsaved work on screen (kept work is
+        // never replaced), so then Cancel's advice names ⬅ Import only, not a reopen.
+        const reo=!_keptMeta;
+        if(!confirm(q+'\n\nSaving now will OVERWRITE their changes with yours.\n\nOK — overwrite anyway (their version stays in Teams version history).\nCancel — don’t save (then use ⬅ Import on the current file'+(reo? ', or reopen it,' : '')+' to pick up their changes first).')){
+          setStat('Save canceled — '+esc(by)+'’s changes are untouched. '+(reo? 'Reopen or ⬅ Import' : '⬅ Import')+' this file to load their version, then redo your edits.');
           return;
         }
       }
@@ -25908,7 +25933,8 @@
   // v1.89: while work is kept aside, the header says so -- an opening message can be replaced by the next.
   // v1.91 (item 29): a button -- it was a link with no address, which a keyboard never reaches.
   if(ss && _keptMeta) ss.innerHTML += ' \u00b7 <button type="button" class="keptbtn" onclick="keptPutBack()" '
-    +'title="Work this browser held that no saved copy had, kept aside '+esc(shortTs(_keptMeta.t))+'. Put it back.">\u21b6 work kept aside</button>';
+    +'title="'+(_keptMeta.why==='swap'? 'What was on screen when other work was put back' : 'Work this browser held that no saved copy had')   // v2.00 (U19)
+    +', kept aside '+esc(shortTs(_keptMeta.t))+'. Put it back.">\u21b6 work kept aside</button>';
   if(sb && _sb){
     sb.className='btn pri'; sb.textContent='\u2709 Submit input'; sb.setAttribute('onclick','pmoSubmit()');
     sb.title='Send your office\u2019s changes to the portfolio team as a small submittal file. Your work is already kept in this browser.';
@@ -26237,7 +26263,8 @@
     mi('💾 Save',"mRun(saveInPlace)",false,_SB? 'turned off in a PMO copy \u2014 use \u2709 Submit input' : 'writes back to this file, in place')+
     mi('⬇ Save a copy…',"mRun(publishState)",false,_SB? 'turned off in a PMO copy' : 'downloads a duplicate')+
     // v1.89: work this browser kept aside when a newer saved copy replaced it. Here, unfolded, as long as it is kept.
-    (_keptMeta? mi('\u21b6 Put back work kept aside\u2026',"mRun(keptPutBack)",false,'kept '+shortTs(_keptMeta.t)+' \u00b7 from before '+keptWhere(_keptMeta)+' replaced it')
+    (_keptMeta? mi('\u21b6 Put back work kept aside\u2026',"mRun(keptPutBack)",false,'kept '+shortTs(_keptMeta.t)+' \u00b7 '
+        +(_keptMeta.why==='swap'? 'what was on screen when other work was put back' : 'from before '+keptWhere(_keptMeta)+' replaced it'))   // v2.00 (U19)
       +mi('⬇ Save work kept aside as a file…',"mRun(keptSaveFile)",false,'it stays kept aside')
       +mi('✕ Discard work kept aside…',"mRun(keptDiscard)",false,'cannot be undone') : '')+
     // in a PMO copy, the one way out is unfolded on top
```

---

# Build record (12 Oct 2026; kept as it was. Read with §FR.12, which lists what the fix round supersedes)


**Track U19, ORBIT v2.00 release.** One commit is proposed: `c1/` = the read-only base (`rec/L6/base`, git archive of
orbit-board `7ee498a`, product `d66dd60`) plus that commit. Nothing was committed, staged or pushed anywhere, and nothing
in `/home/user/orbit-board` or `/home/user/orbit-ui` was edited. Every time below is Eastern, read from
`TZ=America/New_York date`.

This session resumed the track at 7:31 PM ET on 12 Oct. An earlier builder had been stopped at about 6:16 PM ET by a usage
limit. This README was written from 7:50 PM ET.

## 1. In short

- **The defect is reproduced on the base.** The earlier builder's probe runs on `rec/L6/base` give 77 pass and 4 fail,
  and the 4 fails are the four U19 PROPERTY rows. The checker's variants give 66 pass and 18 fail, all U19 rows plus the two
  refuted H0 calibration rows, the same shape as the L4 triage. The checker's pen route (two writer keys) is new here. On
  the base it reproduces U19 too (§8).
- **The fix (board).** `keptPutBack` now keeps what is on screen aside in the kept work's place whenever 💾 Save writes to a
  board file (`!driveStoreOn()`), saved or not, as unsaved work always was. The question says so. The words for a copy
  kept at a put-back (`why:'swap'`) no longer call it unsaved work or work a saved copy replaced: the top bar's button
  title, the 📁 File line and the put-back status. The shared folder is unchanged. 18 lines are added and 6 removed.
- **The tests (audit-import).** The new block "v2.00 (U19)" sits right after the U13 block's end marker. It has 71 checks
  over five routes (file-after, file-retry, ui-after, picker-after, pen-after), three edge cases and four controls.
  - On the base, 34 checks fail, all in the eight changed scenarios. Every CONTROL row passes.
  - On c1, all 71 pass.
  - **Three existing expectations change** (§5), each shown failing on one board and passing on the other.
- **Mutations.** Six new entries are in the `mutate.mjs` text, and each is caught by the focused block (§7). mcount (text
  only) gives c1 1334 of 1334 entries matching exactly once, and the base 1328 of 1328.
- **The other suites.** On c1, every suite this track may run passes: boot-same, audit, audit-ppt, audit-other, audit-recon,
  legacy-fsrc, audit-hostile and audit-inject, and `npm run check` (all checks passed). The base runs are in §9.
- **Not run (the lead's):** the full audit-import and audit-board. No Chromium or Playwright was run.

## 2. What I kept from the earlier attempt, and what I re-ran

I read everything in this directory first. The lead had confirmed at 7:30 PM ET that none of the earlier processes was
still running. Every earlier run in `logs/runs.txt` has an exit record: 29 runs, from 5:59:56 PM to 6:17:40 PM ET.

**Kept, after re-checking:**
- **The base reproduction** (`out/probe-base/`, `logs/p-base-*`, `x-base-*`, `chk-base`, `xchk-base*`, all exit 0).
  - The probe `probe/u19probe.mjs` (`80b848ab`) and `probe/x19.mjs` (`cbca9776`) are byte-identical to the L4 originals.
  - `probe/check.mjs` and `probe/xcheck.mjs` differ from theirs in the board-blob literal only: L4's `98eed7e8` became the
    L6 base `fce8a391`. I checked this with `diff`.
  - Results: 77 pass / 4 fail, and 66 pass / 18 fail (§1).
- **The board change** (`bin/edit-board.py`). `recheck/recheck.sh` rebuilt the board from the read-only base with it, and
  the result is byte-identical to the earlier `c1/prioritization-board-grid.html` (`8cf14d7e`). I reviewed it against the
  proposal and the checker's notes (§3), and kept it unchanged.
- **The suite edit script** (`bin/edit-import.py`): the block insertion after the U13 end marker, and the three changed
  expectations. The rebuild matched the earlier c1 audit-import (`0ad25df2`) byte for byte. I kept the script unchanged.
- **The harness tools.**
  - `bin/mkfocused-u2.py` is byte-identical to `rec/L2/u2impl/mkfocused-u2.py`.
  - `bin/runner.mjs` is byte-identical to `rec/L2/u2impl/runner.mjs`.
  - The run wrappers are `run.sh`, `bx.sh`, `mk-harness.sh` and `focused-runs.sh`.
  - The rebuilt base harnesses are byte-identical to the earlier ones.

**Changed or added by me:**
- **The suite block.** It is now `v2/block-u19.v2.mjs.txt`, made from the earlier `block-u19.mjs.txt` by `v2/mkblock2.py`
  (text only). I added the pen route as case (e), with distinct writer keys and ✍ Take the pen both ways, because the
  checker found the same-key fixture an unlisted shortcut (CHECK §9.2). Cases (e)–(k) became (f)–(l), and the header names
  the new route. Nothing else changed.
- **c1 was rebuilt from the base** by `v2/build-c1.sh`, using the board script, the import script with the new block, and
  the new `bin/edit-mutate.py` (the six mutation entries). The earlier c1 had no mutation entries.
- **New items:** diffs, mcount, every mutant run, the suites, the pen probe, the drafts and this README.

**Re-run rather than trusted:** every focused run (the earlier r1 set was against the older block), as tag r2 on the
current blobs.

## 3. The drafted proposal, evaluated against the checker's notes

The L4 PROPOSAL keys the keep on `nowUnsaved || !driveStoreOn()`. That is the right test: it is exactly "Save does not
write to the shared folder", the one place that keeps the copy a save replaces. I kept it. For each of the checker's
points (CHECK §5, §8, §9):

| checker's point | decision | why |
|---|---|---|
| It fixes the kept-slot side: S1's whole state, its journal included, goes into the kept slot. | kept | Principle 1: S1 is reachable after the Save and after a reopen. This is measured on five routes. |
| The file's Change journal after K's Save keeps no trace of S1. | not changed; said under "Not covered" | S1 and its journal are whole in the kept copy, so nothing is lost. Writing S1 into K's journal would be a new design: it would guess (principle 2) and grow the change (principle 5). |
| Risk 1: a sticky kept slot; a reopen before any Save takes the "occupied" path. | measured (case (g)) and accepted | The reopen keeps K on screen (unsaved), with S1 kept and in the file, and says "… the newer copy was not loaded and nothing was lost". Every word holds: S1 is newer than the copy K came from, the kept work is never replaced, and nothing was lost. It refuses rather than guesses (principle 2). |
| Risk 3: no room to keep S1, so the put-back is refused. | measured (case (h)) and accepted | It fails safe through the existing "There is no room … nothing was changed" path. Nothing on screen or kept moves (principle 1). |
| Risk 5: `!driveStoreOn()` also holds with no file handle (the picker) and with a download-only browser. | measured (picker, case (d)); download-only by code | Keeping a copy aside is harmless there, and the words claim only "kept aside". |
| The proposal's question wording: "saved in the file, and also kept aside … if 💾 Save writes over the file". | the earlier builder's wording kept instead | The base sentence stays as it was ("still in the saved file it came from, and 💾 Save will ask before writing over that.") and one sentence is added: "It is also kept aside in its place, so it is not lost if Save does." That is the smallest true change (principles 4 and 5). |
| Words for the copy kept at a put-back (not in the proposal). | changed (the earlier builder's) | Principle 4: after the fix, the old words become false on reachable routes (below). |
| The HOLD ON calls her own save "their changes" (O1), and the status's "which Bob saved after it" is stale after a take-the-pen (§9.3.1). | not changed; listed | The fix makes neither false or truer, and the lead's brief says the HOLD ON words stay as they are. These are wording points for Brad. |

**Why the three wording edits are needed, not optional (principle 4).** Each old line would say something untrue on a
route the fix opens or makes common.
- **The top bar's title** said "Work this browser held that no saved copy had". After the fix, a copy kept at a put-back can
  be S1 while S1 is still the file's copy, so the line would be false at once. On the base, a swap copy was always unsaved.
- **The put-back status for a swap copy** said "💾 Save will ask before it writes over the saved file, which Alice saved
  after it". Case (f) (K put back, then S1 put back before any Save) shows nobody saved after S1's copy and Save asks
  nothing. The new words state the rule Save follows, which holds either way. By code, the old words were already false on
  the base's unsaved-swap route; that was not measured.
- **The 📁 File line** said "from before the saved file replaced it". No saved copy replaces a copy kept at a put-back.

Only the swap kind gets new words; the words for 'file', 'folder' and 'sidecar' kept copies are unchanged.

## 4. How the change meets each decision principle

1. **Never lose any copy.** After the put-back, the Save with OK and a reopen, S1 is kept aside on every file route: (a),
   (b), (c), (d) and (e). K is on screen and in the file. Putting S1 back keeps K in its place (cases (a) and (f)). No copy
   is dropped anywhere: when there is no room, nothing changes (h).
2. **Refuse or ask rather than guess.** Nothing is merged or chosen silently.
   - The HOLD ON still asks.
   - A reopen before any Save refuses to load over the kept work and says so (g).
   - When there is no room, the put-back is refused and said (h).
3. **Money and exports.** None is touched. The board's money paths, exports and the export suites are unchanged, and pass
   on c1: audit, audit-ppt, audit-other, audit-recon, boot-same and legacy-fsrc.
4. **Every word stays true after the operation lands.** The question now says S1 is also kept aside. The top bar, 📁 File
   and the status say what a swap copy is, and what Save will do. The HOLD ON's words are unchanged and still true: her
   file copy is overwritten, and it is not on screen. Each new word is checked by literal, and each has a mutation.
5. **Smallest change.** One condition (`keepScreen`) replaces `nowUnsaved` at the keep, plus one added sentence and three
   swap-only wording branches. There is no new state, storage key or path.
6. **Existing checks preserved.** Three existing expectations change, because each encoded the defect: a put-back of
   file-saved work kept nothing. They are listed in §5 with file:line, old, new and why. Every other existing check in
   the blocks that drive this function passes unchanged on c1:
   - the rest of v1.89;
   - both U2 blocks, including "work put back during a save stays unsaved" case (c);
   - the v1.95 "work kept aside is never replaced" block;
   - every suite run in §9.

## 5. Existing expectations changed (never silently)

Line numbers are the base `audit-import.mjs` (`4aba2506`) and c1's (`a1a3e32c`).

| # | where (base → c1) | old | new | why |
|---|---|---|---|---|
| 1 | v1.89 "saving never silently overwrites somebody's work", scenario "the file is newer": base L3512 → c1 L3512–3514 (one comment line added) | check "one click puts it back", got `note A|note B|String(kept===null)`, want `'BRAD NOTE||true'` (nothing kept after the put-back) | check "one click puts it back, and what was on screen (the colleague's copy, saved only in the file) is kept aside in its place", got `note A|note B|String(/COLLEAGUE NOTE/ in kept && !/BRAD NOTE/ in kept)`, want `'BRAD NOTE||true'` (literal unchanged) | This is the U19 shape itself. The colleague's copy is saved only in the board file, and the next Save with OK would write Brad's work over it. It is now kept aside. |
| 2 | "v2.00 (U2) — put back waits for a save to finish", the `retry` helper's comment: base L7325–7326 → c1 L7327–7328 | "… kept in its place if no saved copy has it (`was`: null when S1 is saved)." | "… if no saved copy has it, or if it is saved only in a board file (v2.00, U19) (`was`: null when S1 is saved in the folder)." | Comment only; no check changes. |
| 3a | same block, case (d) "the board file: put back while S1's save writes; the save goes in": base L7396–7397 → c1 L7398–7401 (two comment lines added) | "put back again: one question; K on screen, unsaved; nothing kept in its place (S1 is saved)", want `[1,'K',true,true,true,null]` | "put back again: one question; K on screen, unsaved; S1 kept aside in its place (saved only in the board file: v2.00, U19)", want `[1,'K',true,true,true,'S1']` | This is the route the lead's brief names (~L7396). S1 is saved only in the file, so it is now kept aside. |
| 3b | same case: base L7398 → c1 L7402 | `await afterFile(A, f, sc, ['S1', 'K'])`: reopened, S1 on screen and K kept | `await afterFile(A, f, sc, ['K', 'S1'])`: reopened, K on screen and S1 kept | This is the reopen before any Save with S1 kept (risk 1, measured in U19 case (g)). The file's newer copy is the very copy kept aside, so it is not loaded over K. Both are still each in a copy (the check's other two values, `true,true`, are unchanged). |

**Each shown both ways** (focused harnesses, §6):
- **c1's expectations on the base fail exactly there:** v189.c1 on base 1 fail (row 1), U2.c1 on base 2 fail (3a, 3b).
- **The base's expectations on c1 fail exactly there:** v189.base on c1 1 fail, U2.base on c1 2 fail.
- **Each set passes on its own board:** v189 40/40, U2 57/57.

**Observed differently, no expectation changed.** "v2.00 (U2) — work put back during a save stays unsaved", case (c),
around base L7228–7244. When U2 refuses the put-back during the save, the case puts back afterwards with S1 saved. On c1,
S1 is then also kept aside, but the case checks only that K is written, and it passes unchanged.

## 6. The tests: focused harnesses, base against c1

**How the harnesses are built.** `mk-harness.sh` runs `bin/mkfocused-u2.py`, unchanged from `rec/L2/u2impl`. It copies each
harness VERBATIM from the given suite file:
- its imports, failure list, keepBoards, SEEN/chk, the named block, the scenario-ran guard;
- every top-level helper the block references (here MINE, W1H, base, d, it).

**How they are run.** `bin/runner.mjs` (= `rec/L2/u2impl/runner.mjs`) imports the copy's shim, then the copy's own
`boot.mjs`. BOARD is unset (asserted to be that copy's board), or set to a mutant. Every check is recorded with
SUITE_CHECKS in `out/<label>.checks.jsonl`. The run tag is r2, against the current blobs.

| harness (from) | on base `fce8a391` | on c1 `8cf14d7e` |
|---|---|---|
| U19 (c1's block, 71 checks) | **34 fail**, 37 pass; 0 CONTROL rows fail. Fails by scenario: (a) 8, (b) 4, (c) 5, (d) 4, (e) 4, (f) 5, (g) 3, (h) 1. The controls (i)–(l) all pass. | **71/71 pass** |
| U2, both blocks (c1's expectations, 57) | 2 fail: (d) rows 3a, 3b | 57/57 |
| U2, both blocks (the base's, 57) | 57/57 | 2 fail: (d) rows 3a, 3b |
| v1.89 (c1's, 40) | 1 fail: row 1 | 40/40 |
| v1.89 (the base's, 40) | 40/40 (earlier run r1) | 1 fail: row 1 |
| v1.95 "work kept aside is never replaced" (10; identical in both suites) | 10/10 | 10/10 |

**The U19 block's scenarios** (`v2/block-u19.v2.mjs.txt`, in c1 at L7804–8093):

| case | what it drives |
|---|---|
| (a) | The board file. S1 typed and saved through 💾 Save, then ↶ Put back from the top bar, then 💾 Save with the HOLD ON answered OK, then a reopen. S1 is then put back from the reopened board, which keeps K in its place, and Save asks before writing S1. |
| (b) | ↶ Put back pressed while S1's save writes (refused, U2), and again once it has landed; then Save with OK, then a reopen. |
| (c) | S1 typed in the 📄 Description & note editor; 📁 File → 💾 Save, → ↶ Put back, → 💾 Save; then a reopen. |
| (d) | No file handle remembered: the first Save opens the picker once, and the second reuses it. |
| (e) | Two writers with their own keys. Bob's Save is refused, and his ✍ Take the pen… writes N. Alice reopens (K kept, N opened); her Save is refused, and her Take the pen writes S1. Then put back, Save with OK, and a reopen. |
| (f) | K put back, then S1 put back again before any Save. Save asks nothing and writes S1, and the words do not claim someone saved since. |
| (g) | K put back, then a reopen before any Save. K stays on screen, unsaved; S1 is kept and in the file; "… not loaded and nothing was lost". |
| (h) | No room in browser storage to keep S1. The put-back is asked, then refused; nothing changed, and that is said. |
| (i) | CONTROL: the HOLD ON answered Cancel. |
| (j) | CONTROL: S1 never saved (kept as before). |
| (k) | CONTROL: the shared folder. Nothing is kept in place, and "Save yours over theirs" keeps S1 in the folder history. |
| (l) | CONTROL: ordinary editing. The Change journal keeps S1 → the retyped note. |

**Expected values.** Every expected value is a hand-written literal: note texts, booleans, counts, kept-slot pairs, and
regexes on the product's own words. Board helpers are used only for OBSERVED values.

## 7. Mutations

**Where the six new entries go.** They are inserted as text before "  // v2.00 (R3, Brad 11 Oct): a save that lands under a
locked view says it saved the working plan." (`bin/edit-mutate.py`). Each find matches c1's board exactly once
(`mut/c1/*.mkmut.json`, and mcount).

**How each was run.** Each mutant was made by `rec/bin/mkmut.py` (text only) and run through the focused harnesses on
c1, with BOARD set to the mutant. `mutate.mjs` was never imported or run.

| id | what it breaks | caught (failing checks) |
|---|---|---|
| `v200-u19-putback-keeps-nothing-saved` (`keepScreen=nowUnsaved`; mutant `cbd88dc6`) | The keep-aside is dropped: the pre-fix behaviour. | U19: 34 of 71, the base's exact 34. U2: 2 (rows 3a, 3b). v1.89: 1 (row 1). |
| `v200-u19-putback-promise-unkept` (`if(nowUnsaved){` at the keep; `acb9d348`) | The question says S1 is kept aside, but nothing is kept. | U19: 27 of 71, in every changed scenario (a)–(h). U2: 2. v1.89: 1. |
| `v200-u19-putback-question-unsaid` (`d4a756aa`) | The question no longer says it is kept aside. | U19: 8, the question check in (a)–(g), plus (a)'s reopened put-back. |
| `v200-u19-swap-status-names-saver` (`1107a7a0`) | The status after putting a swap copy back says "…, which Alice saved after it". | U19: 2, the status checks in (a) and (f). |
| `v200-u19-swap-title-unsaved` (`9fefcad9`) | The top bar calls a swap copy "work … that no saved copy had". | U19: 3, the title checks in (a). |
| `v200-u19-swap-menu-replaced` (`8b195f25`) | 📁 File says "from before the saved file replaced it". | U19: 2, the 📁 File checks in (a) and (c). |

**Existing mutations near the change, re-run on c1** (each find still matches exactly once; every one is still caught):

| id | on the base (base harnesses) | on c1 (c1 harnesses) |
|---|---|---|
| `putback-drops-screen` (`nowUnsaved=false`) | U2 11 fail; v1.95 kept 1 fail; v1.89 0 | U19 2 fail ((f) and the (j) CONTROL); U2 7 fail; v1.95 kept 0; v1.89 0 |
| `v200-u2-putback-gen` | (not re-run on the base) | U2 1 fail ((d) count); U19 0 |
| `v200-u2-putback-while-saving` | (not re-run on the base) | U2 35 fail; U19 7 fail ((b)) |

**Sensitivity note for the lead.** On c1, the v1.95 "work kept aside" block no longer catches `putback-drops-screen`.
That mutant zeroes `nowUnsaved`, but a board file now keeps what is on screen anyway, so that block's file-mode put-back
still keeps BRAD TWO. The mutant is still caught inside audit-import, by the U2 blocks' folder cases and by U19 (f)/(j). The
mutate sweep's import suite therefore still catches it. Its full-suite run is the lead's.

## 8. Probes (reproduction on the base; the same probes on c1)

**On the base** (the earlier builder's runs, all with exit records, plus my pen runs):
- **The builder's L4 probe** (`u19probe.mjs` + `check.mjs`): 77 pass, 4 fail. The 4 are the PROPERTY rows "S1 is still in a
  copy this board can reach" after 💾 Save and after reopening, in file-after and file-retry. The controls file-cancel,
  file-unsaved, folder-after and folder-retry all pass.
- **The checker's variants** (`x19.mjs` + `xcheck.mjs`): 66 pass, 18 fail. That is 16 U19 rows (ui-after, picker-after,
  multi-after) plus the two calib-H0 rows the checker kept as refuted. The controls multi-cancel, multi-unsaved and
  multi-ordinary pass.
- **The checker's pen route** (`x19pen.mjs` + `xcheck-pen.mjs`, new here, runs `x-base-pen-*`, `xpchk-base`): 73 pass,
  4 fail. The 4 are the pen-after PROPERTY rows. S1 is in no place, no storage key and no file byte after the Save and
  after the reopen, and only in the stand-in version history. pen-cancel passes. **So U19 reproduces on the L6 base on all
  five routes.**

**On c1** (`p-c1-*`, `x-c1-*`, `chk-c1`, `xchk-c1`, `xpchk-c1`). These probes' literals describe the base board, so some
rows fail on c1 by design.
- **Every "S1 is still in a copy this board can reach" PROPERTY row passes** on all five routes, after the Save and after
  the reopen. S1 is in `prio27om.kept` (`[["kept"],["prio27om.kept"],0,1]` on pen-after).
- **Rows that fail on c1, and why:**
  - the board-blob literal, `fce8a391`, in each scenario;
  - "NOTHING kept in its place", and the "U19 shape" rows: both encode the defect;
  - the v2 rows "S1's text is findable in the Change journal panel": not covered, because S1's journal is in the kept
    copy, not in K's file journal;
  - the refuted calib-H0 rows, as on the base;
  - the Cancel controls' reopen rows (multi-cancel, pen-cancel): reopened after a Cancel, K (unsaved) stays on screen and
    S1 is kept as well as in the file, where the base opened S1 and kept K. This is the same reopen behaviour as U19 (g)
    and U2 row 3b. Every copy is still reachable.

**Counts on c1:** check.mjs 70 pass / 11 fail; xcheck.mjs 56 / 28; xcheck-pen 69 / 8.

**Measured on c1's pen-cancel reopen** (`out/probe-c1/pen-cancel.json`): the status reads "⚠ Alice saved a newer copy to
the saved file (…), but this browser already keeps earlier work aside (kept …) and holds new work besides. Kept work is
never replaced, so the newer copy was not loaded and nothing was lost. Deal with the kept work first: …". **The header
reads "Saved 12:08 AM · ↶ work kept aside" while the record says unsaved** (`base.dirty` true, `DIRTY` false). By code
this is the board's existing opening behaviour: DIRTY starts false at every opening, and nothing sets it from the record.
The same header shows on the base's existing "occupied" and "this browser's copy is newer" openings. It is not changed
here (principle 5). It is now reachable by "put back, then reopen before any Save", where the base opened the file's
copy instead. **I flag it for the lead as an open wording point; it is not measured on the base.**

## 9. The other suites, and npm run check

Both runs are in scratch clones (`git/base`, `git/c1`: `git clone --shared --no-checkout /home/user/orbit-board`, detached
at `7ee498a`, never committed in). `git/c1` has c1's board and audit-import copied over. Its `tools/export-audit/mutate.mjs`
is left as git has it, because no suite run here reads it and nothing here runs it. Each suite ran from the clone's root as
`node tools/export-audit/<suite>.mjs`, or as `npm run check`.

| suite | base | c1 |
|---|---|---|
| boot-same | "every page, source, save and error list is identical either way", exit 0 | same, exit 0 |
| audit | ALL CHECKS PASSED, 0 | ALL CHECKS PASSED, 0 |
| audit-ppt | ALL CHECKS PASSED, 0 | ALL CHECKS PASSED, 0 |
| audit-other | ALL CHECKS PASSED, 0 | ALL CHECKS PASSED, 0 |
| audit-recon | ALL CHECKS PASSED, 0 | ALL CHECKS PASSED, 0 |
| legacy-fsrc | "every legacy Force setting computes exactly as before", 0 | same, 0 |
| audit-hostile | ALL CHECKS PASSED, 0 | ALL CHECKS PASSED, 0 |
| audit-inject | ALL CHECKS PASSED, 0 | ALL CHECKS PASSED, 0 |
| npm run check | all checks passed, 0 | all checks passed, 0 (BUILD v2.00 (11 Oct 2026); both "tracked by git" rows ok) |

**Not run:** the full audit-import and audit-board (the lead's). The lock file was absent at every check, so no run waited
and none was skipped.

## 10. mcount (text only, `rec/bin/mcount.py`, `python3 -I`)

- **c1:** c1's mutate text against c1's board: 1334 entries, 1334 exactly once, none missing, multiple or unparsed.
- **Base:** the base's mutate text against the base board: 1328 entries, 1328 once.
- **c1's mutate text against the base board:** 1328 once; the six new ids are missing, as expected, because they find new
  code.
- Outputs are in `out/mcount/`.

## 11. Blobs (`git hash-object`)

| file | base | c1 |
|---|---|---|
| `prioritization-board-grid.html` | `fce8a391bd8a248d5185e199d22190c1687eaea0` | `8cf14d7e6baf8fa6f590e3082a2ed429458c3490` |
| `tools/export-audit/audit-import.mjs` | `4aba2506a7ea3bd367fb74436172b188bb4fc887` | `a1a3e32c67ca632ce9fb5e8f69ddae5f7881d3e4` |
| `tools/export-audit/mutate.mjs` (as `mutate.mjs.txt`) | `cbc6defc6803851e847844848fc9b186daeeb268` | `67ec010fe747ce2c1fb02987f19a1a4f48429aac` |
| `tools/export-audit/audit-recon.mjs` | `529e36f7…` | unchanged |
| `tools/export-audit/audit-board.mjs` | `a7c575e5…` | unchanged |
| `tools/export-audit/audit-other.mjs` | `d89396b0…` | unchanged |
| everything else in the copy | — | byte-identical to the base (`diff -rq`) |

**Diffs** (`diffs/`):

| file | blob | added | removed |
|---|---|---|---|
| `c1-board.diff` | `fbfcfa39` | 18 | 6 |
| `c1-audit-import.diff` | `6d67a515` | 299 | 5 |
| `c1-mutate.diff` | `8f086db2` | 19 | 0 |
| `c1-all.diff` | `8548c774` | — | — |

All are in the appendix.

**Tools, harnesses and probes:**

| file | blob |
|---|---|
| `bin/edit-board.py` | `5d8234c3a5664a663320f94068ec7b8eb562ca30` |
| `bin/edit-import.py` | `df1073a4d313b9e63b2d1750ddb9b8633c6108dc` |
| `bin/edit-mutate.py` | `1ea2739cb54a873f3b6410ea0ee4062ed3cac7d8` |
| `bin/mkfocused-u2.py` | `252c00ef658b2db1d8810b0f3d42348f151b1136` |
| `bin/runner.mjs` | `f720ce184998cf31cad50d288f78c2f7bac19bd6` |
| `bin/tally.py` | `3ad4db88d6855d3b9b7bf7894706a40221473fcc` |
| `bin/fails.py` | `416435180988e20ffcdca5d6209238b09a4978cb` |
| `bin/runstable.py` | `0f016aa3df182b7ceea0e8c62cb7d4a4af915e2e` |
| `block-u19.mjs.txt` | `797d7f0771308b5bf1522ad08a307f83a96f4f68` |
| `v2/block-u19.v2.mjs.txt` | `ca9570dcc23c0b1750459b34488dfd6fbb56f52b` |
| `v2/mkblock2.py` | `135bd4fe3320db8662f26a555e153e7e61e4c66e` |
| `v2/build-c1.sh` | `8758ceb4892e41ffd149be51d32d63062037a8d7` |
| `v2/mkdiffs.sh` | `9722da541f7d69e01ba9b774f4214a55c5acb1b5` |
| `v2/mkpen.sh` | `115706abb50146ef47550dc7b2666dd737a6faeb` |
| `v2/assemble.sh` | `eaaf1ffe9b739ecd4825d2d36d49287ada54ec33` |
| `run.sh` | `a1bf14f89027682e220945aabed5eabde0a0d2ff` |
| `bx.sh` | `34bc4062da4b0003f6e927425f8fc453aef68124` |
| `mk-harness.sh` | `941a5a7dd06bcb4c6e6db721555fefbab5a8dd7b` |
| `focused-runs.sh` | `551bbd5fe1e472dd427e8a3f2dcde1edd139e136` |
| `mut-runs.sh` | `89c7cac9bf3ed55d77e7a8638bbe10048aac7352` |
| `suites.sh` | `462e0bab15892e1a5edf3c46163b77de13b3eecb` |
| `probe-runs.sh` | `9a842293a142fdfd827ac1b5454143865de0419d` |
| `probe-multi.sh` | `66b6a8fd420f27d3a95988ba935a3f763b79d329` |
| `probe-pen.sh` | `739704bc0a0c9e081a2a1b699e13775b55a06103` |
| `probe-checks.sh` | `c2a82774e13ffbba6f6cd9691cddbbf9ab1eadda` |
| `recheck/recheck.sh` | `2915d4b5069d04def762892fa18d724afd273a9a` |
| `git/mkclones.sh` | `ebebfd42d0e1c3316501c434410895c5778bf5ad` |
| `probe/u19probe.mjs` | `80b848ab5b20b65c47f050e016ff890434a31234` |
| `probe/check.mjs` | `490b8c3e9b513d10420700b882cff3ecaa956072` |
| `probe/x19.mjs` | `cbca9776f83fe695dedb4a1217ace6d0575add3c` |
| `probe/xcheck.mjs` | `87fecf8a0bcbf068b8369b45f1cbc8a6d0f3ecea` |
| `probe/x19pen.mjs` | `3db9706f6d490d86bcecc446c223316017fe4ee2` |
| `probe/xcheck-pen.mjs` | `6e4ccb5204587014a87a1c1dcdbfd2db7f510d5e` |
| `h/src-c1/U19.c1.mjs` | `7e20c5828fb19f7c75f0292564f6f9f6629798ba` |
| `h/src-c1/U2.c1.mjs` | `a1edf6a8f1f26605483bec1e595ce6b9451bc54d` |
| `h/src-c1/v189.c1.mjs` | `49261f6a8468169e7272f828a4f88a59fec0660d` |
| `h/src-c1/v195kept.c1.mjs` | `f2adbb73140847e201c0858b0147ace0245b7e81` |
| `h/src-base/U2.base.mjs` | `32cc5ac772e47018425e21dd22ef15064b00e52f` |
| `h/src-base/v189.base.mjs` | `ed54e6137e0a405f9262e1628ded4e6be6ca796e` |
| `h/src-base/v195kept.base.mjs` | `f2adbb73140847e201c0858b0147ace0245b7e81` |
| `../base/tools/export-audit/boot.mjs` (each copy's own, identical) | `9c4f49ad8cec537097bdf485458cfd2a09b06594` |
| `../base/runtime-encoding-shim.mjs` (each copy's own, identical) | `6e2ce2e6beda9e7526527530500f254d877d0320` |

Mutant boards (`mut/blobs.txt`):

- mutant v200-u19-putback-keeps-nothing-saved on c1: cbd88dc6a75cbcbf7f36dd0060f8a18eb7a3e06b
- mutant v200-u19-putback-promise-unkept on c1: acb9d3480612653ba35e744c186e84c7fa2bde8f
- mutant v200-u19-putback-question-unsaid on c1: d4a756aa99b398ec30f124db532924d73e093346
- mutant v200-u19-swap-status-names-saver on c1: 1107a7a044582ff69bfe188c1aa46ab8b3343b3b
- mutant v200-u19-swap-title-unsaved on c1: 9fefcad94f87d8b69f06c45bd50c28f53f9fdca1
- mutant v200-u19-swap-menu-replaced on c1: 8b195f25ca23c5b2143120706a5a5b7b9ad923d5
- mutant putback-drops-screen on c1: 5437317959e737b6ae033c35147d8cdc6689738c
- mutant v200-u2-putback-gen on c1: 216c41747a30d5314f70e0b3bab0e8c2f2bf51b1
- mutant v200-u2-putback-while-saving on c1: 4ff1e6ec7ed5bb576395a22202aa3b75b36d9d52
- mutant putback-drops-screen on base: 40d21588970699717ac7c9c9324856fa85e55bb2

## 12. Drafts for the lead (the lead commits; I did not)

### 12.1 NEXT-VERSION.md, under v2.00, after the U14 entry and before "Unresolved after R1–R5"

```
- **U19 — ↶ Put back after a board-file save keeps what it replaces** (Brad, 12 Oct, about 5:30 PM ET: "Don't wait for me.
  Let's keep pressing throughout to get this next version published."; the lead's decision to fix the release blockers).
  With work saved into the board file (S1), ↶ Put back of the work kept aside (K) kept nothing in S1's place, because S1 was
  "still in the saved file it came from, and 💾 Save will ask before writing over that". Save did ask (its HOLD ON), but
  answered OK it wrote K over S1, and then S1 was in no copy this board could reach: not on screen, not kept aside, not in
  browser storage, not in a byte of the file, after the Save and after a reopen. It was left only in Teams version history,
  outside the board, where the file has one. The shared folder keeps the copy a save replaces in its history; a board file
  keeps none. Now, when 💾 Save writes to a board file, what is on screen is kept aside in the kept work's place whether or
  not it is saved, as unsaved work always was, with the checkpoint it came from. Putting it back later restores it, and Save
  asks again before writing over the file. The question adds "It is also kept aside in its place, so it is not lost if Save
  does." With no room in browser storage to keep it, nothing is put back and nothing changes, as for unsaved work. The words
  for a copy kept at a put-back no longer call it work no saved copy had or say a saved copy replaced it: the top bar's
  ↶ work kept aside says "What was on screen when other work was put back, kept aside …", 📁 File says "kept … · what was on
  screen when other work was put back", and putting such a copy back says "💾 Save will ask before it writes over a copy saved
  after the one this work came from." The shared folder is unchanged. The HOLD ON's words are unchanged.
  - **What users may see:** after ↶ Put back on a board file, the top bar keeps offering ↶ work kept aside (what was on
    screen) until it is put back, saved as a file or discarded. While it is kept, a newer copy that would need work kept
    aside is not loaded, and the board says so, as it already did for unsaved work. This includes reopening the file
    before any Save after the put-back: K stays on screen, unsaved, and the file's copy (S1, the very copy kept aside) is
    not loaded ("… the newer copy was not loaded and nothing was lost"); before, S1 opened and K was kept. A put-back in a
    browser whose storage is full is now refused, with "nothing was changed", where it used to go ahead.
  - **Test:** audit-import "v2.00 (U19) — put back after a board-file save keeps what it replaces" (71 checks). It drives the
    routes through the page's own buttons and menus: put back once S1's save has landed; put back while it writes (refused,
    U2) and again once it has landed; through 📁 File and the note editor; with no file handle remembered (the picker); and
    between two writers, each with their own key (✍ Take the pen, both ways). Each route then runs 💾 Save with the HOLD ON
    answered OK and a reopen. It also covers S1 put back again before any Save, a reopen before any Save, and no room in
    browser storage. The controls are the HOLD ON answered Cancel, S1 never saved, the shared folder and ordinary editing.
    34 checks fail on the board before the change, all in the eight changed scenarios; every control passes on both.
  - **Existing expectations changed (3, each listed with old → new in the builder's record):** v1.89 "the file is newer",
    "one click puts it back": the kept slot was empty after the put-back and now holds the colleague's copy. "v2.00 (U2) — put
    back waits for a save to finish", case (d), the board file: "put back again" kept nothing (`null`) and now keeps S1
    (`'S1'`), and the reopen then shows K with S1 kept (`['K','S1']`, was `['S1','K']`).
  - **Mutations:** `v200-u19-putback-keeps-nothing-saved`, `-putback-promise-unkept`, `-putback-question-unsaid`,
    `-swap-status-names-saver`, `-swap-title-unsaved` and `-swap-menu-replaced`; each caught by the focused block (full-suite
    sensitivity runs in the final-tree queue).
  - **Not covered:** the file's own Change journal after K's Save keeps no trace of S1; S1 and its journal are in the kept
    copy. The HOLD ON still calls the person's own save "their changes" (the triage's O1), and after a take-the-pen route
    the put-back status still names the writer the kept work came from ("which Bob saved after it"); both are wording points,
    not changed here. Reopened before any Save, the top bar says "Saved" while the work on screen is unsaved by the record;
    this is the board's existing opening behaviour, now reached on this route too. A HOLD ON answered OK over another
    writer's file copy, not after a put-back, still leaves that copy only in Teams version history. A second tab of the same
    browser (U20) and a real browser (Chromium) were not run.
```

### 12.2 "Unresolved after R1–R5 (11 Oct)" (NEXT-VERSION.md)

The U2 bullet's last sentence, "Its separate reopening and adoption findings stay open in the ledger (U15–U20).", becomes:

```
    Its separate reopening and adoption findings stay open in the ledger (U15–U18 and U20); U19 is built (below).
```

Add a new bullet after the U14 bullet:

```
  - **U19: built as its own commit** (the lead's decision under Brad's "Don't wait for me", 12 Oct, about 5:30 PM ET): a
    ↶ Put back after a board-file save keeps what it replaces aside, so 💾 Save's HOLD ON answered OK no longer leaves it in
    no copy this board can reach (above). Three wording points stay open: the HOLD ON's "their changes" for the person's own
    save (O1); the put-back status naming the earlier writer after a take-the-pen route; and the top bar's "Saved" on a
    reopen before any Save while the work on screen is unsaved by the record.
```

### 12.3 UNRESOLVED-LEDGER.md

Append to the Status cell of the first U19 row:

```
 **Built as its own commit `<sha>` (<time> ET)** under the lead's decision of 12 Oct (Brad, about 5:30 PM ET: "Don't wait
 for me."): board `8cf14d7e`, audit-import `a1a3e32c`, mutate `67ec010f`. `keptPutBack` keeps what is on screen aside in the
 kept work's place whenever 💾 Save writes to a board file (`!driveStoreOn()`), saved or not, as unsaved work always was.
 The question says so, and the words for a copy kept at a put-back ('swap') no longer call it unsaved or replaced, in the top
 bar, 📁 File and the put-back status. Focused block "v2.00 (U19)": 71 checks, 34 fail on the board before (`fce8a391`, product d66dd60), all
 pass after; every control passes on both. It covers five routes: file-after, file-retry, ui-after (📁 File and the note
 editor), picker-after and pen-after (two keys, ✍ Take the pen both ways). The checker's probes on the fixed copy find S1
 reachable after the Save and after reopening on all five. Three existing expectations changed: v1.89 "the file is newer",
 and two in U2 put back waits case (d). Each is listed old → new in the builder's README (`rec/L6/u19`). Six mutations,
 each caught by the block. The folder route is unchanged. Open:
 - the HOLD ON's "their changes" for her own save (O1), and the put-back status naming the earlier writer after a
   take-the-pen route (wording);
 - the top bar's "Saved" on a reopen before any Save while the record says unsaved (the existing opening behaviour, now on
   this route);
 - the file's Change journal keeps no trace of S1 (S1 is in the kept copy).
 The full audit-import and audit-board runs, and the final-tree mutation queue, are the lead's.
```

Append to the Status cell of the P1 table's U19 row:

```
 Built: see the U19 row (`<sha>`).
```

## 13. What I did not do, and rule deviations (plainly)

**Not done:**
- **Not run (the lead's):** the full audit-import and audit-board, and the mutate sweep. `mutate.mjs` was read as text
  only, through mcount and mkmut.
- **Not run:** Chromium, Playwright and the verify:grid tools, including keyboard-reach.mjs. That tool finds the top bar's
  ↶ button by its onclick, not its title, so by code it is unaffected.
- **Not changed:**
  - the HOLD ON's wording (O1);
  - the put-back status for 'file' kept copies ("which Bob saved after it" after a take-the-pen route, CHECK §9.3.1);
  - the opening's "Saved" header with unsaved work on the record (§8);
  - the file's Change journal (S1 lives in the kept copy).
  All four are listed as open for Brad.
- **Not measured:** the old swap status being false on the base's unsaved-swap route (§3); that is by code only.
- **Not tested:** a second tab of the same browser (U20), and a real disk or Teams version history.
- **Not touched:** nothing was committed, staged or pushed. Nothing in `/home/user/orbit-board` or `/home/user/orbit-ui` was
  written: the clones are `--shared`, and only read its objects. The board stays the empty template; all data is synthetic,
  made at run time.

**Deviations from the run rules, disclosed:**
- **Read-only commands ran without `setsid -w timeout -k 10 600`:** `cat`, `sed`, `grep`, `ls`, `diff` (to the screen),
  `git hash-object`, `git log` and `git status`, plus `mkdir -p` of my own directories and a `cp`/`rm` of the r1 base
  harnesses (to `.r1`, for the byte comparison in §2). The README parts were written with the editor tool, not a
  command. Every node run went through `run.sh`, and every script that writes files went through `bx.sh` or `run.sh`,
  which record their PIDs.
- **Two chains** (the base suites, and mutants M2 plus the probes) were sequenced by an unwrapped background shell calling
  several `bx.sh` steps. Each step was bounded at 600 s, and the sequence itself was not.
- **Three `until … sleep 5` waits** were bounded by `timeout 590`/`300`, and are not in pids.txt.
- **No process was killed.** I killed nothing, by PID, name or pattern.

## 14. PIDs

`pids.txt` lists every bounded command's `timeout` PID and its child, with the time, the label and the command.
- Lines 1–85 are the earlier builder's (5:59–6:17 PM ET).
- Lines 86 onward are mine (7:37 PM ET onward).
No PID was ever killed.

## 15. Every run

`logs/runs.txt` holds every run: the earlier builder's 29 (5:59–6:17 PM ET) and this session's (7:39 PM ET onward). Each
has an exit record and a log in `logs/<label>.log`, which carries its start and end time. None timed out, none waited for
the lock, and none was skipped. The table below is generated from `logs/runs.txt` by `bin/runstable.py`; exit 1 on a
focused or mutant run means checks failed, as expected where the tables above say so.

| label | start (ET) | exit | wall s | log |
|---|---|---|---|---|
| p-base-file-after | 17:59:56 | 0 | 5.2 | `logs/p-base-file-after.log` |
| p-base-file-retry | 18:00:01 | 0 | 5.1 | `logs/p-base-file-retry.log` |
| p-base-file-cancel | 18:00:07 | 0 | 5.3 | `logs/p-base-file-cancel.log` |
| p-base-file-unsaved | 18:00:12 | 0 | 5.2 | `logs/p-base-file-unsaved.log` |
| p-base-folder-after | 18:00:17 | 0 | 5.4 | `logs/p-base-folder-after.log` |
| p-base-folder-retry | 18:00:22 | 0 | 5.7 | `logs/p-base-folder-retry.log` |
| x-base-ui-after | 18:00:28 | 0 | 6.2 | `logs/x-base-ui-after.log` |
| x-base-picker-after | 18:00:34 | 0 | 5.6 | `logs/x-base-picker-after.log` |
| chk-base | 18:00:45 | 0 | 0.1 | `logs/chk-base.log` |
| xchk-base | 18:00:45 | 0 | 0.1 | `logs/xchk-base.log` |
| x-base-multi-after | 18:00:57 | 0 | 5.9 | `logs/x-base-multi-after.log` |
| x-base-multi-ordinary | 18:01:03 | 0 | 6.1 | `logs/x-base-multi-ordinary.log` |
| x-base-multi-unsaved | 18:01:09 | 0 | 6.0 | `logs/x-base-multi-unsaved.log` |
| x-base-multi-cancel | 18:01:15 | 0 | 6.5 | `logs/x-base-multi-cancel.log` |
| xchk-base2 | 18:01:22 | 0 | 0.2 | `logs/xchk-base2.log` |
| t1-U19-on-c1 | 18:11:33 | 1 | 22.1 | `logs/t1-U19-on-c1.log` |
| t2-U19-on-c1 | 18:12:45 | 0 | 22.7 | `logs/t2-U19-on-c1.log` |
| F-r1-U19.c1-on-c1 | 18:13:25 | 0 | 22.8 | `logs/F-r1-U19.c1-on-c1.log` |
| F-r1-U19.c1-on-base | 18:13:48 | 1 | 25.4 | `logs/F-r1-U19.c1-on-base.log` |
| F-r1-U2.c1-on-c1 | 18:14:13 | 0 | 44.3 | `logs/F-r1-U2.c1-on-c1.log` |
| F-r1-U2.base-on-base | 18:14:57 | 0 | 33.8 | `logs/F-r1-U2.base-on-base.log` |
| F-r1-U2.base-on-c1 | 18:15:31 | 1 | 40.7 | `logs/F-r1-U2.base-on-c1.log` |
| F-r1-U2.c1-on-base | 18:16:12 | 1 | 40.1 | `logs/F-r1-U2.c1-on-base.log` |
| F-r1-v189.c1-on-c1 | 18:16:52 | 0 | 10.0 | `logs/F-r1-v189.c1-on-c1.log` |
| F-r1-v189.base-on-base | 18:17:02 | 0 | 10.1 | `logs/F-r1-v189.base-on-base.log` |
| F-r1-v189.base-on-c1 | 18:17:12 | 1 | 10.5 | `logs/F-r1-v189.base-on-c1.log` |
| F-r1-v189.c1-on-base | 18:17:23 | 1 | 10.1 | `logs/F-r1-v189.c1-on-base.log` |
| F-r1-v195kept.c1-on-c1 | 18:17:33 | 0 | 7.1 | `logs/F-r1-v195kept.c1-on-c1.log` |
| F-r1-v195kept.base-on-base | 18:17:40 | 0 | 7.3 | `logs/F-r1-v195kept.base-on-base.log` |
| F-r2-U19.c1-on-c1 | 19:39:42 | 0 | 20.5 | `logs/F-r2-U19.c1-on-c1.log` |
| F-r2-U19.c1-on-base | 19:40:02 | 1 | 25.4 | `logs/F-r2-U19.c1-on-base.log` |
| F-r2-U2.c1-on-c1 | 19:40:28 | 0 | 33.5 | `logs/F-r2-U2.c1-on-c1.log` |
| S-boot-same-c1 | 19:41:10 | 0 | 9.3 | `logs/S-boot-same-c1.log` |
| S-audit-c1 | 19:41:19 | 0 | 7.6 | `logs/S-audit-c1.log` |
| S-audit-ppt-c1 | 19:41:27 | 0 | 3.9 | `logs/S-audit-ppt-c1.log` |
| F-r2-U2.c1-on-base | 19:41:01 | 1 | 35.9 | `logs/F-r2-U2.c1-on-base.log` |
| S-audit-other-c1 | 19:41:31 | 0 | 25.1 | `logs/S-audit-other-c1.log` |
| S-legacy-fsrc-c1 | 19:41:56 | 0 | 2.7 | `logs/S-legacy-fsrc-c1.log` |
| S-check-c1 | 19:41:59 | 0 | 3.3 | `logs/S-check-c1.log` |
| F-r2-U2.base-on-c1 | 19:41:37 | 1 | 34.5 | `logs/F-r2-U2.base-on-c1.log` |
| F-r2-U2.base-on-base | 19:42:12 | 0 | 47.7 | `logs/F-r2-U2.base-on-base.log` |
| F-r2-v189.c1-on-c1 | 19:42:59 | 0 | 19.9 | `logs/F-r2-v189.c1-on-c1.log` |
| F-r2-v189.c1-on-base | 19:43:19 | 1 | 20.1 | `logs/F-r2-v189.c1-on-base.log` |
| F-r2-v189.base-on-c1 | 19:43:39 | 1 | 20.5 | `logs/F-r2-v189.base-on-c1.log` |
| F-r2-v195kept.c1-on-c1 | 19:44:00 | 0 | 11.7 | `logs/F-r2-v195kept.c1-on-c1.log` |
| S-audit-recon-c1 | 19:42:14 | 0 | 124.1 | `logs/S-audit-recon-c1.log` |
| F-r2-v195kept.base-on-base | 19:44:12 | 0 | 10.2 | `logs/F-r2-v195kept.base-on-base.log` |
| S-audit-hostile-c1 | 19:44:19 | 0 | 50.8 | `logs/S-audit-hostile-c1.log` |
| M-M1-v200-u19-putback-keeps-nothing-saved-U19.c1-on-c1 | 19:44:34 | 1 | 36.6 | `logs/M-M1-v200-u19-putback-keeps-nothing-saved-U19.c1-on-c1.log` |
| S-audit-inject-c1 | 19:45:09 | 0 | 13.1 | `logs/S-audit-inject-c1.log` |
| S-boot-same-base | 19:45:30 | 0 | 11.6 | `logs/S-boot-same-base.log` |
| S-audit-base | 19:45:41 | 0 | 10.6 | `logs/S-audit-base.log` |
| M-M1-v200-u19-putback-keeps-nothing-saved-U2.c1-on-c1 | 19:45:10 | 1 | 45.5 | `logs/M-M1-v200-u19-putback-keeps-nothing-saved-U2.c1-on-c1.log` |
| S-audit-ppt-base | 19:45:52 | 0 | 4.6 | `logs/S-audit-ppt-base.log` |
| M-M1-v200-u19-putback-keeps-nothing-saved-v189.c1-on-c1 | 19:45:56 | 1 | 16.6 | `logs/M-M1-v200-u19-putback-keeps-nothing-saved-v189.c1-on-c1.log` |
| S-audit-other-base | 19:45:56 | 0 | 35.5 | `logs/S-audit-other-base.log` |
| S-legacy-fsrc-base | 19:46:32 | 0 | 5.7 | `logs/S-legacy-fsrc-base.log` |
| S-check-base | 19:46:38 | 0 | 5.4 | `logs/S-check-base.log` |
| M-M1-v200-u19-putback-promise-unkept-U19.c1-on-c1 | 19:46:13 | 1 | 51.4 | `logs/M-M1-v200-u19-putback-promise-unkept-U19.c1-on-c1.log` |
| M-M1-v200-u19-putback-promise-unkept-U2.c1-on-c1 | 19:47:04 | 1 | 60.8 | `logs/M-M1-v200-u19-putback-promise-unkept-U2.c1-on-c1.log` |
| M-M1-v200-u19-putback-promise-unkept-v189.c1-on-c1 | 19:48:05 | 1 | 21.9 | `logs/M-M1-v200-u19-putback-promise-unkept-v189.c1-on-c1.log` |
| M-M1-v200-u19-putback-question-unsaid-U19.c1-on-c1 | 19:48:27 | 1 | 43.6 | `logs/M-M1-v200-u19-putback-question-unsaid-U19.c1-on-c1.log` |
| S-audit-recon-base | 19:46:43 | 0 | 151.1 | `logs/S-audit-recon-base.log` |
| M-M1-v200-u19-swap-status-names-saver-U19.c1-on-c1 | 19:49:11 | 1 | 49.6 | `logs/M-M1-v200-u19-swap-status-names-saver-U19.c1-on-c1.log` |
| S-audit-hostile-base | 19:49:14 | 0 | 86.4 | `logs/S-audit-hostile-base.log` |
| M-M1-v200-u19-swap-title-unsaved-U19.c1-on-c1 | 19:50:01 | 1 | 66.7 | `logs/M-M1-v200-u19-swap-title-unsaved-U19.c1-on-c1.log` |
| S-audit-inject-base | 19:50:41 | 0 | 28.6 | `logs/S-audit-inject-base.log` |
| M-M1-v200-u19-swap-menu-replaced-U19.c1-on-c1 | 19:51:08 | 1 | 81.9 | `logs/M-M1-v200-u19-swap-menu-replaced-U19.c1-on-c1.log` |
| M-M2-putback-drops-screen-U19.c1-on-c1 | 19:52:47 | 1 | 91.1 | `logs/M-M2-putback-drops-screen-U19.c1-on-c1.log` |
| M-M2-putback-drops-screen-U2.c1-on-c1 | 19:54:18 | 1 | 84.8 | `logs/M-M2-putback-drops-screen-U2.c1-on-c1.log` |
| M-M2-putback-drops-screen-v195kept.c1-on-c1 | 19:55:43 | 0 | 27.7 | `logs/M-M2-putback-drops-screen-v195kept.c1-on-c1.log` |
| M-M2-putback-drops-screen-v189.c1-on-c1 | 19:56:11 | 0 | 20.3 | `logs/M-M2-putback-drops-screen-v189.c1-on-c1.log` |
| M-M2-v200-u2-putback-gen-U2.c1-on-c1 | 19:56:31 | 1 | 93.1 | `logs/M-M2-v200-u2-putback-gen-U2.c1-on-c1.log` |
| M-M2-v200-u2-putback-gen-U19.c1-on-c1 | 19:58:05 | 0 | 80.8 | `logs/M-M2-v200-u2-putback-gen-U19.c1-on-c1.log` |
| M-M2-v200-u2-putback-while-saving-U2.c1-on-c1 | 19:59:26 | 1 | 87.0 | `logs/M-M2-v200-u2-putback-while-saving-U2.c1-on-c1.log` |
| M-M2-v200-u2-putback-while-saving-U19.c1-on-c1 | 20:00:53 | 1 | 79.1 | `logs/M-M2-v200-u2-putback-while-saving-U19.c1-on-c1.log` |
| M-M2-putback-drops-screen-U2.base-on-base | 20:02:12 | 1 | 85.6 | `logs/M-M2-putback-drops-screen-U2.base-on-base.log` |
| M-M2-putback-drops-screen-v195kept.base-on-base | 20:03:38 | 1 | 29.7 | `logs/M-M2-putback-drops-screen-v195kept.base-on-base.log` |
| M-M2-putback-drops-screen-v189.base-on-base | 20:04:08 | 0 | 34.0 | `logs/M-M2-putback-drops-screen-v189.base-on-base.log` |
| x-base-pen-after | 20:04:42 | 0 | 19.1 | `logs/x-base-pen-after.log` |
| x-base-pen-cancel | 20:05:01 | 0 | 18.1 | `logs/x-base-pen-cancel.log` |
| xpchk-base | 20:05:19 | 0 | 0.3 | `logs/xpchk-base.log` |
| p-c1-file-after | 20:05:19 | 0 | 15.9 | `logs/p-c1-file-after.log` |
| p-c1-file-retry | 20:05:35 | 0 | 11.4 | `logs/p-c1-file-retry.log` |
| p-c1-file-cancel | 20:05:47 | 0 | 11.2 | `logs/p-c1-file-cancel.log` |
| p-c1-file-unsaved | 20:05:58 | 0 | 9.4 | `logs/p-c1-file-unsaved.log` |
| p-c1-folder-after | 20:06:07 | 0 | 10.0 | `logs/p-c1-folder-after.log` |
| p-c1-folder-retry | 20:06:17 | 0 | 7.9 | `logs/p-c1-folder-retry.log` |
| x-c1-ui-after | 20:06:25 | 0 | 12.2 | `logs/x-c1-ui-after.log` |
| x-c1-picker-after | 20:06:38 | 0 | 10.6 | `logs/x-c1-picker-after.log` |
| x-c1-multi-after | 20:06:48 | 0 | 13.1 | `logs/x-c1-multi-after.log` |
| x-c1-multi-ordinary | 20:07:01 | 0 | 12.9 | `logs/x-c1-multi-ordinary.log` |
| x-c1-multi-unsaved | 20:07:14 | 0 | 15.4 | `logs/x-c1-multi-unsaved.log` |
| x-c1-multi-cancel | 20:07:30 | 0 | 14.4 | `logs/x-c1-multi-cancel.log` |
| x-c1-pen-after | 20:07:44 | 0 | 14.7 | `logs/x-c1-pen-after.log` |
| x-c1-pen-cancel | 20:07:59 | 0 | 16.7 | `logs/x-c1-pen-cancel.log` |
| xpchk-c1 | 20:08:16 | 0 | 0.2 | `logs/xpchk-c1.log` |
| chk-c1 | 20:08:16 | 0 | 0.3 | `logs/chk-c1.log` |
| xchk-c1 | 20:08:16 | 0 | 0.2 | `logs/xchk-c1.log` |

## Appendix: exact diffs (c1 against the base)

### diffs/c1-board.diff

```diff
--- a/prioritization-board-grid.html
+++ b/prioritization-board-grid.html
@@ -6955,13 +6955,20 @@
   // WORK ON SCREEN THAT NO SAVED COPY HAS IS KEPT IN ITS PLACE (v1.95, item 50): putting work back
   // never throws away the work it replaces. The slot it frees takes what is on screen.
   const nowUnsaved=!!(DIRTY || baseGet().dirty);
+  // v2.00 (U19): A BOARD FILE KEEPS NO EARLIER COPY THIS BOARD CAN REACH. Work on screen saved only in the board file was not
+  // kept, since the file had it; but the next 💾 Save writes the work put back over that file once its HOLD ON is answered OK,
+  // and then the work that was on screen was in no copy this board could reach. The shared folder keeps the copy a save
+  // replaces in its history; a board file does not. So when Save writes to a board file, what is on screen is kept aside in
+  // its place whether or not it is saved, as unsaved work always was. No room to keep it: nothing is changed, as before.
+  const keepScreen=nowUnsaved || !driveStoreOn();
   if(!confirm('Put back the work this browser kept aside on '+fmtTs(k.meta.t)+'?\n\n'
     +'What is on screen now is replaced by it. '
     +(nowUnsaved? 'What is on screen now has changes no saved copy has, so it is kept aside in its place — nothing is lost.'
-                : 'What is on screen now is still in '+keptWhere(k.meta)+' it came from, and 💾 Save will ask before writing over that.'))) return;
+                : 'What is on screen now is still in '+keptWhere(k.meta)+' it came from, and 💾 Save will ask before writing over that.'
+                  +(keepScreen? ' It is also kept aside in its place, so it is not lost if Save does.' : '')))) return;
   let st; try{ st=JSON.parse(k.raw); }catch(e){ setStat('⚠ The work kept aside could not be read ('+esc(e.message)+'). It is still kept; nothing was changed.'); return; }
   let swapped=null;
-  if(nowUnsaved){
+  if(keepScreen){
     const m2={t:Date.now(), why:'swap', by:whoIs()||'', ts:+MS.ts||0, base:baseGet()};
     const str=JSON.stringify(m2)+'\n'+JSON.stringify(MS);
     try{ localStorage.setItem(_AP.key+'.kept', str); swapped=m2; }
@@ -6985,8 +6992,11 @@
   // count unmoved and marked the board saved, while the folder or file holds what that save wrote. Now that save finds the
   // count moved, leaves the work put back unsaved and says so, and the next Save writes it.
   persist(); _saveGen++; DIRTY=true; render();
-  setStat('↶ <b>Put back</b> the work kept aside on '+esc(fmtTs(k.meta.t))+'. 💾 Save will ask before it writes over '
-    +esc(keptWhere(k.meta))+', which '+esc(k.meta.by||'someone')+' saved after it.'
+  // v2.00 (U19): work kept aside at a put-back ('swap') was not replaced by a newer save, and nobody need have saved since: the
+  // rule Save follows is said instead, which holds either way.
+  setStat('↶ <b>Put back</b> the work kept aside on '+esc(fmtTs(k.meta.t))+'. '
+    +(k.meta.why==='swap'? '💾 Save will ask before it writes over a copy saved after the one this work came from.'
+      : '💾 Save will ask before it writes over '+esc(keptWhere(k.meta))+', which '+esc(k.meta.by||'someone')+' saved after it.')
     +(swapped? ' What was on screen is <b>kept aside</b> in its place: <button type="button" class="nb lnk" onclick="keptPutBack()">put that back</button>.' : ''));
 }
 // SAVE THE KEPT WORK AS A FILE (v1.95, item 50): a board file holding it, to open or hand on. Saving it
@@ -25908,7 +25918,8 @@
   // v1.89: while work is kept aside, the header says so -- an opening message can be replaced by the next.
   // v1.91 (item 29): a button -- it was a link with no address, which a keyboard never reaches.
   if(ss && _keptMeta) ss.innerHTML += ' \u00b7 <button type="button" class="keptbtn" onclick="keptPutBack()" '
-    +'title="Work this browser held that no saved copy had, kept aside '+esc(shortTs(_keptMeta.t))+'. Put it back.">\u21b6 work kept aside</button>';
+    +'title="'+(_keptMeta.why==='swap'? 'What was on screen when other work was put back' : 'Work this browser held that no saved copy had')   // v2.00 (U19)
+    +', kept aside '+esc(shortTs(_keptMeta.t))+'. Put it back.">\u21b6 work kept aside</button>';
   if(sb && _sb){
     sb.className='btn pri'; sb.textContent='\u2709 Submit input'; sb.setAttribute('onclick','pmoSubmit()');
     sb.title='Send your office\u2019s changes to the portfolio team as a small submittal file. Your work is already kept in this browser.';
@@ -26237,7 +26248,8 @@
     mi('💾 Save',"mRun(saveInPlace)",false,_SB? 'turned off in a PMO copy \u2014 use \u2709 Submit input' : 'writes back to this file, in place')+
     mi('⬇ Save a copy…',"mRun(publishState)",false,_SB? 'turned off in a PMO copy' : 'downloads a duplicate')+
     // v1.89: work this browser kept aside when a newer saved copy replaced it. Here, unfolded, as long as it is kept.
-    (_keptMeta? mi('\u21b6 Put back work kept aside\u2026',"mRun(keptPutBack)",false,'kept '+shortTs(_keptMeta.t)+' \u00b7 from before '+keptWhere(_keptMeta)+' replaced it')
+    (_keptMeta? mi('\u21b6 Put back work kept aside\u2026',"mRun(keptPutBack)",false,'kept '+shortTs(_keptMeta.t)+' \u00b7 '
+        +(_keptMeta.why==='swap'? 'what was on screen when other work was put back' : 'from before '+keptWhere(_keptMeta)+' replaced it'))   // v2.00 (U19)
       +mi('⬇ Save work kept aside as a file…',"mRun(keptSaveFile)",false,'it stays kept aside')
       +mi('✕ Discard work kept aside…',"mRun(keptDiscard)",false,'cannot be undone') : '')+
     // in a PMO copy, the one way out is unfolded on top
```

### diffs/c1-mutate.diff

```diff
--- a/tools/export-audit/mutate.mjs
+++ b/tools/export-audit/mutate.mjs
@@ -4285,6 +4285,25 @@
   { id: "v200-u14-notice-plural-it", area: "flowHtml", what: "the panel's notice says \"keeps it\" however many saved years the board cannot answer for: FY24 and FY26 \"stay in the saved selection\", and switching a year \"keeps it\"",
     find: "switching a year on or off keeps '+(F.unavail.length===1?'it':'them')+'.</div>'",
     repl: "switching a year on or off keeps it.</div>'" },
+  // v2.00 (U19, Brad 12 Oct): ↶ Put back after a board-file save keeps what it replaces.
+  { id: "v200-u19-putback-keeps-nothing-saved", area: "keptPutBack", what: "↶ Put back keeps nothing in place of work on screen that is saved only in the board file, as before: the next 💾 Save, its HOLD ON answered OK, writes the work put back over that file, and the work that was on screen is in no copy this board can reach, after the Save and after a reopen",
+    find: "  const keepScreen=nowUnsaved || !driveStoreOn();",
+    repl: "  const keepScreen=nowUnsaved;" },
+  { id: "v200-u19-putback-promise-unkept", area: "keptPutBack", what: "↶ Put back's question says what is on screen, saved only in the board file, is also kept aside, but nothing is kept: the next 💾 Save, OK, leaves it in no copy this board can reach",
+    find: "  if(keepScreen){",
+    repl: "  if(nowUnsaved){" },
+  { id: "v200-u19-putback-question-unsaid", area: "keptPutBack", what: "↶ Put back's question, with what is on screen saved only in the board file, no longer says it is kept aside in its place, though it is",
+    find: "+(keepScreen? ' It is also kept aside in its place, so it is not lost if Save does.' : '')",
+    repl: "" },
+  { id: "v200-u19-swap-status-names-saver", area: "keptPutBack", what: "putting back what was on screen when other work was put back says “💾 Save will ask before it writes over the saved file, which Alice saved after it” when nobody has saved since, and Save asks nothing",
+    find: "+(k.meta.why==='swap'? '💾 Save will ask before it writes over a copy saved after the one this work came from.'",
+    repl: "+(false? ''" },
+  { id: "v200-u19-swap-title-unsaved", area: "saveStateShow", what: "the top bar's ↶ work kept aside calls a copy kept at a put-back “work this browser held that no saved copy had” when it is saved in the board file",
+    find: "+'title=\"'+(_keptMeta.why==='swap'? 'What was on screen when other work was put back'",
+    repl: "+'title=\"'+(false? 'What was on screen when other work was put back'" },
+  { id: "v200-u19-swap-menu-replaced", area: "syncBtns", what: "📁 File says a copy kept at a put-back is “from before the saved file replaced it”, though no saved copy replaced it",
+    find: "+(_keptMeta.why==='swap'? 'what was on screen when other work was put back'",
+    repl: "+(false? 'what was on screen when other work was put back'" },
   // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.
   { id: "v200-r3-landed-view-unsaid", area: "_driveStorePushRun", what: "a folder save that lands while a locked view is on screen says “🔒 Not kept — PB27 is a locked view. ✅ Saved …” again, naming no plan (or, quiet, leaves persist's refusal on screen)",
     find: "  if(CYCVIEW){ _cycRefusedAt=0; setStat('✅ <b>Saved the working plan</b> of '+esc(APPN_LBL[ap]||ap)+' FY'+(fy%100)+' to the shared folder — '\n    +Math.round(body.length/1024)+' KB, built before '+blLbl(CYCVIEW)+' was put on screen. '+blLbl(CYCVIEW)+' is a locked view: nothing in it '\n    +'is saved. Everyone sees the working plan on their next refresh.'+penNote+lateNote); render(); return true; }\n",
```

### diffs/c1-audit-import.diff

```diff
--- a/tools/export-audit/audit-import.mjs
+++ b/tools/export-audit/audit-import.mjs
@@ -3509,7 +3509,9 @@
     chk(name, at, 'the header says so for as long as it is kept', /work kept aside/.test(header(R.ev)), true);
     chk(name, at, 'and 📁 File offers to put it back', /Put back work kept aside/.test(R.ev(`document.getElementById('dd_share')? document.getElementById('dd_share').textContent : ''`)), true);
     R.ev(`globalThis.__yes=true; keptPutBack(); 'ok'`);
-    chk(name, at, 'one click puts it back', note(R.ev, 'A') + '|' + note(R.ev, 'B') + '|' + R.ev(`String(localStorage.getItem(_AP.key+'.kept')===null)`), 'BRAD NOTE||true');
+    // v2.00 (U19): what was on screen -- the colleague's save, in no copy this board can reach but the file -- is kept aside in its place
+    chk(name, at, 'one click puts it back, and what was on screen (the colleague’s copy, saved only in the file) is kept aside in its place',
+      note(R.ev, 'A') + '|' + note(R.ev, 'B') + '|' + R.ev(`(function(){ var s=localStorage.getItem(_AP.key+'.kept')||''; return String(/COLLEAGUE NOTE/.test(s) && !/BRAD NOTE/.test(s)); })()`), 'BRAD NOTE||true');
     const f = disk(R.w, F2);
     const q = await saveNow(R.ev, false);
     chk(name, at, 'and Save, put back, asks before writing over the colleague’s file', q.length === 1 && /HOLD ON/.test(q[0]) && f.writes === 0, true);
@@ -7323,7 +7325,7 @@
   const REFUSED = [true, true, true, true, 0, 'S1', true];
   const RQ = 'during the save: refused; what is on screen and the kept work are byte for byte as they were; nothing asked; the board says so';
   // ↶ Put back once the save has finished: one question, K on screen and unsaved, and what was on screen kept in its place if
-  // no saved copy has it (`was`: null when S1 is saved).
+  // no saved copy has it, or if it is saved only in a board file (v2.00, U19) (`was`: null when S1 is saved in the folder).
   const retry = A => { const q0 = qs(A.ev).length; A.ev('keptPutBack()'); return [qs(A.ev).length - q0, scr(A.ev), ...unsaved(A.ev), keptNote(A.ev)]; };
   const inFold = fold => n => [hist(fold).includes(n), fold.note(2027, 'A') === n];
   // THE FOLDER, after the retry: the refresh runs (live view on, as working out of the folder has it): K stays on screen and
@@ -7393,9 +7395,11 @@
     chk(name, sc, RQ, J(r.v), J(REFUSED));
     chk(name, sc, 'once it lands: S1 on screen and in the file, saved; the kept work byte for byte as it was',
       J([scr(A.ev), fileNote(f.content, 'A'), ...unsaved(A.ev), keptRaw(A.ev) === r.kr]), J(['S1', 'S1', false, false, false, true]));
-    chk(name, sc, 'put back again: one question; K on screen, unsaved; nothing kept in its place (S1 is saved)',
-      J(retry(A)), J([1, 'K', true, true, true, null]));
-    await afterFile(A, f, sc, ['S1', 'K']); }
+    // v2.00 (U19): a board file keeps no earlier copy, so S1 -- saved only in the file -- is kept aside in K's place as well.
+    // Reopened, the file (S1) is newer than the copy K came from, K is unsaved and S1 is kept: K stays on screen, S1 kept.
+    chk(name, sc, 'put back again: one question; K on screen, unsaved; S1 kept aside in its place (saved only in the board file: v2.00, U19)',
+      J(retry(A)), J([1, 'K', true, true, true, 'S1']));
+    await afterFile(A, f, sc, ['K', 'S1']); }
   // (e) THE BOARD FILE, THE SAVE FAILS: the write cannot be finished.
   { const sc = '(e) the board file: put back while S1’s save writes; the save fails';
     const { A, f } = await inFile();
@@ -7797,6 +7801,296 @@
   await settleBoards();
 })();
 // ==== end v2.00 (U13) ====
+// ==== v2.00 (U19): ↶ Put back after a board-file save keeps what it replaces ====
+// With S1 saved into the board file, ↶ Put back of the work kept aside (K) kept nothing in S1's place: S1 was "still in the
+// saved file". The next 💾 Save asked HOLD ON, and answered OK it wrote K over S1 -- and then S1 was in no copy this board
+// could reach: not on screen, not kept aside, not in browser storage, not in a byte of the file, after the Save and after a
+// reopen (only in Teams version history, outside the board). The shared folder keeps the copy a save replaces in its history;
+// a board file keeps none. Now, when Save writes to a board file, what is on screen is kept aside in the kept work's place
+// whether or not it is saved, as unsaved work always was, and the question and the board's words say so. Each route below is
+// driven through the page's own buttons and menus: the board file put back once S1's save has landed, put back while it
+// writes (refused, U2) and again once it has landed, through 📁 File and the note editor, with no file handle remembered
+// (the picker), and between two writers who each hold their own key (✍ Take the pen, both ways). Then: S1 put back again
+// before any Save, a reopen before any Save, no room to keep what is on screen, and the controls -- the HOLD ON answered
+// Cancel, S1 never saved, the shared folder, and ordinary editing -- as they were.
+await (async () => {   // a function, not a bare block: see settleBoards() in boot.mjs
+  const __bm = bootMark();
+  const name = 'v2.00 (U19) — put back after a board-file save keeps what it replaces';
+  try {
+  const { J, wire, KEY, status, qs, baseFile, disk, folder, connect, gate, until, flags, pause, lsOf, fileNote, fileWriter } = W1H;
+  const F1 = baseFile('Alice', KEY.alice);
+  // Requirement A's note says which copy is which: K, Alice's work kept aside by the opening; N, the newer copy that displaced
+  // it; S1, the work typed afterwards and saved into the file before K is put back.
+  const K = 'U19-K-KEPTWORK', N = 'U19-N-NEWER', S1 = 'U19-S1-SAVED';
+  const scr = ev => ev('String(S.notes.A)');
+  const keptRaw = ev => ev(`localStorage.getItem(_AP.key+'.kept')`);
+  // The work kept aside: [its note A, why it was kept], or null when nothing is kept.
+  const kept = ev => { const s = keptRaw(ev); if (s == null) return null;
+    try { const m = JSON.parse(s.slice(0, s.indexOf('\n'))), st = JSON.parse(s.slice(s.indexOf('\n') + 1));
+      return [String(((st.years || {})[st.cur] || { notes: {} }).notes.A || ''), m.why]; } catch (e) { return ['(unreadable)', null]; } };
+  const unsaved = ev => { const fl = flags(ev); return [fl.DIRTY, ev('_baseDirty'), !!fl.base.dirty]; };
+  // WHERE A COPY IS among the places this board offers it -- on screen, this browser's record of the board (its storage key),
+  // kept aside, the board file -- and, wider, whether its text is in any byte of browser storage or of the file.
+  const where = (ev, f, m) => { const ls = lsOf(ev); let main = '';
+    try { const o = JSON.parse(ls[ev('_AP.key')]); main = String(((o.years || {})[o.cur] || { notes: {} }).notes.A || ''); } catch (e) {}
+    const k = kept(ev);
+    return [scr(ev) === m && 'screen', main === m && 'storage', !!k && k[0] === m && 'kept', fileNote(f.content, 'A') === m && 'file'].filter(Boolean); };
+  const anywhere = (ev, f, m) => Object.values(lsOf(ev)).some(v => String(v).includes(m)) || f.content.includes(m);
+  // The page's own controls: 💾 Save in the toolbar (its promise is the save queue's), the top bar's "↶ work kept aside", and
+  // the 📁 File menu (mRun runs its item after a turn of the loop; then the save queue is waited for).
+  const clickSave = ev => ev(`(function(){ var b=document.getElementById('saveBtn'); if(!b) return null; b.click(); return _saveChain; })()`);
+  const clickPutBack = ev => ev(`(function(){ var b=document.querySelector('#saveState .keptbtn'); if(!b) return 'no button'; b.click(); return 'clicked'; })()`);
+  const fileMenu = async (ev, call) => { const r = ev(`(function(){ var b=document.getElementById('b_share'); if(!b) return 'no File button'; b.click();
+      var it=[].slice.call(document.querySelectorAll('#dd_share button')).filter(function(x){ return (x.getAttribute('onclick')||'')===${J(call)}; });
+      if(it.length!==1) return 'items: '+it.length; it[0].click(); return 'clicked'; })()`);
+    await pause(15); await ev('_saveChain'); await pause(20); return r; };
+  // The 📄 Description & note editor: open it for requirement A, type the note, press its ✔ Save.
+  const typeNote = (ev, text) => ev(`(function(){ toggleDesc('A'); var t=document.getElementById('fld-note'); if(!t) return 'no editor';
+    t.value=${J(text)}; var bs=[].slice.call(document.querySelectorAll('#fldBody button')).filter(function(b){ return (b.getAttribute('onclick')||'')==='fldSave()'; });
+    if(bs.length!==1) return 'save buttons: '+bs.length; bs[0].click(); return 'typed'; })()`);
+  // The status line's "✍ Take the pen…" -- the refusal's own button --, answered OK; then the save it makes is waited for.
+  const takePenBtn = async (ev, f) => { const w0 = f.writes;
+    const r = ev(`(function(){ var bs=[].slice.call(document.querySelectorAll('#shareStat button')).filter(function(b){ return (b.getAttribute('onclick')||'')==='takePen()'; });
+      if(bs.length!==1) return 'buttons: '+bs.length; bs[0].click(); return 'clicked'; })()`);
+    await until(() => f.writes > w0); await ev('_saveChain'); await pause(20); return r; };
+  const keptTitle = ev => ev(`(function(){ var b=document.querySelector('#saveState .keptbtn'); return b? b.title : null; })()`);
+  const menuText = ev => ev(`(document.getElementById('dd_share')||{}).textContent||''`);
+  // WORDS, as the board says them. The question when what is on screen is saved in the board file; the HOLD ON, unchanged;
+  // the top bar's and 📁 File's words for a copy kept at a put-back; the status after putting such a copy back.
+  const PUTQ = 'What is on screen now is still in the saved file it came from, and 💾 Save will ask before writing over that. It is also kept aside in its place, so it is not lost if Save does.';
+  const holdOn = q => /^⚠ HOLD ON — Alice saved this file at .+\. That is not the save the copy you are working from came from, so their changes are not on your screen\.\n\nSaving now will OVERWRITE their changes with yours\.\n\nOK — overwrite anyway \(their version stays in Teams version history\)\./.test(q);
+  const SWAPTITLE = /^What was on screen when other work was put back, kept aside .+\. Put it back\.$/;
+  const SWAPMENU = 'what was on screen when other work was put back';
+  const SWAPSAID = '💾 Save will ask before it writes over a copy saved after the one this work came from.';
+  // THE BOARD FILE. Alice types K, unsaved. Her other browser saves N into the file. She reopens the file: the opening keeps K
+  // aside and opens N. `picker`: no file handle is remembered, so the first Save opens the picker (it hands back the same file).
+  const inFile = async picker => {
+    const A0 = boot({ html: F1 }); await pause(80); wire(A0.ev, 'Alice', KEY.alice);
+    A0.ev(`setNote('A',${J(K)}); 'ok'`); await pause(5);
+    const A2 = boot({ html: F1 }); await pause(80); wire(A2.ev, 'Alice', KEY.alice); const f2 = disk(A2.w, F1);
+    A2.ev(`setNote('A',${J(N)}); 'ok'`); await pause(5); await A2.ev('saveInPlaceFile()'); await pause(5);
+    const A = boot({ html: f2.content, ls: lsOf(A0.ev) }); await pause(80); wire(A.ev, 'Alice', KEY.alice); const f = disk(A.w, f2.content);
+    if (picker) A.ev(`FH=null; globalThis.__picks=0; window.showSaveFilePicker=async function(){ globalThis.__picks++; return globalThis.__disk; }; 'ok'`);
+    return { A, f };
+  };
+  const reopen = async (A, f) => { const B = boot({ html: f.content, ls: lsOf(A.ev) }); await pause(80); wire(B.ev, 'Alice', KEY.alice);
+    return { B, fB: disk(B.w, f.content) }; };
+  // S1 typed and saved into the file through 💾 Save: nothing asked; S1 in the file, saved; K still kept aside.
+  const savedS1 = async (A, f, sc) => {
+    A.ev(`setNote('A',${J(S1)}); 'ok'`); await pause(5);
+    chk(name, sc, 'S1 on screen, unsaved; K kept aside by the opening; N in the file (a CONTROL)',
+      J([scr(A.ev), ...unsaved(A.ev), kept(A.ev), fileNote(f.content, 'A')]), J([S1, true, true, true, [K, 'file'], N]));
+    const q0 = qs(A.ev).length; await clickSave(A.ev); await pause(20);
+    chk(name, sc, 'S1’s save lands: nothing asked; S1 in the file, saved; K still kept aside (a CONTROL)',
+      J([qs(A.ev).length - q0, fileNote(f.content, 'A'), ...unsaved(A.ev), kept(A.ev)]), J([0, S1, false, false, false, [K, 'file']]));
+  };
+  // ↶ Put back of K with S1 saved -- the top bar's button, or `via` -- : one question, saying S1 is kept aside too; K on screen,
+  // unsaved; S1 kept in its place.
+  const putBackK = async (A, sc, via) => {
+    const q0 = qs(A.ev).length; const r = via ? await via() : clickPutBack(A.ev); const q = qs(A.ev).slice(q0);
+    chk(name, sc, '↶ Put back: one question, saying S1 is still in the saved file, Save will ask, and S1 is also kept aside in its place',
+      J([q.length, q.length === 1 && q[0].endsWith(PUTQ)]), J([1, true]));
+    chk(name, sc, '↶ Put back: K on screen, unsaved; S1 kept aside in its place; the board says so',
+      J([scr(A.ev), ...unsaved(A.ev), kept(A.ev), / What was on screen is kept aside in its place: put that back\.$/.test(status(A.ev))]),
+      J([K, true, true, true, [S1, 'swap'], true]));
+    return r;
+  };
+  // 💾 Save after the put-back, HOLD ON answered OK: one HOLD ON, in its own words; K written into the file, saved.
+  const saveK = (A, f, sc, q) => chk(name, sc, '💾 Save: one HOLD ON, its words unchanged; OK writes K into the file, saved (a CONTROL)',
+    J([q.length, q.length === 1 && holdOn(q[0]), fileNote(f.content, 'A'), scr(A.ev), ...unsaved(A.ev)]), J([1, true, K, K, false, false, false]));
+  // (a) THE BOARD FILE, PUT BACK ONCE S1's SAVE HAS LANDED; then 💾 Save, OK. Reopened, S1 is put back and saved in its turn.
+  { const sc = '(a) the board file: ↶ Put back once S1’s save has landed; 💾 Save, HOLD ON answered OK; reopened';
+    const { A, f } = await inFile();
+    await savedS1(A, f, sc);
+    chk(name, sc, 'the top bar offers K, as work no saved copy had (a CONTROL)', /^Work this browser held that no saved copy had, kept aside .+\. Put it back\.$/.test(keptTitle(A.ev) || ''), true);
+    await putBackK(A, sc);
+    chk(name, sc, '↶ Put back: the top bar offers S1, as what was on screen when other work was put back; 📁 File says the same',
+      J([SWAPTITLE.test(keptTitle(A.ev) || ''), menuText(A.ev).includes(SWAPMENU), menuText(A.ev).includes('from before the saved file replaced it')]), J([true, true, false]));
+    let q0 = qs(A.ev).length; await clickSave(A.ev); await pause(20); saveK(A, f, sc, qs(A.ev).slice(q0));
+    chk(name, sc, 'after 💾 Save: S1 is kept aside, offered in the top bar, and its text is in this browser’s storage',
+      J([where(A.ev, f, S1), anywhere(A.ev, f, S1), kept(A.ev), SWAPTITLE.test(keptTitle(A.ev) || '')]), J([['kept'], true, [S1, 'swap'], true]));
+    const { B, fB } = await reopen(A, f);
+    chk(name, sc, 'reopened: K on screen and in the file, saved; S1 kept aside, offered in the top bar',
+      J([scr(B.ev), fileNote(fB.content, 'A'), ...unsaved(B.ev), kept(B.ev), where(B.ev, fB, S1), SWAPTITLE.test(keptTitle(B.ev) || '')]),
+      J([K, K, false, false, false, [S1, 'swap'], ['kept'], true]));
+    q0 = qs(B.ev).length; clickPutBack(B.ev); const q = qs(B.ev).slice(q0);
+    chk(name, sc, 'reopened, S1 put back: one question (K is in the saved file, and is kept aside too); S1 on screen, unsaved; K kept in its place',
+      J([q.length, q.length === 1 && q[0].endsWith(PUTQ), scr(B.ev), ...unsaved(B.ev), kept(B.ev)]), J([1, true, S1, true, true, true, [K, 'swap']]));
+    chk(name, sc, 'and the board says Save asks before writing over a copy saved after S1’s -- not who saved the file after it',
+      J([status(B.ev).includes(SWAPSAID), / saved after it\./.test(status(B.ev))]), J([true, false]));
+    q0 = qs(B.ev).length; await clickSave(B.ev); await pause(20); const q2 = qs(B.ev).slice(q0);
+    chk(name, sc, 'then 💾 Save: one HOLD ON (the file holds K, saved after S1’s copy); OK writes S1, saved; K still kept aside',
+      J([q2.length, q2.length === 1 && holdOn(q2[0]), fileNote(fB.content, 'A'), ...unsaved(B.ev), kept(B.ev)]), J([1, true, S1, false, false, false, [K, 'swap']])); }
+  // (b) THE BOARD FILE, PUT BACK WHILE S1's SAVE WRITES: refused (v2.00, U2); once the save has landed, put back; 💾 Save, OK.
+  { const sc = '(b) the board file: ↶ Put back pressed while S1’s save writes, and again once it has landed; 💾 Save, OK; reopened';
+    const { A, f } = await inFile();
+    A.ev(`setNote('A',${J(S1)}); 'ok'`); await pause(5);
+    const n0 = f.hits.write || 0; f.hold.write = gate(); const g = f.hold.write;
+    const p = clickSave(A.ev); const reached = await until(() => (f.hits.write || 0) > n0);
+    const k0 = keptRaw(A.ev), q0 = qs(A.ev).length; const r = clickPutBack(A.ev);
+    chk(name, sc, 'during the save: ↶ Put back refused, nothing asked, K kept byte for byte, S1 on screen, and said (a CONTROL)',
+      J([reached, r, qs(A.ev).length - q0, keptRaw(A.ev) === k0, scr(A.ev), /Not put back/.test(status(A.ev))]), J([true, 'clicked', 0, true, S1, true]));
+    g.open(); await p; await pause(20);
+    chk(name, sc, 'the save lands: S1 in the file, saved; K still kept aside (a CONTROL)',
+      J([fileNote(f.content, 'A'), ...unsaved(A.ev), kept(A.ev)]), J([S1, false, false, false, [K, 'file']]));
+    await putBackK(A, sc);
+    let q1 = qs(A.ev).length; await clickSave(A.ev); await pause(20); saveK(A, f, sc, qs(A.ev).slice(q1));
+    chk(name, sc, 'after 💾 Save: S1 is kept aside, and its text is in this browser’s storage', J([where(A.ev, f, S1), anywhere(A.ev, f, S1)]), J([['kept'], true]));
+    const { B, fB } = await reopen(A, f);
+    chk(name, sc, 'reopened: K on screen and in the file, saved; S1 kept aside', J([scr(B.ev), fileNote(fB.content, 'A'), ...unsaved(B.ev), where(B.ev, fB, S1)]),
+      J([K, K, false, false, false, ['kept']])); }
+  // (c) THROUGH 📁 FILE AND THE NOTE EDITOR: S1 typed in 📄 Description & note, 📁 File → 💾 Save, → ↶ Put back, → 💾 Save.
+  { const sc = '(c) the board file through 📁 File and the note editor; HOLD ON answered OK; reopened';
+    const { A, f } = await inFile();
+    const typed = typeNote(A.ev, S1); await pause(5);
+    const s1 = await fileMenu(A.ev, 'mRun(saveInPlace)');
+    chk(name, sc, 'S1 typed in the editor and saved through 📁 File: nothing asked; S1 in the file, saved; K still kept aside (a CONTROL)',
+      J([typed, s1, qs(A.ev).length, fileNote(f.content, 'A'), ...unsaved(A.ev), kept(A.ev)]), J(['typed', 'clicked', 0, S1, false, false, false, [K, 'file']]));
+    const pb = await putBackK(A, sc, () => fileMenu(A.ev, 'mRun(keptPutBack)'));
+    chk(name, sc, '📁 File → ↶ Put back: 📁 File then says what the work kept aside is', J([pb, menuText(A.ev).includes(SWAPMENU)]), J(['clicked', true]));
+    const q0 = qs(A.ev).length; const s2 = await fileMenu(A.ev, 'mRun(saveInPlace)'); saveK(A, f, sc, qs(A.ev).slice(q0));
+    chk(name, sc, 'after 📁 File → 💾 Save: S1 is kept aside', J([s2, where(A.ev, f, S1), anywhere(A.ev, f, S1)]), J(['clicked', ['kept'], true]));
+    const { B, fB } = await reopen(A, f);
+    chk(name, sc, 'reopened: K on screen, saved; S1 kept aside', J([scr(B.ev), ...unsaved(B.ev), where(B.ev, fB, S1)]), J([K, false, false, false, ['kept']])); }
+  // (d) NO FILE HANDLE REMEMBERED: the first 💾 Save opens the picker (which hands back the same file); the second reuses it.
+  { const sc = '(d) the board file with no file handle remembered: the first 💾 Save opens the picker; HOLD ON answered OK; reopened';
+    const { A, f } = await inFile(true);
+    await savedS1(A, f, sc);
+    chk(name, sc, 'S1’s save opened the picker once (a CONTROL)', A.ev('globalThis.__picks'), 1);
+    await putBackK(A, sc);
+    const q0 = qs(A.ev).length; await clickSave(A.ev); await pause(20); saveK(A, f, sc, qs(A.ev).slice(q0));
+    chk(name, sc, 'after 💾 Save (the picker not opened again): S1 is kept aside', J([A.ev('globalThis.__picks'), where(A.ev, f, S1), anywhere(A.ev, f, S1)]), J([1, ['kept'], true]));
+    const { B, fB } = await reopen(A, f);
+    chk(name, sc, 'reopened: K on screen, saved; S1 kept aside', J([scr(B.ev), ...unsaved(B.ev), where(B.ev, fB, S1)]), J([K, false, false, false, ['kept']])); }
+  // (e) TWO WRITERS, EACH WITH HIS OWN KEY: the board file has one writer, so the newer copy N reaches the file only when Bob
+  // takes the pen, and S1 only when Alice takes it back -- each through the refusal's own "✍ Take the pen…". Then ↶ Put
+  // back, 💾 Save with its HOLD ON answered OK, and a reopen, as in (a).
+  { const sc = '(e) the board file between two writers: N and S1 each written through ✍ Take the pen; ↶ Put back; 💾 Save, HOLD ON answered OK; reopened';
+    const A0 = boot({ html: F1 }); await pause(80); wire(A0.ev, 'Alice', KEY.alice);
+    A0.ev(`setNote('A',${J(K)}); 'ok'`); await pause(5);
+    const Bb = boot({ html: F1 }); await pause(80); wire(Bb.ev, 'Bob', KEY.bob); const fb = disk(Bb.w, F1);
+    Bb.ev(`setNote('A',${J(N)}); 'ok'`); await pause(5);
+    await clickSave(Bb.ev); await pause(20); const bobRefused = [fb.writes, /Not saved\. Alice holds the pen/.test(status(Bb.ev))];
+    const bt = await takePenBtn(Bb.ev, fb);
+    chk(name, sc, 'Bob: 💾 Save refused (Alice holds the pen); ✍ Take the pen… writes N, writer Bob (a CONTROL)',
+      J([...bobRefused, bt, fileNote(fb.content, 'A'), fileWriter(fb.content)]), J([0, true, 'clicked', N, 'Bob']));
+    const A = boot({ html: fb.content, ls: lsOf(A0.ev) }); await pause(80); wire(A.ev, 'Alice', KEY.alice); const f = disk(A.w, fb.content);
+    A.ev(`setNote('A',${J(S1)}); 'ok'`); await pause(5);
+    await clickSave(A.ev); await pause(20); const aliceRefused = [f.writes, /Not saved\. Bob holds the pen/.test(status(A.ev)), kept(A.ev)];
+    const at = await takePenBtn(A.ev, f);
+    chk(name, sc, 'Alice reopens (K kept aside, N opened) and types S1: 💾 Save refused (Bob holds the pen); ✍ Take the pen… writes S1, saved, writer Alice; K still kept aside (a CONTROL)',
+      J([...aliceRefused, at, fileNote(f.content, 'A'), fileWriter(f.content), ...unsaved(A.ev), kept(A.ev)]),
+      J([0, true, [K, 'file'], 'clicked', S1, 'Alice', false, false, false, [K, 'file']]));
+    await putBackK(A, sc);
+    const q0 = qs(A.ev).length; await clickSave(A.ev); await pause(20); saveK(A, f, sc, qs(A.ev).slice(q0));
+    chk(name, sc, 'after 💾 Save: S1 is kept aside, and its text is in this browser’s storage', J([where(A.ev, f, S1), anywhere(A.ev, f, S1)]), J([['kept'], true]));
+    const { B, fB } = await reopen(A, f);
+    chk(name, sc, 'reopened: K on screen and in the file, saved, writer Alice; S1 kept aside',
+      J([scr(B.ev), fileNote(fB.content, 'A'), fileWriter(fB.content), ...unsaved(B.ev), where(B.ev, fB, S1)]), J([K, K, 'Alice', false, false, false, ['kept']])); }
+  // (f) S1 PUT BACK AGAIN BEFORE ANY SAVE: the file still holds S1's own save, so Save asks nothing -- and the board does not
+  // say it will. K, unsaved, is kept in S1's place.
+  { const sc = '(f) the board file: K put back, then S1 put back again before any Save; then 💾 Save';
+    const { A, f } = await inFile();
+    await savedS1(A, f, sc);
+    await putBackK(A, sc);
+    const q0 = qs(A.ev).length; const r = clickPutBack(A.ev); const q = qs(A.ev).slice(q0);
+    chk(name, sc, 'S1 put back: one question (K has changes no saved copy has, so it is kept aside); S1 on screen, unsaved; K kept in its place',
+      J([r, q.length, q.length === 1 && q[0].endsWith('What is on screen now has changes no saved copy has, so it is kept aside in its place — nothing is lost.'), scr(A.ev), ...unsaved(A.ev), kept(A.ev)]),
+      J(['clicked', 1, true, S1, true, true, true, [K, 'swap']]));
+    chk(name, sc, 'the board says Save asks before writing over a copy saved after S1’s -- not that somebody saved the file after it',
+      J([status(A.ev).includes(SWAPSAID), / saved after it\./.test(status(A.ev))]), J([true, false]));
+    const q1 = qs(A.ev).length; await clickSave(A.ev); await pause(20);
+    chk(name, sc, 'then 💾 Save asks nothing (nobody saved after S1’s copy) and writes S1, saved; K still kept aside',
+      J([qs(A.ev).length - q1, fileNote(f.content, 'A'), ...unsaved(A.ev), kept(A.ev)]), J([0, S1, false, false, false, [K, 'swap']])); }
+  // (g) REOPENED BEFORE ANY SAVE, after K was put back: the file is newer than the copy K came from and this browser holds K
+  // unsaved, with S1 already kept aside -- kept work is never replaced, so the file's copy (S1) is not loaded over K.
+  { const sc = '(g) the board file: K put back, then the board reopened before any Save';
+    const { A, f } = await inFile();
+    await savedS1(A, f, sc);
+    await putBackK(A, sc);
+    const { B, fB } = await reopen(A, f);
+    chk(name, sc, 'reopened: K stays on screen, unsaved by the record; S1 kept aside and in the file; the board says the file’s copy was not loaded and nothing was lost',
+      J([scr(B.ev), !!flags(B.ev).base.dirty, kept(B.ev), fileNote(fB.content, 'A'), /the newer copy was not loaded and nothing was lost/.test(status(B.ev))]),
+      J([K, true, [S1, 'swap'], S1, true]));
+    chk(name, sc, 'K and S1 are each still in a copy here or in the file (a CONTROL)', J([K, S1].map(m => where(B.ev, fB, m).length > 0)), J([true, true])); }
+  // (h) NO ROOM TO KEEP WHAT IS ON SCREEN: browser storage refuses the kept copy, so nothing is put back and nothing changes.
+  { const sc = '(h) the board file: no room in browser storage to keep S1 aside';
+    const { A, f } = await inFile();
+    await savedS1(A, f, sc);
+    const k0 = keptRaw(A.ev), m0 = A.ev('JSON.stringify(MS)');
+    A.ev(`(function(){ var o=Storage.prototype.setItem; globalThis.__setItem=o; Storage.prototype.setItem=function(k,v){ if(/\\.kept$/.test(String(k))) throw new DOMException('full', 'QuotaExceededError'); return o.apply(this, arguments); }; return 'ok'; })()`);
+    const q0 = qs(A.ev).length; clickPutBack(A.ev);
+    A.ev(`Storage.prototype.setItem=globalThis.__setItem; 'ok'`);
+    chk(name, sc, '↶ Put back: asked once, then refused -- nothing changed: S1 on screen and in the file, saved; K kept byte for byte; said',
+      J([qs(A.ev).length - q0, scr(A.ev), A.ev('JSON.stringify(MS)') === m0, fileNote(f.content, 'A'), ...unsaved(A.ev), keptRaw(A.ev) === k0,
+        /There is no room to keep what is on screen while the kept work is put back, so nothing was changed/.test(status(A.ev))]),
+      J([1, S1, true, S1, false, false, false, true, true])); }
+  // (i) CONTROL: THE HOLD ON ANSWERED CANCEL. Nothing is written; S1 stays in the file.
+  { const sc = '(i) CONTROL: the board file, the HOLD ON answered Cancel';
+    const { A, f } = await inFile();
+    await savedS1(A, f, sc);
+    clickPutBack(A.ev);
+    const w0 = f.writes, q0 = qs(A.ev).length; A.ev('globalThis.__yes=false; 0'); await clickSave(A.ev); await pause(20); A.ev('globalThis.__yes=true; 0');
+    const q = qs(A.ev).slice(q0);
+    chk(name, sc, '💾 Save: one HOLD ON; Cancel writes nothing: S1 in the file, K on screen, unsaved; said',
+      J([q.length, q.length === 1 && holdOn(q[0]), f.writes - w0, fileNote(f.content, 'A'), scr(A.ev), ...unsaved(A.ev), /^Save canceled/.test(status(A.ev))]),
+      J([1, true, 0, S1, K, true, true, true, true]));
+    chk(name, sc, 'S1 is in the file; K and S1 are each still in a copy here or in the file', J([where(A.ev, f, S1).includes('file'), [K, S1].map(m => where(A.ev, f, m).length > 0)]), J([true, [true, true]])); }
+  // (j) CONTROL: S1 NEVER SAVED. What is on screen has changes no saved copy has, and is kept aside in its place, as always.
+  { const sc = '(j) CONTROL: the board file, S1 never saved; ↶ Put back; 💾 Save, OK; reopened';
+    const { A, f } = await inFile();
+    A.ev(`setNote('A',${J(S1)}); 'ok'`); await pause(5);
+    const q0 = qs(A.ev).length; clickPutBack(A.ev); const q = qs(A.ev).slice(q0);
+    chk(name, sc, '↶ Put back: one question (changes no saved copy has, kept aside in its place); K on screen, unsaved; S1 kept',
+      J([q.length, q.length === 1 && q[0].endsWith('What is on screen now has changes no saved copy has, so it is kept aside in its place — nothing is lost.'), scr(A.ev), ...unsaved(A.ev), kept(A.ev)]),
+      J([1, true, K, true, true, true, [S1, 'swap']]));
+    const q1 = qs(A.ev).length; await clickSave(A.ev); await pause(20); const q2 = qs(A.ev).slice(q1);
+    chk(name, sc, '💾 Save: one HOLD ON (N’s save); OK writes K, saved; S1 still kept aside',
+      J([q2.length, q2.length === 1 && holdOn(q2[0]), fileNote(f.content, 'A'), ...unsaved(A.ev), where(A.ev, f, S1)]), J([1, true, K, false, false, false, ['kept']]));
+    const { B, fB } = await reopen(A, f);
+    chk(name, sc, 'reopened: K on screen, saved; S1 kept aside', J([scr(B.ev), ...unsaved(B.ev), where(B.ev, fB, S1)]), J([K, false, false, false, ['kept']])); }
+  // (k) CONTROL: THE SHARED FOLDER, which keeps the copy a save replaces in its history. Alice saves F0 and types K; her other
+  // browser saves N; her Save is refused and she loads theirs (K kept aside); she types S1 and saves it. ↶ Put back keeps
+  // nothing in S1's place, as before; 💾 Save is refused with the choice; "Save yours over theirs" keeps S1 in the history.
+  { const sc = '(k) CONTROL: the shared folder: ↶ Put back once S1’s save has landed; 💾 Save; Save yours over theirs';
+    const fold = folder(); const A = boot({ html: F1 }); await pause(80); wire(A.ev, 'Alice', KEY.alice); connect(A.ev, A.w, fold);
+    A.ev(`setNote('A','U19-F0'); 'ok'`); await pause(5); await A.ev('driveStorePush(false)'); await pause(5);
+    A.ev(`setNote('A',${J(K)}); 'ok'`); await pause(5);
+    const A2 = boot({ html: F1 }); await pause(80); wire(A2.ev, 'Alice', KEY.alice); connect(A2.ev, A2.w, fold);
+    await A2.ev('driveStorePull(false)'); await pause(5);
+    A2.ev(`setNote('A',${J(N)}); 'ok'`); await pause(5); await A2.ev('driveStorePush(false)'); await pause(5);
+    await A.ev('saveInPlace()'); await A.ev(`driveResolve('theirs')`); await pause(5);
+    A.ev(`setNote('A',${J(S1)}); 'ok'`); await pause(5); await clickSave(A.ev); await pause(20);
+    const hist = () => Object.values((fold.root.dirs.history || { files: {} }).files).map(t => { try { return JSON.parse(t).store.years['2027'].notes.A; } catch (e) { return '?'; } });
+    chk(name, sc, 'S1 saved to the folder, saved; K kept aside (why folder) (a CONTROL)', J([fold.note(2027, 'A'), ...unsaved(A.ev), kept(A.ev)]), J([S1, false, false, false, [K, 'folder']]));
+    const q0 = qs(A.ev).length; clickPutBack(A.ev); const q = qs(A.ev).slice(q0);
+    chk(name, sc, '↶ Put back: one question (S1 is still in the shared folder, Save will ask) and no more; K on screen, unsaved; nothing kept in its place',
+      J([q.length, q.length === 1 && q[0].endsWith('What is on screen now is still in the shared folder it came from, and 💾 Save will ask before writing over that.'), scr(A.ev), ...unsaved(A.ev), kept(A.ev)]),
+      J([1, true, K, true, true, true, null]));
+    const q1 = qs(A.ev).length; await clickSave(A.ev); await pause(20);
+    chk(name, sc, '💾 Save: refused with the choice, nothing asked, S1 still the folder’s copy', J([/Nothing was written/.test(status(A.ev)) && /Save yours over theirs/.test(status(A.ev)), qs(A.ev).length - q1, fold.note(2027, 'A')]), J([true, 0, S1]));
+    const q2 = qs(A.ev).length; await A.ev(`driveResolve('mine')`); await pause(20);
+    chk(name, sc, '"Save yours over theirs": one question; K written, saved; S1 kept in the folder’s history',
+      J([qs(A.ev).length - q2, fold.note(2027, 'A'), ...unsaved(A.ev), hist().includes(S1)]), J([1, K, false, false, false, true])); }
+  // (l) CONTROL: ORDINARY EDITING. S1 saved; more than a minute later (this window's clock moved on 61 s: the journal joins one
+  // person's edits to one field inside a minute) Alice types over it herself and saves: nothing is asked, and the Change journal
+  // the file carries keeps what the note was.
+  { const sc = '(l) CONTROL: the board file, S1 saved, then retyped a minute later and saved (no put-back)';
+    const { A, f } = await inFile();
+    await savedS1(A, f, sc);
+    A.ev(`(function(){ var real=Date.now; Date.now=function(){ return real.call(Date)+61000; }; return 'ok'; })()`);
+    A.ev(`setNote('A',${J(K + ' RETYPED')}); 'ok'`); await pause(5);
+    const q0 = qs(A.ev).length; await clickSave(A.ev); await pause(20);
+    chk(name, sc, '💾 Save asks nothing; the retyped note in the file, saved; the journal holds S1 → the retyped note; K still kept aside',
+      J([qs(A.ev).length - q0, fileNote(f.content, 'A'), ...unsaved(A.ev), A.ev(`(MS.jrnl||[]).some(function(e){ return e.a===${J(S1)} && e.b===${J(K + ' RETYPED')}; })`), kept(A.ev)]),
+      J([0, K + ' RETYPED', false, false, false, true, [K, 'file']])); }
+  } catch (e) {
+    failures.push({ scenario: name, where: 'harness', what: 'the block threw: ' + String((e && e.stack) || e).slice(0, 300), got: 'threw', want: 'ran' });
+  }
+  bootRelease(__bm, keepBoards());
+  await settleBoards();
+})();
+// ==== end v2.00 (U19) ====
 
 await (async () => {   // a function, not a bare block: see settleBoards() in boot.mjs
   const __bm = bootMark();
```
