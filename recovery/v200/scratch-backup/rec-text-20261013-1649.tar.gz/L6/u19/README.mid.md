## 6. The tests: focused harnesses, base against c1

**How the harnesses are built.** `mk-harness.sh` runs `bin/mkfocused-u2.py`, unchanged from `rec/L2/u2impl`. It copies each
harness VERBATIM from the given suite file:
- its imports, failure list, keepBoards, SEEN/chk, the named block, the scenario-ran guard;
- every top-level helper the block references (here MINE, W1H, base, d, it).

**How they are run.** `bin/runner.mjs` (= `rec/L2/u2impl/runner.mjs`) imports the copy's shim, then the copy's own
`boot.mjs`. BOARD is unset (asserted to be that copy's board), or set to a mutant. Every check is recorded with
SUITE_CHECKS in `out/<label>.checks.jsonl`. The run tag is r2, against the current blobs.

| harness (from) | on base `fce8a391` | on c1 `8cf14d7e` |
|---|---|---|
| U19 (c1's block, 71 checks) | **34 fail**, 37 pass; 0 CONTROL rows fail. Fails by scenario: (a) 8, (b) 4, (c) 5, (d) 4, (e) 4, (f) 5, (g) 3, (h) 1. The controls (i)–(l) all pass. | **71/71 pass** |
| U2, both blocks (c1's expectations, 57) | 2 fail: (d) rows 3a, 3b | 57/57 |
| U2, both blocks (the base's, 57) | 57/57 | 2 fail: (d) rows 3a, 3b |
| v1.89 (c1's, 40) | 1 fail: row 1 | 40/40 |
| v1.89 (the base's, 40) | 40/40 (earlier run r1) | 1 fail: row 1 |
| v1.95 "work kept aside is never replaced" (10; identical in both suites) | 10/10 | 10/10 |

**The U19 block's scenarios** (`v2/block-u19.v2.mjs.txt`, in c1 at L7804–8093):

| case | what it drives |
|---|---|
| (a) | The board file. S1 typed and saved through 💾 Save, then ↶ Put back from the top bar, then 💾 Save with the HOLD ON answered OK, then a reopen. S1 is then put back from the reopened board, which keeps K in its place, and Save asks before writing S1. |
| (b) | ↶ Put back pressed while S1's save writes (refused, U2), and again once it has landed; then Save with OK, then a reopen. |
| (c) | S1 typed in the 📄 Description & note editor; 📁 File → 💾 Save, → ↶ Put back, → 💾 Save; then a reopen. |
| (d) | No file handle remembered: the first Save opens the picker once, and the second reuses it. |
| (e) | Two writers with their own keys. Bob's Save is refused, and his ✍ Take the pen… writes N. Alice reopens (K kept, N opened); her Save is refused, and her Take the pen writes S1. Then put back, Save with OK, and a reopen. |
| (f) | K put back, then S1 put back again before any Save. Save asks nothing and writes S1, and the words do not claim someone saved since. |
| (g) | K put back, then a reopen before any Save. K stays on screen, unsaved; S1 is kept and in the file; "… not loaded and nothing was lost". |
| (h) | No room in browser storage to keep S1. The put-back is asked, then refused; nothing changed, and that is said. |
| (i) | CONTROL: the HOLD ON answered Cancel. |
| (j) | CONTROL: S1 never saved (kept as before). |
| (k) | CONTROL: the shared folder. Nothing is kept in place, and "Save yours over theirs" keeps S1 in the folder history. |
| (l) | CONTROL: ordinary editing. The Change journal keeps S1 → the retyped note. |

**Expected values.** Every expected value is a hand-written literal: note texts, booleans, counts, kept-slot pairs, and
regexes on the product's own words. Board helpers are used only for OBSERVED values.

## 7. Mutations

**Where the six new entries go.** They are inserted as text before "  // v2.00 (R3, Brad 11 Oct): a save that lands under a
locked view says it saved the working plan." (`bin/edit-mutate.py`). Each find matches c1's board exactly once
(`mut/c1/*.mkmut.json`, and mcount).

**How each was run.** Each mutant was made by `rec/bin/mkmut.py` (text only) and run through the focused harnesses on
c1, with BOARD set to the mutant. `mutate.mjs` was never imported or run.

| id | what it breaks | caught (failing checks) |
|---|---|---|
| `v200-u19-putback-keeps-nothing-saved` (`keepScreen=nowUnsaved`; mutant `cbd88dc6`) | The keep-aside is dropped: the pre-fix behaviour. | U19: 34 of 71, the base's exact 34. U2: 2 (rows 3a, 3b). v1.89: 1 (row 1). |
| `v200-u19-putback-promise-unkept` (`if(nowUnsaved){` at the keep; `acb9d348`) | The question says S1 is kept aside, but nothing is kept. | U19: 27 of 71, in every changed scenario (a)–(h). U2: 2. v1.89: 1. |
| `v200-u19-putback-question-unsaid` (`d4a756aa`) | The question no longer says it is kept aside. | U19: 8, the question check in (a)–(g), plus (a)'s reopened put-back. |
| `v200-u19-swap-status-names-saver` (`1107a7a0`) | The status after putting a swap copy back says "…, which Alice saved after it". | U19: 2, the status checks in (a) and (f). |
| `v200-u19-swap-title-unsaved` (`9fefcad9`) | The top bar calls a swap copy "work … that no saved copy had". | U19: 3, the title checks in (a). |
| `v200-u19-swap-menu-replaced` (`8b195f25`) | 📁 File says "from before the saved file replaced it". | U19: 2, the 📁 File checks in (a) and (c). |

**Existing mutations near the change, re-run on c1** (each find still matches exactly once; every one is still caught):

| id | on the base (base harnesses) | on c1 (c1 harnesses) |
|---|---|---|
| `putback-drops-screen` (`nowUnsaved=false`) | U2 11 fail; v1.95 kept 1 fail; v1.89 0 | U19 2 fail ((f) and the (j) CONTROL); U2 7 fail; v1.95 kept 0; v1.89 0 |
| `v200-u2-putback-gen` | (not re-run on the base) | U2 1 fail ((d) count); U19 0 |
| `v200-u2-putback-while-saving` | (not re-run on the base) | U2 35 fail; U19 7 fail ((b)) |

**Sensitivity note for the lead.** On c1, the v1.95 "work kept aside" block no longer catches `putback-drops-screen`.
That mutant zeroes `nowUnsaved`, but a board file now keeps what is on screen anyway, so that block's file-mode put-back
still keeps BRAD TWO. The mutant is still caught inside audit-import, by the U2 blocks' folder cases and by U19 (f)/(j). The
mutate sweep's import suite therefore still catches it. Its full-suite run is the lead's.

## 8. Probes (reproduction on the base; the same probes on c1)

**On the base** (the earlier builder's runs, all with exit records, plus my pen runs):
- **The builder's L4 probe** (`u19probe.mjs` + `check.mjs`): 77 pass, 4 fail. The 4 are the PROPERTY rows "S1 is still in a
  copy this board can reach" after 💾 Save and after reopening, in file-after and file-retry. The controls file-cancel,
  file-unsaved, folder-after and folder-retry all pass.
- **The checker's variants** (`x19.mjs` + `xcheck.mjs`): 66 pass, 18 fail. That is 16 U19 rows (ui-after, picker-after,
  multi-after) plus the two calib-H0 rows the checker kept as refuted. The controls multi-cancel, multi-unsaved and
  multi-ordinary pass.
- **The checker's pen route** (`x19pen.mjs` + `xcheck-pen.mjs`, new here, runs `x-base-pen-*`, `xpchk-base`): 73 pass,
  4 fail. The 4 are the pen-after PROPERTY rows. S1 is in no place, no storage key and no file byte after the Save and
  after the reopen, and only in the stand-in version history. pen-cancel passes. **So U19 reproduces on the L6 base on all
  five routes.**

**On c1** (`p-c1-*`, `x-c1-*`, `chk-c1`, `xchk-c1`, `xpchk-c1`). These probes' literals describe the base board, so some
rows fail on c1 by design.
- **Every "S1 is still in a copy this board can reach" PROPERTY row passes** on all five routes, after the Save and after
  the reopen. S1 is in `prio27om.kept` (`[["kept"],["prio27om.kept"],0,1]` on pen-after).
- **Rows that fail on c1, and why:**
  - the board-blob literal, `fce8a391`, in each scenario;
  - "NOTHING kept in its place", and the "U19 shape" rows: both encode the defect;
  - the v2 rows "S1's text is findable in the Change journal panel": not covered, because S1's journal is in the kept
    copy, not in K's file journal;
  - the refuted calib-H0 rows, as on the base;
  - the Cancel controls' reopen rows (multi-cancel, pen-cancel): reopened after a Cancel, K (unsaved) stays on screen and
    S1 is kept as well as in the file, where the base opened S1 and kept K. This is the same reopen behaviour as U19 (g)
    and U2 row 3b. Every copy is still reachable.

**Counts on c1:** check.mjs 70 pass / 11 fail; xcheck.mjs 56 / 28; xcheck-pen 69 / 8.

**Measured on c1's pen-cancel reopen** (`out/probe-c1/pen-cancel.json`): the status reads "⚠ Alice saved a newer copy to
the saved file (…), but this browser already keeps earlier work aside (kept …) and holds new work besides. Kept work is
never replaced, so the newer copy was not loaded and nothing was lost. Deal with the kept work first: …". **The header
reads "Saved 12:08 AM · ↶ work kept aside" while the record says unsaved** (`base.dirty` true, `DIRTY` false). By code
this is the board's existing opening behaviour: DIRTY starts false at every opening, and nothing sets it from the record.
The same header shows on the base's existing "occupied" and "this browser's copy is newer" openings. It is not changed
here (principle 5). It is now reachable by "put back, then reopen before any Save", where the base opened the file's
copy instead. **I flag it for the lead as an open wording point; it is not measured on the base.**

## 9. The other suites, and npm run check

Both runs are in scratch clones (`git/base`, `git/c1`: `git clone --shared --no-checkout /home/user/orbit-board`, detached
at `7ee498a`, never committed in). `git/c1` has c1's board and audit-import copied over. Its `tools/export-audit/mutate.mjs`
is left as git has it, because no suite run here reads it and nothing here runs it. Each suite ran from the clone's root as
`node tools/export-audit/<suite>.mjs`, or as `npm run check`.

| suite | base | c1 |
|---|---|---|
| boot-same | "every page, source, save and error list is identical either way", exit 0 | same, exit 0 |
| audit | ALL CHECKS PASSED, 0 | ALL CHECKS PASSED, 0 |
| audit-ppt | ALL CHECKS PASSED, 0 | ALL CHECKS PASSED, 0 |
| audit-other | ALL CHECKS PASSED, 0 | ALL CHECKS PASSED, 0 |
| audit-recon | ALL CHECKS PASSED, 0 | ALL CHECKS PASSED, 0 |
| legacy-fsrc | "every legacy Force setting computes exactly as before", 0 | same, 0 |
| audit-hostile | ALL CHECKS PASSED, 0 | ALL CHECKS PASSED, 0 |
| audit-inject | ALL CHECKS PASSED, 0 | ALL CHECKS PASSED, 0 |
| npm run check | all checks passed, 0 | all checks passed, 0 (BUILD v2.00 (11 Oct 2026); both "tracked by git" rows ok) |

**Not run:** the full audit-import and audit-board (the lead's). The lock file was absent at every check, so no run waited
and none was skipped.

## 10. mcount (text only, `rec/bin/mcount.py`, `python3 -I`)

- **c1:** c1's mutate text against c1's board: 1334 entries, 1334 exactly once, none missing, multiple or unparsed.
- **Base:** the base's mutate text against the base board: 1328 entries, 1328 once.
- **c1's mutate text against the base board:** 1328 once; the six new ids are missing, as expected, because they find new
  code.
- Outputs are in `out/mcount/`.

## 11. Blobs (`git hash-object`)

| file | base | c1 |
|---|---|---|
| `prioritization-board-grid.html` | `fce8a391bd8a248d5185e199d22190c1687eaea0` | `8cf14d7e6baf8fa6f590e3082a2ed429458c3490` |
| `tools/export-audit/audit-import.mjs` | `4aba2506a7ea3bd367fb74436172b188bb4fc887` | `a1a3e32c67ca632ce9fb5e8f69ddae5f7881d3e4` |
| `tools/export-audit/mutate.mjs` (as `mutate.mjs.txt`) | `cbc6defc6803851e847844848fc9b186daeeb268` | `67ec010fe747ce2c1fb02987f19a1a4f48429aac` |
| `tools/export-audit/audit-recon.mjs` | `529e36f7…` | unchanged |
| `tools/export-audit/audit-board.mjs` | `a7c575e5…` | unchanged |
| `tools/export-audit/audit-other.mjs` | `d89396b0…` | unchanged |
| everything else in the copy | — | byte-identical to the base (`diff -rq`) |

**Diffs** (`diffs/`):

| file | blob | added | removed |
|---|---|---|---|
| `c1-board.diff` | `fbfcfa39` | 18 | 6 |
| `c1-audit-import.diff` | `6d67a515` | 299 | 5 |
| `c1-mutate.diff` | `8f086db2` | 19 | 0 |
| `c1-all.diff` | `8548c774` | — | — |

All are in the appendix.

**Tools, harnesses and probes:**

