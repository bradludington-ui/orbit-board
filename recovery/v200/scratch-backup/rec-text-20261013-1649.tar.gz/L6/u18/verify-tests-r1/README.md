# U18 — independent verifier, round 1, lens B (test adequacy and regressions)

Reviewer's record for ORBIT v2.00 track U18 ("a copy another writer saves during this board's folder save is never
overwritten unseen"), the builder's one proposed commit in `rec/L6/u18` (`c1`). Times are Eastern, each read with
`TZ=America/New_York date`. This review started at 12:18 PM ET on Tue 13 Oct 2026.

**Resuming.** `verify-tests-r1/` did not exist when I started (12:18 PM ET), so nothing came from an earlier attempt of this
review; every run below was made in this session. (`../verify-money-r1/` is the other lens's folder; I did not use it.)

Nothing in `/home/user/orbit-board` or `/home/user/orbit-ui` was edited, staged or committed; orbit-board was only read (the
ledger, `git log`/`diff --stat`) and cloned with `git clone --shared` into `clones/` (scratch, checked out at `7ee498a`,
nothing committed). The builder's files were only read; everything I ran is in my own copies here.
`tools/export-audit/mutate.mjs` was never imported, executed or run: mutants were made as text by `rec/bin/mkmut.py` and by
my own `bin/mkown.py` (plain find/replace on the board's text), counts by `rec/bin/mcount.py`, all with `python3 -I`.

## Verdict: sound-with-issues — one must-fix, in the tests (a data-loss route the change fixes but no check drives)

- **The board change does what it says, and the builder's numbers reproduce exactly.** My copies are byte-identical to the
  builder's (board `e3986f30`, audit-import `329cf6e8`, mutate `fc364266`); my rebuilt focused harnesses are the builder's
  line for line. The U18 block is 58/58 on c1 and 37 of 58 failing on the base, with the **same verdict on every check** as
  the builder's `f5-*`. All eight builder mutants are caught, each by **exactly the same failing checks** as the builder's
  `m2-*`. U13 71/71, both U2 57/57, F-folderA 297/297, F-folderB 142/142 on c1 (and on the base where I ran them); every
  suite I may run passes on both base and c1. mcount 1328/1328 (base) and 1336/1336 (c1), text only.
- **MUST-FIX 1 (tests, data loss).** The Live **autosave** goes through the same folder save (`liveTick` →
  `driveStorePush(true)`, a quiet save) and is fixed by the same re-check, but no check drives it. The plausible wrong fix
  "autosaves skip the re-check" (`if(!quiet && (why || …))`) passes **all 58 checks**. On the base, the autosave route loses
  Bob's copy exactly as the 💾 Save route does and then says it saved. A tested minimal addition is below: scenario (9),
  three checks (four with its `setup()` check), and the entry `v200-u18-autosave-unchecked`.
- **Should-fix S1 (words).** Putting back the board's stamp time but not its name (`MS.ts=was.ts;` without `MS.by=was.by`)
  passes all 58 checks; the header's tooltip then says Brad saved Bob's copy. Tested addition (10), two checks (three with `setup()`'s),
  entry `v200-u18-stamp-name-moved`.
- Minor points below (an unlabelled check that passes on the base, one observed value used as an expected value, two
  surviving mutants that are equivalent or near-equivalent, and one untested design decision).

## What I checked, and how

### 1. Identities and diffs (my own copies; `diffs/`)

| copy | board | audit-import | mutate (text) | made from |
|---|---|---|---|---|
| `b0/` | `fce8a391` | `4aba2506` | `cbc6defc` | `cp -a ../../base` (`diff -rq` identical) |
| `c1/` | `e3986f30e6cb8ebd543c60c3c8d4c3361f36ec01` | `329cf6e89f0a602aaaccf53a07c1cf2bae34639c` | `fc364266c7d4533c969eca1667799c889c2e97c4` | `cp -a ../c1` (blobs equal the builder's) |
| `c1q/` (my proposal, below) | `e3986f30` (unchanged) | `e0d25ad34d2d6eb8aa00268abc4b4dbcf4d6912e` | `e868df9db90b25bad3ed419d1e3597a8f407d3fe` | `c1` + `probe/proposed-9-10.mjs.txt` + `probe/proposed-entries.mjs.txt` |

audit-recon `529e36f7`, audit-board `a7c575e5`, audit-other `d89396b0` are unchanged in c1. My `diffs/c1-board.diff`,
`c1-audit-import.diff` and `c1-mutate.diff` have hunks identical to the builder's `../diffs/` (only the header lines differ).

- **Board:** +30 −1, all in `_driveStorePushRun` (stamp capture; the re-read and refusal before `driveWrite`) and
  `driveClashSay` (the `'late'` wording). Read in full against the function.
- **audit-import:** +255 −0. c1's suite is exactly the base's with `blocks/u18.mjs.txt` inserted after
  `// ==== end v2.00 (U13) ====` (checked by string comparison). **No existing line of any suite is changed**, so no existing
  expectation was changed (principle 6 holds; nothing to list).
- **mutate.mjs (text):** +25 −0, eight `{ id, area, what, find, repl }` entries placed right before
  `  // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.` No existing entry
  is changed.
- House style: the block follows the v2.00 blocks (async wrapper, `bootMark()`/`bootRelease(__bm, keepBoards())`/
  `settleBoards()`, two-space `  const name = '…';`, `// ==== …` markers); board comments use the `// v2.00 (U18): …` prefix.

### 2. Expected values and the base

- **Literals.** Every expected value is a hand-written literal or built from literal string constants (`LATE`, `EARLY`,
  `NOTSAVED(…)`, `CHOICES`, `TAIL`), **except one**: `refusedThen`'s stamp check expects `J([...st0, 'Unsaved changes'])`,
  where `st0 = stamp(A.ev)` is the board's stamp read before the save (minor M2 below). Board helpers are otherwise used
  only for observed values; identities (`base(A.ev) === tsOf(v1)`, `headTs(fold) === bobTs`) are compared with literal `true`.
- **Fails on the base.** Base run `v1-F-u18-b0`: 37 of 58 fail, 21 pass — the same 37/21 as the builder's `f5-F-u18-b0`,
  verdict for verdict. Of the 21 that pass on the base, 20 are setup checks or checks in scenarios labelled "(a CONTROL)";
  the one that is neither is (1)'s "the history holds v1, BRAD-1, $700, and nothing else" (minor M1; it is not useless — it
  is the only check that catches my `vt-keep-theirs-then-write`).

### 3. The builder's runs, re-run and compared

| builder's run | builder's result | mine | same? |
|---|---|---|---|
| F-u18 on c1 (`f5-F-u18-c1`) | 58/58 | `v1-F-u18-c1` 58/58 | yes, every verdict |
| F-u18 on base (`f5-F-u18-b0`) | 37 fail | `v1-F-u18-b0` 37 fail | yes, every verdict |
| 8 mutants `m2-v200-u18-*` | 35/3/3/3/5/1/4/1 fail | `m-v200-u18-*` 35/3/3/3/5/1/4/1 fail | yes, the same failing checks for each (compared set to set) |
| F-u13 base / c1 | 71/71, 71/71 | `r-F-u13-b0`, `r-F-u13-c1` 71/71, 71/71 | yes |
| F-u2 base / c1 | 57/57, 57/57 | `r-F-u2-b0`, `r-F-u2-c1` 57/57, 57/57 | yes |
| F-folderA base / c1 | 297/297, 297/297 | `r-F-folderA-b0`, `r-F-folderA-c1` 297/297, 297/297 | yes |
| F-folderB base / c1 | 142/142, 142/142 | `r-F-folderB-b0`, `r-F-folderB-c1` 142/142, 142/142 | yes |
| suites b0 / c1 (boot-same, audit, audit-ppt, audit-other, audit-recon, legacy-fsrc, audit-hostile, audit-inject, npm run check) | all pass on both | all exit 0 on both (`out/suites-b0.summary`, `out/suites-c1.summary`) | yes |
| mcount | base 1328/1328; c1 1336/1336; c1 mutate on base: the 8 U18 ids missing | the same (`out/mcount-*.json`) | yes |

I did not re-run the builder's probe (`probe/u18-probe.mjs`); the block's own base run reproduces the defect (BRAD-2 written
over BOB-2, "✅ Saved", `v1-F-u18-b0`).

### 4. My own mutants (plausible wrong fixes), each through F-u18 on c1

Made by `bin/mkown.py` (`aa76e8f1`) from c1's board, text only; each find matched exactly once. Logs `logs/m-vt-*.log`,
every check and value in `out/m-vt-*.checks.jsonl`.

| mutant (blob) | the wrong fix | failing checks of 58 | caught by |
|---|---|---|---|
| `vt-recheck-before-history` (`e3ec5666`) | the re-check moved to right after the bytes are built, before the history keep (not after the last wait) | 29 | (1), (2), (1b), (3), (6a–c), (8) — not (7): with no copy read there is no history keep to move it past |
| `vt-keep-theirs-then-write` (`3150788e`) | a copy that landed is kept in the history, then written over without asking | 24 | (1) incl. its history check, (2), (1b), (3), (6c), (8) |
| `vt-error-as-none` (`878fe890`) | a re-read that fails is taken as "nothing there" | 4 | (6b) words; (7b) |
| `vt-takepen-unchecked` (`c0381837`) | a take-the-pen save skips the re-check | 3 | (8) only |
| `vt-by-compare` (`98e20ebd`) | compares who saved (`now.by` vs `cur.by`), not the copy | 3 | (8) only (Bob over Bob) |
| `vt-read-year-on-screen` (`2fb62ec9`) | re-reads the year on screen (as `driveResolve` reads), not the year the save was for | 1 | (6c) words only |
| **`vt-quiet-unchecked` (`b380a60e`)** | **the Live autosave (`quiet`) skips the re-check** | **0 — survives** | — (MUST-FIX 1) |
| **`vt-restore-ts-only` (`70612c26`)** | **puts back the stamp's time, not its name** | **0 — survives** | — (S1) |
| `vt-stamp-compare` (`d72bfeb9`) | compares the copy's stamp, not its bytes | 0 — survives | — (minor M5) |
| `vt-restore-always` (`076d318a`) | puts the stamp back even when something was typed meanwhile | 0 — survives | — (minor M4) |
| `vt-no-render` (`8376f152`) | the refusal does not call `render()` | 0 — survives | — (equivalent, minor M4) |

Six of eleven caught. Two of the caught ones hang on a single scenario ((8) for take-the-pen and for Bob-over-Bob; (6c)'s
words for the year read) — enough, but thin.

### 5. A sample of existing mutants in the changed function, on c1 (masking check)

Sixteen existing entries have their find inside `_driveStorePushRun`/`driveClashSay`. The new re-read adds a wait and a
refusal, so I ran four whose catching scenarios sit near it, on c1, to see they are still caught (not masked):

| existing entry (c1 mutant blob) | harness | failing on c1 | |
|---|---|---|---|
| `folder-writes-screen-year` (`9403f26e`) | F-folderA | 2 of 297 (v1.95 "year switch during the write") | still caught |
| `folder-writer-unchecked` (`ac05f5fb`) | F-folderA | 4 of 297 (v1.95 one writer per board file) | still caught |
| `folder-history-written-over` (`8ea3561c`) | F-folderB | 6 of 142 (v1.97 item 79, each history failure) | still caught |
| `v200-r3-cycblock-gone` (`c3447e8f`) | F-folderB | 4 of 142 (R3 (a)) | still caught |

None is masked by the new re-read. (Base mutant boards `b0-ex-*` were made too but not run; I did not re-check these four
on the base.)

## MUST-FIX 1 — the Live autosave route is fixed but not tested (data loss)

**Defect in the tests.** `_driveStorePushRun(quiet, …)` is reached by 💾 Save, ✍ Take the pen, ⬆ Publish now and Save yours
over theirs with `quiet=false`, and by the Live timer's autosave (`liveTick` → `driveStorePush(true)`) with `quiet=true`.
Working out of the shared folder turns Live and autosave on, so the autosave is the save that runs most often. Every U18
scenario saves with `quiet=false`.

**Reproduction.** `mut/c1-vt-quiet-unchecked.html` (`b380a60e`), the c1 board with
`    if(!quiet && (why || (cur? (!now || nowRaw.txt!==curRaw.txt) : !!now))){` in place of the re-check's condition:
`m-vt-quiet-unchecked` — **58/58 pass, exit 0** (12:23 PM ET). The route itself, scenario (9) below, on the base
(`q-F-u18q-b0` / `p-F-u18p-b0`): Brad's autosave, held at its history copy while Bob takes the pen, then let go, writes
BRAD-2 over BOB-2 (`["BRAD-2",720,"Brad","Brad",2,[["BRAD-1",700]]]`: two main writes since the hold, Bob's copy in no copy
in the folder), Brad is recorded saved and the line says it saved (`[…,false,false,false,true]`). On c1 the same route is
refused and Bob's copy stays — the fix works; only the test is missing.

**Minimal fix (tested).** Add scenario (9) to the U18 block, before `  } catch (e) {` (`probe/proposed-9-10.mjs.txt`, first
scenario), and the entry `v200-u18-autosave-unchecked` (`probe/proposed-entries.mjs.txt`):

```js
  // (9) THE LIVE AUTOSAVE: the same folder save, quiet, from the Live timer. Held at its history write while Bob takes the pen;
  // let go, it writes nothing over BOB-2, and the board does not say it saved automatically.
  { const sc = '(9) Bob takes the pen while Brad’s Live autosave is held';
    const { fold, A, Bb, v1 } = await setup(sc); const st0 = stamp(A.ev);
    A.ev(`_liveCfg.on=true; _liveCfg.auto=true; _driveLive=true; 'ok'`);   // working out of the folder turns these on
    const h = await held(A, fold, 'liveTick()'); await pause(5);
    const m0 = mains(fold); await Bb.ev('takePen()'); await pause(5);
    chk(name, sc, 'while Brad’s autosave is held, Bob takes the pen: BOB-2, $650, saved by Bob, its writer now, is the folder’s copy (a CONTROL)',
      J([h.ok, ...head(fold), ...who(fold), mains(fold) - m0]), J([true, 'BOB-2', 650, 'Bob', 'Bob', 1]));
    h.g.open(); await h.p; await pause(5);
    chk(name, sc, 'the autosave, let go, writes nothing over it: BOB-2, $650, saved by Bob, its writer, is still the folder’s copy; one write of it since the hold, Bob’s; v1 in the history and nothing else',
      J([...head(fold), ...who(fold), mains(fold) - m0, histHolds(fold)]), J(['BOB-2', 650, 'Bob', 'Bob', 1, [['BRAD-1', 700]]]));
    chk(name, sc, 'Brad’s work stays on screen, in browser storage and unsaved, recorded against v1; the board’s stamp as it was; nothing says it saved',
      J([...scr(A.ev), ...stored(A.ev), unsaved(A.ev), base(A.ev) === tsOf(v1), J(stamp(A.ev)) === J(st0), /Saved/.test(status(A.ev))]),
      J(['BRAD-2', 720, 'BRAD-2', 720, true, true, true, false]));
  }
```

```js
  { id: "v200-u18-autosave-unchecked", area: "_driveStorePushRun", what: "the Live autosave (a quiet folder save) does not check the folder's copy again before it writes: Bob's take-the-pen save, landing while Brad's autosave keeps the history, is written over and is then in no copy in the folder",
    find: "    if(why || (cur? (!now || nowRaw.txt!==curRaw.txt) : !!now)){\n",
    repl: "    if(!quiet && (why || (cur? (!now || nowRaw.txt!==curRaw.txt) : !!now))){\n" },
```

Results with it (`c1q`, harness `F-u18q.mjs` `081cd5e0`, built verbatim from c1q's suite): 

| run | board | checks | failing |
|---|---|---|---|
| `q-F-u18q-c1` | c1 `e3986f30` | 65 | **0** (all pass, exit 0) |
| `q-F-u18q-b0` | base `fce8a391` | 65 | **40** = the 37 as before + (9)'s two non-control checks + (10)'s second check; (9)'s and (10)'s controls pass |
| `q-F-u18q-autosave-unchecked` | `b380a60e` | 65 | **2**, both in (9): `["BRAD-2",720,"Brad","Brad",2,[["BRAD-1",700]]]` and `["BRAD-2",720,"BRAD-2",720,false,false,false,true]` |
| `q-F-u18q-stamp-name-moved` | `70612c26` | 65 | **1**, (10)'s second check: `["BOB-3",640,"Bob","Bob",true,"Brad",true,false,true]` |

mcount on c1q (text): 1338 entries, 1338 once; c1q's mutate on the base board: 1328 once, exactly the ten U18 ids missing
(`out/mcount-c1q.json`). The diffs against c1 are additions only: `diffs/c1q-audit-import.diff` (+33) and
`diffs/c1q-mutate.diff` (+6).

## SHOULD-FIX

**S1 — the name half of the stamp restore has no check.** In every U18 scenario the stamp's name before the save is already
Brad's (he saved v1, or typed, and `save()` stamps `MS.by=whoAmI()`), so `if(MS.ts===wroteTs){ MS.ts=was.ts; }` (no
`MS.by=was.by`) passes all 58 (`m-vt-restore-ts-only`, exit 0). It is reachable: Brad loads Bob's copy (stamped Bob), types
nothing, takes the pen, and Bob saves while that save is held; refused, the board's tooltip then reads "Saved <Bob's time>
by Brad" — a save Brad never made (principle 4). Proposed scenario (10) (two checks, second part of
`probe/proposed-9-10.mjs.txt`) and entry `v200-u18-stamp-name-moved` (find
`if(MS.ts===wroteTs){ MS.ts=was.ts; MS.by=was.by; }`, repl `if(MS.ts===wroteTs){ MS.ts=was.ts; }`). Results: see the table under MUST-FIX 1 (`q-F-u18q-stamp-name-moved`: one check fails, (10)'s second; c1 passes it; the base fails it).

### If (9) and (10) are adopted: the builder's drafts change in these places only

- `drafts/NEXT-VERSION-u18.md`, **Test:** "(58 checks)" → "(65 checks)"; add "the same race through the Live autosave (the
  quiet save the Live timer makes); and, with nothing typed, a stopped take-the-pen save over Bob's copy keeps Bob's name
  in the board's stamp" after "…takes its pen line back;"; "37 checks fail on the board before the change" → "40 checks
  fail…". **Mutations:** add `-autosave-unchecked` and `-stamp-name-moved`.
- `drafts/LEDGER-u18.md` §1: "Focused block 58 checks: 37 fail on the base board" → "Focused block 65 checks: 40 fail on
  the base board"; "Eight mutations" → "Ten mutations"; "mcount 1336/1336" → "mcount 1338/1338"; and the audit-import and
  mutate blobs become the lead's final ones (mine, `e0d25ad3` and `e868df9d`, are for this proposal only).
- Each of (9) and (10) calls `setup()`, which records one check of its own: 4 + 3 = 7 new checks, of which (9)'s two and
  (10)'s one non-control check fail on the base.

## Minor

- **M1.** (1)'s "the history holds v1, BRAD-1, $700, and nothing else" passes on the base and is not labelled a control. Say
  so in its words (or fold it into the check before it). It does earn its place: it alone catches `vt-keep-theirs-then-write`.
- **M2.** `refusedThen`'s stamp check expects `J([...st0, 'Unsaved changes'])`, with `st0` read from the board — an observed
  value in the expected position. (8) already uses the house form; use it here too:
  `J([J(stamp(A.ev)) === J(st0), header(A.ev)])` against `J([true, 'Unsaved changes'])`.
- **M3.** The header text is minute-resolution ("Saved 12:22 PM"), so (1b)'s `header(A.ev) === hd0` cannot see a stamp moved
  within the same minute; the `MS.ts`/`MS.by` values beside it carry that check (they catch `v200-u18-stamp-moved`).
- **M4.** `vt-restore-always` and `vt-no-render` survive. The first changes only the in-memory stamp after something was typed
  during the hold (the header then says "Unsaved changes" either way, and browser storage already holds the typing's stamp);
  the second leaves the header as it was before the save, which the restore makes equal to what `render()` would draw. I
  judge both equivalent or near-equivalent; no check proposed.
- **M5.** `vt-stamp-compare` survives: the "byte for byte" decision is not pinned. Every board save stamps a new
  `store.ts`, so only a writer other than the board could make same-stamp, different-bytes copies; a check (the folder's copy
  rewritten during the hold with v1's stamp and another note) would pin it if the lead wants the decision tested.
- **For the lead (scope, not a defect of the change).** The ledger row's own evidence (`rec/L2/u13probe`) held Brad's save at
  the close of its **main write**, which is the window the builder lists as not covered (no atomic compare-and-write);
  U13's (2) still shows Bob's copy written over there, on c1 as on the base. The builder's drafts say this plainly ("Still
  open, narrower: a copy landing during the write itself"); keep that wording when the row is updated.
- My own process note: one `node --check` of my probe harness `P-autosave.mjs` (syntax only, under a second; between the
  clock reads of 12:26:56 and 12:29:01 PM ET, not run through `run.sh`, lock absent) ran while my two mutant lanes were
  running, so for that second three node processes of mine were up. Not repeated.

## Every run

| label | start (ET) | exit | wall s | log | result |
|---|---|---|---|---|---|
| v1-F-u18-c1 | 2026-10-13 12:20:48 EDT | 0 | 67.9 | `logs/v1-F-u18-c1.log` | ALL CHECKS PASSED (58 checks, 0 fail) |
| v1-F-u18-b0 | 2026-10-13 12:21:56 EDT | 1 | 62.1 | `logs/v1-F-u18-b0.log` | 37 FAILING CHECK(S) (58 checks, 37 fail) |
| m-vt-quiet-unchecked | 2026-10-13 12:23:58 EDT | 0 | 57.5 | `logs/m-vt-quiet-unchecked.log` | ALL CHECKS PASSED (58 checks, 0 fail) |
| m-vt-no-render | 2026-10-13 12:23:58 EDT | 0 | 58.0 | `logs/m-vt-no-render.log` | ALL CHECKS PASSED (58 checks, 0 fail) |
| m-vt-stamp-compare | 2026-10-13 12:24:56 EDT | 0 | 71.2 | `logs/m-vt-stamp-compare.log` | ALL CHECKS PASSED (58 checks, 0 fail) |
| m-vt-takepen-unchecked | 2026-10-13 12:24:56 EDT | 1 | 70.9 | `logs/m-vt-takepen-unchecked.log` | 3 FAILING CHECK(S) (58 checks, 3 fail) |
| m-vt-by-compare | 2026-10-13 12:26:07 EDT | 1 | 77.1 | `logs/m-vt-by-compare.log` | 3 FAILING CHECK(S) (58 checks, 3 fail) |
| m-vt-restore-always | 2026-10-13 12:26:07 EDT | 0 | 90.1 | `logs/m-vt-restore-always.log` | ALL CHECKS PASSED (58 checks, 0 fail) |
| m-vt-error-as-none | 2026-10-13 12:27:24 EDT | 1 | 91.6 | `logs/m-vt-error-as-none.log` | 4 FAILING CHECK(S) (58 checks, 4 fail) |
| m-vt-restore-ts-only | 2026-10-13 12:27:37 EDT | 0 | 89.2 | `logs/m-vt-restore-ts-only.log` | ALL CHECKS PASSED (58 checks, 0 fail) |
| m-vt-recheck-before-history | 2026-10-13 12:28:56 EDT | 1 | 105.2 | `logs/m-vt-recheck-before-history.log` | 29 FAILING CHECK(S) (58 checks, 29 fail) |
| m-vt-keep-theirs-then-write | 2026-10-13 12:29:06 EDT | 1 | 105.7 | `logs/m-vt-keep-theirs-then-write.log` | 24 FAILING CHECK(S) (58 checks, 24 fail) |
| m-v200-u18-said-nothing-written | 2026-10-13 12:30:41 EDT | 1 | 106.4 | `logs/m-v200-u18-said-nothing-written.log` | 5 FAILING CHECK(S) (58 checks, 5 fail) |
| m-vt-read-year-on-screen | 2026-10-13 12:30:52 EDT | 1 | 103.9 | `logs/m-vt-read-year-on-screen.log` | 1 FAILING CHECK(S) (58 checks, 1 fail) |
| m-v200-u18-pen-line-kept | 2026-10-13 12:32:28 EDT | 1 | 96.8 | `logs/m-v200-u18-pen-line-kept.log` | 1 FAILING CHECK(S) (58 checks, 1 fail) |
| m-v200-u18-recheck-gone | 2026-10-13 12:32:36 EDT | 1 | 98.7 | `logs/m-v200-u18-recheck-gone.log` | 35 FAILING CHECK(S) (58 checks, 35 fail) |
| m-v200-u18-stamp-moved | 2026-10-13 12:34:05 EDT | 1 | 86.7 | `logs/m-v200-u18-stamp-moved.log` | 4 FAILING CHECK(S) (58 checks, 4 fail) |
| m-v200-u18-first-copy-unchecked | 2026-10-13 12:34:15 EDT | 1 | 87.5 | `logs/m-v200-u18-first-copy-unchecked.log` | 3 FAILING CHECK(S) (58 checks, 3 fail) |
| m-v200-u18-other-year-choices | 2026-10-13 12:35:31 EDT | 1 | 117.6 | `logs/m-v200-u18-other-year-choices.log` | 1 FAILING CHECK(S) (58 checks, 1 fail) |
| lane B done 2026-10-13 12:37:29 EDT | | | | | |
| m-v200-u18-gone-written-in-place | 2026-10-13 12:35:43 EDT | 1 | 119.8 | `logs/m-v200-u18-gone-written-in-place.log` | 3 FAILING CHECK(S) (58 checks, 3 fail) |
| m-v200-u18-unreadable-written | 2026-10-13 12:37:42 EDT | 1 | 101.6 | `logs/m-v200-u18-unreadable-written.log` | 3 FAILING CHECK(S) (58 checks, 3 fail) |
| lane A done 2026-10-13 12:39:24 EDT | | | | | |
| S-b0-boot-same | 2026-10-13 12:39:34 EDT | 0 | 35.0 | `logs/S-b0-boot-same.log` |  |
| S-b0-audit | 2026-10-13 12:40:09 EDT | 0 | 31.5 | `logs/S-b0-audit.log` | ALL CHECKS PASSED |
| S-b0-audit-ppt | 2026-10-13 12:40:40 EDT | 0 | 17.6 | `logs/S-b0-audit-ppt.log` | ALL CHECKS PASSED |
| p-F-u18p-c1 | 2026-10-13 12:39:34 EDT | 1 | 119.6 | `logs/p-F-u18p-c1.log` | 1 FAILING CHECK(S) (65 checks, 1 fail) |
| S-b0-audit-other | 2026-10-13 12:40:58 EDT | 0 | 124.3 | `logs/S-b0-audit-other.log` | ALL CHECKS PASSED |
| p-F-u18p-b0 | 2026-10-13 12:41:34 EDT | 1 | 127.8 | `logs/p-F-u18p-b0.log` | 41 FAILING CHECK(S) (65 checks, 41 fail) |
| p-F-u18p-autosave-unchecked | 2026-10-13 12:43:41 EDT | 1 | 125.8 | `logs/p-F-u18p-autosave-unchecked.log` | 3 FAILING CHECK(S) (65 checks, 3 fail) |
| p-F-u18p-stamp-name-moved | 2026-10-13 12:45:47 EDT | 1 | 120.6 | `logs/p-F-u18p-stamp-name-moved.log` | 2 FAILING CHECK(S) (65 checks, 2 fail) |
| r-F-u13-c1 | 2026-10-13 12:47:48 EDT | 0 | 112.2 | `logs/r-F-u13-c1.log` | ALL CHECKS PASSED (71 checks, 0 fail) |
| S-b0-audit-recon | 2026-10-13 12:43:02 EDT | 0 | 415.5 | `logs/S-b0-audit-recon.log` | ALL CHECKS PASSED |
| S-b0-legacy-fsrc | 2026-10-13 12:49:58 EDT | 0 | 14.6 | `logs/S-b0-legacy-fsrc.log` |  |
| r-F-u2-c1 | 2026-10-13 12:49:40 EDT | 0 | 196.5 | `logs/r-F-u2-c1.log` | ALL CHECKS PASSED (57 checks, 0 fail) |
| S-b0-audit-hostile | 2026-10-13 12:50:13 EDT | 0 | 267.5 | `logs/S-b0-audit-hostile.log` | ALL CHECKS PASSED |
| S-b0-audit-inject | 2026-10-13 12:54:40 EDT | 0 | 54.4 | `logs/S-b0-audit-inject.log` | ALL CHECKS PASSED |
| S-b0-npm-check | 2026-10-13 12:55:35 EDT | 0 | 16.2 | `logs/S-b0-npm-check.log` | all checks passed |
| S-c1-boot-same | 2026-10-13 12:55:51 EDT | 0 | 40.9 | `logs/S-c1-boot-same.log` |  |
| S-c1-audit | 2026-10-13 12:56:32 EDT | 0 | 37.5 | `logs/S-c1-audit.log` | ALL CHECKS PASSED |
| S-c1-audit-ppt | 2026-10-13 12:57:10 EDT | 0 | 18.9 | `logs/S-c1-audit-ppt.log` | ALL CHECKS PASSED |
| r-F-folderA-c1 | 2026-10-13 12:52:57 EDT | 0 | 388.3 | `logs/r-F-folderA-c1.log` | ALL CHECKS PASSED (297 checks, 0 fail) |
| S-c1-audit-other | 2026-10-13 12:57:29 EDT | 0 | 127.5 | `logs/S-c1-audit-other.log` | ALL CHECKS PASSED |
| S-c1-audit-recon | 2026-10-13 12:59:36 EDT | 0 | 310.7 | `logs/S-c1-audit-recon.log` | ALL CHECKS PASSED |
| S-c1-legacy-fsrc | 2026-10-13 13:04:47 EDT | 0 | 8.8 | `logs/S-c1-legacy-fsrc.log` |  |
| r-F-folderB-c1 | 2026-10-13 12:59:25 EDT | 0 | 429.8 | `logs/r-F-folderB-c1.log` | ALL CHECKS PASSED (142 checks, 0 fail) |
| S-c1-audit-hostile | 2026-10-13 13:04:56 EDT | 0 | 200.2 | `logs/S-c1-audit-hostile.log` | ALL CHECKS PASSED |
| S-c1-audit-inject | 2026-10-13 13:08:16 EDT | 0 | 41.8 | `logs/S-c1-audit-inject.log` | ALL CHECKS PASSED |
| S-c1-npm-check | 2026-10-13 13:08:58 EDT | 0 | 11.9 | `logs/S-c1-npm-check.log` | all checks passed |
| slane done 2026-10-13 13:09:10 EDT | | | | | |
| r-F-u13-b0 | 2026-10-13 13:09:10 EDT | 0 | 106.3 | `logs/r-F-u13-b0.log` | ALL CHECKS PASSED (71 checks, 0 fail) |
| ex-folder-writes-screen-year | 2026-10-13 13:06:35 EDT | 1 | 321.3 | `logs/ex-folder-writes-screen-year.log` | 2 FAILING CHECK(S) (297 checks, 2 fail) |
| r-F-u2-b0 | 2026-10-13 13:10:56 EDT | 0 | 129.9 | `logs/r-F-u2-b0.log` | ALL CHECKS PASSED (57 checks, 0 fail) |
| r-F-folderA-b0 | 2026-10-13 13:13:06 EDT | 0 | 282.9 | `logs/r-F-folderA-b0.log` | ALL CHECKS PASSED (297 checks, 0 fail) |
| ex-folder-history-written-over | 2026-10-13 13:11:57 EDT | 1 | 411.0 | `logs/ex-folder-history-written-over.log` | 6 FAILING CHECK(S) (142 checks, 6 fail) |
| flane C done 2026-10-13 13:18:48 EDT | | | | | |
| q-F-u18q-c1 | 2026-10-13 13:19:01 EDT | 0 | 80.0 | `logs/q-F-u18q-c1.log` | ALL CHECKS PASSED (65 checks, 0 fail) |
| q-F-u18q-b0 | 2026-10-13 13:20:21 EDT | 1 | 73.9 | `logs/q-F-u18q-b0.log` | 40 FAILING CHECK(S) (65 checks, 40 fail) |
| q-F-u18q-autosave-unchecked | 2026-10-13 13:21:35 EDT | 1 | 70.6 | `logs/q-F-u18q-autosave-unchecked.log` | 2 FAILING CHECK(S) (65 checks, 2 fail) |
| r-F-folderB-b0 | 2026-10-13 13:17:49 EDT | 0 | 343.7 | `logs/r-F-folderB-b0.log` | ALL CHECKS PASSED (142 checks, 0 fail) |
| q-F-u18q-stamp-name-moved | 2026-10-13 13:22:46 EDT | 1 | 90.7 | `logs/q-F-u18q-stamp-name-moved.log` | 1 FAILING CHECK(S) (65 checks, 1 fail) |
| flane E done 2026-10-13 13:24:16 EDT | | | | | |
| ex-folder-writer-unchecked | 2026-10-13 13:23:33 EDT | 1 | 184.1 | `logs/ex-folder-writer-unchecked.log` | 4 FAILING CHECK(S) (297 checks, 4 fail) |
| ex-v200-r3-cycblock-gone | 2026-10-13 13:26:37 EDT | 1 | 274.4 | `logs/ex-v200-r3-cycblock-gone.log` | 4 FAILING CHECK(S) (142 checks, 4 fail) |
| flane D done 2026-10-13 13:31:12 EDT | | | | | |

59 bounded runs, every one through `bin/run.sh` (`setsid -w timeout -k 10 600`; the `AUDIT_IMPORT_RUNNING` lock was checked
before each and was never present, so none waited or was skipped; none hit the 600 s cap). Exit 1 on a mutant or on the base
is the expected "caught"/"fails on the base". `p-F-u18p-*` are my proposal's first version (its (10) control was wrong, see
Files) and are superseded by `q-F-u18q-*`; they are kept and shown, not counted. At most two runs of mine were under way at
any time (lanes A+B, then C+D, then E took C's place), apart from the one `node --check` noted under Minor.
boot-same and legacy-fsrc print no "ALL CHECKS PASSED"; their last lines, the same on base and c1, are "every page, source,
save and error list is identical either way" and "every legacy Force setting computes exactly as before".

README closed at 1:32 PM ET on Tue 13 Oct 2026, after the last run (`ex-v200-r3-cycblock-gone`, started 1:26:37 PM ET, ended by 1:31:12 PM
ET); no process of mine was left running (checked against `pids.txt`).

## PIDs

Every bounded run's `timeout` PID and its `node`/`npm` child are in `pids.txt` with the command (written by `bin/run.sh`),
and each lane wrapper (`lane.sh`, `flane.sh`, `slane.sh`, `elane.sh`, `suites.sh`) recorded its own PID. I stopped no
process; nothing was killed. Monitors and waits were plain shell loops reading `logs/runs.txt`.

## Files

- `bin/`: `run.sh`, `frun.sh`, `runner.mjs`, `mkfocused-multi.py`, `fails.py`, `suites.sh` copied from the builder's `bin/`
  (only the `U=` line changed); my own `mkown.py`, `lane.sh`, `flane.sh`, `slane.sh`, `elane.sh`, `runs-table.py`.
- `harness/`: F-u18, F-u13, F-u2, F-folderA, F-folderB (verbatim from c1's suite; same as the builder's except line 1),
  F-u18p (my proposal, first version — its (10) control read the tooltip before anything had re-drawn it, so that control
  failed on c1; superseded, kept), F-u18q (the proposal as given above), P-autosave (an earlier probe of the same route,
  superseded by (9) and never run).
- `mut/`: every mutant board (blobs above and in the runs table); `diffs/`: c1 vs base, c1q vs c1, two structural mutants.
- `out/`: checks files (`*.checks.jsonl`), suite summaries, mcount JSON.

## What I did not do

- Did not run the full audit-import or audit-board (the lead's), Chromium or playwright (no layout change).
- Did not import, execute or run `tools/export-audit/mutate.mjs`, not even to count.
- Did not run all 16 existing mutants in the changed function on c1 — four, chosen near the change.
- Did not run the builder's probe; did not run my P-autosave probe (superseded by (9)).
- Did not commit, push or edit anything outside this folder; the proposal is in my copy `c1q/` only.
