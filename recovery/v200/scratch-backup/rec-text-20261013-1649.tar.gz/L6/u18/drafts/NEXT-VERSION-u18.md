<!-- Draft for NEXT-VERSION.md, under "### v2.00 — 11 Oct 2026 ...", after the U14 entry and before "- **Unresolved after
R1–R5 (11 Oct).**". Wrapped as the U13/U1/U14 entries are. The lead commits; nothing here is in any copy. -->
- **U18 — a copy saved while a folder save is under way is never written over** (the lead's decision on 12 Oct, under
  Brad's "Don't wait for me. Let's keep pressing throughout to get this next version published.", about 5:30 PM ET). The
  folder save read the folder's copy once, at its start, and then wrote over whatever was there by the time it wrote. Bob
  took the pen and saved while Brad's 💾 Save was keeping the copy it had read in the folder's history; Brad's save then
  wrote his work over Bob's copy and thinned the history, so Bob's copy was in no copy in the folder, and Brad's board
  said "✅ Saved". U13 kept Brad's own record consistent but not Bob's copy. Now the save reads the folder's copy again
  after its last wait, just before it writes. Unless that copy is still, byte for byte, the one it read (or there is still
  none), nothing is written in its place: Bob's copy stays the folder's copy, Brad's work stays on screen, not saved, and
  the copy the save read stays in the folder's history. A copy that landed meanwhile is the clash, said with who saved it
  and when, with the same two choices; a copy gone or unreadable is said as such. The board's header still says when it
  was last saved, not when the stopped save began.
  - **What users may see:** in that race, instead of "✅ Saved": "⛔ Bob saved O&M FY27 to the shared folder just now,
    after the copy you are working from. Their copy landed while your save was under way, and your save stopped before
    writing over it. Load theirs (your work is kept aside, and one click puts it back) · Save yours over theirs (theirs is
    kept in the folder’s history)." If the folder's copy is gone or cannot be read just before the write: "⛔ Not saved.
    The shared folder’s copy of O&M FY27 is no longer there" (or "could not be read again just before it was to be
    written over — <the reason>") ". Nothing was written in its place: a save never writes over a copy it has not read.
    Your work is still here — 💾 Save again to read the folder afresh." The same words, with "changed while this save was
    under way" and no choices, if the board was moved to another year meanwhile. Every folder save now reads the folder's
    copy twice.
  - **Test:** audit-import "v2.00 (U18) — a copy saved while a folder save is under way is never written over"
    (58 checks): Bob takes the pen and saves while Brad's save is held at its last wait, with Brad's work unsaved and
    with nothing unsaved (U13's second-writer case, held before the write instead of in it): refused, Bob's copy the
    folder's copy, Brad's work and the board's stamp as they were, the clash said word for word with both choices; the
    retry, Save yours over theirs (refused while Bob holds the pen, with Bob's copy kept in the history) then Take the pen
    (Brad's work lands; v1 and Bob's copy both in the history); Load theirs; the folder's copy removed, unreadable, or
    saved by Bob while the board moved to FY28; the folder's first copy landing at the save's read just before its write,
    and the same unreadable; a take-the-pen save stopped there takes its pen line back; and two controls (no second writer:
    the save lands as before; Bob saves before Brad's save reads the folder: the existing clash, word for word). 37
    checks fail on the board before the change; every control passes on both, except (7)'s hold, which that board cannot
    reach (it makes no read there).
  - **Mutations:** `v200-u18-recheck-gone`, `-first-copy-unchecked`, `-gone-written-in-place`, `-unreadable-written`,
    `-said-nothing-written`, `-pen-line-kept`, `-stamp-moved` and `-other-year-choices`; each caught by the focused block
    (full-suite sensitivity runs in the final-tree queue).
  - **Not covered:** a copy that lands while the write itself is being made (between its start and its close) is still
    written over: a file share has no atomic compare-and-write. U13's second-writer case holds Brad's save exactly there,
    and still sees Bob's copy written over. The window is now the write alone, no longer the history keeping before it.
    A save waiting for another tab's Web Lock (U20) is not changed by this.
