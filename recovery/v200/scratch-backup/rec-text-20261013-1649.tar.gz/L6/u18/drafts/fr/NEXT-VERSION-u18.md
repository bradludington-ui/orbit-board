<!-- Draft for NEXT-VERSION.md, under "### v2.00 — 11 Oct 2026 ...", after the U14 entry and before "- **Unresolved after
R1–R5 (11 Oct).**". Wrapped as the U13/U1/U14 entries are. The lead commits; nothing here is in any copy.
FIX ROUND (13 Oct): this replaces drafts/NEXT-VERSION-u18.md (657a0da5), which is superseded. -->
- **U18 — a copy saved while a folder save is under way is never written over** (the lead's decision on 12 Oct, under
  Brad's "Don't wait for me. Let's keep pressing throughout to get this next version published.", about 5:30 PM ET). The
  folder save read the folder's copy once, at its start, and then wrote over whatever was there by the time it wrote. Bob
  took the pen and saved while Brad's 💾 Save was keeping the copy it had read in the folder's history; Brad's save then
  wrote his work over Bob's copy and thinned the history, so Bob's copy was in no copy in the folder, and Brad's board
  said "✅ Saved". The Live autosave, which is the same folder save run by the Live timer, did the same and said "✓ Saved
  to the shared folder automatically". U13 kept Brad's own record consistent but not Bob's copy. Now every folder save
  reads the folder's copy again after its last wait, just before it writes. Unless that copy is still, byte for byte, the
  one it read (or there is still none), nothing is written in its place. Bob's copy stays the folder's copy, Brad's work
  stays on screen, not saved, and the copy the save read stays in the folder's history. A copy that landed meanwhile is the
  clash, said with who saved it and when, with the same two choices. A copy gone or unreadable is said as such. If the
  board was moved to another year meanwhile, it is said with who saved it and when but no choice is offered. The stopped
  save takes back its pen line and puts the board's stamp back, so the header still says when it was last saved and by
  whom, not when the stopped save began. Both are put back on the working plan, even when a locked view was put on screen
  during the save.
  - **What users may see:** in that race, instead of "✅ Saved": "⛔ Bob saved O&M FY27 to the shared folder just now,
    after the copy you are working from. Their copy landed while your save was under way, and your save stopped before
    writing over it. Load theirs (your work is kept aside, and one click puts it back) · Save yours over theirs (theirs is
    kept in the folder’s history)." For the Live autosave, the refresh that follows it in the same tick then says, as it
    already did when Bob's copy was there before the autosave read the folder: "⚠ Bob saved O&M to the shared folder just
    now, and you have unsaved changes. Nothing was replaced. Save yours, or reload to take theirs." If the folder's copy
    is gone or cannot be read just before the write: "⛔ Not saved. The shared folder’s copy of O&M FY27 is no longer
    there" (or "could not be read again just before it was to be written over — <the reason>") ". Nothing was written in
    its place: a save never writes over a copy it has not read. Your work is still here — 💾 Save again to read the
    folder afresh." If the board was moved to another year meanwhile, the same words, with "changed while this save was
    under way — Bob saved it just now" and no choices. Every folder save now reads the folder's copy twice.
  - **Test:** audit-import "v2.00 (U18) — a copy saved while a folder save is under way is never written over"
    (78 checks): Bob takes the pen and saves while Brad's save is held at its last wait, with Brad's work unsaved and with
    nothing unsaved (U13's second-writer case, held before the write instead of in it): refused, Bob's copy the folder's
    copy, Brad's work and the board's stamp as they were, the clash said word for word with both choices; the retry, Save
    yours over theirs (refused while Bob holds the pen, with Bob's copy kept in the history) then Take the pen (Brad's work
    lands; v1 and Bob's copy both in the history); Load theirs; the folder's copy removed, unreadable, or saved by Bob while
    the board moved to FY28; the folder's first copy landing at the save's read just before its write, and the same
    unreadable; a take-the-pen save stopped there takes its pen line back; the Live autosave held the same way; a
    take-the-pen save over Bob's copy with nothing typed, whose stamp still names Bob, in the header's tooltip too; a locked
    view put on screen during the held save, with nothing unsaved and with a take-the-pen save (once the view is left, the
    working plan's stamp, header, tooltip and journal say what happened); a copy rewritten during the save with the same
    stamp and other bytes; and three controls (no second writer: the save lands as before; Bob saves before Brad's save
    reads the folder: the existing clash, word for word; the same for the Live autosave). 46 checks fail on the board
    before the change; every control passes on both, except (7)'s hold, which that board cannot reach (it makes no read
    there).
  - **Mutations:** `v200-u18-recheck-gone`, `-first-copy-unchecked`, `-gone-written-in-place`, `-unreadable-written`,
    `-said-nothing-written`, `-pen-line-kept`, `-stamp-moved`, `-other-year-choices`, `-autosave-unchecked`,
    `-stamp-name-moved`, `-stamp-on-view`, `-pen-line-on-view`, `-other-year-unnamed` and `-stamp-compare`. Each is
    caught by the focused block. Full-suite sensitivity runs in the final-tree queue.
  - **Not covered:** a copy that lands while the write itself is being made (between its start and its close) is still
    written over: a file share has no atomic compare-and-write. U13's second-writer case holds Brad's save exactly there,
    and still sees Bob's copy written over. The window is now the write alone, no longer the history keeping before it. A
    save waiting for another tab's Web Lock (U20) is not changed by this. The stamp is put back in memory: a path that
    writes browser storage during the save without restamping (importing a cost estimate, for one) leaves the stopped
    save's stamp there until the next change is kept (found by reading code; not run). Under a locked view the clash's two
    buttons refuse until the view is left, as for any clash said there. A copy rewritten outside the board with its old
    stamp is refused like a landed copy and named as it names itself ("Brad saved … after the copy you are working from").
    The history-failure refusal (v1.97, item 79) still leaves the stamp moved, and under a locked view its pen line on the
    working plan, as before: its own finding.
