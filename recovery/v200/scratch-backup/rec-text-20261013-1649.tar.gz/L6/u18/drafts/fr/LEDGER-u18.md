# U18: ledger texts (fix round, 13 Oct; drafts; the lead commits; `<sha>` and `<time>` are placeholders)

This replaces `drafts/LEDGER-u18.md` (`64c47000`), which is superseded: its blobs, counts and "the board's stamp goes back
to what it was" were c1's, and that last was not true under a locked view (verify-money r1, MF1).

## 1. Text to append to the U18 row of the main table (`recovery/v200/UNRESOLVED-LEDGER.md`, the row beginning "| U18 |", its last cell)

 **Built on the lead's decision (12 Oct, under Brad's "Don't wait for me. Let's keep pressing throughout to get this next
version published.", about 5:30 PM ET), as its own commit: COMMITTED as `<sha>` (<time>)**: board `04be53ef`, audit-import
`c6e336f6`, mutate `57baa27d`, built on the base archive `7ee498a` (product `d66dd60`, board `fce8a391`). Every folder save
(the Live autosave's too) reads the folder's copy again after its last wait, just before it writes; unless that copy is
still, byte for byte, the one it read (or there is still none), nothing is written in its place. A copy that landed meanwhile
is the clash (who saved it and when; Load theirs, Save yours over theirs; under another year on screen, who and when without
the choices); a copy gone or unreadable is said as such. The stopped save takes its pen line back and puts the board's stamp
back on the working plan, also when a locked view was put on screen meanwhile. Reproduced first on the base
(`rec/L6/u18/probe`: Bob's take-the-pen save landing while Brad's save keeps its history copy is written over and is in no
copy in the folder, Brad's board says "✅ Saved"; controls pass). Reviewed (verify-money r1, verify-tests r1: sound with
issues); fixed in a fix round on 13 Oct (the stamp and pen line under a locked view; tests for the Live autosave, the
stamp's name, the locked view and the byte comparison; who and when for another year). Focused block 78 checks: 46 fail on
the base board, all pass after (3 fail on the first build); every control passes on both, except (7)'s hold, which the base
cannot reach. Fourteen mutations, each caught by the block. mcount 1342/1342 once (text). **Not covered (still open,
narrower):** a copy landing during the write itself (between its start and its close) is still written over -- a file share
has no atomic compare-and-write; U13's (2) holds the save exactly there. Full audit-import and full-suite sensitivity: in the
final-tree queue.

## 2. Text to append to the U18 row of the priority table (the row beginning "| U18 | P1 |", its disposition cell)

 **Built and committed as `<sha>` (<time>):** a copy that lands between the save's read and its write is no longer written
over, by a 💾 Save, a take-the-pen save or the Live autosave (the save stops, says the clash, keeps both). Still open,
narrower: a copy landing during the write itself.

## 3. "Unresolved after R1–R5" in NEXT-VERSION.md

As in the build's draft, with line references added. U18 has no line of its own there. It is named in two places, which this commit makes
partly stale. Suggested replacements (the lead decides; nothing in an existing check depends on these words):

- In the U13 entry's **Not covered** bullet (NEXT-VERSION.md line 726 at the base), replace
  "a copy another writer saves during the save is still written over and kept nowhere in the folder (U18);"
  with
  "a copy another writer saves during the save was still written over and kept nowhere in the folder (U18, built below: now
  only one that lands during the write itself);"
- In the **U13: built as its own commit** line of "Unresolved after R1–R5" (NEXT-VERSION.md lines 798–799 at the base; the
  text wraps after "U16–U18,"), replace
  "stay open in the ledger (U16–U18, U20)"
  with
  "stay open in the ledger (U16, U17, U20; U18 built, above, except a copy landing during the write itself)".
- Optionally add a line after the U14 line:
  "  - **U18: built as its own commit** (the lead's decision under Brad's \"keep pressing\", 12 Oct): a copy another writer
    saves while a folder save is under way is no longer written over, except one that lands during the write itself (above)."

## 4. Found in passing (for the lead; not built)

The history-failure refusal (v1.97, item 79) moves the board's stamp and does not put it back, and under a locked view its
pen line is taken out of the view's copy, not the working plan's (same root as verify-money r1's MF1; the `ms` argument
`writerJournalUndo` now takes would serve that call too). Read in code and reported by verify-money r1; not run by me, not
changed here: it is outside U18 and needs its own test.
