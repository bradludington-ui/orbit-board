# U18: ledger texts (drafts; the lead commits; `<sha>` and `<time>` are placeholders)

## 1. Text to append to the U18 row of the main table (`recovery/v200/UNRESOLVED-LEDGER.md`, the row beginning "| U18 |", its last cell)

 **Built on the lead's decision (12 Oct, under Brad's "Don't wait for me. Let's keep pressing throughout to get this next
version published.", about 5:30 PM ET), as its own commit: COMMITTED as `<sha>` (<time>)**: board `e3986f30`, audit-import
`329cf6e8`, mutate `fc364266`, built on the base archive `7ee498a` (product `d66dd60`, board `fce8a391`). The folder save
reads the folder's copy again after its last wait, just before it writes; unless that copy is still, byte for byte, the one it read (or there is still none),
nothing is written in its place. A copy that landed meanwhile is the clash (who saved it and when; Load theirs, Save yours over
theirs); a copy gone or unreadable is said as such; the board's stamp goes back to what it was. Reproduced first on the base
(`rec/L6/u18/probe`: Bob's take-the-pen save landing while Brad's save keeps its history copy is written over and is in no copy
in the folder, Brad's board says "✅ Saved"; controls pass). Focused block 58 checks: 37 fail on the base board, all
pass after; every control passes on both, except (7)'s hold, which the base cannot reach. Eight mutations, each caught by the
block. mcount 1336/1336 once (text). **Not covered (still open, narrower):** a copy landing during the write itself (between its
start and its close) is still written over -- a file share has no atomic compare-and-write; U13's (2) holds the save exactly
there. Full audit-import and full-suite sensitivity: in the final-tree queue.

## 2. Text to append to the U18 row of the priority table (the row beginning "| U18 | P1 |", its disposition cell)

 **Built and committed as `<sha>` (<time>):** a copy that lands between the save's read and its write is no longer written
over (the save stops, says the clash, keeps both). Still open, narrower: a copy landing during the write itself.

## 3. "Unresolved after R1–R5" in NEXT-VERSION.md

U18 has no line of its own there. It is named in two places, which this commit makes partly stale. Suggested replacements
(the lead decides; nothing in an existing check depends on these words):

- In the U13 entry's **Not covered** bullet, replace
  "a copy another writer saves during the save is still written over and kept nowhere in the folder (U18);"
  with
  "a copy another writer saves during the save was still written over and kept nowhere in the folder (U18, built below: now
  only one that lands during the write itself);"
- In the **U13: built as its own commit** line of "Unresolved after R1–R5", replace
  "stay open in the ledger (U16–U18, U20)"
  with
  "stay open in the ledger (U16, U17, U20; U18 built, above, except a copy landing during the write itself)".
- Optionally add a line after the U14 line:
  "  - **U18: built as its own commit** (the lead's decision under Brad's \"keep pressing\", 12 Oct): a copy another writer
    saves while a folder save is under way is no longer written over, except one that lands during the write itself (above)."
