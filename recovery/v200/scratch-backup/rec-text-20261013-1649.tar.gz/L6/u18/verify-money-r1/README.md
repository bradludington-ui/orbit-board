# U18 -- independent adversarial verification, round 1, LENS A (data loss and money)

Verifier's own directory. Nothing in /home/user/orbit-board or /home/user/orbit-ui was edited, staged, committed or pushed;
the builder's files were only read. mutate.mjs was read as TEXT only (mcount.py, mkmut.py), never imported or run.
The full audit-import / audit-board were not run (the lead's). No playwright, no Chromium.

## Resumed attempt

An earlier attempt of this same review began no later than 11:36 AM ET on 13 Oct (its first file, bin/region.py, is stamped then) (copies b0/ and c1/, probe 1 written) and was
stopped by the lead at about 11:45 AM ET. Its one run, v-F-u18-c1 (started 11:41:56 AM ET, PIDs 16216/16228/16230), has no
exit record: it is NOT counted and was re-run as v2-F-u18-c1. None of its PIDs was running when this attempt began (checked
with ps at 11:57 AM ET). Probe 1 (probe/V-cyc.mjs) was written then but never run; it was run in this attempt.

## Identities (git hash-object)

| what | blob |
|---|---|
| b0 board (= rec/L6/base, orbit-board 7ee498a, product d66dd60) | fce8a391bd8a248d5185e199d22190c1687eaea0 |
| c1 board (= builder's rec/L6/u18/c1, diff -rq clean) | e3986f30e6cb8ebd543c60c3c8d4c3361f36ec01 |
| c1 audit-import | 329cf6e89f0a602aaaccf53a07c1cf2bae34639c (base 4aba2506) |
| c1 mutate.mjs.txt | fc364266c7d4533c969eca1667799c889c2e97c4 (base cbc6defc) |
| audit-recon / audit-board / audit-other (both copies) | 529e36f7 / a7c575e5 / d89396b0 (unchanged) |
| fx board (c1 + the verifier's proposed must-fix, out/fx-board.diff) | 172c127b837839e0313f0af74de4d8506bb6aa99 |
| harness/F-u18.mjs (the U18 block, verbatim from c1's audit-import by bin/mkfocused-multi.py; differs from the builder's harness f2555f38 only in line 1's path) | e2b1889f2eaabfedb7b0f3141ab0336e8d17faac |
| harness/F-u13.mjs (the U13 block, verbatim, same way) | b07f7342e473ed3004b28b2efde49582202af48b |
| probe/V-cyc.mjs (probe 1, block probe/vblock.mjs.txt 6fe5516a) | abe3a914f96933ee40e64ef0f9bad2a0992315e5 |
| probe/V-p2.mjs (probe 2, block probe/vblock2.mjs.txt 1a72bb95) | fb4be80ac0886ade9f8f6bf6409d19cf0ff32f50 |
| probe/V-p3.mjs (probe 3, block probe/vblock3.mjs.txt 11d088f3) | eb310cb8a654e281f8812a7f29bb958782be3d7c |
| bin/runner.mjs / run.sh / frun.sh / mrun.sh | e835140a / 31597810 / bd1c12a0 / faa57bc7 |
| mutants (mkmut.py, text only, each find once): recheck-gone / stamp-moved / pen-line-kept / first-copy-unchecked | c17257f9 / ff042085 / f912d6d9 / 71b1e392 |

Every probe and harness boots the copy's own tools/export-audit/boot.mjs (9c4f49ad) after its runtime-encoding-shim.mjs
(6e2ce2e6); each log's IDS line records the board blob actually booted.

## What was checked, and what it showed

### The builder's claims, re-run independently

- The U18 block (58 checks), verbatim from c1's audit-import: ALL 58 PASS on c1; on the base, 37 FAIL and 21 pass. Every
  check marked CONTROL passes on the base except (7a)/(7b)'s hold (the base makes no read there), exactly as claimed.
  (v2-F-u18-c1, v2-F-u18-b0.)
- mcount, text only: base 1328/1328 once; c1 1336/1336 once; c1's mutate on the base board: exactly the 8 U18 ids missing.
- Four of the eight U18 mutants, made from the mutate TEXT by mkmut.py and run through the block: all caught, with the same
  failing counts the builder reported (recheck-gone 35, stamp-moved 4, pen-line-kept 1, first-copy-unchecked 3).
- The diffs to audit-import and mutate are additions only (0 removed lines); entries sit before the R3 line as required.
- The comparison the fix makes is right: it compares the bytes read just before the write with the bytes read at the top
  (curRaw.txt), so an A-B-A change (a copy put back byte for byte) is not a clash and loses nothing -- what is written over is
  byte-identical to a copy already kept in the history.

### Paths next to the change (data loss)

- Every caller of the folder save goes through the one changed function (_driveStorePushRun): 💾 Save (saveInPlace), the Live
  autosave (liveTick -> driveStorePush(true)), Publish now (driveStorePush(false)), Save yours over theirs
  (_driveResolveRun('mine') -> _driveStorePushRun) and Take the pen (takePen -> saveInPlace). The only write of the folder's
  copy is the one the re-read now guards (grep driveWrite: line 26950 on c1). The cost-estimate put-back already re-reads before
  its write (the pattern U18 follows); ↶ Put back (driveRestore) writes no copy of the board -- it loads one, and the next Save
  goes through the guarded write.
- THE AUTOSAVE ROUTE (not in the builder's block): probe 2 (W3) holds Brad's Live autosave at its history copy while Bob takes
  the pen. Base: BRAD-2 is written over BOB-2 and the board says "✓ Saved to the shared folder automatically". c1: BOB-2 stays the
  folder's copy, BRAD-2 stays on screen and in browser storage, nothing says "automatically"; the same tick's refresh then says
  "Bob saved O&M ... Nothing was replaced. Save yours, or reload to take theirs." -- exactly what the early clash (W3b, a control)
  says on both boards. So the fix also closes U18 on the autosave route.
- Save yours over theirs after a late clash (block (2)): refused while Bob holds the pen, Bob's copy kept in the history first,
  then Take the pen lands with v1 and Bob's copy both in the history. Load theirs (block (3)): Brad's work kept aside.

### Money and exports

- Nothing in the change touches a computation, a figure or an export: the stopped save leaves S (notes and allocations, in
  dollars) on screen and in browser storage exactly as typed (block (1), (3), (8); probe 2 W2/W3), and builds no new bytes.
  No exported product reads the refusal path.

### Words (principle 4) -- the must-fix

The builder's restore (stamp and pen line) acts on `MS`, the store on screen at the moment of refusal. A locked cycle view put on
screen while the save is under way (a route the board already supports and tests: v2.00 R3, "a save that lands under a locked
view") sets the working plan aside (_cycStash.MS) and puts a throwaway deep copy in `MS`. The restore then acts on the
throwaway copy; once the view is left, the working plan still carries:

- the stopped save's stamp: MS.ts = the time the stopped save began, MS.by = Brad. The header's "Saved <time>" and its tooltip
  "Saved <day time> by Brad" name a save that never happened (probe 2 W1: stamp 3,670 ms after v1 on c1, 0 on fx; probe 3: the
  visible header after a stopped save seven minutes after v1).
- for a take-the-pen save, the pen line: the working plan's journal says Brad took the pen from Bob, though the pen stayed with
  Bob (probe 2 W2: journal pen lines ["Bob","Brad"] on c1, ["Bob"] on fx). The journal travels in every later save and folder
  copy (pkgStrip keeps MS.jrnl), so the false line reaches everyone at Brad's next save.

Both are claims the builder makes in the code comment, in its own mutations (v200-u18-stamp-moved, v200-u18-pen-line-kept)
and in the NEXT-VERSION draft ("The board's header still says when it was last saved, not when the stopped save began"); both
are false on this route. On the base the same route writes over Bob's copy instead (probe 2 W1/W2 on b0), so this is new to the
refusal path the change adds.

Minimal fix (out/fx-board.diff, board 172c127b): capture the store with the stamp, and put both back on that store.

    -function writerJournalUndo(e){ try{ const j=MS.jrnl||[]; ...
    +// v2.00 (U18): `ms`, the store the line was added to -- the working plan, set aside while a locked view is on screen.
    +function writerJournalUndo(e, ms){ try{ const j=(ms||MS).jrnl||[]; ...
    -  const was={ts:MS.ts, by:MS.by};   // v2.00 (U18): put back if this save stops just before its write (below)
    +  const was={ms:MS, ts:MS.ts, by:MS.by};   // ... on this working plan even if a locked view has set it aside by then
    -      if(penLine) writerJournalUndo(penLine);
    -      if(MS.ts===wroteTs){ MS.ts=was.ts; MS.by=was.by; }
    +      if(penLine) writerJournalUndo(penLine, was.ms);
    +      if(was.ms.ts===wroteTs){ was.ms.ts=was.ts; was.ms.by=was.by; }

On fx: probe 2 W1/W2 and probe 3 (V) pass, and the builder's block still passes 58/58 (v-F-u18-fx-r2). Suggested test: a scenario
(9) in the U18 block built from probe 2's W1/W2 (probe/vblock2.mjs.txt), and a mutation that puts the restore back on `MS`
(find the two fx lines above, repl the two c1 lines) -- c1 itself is that mutant, and W1/W2 fail on it.

## Runs (every run of this attempt; times ET; each bounded by setsid -w timeout -k 10 600, lock checked first)

| label | start (ET) | exit | wall s | checks pass/total | board booted | log |
|---|---|---|---|---|---|---|
| v-cyc-c1 | 2026-10-13 12:03:37 | 1 | 26.7 | 3/11 | e3986f30 | logs/v-cyc-c1.log |
| v-cyc-b0 | 2026-10-13 12:04:04 | 1 | 31.2 | 3/11 | fce8a391 | logs/v-cyc-b0.log |
| v2-F-u18-c1 | 2026-10-13 12:03:36 | 0 | 79.4 | 58/58 | e3986f30 | logs/v2-F-u18-c1.log |
| v2-F-u18-b0 | 2026-10-13 12:04:56 | 1 | 109.2 | 21/58 | fce8a391 | logs/v2-F-u18-b0.log |
| v-p2-fx | 2026-10-13 12:07:36 | 1 | 2.7 |  | 172c127b | logs/v-p2-fx.log |
| v-F-u18-fx | 2026-10-13 12:07:39 | 1 | 1.8 |  | 172c127b | logs/v-F-u18-fx.log |
| v-p2-c1 | 2026-10-13 12:07:35 | 1 | 39.1 | 11/18 | e3986f30 | logs/v-p2-c1.log |
| v-p2-fx-r2 | 2026-10-13 12:07:54 | 1 | 42.9 | 14/18 | 172c127b | logs/v-p2-fx-r2.log |
| v-p2-b0 | 2026-10-13 12:08:14 | 1 | 50.6 | 7/18 | fce8a391 | logs/v-p2-b0.log |
| v-F-u18-fx-r2 | 2026-10-13 12:08:37 | 0 | 95.2 | 58/58 | 172c127b | logs/v-F-u18-fx-r2.log |
| m-recheck-gone | 2026-10-13 12:09:20 | 1 | 95.2 | 23/58 | c17257f9 | logs/m-recheck-gone.log |
| m-pen-line-kept | 2026-10-13 12:10:24 | 1 | 92.4 | 57/58 | f912d6d9 | logs/m-pen-line-kept.log |
| m-stamp-moved | 2026-10-13 12:10:55 | 1 | 91.8 | 54/58 | ff042085 | logs/m-stamp-moved.log |
| m-first-copy-unchecked | 2026-10-13 12:11:56 | 1 | 104.5 | 55/58 | 71b1e392 | logs/m-first-copy-unchecked.log |
| v-F-u13-c1 | 2026-10-13 12:12:27 | 0 | 112.1 | 71/71 | e3986f30 | logs/v-F-u13-c1.log |
| v-p3-c1 | 2026-10-13 12:13:41 | 1 | 39.3 | 3/6 | e3986f30 | logs/v-p3-c1.log |
| v-p3-fx | 2026-10-13 12:14:20 | 1 | 34.9 | 4/6 | 172c127b | logs/v-p3-fx.log |
| S-c1-boot-same | 2026-10-13 12:14:44 | 0 | 35.8 |  |  | logs/S-c1-boot-same.log |
| S-c1-audit-other | 2026-10-13 12:15:20 | 0 | 96.2 | all passed |  | logs/S-c1-audit-other.log |
| S-c1-npm-check | 2026-10-13 12:16:56 | 0 | 9.9 | all passed |  | logs/S-c1-npm-check.log |

Notes on the table:
- "checks pass/total" counts every chk() line in the run's SUITE_CHECKS file. The probes carry OBSERVE lines whose expected value
  is "(observed)": they always count as failures and only record what the board said (probe 1: 2 lines; probe 2: 4; probe 3: 2).
  Net of those: probe 2 c1 11/14 (W1 stamp, W2 journal, W2 stamp fail), fx 14/14, b0 7/14 (U18 itself, W1-W3); probe 3 c1 3/4
  ((V) header fails), fx 4/4.
- v-p2-fx and v-F-u18-fx (exit 1 in under 3 s) failed at module resolution -- h/fx had no node_modules link -- before any check
  ran; NOT counted. Re-run as v-p2-fx-r2 and v-F-u18-fx-r2 after adding the link.
- Probe 1 (v-cyc-*): two of its expectations were mine and wrong (see Minor); probe 2 supersedes it. Its observations stand.
- m-*: the builder's block (harness/F-u18.mjs, blob e2b1889f) against a mutant, BOARD set to mut/<id>.html (the runner asserts
  it; the booted blob is in the table). Failing counts: recheck-gone 35, stamp-moved 4, pen-line-kept 1, first-copy-unchecked 3
  -- each equal to the builder's out/m2-failing-checks.txt.
- S-c1-*: boot-same printed "every page, source, save and error list is identical either way"; audit-other "ALL CHECKS PASSED";
  npm run check "all checks passed". Run in clones/c1 (git clone --shared of orbit-board, checked out at 7ee498a, c1's board e3986f30 and audit-import
  329cf6e8 copied over; node_modules linked; never committed).
- mcount (python3 -I, text only, not in the table): out/mcount-c1.txt 1336/1336 once; out/mcount-b0.txt 1328/1328 once;
  out/mcount-c1mut-on-b0.txt 1328 once, missing exactly the 8 v200-u18-* ids. (out/mcount-b0mut-on-b0.json, 0 bytes, is a stray
  from the stopped attempt; out/v-F-u18-c1.checks.jsonl, 44 lines, is the stopped run's partial record; neither is counted.)

## PIDs (pids.txt, as recorded; only these were ever mine; none was killed in this attempt)

```
batch1 pid 16216 2026-10-13 11:41:56 EDT bash batch1.sh
16228 2026-10-13 11:41:56 EDT timeout run:v-F-u18-c1 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885
16230 2026-10-13 11:41:57 EDT node run:v-F-u18-c1 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f50
batch2 launcher 27149 2026-10-13 12:03:36 EDT
batch2 pid 27149 2026-10-13 12:03:36 EDT bash batch2.sh
27159 2026-10-13 12:03:36 EDT timeout run:v2-F-u18-c1 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-88
27161 2026-10-13 12:03:36 EDT node run:v2-F-u18-c1 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f5
batch3 launcher 27196 2026-10-13 12:03:37 EDT
batch3 pid 27196 2026-10-13 12:03:37 EDT bash batch3.sh
27205 2026-10-13 12:03:37 EDT timeout run:v-cyc-c1 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f5
27208 2026-10-13 12:03:38 EDT node run:v-cyc-c1 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b
27505 2026-10-13 12:04:04 EDT timeout run:v-cyc-b0 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f5
27508 2026-10-13 12:04:04 EDT node run:v-cyc-b0 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b
28406 2026-10-13 12:04:56 EDT timeout run:v2-F-u18-b0 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-88
28408 2026-10-13 12:04:56 EDT node run:v2-F-u18-b0 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f5
batch4 launcher 30056 2026-10-13 12:07:35 EDT
batch4 pid 30056 2026-10-13 12:07:35 EDT bash batch4.sh
30067 2026-10-13 12:07:35 EDT timeout run:v-p2-c1 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f50
30069 2026-10-13 12:07:35 EDT node run:v-p2-c1 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9
batch5 launcher 30095 2026-10-13 12:07:36 EDT
batch5 pid 30095 2026-10-13 12:07:36 EDT bash batch5.sh
30109 2026-10-13 12:07:36 EDT timeout run:v-p2-fx :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f50
30112 2026-10-13 12:07:37 EDT node run:v-p2-fx :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9
30194 2026-10-13 12:07:39 EDT timeout run:v-F-u18-fx :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885
30196 2026-10-13 12:07:39 EDT node run:v-F-u18-fx :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f50
batch5b launcher 30402 2026-10-13 12:07:54 EDT
batch5b pid 30402 2026-10-13 12:07:54 EDT bash batch5b.sh
30411 2026-10-13 12:07:54 EDT timeout run:v-p2-fx-r2 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885
30414 2026-10-13 12:07:54 EDT node run:v-p2-fx-r2 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f50
30611 2026-10-13 12:08:14 EDT timeout run:v-p2-b0 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f50
30613 2026-10-13 12:08:15 EDT node run:v-p2-b0 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9
30882 2026-10-13 12:08:37 EDT timeout run:v-F-u18-fx-r2 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-
30885 2026-10-13 12:08:37 EDT node run:v-F-u18-fx-r2 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885
batch6 launcher 31174 2026-10-13 12:09:20 EDT
batch6 pid 31174 2026-10-13 12:09:20 EDT bash batch6.sh
31184 2026-10-13 12:09:20 EDT timeout run:m-recheck-gone :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224
31188 2026-10-13 12:09:20 EDT node run:m-recheck-gone :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-88
batch7 launcher 31935 2026-10-13 12:10:23 EDT
batch7 pid 31935 2026-10-13 12:10:23 EDT bash batch7.sh
31945 2026-10-13 12:10:24 EDT timeout run:m-pen-line-kept :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-822
31947 2026-10-13 12:10:24 EDT node run:m-pen-line-kept :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-8
32369 2026-10-13 12:10:55 EDT timeout run:m-stamp-moved :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-
32371 2026-10-13 12:10:55 EDT node run:m-stamp-moved :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885
465 2026-10-13 12:11:56 EDT timeout run:m-first-copy-unchecked :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8
468 2026-10-13 12:11:56 EDT node run:m-first-copy-unchecked :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8
1105 2026-10-13 12:12:27 EDT timeout run:v-F-u13-c1 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f
1107 2026-10-13 12:12:27 EDT node run:v-F-u13-c1 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500
2138 2026-10-13 12:13:41 EDT timeout run:v-p3-c1 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500
2140 2026-10-13 12:13:41 EDT node run:v-p3-c1 :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b95
2822 2026-10-13 12:14:20 EDT timeout run:v-p3-fx :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500
2825 2026-10-13 12:14:20 EDT node run:v-p3-fx :: env SUITE_CHECKS=/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b95
batch8 launcher 3206 2026-10-13 12:14:44 EDT
batch8 pid 3206 2026-10-13 12:14:44 EDT bash batch8.sh
3213 2026-10-13 12:14:44 EDT timeout run:S-c1-boot-same :: node tools/export-audit/boot-same.mjs
3215 2026-10-13 12:14:44 EDT node run:S-c1-boot-same :: node tools/export-audit/boot-same.mjs
3603 2026-10-13 12:15:20 EDT timeout run:S-c1-audit-other :: node tools/export-audit/audit-other.mjs
3605 2026-10-13 12:15:20 EDT node run:S-c1-audit-other :: node tools/export-audit/audit-other.mjs
4620 2026-10-13 12:16:56 EDT timeout run:S-c1-npm-check :: npm run check
4622 2026-10-13 12:16:56 EDT npm run:S-c1-npm-check :: npm run check
```

## Should fix

1. TEST THE AUTOSAVE ROUTE. The block drives 💾 Save and Take the pen, never the Live autosave (liveTick -> driveStorePush(true)),
   the save a Live user makes most. Probe 2's W3 (with W3b as its control) fails on the base (BRAD-2 written over BOB-2, "✓ Saved
   to the shared folder automatically") and passes on c1. Adding it as a scenario costs one hold; probe/vblock2.mjs.txt has it.
2. THE OTHER-YEAR STOP SAYS NO NAME OR TIME. Block (6c): with the board moved to FY28 and Bob's copy landed, Brad is told only that
   the FY27 copy "changed while this save was under way". The lead's fix asked for who saved and when to be said; the builder rightly
   drops the two choices there (they act on the year on screen), but `now` is at hand, so "-- <b>Bob</b> saved it <age>" costs one
   clause. The words said are true; they are short of what was asked.
3. THE DRAFTS, once the must-fix lands: NEXT-VERSION's "The board's header still says when it was last saved, not when the stopped
   save began" and the ledger's "the board's stamp goes back to what it was" are false on c1 under a locked view (above). Keep the
   words and fix the board, or qualify them; either way the U18 block should carry the view case.

## Minor

- (7a): with no folder copy when the save read the folder, the late clash still says Bob saved "after the copy you are working
  from", though Brad worked from no folder copy. The same words come from the existing clash when nothing is recorded (base 0);
  pre-existing wording, not U18's.
- Under a locked view the late clash's two buttons refuse at once (cycBlock), and leaving the view replaces the line with "↩ Back on
  the working plan", so the clash is said again only at the next 💾 Save or refresh. Pre-existing for any line said under a view.
- The stamp is put back in memory only. A path that writes browser storage during the save without restamping (for example a cost
  estimate imported then: MS.spAce=key; persist(), line 14540) leaves the stopped save's stamp in storage until the next persist.
  By code reading only; not run.
- Pre-existing, outside U18: the v1.97 item-79 refusal (history copy not kept) leaves the stamp moved (the builder noted it) and,
  under a locked view, its pen line on the working plan -- the same root as the must-fix; the `ms` argument fixes that call too.
- Probe 1 (V-cyc) carried two wrong expectations of mine, not board defects: saveInPlace() resolves to undefined, not false; and
  Brad's later Take the pen correctly meets the existing clash (his base is Bob's earlier copy). Probe 2 corrects both.

## The lead's six principles, against c1

1. Never lose a copy: met for the window from the save's read to its re-read, on 💾 Save, Take the pen, Save yours over theirs and
   (probe 2 W3) the Live autosave: Bob's copy stays the head, Brad's work stays on screen and in browser storage, the copy read stays
   in the history. Residual, said in the drafts: a copy landing between the re-read and the write's close.
2. Refuse rather than guess: met -- any difference, a copy gone or unreadable, is a refusal.
3. Money and exports: untouched; no figure moves (dollars checked on screen and in storage).
4. Every word true after: NOT met under a locked view (must-fix); met otherwise.
5. Smallest change: +30 -1 in one function and one message; the must-fix adds 3 changed lines and 1 comment line.
6. Existing checks preserved: audit-import and mutate diffs are additions only; mcount 1336/1336 once; the U13 block 71/71 on c1;
   boot-same, audit-other and npm run check on c1 (see runs).

## What I did not do

- Did not run the full audit-import or audit-board (the lead's), audit-recon, audit-hostile, audit-inject, audit-ppt or legacy-fsrc
  (the builder ran them with exit records; the change is in one function those do not drive), or the U2 / folder blocks the builder
  re-ran. Did not re-run the builder's base probe (u18-probe.mjs); the block's 37 base failures reproduce the defect.
- Ran 4 of the 8 U18 mutants (recheck-gone, stamp-moved, pen-line-kept, first-copy-unchecked), not the other 4.
- Did not write the must-fix into any suite or mutate copy: fx/ is c1 + the board change only, to show the fix works and keeps the
  block at 58/58. No new mutation entry was inserted anywhere.
- Did not run Chromium or playwright. Did not touch orbit-board or orbit-ui; the scratch clone (clones/c1, orbit-board 7ee498a with
  c1's board and audit-import copied over) was never committed to.
