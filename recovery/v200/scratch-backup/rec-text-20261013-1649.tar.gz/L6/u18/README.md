# U18: a copy another writer saves during this board's folder save is never overwritten unseen

> **Fix round, 13 Oct 2026 (started 3:38 PM ET): see "Fix round" at the end.** The commit is now the copy `fr/c1` (board
> `04be53ef`, audit-import `c6e336f6`, mutate `57baa27d`), which supersedes `c1/` (`e3986f30`, `329cf6e8`, `fc364266`). The
> build record below is kept as it was; what the fix round supersedes in it is listed there. `c1/` is kept unchanged.

Builder's record for ORBIT v2.00 release track U18. **One commit is proposed. Nothing is committed or pushed.** The lead
commits. Nothing in `/home/user/orbit-board` or `/home/user/orbit-ui` was edited, staged or committed; orbit-board was only
read (`git log`, `git rev-parse`, the ledger) and cloned with `git clone --shared` into `clones/` (scratch; nothing committed
there).

Times are Eastern, each read with `TZ=America/New_York date`. This attempt started at 11:13 PM ET on Mon 12 Oct 2026.

**Resuming.** This directory did not exist when I started (checked 11:13 PM ET): no earlier builder's work for U18 was found
here, so nothing was kept from an earlier attempt and everything below was made fresh in this session. The tooling in `bin/`
(`run.sh`, `bx.sh`, `frun.sh`, `batch.sh`, `suites.sh`, `runner.mjs`, `mkfocused-multi.py`, `insert.py`, `fails.py`) was
copied from the sibling track `rec/L6/u20u30/bin/`; the shell scripts changed only in their `U=` line, the others are
byte-identical (blobs below).

## The commit

| # | subject | copy | board | audit-import | mutate (`mutate.mjs.txt`, text only) |
|---|---|---|---|---|---|
| base | `7ee498a` archive (product `d66dd60`, U14) | `b0/` (= `../base`, `cp -a`, `diff -rq` identical) | `fce8a391` | `4aba2506` | `cbc6defc` |
| 1 | v2.00 U18: a folder save never writes over a copy that landed while it was under way | `c1/` | `e3986f30` | `329cf6e8` | `fc364266` |

Full blobs: board `e3986f30e6cb8ebd543c60c3c8d4c3361f36ec01`, audit-import `329cf6e89f0a602aaaccf53a07c1cf2bae34639c`,
mutate `fc364266c7d4533c969eca1667799c889c2e97c4`. Every other file in `c1/` is byte-identical to the base (`diff -rq`):
audit-recon `529e36f7`, audit-board `a7c575e5`, audit-other `d89396b0`, package.json `7cf8186f`, NEXT-VERSION.md `65265c13`.
`c1/` was made with `cp -a` of the base, keeps the `node_modules` symlink, and is `u+w`. The board stays the empty template:
only code and comments changed.

Diffs against the base, in `diffs/`: `c1-board.diff` (`d7f62922`, +30 −1), `c1-audit-import.diff` (`cd04e467`, +255
non-blank lines, additions only: the block is inserted right after `// ==== end v2.00 (U13) ====`), `c1-mutate.diff`
(`5ead0ae6`, +25, additions only: before the line `  // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says
it saved the working plan.`). The suite block alone is `blocks/u18.mjs.txt` (`8a825722`); the entries alone are
`blocks/entries-u18.mjs.txt` (`81e008c6`). No existing line of any suite or of mutate.mjs is changed.

Suggested commit message:

```
v2.00 U18: a folder save never writes over a copy that landed while it was under way

The folder save read the folder's copy once, at its start, and wrote over whatever was there by the time it wrote. Bob took
the pen and saved while Brad's save was keeping the copy it had read in the history; Brad's save then wrote over Bob's copy,
which was then in no copy in the folder, and said Saved. The save now reads the folder's copy again after its last wait,
just before it writes, and writes nothing in its place unless it is still, byte for byte, the copy it read (or there is
still none): a copy that landed is the clash (who saved it and when; Load theirs, Save yours over theirs), a copy gone or
unreadable is said as such, and the board's stamp goes back to what it was. Not covered: a copy landing during the write
itself (a file share has no atomic compare-and-write).

audit-import: "v2.00 (U18) — a copy saved while a folder save is under way is never written over" (58 checks).
mutate: eight v200-u18-* entries, each caught by the block.
```

## What was wrong (reproduced on the base first)

`_driveStorePushRun` reads the folder's copy once (`driveStoreRead`, its top), checks it against the copy the work came
from, keeps it in the history (`snapKeep`: list the history, create and write a copy) and then writes (`driveWrite`). Every
wait between the read and the write is a window for another writer's save to land, and the write then replaces it unread.

Probe `probe/u18-probe.mjs` (`a30f1655`; W1H copied verbatim from the base suite, lines 3745–3813, as `probe/w1h.verbatim.txt`
`e771578d`), literal expectations, run on the base board `fce8a391`:

- **P1 (the defect).** Brad saves BRAD-1, $700 (v1, writer Brad). Bob loads v1 and types BOB-2, $650. Brad types BRAD-2, $720
  and presses 💾 Save, held at the close of its history copy (its last wait before writing). Bob takes the pen (✍), which saves
  BOB-2 at once. Brad's save is let go. **Observed on the base:** the folder's copy is BRAD-2/$720 by Brad, writer Brad; BOB-2
  is in no copy in the folder (history: only v1); Brad's board says "✅ Saved O&M FY27 to the shared folder — 5 KB. Everyone
  sees it on their next refresh." and is recorded saved. Contract checks K1–K4 FAIL; K5 (v1 in history) and the controls PASS
  (`logs/probe-base-P1.log`, `out/probe-base-P1.json`).
- **P2 (the write's own close, U13 (2)'s hold).** The same with Brad's save held inside the close of its main write: Bob's
  copy is written over. Pinned as a residual observation: identical on the base and on c1 (see Not covered).
- **C1 (control, no second writer)** and **C2 (control, Bob saves before Brad's save reads the folder: the existing clash,
  "… Nothing was written. Load theirs … · Save yours over theirs …", word for word)**: both PASS on the base.

On c1 (round-2 board `e3986f30`): P1 8/8, P2 4/4, C1 3/3, C2 3/3 (`logs/probe-c1r2-*.log`). P1's status on c1: "⛔ Bob saved
O&M FY27 to the shared folder just now, after the copy you are working from. Their copy landed while your save was under way,
and your save stopped before writing over it. Load theirs (your work is kept aside, and one click puts it back) · Save yours
over theirs (theirs is kept in the folder’s history)."; the history holds two copies of v1 (Brad's kept copy and Bob's).

## The change (`diffs/c1-board.diff`, in full)

```diff
--- a/prioritization-board-grid.html
+++ b/prioritization-board-grid.html
@@ -26896,6 +26896,7 @@
       +'Press ↻ Reconnect to load the folder’s copy, or import a board first.');
     render(); return false;
   }
+  const was={ts:MS.ts, by:MS.by};   // v2.00 (U18): put back if this save stops just before its write (below)
   MS.ts=Date.now(); MS.by=whoAmI();
   // THE BYTES, AND WHICH SAVE THEY ARE (v1.95, item 47): built once, here, before the write's first wait.
   const body=JSON.stringify(livePayload(fwriter)), wroteTs=MS.ts, gen=_saveGen;
@@ -26922,6 +26923,30 @@
         render(); return false;
       }
     }
+    // v2.00 (U18): A COPY THAT LANDED WHILE THIS SAVE WAS UNDER WAY IS NEVER WRITTEN OVER. The folder's copy was read once,
+    // at the top, and every wait since -- keeping it in the history above all -- is time for another writer's save to land:
+    // Bob took the pen and saved while Brad's save was keeping the history, and Brad's save then wrote over Bob's copy, which
+    // was then in no copy in the folder. So the folder's copy is read again here, after the last wait and just before the
+    // write. Unless it is still, byte for byte, the copy read at the top (or there is still none), nothing is written in its
+    // place: a copy that landed meanwhile is the clash, said with who saved it and when and the same two choices (said
+    // without them if the board has moved to another year meanwhile); a copy gone or unreadable now is said as such. Both
+    // copies stay -- theirs is the folder's copy, the work on screen is left as it is, not saved -- and the copy read at the
+    // top, if there was one, stays in the history. The board's own stamp, which the header shows as when it was saved and
+    // by whom, goes back to what it was unless something was typed meanwhile. Not covered: the write itself. A file share
+    // has no atomic compare-and-write, so a copy landing while this write is being made is still written over.
+    let now=null, why=''; const nowRaw={};
+    try{ now=await driveStoreRead(dir, ap, fy, nowRaw); }catch(e){ why=(e&&e.message)||String(e); }
+    if(why || (cur? (!now || nowRaw.txt!==curRaw.txt) : !!now)){
+      if(penLine) writerJournalUndo(penLine);
+      if(MS.ts===wroteTs){ MS.ts=was.ts; MS.by=was.by; }
+      if(now && MS.cur===fy) driveClashSay(now, 'late');
+      else setStat('⛔ <b>Not saved.</b> The shared folder’s copy of '+esc(APPN_LBL[ap]||ap)+' FY'+(fy%100)+' '
+        +(why? 'could not be read again just before it was to be written over — <b>'+esc(why)+'</b>'
+          : now? 'changed while this save was under way' : 'is no longer there')
+        +'. <b>Nothing was written in its place</b>: a save never writes over a copy it has not read. Your work is still here — '
+        +'💾 Save again to read the folder afresh.');
+      render(); return false;
+    }
     await driveWrite(dir, driveName(fy, ap), body);
   }catch(e){ if(penLine) writerJournalUndo(penLine); throw e; }
   if(kept) await snapPrune(dir, fy, ap, kept.name, true);
@@ -26954,11 +26979,15 @@
 // load theirs, with this browser's work kept aside; or save this one over theirs, with theirs kept in
 // the folder's history. The refusal this replaces said "Reload to take their copy" -- and a reload then
 // took the folder's newer time as the one the work came from, and the next Save wrote over them.
+// v2.00 (U18): `refused` 'late' -- their copy landed while a save was under way and was found just before its write. That
+// save stopped there, after keeping the copy it had read, if any, in the folder's history: it is not said that nothing was
+// written.
 function driveClashSay(j, refused){
   const ap=mySlug(), theirs=+((j&&j.store&&j.store.ts)||(j&&j.ts)||0);
   setStat('⛔ <b>'+esc((j&&j.by)||'someone')+'</b> saved '+esc(APPN_LBL[ap]||ap)+' FY'+(MS.cur%100)
     +' to the shared folder '+esc(liveAge(theirs))+', after the copy you are working from. '
-    +(refused? '<b>Nothing was written.</b> ' : 'What is on screen does not have their changes. ')
+    +(refused==='late'? 'Their copy landed while your save was under way, and <b>your save stopped before writing over it</b>. '
+      : refused? '<b>Nothing was written.</b> ' : 'What is on screen does not have their changes. ')
     +'<button type="button" class="nb lnk" onclick="driveResolve(\'theirs\')">Load theirs</button> '
     +'(your work is kept aside, and one click puts it back) · '
     +'<button type="button" class="nb lnk" onclick="driveResolve(\'mine\')">Save yours over theirs</button> '
```

## Decisions, and how each meets the lead's principles

1. **Never lose any copy.** The save writes nothing in the folder copy's place unless it is the copy the save read. In the
   race, Bob's copy stays the folder's copy; Brad's work stays on screen and in this browser's storage, unsaved; v1 (the copy
   the save read) stays in the history. The retry through the offered choices keeps all three: after Save yours over theirs
   (refused while Bob holds the pen, with Bob's copy force-kept in the history) and ✍ Take the pen, the folder's copy is
   BRAD-2 and the history holds both BRAD-1 and BOB-2 (block (2)). Load theirs keeps Brad's work aside (block (3)).
2. **Refuse rather than guess.** Any difference refuses: another copy, none where one was read, one where none was read, or a
   copy that cannot be read now. Nothing is merged or chosen automatically.
3. **Money and exports.** Untouched: when the copy is unchanged the save writes the same bytes as before; no computation or
   export path changed.
4. **Every word stays true.** (a) The existing clash says "Nothing was written." — false here, because this save has already
   written the copy it read into the history; so the late clash says "Their copy landed while your save was under way, and
   your save stopped before writing over it." (b) If the board moved to another year during the save, Load theirs and Save
   yours over theirs would act on the year on screen, not on the copy the save was for; so that case names FY27 and offers
   no choice. (c) The save moves the board's stamp (`MS.ts`, `MS.by`) before writing; the header shows it as "Saved <time>"
   (tooltip "Saved <time> by <name>"). Left moved, a refused save would make the header claim a save that never happened
   (this was found while building; see round 2 below), so it is put back unless something was typed meanwhile.
5. **Smallest change.** One re-read after the last wait, one condition, one refusal branch, one wording variant in
   `driveClashSay`, and the stamp kept and put back. The re-check is placed where the lead asked: after every wait, just
   before `driveWrite`.
6. **Existing checks preserved.** No existing line of any suite or of mutate.mjs is edited (additions only). No existing
   expectation encodes the old behaviour: U13's (2) scenario holds Brad's save inside the close of its main write, after the
   new re-check, so its expectations (Brad's save lands, BRAD-1 everywhere) are unchanged, and it still passes on c1 (F-u13,
   below). Its comment "(U18, open; not this block's)" stays true for that window (see Not covered); the lead may want to
   reword it, but I did not touch it.

Other decisions:

- **The comparison is on the bytes**, not the stamp: a copy laid out differently but with the same stamp is still "a copy it
  did not read". The existing item-79 scenario "a folder copy laid out differently" still passes (F-folderB).
- **The re-check is also made when the folder held nothing at the read** (the folder's first copy, block (7)). On the base
  there is no wait between that read and the write except the write itself, so the base cannot be held there (see the block
  results); the branch exists because the new read is itself a wait, and a copy found there must not be ignored.
- **The pen line is taken back** on refusal, as the existing history-failure refusal does (block (8)).
- **A history copy made by the refused save is left in place**, never removed: it is a copy of what the save read, and
  removing a file is never safer than keeping one.

## Round 2 (within this session, before any result was reported)

The first c1 board (`74e724aa`, `superseded/r1/c1-board.r1.diff`) did not put the board's stamp back. Reading the header code
(`saveStateShow`: "Saved " + `shortTime(MS.ts)`, tooltip "Saved … by `MS.by`") showed a refused save would leave the header
naming the refused save's start as the time saved. I stopped the batch that was running against that board (its PIDs were
recorded; `pids.txt` line marked STOPPED; `m1-*` runs are superseded and not counted), added the stamp restore, a scenario
(1b) with nothing unsaved (U13's second-writer case held at the last wait) and stamp/header checks, and the mutation
`v200-u18-stamp-moved`. All results below are for the round-2 board `e3986f30`. Superseded files are in `superseded/r1/`.
The block's (6c) scenario label was reworded once more (only its text; same checks) after `f3-*`; the final harness
`F-u18.mjs` (`f2555f38`) was used for every mutant run and for `f5-*`.

## The suite block (audit-import, 58 checks)

"v2.00 (U18) — a copy saved while a folder save is under way is never written over" (`blocks/u18.mjs.txt`), built in the
house style of the U2/U13 blocks (async wrapper, `bootMark()`/`bootRelease(__bm, keepBoards())`/`settleBoards()`, the
two-space `const name = '...';` line, `// ==== ...` markers), with W1H's folder and its `hold`/`failRead`/`hits` gates.
Every expected value is a literal; board helpers only read observed values; timestamps are compared as identities read from
the raw folder bytes. Checks per scenario (from `out/f5-F-u18-c1.checks.jsonl`, the final harness):

| scenario | checks | what |
|---|---|---|
| (1) Bob takes the pen and saves while Brad's save is held | 9 | refused; BOB-2 the folder's copy with its own time, one main write (Bob's); history = v1 only; Brad's BRAD-2 on screen, stored, unsaved, recorded against v1; stamp and header as before; the late clash word for word with both buttons; Bob's board saved against the head; a later refresh loads nothing |
| (2) the retry | 4 | Save yours over theirs asks, is refused (Bob holds the pen), keeps BOB-2 in the history; Take the pen asks naming Bob, lands BRAD-2 (writer Brad); Brad saved against it; history holds BRAD-1 and BOB-2 |
| (1b) nothing unsaved | 5 | U13's second-writer case held at the last wait: refused; BOB-2 head; Brad as he was (BRAD-1, saved, stamp = v1's time and "Brad", header unchanged); late clash word for word |
| (3) Load theirs | 5 | refused as (1); Load theirs: BOB-2 on screen, saved against the head; BRAD-2 kept aside |
| (4) CONTROL: no second writer | 3 | the save lands as before |
| (5) CONTROL: Bob saves before Brad's read | 6 | the existing clash word for word ("Nothing was written."); no history or main write by Brad's save |
| (6a) the copy removed / (6b) unreadable / (6c) changed while the board moved to FY28 | 4 each | nothing written in its place; v1 in history; each message word for word, no buttons; FY27 work unsaved |
| (7a) first copy lands at the read before the write / (7b) and cannot be read | 4 each | nothing written over BOB-1; Brad unsaved, nothing recorded; clash (both buttons) / unreadable message |
| (8) a take-the-pen save refused | 6 | BOB-3 head, writer still Bob; Bob's BOB-2 in history; journal's pen lines still only Bob's; BRAD-3 unsaved; BRAD-2 still kept; stamp as before; late clash |

(7a)'s status check matches the start and the end of the message rather than the whole: U30 (another track) changes the
middle phrase when nothing is recorded for the folder, and (7a) has nothing recorded.

## Runs

Every node run went through `bin/run.sh` (`setsid -w timeout -k 10 600`, the AUDIT_IMPORT_RUNNING lock checked before each
run; it was never present, so no run waited or was skipped), except one `node --check` of the probe (syntax only, under 1 s,
11:23 PM ET), noted in `logs/runs.txt`. Non-node helpers went through `bin/bx.sh` (same bound; `logs/bx.txt`). Every
timeout PID and its child are in `pids.txt` with the command; the background wrappers (`after-impl.sh`, `after-impl2.sh`,
`after-final.sh`, `batch.sh`, `suites.sh`) recorded their own PIDs and start nothing but bounded runs. The only processes I
stopped are the four recorded PIDs marked STOPPED in `pids.txt` (11:41 PM ET). Full list: `logs/runs.txt`.

### Results (round-2 board `e3986f30`; final harness `F-u18.mjs` `f2555f38`)

| what | base `b0` (`fce8a391`) | c1 (`e3986f30`) |
|---|---|---|
| U18 block, focused (`F-u18`, final: `f5-*`) | **37 of 58 fail**, 21 pass | **58/58 pass** |
| U18 block, earlier harness `41d2c33f` (`f3-*`; only (6c)'s label differs) | 37 fail, 21 pass (same verdict on every check) | 58/58 |
| probe P1 / P2 / C1 / C2 | 4/8 (K1–K4 fail) / 4/4 / 3/3 / 3/3 | 8/8 / 4/4 / 3/3 / 3/3 (`probe-c1r2-*`) |
| U13 block (`F-u13` `5260ce8c`) | 71/71 | 71/71 |
| both U2 blocks (`F-u2` `f465f7bc`) | 57/57 | 57/57 |
| `F-folderA` (`0927e961`; 11 folder/file-save scenarios) | 297/297 | 297/297 |
| `F-folderB` (`cc40835b`; 10 more, incl. item 79, R3, R4, R5) | 142/142 | 142/142 |
| boot-same, audit, audit-ppt, audit-other, audit-recon, legacy-fsrc, audit-hostile, audit-inject (scratch git clones) | all pass, exit 0 | all pass, exit 0 |
| `npm run check` (scratch git clone) | all checks passed | all checks passed |

The 21 checks that pass on the base are the setup and hold controls of every scenario, all of (4) and (5) (the two controls),
and (1)'s "the history holds v1 and nothing else" (true on the base too: there Bob's copy is never kept). Every other check
fails on the base. (7a)/(7b)'s hold control fails on the base because that board makes no read just before its write, so
the interleaving cannot be produced there; the harness then lets Bob's save through (it would otherwise wait for a gate
never reached) and the block fails without hanging (`f5-F-u18-b0`, 34.9 s).

`F-u13`, `F-u2`, `F-folderA` and `F-folderB` are built verbatim from c1's suite by `bin/mkfocused-multi.py` (the U13 and U2
blocks by their markers; the folder lists are the u20u30 builder's 21 scenarios that save or refresh through the folder or
file paths); those blocks are byte-identical in the base's and c1's suites, so the same harness ran on both boards.

### Mutants (each through `F-u18` `f2555f38`, BOARD set to the mutant; all caught)

| id | mutant blob | failing checks (of 58) | which |
|---|---|---|---|
| `v200-u18-recheck-gone` | `c17257f9` | 35 | (1), (2), (1b), (3), (6a–c), (7a–b), (8) |
| `v200-u18-first-copy-unchecked` | `71b1e392` | 3 | (7a) |
| `v200-u18-gone-written-in-place` | `3b2a43e9` | 3 | (6a) |
| `v200-u18-unreadable-written` | `f3f5224a` | 3 | (7b) |
| `v200-u18-said-nothing-written` | `33b37759` | 5 | the words in (1), (1b), (3), (7a), (8) |
| `v200-u18-pen-line-kept` | `f912d6d9` | 1 | (8)'s journal check |
| `v200-u18-stamp-moved` | `ff042085` | 4 | the stamp/header checks in (1), (1b), (3), (8) |
| `v200-u18-other-year-choices` | `e4725ada` | 1 | (6c)'s words ("⛔ Bob saved O&M FY28 …") |

Every failing check per mutant is in `out/m2-failing-checks.txt` (`8f171870`); full verdicts and values in
`out/m2-*.checks.jsonl`.

### Superseded runs (kept, not counted)

- `probe-c1-*`, `f1b-F-u18-c1`, `f1-F-u18-b0`, `m1-*`: round 1 (c1 board `74e724aa`, before the stamp restore). `m1-v200-u18-
  first-copy-unchecked` exit 143 is the run I stopped (recorded PIDs). Round 1's c1 passed its own block (50/50) and the base
  failed 32 of 50.
- `f1-F-u18-c1` exit 1 after 2.7 s: the harness folder had no `node_modules` link yet (`Cannot find package 'jsdom'`); fixed
  by linking `h/<copy>/node_modules`, then `f1b` ran.

### Every run

The suites ran in scratch clones: `clones/b0` and `clones/c1` are `git clone --shared /home/user/orbit-board` (HEAD `9dd0763`,
records-only commits after `7ee498a`; its board, audit-import and mutate.mjs equal the base's blobs) with the copy's board,
`tools/`, package.json, NEXT-VERSION.md and the shim copied over and a `node_modules` link. `git status` in `clones/c1` shows
only the board and audit-import modified, plus the untracked shim, link and `mutate.mjs.txt`; nothing was committed there.

| label | start (ET) | exit | wall s | log | result |
|---|---|---|---|---|---|
| 2026-10-12 23:23:11 EDT NOTE: one 'node --check probe/u18-probe.mjs' (syntax only, no execution; under 1 s) was run directly, not through run.sh; the lock file was absent at 23:16 ET and is absent now: No such file or directory | | | | | |
| probe-base-P1 | 2026-10-12 23:23:11 EDT | 0 | 6.9 | `logs/probe-base-P1.log` | SUMMARY P1 4/8 pass |
| probe-base-P2 | 2026-10-12 23:23:18 EDT | 0 | 11.3 | `logs/probe-base-P2.log` | SUMMARY P2 4/4 pass |
| probe-base-C1 | 2026-10-12 23:23:29 EDT | 0 | 10.9 | `logs/probe-base-C1.log` | SUMMARY C1 3/3 pass |
| probe-base-C2 | 2026-10-12 23:23:40 EDT | 0 | 11.8 | `logs/probe-base-C2.log` | SUMMARY C2 3/3 pass |
| probe-c1-P1 | 2026-10-12 23:25:58 EDT | 0 | 13.2 | `logs/probe-c1-P1.log` | SUMMARY P1 8/8 pass |
| probe-c1-P2 | 2026-10-12 23:26:11 EDT | 0 | 13.4 | `logs/probe-c1-P2.log` | SUMMARY P2 4/4 pass |
| probe-c1-C1 | 2026-10-12 23:26:25 EDT | 0 | 17.9 | `logs/probe-c1-C1.log` | SUMMARY C1 3/3 pass |
| probe-c1-C2 | 2026-10-12 23:26:43 EDT | 0 | 21.3 | `logs/probe-c1-C2.log` | SUMMARY C2 3/3 pass |
| f1-F-u18-c1 | 2026-10-12 23:32:17 EDT | 1 | 2.7 | `logs/f1-F-u18-c1.log` | Cannot find package |
| f1b-F-u18-c1 | 2026-10-12 23:32:32 EDT | 0 | 108.8 | `logs/f1b-F-u18-c1.log` | ALL CHECKS PASSED |
| f1-F-u18-b0 | 2026-10-12 23:34:26 EDT | 1 | 107.9 | `logs/f1-F-u18-b0.log` | 32 FAILING CHECK(S) |
| mutant batch m1 launched 2026-10-12 23:38:43 EDT | | | | | |
| m1-v200-u18-recheck-gone | 2026-10-12 23:38:44 EDT | 1 | 85.6 | `logs/m1-v200-u18-recheck-gone.log` | 30 FAILING CHECK(S) |
| m1-v200-u18-first-copy-unchecked | 2026-10-12 23:40:09 EDT | 143 | 42.2 | `logs/m1-v200-u18-first-copy-unchecked.log` |  |
| focused batch f3 launched 2026-10-12 23:43:47 EDT | | | | | |
| f3-F-u18-c1 | 2026-10-12 23:43:47 EDT | 0 | 75.6 | `logs/f3-F-u18-c1.log` | ALL CHECKS PASSED |
| f3-F-u18-b0 | 2026-10-12 23:45:02 EDT | 1 | 84.7 | `logs/f3-F-u18-b0.log` | 37 FAILING CHECK(S) |
| probe-c1r2-P1 | 2026-10-12 23:46:27 EDT | 0 | 21.2 | `logs/probe-c1r2-P1.log` | SUMMARY P1 8/8 pass |
| probe-c1r2-P2 | 2026-10-12 23:46:48 EDT | 0 | 23.5 | `logs/probe-c1r2-P2.log` | SUMMARY P2 4/4 pass |
| probe-c1r2-C1 | 2026-10-12 23:47:12 EDT | 0 | 21.9 | `logs/probe-c1r2-C1.log` | SUMMARY C1 3/3 pass |
| probe-c1r2-C2 | 2026-10-12 23:47:34 EDT | 0 | 21.2 | `logs/probe-c1r2-C2.log` | SUMMARY C2 3/3 pass |
| mutant batch m2 launched 2026-10-12 23:47:55 EDT | | | | | |
| m2-v200-u18-recheck-gone | 2026-10-12 23:47:55 EDT | 1 | 91.9 | `logs/m2-v200-u18-recheck-gone.log` | 35 FAILING CHECK(S) |
| m2-v200-u18-first-copy-unchecked | 2026-10-12 23:49:27 EDT | 1 | 88.6 | `logs/m2-v200-u18-first-copy-unchecked.log` | 3 FAILING CHECK(S) |
| m2-v200-u18-gone-written-in-place | 2026-10-12 23:50:56 EDT | 1 | 103.6 | `logs/m2-v200-u18-gone-written-in-place.log` | 3 FAILING CHECK(S) |
| m2-v200-u18-unreadable-written | 2026-10-12 23:52:40 EDT | 1 | 109.6 | `logs/m2-v200-u18-unreadable-written.log` | 3 FAILING CHECK(S) |
| m2-v200-u18-said-nothing-written | 2026-10-12 23:54:29 EDT | 1 | 82.6 | `logs/m2-v200-u18-said-nothing-written.log` | 5 FAILING CHECK(S) |
| m2-v200-u18-pen-line-kept | 2026-10-12 23:55:52 EDT | 1 | 75.5 | `logs/m2-v200-u18-pen-line-kept.log` | 1 FAILING CHECK(S) |
| m2-v200-u18-stamp-moved | 2026-10-12 23:57:08 EDT | 1 | 68.6 | `logs/m2-v200-u18-stamp-moved.log` | 4 FAILING CHECK(S) |
| m2-v200-u18-other-year-choices | 2026-10-12 23:58:16 EDT | 1 | 65.3 | `logs/m2-v200-u18-other-year-choices.log` | 1 FAILING CHECK(S) |
| focused batch f4 launched 2026-10-12 23:59:22 EDT | | | | | |
| f4-F-u13-b0 | 2026-10-12 23:59:22 EDT | 0 | 58.5 | `logs/f4-F-u13-b0.log` | ALL CHECKS PASSED |
| f4-F-u13-c1 | 2026-10-13 00:00:20 EDT | 0 | 52.2 | `logs/f4-F-u13-c1.log` | ALL CHECKS PASSED |
| f4-F-u2-b0 | 2026-10-13 00:01:13 EDT | 0 | 75.3 | `logs/f4-F-u2-b0.log` | ALL CHECKS PASSED |
| f4-F-u2-c1 | 2026-10-13 00:02:28 EDT | 0 | 40.1 | `logs/f4-F-u2-c1.log` | ALL CHECKS PASSED |
| f4-F-folderA-b0 | 2026-10-13 00:03:08 EDT | 0 | 99.6 | `logs/f4-F-folderA-b0.log` | ALL CHECKS PASSED |
| f4-F-folderA-c1 | 2026-10-13 00:04:48 EDT | 0 | 106.1 | `logs/f4-F-folderA-c1.log` | ALL CHECKS PASSED |
| f4-F-folderB-b0 | 2026-10-13 00:06:34 EDT | 0 | 254.6 | `logs/f4-F-folderB-b0.log` | ALL CHECKS PASSED |
| f4-F-folderB-c1 | 2026-10-13 00:10:49 EDT | 0 | 229.0 | `logs/f4-F-folderB-c1.log` | ALL CHECKS PASSED |
| focused batch f5 launched 2026-10-13 00:14:51 EDT | | | | | |
| f5-F-u18-c1 | 2026-10-13 00:14:51 EDT | 0 | 30.0 | `logs/f5-F-u18-c1.log` | ALL CHECKS PASSED |
| f5-F-u18-b0 | 2026-10-13 00:15:21 EDT | 1 | 34.9 | `logs/f5-F-u18-b0.log` | 37 FAILING CHECK(S) |
| suites launched 2026-10-13 00:15:56 EDT | | | | | |
| S-b0-boot-same | 2026-10-13 00:15:56 EDT | 0 | 12.5 | `logs/S-b0-boot-same.log` |  |
| S-b0-audit | 2026-10-13 00:16:08 EDT | 0 | 15.9 | `logs/S-b0-audit.log` | ALL CHECKS PASSED |
| S-b0-audit-ppt | 2026-10-13 00:16:24 EDT | 0 | 8.1 | `logs/S-b0-audit-ppt.log` | ALL CHECKS PASSED |
| S-b0-audit-other | 2026-10-13 00:16:32 EDT | 0 | 47.3 | `logs/S-b0-audit-other.log` | ALL CHECKS PASSED |
| S-b0-audit-recon | 2026-10-13 00:17:20 EDT | 0 | 175.4 | `logs/S-b0-audit-recon.log` | ALL CHECKS PASSED |
| S-b0-legacy-fsrc | 2026-10-13 00:20:15 EDT | 0 | 5.1 | `logs/S-b0-legacy-fsrc.log` |  |
| S-b0-audit-hostile | 2026-10-13 00:20:21 EDT | 0 | 72.1 | `logs/S-b0-audit-hostile.log` | ALL CHECKS PASSED |
| S-b0-audit-inject | 2026-10-13 00:21:33 EDT | 0 | 10.7 | `logs/S-b0-audit-inject.log` | ALL CHECKS PASSED |
| S-b0-npm-check | 2026-10-13 00:21:43 EDT | 0 | 3.7 | `logs/S-b0-npm-check.log` | all checks passed |
| S-c1-boot-same | 2026-10-13 00:21:47 EDT | 0 | 13.0 | `logs/S-c1-boot-same.log` |  |
| S-c1-audit | 2026-10-13 00:22:00 EDT | 0 | 14.7 | `logs/S-c1-audit.log` | ALL CHECKS PASSED |
| S-c1-audit-ppt | 2026-10-13 00:22:15 EDT | 0 | 7.6 | `logs/S-c1-audit-ppt.log` | ALL CHECKS PASSED |
| S-c1-audit-other | 2026-10-13 00:22:23 EDT | 0 | 39.6 | `logs/S-c1-audit-other.log` | ALL CHECKS PASSED |
| S-c1-audit-recon | 2026-10-13 00:23:02 EDT | 0 | 124.5 | `logs/S-c1-audit-recon.log` | ALL CHECKS PASSED |
| S-c1-legacy-fsrc | 2026-10-13 00:25:07 EDT | 0 | 2.8 | `logs/S-c1-legacy-fsrc.log` |  |
| S-c1-audit-hostile | 2026-10-13 00:25:10 EDT | 0 | 54.4 | `logs/S-c1-audit-hostile.log` | ALL CHECKS PASSED |
| S-c1-audit-inject | 2026-10-13 00:26:04 EDT | 0 | 14.6 | `logs/S-c1-audit-inject.log` | ALL CHECKS PASSED |
| S-c1-npm-check | 2026-10-13 00:26:19 EDT | 0 | 3.8 | `logs/S-c1-npm-check.log` | all checks passed |


## For the lead: overlaps with other L6 tracks (read only; nothing of theirs was changed)

- **U4 (track `rec/L6/hold`, its c2):** it adds, at the same two places in `_driveStorePushRun`, a stamp capture before
  `MS.ts=Date.now(); MS.by=whoAmI();` (`const ts0=MS.ts, by0=MS.by;`) and a refusal right before
  `await driveWrite(dir, driveName(fy, ap), body);` that puts the pen line and the stamp back (`impMixedOn()`). The two
  commits will not apply cleanly one over the other. Suggested merge: one stamp capture (either name), then U18's re-read and
  comparison, then U4's hold check, then the write -- U18's re-read is itself a wait, so U4's "after the last wait" check
  belongs after it.
- **U30 (track `rec/L6/u20u30`, its c2):** it changes the line above U18's in `driveClashSay` ("after the copy you are
  working from" becomes conditional on a recorded base). The hunks are adjacent; a three-way merge may need a hand. U18's
  block checks the full words only where a base is recorded ((1), (1b), (3), (8)); (7a), with nothing recorded, checks the
  start and end of the message, so it holds with U30's wording too.
- **U13's block** says of its (2) scenario "(U18, open; not this block's)". With this commit that scenario's window (the
  write's own close) is still open, so the words stay true; the lead may still wish to reword them. Not changed here.

## mcount (text only, `rec/bin/mcount.py`, `python3 -I`)

- base mutate on the base board: 1328 entries, 1328 once (`out/mcount-base.json`).
- c1 mutate on the c1 board: 1336 entries, 1336 once, none missing, none multiple, none unparsed (`out/mcount-c1.json`); the
  eight U18 entries 1 each (`out/mcount-c1-u18.json`).
- c1 mutate on the base board: 1328 once, and exactly the eight U18 entries missing (`out/mcount-c1mut-on-base.json`).

mutate.mjs was never imported, executed or run; mutants were made by `rec/bin/mkmut.py` (text only) into `mut/`.

## Drafts (in `drafts/`)

- `drafts/NEXT-VERSION-u18.md` (`657a0da5`): the entry for NEXT-VERSION.md, under v2.00 after U14 (what was wrong, what
  changes, "What users may see", "Test", "Mutations", "Not covered").
- `drafts/LEDGER-u18.md` (`64c47000`): the text to append to U18's row in the main table and in the priority table (with
  `<sha>`/`<time>` placeholders), and, since U18 has no line of its own in "Unresolved after R1–R5", suggested rewordings of
  the two places that name it (U13's Not covered, and the U13 line of that list) plus an optional new line.

## Not covered

- **A copy that lands during the write itself** (between `getFileHandle(..., {create:true})` and the writable's `close()`)
  is still written over: a file share has no atomic compare-and-write. U13's (2) scenario and probe P2 hold Brad's save
  exactly there; both still show Bob's copy written over, on c1 as on the base. The window is now the write alone, no longer
  the history keeping before it.
- A save waiting for another tab's Web Lock (U20) is unchanged by this.
- After a late refusal with nothing unsaved (1b), a later Live refresh may load Bob's newer copy quietly (existing behaviour,
  as after the existing clash); the clash line then stays on screen. Brad's copy is v1, in the history. Not changed here.
- Found in passing, by code only (not run, not fixed): the existing history-failure refusal (v1.97 item 79) also moves
  `MS.ts`/`MS.by` before refusing and does not put them back, so its header can say "Saved <time>" for a save that did not
  happen. Same shape as round 2 above; outside this finding.

## What I did not do

- Nothing in orbit-board or orbit-ui was edited, staged, committed or pushed; NEXT-VERSION.md and the ledger texts are drafts
  in `drafts/`.
- The full audit-import and audit-board were not run (the lead's). mutate.mjs was not imported, executed or run, not even to
  count. No `playwright install`; no Chromium run (no layout change: the words are the status line).
- The clones' `tools/export-audit/mutate.mjs` is the base's; c1's mutate text sits beside it as `mutate.mjs.txt` (untracked),
  so nothing could execute it.
- No independent review of this build was made by me.

README closed at 12:27 AM ET on Tue 13 Oct 2026, after the last run (`S-c1-npm-check`, started 12:26:19 AM ET).


---

## Fix round (13 Oct 2026, started 3:38 PM ET)

The two independent reviews of the build (`verify-money-r1/`, `verify-tests-r1/`, both "sound with issues") found one
must-fix each, plus should-fixes. This round fixes all of them and the minors that are cheap and clearly right. It revises
the one proposed commit in a new cumulative copy, **`fr/c1/` = base + the revised U18 commit** (`cp -a` of the base, the
`node_modules` symlink kept, `u+w`). `c1/` is kept unchanged as the build's copy; nothing in it was edited.

**Resuming.** Checked at 3:38 PM ET: nothing in this directory was newer than the build's README (12:27 AM ET) except
`wfstate/` and the two reviewers' directories. No earlier attempt of this fix round had begun, so nothing was kept from one
and everything below was made in this session.

### What the reviews found, and what was done

| finding | what was done | principle |
|---|---|---|
| **MF1 (verify-money r1).** The stopped save put the pen line and the stamp back on `MS`, the store on screen. If a locked view was put on screen during the save, `MS` is the view's throwaway copy; once the view was left, the working plan said it was saved when the stopped save began, and on a take-the-pen save its journal said Brad took the pen. The journal travels in every later save. | The stopped save now holds the working plan it stamped by reference (`was.ms`) and puts the pen line and the stamp back on it. `writerJournalUndo(e, ms)` takes the store as an optional second argument; every other caller is unchanged. This is the reviewer's own minimal fix (`verify-money-r1/out/fx-board.diff`), with comments in house voice. New scenario (11a)/(11b) from the reviewer's probe 2 W1/W2, with (11a) also moving Brad's clock seven minutes on (the reviewer's probe 3), so a header naming the stopped save differs visibly. Two mutations: `-stamp-on-view` and `-pen-line-on-view`. | 4 |
| **MUST-FIX 1 (verify-tests r1) / SF1 (verify-money r1).** Nothing tested the Live autosave (`liveTick` → `driveStorePush(true)`, `quiet`), the folder save that runs most often. | Scenario (9), the autosave held at its history copy while Bob takes the pen (the reviewer's proposed (9), unchanged in substance), and (9b), the CONTROL where Bob takes the pen before the autosave reads the folder (verify-money's W3b). Mutation `-autosave-unchecked` (the reviewer's). | 1 |
| **S1 (verify-tests r1).** The name half of the stamp restore had no check. | Scenario (10) (the reviewer's proposed (10)): nothing typed, Brad takes the pen over Bob's copy, and Bob saves while it is held. Afterwards the stamp is still Bob's copy's time and Bob, and the tooltip says "by Bob". Mutation `-stamp-name-moved` (the reviewer's, with its find moved to the revised line). | 4 |
| **SF2 (verify-money r1).** With the board moved to another year, (6c) said only that the FY27 copy "changed while this save was under way". | It now says who saved it and when: "… changed while this save was under way — **Bob** saved it just now. …". It still offers no choice, since both choices act on the year on screen. Mutation `-other-year-unnamed`. | 4 |
| **SF3 (verify-money r1).** The drafts said the stamp goes back, which was false under a locked view. | True now (MF1). The drafts are rewritten in `drafts/fr/` and say so. | 4 |
| **M2 (verify-tests r1).** `refusedThen`'s stamp check put an observed value in the expected slot. | Changed to the house form `J([J(stamp(A.ev)) === J(st0), header(A.ev)])` against `J([true, 'Unsaved changes'])`, as (8) already did. | 6 |
| **M5 (verify-tests r1).** The byte-for-byte comparison was not pinned. | Scenario (12): during the hold, the folder's copy is rewritten with v1's own stamp and saver but another note. The save writes nothing over it. Mutation `-stamp-compare` (compares the stamp, not the bytes). The words said there are not checked; see Not covered. | 1, 2 |
| M3 (header minute resolution) | Covered by (11a)'s seven-minute clock move; (1b) is unchanged. | — |
| M4 (`vt-restore-always`, `vt-no-render` survive) | Not changed: I agree with the reviewer that both are equivalent or nearly so. | — |
| verify-money minor 1 ((7a) wording with no base) and minor 2 (buttons refuse under a view) | Not changed: both predate U18. Minor 1 is U30's. Minor 2 is noted in Not covered. | 5 |
| verify-money minor 3 (stamp put back in memory only) | Not changed; noted in Not covered. A `persist()` in the refusal would write browser storage on a path that writes none today. Under a locked view, `persist()` refuses and puts its own message over the clash. The route (an import during a held save) was found by reading only. | 5 |
| verify-money minor 4 (item-79 refusal has the same root) | Not changed: outside U18, and it would need its own test. Reported in `drafts/fr/LEDGER-u18.md` §4. The new `ms` argument would serve it. | 5 |

**How the round meets the lead's principles.** (1) The changes only widen what the stopped save keeps and checks; no
path writes more than before. The autosave, the same-stamp rewrite and the locked-view case each keep Bob's copy and
Brad's work, and each is now tested. (2) Nothing new is guessed: (12) refuses on any byte difference. (3) Money and exports
are untouched: no computation, payload or export path changed, and a save that lands writes the same bytes as before.
(4) The working plan's header, tooltip and journal after a stopped save under a view now say what happened, and (6c) says
who and when. (5) Board change against c1: +18 −10 lines, all in `writerJournalUndo` (an optional argument) and
`_driveStorePushRun`'s U18 lines; against the base: +39 −2. (6) No existing (base) check, fixture, expected value or
mutation entry is edited: the audit-import and mutate diffs against the base are additions only. The fix round changes the
build's own, not-yet-committed U18 lines, listed here:

| file:line (fr) | old (c1) | new (fr) | why |
|---|---|---|---|
| `tools/export-audit/audit-import.mjs:7884` (refusedThen) | `J([...stamp(A.ev), header(A.ev)]), J([...st0, 'Unsaved changes'])` | `J([J(stamp(A.ev)) === J(st0), header(A.ev)]), J([true, 'Unsaved changes'])` | M2: expected values are literals; the observed stamp is compared as an identity |
| `tools/export-audit/audit-import.mjs:7995` ((6c)) | `NOTSAVED('changed while this save was under way')` | `NOTSAVED('changed while this save was under way — Bob saved it just now')` | SF2: the board now says who and when |
| `tools/export-audit/mutate.mjs:4305` (`v200-u18-pen-line-kept` find) | `      if(penLine) writerJournalUndo(penLine);\n      if(MS.ts===wroteTs)` | `      if(penLine) writerJournalUndo(penLine, was.ms);\n      if(was.ms.ts===wroteTs)` | the board line it mutates changed (MF1); same mutation |
| `tools/export-audit/mutate.mjs:4308` (`v200-u18-stamp-moved` find) | `      if(MS.ts===wroteTs){ MS.ts=was.ts; MS.by=was.by; }\n` | `      if(was.ms.ts===wroteTs){ was.ms.ts=was.ts; was.ms.by=was.by; }\n` | the same |

The block's header comment and (6)'s comment also changed wording; no other line of the c1 block changed.

### The revised commit

| # | subject | copy | board | audit-import | mutate (`mutate.mjs.txt`, text only) |
|---|---|---|---|---|---|
| base | `7ee498a` archive (product `d66dd60`, U14) | `b0/` | `fce8a391` | `4aba2506` | `cbc6defc` |
| 1 (build, **superseded**) | v2.00 U18 … | `c1/` | `e3986f30` | `329cf6e8` | `fc364266` |
| **1 (fix round, current)** | v2.00 U18: a folder save never writes over a copy that landed while it was under way | **`fr/c1/`** | **`04be53ef`** | **`c6e336f6`** | **`57baa27d`** |

Full blobs: board `04be53efb880c3e076afac0bc7826eb7fcc55f47`, audit-import `c6e336f64f0e85055da7aeb5af1acc6eda6e5ebd`,
mutate `57baa27d04196377352f9e2043d98fc84d26c9ab`. Every other file in `fr/c1/` is byte-identical to the base (`diff -rq`):
audit-recon `529e36f7`, audit-board `a7c575e5`, audit-other `d89396b0`, package.json `7cf8186f`, NEXT-VERSION.md `65265c13`.
The board stays the empty template: only code and comments changed.

Diffs, in `diffs/fr/`:

| diff | blob | lines |
|---|---|---|
| `fr-board.diff` (base → fr) | `97afe5ce` | +39 −2 |
| `fr-audit-import.diff` (base → fr) | `34379ded` | +370 −0 (the block after `// ==== end v2.00 (U13) ====`) |
| `fr-mutate.diff` (base → fr) | `1b35e5e0` | +43 −0 (before the R3 line) |
| `c1-to-fr-board.diff` | `107ea2f0` | +18 −10 |
| `c1-to-fr-audit-import.diff` | `19dadfa4` | +121 −6 |
| `c1-to-fr-mutate.diff` | `0821a9db` | +21 −3 |

How it was made (text only; each step through `bin/bx.sh`, bounded, PIDs in `pids.txt`): `bin/edit-fr.py` (`eb03e3c5`) on
a copy of c1's board; `bin/edit-block-fr.py` (`69291f4a`) on a copy of c1's block, giving `blocks/u18.fr.mjs.txt`
(`8ef57ca7`); `bin/mkentries-fr.py` (`de5fa2c2`) giving `blocks/entries-u18.fr.mjs.txt` (`11f81071`, 14 entries, each
find taken from the fr board and asserted once); and `bin/rebuild-fr.sh` (`d26cd4ec`), which inserts both into the base's
files and cuts the focused harnesses verbatim from fr's suite.

The board change against c1, in full (`diffs/fr/c1-to-fr-board.diff`):

```diff
--- c1/prioritization-board-grid.html
+++ fr/prioritization-board-grid.html
@@ -2140,7 +2140,9 @@
   try{ jrnlAdd(e); }catch(x){}
   return e;
 }
-function writerJournalUndo(e){ try{ const j=MS.jrnl||[]; const i=j.lastIndexOf(e); if(i>=0) j.splice(i,1); }catch(x){} }
+// v2.00 (U18): `ms`, when given, is the store the line was added to: the working plan, which a locked view put on screen since
+// has set aside (MS is then the view's throwaway copy).
+function writerJournalUndo(e, ms){ try{ const j=(ms||MS).jrnl||[]; const i=j.lastIndexOf(e); if(i>=0) j.splice(i,1); }catch(x){} }
 // ── PMO COPY (sandbox) ────────────────────────────────────────────────────────────
 // A copy published for a programme office. Everything on screen still WORKS -- drag the order,
 // retype a value, watch the cutline move -- and persist() still writes to that reader's own browser
@@ -26896,7 +26898,9 @@
       +'Press ↻ Reconnect to load the folder’s copy, or import a board first.');
     render(); return false;
   }
-  const was={ts:MS.ts, by:MS.by};   // v2.00 (U18): put back if this save stops just before its write (below)
+  // v2.00 (U18): the working plan and its stamp, put back if this save stops just before its write (below). Held by reference:
+  // a locked view put on screen meanwhile sets the working plan aside, and MS is then the view's throwaway copy.
+  const was={ms:MS, ts:MS.ts, by:MS.by};
   MS.ts=Date.now(); MS.by=whoAmI();
   // THE BYTES, AND WHICH SAVE THEY ARE (v1.95, item 47): built once, here, before the write's first wait.
   const body=JSON.stringify(livePayload(fwriter)), wroteTs=MS.ts, gen=_saveGen;
@@ -26929,20 +26933,24 @@
     // was then in no copy in the folder. So the folder's copy is read again here, after the last wait and just before the
     // write. Unless it is still, byte for byte, the copy read at the top (or there is still none), nothing is written in its
     // place: a copy that landed meanwhile is the clash, said with who saved it and when and the same two choices (said
-    // without them if the board has moved to another year meanwhile); a copy gone or unreadable now is said as such. Both
-    // copies stay -- theirs is the folder's copy, the work on screen is left as it is, not saved -- and the copy read at the
-    // top, if there was one, stays in the history. The board's own stamp, which the header shows as when it was saved and
-    // by whom, goes back to what it was unless something was typed meanwhile. Not covered: the write itself. A file share
-    // has no atomic compare-and-write, so a copy landing while this write is being made is still written over.
+    // with who and when but without the choices if the board has moved to another year meanwhile); a copy gone or
+    // unreadable now is said as such. Both copies stay -- theirs is the folder's copy, the work on screen is left as it is,
+    // not saved -- and the copy read at the top, if there was one, stays in the history. The pen line goes, and the board's
+    // own stamp, which the header shows as when it was saved and by whom, goes back to what it was unless something was
+    // typed meanwhile: both on the working plan, even if a locked view is on screen now. This is every folder save, the
+    // Live autosave's too. Not covered: the write itself. A file share has no atomic compare-and-write, so a copy landing
+    // while this write is being made is still written over.
     let now=null, why=''; const nowRaw={};
     try{ now=await driveStoreRead(dir, ap, fy, nowRaw); }catch(e){ why=(e&&e.message)||String(e); }
     if(why || (cur? (!now || nowRaw.txt!==curRaw.txt) : !!now)){
-      if(penLine) writerJournalUndo(penLine);
-      if(MS.ts===wroteTs){ MS.ts=was.ts; MS.by=was.by; }
+      if(penLine) writerJournalUndo(penLine, was.ms);
+      if(was.ms.ts===wroteTs){ was.ms.ts=was.ts; was.ms.by=was.by; }
       if(now && MS.cur===fy) driveClashSay(now, 'late');
       else setStat('\u26d4 <b>Not saved.</b> The shared folder\u2019s copy of '+esc(APPN_LBL[ap]||ap)+' FY'+(fy%100)+' '
         +(why? 'could not be read again just before it was to be written over \u2014 <b>'+esc(why)+'</b>'
-          : now? 'changed while this save was under way' : 'is no longer there')
+          : now? 'changed while this save was under way \u2014 <b>'+esc(now.by||'someone')+'</b> saved it '
+            +esc(liveAge(+((now.store&&now.store.ts)||now.ts||0)))
+          : 'is no longer there')
         +'. <b>Nothing was written in its place</b>: a save never writes over a copy it has not read. Your work is still here \u2014 '
         +'\ud83d\udcbe Save again to read the folder afresh.');
       render(); return false;
```

Suggested commit message (replaces the build's):

```
v2.00 U18: a folder save never writes over a copy that landed while it was under way

The folder save read the folder's copy once, at its start, and wrote over whatever was there by the time it wrote. Bob took
the pen and saved while Brad's save was keeping the copy it had read in the history; Brad's save then wrote over Bob's copy,
which was then in no copy in the folder, and said Saved. The Live autosave, the same save run by the Live timer, did the
same. Every folder save now reads the folder's copy again after its last wait, just before it writes, and writes nothing in
its place unless it is still, byte for byte, the copy it read (or there is still none): a copy that landed is the clash
(who saved it and when; Load theirs, Save yours over theirs; with the board on another year, who and when without the
choices), a copy gone or unreadable is said as such. The stopped save takes its pen line back and puts the board's stamp
back on the working plan, also when a locked view was put on screen meanwhile. Not covered: a copy landing during the
write itself (a file share has no atomic compare-and-write).

audit-import: "v2.00 (U18) — a copy saved while a folder save is under way is never written over" (78 checks).
mutate: fourteen v200-u18-* entries, each caught by the block.
```

### The suite block (fix round: 78 checks; was 58)

Scenarios (1)–(8) are the build's, with the two expectation changes above. New:

| scenario | checks | what | base | c1 | fr |
|---|---|---|---|---|---|
| (9) the Live autosave held at its history copy; Bob takes the pen | 4 | setup and hold CONTROLs; BOB-2 still the folder's copy, one write (Bob's), history v1 only; BRAD-2 on screen, stored, unsaved against v1, stamp as it was, told Bob saved, nothing says Saved/automatically | 2 fail | pass | pass |
| (9b) CONTROL: Bob takes the pen before the autosave reads | 2 | no history copy, no write; BOB-2 the copy; Brad unsaved, stamp as it was, told Bob saved | pass | pass | pass |
| (10) nothing typed: Brad takes the pen over Bob's copy; Bob saves BOB-3 while it is held | 3 | CONTROLs; BOB-3 the copy, Brad's stamp is Bob's copy's time and "Bob", header unchanged, tooltip "by Bob." not "by Brad." | 1 fail | pass | pass |
| (11a) nothing unsaved; PB27 put on screen during the held save; Bob takes the pen | 3 | CONTROL (v1, PB27 locked); nothing written over BOB-2, view on screen; after leaving the view: saved, stamp v1's time and Brad, header and tooltip as before (clock moved on 7 min) | 2 fail | 1 fail (MF1) | pass |
| (11b) Brad takes the pen; PB27 put on screen during the held save; Bob saves | 4 | CONTROLs; nothing written over BOB-3, Bob still writer; after leaving the view: journal's pen lines `['Bob']`, stamp as it was, BRAD-3 unsaved | 2 fail | 1 fail (MF1) | pass |
| (12) the folder's copy rewritten with v1's stamp during the hold | 4 | CONTROLs; EDITED still the copy, no write, v1 in history; Brad unsaved against v1, stamp as it was, both choices offered | 2 fail | pass | pass |

On c1 the third failing check is (6c)'s words (SF2). Observed on c1 (`out/g1-F-u18fr-c1.checks.jsonl`): (11a) `[true,false,"Brad",false,false,true]`, meaning the stamp moved and the header and tooltip changed; (11b) `[["Bob","Brad"],false,"BRAD-3",730,true]`, meaning a false pen line and a moved stamp.
On the base (`out/g1-F-u18fr-b0.checks.jsonl`): (9) the autosave wrote BRAD-2 over BOB-2 (`["BRAD-2",720,"Brad","Brad",2,…]`)
and Brad was recorded saved; (10) Brad's take-the-pen save wrote BOB-2 over BOB-3 with writer Brad; (11a) BRAD-1 written
over BOB-2 under the view; (11b) BRAD-3 over BOB-3, journal `["Bob","Brad"]`; (12) BRAD-2 over EDITED.

### Runs (fix round)

Every node run went through `bin/run.sh` (`setsid -w timeout -k 10 600`, the AUDIT_IMPORT_RUNNING lock checked before each
run: it was never present, so no run waited or was skipped), in at most two lanes at once (focused/regression/suites in
one, mutants in the other; never a third node process of mine). Batches: `g1` (focused), `m3` (14 mutants), `r3`
(regression harnesses), `suites.sh fr` (scratch clone `clones/fr`: `git clone --shared /home/user/orbit-board`, HEAD
`4bbec77`, records-only commits after `7ee498a` whose board, audit-import, mutate.mjs, package.json and NEXT-VERSION.md
blobs equal the base's; fr's files copied over; `git status`: board and audit-import modified, the shim, the link and
`mutate.mjs.txt` untracked; nothing committed). Each wrapper ran under its own outer `timeout` and recorded its PID. The
fix-round PIDs follow the line `# ---- fix round (13 Oct 2026) ----` in `pids.txt`; the text-only `bx.sh` steps before it
(edit-fr, edit-block-fr, rebuild-fr, mcount, mkmut, clone-fr at 3:43–3:48 PM ET) are recorded just above that line and in
`logs/bx.txt`. I stopped no process in this round. Load average was 25–37 on 4 CPUs throughout, so wall times are longer
than in the build. No run hit its cap.

| label | start (ET) | exit | wall s | log | result |
|---|---|---|---|---|---|
| g1-F-u18fr-fr | 2026-10-13 15:47:53 | 0 | 129.3 | `logs/g1-F-u18fr-fr.log` | ALL CHECKS PASSED |
| g1-F-u18fr-b0 | 2026-10-13 15:50:03 | 1 | 165.3 | `logs/g1-F-u18fr-b0.log` | 46 FAILING CHECK(S) |
| m3-autosave-unchecked | 2026-10-13 15:50:28 | 1 | 157.7 | `logs/m3-autosave-unchecked.log` | 2 FAILING CHECK(S) |
| g1-F-u18fr-c1 | 2026-10-13 15:52:48 | 1 | 191.2 | `logs/g1-F-u18fr-c1.log` | 3 FAILING CHECK(S) |
| m3-stamp-name-moved | 2026-10-13 15:53:06 | 1 | 202.0 | `logs/m3-stamp-name-moved.log` | 1 FAILING CHECK(S) |
| r3-F-u13-fr | 2026-10-13 15:56:18 | 0 | 118.0 | `logs/r3-F-u13-fr.log` | ALL CHECKS PASSED |
| m3-stamp-on-view | 2026-10-13 15:56:28 | 1 | 165.5 | `logs/m3-stamp-on-view.log` | 2 FAILING CHECK(S) |
| r3-F-u2-fr | 2026-10-13 15:58:16 | 0 | 150.0 | `logs/r3-F-u2-fr.log` | ALL CHECKS PASSED |
| m3-pen-line-on-view | 2026-10-13 15:59:13 | 1 | 151.0 | `logs/m3-pen-line-on-view.log` | 1 FAILING CHECK(S) |
| m3-other-year-unnamed | 2026-10-13 16:01:45 | 1 | 199.6 | `logs/m3-other-year-unnamed.log` | 1 FAILING CHECK(S) |
| r3-F-folderA-fr | 2026-10-13 16:00:46 | 0 | 372.9 | `logs/r3-F-folderA-fr.log` | ALL CHECKS PASSED |
| m3-stamp-compare | 2026-10-13 16:05:04 | 1 | 167.2 | `logs/m3-stamp-compare.log` | 2 FAILING CHECK(S) |
| m3-recheck-gone | 2026-10-13 16:07:52 | 1 | 149.3 | `logs/m3-recheck-gone.log` | 44 FAILING CHECK(S) |
| m3-first-copy-unchecked | 2026-10-13 16:10:21 | 1 | 208.9 | `logs/m3-first-copy-unchecked.log` | 3 FAILING CHECK(S) |
| r3-F-folderB-fr | 2026-10-13 16:06:59 | 0 | 540.2 | `logs/r3-F-folderB-fr.log` | ALL CHECKS PASSED |
| S-fr-boot-same | 2026-10-13 16:16:08 | 0 | 50.6 | `logs/S-fr-boot-same.log` | every page, source, save and error list is identical either way |
| m3-gone-written-in-place | 2026-10-13 16:13:50 | 1 | 212.4 | `logs/m3-gone-written-in-place.log` | 3 FAILING CHECK(S) |
| S-fr-audit | 2026-10-13 16:16:59 | 0 | 54.9 | `logs/S-fr-audit.log` | ALL CHECKS PASSED |
| S-fr-audit-ppt | 2026-10-13 16:17:54 | 0 | 31.8 | `logs/S-fr-audit-ppt.log` | ALL CHECKS PASSED |
| m3-unreadable-written | 2026-10-13 16:17:23 | 1 | 204.2 | `logs/m3-unreadable-written.log` | 3 FAILING CHECK(S) |
| S-fr-audit-other | 2026-10-13 16:18:26 | 0 | 142.8 | `logs/S-fr-audit-other.log` | ALL CHECKS PASSED |
| m3-said-nothing-written | 2026-10-13 16:20:47 | 1 | 180.7 | `logs/m3-said-nothing-written.log` | 5 FAILING CHECK(S) |
| m3-pen-line-kept | 2026-10-13 16:23:48 | 1 | 190.7 | `logs/m3-pen-line-kept.log` | 2 FAILING CHECK(S) |
| S-fr-audit-recon | 2026-10-13 16:20:49 | 0 | 464.6 | `logs/S-fr-audit-recon.log` | ALL CHECKS PASSED |
| S-fr-legacy-fsrc | 2026-10-13 16:28:33 | 0 | 14.9 | `logs/S-fr-legacy-fsrc.log` | every legacy Force setting computes exactly as before |
| m3-stamp-moved | 2026-10-13 16:26:59 | 1 | 177.4 | `logs/m3-stamp-moved.log` | 9 FAILING CHECK(S) |
| S-fr-audit-hostile | 2026-10-13 16:28:48 | 0 | 233.9 | `logs/S-fr-audit-hostile.log` | ALL CHECKS PASSED |
| m3-other-year-choices | 2026-10-13 16:29:56 | 1 | 171.2 | `logs/m3-other-year-choices.log` | 1 FAILING CHECK(S) |
| S-fr-audit-inject | 2026-10-13 16:32:42 | 0 | 48.5 | `logs/S-fr-audit-inject.log` | ALL CHECKS PASSED |
| S-fr-npm-check | 2026-10-13 16:33:31 | 0 | 13.6 | `logs/S-fr-npm-check.log` | all checks passed |

### Results (fix round)

| what | base `b0` (`fce8a391`) | build c1 (`e3986f30`) | **fr (`04be53ef`)** |
|---|---|---|---|
| U18 block, focused (`F-u18fr`, harness `89817d47`) | 46 of 78 fail (32 pass: every control, setup and hold check, and (1)'s history check) | 3 of 78 fail ((6c) words, (11a), (11b)) | **78/78 pass** |
| U13 block (`F-u13`, body identical to the build's `5260ce8c`) | 71/71 (build, `f4-F-u13-b0`) | 71/71 (build) | **71/71** (`r3-F-u13-fr`) |
| both U2 blocks (`F-u2`, body identical to `f465f7bc`) | 57/57 (build) | 57/57 (build) | **57/57** |
| `F-folderA` (`0927e961`, 11 folder/file-save scenarios) | 297/297 (build) | 297/297 (build) | **297/297** |
| `F-folderB` (`cc40835b`, 10 more incl. item 79, R3, R4, R5) | 142/142 (build) | 142/142 (build) | **142/142** |
| boot-same, audit, audit-ppt, audit-other, audit-recon, legacy-fsrc, audit-hostile, audit-inject | all pass (build) | all pass (build) | **all pass, exit 0** |
| `npm run check` | all checks passed (build) | (build) | **all checks passed** |

The focused harnesses for U13/U2 cut from fr's suite differ from the build's only in their first comment line (the source
path); their bodies are byte-identical (`diff` of all lines after the first), because those blocks are unchanged.

**Every new test fails on the base and passes on fr**: each of (9), (10), (11a), (11b), (12) has failing checks on the base
(table above) and none on fr. (9b) is a control and passes on both, as it should.

**Mutants** (each the fr board with one entry applied by `rec/bin/mkmut.py`, text only, into `mut/fr/`; each through
`F-u18fr`; all caught). Every failing check is listed in `out/m3-failing-checks.txt` (`4d983cc8`):

| id | mutant blob | failing (of 78) | caught by | build (of 58) |
|---|---|---|---|---|
| `v200-u18-recheck-gone` | `6dbc9606` | 44 | (1), (2), (1b), (3), (6a–c), (7a–b), (8), (9), (10), (11a), (11b), (12) | 35 |
| `v200-u18-first-copy-unchecked` | `18edd3b5` | 3 | (7a) | 3 |
| `v200-u18-gone-written-in-place` | `74f01889` | 3 | (6a) | 3 |
| `v200-u18-unreadable-written` | `46560bb8` | 3 | (7b) | 3 |
| `v200-u18-said-nothing-written` | `9b16e86f` | 5 | the words in (1), (1b), (3), (7a), (8) | 5 |
| `v200-u18-pen-line-kept` | `3ce68f46` | 2 | (8), (11b) journal | 1 |
| `v200-u18-stamp-moved` | `666ac97d` | 9 | stamp/header checks in (1), (1b), (3), (8), (9), (10), (11a), (11b), (12) | 4 |
| `v200-u18-other-year-choices` | `59b70358` | 1 | (6c) words | 1 |
| `v200-u18-autosave-unchecked` (new) | `1928e15f` | 2 | (9) | — |
| `v200-u18-stamp-name-moved` (new) | `858c8952` | 1 | (10) | — |
| `v200-u18-stamp-on-view` (new) | `755faee0` | 2 | (11a), (11b) | — |
| `v200-u18-pen-line-on-view` (new) | `5463a035` | 1 | (11b) journal | — |
| `v200-u18-other-year-unnamed` (new) | `afdfd4dd` | 1 | (6c) words | — |
| `v200-u18-stamp-compare` (new) | `1edade88` | 2 | (12) | — |

**mcount** (text only, `rec/bin/mcount.py`, `python3 -I`): fr mutate on the fr board: 1342 entries, 1342 once, none
missing, multiple or unparsed (`out/mcount-fr.json`). fr mutate on the base board: 1328 once, exactly the 14 U18 ids
missing (`out/mcount-frmut-on-base.json`), so every base entry still matches the fr board exactly once. fr mutate on the
c1 board: 1336 once, the 6 entries whose finds use the fix-round text missing (`out/mcount-frmut-on-c1.json`).
mutate.mjs was never imported, executed or run.

### Drafts (fix round, in `drafts/fr/`)

- `NEXT-VERSION-u18.md` (`ac94f502`): the entry for NEXT-VERSION.md under v2.00, after U14, in the style of the U13/U1/U14
  entries: what was wrong, what changes, "What users may see", "Test" (78 checks, 46 fail on the base), "Mutations" (14),
  "Not covered".
- `LEDGER-u18.md` (`0e52bf7d`): §1 the text to append to U18's row in the main table, §2 to its row in the priority table
  (both with `<sha>`/`<time>` placeholders); §3 "Unresolved after R1–R5": U18 has no line of its own there, so it proposes
  rewordings of the two places that name it (U13's Not covered, NEXT-VERSION.md line 726, and the U13 line, lines 798–799)
  and an optional new line; §4 the item-79 refusal found in passing.

### Superseded by this round

- `c1/` and its blobs (`e3986f30`, `329cf6e8`, `fc364266`) as the proposed commit: superseded by `fr/c1/`. Kept unchanged.
- The build's README text above, wherever it gives c1's numbers (58 checks, 37 fail on the base, 8 mutations, mcount 1336) or
  says the stamp goes back without qualification. The build's results stay true of c1. Kept as written, and copied
  unchanged to `superseded/README.build.md` (`68d67581`).
- `drafts/NEXT-VERSION-u18.md` and `drafts/LEDGER-u18.md`: superseded by `drafts/fr/NEXT-VERSION-u18.md` (`ac94f502`)
  and `drafts/fr/LEDGER-u18.md` (`0e52bf7d`). Their line "The board's header still says when it was last saved, not when
  the stopped save began" and "the board's stamp goes back to what it was" were false under a locked view on c1 (SF3).
  They are true on fr.
- `blocks/u18.mjs.txt`, `blocks/entries-u18.mjs.txt`, `harness/F-u18.mjs`, `diffs/c1-*.diff`: the build's. The fix round's
  are `blocks/u18.fr.mjs.txt`, `blocks/entries-u18.fr.mjs.txt`, `harness/fr/F-u18fr.mjs`, `diffs/fr/*.diff`.

### For the lead: integration (read only; nothing of another track was changed)

- **U4 (track `rec/L6/hold`, its c2) has the same shape as MF1.** Its refusal before the write restores
  `if(MS.ts===wroteTs){ MS.ts=ts0; MS.by=by0; }` and `writerJournalUndo(penLine)` on `MS` (hold `c2` board lines
  26940–26941). If a locked view can be on screen when that hold refusal fires, it has the same false-stamp and false-pen-line
  result. When the two commits are merged, one capture (`was={ms:MS, ts, by}`) can serve both refusals, with both restoring
  on `was.ms`. Read only; not run.
- The build's merge notes still hold. U4 adds a stamp capture and a refusal at the same two places in `_driveStorePushRun`;
  suggested order: one capture, then U18's re-read and comparison, then U4's hold check, then the write. U30's
  `driveClashSay` change is next to U18's.

### Not covered (fix round)

The build's list stands, revised:

- **A copy landing during the write itself** is still written over: a file share has no atomic compare-and-write.
- **The stamp is put back in memory.** A path that writes browser storage during the save without restamping (for example a
  cost-estimate import) leaves the stopped save's stamp in browser storage until the next change is kept. Found by reading
  (verify-money minor 3); not run, not changed.
- **Under a locked view, the clash's two buttons refuse** until the view is left, and leaving says "↩ Back on the working
  plan", as for any line said under a view. This predates U18.
- **A copy rewritten outside the board with its old stamp** ((12)) is refused like a landed copy and named as it names
  itself: "⛔ Brad saved O&M FY27 … after the copy you are working from. …" Those words are not checked by (12). The board
  never writes such a copy itself, since it stamps every save.
- **The item-79 history-failure refusal** keeps its moved stamp and, under a view, its pen line on the working plan. This is
  outside U18; see `drafts/fr/LEDGER-u18.md` §4.
- A save waiting for another tab's Web Lock (U20) is unchanged.

### What I did not do (fix round)

- I did not commit, stage or push anything, and did not edit or stage anything in `/home/user/orbit-board` or
  `/home/user/orbit-ui`. orbit-board was only read (`git log`, `git rev-parse`, the ledger) and cloned with
  `git clone --shared` into `clones/fr` (nothing committed there).
- I did not run the full audit-import or audit-board; the lead runs them. I made no Chromium or playwright run (no layout
  change) and never ran `playwright install`. mutate.mjs was read as text only.
- I did not re-run the base or c1 through the U13/U2/folder harnesses or the other suites in this round. Those blocks and
  suites are unchanged and the build's base and c1 runs stand; fr was run through all of them.
- I did not re-run the reviewers' probes (`V-p2`, `V-p3`) themselves. Their W1/W2/W3/W3b and probe-3 routes are now block
  scenarios (9), (9b), (11a), (11b), run on base, c1 and fr.
- I did not fix minors 1–4 of verify-money r1 or M3/M4 of verify-tests r1 beyond what the table above says, and I did not
  edit U13's "(U18, open; not this block's)" comment: it is still true of the write's own window.
- This round has not been reviewed independently.

README closed at 4:36 PM ET on Tue 13 Oct 2026, after the last fix-round run (`S-fr-npm-check`, started 4:33:31 PM ET).
