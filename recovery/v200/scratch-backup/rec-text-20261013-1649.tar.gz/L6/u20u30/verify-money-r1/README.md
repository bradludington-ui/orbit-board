# U20U30: independent adversarial verification, round 1, LENS A (data loss and money)

This is the verifier's own directory. Nothing in `/home/user/orbit-board` or `/home/user/orbit-ui` was edited, staged,
committed or pushed (orbit-board was only read: `git log`, `git show HEAD:…`, `grep`). The builder's files were read only;
copies were made here. `tools/export-audit/mutate.mjs` was never imported or run: it was read as text only (`rec/bin/mkmut.py`,
`rec/bin/mcount.py`, `python3 -I`). `playwright install` was never run; Chromium is `/opt/pw-browsers/chromium`, with
playwright-core from the copy's `node_modules`. The full `audit-import` and `audit-board` were not run, because the lead runs
them alone.

**Sessions.** This review was done in two sessions, and both are recorded here:
- **Attempt 2:** 5:39 to about 6:02 AM ET, 13 Oct. Its own note says the attempt before it had not created this directory.
  It stopped at the usage limit while `M-c2-v200-u30-base-only-other-copy-G-u2030` was running (started 6:02:28 AM ET). That
  run has no exit record, so it was re-run.
- **Attempt 3 (this session):** resumed at 9:23 AM ET after the container restarted at 9:11 AM ET, so no earlier process was
  still running. Every run of attempt 2 that has an exit record ran on the same blobs as below, and was reused. The rest was
  re-run, and new probes were added.

**VERDICT: sound-with-issues.** There is one must-fix, and it is about words. It is not data loss and not money.

**What holds:**
- U20 and U30 close what they claim, on real product paths:
  - in jsdom: the builder's U20 and U30 blocks, and this review's probes (C), (D) and (E);
  - for U20, also in real Chromium (attempt 2, `rc-u20`).
- No copy is lost, and nothing is written over unasked on c1 or c2, on any route tried.
- c2 also closes a per-year form of U30 that neither the builder nor the checker ran (probe (D)). On base and c1 that route
  writes B's FY28 over Alice's FY28 copy without asking.
- No money, export or code path is touched.

**What does not hold (must-fix MF1):**
- U30 makes Save ask with nothing recorded. On a real route, a board file handed over that is newer than the folder's copy,
  the next two lines of that very question are false:
  - ↶ Put back says the folder's copy was "saved after it";
  - the kept-work refusal calls it "a newer copy".
- On base, the Save overwrote the folder's copy instead, so those lines were never reached on this route.
- A minimal fix is in `copies/c2fix2`, with its tests and mutants, all checked.

**Should-fix:**
- The ADOPT track rewrites the same `driveClashSay` line. The builder named the wrong function, and both tracks' mutation
  entries will stop matching once the other lands.
- Three draft overstatements, listed under "SF: the drafts" below.


## Identities (`git hash-object`)

| what | blob |
|---|---|
| base board (`../../base`, orbit-board HEAD board = 7ee498a / d66dd60 product) | `fce8a391bd8a248d5185e199d22190c1687eaea0` |
| builder c1 board (U20) = `copies/c1` | `83b87782710c2dee6ca2dbc030aabb22a92c9a0f` |
| builder c2 board (U20+U30) = `copies/c2` | `c42be8e71244fdbdaeb447278ab99edd94626a2c` |
| builder c1 audit-import / mutate.mjs.txt | `776c66800875f00ad05de7e0d8d3040860270cc6` / `6b4c83d64559b77fe1995c53bde366e0f94067e4` |
| builder c2 audit-import / mutate.mjs.txt | `e0d4186bbd7091b1a4dd006a62372be5d958af8a` / `54c7d9289939e04ba510deff3f93279505d61765` |
| audit-recon / audit-board / audit-other (unchanged in c1, c2) | `529e36f7` / `a7c575e5` / `d89396b0` |
| boot.mjs (all copies) | `9c4f49ad8cec537097bdf485458cfd2a09b06594` |
| attempt 2's word-fix copy `copies/c2fix` board (put-back line only) | `6557a3ccf64f1b6da7cb1a9dc627ab4042f08eaa` |
| **this session's proposed word fix `copies/c2fix2` board** (put-back line + occupied refusal) | `5f09cc34ff1d9b9e41120e0c9ec17a5afe6b631b` |
| proposal diff `diffs/proposal-c2fix2-words.diff` (c2 → c2fix2) | `ad5654aadd4c62847fd601a01758c3f63c521072` |
| focused harness G-u2030 (the U20 + U30 blocks, verbatim from c2's audit-import) | `cb8ef41c738bc41a5494a97b76aa09ecbef51e00` |
| focused harness G-all (U2 ×2, U13, U20, U30 blocks) / G-serial | `baaf1215…` / see `h/` |
| probe P-verify (attempt 2) / **P2-verify (this session)** | `db3e7ac9d33f69678da43aa7ab963709674dc323` / `910789b2afc0e1506cd62fff28b6201b22700091` |
| probe-2 block source `bin/probe2-block.mjs.txt` | `52e03d92d17416e06d6db0033ef8670a633a6c19` |
| proposed mutation entries `bin/own-entries2.mjs.txt` | `63464c6fcdf10881ba13895760421e8328e3e633` |
| real-Chromium script `bin/rc-u20.mjs` (attempt 2) | `7d798de010673070523352cad00c44e839e97af5` |
| builder F-folderA / F-folderB harnesses (copied verbatim) | `ab838a51a2ddca2f12ee7a712a5b2c1d76d8f0bc` / `739ff555252c80b774a3a678d765cc53b5168792` |
| runner.mjs | `e835140ac90d3fc9303ebb4a55af13ac6fb5d6ae` |

The diffs were checked: c1 and c2 audit-import and mutate diffs are **additions only** (0 removed lines). The board diffs are
exactly the builder's `diffs/c1-board.diff` and `diffs/c2-board.diff`.

## What the change does, read line by line

**Commit 1 (U20), `saveSerial`.** `_saveBusy++` now runs when a save is asked for, before `_saveChain.then(run, run)`, and
`p.then(done, done)` takes it back down once the save's promise `p` settles. `p` is the lock request's promise where there
is a lock (it settles after the callback's result settles and the lock has been let go), or `go()`'s otherwise. Read for
every exit:
- saved, refused inside `fn`, `fn` throwing: `p` settles, and `done` runs;
- the lock request rejected: `p` rejects, and `done` runs (`v200-u20-failed-stays-counted` is caught);
- `navigator.locks.request` throwing at once: the `try` falls back to `go()`, and `done` runs.

`done` is registered inside `saveSerial`, before any caller's `await p`, so a caller that resumes after `p` already sees the
count down. Nothing else reads `_saveBusy` (4 readers: the queued notice, ↶ Put back, and the two branches of
`driveStorePull`), and nothing waits for it to reach 0, so a longer count cannot deadlock. Refusals never lose a copy.

**Commit 2 (U30), `driveStorePull`.** The new line is `if(!base && theirs!==ours) return false;`, in the not-newer branch,
with no wait between reading `ours` and returning.
- Why it is sound: a folder copy stamped T was written by a push that stamped `MS.ts=T` and wrote `pkgStrip(MS)`. A screen
  stamped T therefore comes from that copy, and every edit (`save()`) restamps.
- Paths that put a copy on screen without restamping it are ↶ Put back (K keeps its own stamp) and putting an earlier copy
  back from history (H keeps its own). By the same argument, both are consistent: equal stamps still mean the same copy.
- The one gap is two unrelated boards stamped to the same millisecond. It is disclosed.

Every other place that records a copy not on screen is a deliberate choice that first force-keeps that copy in the history:
- `driveResolve('mine')`;
- putting an earlier copy back;
- ↶ Put back restoring the kept work's own record.

## Probes run in this session (P2-verify, `bin/probe2-block.mjs.txt`; expected values written by hand)

**(C) A handed-over file newer than the folder's copy.** This is a real route:
1. Alice saved F0 to the folder from her other machine.
2. She then saved a board file after it and handed the file over.
3. B opens that file in a browser with nothing recorded and connects with the opening's own `driveAutoConnect()`.
4. B types B-EDIT and presses 💾 Save.
5. B chooses Load theirs, then ↶ Put back.

Results:
- **On base and c1:** the Save writes B-EDIT over F0 with no question. This is the U30 harm on another route.
- **On c2:** the Save asks, in the new words, which are true.
- **But then on c2,** ↶ Put back says: "💾 Save will ask before it writes over the shared folder, which Alice saved after it."
  **That is false.** F0 was saved before the file the work came from (the premise check `tF0 < tN` passes) and before
  B-EDIT.

**(C2) The same route, with other work already kept aside.** Load theirs is refused, saying "⚠ Alice saved **a newer copy**
to the shared folder … so the newer copy was not loaded". **That is false:** F0 is older than the file the work came from. The
same line offers "discard it" for the kept work.

On base and c1, neither line is reached on this route, because the Save had already written over F0. **U30 makes both lines
reachable, through the very question it adds.** The builder reworded `driveClashSay` under principle 4 for this case, but not
the next two lines of the same flow.

**(D) Another year.** FY28 was saved by Alice's other machine and never loaded in B. B edits FY27, switches to FY28, presses
↻ Refresh now, then 💾 Save.
- **On base and c1:** the refresh records A28, and the Save writes B's rolled-forward FY28 ("B27-2") over Alice's A28 with no
  question.
- **On c2:** the refresh records nothing, and the Save asks.

**c2 closes this per-year form of U30 too.**

**(E) U20 with Load theirs as the waiting operation.** The builder lists this as not covered. Load theirs, pressed while tab
A's save holds the lock, waits.
- B counts it (`_saveBusy` 1), and ↶ Put back is refused and changes nothing.
- Once A lands, Load theirs runs: N on screen and recorded, B-EDIT kept aside, the count back to 0.

This passes on c1 and c2 and fails on base.

**Attempt 2's probes (reused; exit records on the same blobs):**
- **P-verify (A):** the put-back line in the BR-Wreal-like route, where B opened an older file and F0 was saved after it. It
  is false only if "it" is read as the edit, so it is ambiguous. That is why (C) was added.
- **P-verify (B):** the occupied refusal.
- **rc-u20 in real Chromium** (two and three tabs, the board's own `saveSerial` and Chromium's own Web Locks):
  - on c2, every behavioural check passes: W1–W7, including a tab closed while it held the lock (W6), a waiting save that
    throws (W5), and the board opened from `file://` (F1);
  - on base, the W* checks fail as expected;
  - the one check failing on both boards is the script's own environment check, "no request but the page". It fails because
    the board fetches `prio-state-om.json` (loadShared), so it is a harness assumption, not the board.

## Re-runs of the builder's evidence (independent; harnesses built verbatim from the copies' own audit-import)

**Focused harnesses**

| harness (checks) | base `fce8a391` | c1 `83b87782` | c2 `c42be8e7` |
|---|---|---|---|
| G-u2030 (locks 19 + U20 59 + U30 48 = 126) | 43 fail (U20 20, U30 23) | 21 fail (U30 only) | 126/126 |
| G-all (U2 ×2, U13, U20 ×2, U30 = 254) | not re-run | 21 fail (U30 only) | 254/254 |
| F-folderA + F-folderB (the builder's 21 other folder scenarios, 439) | not re-run (the builder: 439/439) | not re-run | 297/297 + 142/142 |

Every number agrees with the builder's.

**Mutants** (`mkmut.py`, text only), run through G-u2030 unless stated. Every one is caught:

| copy | mutant | failing checks |
|---|---|---|
| c2 | `v200-u20-wait-uncounted` | 15: F-u20's 14, plus U30 (4)'s count |
| c2 | `v200-u20-failed-stays-counted` | 2 |
| c2 | `v200-u30-base-whatever-on-screen` | 19 |
| c2 | `v200-u30-base-only-other-copy` | 21 |
| c2 | `v200-u30-unrecorded-said-after` | 2 |
| c2 | `v200-u30-recorded-said-unknown` | 1 |
| c2 | `v200-u13-base-while-saving` | 4 |
| c2 | `v200-u13-clash-while-saving` | 2 |
| c2 | `v200-u2-putback-while-saving` | 5 |
| c2 | `folder-mine-unforced` | 8 |
| c2 | own `vr1-u30-said-at-refresh` | 7 |
| c2 | own `vr1-u30-clash-words-other-year` | 1 |
| c1 | `v200-u20-wait-uncounted` | 43: c1 back to base |
| c1 | `v200-u20-failed-stays-counted` | 23: (6a) and (6b), plus c1's 21 U30 failures |
| c2 and base, via G-serial | `saves-not-serial` | 5 of 37 on each |

**mcount (text only):** base 1328/1328, c1 1330/1330, c2 1334/1334 entries match exactly once.

**Other suites, base and c2 (attempt 2):** audit, audit-other and audit-recon all pass, with the same output on both.

**npm run check:** passes on c2 and on c2fix2, each in a scratch git clone (`clones/`) with the copy's board and audit-import
over orbit-board HEAD `f40eded`. Nothing was committed there.

## Proposed corrections (for the lead; nothing applied outside this directory)

### MF1: the two lines after U30's question (board, commit 2)

The exact diff is `diffs/proposal-c2fix2-words.diff`; the board is `copies/c2fix2/…html` (`5f09cc34`).

```
keptPutBack():   const after=(k.meta.why!=='folder') || !!driveBaseOf(mySlug());
                 … +', which '+by+(after? ' saved after it.' : ' saved; this browser has no record of which copy there, if any, this work came from.')
keptOccupiedMsg(by, ts, from, unknown): 'saved '+(unknown? 'a copy' : 'a newer copy')+…, so '+(unknown? 'their' : 'the newer')+' copy was not loaded'
_driveResolveRun('theirs'):  keptOccupiedMsg(by, theirs, 'the shared folder', !driveBaseOf(ap))
```

- **Other callers.** The other four callers of `keptOccupiedMsg` pass three arguments, so their words are unchanged.
- **Where the record is read.** `driveBaseOf` in ↶ Put back reads the kept work's own record, which has just been put back
  into `_driveBase`.

**Test:** probe (C)/(C2) (`bin/probe2-block.mjs.txt`).

| board | P2-verify result |
|---|---|
| c2 | 2 of 18 fail (exactly the two word checks) |
| c2fix2 | 18 of 18 pass |

**Proposed mutation entries** (`bin/own-entries2.mjs.txt`; each find matches c2fix2 once). Each is caught by P2-verify on
c2fix2, with 1 failing check:
- `vr1-u30-putback-said-after`
- `vr1-u30-occupied-said-newer`

**Runs on c2fix2** (all exit 0):

| run | result |
|---|---|
| P2-verify | 18/18 |
| P-verify | 10/10, including attempt 2's (B) |
| G-u2030 | 126/126: every U20 and U30 check still passes |
| G-all | 254/254: U2 ×2, U13, U20, U30 |
| F-folderA / F-folderB | 297/297 and 142/142: the 21 other folder scenarios |
| npm run check (scratch git clone) | all checks passed |
| audit, audit-other | all checks passed |


### SF: the drafts

- **Builder's finding 4 ("the ADOPT track also edits driveStorePull") is not accurate.** The ADOPT board diff
  (`rec/L6/adopt/diffs/all-c3-vs-base.diff`) does not touch `driveStorePull`. It does change **the same line of
  `driveClashSay`** that U30 rewords: `(theirs>driveBaseOf(ap)? ', after …' : ', and that is not the copy you are working from. ')`.
  It also adds `loadedNotSaved`, which writes `_driveBase` with a loaded copy's own stamp. So:
  - the two commits conflict textually;
  - each track's mutation entry for that line (`v200-u30-unrecorded-said-after`, `v200-u30-recorded-said-unknown`, and
    ADOPT's U29 entry) stops matching once the other lands;
  - the merged wording needs three cases:
    - nothing recorded (U30): no record;
    - theirs later than the record: "after";
    - a record that is not theirs and not earlier (U29): "not the copy you are working from".
- **The U20 entry's "What users may see"** says a Connect says the folder's copy was not loaded. That is said only when the
  folder's copy is newer than the screen. When it is not newer, the Connect says nothing.
- **The U20 entry's "Not covered"** says "This board was not run in real Chromium". Attempt 2 of this review ran c2 in real
  Chromium (`bin/rc-u20.mjs`): two and three tabs, a tab closed while holding the lock, a waiting save that throws, and
  `file://`. All of that behaviour passes. The line can say so.
- **The "Unresolved" line for U30** says "No copy is written over unasked, and none is left only as a recent history copy".
  That is wider than U30 while U29 (another copy put on screen, then Save, in the ADOPT track) is open. Proposed: "In this
  case no copy is written over unasked, and none is left only as a recent history copy."
- **If MF1 is taken,** the U30 entry's "What users may see" and "Mutations" sections gain:
  - the ↶ Put back line, and the refusal for kept work, no longer say that theirs was saved after, or is newer, when nothing
    is recorded;
  - the two mutation ids.

## Minor (no change needed before commit)

- **U2's refusal words.** When what waits is a Load theirs, U2's refusal still says "a save was under way" (probe (E)). U13's
  words say "a save or Load theirs". Changing U2's words would change U2's existing `/a save was under way/` checks, so this
  is listed only.
- **A tab holding the lock across a dialog.** "Save yours over theirs" asks `confirm()` inside `saveSerial`. A tab with that
  dialog open holds 'orbit-save' and blocks saves in every other ORBIT tab of the profile, and with U20 their ↶ Put back and
  adoption too. Their words say "a save was under way" and do not say that the save is in another tab. No copy is lost. This
  sits next to O1 (the first waiting Save gives no sign), which the builder disclosed.
- **A folder copy with no stamp.** The push checks the record only when theirs is non-zero
  (`if(theirs && theirs!==driveBaseOf(ap, fy))`). A copy whose `store.ts` and `ts` are both missing is written over with no
  question, and kept only by the ordinary, possibly recent, history copy. This predates U20 and U30, and every copy this
  board writes is stamped. It is noted because the U30 wording ("never writes over a folder copy it has not shown …") is
  absolute.
- **A strict harness check.** `rc-u20`'s "no request but the page" check fails on both boards, because the board fetches
  `prio-state-om.json` (loadShared). That is the harness's assumption, not the board's behaviour.
- **U13 (3c).** It now passes through the U30 rule rather than U13's own guard; the builder disclosed this, and it was
  measured again here.

## The six decision principles, checked literally

1. **Never lose any copy.** Met for U20 and U30. No route found that loses a copy on c1 or c2.
   - Every route that used to write over a copy unasked now asks: U20 (1)–(4), U30 (1)–(4), probe (C) and probe (D).
   - Where Save yours over theirs is chosen, the folder's copy is force-kept as a spaced history copy.
   - Refusals (Put back, adoption) change nothing.
2. **Refuse or ask rather than guess.** Met: the guess "taken as the base, as it always was" is gone. It now asks.
3. **Money and exports.** Untouched. No money, export or code path changed. audit, audit-other and audit-recon pass with the
   same output on base and c2 (attempt 2's runs, reused).
4. **Every word stays true.** **Not met on the route U30 opens** (probes (C) and (C2)): the ↶ Put back line and the occupied
   refusal state an order of saves that is false. Also minor: U2's refusal says "a save was under way" when what waits is a
   Load theirs (probe (E)). And the drafts overstate in three places (below).
5. **Smallest change.** Met: commit 1 moves the count and adds 2 lines; commit 2 adds 1 line plus the one wording branch.
6. **Existing checks preserved.** Met:
   - additions only;
   - mcount gives base 1328/1328, c1 1330/1330 and c2 1334/1334;
   - U13 (3c)'s coverage moves to the new same-copy cases, as the builder disclosed;
   - `v200-u13-base-while-saving` and `v200-u13-clash-while-saving` are still caught on c2 (4 and 2 checks).

## Decisions, with reasons

- **The false words in (C)/(C2) are rated must-fix, not should-fix.** Principle 4 is the lead's rule for every track. The lines
  were already in the board before this change, but they were not reachable on this route: the base overwrote F0 instead.
  U30 makes them reachable through the very question it adds ("Load theirs … one click puts it back"). The builder's own
  commit takes principle 4 as the reason to reword `driveClashSay` for this case, and the next two lines of the same flow stay
  false.
  - The fix is small and tested: `copies/c2fix2`, `diffs/proposal-c2fix2-words.diff`.
  - The existing callers of `keptOccupiedMsg` keep their words, because the new argument defaults to the old wording.
- **Attempt 2's P-verify (A) is not used as evidence of falsity.** In that route the words can be read as true, because F0
  was saved after the file the work came from. (C) was written to remove the ambiguity.
- **The ADOPT overlap is rated should-fix**, a coordination point rather than a defect of this change. Neither track is
  committed: orbit-board HEAD `f40eded` still has board `fce8a391`.

## What I did not do

- I did not run the full audit-import or audit-board; by rule, the lead runs them alone.
- I did not run real Chromium against c1, or against c2fix2. Attempt 2 ran c2 and the base.
- I did not test Take the pen as the waiting operation, or Save yours over theirs as the waiting operation.
- I did not edit the builder's files, NEXT-VERSION.md or the ledger. The replacement texts proposed are below.
- I committed nothing and pushed nothing.
- Read-only shell commands (ls, cat, sed -n, grep, diff, git hash-object, git log/show on orbit-board) ran without the
  setsid/timeout bound.
- The batch drivers (`bin/batch3.sh`, `batch4.sh`, `batch5.sh`) are wrapper shells that run longer than 600 s. They are not
  under a 600 s bound, but every node, npm, python, cp and git run inside them is, through `bin/bx.sh`. The drivers' PIDs are
  recorded.

## Every run (label, start ET, exit, wall, log, PID; checks where a harness recorded them)

PIDs and commands are in `pids.txt`; the raw record is `logs/runs.txt`.

- Attempt 2's runs are from 5:41 to 6:02 AM ET. This session's started at 9:32 AM ET.
- `M-c2-v200-u30-base-only-other-copy-G-u2030` (6:02:28 AM ET) has no exit record. It was re-run at 9:32:48 AM ET.
- `P2-verify-c2fix2` (9:38:05 AM ET) failed to start, because `h/c2fix2` had no `node_modules` link yet. It was re-run as
  `P2-verify-c2fix2-2`.
- The `M-*` rows' failing-check counts are in `logs/mutants.txt`.
- Non-zero exits on base, c1 and mutants are expected: each is a defect check or a caught mutant.
- No run waited for `AUDIT_IMPORT_RUNNING`; it was never present. No run timed out.

| label | start (ET) | exit | wall | log | pid | checks |
|---|---|---|---|---|---|---|
| cp-base | 2026-10-13 5:41:39 AM ET | 0 | 0.0s | logs/cp-base.log | 16836 |  |
| cp-c1 | 2026-10-13 5:41:39 AM ET | 0 | 0.4s | logs/cp-c1.log | 16843 |  |
| cp-c2 | 2026-10-13 5:41:40 AM ET | 0 | 0.0s | logs/cp-c2.log | 16850 |  |
| rc-u20-base | 2026-10-13 5:48:13 AM ET | 1 | 4.6s | logs/rc-u20-base.log | 22059 |  |
| rc-u20-c2 | 2026-10-13 5:48:18 AM ET | 1 | 4.5s | logs/rc-u20-c2.log | 22202 |  |
| P-verify-base | 2026-10-13 5:50:56 AM ET | 1 | 0.9s | logs/P-verify-base.log | 24891 | 8/10 pass, 2 fail |
| P-verify-c2 | 2026-10-13 5:50:57 AM ET | 1 | 0.7s | logs/P-verify-c2.log | 24905 | 8/10 pass, 2 fail |
| P-verify-base-2 | 2026-10-13 5:51:08 AM ET | 1 | 9.0s | logs/P-verify-base.log | 25074 |  |
| P-verify-c2-2 | 2026-10-13 5:51:17 AM ET | 1 | 6.7s | logs/P-verify-c2.log | 25338 |  |
| S-c2-audit | 2026-10-13 5:52:07 AM ET | 0 | 8.1s | logs/S-c2-audit.log | 26748 |  |
| S-c2-audit-other | 2026-10-13 5:52:16 AM ET | 0 | 28.5s | logs/S-c2-audit-other.log | 26833 |  |
| S-c2-audit-recon | 2026-10-13 5:52:44 AM ET | 0 | 126.0s | logs/S-c2-audit-recon.log | 27006 |  |
| S-base-audit | 2026-10-13 5:54:50 AM ET | 0 | 10.7s | logs/S-base-audit.log | 28758 |  |
| S-base-audit-other | 2026-10-13 5:55:01 AM ET | 0 | 44.9s | logs/S-base-audit-other.log | 28951 |  |
| G-u2030-base | 2026-10-13 5:54:47 AM ET | 1 | 70.0s | logs/G-u2030-base.log | 28688 | 83/126 pass, 43 fail |
| mcount-base | 2026-10-13 5:56:32 AM ET | 0 | 3.7s | logs/mcount-base.log | 29874 |  |
| mcount-c1 | 2026-10-13 5:56:35 AM ET | 0 | 3.9s | logs/mcount-c1.log | 29926 |  |
| mcount-c2 | 2026-10-13 5:56:39 AM ET | 0 | 3.9s | logs/mcount-c2.log | 29949 |  |
| cp-c2fix | 2026-10-13 5:57:08 AM ET | 0 | 0.0s | logs/cp-c2fix.log | 30440 |  |
| G-u2030-c1 | 2026-10-13 5:55:57 AM ET | 1 | 81.3s | logs/G-u2030-c1.log | 29481 | 105/126 pass, 21 fail |
| P-verify-c2fix | 2026-10-13 5:57:14 AM ET | 1 | 14.8s | logs/P-verify-c2fix.log | 30586 | 9/10 pass, 1 fail |
| S-base-audit-recon | 2026-10-13 5:55:46 AM ET | 0 | 154.5s | logs/S-base-audit-recon.log | 29390 |  |
| G-u2030-c2 | 2026-10-13 5:57:18 AM ET | 0 | 70.6s | logs/G-u2030-c2.log | 30710 | 126/126 pass |
| P-verify-c1 | 2026-10-13 5:58:29 AM ET | 1 | 11.0s | logs/P-verify-c1.log | 31588 | 8/10 pass, 2 fail |
| mk-c2-v200-u20-wait-uncounted | 2026-10-13 5:58:40 AM ET | 0 | 0.2s | logs/mk-c2-v200-u20-wait-uncounted.log | 31771 |  |
| M-c2-v200-u20-wait-uncounted-G-u2030 | 2026-10-13 5:58:40 AM ET | 1 | 61.5s | logs/M-c2-v200-u20-wait-uncounted-G-u2030.log | 31779 | 111/126 pass, 15 fail |
| mk-c2-v200-u20-failed-stays-counted | 2026-10-13 5:59:42 AM ET | 0 | 0.5s | logs/mk-c2-v200-u20-failed-stays-counted.log | 32697 |  |
| M-c2-v200-u20-failed-stays-counted-G-u2030 | 2026-10-13 5:59:43 AM ET | 1 | 84.3s | logs/M-c2-v200-u20-failed-stays-counted-G-u2030.log | 32705 | 124/126 pass, 2 fail |
| mk-c2-v200-u30-base-whatever-on-screen | 2026-10-13 6:01:07 AM ET | 0 | 0.4s | logs/mk-c2-v200-u30-base-whatever-on-screen.log | 1419 |  |
| M-c2-v200-u30-base-whatever-on-screen-G-u2030 | 2026-10-13 6:01:08 AM ET | 1 | 79.4s | logs/M-c2-v200-u30-base-whatever-on-screen-G-u2030.log | 1427 | 107/126 pass, 19 fail |
| mk-c2-v200-u30-base-only-other-copy | 2026-10-13 6:02:27 AM ET | 0 | 0.3s | logs/mk-c2-v200-u30-base-only-other-copy.log | 1879 |  |
| mk-c2-v200-u30-base-only-other-copy | 2026-10-13 9:32:48 AM ET | 0 | 0.2s | logs/mk-c2-v200-u30-base-only-other-copy.log | 18406 |  |
| M-c2-v200-u30-base-only-other-copy-G-u2030 | 2026-10-13 9:32:48 AM ET | 1 | 64.7s | logs/M-c2-v200-u30-base-only-other-copy-G-u2030.log | 18418 | 105/126 pass, 21 fail |
| mk-c2-v200-u30-unrecorded-said-after | 2026-10-13 9:33:53 AM ET | 0 | 0.2s | logs/mk-c2-v200-u30-unrecorded-said-after.log | 18795 |  |
| M-c2-v200-u30-unrecorded-said-after-G-u2030 | 2026-10-13 9:33:54 AM ET | 1 | 67.4s | logs/M-c2-v200-u30-unrecorded-said-after-G-u2030.log | 18806 | 124/126 pass, 2 fail |
| mk-c2-v200-u30-recorded-said-unknown | 2026-10-13 9:35:01 AM ET | 0 | 0.3s | logs/mk-c2-v200-u30-recorded-said-unknown.log | 19519 |  |
| M-c2-v200-u30-recorded-said-unknown-G-u2030 | 2026-10-13 9:35:01 AM ET | 1 | 56.2s | logs/M-c2-v200-u30-recorded-said-unknown-G-u2030.log | 19527 | 125/126 pass, 1 fail |
| mk-c2-v200-u13-base-while-saving | 2026-10-13 9:35:58 AM ET | 0 | 0.1s | logs/mk-c2-v200-u13-base-while-saving.log | 20099 |  |
| M-c2-v200-u13-base-while-saving-G-u2030 | 2026-10-13 9:35:58 AM ET | 1 | 47.4s | logs/M-c2-v200-u13-base-while-saving-G-u2030.log | 20107 | 122/126 pass, 4 fail |
| mk-c2-v200-u13-clash-while-saving | 2026-10-13 9:36:45 AM ET | 0 | 0.2s | logs/mk-c2-v200-u13-clash-while-saving.log | 20904 |  |
| M-c2-v200-u13-clash-while-saving-G-u2030 | 2026-10-13 9:36:45 AM ET | 1 | 60.7s | logs/M-c2-v200-u13-clash-while-saving-G-u2030.log | 20912 | 124/126 pass, 2 fail |
| mk-c2-v200-u2-putback-while-saving | 2026-10-13 9:37:46 AM ET | 0 | 0.3s | logs/mk-c2-v200-u2-putback-while-saving.log | 21496 |  |
| P2-verify-c2 | 2026-10-13 9:37:35 AM ET | 1 | 23.9s | logs/P2-verify-c2.log | 21383 | 16/18 pass, 2 fail |
| P2-verify-c2fix2 | 2026-10-13 9:38:05 AM ET | 1 | 1.3s | logs/P2-verify-c2fix2.log | 21791 | 18/18 pass |
| P2-verify-base | 2026-10-13 9:38:06 AM ET | 1 | 26.1s | logs/P2-verify-base.log | 21848 | 4/18 pass, 14 fail |
| P2-verify-c1 | 2026-10-13 9:38:32 AM ET | 1 | 25.5s | logs/P2-verify-c1.log | 22123 | 7/18 pass, 11 fail |
| M-c2-v200-u2-putback-while-saving-G-u2030 | 2026-10-13 9:37:47 AM ET | 1 | 93.3s | logs/M-c2-v200-u2-putback-while-saving-G-u2030.log | 21513 | 121/126 pass, 5 fail |
| mk-c2-folder-mine-unforced | 2026-10-13 9:39:20 AM ET | 0 | 0.5s | logs/mk-c2-folder-mine-unforced.log | 22787 |  |
| P2-verify-c2fix2-2 | 2026-10-13 9:39:09 AM ET | 0 | 29.3s | logs/P2-verify-c2fix2.log | 22663 |  |
| M-c2-folder-mine-unforced-G-u2030 | 2026-10-13 9:39:21 AM ET | 1 | 111.0s | logs/M-c2-folder-mine-unforced-G-u2030.log | 22795 | 118/126 pass, 8 fail |
| mk-c2-vr1-u30-said-at-refresh | 2026-10-13 9:41:12 AM ET | 0 | 0.2s | logs/mk-c2-vr1-u30-said-at-refresh.log | 23883 |  |
| M-c2-vr1-u30-said-at-refresh-G-u2030 | 2026-10-13 9:41:12 AM ET | 1 | 78.3s | logs/M-c2-vr1-u30-said-at-refresh-G-u2030.log | 23896 | 119/126 pass, 7 fail |
| mk-c2-vr1-u30-clash-words-other-year | 2026-10-13 9:42:31 AM ET | 0 | 0.2s | logs/mk-c2-vr1-u30-clash-words-other-year.log | 25103 |  |
| mk-c2fix2-vr1-u30-putback-said-after | 2026-10-13 9:43:17 AM ET | 0 | 0.2s | logs/mk-c2fix2-vr1-u30-putback-said-after.log | 25818 |  |
| M-c2fix2-vr1-u30-putback-said-after-P2-verify | 2026-10-13 9:43:17 AM ET | 1 | 31.5s | logs/M-c2fix2-vr1-u30-putback-said-after-P2-verify.log | 25828 | 17/18 pass, 1 fail |
| mk-c2fix2-vr1-u30-occupied-said-newer | 2026-10-13 9:43:49 AM ET | 0 | 0.2s | logs/mk-c2fix2-vr1-u30-occupied-said-newer.log | 26272 |  |
| M-c2-vr1-u30-clash-words-other-year-G-u2030 | 2026-10-13 9:42:31 AM ET | 1 | 89.3s | logs/M-c2-vr1-u30-clash-words-other-year-G-u2030.log | 25111 | 125/126 pass, 1 fail |
| mk-c1-v200-u20-wait-uncounted | 2026-10-13 9:44:00 AM ET | 0 | 0.4s | logs/mk-c1-v200-u20-wait-uncounted.log | 26397 |  |
| M-c2fix2-vr1-u30-occupied-said-newer-P2-verify | 2026-10-13 9:43:49 AM ET | 1 | 30.3s | logs/M-c2fix2-vr1-u30-occupied-said-newer-P2-verify.log | 26280 | 17/18 pass, 1 fail |
| M-c1-v200-u20-wait-uncounted-G-u2030 | 2026-10-13 9:44:01 AM ET | 1 | 114.8s | logs/M-c1-v200-u20-wait-uncounted-G-u2030.log | 26434 | 83/126 pass, 43 fail |
| mk-c1-v200-u20-failed-stays-counted | 2026-10-13 9:45:56 AM ET | 0 | 0.4s | logs/mk-c1-v200-u20-failed-stays-counted.log | 27844 |  |
| M-c1-v200-u20-failed-stays-counted-G-u2030 | 2026-10-13 9:45:56 AM ET | 1 | 93.3s | logs/M-c1-v200-u20-failed-stays-counted-G-u2030.log | 27852 | 103/126 pass, 23 fail |
| mk-c2-saves-not-serial | 2026-10-13 9:47:30 AM ET | 0 | 0.4s | logs/mk-c2-saves-not-serial.log | 29322 |  |
| M-c2-saves-not-serial-G-serial | 2026-10-13 9:47:30 AM ET | 1 | 46.1s | logs/M-c2-saves-not-serial-G-serial.log | 29336 | 32/37 pass, 5 fail |
| mk-base-saves-not-serial | 2026-10-13 9:48:17 AM ET | 0 | 0.4s | logs/mk-base-saves-not-serial.log | 30043 |  |
| M-base-saves-not-serial-G-serial | 2026-10-13 9:48:17 AM ET | 1 | 60.2s | logs/M-base-saves-not-serial-G-serial.log | 30061 | 32/37 pass, 5 fail |
| G-all-c2 | 2026-10-13 9:49:18 AM ET | 0 | 245.4s | logs/G-all-c2.log | 30782 | 254/254 pass |
| G-all-c1 | 2026-10-13 9:53:23 AM ET | 1 | 211.7s | logs/G-all-c1.log | 1743 | 233/254 pass, 21 fail |
| G-all-c2fix | 2026-10-13 9:56:55 AM ET | 0 | 227.5s | logs/G-all-c2fix.log | 4222 | 254/254 pass |
| F-folderA-c2 | 2026-10-13 10:00:48 AM ET | 0 | 191.6s | logs/F-folderA-c2.log | 6797 | 297/297 pass |
| F-folderB-c2 | 2026-10-13 10:04:00 AM ET | 0 | 312.0s | logs/F-folderB-c2.log | 9063 | 142/142 pass |
| G-u2030-c2fix2 | 2026-10-13 10:09:12 AM ET | 0 | 103.0s | logs/G-u2030-c2fix2.log | 11928 | 126/126 pass |
| P-verify-c2fix2 | 2026-10-13 10:10:55 AM ET | 0 | 15.3s | logs/P-verify-c2fix2.log | 12944 | 10/10 pass |
| F-folderA-c2fix2 | 2026-10-13 10:11:10 AM ET | 0 | 198.0s | logs/F-folderA-c2fix2.log | 13126 | 297/297 pass |
| F-folderB-c2fix2 | 2026-10-13 10:14:28 AM ET | 0 | 265.9s | logs/F-folderB-c2fix2.log | 15379 | 142/142 pass |
| S-c2-npm-check | 2026-10-13 10:18:58 AM ET | 0 | 6.9s | logs/S-c2-npm-check.log | 17713 |  |
| S-c2fix2-npm-check | 2026-10-13 10:19:05 AM ET | 0 | 6.3s | logs/S-c2fix2-npm-check.log | 17769 |  |
| S-c2fix2-audit | 2026-10-13 10:19:11 AM ET | 0 | 18.8s | logs/S-c2fix2-audit.log | 17831 |  |
| S-c2fix2-audit-other | 2026-10-13 10:19:30 AM ET | 0 | 58.5s | logs/S-c2fix2-audit-other.log | 17927 |  |
| G-all-c2fix2 | 2026-10-13 10:20:31 AM ET | 0 | 163.4s | logs/G-all-c2fix2.log | 18347 | 254/254 pass |

