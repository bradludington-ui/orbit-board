# U20 then U30: a save waiting for the Web Lock is counted; a refresh never lets a Save overwrite unasked

> **Fix round, 13 Oct: the proposed commits are now `c1f/` and `c2f/`; see "Fix round (13 Oct 2026)" at the end. The round-1
> commits, results and drafts below are kept as the record the reviews read, and are superseded where that section says so.**

Builder's record for the ORBIT v2.00 release track U20U30. **Two commits are proposed. Nothing is committed or pushed.**
The lead commits. Nothing in `/home/user/orbit-board` or `/home/user/orbit-ui` was edited, staged or committed by this
builder. The only contact with orbit-board was reading it: `git log`, the ledger, and `git clone --shared` into
`clones/` (see Runs).

Times are Eastern. Each was read with `TZ=America/New_York date`. This resumed attempt ran from 7:31 PM ET on Mon
12 Oct 2026. The last run is recorded in `logs/runs.txt`; the README's closing time is at its end.

## The two commits

| # | subject | copy | board | audit-import | mutate (`mutate.mjs.txt`, text only) |
|---|---|---|---|---|---|
| base | `7ee498a` archive (product `d66dd60`, U14) | `b0/` (= `../base`) | `fce8a391` | `4aba2506` | `cbc6defc` |
| 1 | v2.00 U20: a save waiting for another tab's save is under way | `c1/` | `83b87782` | `776c6680` | `6b4c83d6` |
| 2 | v2.00 U30: a refresh takes the folder's copy as the base only when it is on screen | `c2/` | `c42be8e7` | `e0d4186b` | `54c7d928` |

Each copy is cumulative: c1 is the base plus commit 1, and c2 is c1 plus commit 2. Each was made with `cp -a`, keeps the
`node_modules` symlink and is `u+w`. Every other file is byte-identical to the base (`diff -rq` over `tools/`), including
audit-recon `529e36f7`, audit-board `a7c575e5`, audit-other `d89396b0`, package.json `7cf8186f` and NEXT-VERSION.md
`65265c13`. The board stays the empty template: only code and comments changed.

Full blob ids:

- c1 board `83b87782710c2dee6ca2dbc030aabb22a92c9a0f`;
- c2 board `c42be8e71244fdbdaeb447278ab99edd94626a2c`;
- c1 audit-import `776c66800875f00ad05de7e0d8d3040860270cc6`;
- c2 audit-import `e0d4186bbd7091b1a4dd006a62372be5d958af8a`;
- c1 mutate `6b4c83d64559b77fe1995c53bde366e0f94067e4`;
- c2 mutate `54c7d9289939e04ba510deff3f93279505d61765`.

Diffs, each against the previous copy, are in `diffs/`:

- c1: `c1-board.diff`, `c1-audit-import.diff` (+503 lines, additions only) and `c1-mutate.diff` (+7);
- c2: `c2-board.diff`, `c2-audit-import.diff` (+217, additions only) and `c2-mutate.diff` (+13).

The board diffs and the mutation entries are given in full below. The suite blocks are `blocks/u20.mjs.txt` (`85beabdec`)
and `blocks/u30.mjs.txt` (`9b6c5259`). Each is inserted verbatim, U20's after `// ==== end v2.00 (U13) ====` and U30's
after `// ==== end v2.00 (U20) ====`.

## What was wrong, and the decision for each

**U20.** `saveSerial` counted a save in `_saveBusy` only inside the Web Lock's callback. A save waiting for another tab's
`orbit-save` lock was therefore not under way to ↶ Put back (U2's refusal) or to `driveStorePull` (U13's adoption refusal
and its base-record guard). With nothing recorded for the folder and a folder copy not newer than the screen, a refresh
during the wait recorded the folder's copy F0 as the base. The waiting save then wrote B-EDIT over F0 without asking.
With a spaced history copy under ten minutes old, F0 was kept only as `-recent`, and one more Save pruned it.

**Commit 1** counts a save from the moment it is asked for, and uncounts it once its promise settles, however it ends. The
whole change:

```diff
--- a/prioritization-board-grid.html
+++ b/prioritization-board-grid.html
@@ -6490,16 +6490,23 @@
 // - One save runs at a time, across the Save button, the folder's autosave and "Save yours over
 //   theirs", and across this browser's tabs (Web Locks, where the browser has them). A save that had to
 //   wait captures its own target and bytes when it starts, and re-reads everything it checks.
+// v2.00 (U20): A SAVE IS UNDER WAY FROM THE MOMENT IT IS ASKED FOR, WAITING INCLUDED, until it has finished, however it
+// ends. It was counted only once it held the lock, so a save waiting for another tab's save was no save at all to ↶ Put
+// back (U2) and to the folder's refresh (U13): a refresh then took the folder's copy as the one the work came from, and the
+// waiting save wrote over that copy without asking. _saveBusy is the number of saves asked for in this tab and not finished.
 let _saveGen=0, _saveChain=Promise.resolve(), _saveBusy=0;
 function saveSerial(fn){
-  const go=function(){ _saveBusy++; return Promise.resolve().then(fn).finally(function(){ _saveBusy--; }); };
+  const go=function(){ return Promise.resolve().then(fn); };
   const run=function(){
     try{ if(typeof navigator!=='undefined' && navigator.locks && typeof navigator.locks.request==='function')
       return navigator.locks.request('orbit-save', {mode:'exclusive'}, go); }catch(e){}
     return go();
   };
   if(_saveBusy){ try{ setStat('⏳ A save is already under way — this one runs as soon as it finishes.'); }catch(e){} }
+  _saveBusy++;
   const p=_saveChain.then(run, run);
+  const done=function(){ _saveBusy--; };
+  p.then(done, done);   // saved, refused, failed or thrown -- and the lock, where there is one, let go
   _saveChain=p.catch(function(){});
   return p;
 }
```

Every exit path settles `p`: saved, refused or canceled (`fn` resolves); failed or thrown (`fn` rejects, through
`Promise.resolve().then(fn)`); the lock request rejected (the `run` promise rejects); and `request()` throwing at once
(the `catch` falls back to `go()`). `done` is registered before the caller gets `p`, so a caller's continuation already
sees the count down. Nothing in the board compares `_saveBusy` with a number; every reader tests it for truth (`grep`:
lines 6501, 6954, 26769 and 26803 at the base). Callers: `saveInPlace`, `saveInPlaceFile`, `driveStorePush` and
`driveResolve`. The refusals made at once (`sandboxBlock`/`cycBlock`) come before `saveSerial` and are never counted.

**U30.** It is the same unasked overwrite with no second tab. The v1.89 rule "with nothing recorded … the folder's copy is
taken as the base, as it always was" recorded F0 whatever was on screen (BR-C2a/C2ah; O4-tick: the Live timer's tick 2
wrote over F0 one tick after saying "Nothing was written"). The rule starts from the U20 checker's O4 proposal, which
records the base only when `theirs===ours`. The O4 proposal's own risk 2 ("The wording is not exact here") is closed as
well. The refusal said theirs was saved "after the copy you are working from", which nothing recorded can tell, and this
change makes that refusal far more frequent (every Save and every autosave tick until a choice is made). So with nothing
recorded it now says only what is known. The whole change:

```diff
--- a/prioritization-board-grid.html
+++ b/prioritization-board-grid.html
@@ -26773,6 +26773,13 @@
     // v1.89) there is no telling, and the folder's copy is taken as the base, as it always was.
     // v2.00 (U13): BUT NOT WHILE A SAVE IS UNDER WAY. A save still to read the folder would find this copy recorded as the one
     // the work came from, and write over it without asking; a save past its read records the copy it writes, once it lands.
+    // v2.00 (U30): AND ONLY WHEN THAT COPY IS WHAT IS ON SCREEN -- the same stamp, as every change stamps the board anew.
+    // Taken as the base while the screen held other work, it let the next Save, or the Live timer's autosave one tick after
+    // it had said "Nothing was written" and offered the choice, write that work over it without asking; with a history copy
+    // kept less than ten minutes before, the copy written over was kept only as a recent copy, and one more Save removed it.
+    // Now nothing is recorded and nothing is said, and Save asks: Load theirs, or Save yours over theirs, which keeps theirs
+    // in the folder's history whatever the spacing.
+    if(!base && theirs!==ours) return false;
     if(!base){ if(!_saveBusy) driveBaseSet(mySlug(), theirs); }
     else if(theirs!==base){ driveClashSay(j, false); render(); }
     return false;
@@ -26961,10 +26968,15 @@
 // load theirs, with this browser's work kept aside; or save this one over theirs, with theirs kept in
 // the folder's history. The refusal this replaces said "Reload to take their copy" -- and a reload then
 // took the folder's newer time as the one the work came from, and the next Save wrote over them.
+// v2.00 (U30): WITH NOTHING RECORDED THERE IS NO TELLING which copy in the folder the work on screen came from, if any, so
+// it is not said that theirs came after it. Save asks for that reason alone (the push, above); and since a refresh records
+// the folder's copy only when it is what is on screen, this is said on every Save and autosave until one is chosen.
 function driveClashSay(j, refused){
   const ap=mySlug(), theirs=+((j&&j.store&&j.store.ts)||(j&&j.ts)||0);
   setStat('⛔ <b>'+esc((j&&j.by)||'someone')+'</b> saved '+esc(APPN_LBL[ap]||ap)+' FY'+(MS.cur%100)
-    +' to the shared folder '+esc(liveAge(theirs))+', after the copy you are working from. '
+    +' to the shared folder '+esc(liveAge(theirs))
+    +(driveBaseOf(ap)? ', after the copy you are working from. '
+      : ', and this browser has no record of which copy in the folder, if any, the work on screen came from. ')
     +(refused? '<b>Nothing was written.</b> ' : 'What is on screen does not have their changes. ')
     +'<button type="button" class="nb lnk" onclick="driveResolve(\'theirs\')">Load theirs</button> '
     +'(your work is kept aside, and one click puts it back) · '
```

Why the rule is enough: the base is recorded from the folder only by its own write (the copy it wrote), by an adoption
(shown), by "Save yours over theirs" (asked; theirs kept with `force`), by ↶ Put this back from the history (asked; the
standing copy kept with `force`), and by this refusal branch. `grep driveBaseSet` gives seven call sites, every one read.
After this change, the refusal branch records only the copy on screen. Save writes over a folder copy only when it matches
the recorded base, so a copy that was never shown or adopted is never written over unasked, and is never left only as a
prunable `-recent` copy. "Save yours over theirs" keeps theirs as a spaced copy (`snapKeep(…, true)`). The push's own
`-recent` copy of it is then pruned, and the spaced one stays; scenarios (1)/(1h)/(2) check this, through one more Save
and a reopen. `driveClashSay` is called from two places. The pull calls it only with a base recorded, so its words are
unchanged. The push calls it whenever the folder's copy is not the recorded base, which includes nothing recorded.

### The decision principles, one by one

1. **Never lose any copy; keep both and ask.**
   - U20: a waiting save now meets U2's refusal and U13's two guards exactly as a running one does.
   - U30: with nothing recorded and other work on screen, Save refuses with the choice. Load theirs keeps yours aside.
     Save yours over theirs keeps theirs as a spaced history copy.
   - The history variants (U20 (3h); U30 (1h) and (2)) check that F0 stays reachable through one more Save and a reopen.
2. **Refuse or ask rather than guess.**
   - U30 replaces a guess ("the folder's copy is what the work came from") with a question.
   - With nothing recorded, the question no longer guesses that theirs came after.
3. **Money and every export match the computation exactly.** No money or export path is touched. audit, audit-ppt,
   audit-other, audit-recon, audit-hostile, audit-inject, legacy-fsrc, boot-same and npm run check give the same results
   on the base and on c2 (below).
4. **Every word stays true, including after the operation lands.**
   - U2's and U13's refusals are past-tense, and true of a waiting save.
   - "⏳ A save is already under way" is now said for a second Save while the first waits, which is true.
   - The U30 refusal no longer claims an order it cannot know.
   - Not changed, and stated under Not covered: with a copy recorded, "after the copy you are working from" is still said,
     as before.
5. **Smallest change.**
   - U20: three lines moved in one function.
   - U30: one line in the refresh, and one conditional phrase in the refusal.
   - No other behaviour changes.
6. **Every existing check, fixture and expected value is preserved.**
   - No existing line of any suite or of `mutate.mjs` was edited. Both diffs are additions only.
   - Every audit-import scenario that reaches the changed code passes on c1 and c2: U2 ×2, U13 and the 21 other folder
     and file save scenarios (below).
   - Every existing mutation entry still matches exactly once (`mcount`).
   - U13's mutations stay caught on c2. U13's case (3c) has other work on screen, so on c2 the U30 rule returns before
     U13's base-record guard is reached. Its mutations `v200-u13-base-while-saving` and `v200-u13-clash-while-saving` are
     still caught on c2, by the U20 block's case (4) and the U30 block's (5b), which put the folder's copy itself on screen.
     Measured, below.
   - No existing expectation had to change: **none**.

## Tests (audit-import, cumulative)

House style: async wrapper, `bootMark()` / `bootRelease(__bm, keepBoards())` / `settleBoards()`, the two-space
`  const name = '…';` line, and `// ==== …` / `// ==== end … ====` markers. Every expected value is a hand-written
literal; board helpers are used only for observed values.

**Commit 1 adds two blocks** (`// ==== v2.00 (U20): a save waiting for another tab's save is under way ====`):

- **`webLocks()`, the U20 probe's `locks-mock.mjs`, ported as a top-level suite helper.** It is the same model, and it is
  checked first.
  - **"v2.00 (U20) — the Web Locks stand-in behaves as the API does" (19 checks).** These are the mock's own tests T1–T10:
    - exclusive first-come-first-served across three tabs, with the callback never run inside `request()`;
    - a rejection and a throw letting go, and a plain value;
    - let go before `request()` settles;
    - independent names;
    - `ifAvailable`;
    - shared then exclusive;
    - `query()` and a closing tab;
    - steal, signal and bad arguments refused, not ignored;
    - 300 seeded requests: granted in order, never two holders.
- **"v2.00 (U20) — a save waiting for another tab's save is under way" (59 checks).** Alice's browser has tab B (O&M FY27)
  and tab A (FULL FUND), with one lock manager. A's 💾 Save is held at its write, so it holds the lock. B's 💾 Save
  (`saveInPlace()`, the toolbar's path) waits.
  - (1) ↶ Put back (`keptPutBack()`) while waiting is refused, byte for byte; after A lands, B's S1 lands and Put back works.
  - (2) A refresh of a newer copy while waiting loads nothing, in U13's exact words. The Save then asks, and the next
    refresh is ordinary.
  - (3)/(3h) Nothing recorded, the product's own way. The opening's `driveAutoConnect()` finds an empty folder, then
    Alice's other machine saves F0 (and in (3h) F00 a moment before). Live view's ↻ Refresh now (`livePoll(false)`) during
    the wait records nothing, and the Save asks. Then Save yours over theirs keeps F0 as a spaced copy, through one more Save.
  - (4) The screen exactly the folder's copy, nothing recorded: a refresh during the wait records nothing and says
    nothing, and the Save asks.
  - (5a) **Control:** a second Save waiting behind this tab's own save. It is told it waits, Put back is refused and a
    refresh loads nothing.
  - (5b) **Control:** case (3) with the waiting save counted by the harness itself, by wrapping `locks.request`. The
    uncounted wait alone was the cause.
  - (6a)–(6d) The count comes back down when the autosave throws while it holds the lock, when the lock request is refused,
    and when asking for it throws. Two Saves waiting are counted as two.
  - Every case ends with the stand-in's sanity check: grant order, no violations, nothing unmodelled, every grant let go.

**Commit 2 adds one block** (`// ==== v2.00 (U30): a refresh takes the folder's copy as the one the work came from only when it is what is on screen ====`).
"v2.00 (U30) — a refresh takes the folder's copy as the base only when it is on screen" has 48 checks:

- (1)/(1h) The Live timer alone, in one tab, with Live view and autosave on: `liveTick()` twice, then 💾 Save. Each asks
  and writes nothing. The words are checked against a literal pattern (the copy's age is the only variable part), and
  "after the copy you are working from" is not said. Then Save yours over theirs, one more Save and a reopen. F0 (and F00)
  stay spaced history copies throughout.
- (2) ↻ Refresh now, then Save.
- (3) Save, then a refresh, then Save. It used to write over F0 the second time.
- (4) A second tab. B's Save waits and the Live timer ticks twice. Tick 1's autosave queues behind it (both counted: 2),
  and tick 2's refresh records nothing. Once A lands, both refuse. Tick 1's own refresh then runs with nothing under way
  and records nothing (the BR-Wrealtickcount route), and the next Save asks.
- (5a) **Control:** the screen exactly the folder's copy (another browser's storage with its record removed). The opening's
  connect records F0, and L-EDIT saves with no question.
- (5b) **Control:** the same, with a save held at its read. U13's rule holds: nothing recorded, nothing said, and the save
  asks.
- (5c) **Control:** a genuine first save of a new board into an empty folder, then a second save, both with no question.
- (5d) **Control:** an ordinary refresh with nothing unsaved loads N and records it, then N-EDIT saves with no question.
- (5e) **Control:** a copy recorded and a later one saved over it. Save asks in the words it always used.

**Not labelled a control:** U30 (4)'s "B counts both as under way" check. It is a U20 check, and it fails on the base.

### Focused results (harnesses built verbatim from the suites; final runs)

Each harness is built by `bin/mkfocused-multi.py`, adapted from `rec/L2/u2impl/mkfocused-u2.py`. It copies, verbatim,
the suite's imports, failure list, `keepBoards`, SEEN/`chk`, the selected blocks, the scenario-ran guard, and the
top-level helpers they reference (by closure). It runs through `bin/runner.mjs`, which imports the copy's
`runtime-encoding-shim.mjs` and then the copy's own `boot.mjs`, with BOARD unset (asserted).

| harness (blob) | what | base `fce8a391` | c1 `83b87782` | c2 `c42be8e7` |
|---|---|---|---|---|
| F-u20 `9ca47a19` | the two U20 scenarios | **20 of 78 fail** (f1) | 78/78 (f1) | 78/78 (f2) |
| F-u30 `97909af0` | the U30 scenario | **23 of 48 fail** (f2) | **21 of 48 fail** (f2) | 48/48 (f2) |
| F-all `9d5a1ef4` | U2 ×2, U13, U20 ×2, U30 | 43 of 254 fail (U20 + U30 only) (f2) | 21 of 254 fail (U30 only) (f2) | 254/254 (f2) |
| F-folder `05908d30` | the 21 other audit-import scenarios that save or refresh | 439/439 (f1) | see F-folderA/B | 439/439 (f1) |
| F-folderA `ab838a51` / F-folderB `739ff555` | F-folder in two halves (11 + 10 scenarios) | — | 297/297 + 142/142 = 439 (f3) | — |

The 21 scenarios in F-folder are every other audit-import scenario that calls `driveStorePull`, `liveTick`,
`driveAutoConnect`, `driveConnectNow`, `livePoll`, `drivePoll`, `driveStorePush`, `saveInPlace` or `driveResolve`. Found
by grep, with `keptPutBack`, `driveRestore`, `takePen`, `saveBtn` and `driveClashSay` checked too: the only other hit,
"v1.84 — a copy points to Submit input", only reads the Save button's text. They are:

- PMO copy;
- v1.89 — saving never silently overwrites;
- v1.95 ×6;
- v1.96 NR01;
- v1.97 ×5;
- v1.99 item 86;
- v2.00 R3 ×2, R4, R4b and R5.

audit-board and audit-recon reach none of the changed code (no call to any save or refresh path; `grep`).

**Every failure on the base and on c1 is a defect check.**
- **F-u20 on the base:**
  - the premise checks ("B counts its waiting Save", ×5, and (6d)'s two);
  - Put back going ahead (1);
  - the refresh adopting (2);
  - the base recorded and the waiting save writing unasked (3)/(3h)/(4);
  - (3h)'s history loss: F0 not a spaced copy after Save yours over theirs, and gone after one more Save.
- **F-u30:**
  - on the base, every U30 property and U30 (4)'s U20 count;
  - on c1, the U30 properties only; the U20 count passes.
- **Every check labelled a control passes on all three boards.**

The full failing lists with observed values are in `out/<label>.checks.jsonl`; `bin/fails.py` prints them. The f1 run of
F-u30 used the harness before (4)'s count was split from its control check (the split is the only difference). f2 is the
final.

### Mutations (inserted before the R3 line; ids `v200-u20-*`, `v200-u30-*`)

```
  // v2.00 (U20): a save waiting for another tab's save (the 'orbit-save' Web Lock) is under way, from the moment it is asked for until it ends.
  { id: "v200-u20-wait-uncounted", area: "saveSerial", what: "a save is counted as under way only once it holds the lock: one waiting for another tab's save is no save at all to ↶ Put back and to the folder's refresh, which takes the folder's copy as the one the work came from, so the waiting save writes over that copy without asking (with a history copy kept less than ten minutes before, it is gone after one more Save)",
    find: <c1's saveSerial from "  const go=" through "  p.then(done, done);   // saved, …\n">,
    repl: <the base's own text for the same lines> },
  { id: "v200-u20-failed-stays-counted", area: "saveSerial", what: "a save that fails, throws or whose lock request is refused stays counted as under way for good: ↶ Put back is refused and every refresh loads nothing until the page is reopened",
    find: "  p.then(done, done);   // saved, refused, failed or thrown -- and the lock, where there is one, let go\n",
    repl: "  p.then(done, function(){});\n" },
  // v2.00 (U30): a refresh takes the folder's copy as the one the work came from only when it is what is on screen; with nothing recorded, Save asks without saying theirs came after.
  { id: "v200-u30-base-whatever-on-screen", …  find: "    if(!base && theirs!==ours) return false;\n", repl: "" },
  { id: "v200-u30-base-only-other-copy", …     find: the same, repl: "    if(!base && theirs===ours) return false;\n" },
  { id: "v200-u30-unrecorded-said-after", …    find: the two-line conditional, repl: "    +', after the copy you are working from. '\n" },
  { id: "v200-u30-recorded-said-unknown", …    find: "    +(driveBaseOf(ap)? ', after the copy you are working from. '\n", repl: "    +(false? ', after …" },
```

The exact text is in `mut/entries-u20.txt` (`39d031cc`) and `mut/entries-u30.txt` (`df6fc2cc`), and in `diffs/c*-mutate.diff`.
The entries were generated by `bin/mkentries.py`. It takes every find from the board it mutates, asserts that it occurs
there exactly once, and takes the U20 repl from the base board's own text. Every string is JSON-encoded, which is valid JS.

**mcount**, text only, with `rec/bin/mcount.py` under `python3 -I`:
- base: 1328 of 1328 entries match exactly once;
- c1: 1330 of 1330;
- c2: 1334 of 1334.

No entry is missing, multiple or unparsed (`out/mcount-*.json`). The c2 count was re-run on the final c2 board.

**Mutants** were made with `rec/bin/mkmut.py`, which reads mutate as text only. Each printed `matches: 1` (`out/mkmut2.txt`),
and each was run through the focused harness with BOARD set to the mutant, asserted. Every mutant was caught:

| mutant (board blob) | harness | failing checks |
|---|---|---|
| c1 `v200-u20-wait-uncounted` (`dc6fd5d6`) | F-u20 | 20: the same 20 as the base |
| c1 `v200-u20-failed-stays-counted` (`5a25ded3`) | F-u20 | 2: (6a) the autosave throws and `_saveBusy` stays 1; (6b) the lock is refused and it stays 1 |
| c2 `v200-u20-wait-uncounted` (`cc5e4ece`) | F-u20 | 14: (1) ×4, (2) ×4, the premise in (3)/(3h)/(4), (4)'s record and ask, (6d) |
| c2 `v200-u20-failed-stays-counted` (`7bce8192`) | F-u20 | 2: (6a), (6b) |
| c2 `v200-u30-base-whatever-on-screen` (`e5c1f24b`) | F-u30 | 19: (1)/(1h) ticks and Save, (1h)'s loss, (2), (3), (4) |
| c2 `v200-u30-base-only-other-copy` (`7820a082`) | F-u30 | 21: the same, plus the (5a) control (the same copy no longer recorded) |
| c2 `v200-u30-unrecorded-said-after` (`e4b63e0e`) | F-u30 | 2: the words in (1) and (1h) |
| c2 `v200-u30-recorded-said-unknown` (`17d72862`) | F-u30 | 1: (5e)'s words |
| c2 `v200-u2-putback-gen` (`e66cc5bb`) | F-all | 1: U2's (d), the direct count check. This is by design, as recorded for U2 at `a8891e1`. |
| c2 `v200-u2-putback-while-saving` (`3b98f84f`) | F-all | 39: U2 (a)–(h) 34, the same 34 as at `a8891e1`; U20 (1) 3 and (5a) 2 |
| c2 `v200-u13-pull-while-saving` (`41d69a4b`) | F-all | 43: U13 40 ((1) 12, (2) 5, (3a) 2, (3b) 2, (4a)–(4d) 11, (6a) 6, (6b) 2); U20 (2) 3 |
| c2 `v200-u13-base-while-saving` (`08b5dbd6`) | F-all | 4: U20 (4) 2 and U30 (5b) 2. U13 (3c) no longer catches it on c2, because its screen holds other work and the U30 rule returns first. The two same-copy cases do. |
| c2 `v200-u13-pull-unchecked` (`880beea7`) | F-all | 47: U13 40; U20 (2) 3 and (4) 2; U30 (5b) 2 |
| c2 `v200-u13-said-nothing-loaded` (`8a63cf4b`) | F-all | 11: U13's words 10; U20 (2)'s words, word for word |
| c2 `v200-u13-clash-while-saving` (`b8e66d47`) | F-all | 2: U20 (4) and U30 (5b), "says nothing" (a clash said with nothing recorded) |

## The U20 probe and checker, re-run (reproduction first)

`probe/b` and `probe/x` are byte-identical copies of the U20 probe's and checker's scripts: `u20probe.mjs` `677d6f3f`,
`locks-mock.mjs` `cee3b470`, `locktest.mjs` `bb670f12` and `u20x.mjs` `795f0928`, the same as
`rec/L4/u20-check/rerun` and `/x`. The literal checks `check.mjs` / `xcheck.mjs` are changed only in the board id they
assert. They ran one scenario per bounded run.

| pass | board | probe: kinds failing | checker: kinds failing |
|---|---|---|---|
| r0 (earlier builder, kept) | base `fce8a391` | U20 9, OUT 6. The same 15 as the triage on `98eed7e8`: BR-W, -Wtick, -Wperm, -Wh, -Wpermh; BR-C2a/C2ah/C2b/C2bh. Every control healthy, and locktest 19/19. | U20 5 (BR-Wreal, -Wrealtick, -Wrealh) and O4 5 (O4-tick, -tickh, BR-Wrealtickcount). Counted controls CNT 45/45. |
| r1 (kept) | c1 `83b87782` | PRE 10: the probe's literal premise "B `_saveBusy` 0", which the fix changes, as intended. U20 1: BR-Wtick's next Save, the U30 route. OUT 6 (U30). | PRE 8, INFO 3: the mechanism the fix removes. U20 1: BR-Wrealtick's next Save (U30). O4 5. |
| r2 (kept) | c2 before the wording change (`111360a2`) | PRE 10 only. U20 77/77, OUT 26/26. | PRE 8, INFO 4, O4 2: the "observed mechanism" checks only. U20 24/24, CNT 45/45. |
| r3 | final c2 `c42be8e7` | PRE 10 only (as r2); U20 77/77, OUT 26/26, CTL 109/109, locktest 19/19; all 40 runs exit 0 | PRE 8 and INFO 4 (the mechanism, as r2); O4 2, its two "observed mechanism" checks only; U20 24/24, CNT 45/45, CTL 10/10 |

## Other suites and npm run check (scratch git clones, the base vs c2)

`clones/b0` and `clones/c2` are `git clone --shared /home/user/orbit-board`. The clone head was `60336a0`, a records-only
commit after `7ee498a`. b0's or c2's files were then copied over, and a `node_modules` symlink added. `git status` in
`clones/b0` shows only `?? node_modules` and `?? mutate.mjs.txt`, so the base's product files equal that head's. In
`clones/c2` it shows the board and audit-import modified. Nothing was committed there.

| suite | base clone | c2 clone |
|---|---|---|
| boot-same | exit 0 (every page, source, save and error list identical) | exit 0 (same) |
| audit (export) | ALL CHECKS PASSED | ALL CHECKS PASSED |
| audit-ppt | ALL CHECKS PASSED | ALL CHECKS PASSED |
| audit-other | ALL CHECKS PASSED | ALL CHECKS PASSED |
| audit-recon | ALL CHECKS PASSED | ALL CHECKS PASSED |
| legacy-fsrc | exit 0 | exit 0 |
| audit-hostile | ALL CHECKS PASSED | ALL CHECKS PASSED |
| audit-inject | ALL CHECKS PASSED | ALL CHECKS PASSED |
| npm run check | all checks passed | all checks passed |

**Not run, by rule:** the full audit-import and audit-board (the lead runs those alone), and `mutate.mjs` (read as text only).

## What was kept from the earlier attempt, and what was re-run

The earlier builder worked here from 5:58 PM ET to about 6:16 PM ET, when a usage limit stopped it. Its 266-line
`pids.txt` was kept and appended to. The lead had checked at 7:30 PM ET that none of its processes was running.

**Kept, after checking:**
- `b0/`: `diff -rq` against `../base` shows nothing.
- `c1/`'s board: its diff against the base is exactly the U20 hunk above.
- `c2/`'s U30 rule: its diff against c1 was that hunk alone.
- `blocks/u20.mjs.txt` and `blocks/u30.mjs.txt`.
- The probe copies, with r0, r1 and r2. Every log has its `# end … exit` line, and every run in `logs/runs.txt` has an
  exit record.
- The scripts `run.sh`, `bx.sh`, `frun.sh`, `runner.mjs`, `insert.py`, `mkfocused-multi.py`, `rebuild-suites.sh`,
  `repro.sh` and `repro2.sh`.
- Its dev runs (`dev1-*`, `dev2-*`), which are not evidence. dev1 failed only on the stand-in's grant-order checks, which
  then counted the fixture's own saves; they now count from the case's mark.

**Changed by this attempt:**
- c2's board: the refusal's words with nothing recorded (`driveClashSay`). One whitespace slip of this attempt's own edit
  (`refused?'<b>`) was found in the diff and put back. The c2 board went `111360a2` → `8fea44af` → `c42be8e7`; only
  `c42be8e7` is proposed.
- The U30 block:
  - the words check in (1)/(1h), and the `UNSAID` literal;
  - control (5e);
  - (4)'s U20 count split out of a check that was labelled a control and failed on the base.
- **Added:**
  - the mutation entries (none existed);
  - `mcount`;
  - F-folder, F-folderA and F-folderB;
  - the suites and npm check;
  - the drafts and this README.
  - Scripts: `bin/rebuild-suites2.sh`, `batch.sh`, `suites.sh`, `after-f1.sh`, `mkentries.py` and `fails.py`.

**Re-run by this attempt:**
- every focused run (f1, f2, f3);
- every mutant (m1);
- the probe on the final c2 board (r3);
- all the suites.

The earlier r0/r1/r2 probe passes are kept as they were. r0 is the base reproduction.

## Runs

Every node, npm and text-helper command was run as `setsid -w timeout -k 10 600 …` through `bin/run.sh` (node and npm)
or `bin/bx.sh` (copies, hashes, diffs, python text helpers). Before every node or npm run, `run.sh` checked
`AUDIT_IMPORT_RUNNING`. It was never present, so no run waited and none was skipped. The timeout PID and its child are in
`pids.txt` with the command. The batch wrappers' own PIDs are recorded too (`batch.sh`, `suites.sh`, `after-f1.sh`): each
starts nothing but bounded runs. **No run timed out and none was killed.** Nothing was killed by this builder. One of this
builder's waiting loops, a background `until … sleep` started by the agent tool, was stopped by the tool at its own time
limit. It ran no node and is not in `pids.txt`.

`logs/runs.txt` holds every run as `label start_et exit wall_s log`. Batches:
- r0/r1/r2 (earlier builder): 17:59–18:09 ET.
- dev1/dev2: 18:14–18:16.
- f1: 19:40–20:06.
- Base suites: 19:46–19:53.
- f2 alongside m1: from 20:06.
- c2 suites: 20:06–20:13.
- f3 alongside r3: 20:37–20:42.

Wall times:
- F-u20 and F-u30: 21–54 s.
- F-all: 129–306 s (the box's load average was 10–19 from the other tracks).
- F-folder: 491 s on the base. That is why it was split for c1.
- Each probe scenario: 4–6 s.

This attempt's node and npm runs (`logs/runs.txt` from "# focused batch f1" on; the earlier builder's r0/r1/r2 and dev
lines are above them in the same file). Exit 1 on a focused run means checks failed, as intended on the base and c1, and
on every mutant:

```
# focused batch f1 launched 2026-10-12 19:40:03 EDT
f1-F-u20-b0 start_et="2026-10-12 19:40:03 EDT" exit=1 wall_s=22.3 log=logs/f1-F-u20-b0.log 
f1-F-u20-c1 start_et="2026-10-12 19:40:26 EDT" exit=0 wall_s=22.2 log=logs/f1-F-u20-c1.log 
f1-F-u20-c2 start_et="2026-10-12 19:40:48 EDT" exit=0 wall_s=26.0 log=logs/f1-F-u20-c2.log 
f1-F-u30-b0 start_et="2026-10-12 19:41:14 EDT" exit=1 wall_s=21.3 log=logs/f1-F-u30-b0.log 
f1-F-u30-c1 start_et="2026-10-12 19:41:35 EDT" exit=1 wall_s=22.0 log=logs/f1-F-u30-c1.log 
f1-F-u30-c2 start_et="2026-10-12 19:41:57 EDT" exit=0 wall_s=23.5 log=logs/f1-F-u30-c2.log 
f1-F-all-b0 start_et="2026-10-12 19:42:21 EDT" exit=1 wall_s=129.3 log=logs/f1-F-all-b0.log 
# suites on the base clone launched 2026-10-12 19:46:17 EDT
S-b0-boot-same start_et="2026-10-12 19:46:17 EDT" exit=0 wall_s=11.3 log=logs/S-b0-boot-same.log 
f1-F-all-c1 start_et="2026-10-12 19:44:30 EDT" exit=1 wall_s=131.1 log=logs/f1-F-all-c1.log 
S-b0-audit start_et="2026-10-12 19:46:28 EDT" exit=0 wall_s=16.3 log=logs/S-b0-audit.log 
S-b0-audit-ppt start_et="2026-10-12 19:46:45 EDT" exit=0 wall_s=8.1 log=logs/S-b0-audit-ppt.log 
S-b0-audit-other start_et="2026-10-12 19:46:53 EDT" exit=0 wall_s=51.8 log=logs/S-b0-audit-other.log 
f1-F-all-c2 start_et="2026-10-12 19:46:41 EDT" exit=0 wall_s=157.3 log=logs/f1-F-all-c2.log 
S-b0-audit-recon start_et="2026-10-12 19:47:45 EDT" exit=0 wall_s=147.1 log=logs/S-b0-audit-recon.log 
S-b0-legacy-fsrc start_et="2026-10-12 19:50:12 EDT" exit=0 wall_s=5.7 log=logs/S-b0-legacy-fsrc.log 
S-b0-audit-hostile start_et="2026-10-12 19:50:18 EDT" exit=0 wall_s=145.4 log=logs/S-b0-audit-hostile.log 
S-b0-audit-inject start_et="2026-10-12 19:52:43 EDT" exit=0 wall_s=38.4 log=logs/S-b0-audit-inject.log 
S-b0-npm-check start_et="2026-10-12 19:53:22 EDT" exit=0 wall_s=9.9 log=logs/S-b0-npm-check.log 
f1-F-folder-b0 start_et="2026-10-12 19:49:19 EDT" exit=0 wall_s=491.2 log=logs/f1-F-folder-b0.log 
f1-F-folder-c2 start_et="2026-10-12 19:57:30 EDT" exit=0 wall_s=515.5 log=logs/f1-F-folder-c2.log 
# focused batch f2 launched 2026-10-12 20:06:22 EDT
# mutant batch m1 launched 2026-10-12 20:06:22 EDT
# suites on the c2 clone launched 2026-10-12 20:06:24 EDT
S-c2-boot-same start_et="2026-10-12 20:06:24 EDT" exit=0 wall_s=17.0 log=logs/S-c2-boot-same.log 
S-c2-audit start_et="2026-10-12 20:06:41 EDT" exit=0 wall_s=17.2 log=logs/S-c2-audit.log 
S-c2-audit-ppt start_et="2026-10-12 20:06:59 EDT" exit=0 wall_s=8.5 log=logs/S-c2-audit-ppt.log 
m1-c1-v200-u20-wait-uncounted start_et="2026-10-12 20:06:22 EDT" exit=1 wall_s=49.4 log=logs/m1-c1-v200-u20-wait-uncounted.log 
f2-F-u20-c2 start_et="2026-10-12 20:06:22 EDT" exit=0 wall_s=50.4 log=logs/f2-F-u20-c2.log 
f2-F-u30-b0 start_et="2026-10-12 20:07:13 EDT" exit=1 wall_s=50.4 log=logs/f2-F-u30-b0.log 
m1-c1-v200-u20-failed-stays-counted start_et="2026-10-12 20:07:12 EDT" exit=1 wall_s=55.8 log=logs/m1-c1-v200-u20-failed-stays-counted.log 
S-c2-audit-other start_et="2026-10-12 20:07:07 EDT" exit=0 wall_s=62.9 log=logs/S-c2-audit-other.log 
f2-F-u30-c1 start_et="2026-10-12 20:08:03 EDT" exit=1 wall_s=49.8 log=logs/f2-F-u30-c1.log 
m1-c2-v200-u20-wait-uncounted start_et="2026-10-12 20:08:08 EDT" exit=1 wall_s=52.2 log=logs/m1-c2-v200-u20-wait-uncounted.log 
f2-F-u30-c2 start_et="2026-10-12 20:08:53 EDT" exit=0 wall_s=53.3 log=logs/f2-F-u30-c2.log 
m1-c2-v200-u20-failed-stays-counted start_et="2026-10-12 20:09:00 EDT" exit=1 wall_s=54.0 log=logs/m1-c2-v200-u20-failed-stays-counted.log 
m1-c2-v200-u30-base-whatever-on-screen start_et="2026-10-12 20:09:54 EDT" exit=1 wall_s=49.8 log=logs/m1-c2-v200-u30-base-whatever-on-screen.log 
S-c2-audit-recon start_et="2026-10-12 20:08:10 EDT" exit=0 wall_s=183.1 log=logs/S-c2-audit-recon.log 
S-c2-legacy-fsrc start_et="2026-10-12 20:11:13 EDT" exit=0 wall_s=6.0 log=logs/S-c2-legacy-fsrc.log 
m1-c2-v200-u30-base-only-other-copy start_et="2026-10-12 20:10:44 EDT" exit=1 wall_s=37.5 log=logs/m1-c2-v200-u30-base-only-other-copy.log 
m1-c2-v200-u30-unrecorded-said-after start_et="2026-10-12 20:11:21 EDT" exit=1 wall_s=53.4 log=logs/m1-c2-v200-u30-unrecorded-said-after.log 
m1-c2-v200-u30-recorded-said-unknown start_et="2026-10-12 20:12:15 EDT" exit=1 wall_s=54.2 log=logs/m1-c2-v200-u30-recorded-said-unknown.log 
S-c2-audit-hostile start_et="2026-10-12 20:11:19 EDT" exit=0 wall_s=120.8 log=logs/S-c2-audit-hostile.log 
f2-F-all-b0 start_et="2026-10-12 20:09:46 EDT" exit=1 wall_s=221.1 log=logs/f2-F-all-b0.log 
S-c2-audit-inject start_et="2026-10-12 20:13:20 EDT" exit=0 wall_s=25.7 log=logs/S-c2-audit-inject.log 
S-c2-npm-check start_et="2026-10-12 20:13:46 EDT" exit=0 wall_s=7.8 log=logs/S-c2-npm-check.log 
m1-c2-v200-u2-putback-gen start_et="2026-10-12 20:13:09 EDT" exit=1 wall_s=256.8 log=logs/m1-c2-v200-u2-putback-gen.log 
f2-F-all-c1 start_et="2026-10-12 20:13:28 EDT" exit=1 wall_s=257.0 log=logs/f2-F-all-c1.log 
m1-c2-v200-u2-putback-while-saving start_et="2026-10-12 20:17:26 EDT" exit=1 wall_s=306.4 log=logs/m1-c2-v200-u2-putback-while-saving.log 
f2-F-all-c2 start_et="2026-10-12 20:17:45 EDT" exit=0 wall_s=299.1 log=logs/f2-F-all-c2.log 
m1-c2-v200-u13-pull-while-saving start_et="2026-10-12 20:22:32 EDT" exit=1 wall_s=208.8 log=logs/m1-c2-v200-u13-pull-while-saving.log 
m1-c2-v200-u13-base-while-saving start_et="2026-10-12 20:26:01 EDT" exit=1 wall_s=219.2 log=logs/m1-c2-v200-u13-base-while-saving.log 
m1-c2-v200-u13-pull-unchecked start_et="2026-10-12 20:29:40 EDT" exit=1 wall_s=215.7 log=logs/m1-c2-v200-u13-pull-unchecked.log 
m1-c2-v200-u13-said-nothing-loaded start_et="2026-10-12 20:33:16 EDT" exit=1 wall_s=145.4 log=logs/m1-c2-v200-u13-said-nothing-loaded.log 
m1-c2-v200-u13-clash-while-saving start_et="2026-10-12 20:35:42 EDT" exit=1 wall_s=121.2 log=logs/m1-c2-v200-u13-clash-while-saving.log 
# folder batch f3 (F-folderA/B on c1) launched 2026-10-12 20:37:43 EDT
# repro r3 on c2 (c42be8e7) launched 2026-10-12 20:37:43 EDT
r3-locktest start_et="2026-10-12 20:37:43 EDT" exit=0 wall_s=1.7 log=logs/r3-locktest.log 
r3-PB-W start_et="2026-10-12 20:37:45 EDT" exit=0 wall_s=7.5 log=logs/r3-PB-W.log 
r3-PB-Wtick start_et="2026-10-12 20:37:52 EDT" exit=0 wall_s=6.9 log=logs/r3-PB-Wtick.log 
r3-PB-C1 start_et="2026-10-12 20:37:59 EDT" exit=0 wall_s=8.9 log=logs/r3-PB-C1.log 
r3-PB-C2a start_et="2026-10-12 20:38:08 EDT" exit=0 wall_s=10.1 log=logs/r3-PB-C2a.log 
r3-PB-C2b start_et="2026-10-12 20:38:18 EDT" exit=0 wall_s=13.5 log=logs/r3-PB-C2b.log 
r3-PB-NL start_et="2026-10-12 20:38:32 EDT" exit=0 wall_s=11.7 log=logs/r3-PB-NL.log 
r3-AD-W start_et="2026-10-12 20:38:43 EDT" exit=0 wall_s=11.2 log=logs/r3-AD-W.log 
r3-AD-Wtick start_et="2026-10-12 20:38:55 EDT" exit=0 wall_s=10.9 log=logs/r3-AD-Wtick.log 
r3-AD-C1 start_et="2026-10-12 20:39:05 EDT" exit=0 wall_s=10.5 log=logs/r3-AD-C1.log 
r3-AD-C2a start_et="2026-10-12 20:39:16 EDT" exit=0 wall_s=7.4 log=logs/r3-AD-C2a.log 
r3-AD-C2b start_et="2026-10-12 20:39:23 EDT" exit=0 wall_s=6.0 log=logs/r3-AD-C2b.log 
f3-F-folderA-c1 start_et="2026-10-12 20:37:43 EDT" exit=0 wall_s=112.6 log=logs/f3-F-folderA-c1.log 
r3-BR-W start_et="2026-10-12 20:39:29 EDT" exit=0 wall_s=7.5 log=logs/r3-BR-W.log 
r3-BR-Wtick start_et="2026-10-12 20:39:37 EDT" exit=0 wall_s=6.8 log=logs/r3-BR-Wtick.log 
r3-BR-C1 start_et="2026-10-12 20:39:44 EDT" exit=0 wall_s=5.4 log=logs/r3-BR-C1.log 
r3-BR-C2a start_et="2026-10-12 20:39:49 EDT" exit=0 wall_s=6.0 log=logs/r3-BR-C2a.log 
r3-BR-C2b start_et="2026-10-12 20:39:55 EDT" exit=0 wall_s=6.3 log=logs/r3-BR-C2b.log 
r3-BR-Wperm start_et="2026-10-12 20:40:02 EDT" exit=0 wall_s=5.5 log=logs/r3-BR-Wperm.log 
r3-BR-C1perm start_et="2026-10-12 20:40:07 EDT" exit=0 wall_s=4.8 log=logs/r3-BR-C1perm.log 
r3-BR-Wh start_et="2026-10-12 20:40:12 EDT" exit=0 wall_s=5.7 log=logs/r3-BR-Wh.log 
r3-BR-C1h start_et="2026-10-12 20:40:18 EDT" exit=0 wall_s=6.8 log=logs/r3-BR-C1h.log 
r3-BR-Wpermh start_et="2026-10-12 20:40:24 EDT" exit=0 wall_s=4.8 log=logs/r3-BR-Wpermh.log 
r3-BR-C2ah start_et="2026-10-12 20:40:29 EDT" exit=0 wall_s=4.2 log=logs/r3-BR-C2ah.log 
r3-BR-C2bh start_et="2026-10-12 20:40:33 EDT" exit=0 wall_s=4.4 log=logs/r3-BR-C2bh.log 
r3-PF-W start_et="2026-10-12 20:40:38 EDT" exit=0 wall_s=4.0 log=logs/r3-PF-W.log 
r3-PF-C1 start_et="2026-10-12 20:40:42 EDT" exit=0 wall_s=4.1 log=logs/r3-PF-C1.log 
r3-PF-C2a start_et="2026-10-12 20:40:46 EDT" exit=0 wall_s=4.2 log=logs/r3-PF-C2a.log 
r3-x-PB-Wcount start_et="2026-10-12 20:40:50 EDT" exit=0 wall_s=5.6 log=logs/r3-x-PB-Wcount.log 
r3-x-AD-Wcount start_et="2026-10-12 20:40:56 EDT" exit=0 wall_s=6.2 log=logs/r3-x-AD-Wcount.log 
r3-x-BR-Wcount start_et="2026-10-12 20:41:02 EDT" exit=0 wall_s=4.8 log=logs/r3-x-BR-Wcount.log 
r3-x-BR-Wreal start_et="2026-10-12 20:41:07 EDT" exit=0 wall_s=4.6 log=logs/r3-x-BR-Wreal.log 
r3-x-BR-Wrealtick start_et="2026-10-12 20:41:12 EDT" exit=0 wall_s=4.3 log=logs/r3-x-BR-Wrealtick.log 
r3-x-BR-C1real start_et="2026-10-12 20:41:16 EDT" exit=0 wall_s=4.9 log=logs/r3-x-BR-C1real.log 
r3-x-BR-Wrealcount start_et="2026-10-12 20:41:21 EDT" exit=0 wall_s=6.2 log=logs/r3-x-BR-Wrealcount.log 
r3-x-BR-Wrealh start_et="2026-10-12 20:41:27 EDT" exit=0 wall_s=8.6 log=logs/r3-x-BR-Wrealh.log 
r3-x-O4-tick start_et="2026-10-12 20:41:36 EDT" exit=0 wall_s=5.0 log=logs/r3-x-O4-tick.log 
r3-x-O4-tickh start_et="2026-10-12 20:41:41 EDT" exit=0 wall_s=4.6 log=logs/r3-x-O4-tickh.log 
r3-x-BR-Wrealtickcount start_et="2026-10-12 20:41:45 EDT" exit=0 wall_s=5.7 log=logs/r3-x-BR-Wrealtickcount.log 
r3-check start_et="2026-10-12 20:41:51 EDT" exit=0 wall_s=0.1 log=logs/r3-check.log 
r3-xcheck start_et="2026-10-12 20:41:51 EDT" exit=0 wall_s=0.1 log=logs/r3-xcheck.log 
f3-F-folderB-c1 start_et="2026-10-12 20:39:36 EDT" exit=0 wall_s=198.7 log=logs/f3-F-folderB-c1.log 
```

This attempt's bounded text and copy commands (`logs/bx.txt` from `rebuild2` on):

```
rebuild2 start_et="2026-10-12 19:39:34 EDT" exit=0 wall_s=4.05
mkentries start_et="2026-10-12 19:40:45 EDT" exit=0 wall_s=0.43
ins-mut-c1 start_et="2026-10-12 19:40:58 EDT" exit=0 wall_s=0.1
ins-mut-c2 start_et="2026-10-12 19:40:58 EDT" exit=0 wall_s=0.1
mcount-b0 start_et="2026-10-12 19:41:05 EDT" exit=0 wall_s=2.21
mcount-c1 start_et="2026-10-12 19:41:07 EDT" exit=0 wall_s=1.86
mcount-c2 start_et="2026-10-12 19:41:09 EDT" exit=0 wall_s=2.42
fails-f1u20b0 start_et="2026-10-12 19:41:32 EDT" exit=0 wall_s=0.07
mkmut-c1-v200-u20-wait-uncounted start_et="2026-10-12 19:41:48 EDT" exit=0 wall_s=0.18
mkmut-c1-v200-u20-failed-stays-counted start_et="2026-10-12 19:41:48 EDT" exit=0 wall_s=0.2
mkmut-c2-v200-u20-wait-uncounted start_et="2026-10-12 19:41:48 EDT" exit=0 wall_s=0.24
mkmut-c2-v200-u20-failed-stays-counted start_et="2026-10-12 19:41:49 EDT" exit=0 wall_s=0.21
mkmut-c2-v200-u30-base-whatever-on-screen start_et="2026-10-12 19:41:49 EDT" exit=0 wall_s=0.15
mkmut-c2-v200-u30-base-only-other-copy start_et="2026-10-12 19:41:49 EDT" exit=0 wall_s=0.19
mkmut-c2-v200-u30-unrecorded-said-after start_et="2026-10-12 19:41:49 EDT" exit=0 wall_s=0.24
mkmut-c2-v200-u30-recorded-said-unknown start_et="2026-10-12 19:41:49 EDT" exit=0 wall_s=0.18
mkmut-c2-v200-u2-putback-gen start_et="2026-10-12 19:41:50 EDT" exit=0 wall_s=0.26
mkmut-c2-v200-u2-putback-while-saving start_et="2026-10-12 19:41:50 EDT" exit=0 wall_s=0.2
mkmut-c2-v200-u13-pull-while-saving start_et="2026-10-12 19:41:50 EDT" exit=0 wall_s=0.16
mkmut-c2-v200-u13-base-while-saving start_et="2026-10-12 19:41:50 EDT" exit=0 wall_s=0.16
mkmut-c2-v200-u13-pull-unchecked start_et="2026-10-12 19:41:50 EDT" exit=0 wall_s=0.19
mkmut-c2-v200-u13-said-nothing-loaded start_et="2026-10-12 19:41:51 EDT" exit=0 wall_s=0.22
mkmut-c2-v200-u13-clash-while-saving start_et="2026-10-12 19:41:51 EDT" exit=0 wall_s=0.35
fails-f1u30b0 start_et="2026-10-12 19:42:00 EDT" exit=0 wall_s=0.11
clone-b0 start_et="2026-10-12 19:43:31 EDT" exit=0 wall_s=1.44
cpover-b0 start_et="2026-10-12 19:43:32 EDT" exit=0 wall_s=0.08
clone-c2 start_et="2026-10-12 19:43:32 EDT" exit=0 wall_s=0.91
cpover-c2 start_et="2026-10-12 19:43:33 EDT" exit=0 wall_s=2.62
diff-c1-board start_et="2026-10-12 19:44:21 EDT" exit=1 wall_s=0.08
diff-c2-board start_et="2026-10-12 19:44:21 EDT" exit=1 wall_s=0.04
diff-c2-board-2 start_et="2026-10-12 19:44:34 EDT" exit=1 wall_s=1.47
diff-c1-mutate start_et="2026-10-12 19:58:59 EDT" exit=1 wall_s=6.31
diff-c2-mutate start_et="2026-10-12 19:59:05 EDT" exit=1 wall_s=6.48
diff-c1-import start_et="2026-10-12 19:59:12 EDT" exit=1 wall_s=4.95
rebuild3 start_et="2026-10-12 20:06:06 EDT" exit=0 wall_s=10.35
mkmut2-c2-v200-u20-wait-uncounted start_et="2026-10-12 20:06:16 EDT" exit=0 wall_s=0.26
mkmut2-c2-v200-u20-failed-stays-counted start_et="2026-10-12 20:06:16 EDT" exit=0 wall_s=0.2
mkmut2-c2-v200-u30-base-whatever-on-screen start_et="2026-10-12 20:06:16 EDT" exit=0 wall_s=0.26
mkmut2-c2-v200-u30-base-only-other-copy start_et="2026-10-12 20:06:17 EDT" exit=0 wall_s=0.19
mkmut2-c2-v200-u30-unrecorded-said-after start_et="2026-10-12 20:06:17 EDT" exit=0 wall_s=0.2
mkmut2-c2-v200-u30-recorded-said-unknown start_et="2026-10-12 20:06:17 EDT" exit=0 wall_s=0.31
mkmut2-c2-v200-u2-putback-gen start_et="2026-10-12 20:06:17 EDT" exit=0 wall_s=0.28
mkmut2-c2-v200-u2-putback-while-saving start_et="2026-10-12 20:06:18 EDT" exit=0 wall_s=0.31
mkmut2-c2-v200-u13-pull-while-saving start_et="2026-10-12 20:06:18 EDT" exit=0 wall_s=0.34
mkmut2-c2-v200-u13-base-while-saving start_et="2026-10-12 20:06:18 EDT" exit=0 wall_s=0.25
mkmut2-c2-v200-u13-pull-unchecked start_et="2026-10-12 20:06:19 EDT" exit=0 wall_s=0.3
mkmut2-c2-v200-u13-said-nothing-loaded start_et="2026-10-12 20:06:19 EDT" exit=0 wall_s=0.16
mkmut2-c2-v200-u13-clash-while-saving start_et="2026-10-12 20:06:19 EDT" exit=0 wall_s=0.15
mcount2-c2 start_et="2026-10-12 20:06:20 EDT" exit=0 wall_s=2.35
cpover2-c2 start_et="2026-10-12 20:06:22 EDT" exit=0 wall_s=0.14
diff-c2-import start_et="2026-10-12 20:07:25 EDT" exit=1 wall_s=5.07
diff-c1-import-2 start_et="2026-10-12 20:07:31 EDT" exit=1 wall_s=3.52
fails-m1a start_et="2026-10-12 20:18:03 EDT" exit=0 wall_s=0.09
fails-f2 start_et="2026-10-12 20:28:30 EDT" exit=0 wall_s=7.01
fails-f2c1 start_et="2026-10-12 20:28:37 EDT" exit=0 wall_s=0.14
fails-m1b start_et="2026-10-12 20:30:55 EDT" exit=0 wall_s=0.19
fails-m1c start_et="2026-10-12 20:37:50 EDT" exit=0 wall_s=0.05
fails-m1d start_et="2026-10-12 20:37:50 EDT" exit=0 wall_s=0.06
fails-f3 start_et="2026-10-12 20:43:02 EDT" exit=0 wall_s=0.07
```

## PIDs

`pids.txt` has one line per process: `<pid> <ET time> <process> <label> :: <command>`. It was started by the earlier
builder at 5:58:25 PM ET and appended to by this one. This attempt appended lines 267–569 (303 lines). They cover 152 bounded commands (93 node or npm runs, and 59 text,
copy, diff and hash commands), each with its `timeout` PID and its child. A child shows as `gone` where it ended
before `ps` looked: 26 lines. The other 7 lines are the wrapper PIDs (`batch.sh` ×4, `suites.sh` ×2, `after-f1.sh`).
Nothing was killed.

## Deviations, stated plainly

- **Read-only commands outside the wrapper.** In this attempt, read-only shell commands ran without the
  `setsid -w timeout` wrapper, with no PIDs recorded: `ls`, `cat`, `grep`, `sed -n`, `head`/`tail`, `diff -q`, `wc`,
  `git log`, `git status` and `git hash-object` (in this directory, the base, and orbit-board's ledger and log). So did a
  few short `python3 -I` readers and summaries.
- **Small writes outside the wrapper.** Some small text writes also ran unwrapped and finished at once:
  - two `sed` copies of the probe's literal checks (`check-c42be8e7.mjs` and `xcheck-c42be8e7.mjs`, the board id only);
  - the heredocs that wrote the scripts in `bin/`;
  - two in-place `python3 -I` edits of `bin/after-f1.sh` and `bin/rebuild-suites2.sh`, made before either ran;
  - `chmod`, `mkdir` and `ln -s` in this directory;
  - the edits made with the editor tool: the c2 board, the U30 block and the drafts.

  Every node, npm, copy and diff run that produced evidence was bounded.
- **Runs alongside each other.** f2 and m1 ran together, and the c2 suites ran alongside them. A flaky catch would show as
  unexpected failing checks; every mutant's failing list was read and is the one expected (table above).
- **Records left unchanged.** The f1 c2 rows record two earlier c2 boards. F-u20/F-u30 ran on `8fea44af`; F-all and
  F-folder ran on `c42be8e7`. f2 re-ran F-u20, F-u30 and F-all on `c42be8e7`. Nothing was overwritten.

## Not done (plainly)

- The full audit-import and audit-board were not run (the lead's). Nor were mutate.mjs and `playwright install`.
- **Real Chromium was not run with these boards.** The lock semantics rest on the U20 probe's earlier Chromium comparison
  of the same mock. The folder paths rest on jsdom and the folder mock.
- **Not covered by a test:**
  - ✍ Take the pen, Load theirs or Save yours over theirs as the operation that waits;
  - a tab closed while it holds the lock;
  - the first waiting Save's silence (O1);
  - a non-quiet Connect in the U30 case, which says nothing about the folder's copy (as before);
  - with a copy recorded and the folder's copy older than it, the unchanged words "after the copy you are working from";
  - a folder copy stamped to the millisecond as the screen but different (recorded, as before).
- **Possible overlap with the ADOPT track (U24/U29/U31) in this round.** That track touches the adoption paths, and its
  builders also edit `driveStorePull`. This change was made on the base, not on top of theirs. Applying both needs a
  rebase check.
- **Nothing was committed or pushed.** NEXT-VERSION.md and the ledger are drafted only, in
  `drafts/NEXT-VERSION-U20-U30.txt`, copied below.

## Drafts for the lead

The same text as `drafts/NEXT-VERSION-U20-U30.txt` (`git hash-object` in the identities list):

```
DRAFT for the lead (not applied anywhere). Two entries for NEXT-VERSION.md, under "### v2.00", after the U14 entry and
before "- **Unresolved after R1–R5 (11 Oct).**", in the style of the U13 / U1 / U14 entries. <n> marks a count the lead
re-reads from the committed block if anything changes before commit.

- **U20 — a save waiting for another tab's save is under way** (the lead's decision under Brad's word of 12 Oct, about
  5:30 PM ET: "Don't wait for me. Let's keep pressing throughout to get this next version published."). A save waits for
  the 'orbit-save' Web Lock, so that one save runs at a time across this browser's tabs. It was counted as under way only
  once it held the lock. While it waited for another tab's save, ↶ Put back (U2) and the folder's refresh (U13) took it for
  no save at all: Put back went ahead under it, a refresh loaded a newer copy under it, and a refresh with nothing recorded
  for the folder took the folder's copy as the one the work came from. The waiting save then wrote over that copy without
  asking. With a history copy kept less than ten minutes before, the copy written over was kept only as a recent copy, and
  one more Save removed it: it was in no copy the board could reach. Now a save is counted from the moment it is asked for,
  waiting included, until it has finished, however it ends: saved, refused, failed, thrown, or its lock request refused.
  - **What users may see:** while a Save waits for another tab's save, ↶ Put back is refused in U2's words ("⏳ Not put back:
    a save was under way …"), and a Connect says the folder's copy was not loaded, in U13's words. A second Save asked
    meanwhile says "⏳ A save is already under way — this one runs as soon as it finishes." Once the save has finished,
    both work as before.
  - **Test:** audit-import "v2.00 (U20) — the Web Locks stand-in behaves as the API does" (19 checks). This is the U20
    probe's lock mock, ported as the suite helper `webLocks()`, with its own tests: first come first served across tabs, a
    rejection and a throw letting go, let go before request() settles, independent names, ifAvailable, shared and
    exclusive, query and a closing tab, what it does not model refused, and 300 seeded requests. Then audit-import
    "v2.00 (U20) — a save waiting for another tab's save is under way" (59 checks): two tabs of one browser share one lock
    manager, and the second tab's 💾 Save waits for the first tab's held save. It covers ↶ Put back, a refresh of a newer
    copy, and Live view's ↻ Refresh now with nothing recorded, with and without a history copy kept minutes before; after
    the refresh it checks Save yours over theirs and one more Save. It also covers the screen exactly the folder's copy.
    Controls: a second Save waiting behind this tab's own save; the waiting save counted by the harness itself (the
    uncounted wait alone was the cause); the count coming back down when the autosave throws, when the lock request is
    refused and when asking for it throws; and two Saves waiting, counted as two. 20 checks fail on the board before the
    change; every control passes on both.
  - **Mutations:** `v200-u20-wait-uncounted`, `v200-u20-failed-stays-counted`; each caught by the focused block (full-suite
    sensitivity runs in the final-tree queue).
  - **Not covered:** the first waiting Save still gives no sign that it waits (the U20 probe's O1). This board was not run
    in real Chromium: the lock semantics were checked there by the U20 probe. Not run as the waiting operation: ✍ Take the
    pen, Load theirs and Save yours over theirs. Not run: a tab closed while holding the lock (by the API, it lets the lock
    go). A refresh that records the folder's copy as the base with no second tab is U30, next.

- **U30 — a refresh takes the folder's copy as the one the work came from only when it is what is on screen** (the lead's
  decision, as for U20). It applies with nothing recorded for the folder: an opening that found no copy there and a
  colleague's or another machine's save after it, or a browser that never kept a record. A refresh that found the folder's
  copy not newer than the screen took it as the one the work on screen came from, "as it always was" (v1.89), whatever was
  on screen. The next 💾 Save then wrote the work on screen over that copy without asking. So did the Live timer's
  autosave, one tick after it had said "Nothing was written" and offered the choice. With a history copy kept less than
  ten minutes before, the copy written over was kept only as a recent copy, and one more Save removed it. No second tab
  was needed; U20 was its two-tab form. Now the refresh records the folder's copy only when it is what is on screen: the
  same stamp, as every change stamps the board anew. Otherwise it records nothing and says nothing, and Save asks: Load
  theirs (your work kept aside), or Save yours over theirs (theirs kept in the folder's history as a spaced copy, whatever
  the spacing). With nothing recorded, the question no longer says that theirs was saved "after the copy you are working
  from", which nothing recorded can tell. It says that this browser has no record of which copy in the folder, if any,
  the work on screen came from.
  - **What users may see:** with nothing recorded and other work on screen, 💾 Save and every autosave tick say
    "⛔ Alice saved O&M FY27 to the shared folder 2 minutes ago, and this browser has no record of which copy in the folder,
    if any, the work on screen came from. Nothing was written. Load theirs … · Save yours over theirs …" until one is
    chosen. Until now the board wrote over the folder's copy without asking. A board showing exactly the folder's copy is
    recorded as before and saves with no question. With a copy recorded, the words are unchanged.
  - **Test:** audit-import "v2.00 (U30) — a refresh takes the folder’s copy as the base only when it is on screen" (48
    checks):
    - the Live timer alone in one tab, with and without a history copy kept minutes before: tick 1, tick 2 and 💾 Save
      each ask and write nothing, and the words are checked; then Save yours over theirs, one more Save and a reopen,
      with the folder's copy kept as a spaced history copy throughout;
    - ↻ Refresh now, then Save;
    - Save, then a refresh, then Save;
    - a second tab whose Save waits while the Live timer ticks twice: U20's case, with the first tick's own refresh after
      the wait;
    - controls: the screen exactly the folder's copy, recorded and saved with no question (and during a save, U13's rule
      holds); the first save of a new board into an empty folder; an ordinary refresh with nothing unsaved; and the
      recorded case's words.
    23 checks fail on the board before U20, and 21 on the U20 board; every control passes on all three.
  - **Mutations:** `v200-u30-base-whatever-on-screen`, `v200-u30-base-only-other-copy`, `v200-u30-unrecorded-said-after`,
    `v200-u30-recorded-said-unknown`; each caught by the focused block. U13's case (3c) has other work on screen, which this
    rule now stops before U13's guard is reached. So on this board, U13's `v200-u13-base-while-saving` and
    `v200-u13-clash-while-saving` are caught by the U30 and U20 blocks' same-copy cases.
  - **Not covered:** a different folder copy stamped to the same millisecond as the screen (clock skew) is recorded, as
    before. The ⛔ line repeats at every autosave tick until Load theirs or Save yours over theirs is chosen. A non-quiet
    Connect in this case says nothing about the folder's copy, as before. With a copy recorded, the words "after the copy
    you are working from" are still said, unchanged, where the folder's copy is older than the recorded one. Real Chromium
    was not run.


OPTIONAL replacements elsewhere in the v2.00 section (each line is now stale once U20 lands; principle 4):

  U2 entry (2 of 2), its last bullet:
    old: "  - **Not covered:** a save waiting for another tab's Web Lock is not counted as under way until it starts."
    new: "  - **Not covered:** a save waiting for another tab's Web Lock was not counted as under way until it started (U20,
         below, counts it)."
  U13 entry, its "Not covered" bullet:
    old: "a save waiting for another tab's Web Lock is not counted (U20);"
    new: "a save waiting for another tab's Web Lock was not counted (U20, below, counts it);"


"Unresolved after R1–R5 (11 Oct)." -- U20 and U30 have no line of their own there. Two new lines, after the U14 line:

  - **U20: built as its own commit** (the lead's decision under Brad's word of 12 Oct, about 5:30 PM ET, to keep pressing):
    a save waiting for another tab's Web Lock is counted as under way from the moment it is asked for, until it ends
    (above). U2's refusal and U13's two guards now see it.
  - **U30: built as its own commit after U20** (the same decision): a refresh records the folder's copy as the one the
    work came from only when it is what is on screen; otherwise Save asks, and with nothing recorded it says so rather than
    that theirs came after (above). No copy is written over unasked, and none is left only as a recent history copy.

  and, in the existing lines (optional):
    U2 line:  "Its separate reopening and adoption findings stay open in the ledger (U15–U20)."
          ->  "Its separate reopening and adoption findings stay open in the ledger (U15–U19); U20 is built (below)."
    U13 line: "stay open in the ledger (U16–U18, U20)"  ->  "stay open in the ledger (U16–U18; U20 is built, below)"


UNRESOLVED-LEDGER.md -- text to APPEND to the Status cell of each row (the lead fills <sha>, <time> and confirms blobs):

  Row U20 (the main table, "| U20 | **A save waiting for another tab's Web Lock …"):
    " **Decided by the lead, 12 Oct (Brad, about 5:30 PM ET: "Don't wait for me. Let's keep pressing throughout to get
    this next version published."):** count a save from the moment it is asked for. **COMMITTED as `<sha>` (12 Oct, <time>
    ET)**: board `83b87782`, audit-import `776c6680`, mutate `6b4c83d6`. `saveSerial` counts a save in `_saveBusy` when it
    is asked for, waiting for the lock included, and uncounts it once it has settled, however it ends (saved, refused,
    failed, thrown, lock request refused). U2's put-back refusal and U13's two guards now see a waiting save. Focused blocks
    78 checks (the lock stand-in's 19 self-tests and 59 on the board): 20 fail before, all pass after. Two mutations caught
    by the block. The U20 probe's 26 scenarios and the checker's 11 re-run on this board: the U20 harm checks pass; what
    stays open on this board alone is U30 (BR-C2a/C2ah/C2b/C2bh, BR-Wtick's and BR-Wrealtick's next Save, O4-tick/tickh).
    Full audit-import and full-suite sensitivity: in the final-tree queue."

  Row U20 (the triage table, "| U20 | P2 (P1 if reproduced) | Two tabs: …"):
    " **COMMITTED as `<sha>` (12 Oct, <time> ET)**; see the U20 row above."

  Row U30 ("| U30 | **A refresh that records the folder's copy as the base before a Save …"):
    " **Decided by the lead, 12 Oct (as U20).** **COMMITTED as `<sha>` (12 Oct, <time> ET)**, after U20: board `c42be8e7`,
    audit-import `e0d4186b`, mutate `54c7d928`. `driveStorePull` records the folder's copy as the base only
    when it is what is on screen (`theirs===ours`); otherwise it records nothing and says nothing, and Save asks.
    `driveClashSay`, with nothing recorded, says this browser has no record of which copy in the folder, if any, the work on
    screen came from, instead of "after the copy you are working from". Focused block 48 checks: 23 fail before U20, 21 on
    the U20 board, all pass after. Four mutations caught by the block. U13's `v200-u13-base-while-saving` and
    `v200-u13-clash-while-saving` are still caught on this board, by the U30 and U20 blocks' same-copy cases. The U20 probe
    and checker re-run on this board: every U20 and OUT check passes, and O4 passes but for its two "observed mechanism"
    checks. Full audit-import and full-suite sensitivity: in the final-tree queue."
```

---
README finalised at 8:43 PM ET on Mon 12 Oct 2026 (read with `TZ=America/New_York date`). The last bounded run ended at 8:42:54 PM ET (batch f3 and the r3 probe).

---

# Fix round (13 Oct 2026)

Builder's fix round after the two round-1 reviews: `verify-money-r1/` (lens money/data loss, `wfstate/verify_u20u30_r1_money.json`)
and `verify-tests-r1/` (lens tests). Both said **sound-with-issues**. Times are Eastern, each read with
`TZ=America/New_York date`. This round started at 12:18 PM ET on Tue 13 Oct.

**Nothing is committed or pushed.** Nothing in `/home/user/orbit-board` or `/home/user/orbit-ui` was edited, staged or committed;
orbit-board was only read (`git log`, `git show HEAD:…`, the ledger rows) and cloned with `git clone --shared` into `clones/c2f`.
Its HEAD is now `f3f4b3d` (records-only commits since `7ee498a`), and its product blobs are still the base's: board `fce8a391`,
audit-import `4aba2506`, audit-board `a7c575e5`, mutate.mjs `cbc6defc` (read with `git show HEAD:<path> | git hash-object --stdin`).

**What was kept from an earlier attempt of this fix round: nothing, because there was none.** Before starting I looked for
fix-round work after the build: no copy had changed since the builder's recorded blobs (c1 `83b87782`, c2 `c42be8e7`), no file
of mine was newer than 11:13 PM ET on 12 Oct apart from the two reviews' own directories and `wfstate/`, and README.md had no
"Fix round" section. The two reviews' directories (`verify-money-r1/`, `verify-tests-r1/`) were read, never written.

**Round 1 is kept as it was, and is superseded where this section says so.** `c1/`, `c2/`, `blocks/u20.mjs.txt`,
`blocks/u30.mjs.txt`, `mut/entries-u*.txt`, `drafts/NEXT-VERSION-U20-U30.txt`, the round-1 logs and outputs are unchanged, so
the reviews' references still resolve. **The proposed commits are now `c1f/` and `c2f/`**, below; round 1's commit list
(c1 `83b87782`/`776c6680`/`6b4c83d6`, c2 `c42be8e7`/`e0d4186b`/`54c7d928`) and its drafts are **superseded**.

## The two commits now (cumulative copies; diffs in `fr/diffs/`)

| # | subject | copy | board | audit-import | mutate (`mutate.mjs.txt`, text only) |
|---|---|---|---|---|---|
| base | `7ee498a` archive (product `d66dd60`) | `b0/` | `fce8a391` | `4aba2506` | `cbc6defc` |
| 1 | v2.00 U20: a save (or Load theirs) waiting for another tab's save is under way | `c1f/` | `83b87782` (= round 1) | `d7d41c6a` | `6b4c83d6` (= round 1) |
| 2 | v2.00 U30: a refresh takes the folder's copy as the base only when it is on screen; with nothing recorded, nothing on that route says theirs came after | `c2f/` | `84cf2bf4` | `3a34d922` | `d174d05d` |

Full ids: c1f audit-import `d7d41c6accb997073280c9a172fa27ae1feab7c0`; c2f board `84cf2bf4ef12f2e6dbef255503c4c2ecf23034e2`;
c2f audit-import `3a34d922731dbb5c67dc0de656cd567250793da1`; c2f mutate `d174d05da7e5efc45e3478b192605a02899d7dc7`. Every other
file of each copy is byte-identical to the base (`diff -rq`): only the board, audit-import and mutate.mjs.txt differ.

Diffs (`fr/src/mkdiffs.sh`; removed / added lines, blob):

| diff | what | removed | added | blob |
|---|---|---|---|---|
| `c1f-board.diff` | commit 1 board vs base (= round 1's `diffs/c1-board.diff`) | 1 | 8 | `012531ae` |
| `c1f-audit-import.diff` | commit 1 suite vs base | **0** | 531 | `9e04c6b4` |
| `c1f-mutate.diff` | commit 1 entries vs base (= round 1) | **0** | 7 | `4031197f` |
| `c2f-board.diff` | commit 2 board vs c1f | 5 | 22 | `3e8fc2c3` |
| `c2f-audit-import.diff` | commit 2 suite vs c1f | **0** | 369 | `ea034051` |
| `c2f-mutate.diff` | commit 2 entries vs c1f | **0** | 39 | `692000ae` |
| `c1-to-c1f-audit-import.diff` | what this round changed in commit 1's suite | 7 | 36 | `cdea6a02` |
| `c2-to-c2f-board.diff` | what this round changed in commit 2's board | 4 | 9 | `4928acdf` |
| `c2-to-c2f-audit-import.diff` | what this round changed in both suite blocks | 14 | 195 | `952aa13f` |
| `c2-to-c2f-mutate.diff` | what this round added to commit 2's entries | **0** | 26 | `cfa7358b` |

The lines "removed" against round 1 are round 1's own new check labels (guard labels added) and nothing older; against the base
and against the previous copy, every suite and mutate diff is additions only. The blocks are `blocks/u20f.mjs.txt` (`456290a6`)
and `blocks/u30f.mjs.txt` (`eb891f9c`), made from round 1's blocks by `fr/src/mk-u20f.py` and `fr/src/mk-u30f.py` (exact
replacements, each asserted to match once) and inserted as before (`fr/src/rebuild-fr.sh`).

## The findings, and what was done with each

| finding | lens | decision | where |
|---|---|---|---|
| **M1** (must-fix): U30's tests reach the rule only through quiet refreshes with work typed in the same session; four wrong forms of the rule passed every check | tests | **Taken.** The reviewer's cases (6)/(6h)/(7) added verbatim (`proposal/u30-cases-6-7.mjs.txt`, `55f34f65`), and its three entries verbatim (`proposal/u30-entries.txt`, `83772e2e`). The fourth survivor (`ownUnsaved` rule) run as my own mutant. | U30 block, mutate |
| **MF1** (must-fix): on the route U30 opens (a board file handed over, newer than the folder's copy), ↶ Put back says "saved after it" and Load theirs refused for kept work says "a newer copy", both false | money | **Taken, with one change to the reviewer's diff** (below): its call-site edit made the existing entry `kept-theirs-wrong-word` stop matching, which the hard rule forbids; the no-record refusal is a separate line before the old one, left byte for byte. Tests (8)/(9) port the reviewer's probes (C)/(C2) with the words checked literally; controls (8c), (8d), (9c) pin the unchanged words; 5 entries. | board, U30 block, mutate |
| S1: 18 new non-control checks pass on the base and are not labelled | tests | **Taken.** Labelled "(a GUARD: it passes before this change too)", defined in each block; a script (`fr/src/labels.py`) checks the rule on the base output: every CONTROL and GUARD passes there, every other check fails. | both blocks |
| S2: U13's two mutations are now caught only by U20 (4) / U30 (5b) | tests | **Taken**: drafted as a replacement of the U13 entry's "Mutations" bullet, in commit 2. | drafts (2b) |
| S3: U2's and U13's "Not covered" lines become false once U20 lands | tests | **Taken**: the replacements are now part of commit 1, not optional. | drafts (1b) |
| SF: round 1's finding 4 ("ADOPT also edits driveStorePull") is wrong; the two tracks conflict on `driveClashSay` | money | **Corrected**; a rebase note gives the three-case merged wording and the entries that stop matching, and adds that MF1's two lines need the same three cases once ADOPT's `loadedNotSaved` lands. | drafts (end) |
| SF: U20 draft "What users may see" overstates what a Connect says | money | **Reworded**: only a newer copy is said not loaded; a copy no newer says nothing and records nothing. | drafts (1a) |
| SF: U20 draft says the board was not run in real Chromium | money | **Reworded**, citing the review's run on `c2f`'s identical `saveSerial`; and re-run here on `c2f` (below). | drafts (1a) |
| SF: U30 "Unresolved" line is wider than U30 | money | **Scoped**: "In this case …", naming U29 as separate. | drafts (2c) |
| SF: if MF1 is taken, U30's entry gains the lines and ids | money | **Done.** | drafts (2a) |
| minor: Load theirs as the waiting operation (probe E) | money | **Added as U20 case (7)**; it fails on the base and passes on c1f/c2f. U2's words in that case ("a save was under way") are listed, not changed (they are U2's existing checks). | U20 block |
| minor: the per-year form of U30 (probe D) | money | **Added as U30 case (10)**. | U30 block |
| minor: Save yours over theirs holds the lock across its dialog; a folder copy with no stamp | money | Listed under Not covered in the drafts. No change. | drafts |
| minor: the `v200-u20-wait-uncounted` find spans 11 lines; U20 (5b) double counts | tests | No change: mcount reports a broken find, and (5b) reads `> 0`. | — |

### The board change (commit 2), exactly (`fr/diffs/c2-to-c2f-board.diff`)

```diff
@@ -6937,11 +6937,12 @@
 // The newer copy was not loaded, because earlier work is already kept aside (v1.95, item 50).
-function keptOccupiedMsg(by, ts, from){
+// v2.00 (U30): `unknown` -- nothing recorded for the folder, so there is no telling that their copy is the newer one.
+function keptOccupiedMsg(by, ts, from, unknown){
   const k=keptCopy(), m=(k&&k.meta)||_keptMeta||{};
-  return '⚠ <b>'+esc(by||'someone')+'</b> saved a newer copy to '+esc(from)+(ts? ' ('+esc(fmtTs(ts))+')' : '')
+  return '⚠ <b>'+esc(by||'someone')+'</b> saved '+(unknown? 'a copy' : 'a newer copy')+' to '+esc(from)+(ts? ' ('+esc(fmtTs(ts))+')' : '')
     +', but this browser already keeps earlier work aside'+(m.t? ' (kept '+esc(fmtTs(m.t))+')' : '')
-    +' and holds new work besides. Kept work is never replaced, so the newer copy was <b>not loaded</b> and nothing was lost. '
+    +' and holds new work besides. Kept work is never replaced, so '+(unknown? 'their' : 'the newer')+' copy was <b>not loaded</b> and nothing was lost. '
@@ -6992,8 +6993,10 @@
   persist(); _saveGen++; DIRTY=true; render();
+  // v2.00 (U30): with nothing recorded for the folder there is no telling that their copy came after the work put back.
+  const after=(k.meta.why!=='folder') || !!driveBaseOf(mySlug());
   setStat('↶ <b>Put back</b> the work kept aside on '+esc(fmtTs(k.meta.t))+'. 💾 Save will ask before it writes over '
-    +esc(keptWhere(k.meta))+', which '+esc(k.meta.by||'someone')+' saved after it.'
+    +esc(keptWhere(k.meta))+', which '+esc(k.meta.by||'someone')+(after? ' saved after it.' : ' saved; this browser has no record of which copy there, if any, this work came from.')
@@ -27014,6 +27017,8 @@
     kept=keepAside(MS, {why:'folder', by:by, ts:theirs}, baseGet());
+    // v2.00 (U30): with nothing recorded for the folder there is no telling that theirs is the newer copy.
+    if(kept==='occupied' && !driveBaseOf(ap)){ setStat(keptOccupiedMsg(by, theirs, 'the shared folder', true)); render(); return false; }
     if(kept==='occupied'){ setStat(keptOccupiedMsg(by, theirs, 'the shared folder')); render(); return false; }
```

- The first two hunks are the money review's tested proposal (`verify-money-r1/diffs/proposal-c2fix2-words.diff`), plus one
  comment line on the new parameter.
- **The third hunk differs from the proposal, on purpose.** The proposal changed the call on the existing line to pass
  `!driveBaseOf(ap)`. That line is the whole `find` of the existing entry `kept-theirs-wrong-word`
  (`mutate.mjs.txt` line 2556 at the base), so mcount on the proposal's text gave 1341 of 1342 entries matching, with
  `kept-theirs-wrong-word` missing. The hard rule is that every existing entry still matches exactly once, so the existing line
  is left byte for byte and the no-record refusal is one new line before it. Same behaviour; the existing mutant (deleting the
  old line) is still caught on c2f, because v1.95's "folder theirs" case runs with a copy recorded (run below).
- `keptOccupiedMsg`'s other four callers pass three arguments, so their words are unchanged. `keptPutBack`'s words change only
  for work kept aside from the folder (`why==='folder'`) with nothing recorded once its own record is put back.

### The suite changes

**Commit 1 (U20 block, `blocks/u20f.mjs.txt`)**: 84 checks (19 stand-in self-tests + 65 board checks; round 1 had 78).
- **(7) Load theirs while another tab's save holds the lock** (6 checks; the money review's probe E): B's Save has asked; B
  presses Load theirs while tab A's save holds the lock. It waits and is counted (`_saveBusy` 1); ↶ Put back is refused and
  changes nothing; once A lands, Load theirs runs (N on screen and recorded, B-EDIT kept aside, nothing under way); the stand-in
  is sane. The kept slot that Put back would act on is made by the harness (`keepAside`), and emptied by the harness before
  Load theirs runs; that is said in the case's comment.
- **GUARD labels (S1)**: the stand-in sanity check (`SANE`, in every case), (3)'s Save yours over theirs and next Save when there
  is no history copy, (6a)–(6c)'s outcome checks and (6d)'s landing check.

**Commit 2 (U30 block, `blocks/u30f.mjs.txt`)**: 89 checks (round 1 had 48).
- **(6)/(6h) a reopen with unsaved work** and **(7) a board saved to its own file** (the tests review's text, verbatim; 20 checks).
- **(8) a board file handed over, newer than the folder's copy**: Save asks (the words for nothing recorded); Load theirs;
  ↶ Put back, whose line is checked against a literal pattern (`PUT_UNREC`) and must not say "saved after it"; Save asks again.
- **(8c) CONTROL**, a copy recorded: the put-back line says "saved after it" (`PUT_REC`).
- **(8d) CONTROL**, work kept aside from a board file with nothing recorded for the folder: the put-back line keeps its old
  words for the file (`PUT_FILE`). It catches a wrong form of MF1 that drops the `why` test.
- **(9)** the same as (8) with other work kept: Load theirs refused, its words checked literally (`OCC_UNREC`: "a copy", "their
  copy"), and "newer" not said. **(9c) CONTROL**, a copy recorded: "a newer copy", as always (`OCC_REC`).
- **(10) another year** (the money review's probe D): FY28 saved elsewhere and never loaded here; ↻ Refresh now on FY28 records
  nothing; Save on FY28 asks.
- **GUARD labels (S1)**: (1)'s copy-reached check and `chooseMine`'s three checks when there is no history copy (in (1) and
  (6)), (3)'s first Save, and (4)'s stand-in check.
- Every expected value is a hand-written literal (patterns included); board helpers are used for observed values only.

### The new mutation entries (commit 2; `mut/entries-u30-fr.txt`, `a4cb8be5`)

Inserted before the R3 line, after round 1's U30 entries (`c2-to-c2f-mutate.diff`, additions only), generated by
`fr/src/mkentries-fr.py`, which asserts every find occurs exactly once in the c2f board:
- the tests review's three, verbatim: `v200-u30-unsaved-this-session-only` (`DIRTY`), `v200-u30-quiet-refresh-only`
  (`&& quiet`), `v200-u30-unsaved-only` (`DIRTY || _baseDirty`);
- `v200-u30-putback-said-after` (the put-back words always "saved after it"), `v200-u30-putback-said-unknown` (`after=false`),
  `v200-u30-putback-file-unknown` (the `why` test dropped), `v200-u30-occupied-said-newer` (the new line deleted),
  `v200-u30-occupied-said-unknown` (the new line's record test dropped).

The exact text inserted (`mut/entries-u30-fr.txt`):

```
  // v2.00 (U30): the refresh's rule keyed on anything but the stamp misses a reopen, a Connect, or a board saved to its own file.
  { id: "v200-u30-unsaved-this-session-only", area: "driveStorePull", what: "the refresh's rule keyed on this session's unsaved flag (DIRTY) instead of the stamp: after a reopen with unsaved work, the opening's own connect takes the folder's copy as the one the work came from, and the next Save writes over it without asking (with a history copy kept minutes before, it is gone after one more Save)",
    find: "    if(!base && theirs!==ours) return false;\n",
    repl: "    if(!base && DIRTY) return false;\n" },
  { id: "v200-u30-quiet-refresh-only", area: "driveStorePull", what: "only the quiet refresh (the Live timer, ↻ Refresh now) is stopped: a Connect, or the opening's own connect after a reopen, still takes the folder's copy as the one the work came from, and the next Save writes over it without asking",
    find: "    if(!base && theirs!==ours) return false;\n",
    repl: "    if(!base && theirs!==ours && quiet) return false;\n" },
  { id: "v200-u30-unsaved-only", area: "driveStorePull", what: "the rule keyed on unsaved work (this session's or this browser's record) instead of the stamp: a board saved to its own file, which is not the folder's copy, takes that copy as the one the work came from, and the next Save writes over it without asking",
    find: "    if(!base && theirs!==ours) return false;\n",
    repl: "    if(!base && (DIRTY || _baseDirty)) return false;\n" },
  // v2.00 (U30): with nothing recorded, the lines after Save's question (↶ Put back, and Load theirs refused for work already kept) say no order they cannot know.
  { id: "v200-u30-putback-said-after", area: "keptPutBack", what: "with nothing recorded for the folder, ↶ Put back says the folder's copy was saved after the work put back -- a board file handed over can be newer than that copy, and nothing recorded can tell",
    find: "(after? ' saved after it.' : ' saved; this browser has no record of which copy there, if any, this work came from.')",
    repl: "' saved after it.'" },
  { id: "v200-u30-putback-said-unknown", area: "keptPutBack", what: "with a copy recorded, ↶ Put back says there is no record of which copy the work came from, though there is, and no longer says theirs was saved after it",
    find: "  const after=(k.meta.why!=='folder') || !!driveBaseOf(mySlug());\n",
    repl: "  const after=false;\n" },
  { id: "v200-u30-putback-file-unknown", area: "keptPutBack", what: "work kept aside from a board file, put back with nothing recorded for the folder, is said to come from no known copy, where it always said the file was saved after it",
    find: "  const after=(k.meta.why!=='folder') || !!driveBaseOf(mySlug());\n",
    repl: "  const after=!!driveBaseOf(mySlug());\n" },
  { id: "v200-u30-occupied-said-newer", area: "_driveResolveRun", what: "with nothing recorded, Load theirs refused for work already kept calls the folder's copy “a newer copy”, which nothing recorded can tell",
    find: "    if(kept==='occupied' && !driveBaseOf(ap)){ setStat(keptOccupiedMsg(by, theirs, 'the shared folder', true)); render(); return false; }\n",
    repl: "" },
  { id: "v200-u30-occupied-said-unknown", area: "_driveResolveRun", what: "with a copy recorded, Load theirs refused for work already kept calls the folder's copy “a copy”, no longer “a newer copy”",
    find: "    if(kept==='occupied' && !driveBaseOf(ap)){",
    repl: "    if(kept==='occupied'){" },
```

**mcount (text only)**: base 1328/1328, c1f 1330/1330, c2f 1342/1342 entries match exactly once; none missing, multiple or
unparsed (`fr/out/mcount-*.json`).

### The six principles, for the fix round

1. **Never lose any copy.** M1's cases show, on three more real routes (a reopen's own connect, a board saved to its file,
   another year), that the folder's copy is never written over unasked and stays a spaced history copy through Save yours over
   theirs, one more Save and a reopen. The word fix changes words only; nothing is kept or written differently.
2. **Refuse or ask rather than guess.** With nothing recorded, the put-back line and the kept-work refusal no longer guess an
   order of saves; they say what is known.
3. **Money and exports.** Untouched: the change is three status lines and the refresh rule. The suites that cover money and
   exports were re-run on c2f (below).
4. **Every word stays true.** MF1's two lines are true on the route U30 opens, and unchanged where a copy is recorded or the
   work came from a file (controls (8c), (8d), (9c)). The drafts' three overstatements are corrected, and U2's and U13's lines
   that U20 makes false are replaced in the same commits.
5. **Smallest change.** Board: one parameter, one conditional phrase, one boolean and one guarded line; commit 1's board is
   unchanged.
6. **Every existing check, fixture and expected value preserved.** No existing line of any suite or of `mutate.mjs` was edited
   (diffs above: additions only against the base and the previous copy). Every existing entry still matches exactly once; the
   one the review's proposal would have broken (`kept-theirs-wrong-word`) is kept matching by placing the new line beside it,
   and is still caught. No existing expectation had to change: **none**.

## Fix-round results

Harnesses are built verbatim from the copies' own suites by `bin/mkfocused-multi.py` (`fr/src/rebuild-fr.sh`), run by
`bin/runner.mjs` (`e835140a`) through `bin/frun.sh` → `bin/run.sh` (`setsid -w timeout -k 10 600`, the lock checked, PIDs
recorded, every check, verdict and value written to `out/<label>.checks.jsonl`):

| harness | blob | what |
|---|---|---|
| G-u20 | `058f09f0` | the two U20 scenarios (stand-in self-tests + U20), from c1f's suite |
| G-u30 | `acf8e24f` | the U30 scenario, from c2f's suite |
| G-all | `f997a9cc` | U2 ×2, U13, U20 ×2, U30, from c2f's suite |
| G-u2u13 | `3304247f` | U2 ×2, U13, from c2f's suite (made when G-all took 576 s of the 600 s cap under load 31) |
| F-folderA / F-folderB | `ab838a51` / `739ff555` | round 1's: the 21 other audit-import scenarios that save or refresh (byte-identical in c2f's suite) |

### Focused runs (final blocks; base `fce8a391`, c1f `83b87782`, c2f `84cf2bf4`)

| harness | base | c1f | c2f |
|---|---|---|---|
| G-u20 (84 checks) | **23 fail** (fr1) | 84/84 (fr1) | 84/84 (fr1) |
| G-u30 (89 checks) | **46 fail** (fr2) | **44 fail**, U30 only (fr2) | 89/89 (fr2) |
| G-all (301 checks) | **69 fail** = U20 23 + U30 46; U2 57/57, U13 71/71 (fr2) | **44 fail** = U30 only (fr2) | 301/301 (fr2, 576 s) |
| G-u2u13 (128 checks) | — | — | 128/128 (fr3) |
| F-folderA (297) / F-folderB (142) | round 1 f1: 439/439 | round 1 f3 on the same board and harnesses: 297/297 + 142/142 | 297/297 (fr2) + 142/142 (fr3) |

**The labelling rule (S1), checked on the base output by `fr/src/labels.py` (`9e753ded`):**
- U20: 84 checks, CONTROL 48 pass / 0 fail (19 of them the stand-in's self-tests), GUARD 13 pass / 0 fail, every other check 0
  pass / 23 fail;
- U30: 89 checks, CONTROL 34 / 0, GUARD 9 / 0, every other check 0 pass / 46 fail;
- in G-all on the base the U20 and U30 checks give 0 breaches of 173 (the U2 and U13 blocks are the base's own, and pass there).

fr1 also ran G-u30 before control (8d) was added (87 checks): base 46 fail, c1f 44, c2f 87/87. It is superseded by fr2.

### Mutants (each built text-only by `rec/bin/mkmut.py`, `matches: 1`; blobs in `fr/out/mutant-blobs.txt`)

| copy | mutant | harness | failing checks (cases) |
|---|---|---|---|
| c1f | `v200-u20-wait-uncounted` (`dc6fd5d6` = round 1's) | G-u20 | 23 of 84: (1) 4, (2) 4, (3) 3, (3h) 5, (4) 3, (6d) 1, **(7) 3** |
| c1f | `v200-u20-failed-stays-counted` (`5a25ded3`) | G-u20 | 2: (6a), (6b) |
| c2f | `v200-u20-wait-uncounted` (`dc0cff4f`) | G-u20 | 17: (1) 4, (2) 4, (3) 1, (3h) 1, (4) 3, (6d) 1, (7) 3 |
| c2f | `v200-u20-failed-stays-counted` (`c5cff638`) | G-u20 | 2: (6a), (6b) |
| c2f | `v200-u30-base-whatever-on-screen` (`994ee8d3`) | G-u30 | 42: (1)–(4), (6)/(6h), (7), (8), (9), (10) |
| c2f | `v200-u30-base-only-other-copy` (`9675d720`) | G-u30 | 44: the same plus (5a) 2 |
| c2f | `v200-u30-unrecorded-said-after` (`47c162b6`) | G-u30 | 5: the words in (1), (1h), (6), (6h), (8) |
| c2f | `v200-u30-recorded-said-unknown` (`bf1b960e`) | G-u30 | 1: (5e) |
| c2f | **`v200-u30-unsaved-this-session-only`** (`a0eed275`; M1) | G-u30 | **21**: (6) 2, (6h) 5, (7) 5, (8) 6, (9) 3 |
| c2f | **`v200-u30-quiet-refresh-only`** (`bdf4db36`; M1) | G-u30 | **16**: (6) 2, (6h) 5, (8) 6, (9) 3 |
| c2f | **`v200-u30-unsaved-only`** (`76cb0459`; M1) | G-u30 | **14**: (7) 5, (8) 6, (9) 3 |
| c2f | own `ownUnsaved` rule (`fb879f74`; the review's fourth survivor, `fr/src/mkown.py`) | G-u30 | **14**: (7) 5, (8) 6, (9) 3 |
| c2f | **`v200-u30-putback-said-after`** (`4e66ae9a`; MF1) | G-u30 | 1: (8) |
| c2f | **`v200-u30-putback-said-unknown`** (`355e5bac`) | G-u30 | 2: (8c), (8d) |
| c2f | **`v200-u30-putback-file-unknown`** (`160242dc`) | G-u30 | 1: (8d) |
| c2f | **`v200-u30-occupied-said-newer`** (`5ae2fad8`; MF1) | G-u30 | 1: (9) |
| c2f | **`v200-u30-occupied-said-unknown`** (`51a0fd9b`) | G-u30 | 1: (9c) |
| c2f | existing `kept-theirs-wrong-word` (`b05f4428`) | F-folderA | 1 of 297: v1.95 "folder theirs" (still caught with the new line beside it) |
| c2f | `v200-u2-putback-gen` (`6e937bbd`) | G-u2u13 | 1 of 128: U2 (d) |
| c2f | `v200-u2-putback-while-saving` (`d6b3fa7e`) | G-u2u13 | 34: U2 (a)–(h) |
| c2f | `v200-u13-pull-while-saving` (`6caf125e`) | G-u2u13 | 40: U13 |
| c2f | `v200-u13-pull-unchecked` (`0b18930c`) | G-u2u13 | 40: U13 |
| c2f | `v200-u13-said-nothing-loaded` (`610ee8f0`) | G-u2u13 | 10: U13's words |
| c2f | `v200-u13-base-while-saving` (`a13c0aa9`) | G-u20 / G-u30 | 2: U20 (4) / 2: U30 (5b) |
| c2f | `v200-u13-clash-while-saving` (`d78227bc`) | G-u20 / G-u30 | 1: U20 (4) / 1: U30 (5b) |

Every mutant is caught: 25 entries and one own mutant, all exit 1, each failing list read and as expected. The four rule forms the
tests review found surviving round 1 are now caught with 14–21 checks each (the review's proposal alone gave 5–12; cases (8)–(10)
reach the rule too).

### The U20 probe and checker (r4, final c2f `84cf2bf4`), the other suites, and real Chromium

- **r4** (`bin/repro2.sh r4 c2f 84cf2bf4`, the probe and checker scripts unchanged; the literal checks `check-84cf2bf4.mjs` /
  `xcheck-84cf2bf4.mjs` differ from `check.mjs` / `xcheck.mjs` only in the board id): **the same verdicts by kind as round 1's
  r3** on `c42be8e7`. Probe: U20 77/77, OUT 26/26, CTL 109/109, locktest 19/19, PRE fails 10 (the premise "B `_saveBusy` 0" the
  fix changes). Checker: U20 24/24, CNT 45/45, CTL 10/10; PRE 8, INFO 4 and O4 2 fail, all "observed mechanism" checks the fix
  removes. All 40 runs exit 0.
- **Other suites, scratch clone `clones/c2f`** (`git clone --shared /home/user/orbit-board` at `f3f4b3d`, c2f's board, `tools/`,
  package.json and NEXT-VERSION.md copied over; `git status` shows only the board and audit-import modified, and `node_modules`
  and `mutate.mjs.txt` untracked; nothing committed): boot-same exit 0, audit, audit-ppt, audit-other, audit-recon, audit-hostile
  and audit-inject ALL CHECKS PASSED, legacy-fsrc exit 0, npm run check all checks passed. Every log is the same as round 1's
  c2 log apart from timings and the board's size (npm check: 31696 lines against 31691). The base's suites were not re-run:
  the base is unchanged, and round 1's base logs stand.
- **Real Chromium** (`fr/src/rc-u20.mjs`, `338ec398`: the money review's `bin/rc-u20.mjs`, `7d798de0`, with only its temp
  directory moved into `fr/out/`; Chromium `/opt/pw-browsers/chromium`, playwright-core from the copy's `node_modules`; run
  alone): **c2f 13 of 14 pass**: W1–W7 (a waiting save counted, ↶ Put back refused while it waits, a second Save counted as two
  with its line, both run in order, a waiting save that throws, a tab closed while it holds the lock, Put back asks once
  nothing is under way) and F1 (file://). **Base 7 of 14**: W1–W6 fail, as they should. The one check failing on both is the
  script's own environment check that no request but the page is made: the board asks for `prio-state-om.json`. Same as the
  review's runs.

**mcount**: base 1328/1328, c1f 1330/1330, c2f 1342/1342 (above).

### Every fix-round run

All node, npm and Chromium runs went through `bin/run.sh` (lock checked before each: `AUDIT_IMPORT_RUNNING` was never present,
so no run waited and none was skipped). **No run timed out.** Exit 1 on the base, on c1f's U30 runs and on every mutant means
checks failed, as intended. Raw lines: `logs/runs.txt` from "# fix round started"; logs `logs/<label>.log`.

```
label | start (ET) | exit | wall s | checks | board | log
fr1-G-u20-b0 | 2026-10-13 12:26:25 EDT | 1 | 96.1 | 84 checks, 23 fail | fce8a391 | logs/fr1-G-u20-b0.log
fr1-G-u30-b0 | 2026-10-13 12:26:25 EDT | 1 | 139.2 | 87 checks, 46 fail | fce8a391 | logs/fr1-G-u30-b0.log
fr1-G-u20-c1f | 2026-10-13 12:28:01 EDT | 0 | 112.9 | 84 checks, 0 fail | 83b87782 | logs/fr1-G-u20-c1f.log
fr1-G-u30-c1f | 2026-10-13 12:28:44 EDT | 1 | 164.7 | 87 checks, 44 fail | 83b87782 | logs/fr1-G-u30-c1f.log
fr1-G-u20-c2f | 2026-10-13 12:29:54 EDT | 0 | 116.0 | 84 checks, 0 fail | 84cf2bf4 | logs/fr1-G-u20-c2f.log
fr1-G-u30-c2f | 2026-10-13 12:31:29 EDT | 0 | 160.1 | 87 checks, 0 fail | 84cf2bf4 | logs/fr1-G-u30-c2f.log
fr2m-c1f-v200-u20-wait-uncounted-G-u20 | 2026-10-13 12:35:36 EDT | 1 | 133.1 | 84 checks, 23 fail | dc6fd5d6 | logs/fr2m-c1f-v200-u20-wait-uncounted-G-u20.log
fr2-G-u30-b0 | 2026-10-13 12:35:36 EDT | 1 | 190.2 | 89 checks, 46 fail | fce8a391 | logs/fr2-G-u30-b0.log
fr2m-c2f-v200-u20-wait-uncounted-G-u20 | 2026-10-13 12:37:49 EDT | 1 | 107.4 | 84 checks, 17 fail | dc0cff4f | logs/fr2m-c2f-v200-u20-wait-uncounted-G-u20.log
fr2m-c1f-v200-u20-failed-stays-counted-G-u20 | 2026-10-13 12:39:37 EDT | 1 | 103.2 | 84 checks, 2 fail | 5a25ded3 | logs/fr2m-c1f-v200-u20-failed-stays-counted-G-u20.log
fr2-G-u30-c1f | 2026-10-13 12:38:47 EDT | 1 | 158.9 | 89 checks, 44 fail | 83b87782 | logs/fr2-G-u30-c1f.log
fr2m-c2f-v200-u20-failed-stays-counted-G-u20 | 2026-10-13 12:41:20 EDT | 1 | 134.1 | 84 checks, 2 fail | c5cff638 | logs/fr2m-c2f-v200-u20-failed-stays-counted-G-u20.log
fr2-G-u30-c2f | 2026-10-13 12:41:26 EDT | 0 | 187.9 | 89 checks, 0 fail | 84cf2bf4 | logs/fr2-G-u30-c2f.log
fr2m-c2f-v200-u30-base-whatever-on-screen-G-u30 | 2026-10-13 12:44:34 EDT | 1 | 176.2 | 89 checks, 42 fail | 994ee8d3 | logs/fr2m-c2f-v200-u30-base-whatever-on-screen-G-u30.log
fr2m-c2f-v200-u30-base-only-other-copy-G-u30 | 2026-10-13 12:47:30 EDT | 1 | 186.8 | 89 checks, 44 fail | 9675d720 | logs/fr2m-c2f-v200-u30-base-only-other-copy-G-u30.log
fr2-G-all-c2f | 2026-10-13 12:43:34 EDT | 0 | 576.4 | 301 checks, 0 fail | 84cf2bf4 | logs/fr2-G-all-c2f.log
fr2m-c2f-v200-u30-unrecorded-said-after-G-u30 | 2026-10-13 12:50:37 EDT | 1 | 226.7 | 89 checks, 5 fail | 47c162b6 | logs/fr2m-c2f-v200-u30-unrecorded-said-after-G-u30.log
fr2m-c2f-v200-u30-recorded-said-unknown-G-u30 | 2026-10-13 12:54:24 EDT | 1 | 189.5 | 89 checks, 1 fail | bf1b960e | logs/fr2m-c2f-v200-u30-recorded-said-unknown-G-u30.log
fr2-F-folderA-c2f | 2026-10-13 12:53:11 EDT | 0 | 384.2 | 297 checks, 0 fail | 84cf2bf4 | logs/fr2-F-folderA-c2f.log
fr2m-c2f-v200-u30-unsaved-this-session-only-G-u30 | 2026-10-13 12:57:33 EDT | 1 | 165.0 | 89 checks, 21 fail | a0eed275 | logs/fr2m-c2f-v200-u30-unsaved-this-session-only-G-u30.log
fr2m-c2f-v200-u30-quiet-refresh-only-G-u30 | 2026-10-13 13:00:18 EDT | 1 | 121.3 | 89 checks, 16 fail | bdf4db36 | logs/fr2m-c2f-v200-u30-quiet-refresh-only-G-u30.log
fr2m-c2f-v200-u30-unsaved-only-G-u30 | 2026-10-13 13:02:19 EDT | 1 | 144.5 | 89 checks, 14 fail | 76cb0459 | logs/fr2m-c2f-v200-u30-unsaved-only-G-u30.log
fr3-F-folderB-c2f | 2026-10-13 12:59:43 EDT | 0 | 427.4 | 142 checks, 0 fail | 84cf2bf4 | logs/fr3-F-folderB-c2f.log
fr2m-c2f-v200-u30-putback-said-after-G-u30 | 2026-10-13 13:04:44 EDT | 1 | 168.6 | 89 checks, 1 fail | 4e66ae9a | logs/fr2m-c2f-v200-u30-putback-said-after-G-u30.log
fr2m-c2f-v200-u30-putback-said-unknown-G-u30 | 2026-10-13 13:07:33 EDT | 1 | 165.6 | 89 checks, 2 fail | 355e5bac | logs/fr2m-c2f-v200-u30-putback-said-unknown-G-u30.log
fr3m-c2f-kept-theirs-wrong-word-F-folderA | 2026-10-13 13:06:51 EDT | 1 | 329.2 | 297 checks, 1 fail | b05f4428 | logs/fr3m-c2f-kept-theirs-wrong-word-F-folderA.log
fr2m-c2f-v200-u30-putback-file-unknown-G-u30 | 2026-10-13 13:10:18 EDT | 1 | 144.9 | 89 checks, 1 fail | 160242dc | logs/fr2m-c2f-v200-u30-putback-file-unknown-G-u30.log
fr2m-c2f-v200-u30-occupied-said-newer-G-u30 | 2026-10-13 13:12:43 EDT | 1 | 139.7 | 89 checks, 1 fail | 5ae2fad8 | logs/fr2m-c2f-v200-u30-occupied-said-newer-G-u30.log
fr3m-c2f-v200-u2-putback-gen-G-u2u13 | 2026-10-13 13:12:20 EDT | 1 | 200.8 | 128 checks, 1 fail | 6e937bbd | logs/fr3m-c2f-v200-u2-putback-gen-G-u2u13.log
fr2m-c2f-v200-u30-occupied-said-unknown-G-u30 | 2026-10-13 13:15:03 EDT | 1 | 148.1 | 89 checks, 1 fail | 51a0fd9b | logs/fr2m-c2f-v200-u30-occupied-said-unknown-G-u30.log
fr3m-c2f-v200-u2-putback-while-saving-G-u2u13 | 2026-10-13 13:15:41 EDT | 1 | 195.7 | 128 checks, 34 fail | d6b3fa7e | logs/fr3m-c2f-v200-u2-putback-while-saving-G-u2u13.log
fr2m-c2f-own-u30-ownunsaved-rule-G-u30 | 2026-10-13 13:17:31 EDT | 1 | 122.9 | 89 checks, 14 fail | fb879f74 | logs/fr2m-c2f-own-u30-ownunsaved-rule-G-u30.log
fr3m-c2f-v200-u13-pull-while-saving-G-u2u13 | 2026-10-13 13:18:57 EDT | 1 | 145.4 | 128 checks, 40 fail | 6caf125e | logs/fr3m-c2f-v200-u13-pull-while-saving-G-u2u13.log
fr3m-c2f-v200-u13-pull-unchecked-G-u2u13 | 2026-10-13 13:21:22 EDT | 1 | 154.5 | 128 checks, 40 fail | 0b18930c | logs/fr3m-c2f-v200-u13-pull-unchecked-G-u2u13.log
fr2-G-all-c1f | 2026-10-13 13:19:34 EDT | 1 | 317.5 | 301 checks, 44 fail | 83b87782 | logs/fr2-G-all-c1f.log
fr3m-c2f-v200-u13-said-nothing-loaded-G-u2u13 | 2026-10-13 13:23:57 EDT | 1 | 137.9 | 128 checks, 10 fail | 610ee8f0 | logs/fr3m-c2f-v200-u13-said-nothing-loaded-G-u2u13.log
fr3m-c2f-v200-u13-base-while-saving-G-u20 | 2026-10-13 13:26:15 EDT | 1 | 51.9 | 84 checks, 2 fail | a13c0aa9 | logs/fr3m-c2f-v200-u13-base-while-saving-G-u20.log
fr3m-c2f-v200-u13-base-while-saving-G-u30 | 2026-10-13 13:27:07 EDT | 1 | 85.0 | 89 checks, 2 fail | a13c0aa9 | logs/fr3m-c2f-v200-u13-base-while-saving-G-u30.log
fr2-G-all-b0 | 2026-10-13 13:24:52 EDT | 1 | 251.2 | 301 checks, 69 fail | fce8a391 | logs/fr2-G-all-b0.log
fr3m-c2f-v200-u13-clash-while-saving-G-u20 | 2026-10-13 13:28:32 EDT | 1 | 52.4 | 84 checks, 1 fail | d78227bc | logs/fr3m-c2f-v200-u13-clash-while-saving-G-u20.log
fr3m-c2f-v200-u13-clash-while-saving-G-u30 | 2026-10-13 13:29:24 EDT | 1 | 87.6 | 89 checks, 1 fail | d78227bc | logs/fr3m-c2f-v200-u13-clash-while-saving-G-u30.log
fr3-G-u2u13-c2f | 2026-10-13 13:30:52 EDT | 0 | 138.0 | 128 checks, 0 fail | 84cf2bf4 | logs/fr3-G-u2u13-c2f.log
r4-locktest | 2026-10-13 13:33:32 EDT | 0 | 3.8 |  |  | logs/r4-locktest.log
r4-PB-W | 2026-10-13 13:33:36 EDT | 0 | 20.3 |  | 84cf2bf4 | logs/r4-PB-W.log
S-fr-c2f-boot-same | 2026-10-13 13:33:32 EDT | 0 | 27.9 |  |  | logs/S-fr-c2f-boot-same.log
r4-PB-Wtick | 2026-10-13 13:33:56 EDT | 0 | 18.2 |  | 84cf2bf4 | logs/r4-PB-Wtick.log
S-fr-c2f-audit | 2026-10-13 13:34:00 EDT | 0 | 25.7 |  |  | logs/S-fr-c2f-audit.log
r4-PB-C1 | 2026-10-13 13:34:14 EDT | 0 | 21.0 |  | 84cf2bf4 | logs/r4-PB-C1.log
S-fr-c2f-audit-ppt | 2026-10-13 13:34:25 EDT | 0 | 15.6 |  |  | logs/S-fr-c2f-audit-ppt.log
r4-PB-C2a | 2026-10-13 13:34:35 EDT | 0 | 20.4 |  | 84cf2bf4 | logs/r4-PB-C2a.log
r4-PB-C2b | 2026-10-13 13:34:56 EDT | 0 | 17.2 |  | 84cf2bf4 | logs/r4-PB-C2b.log
r4-PB-NL | 2026-10-13 13:35:13 EDT | 0 | 15.8 |  | 84cf2bf4 | logs/r4-PB-NL.log
r4-AD-W | 2026-10-13 13:35:29 EDT | 0 | 23.7 |  | 84cf2bf4 | logs/r4-AD-W.log
S-fr-c2f-audit-other | 2026-10-13 13:34:41 EDT | 0 | 77.2 |  |  | logs/S-fr-c2f-audit-other.log
r4-AD-Wtick | 2026-10-13 13:35:53 EDT | 0 | 24.5 |  | 84cf2bf4 | logs/r4-AD-Wtick.log
r4-AD-C1 | 2026-10-13 13:36:17 EDT | 0 | 20.5 |  | 84cf2bf4 | logs/r4-AD-C1.log
r4-AD-C2a | 2026-10-13 13:36:38 EDT | 0 | 18.8 |  | 84cf2bf4 | logs/r4-AD-C2a.log
r4-AD-C2b | 2026-10-13 13:36:57 EDT | 0 | 16.0 |  | 84cf2bf4 | logs/r4-AD-C2b.log
r4-BR-W | 2026-10-13 13:37:13 EDT | 0 | 14.8 |  | 84cf2bf4 | logs/r4-BR-W.log
r4-BR-Wtick | 2026-10-13 13:37:27 EDT | 0 | 20.5 |  | 84cf2bf4 | logs/r4-BR-Wtick.log
r4-BR-C1 | 2026-10-13 13:37:48 EDT | 0 | 17.5 |  | 84cf2bf4 | logs/r4-BR-C1.log
r4-BR-C2a | 2026-10-13 13:38:06 EDT | 0 | 11.6 |  | 84cf2bf4 | logs/r4-BR-C2a.log
r4-BR-C2b | 2026-10-13 13:38:17 EDT | 0 | 8.5 |  | 84cf2bf4 | logs/r4-BR-C2b.log
r4-BR-Wperm | 2026-10-13 13:38:26 EDT | 0 | 15.1 |  | 84cf2bf4 | logs/r4-BR-Wperm.log
r4-BR-C1perm | 2026-10-13 13:38:41 EDT | 0 | 17.2 |  | 84cf2bf4 | logs/r4-BR-C1perm.log
r4-BR-Wh | 2026-10-13 13:38:58 EDT | 0 | 18.0 |  | 84cf2bf4 | logs/r4-BR-Wh.log
r4-BR-C1h | 2026-10-13 13:39:16 EDT | 0 | 19.0 |  | 84cf2bf4 | logs/r4-BR-C1h.log
r4-BR-Wpermh | 2026-10-13 13:39:35 EDT | 0 | 18.2 |  | 84cf2bf4 | logs/r4-BR-Wpermh.log
r4-BR-C2ah | 2026-10-13 13:39:53 EDT | 0 | 21.8 |  | 84cf2bf4 | logs/r4-BR-C2ah.log
S-fr-c2f-audit-recon | 2026-10-13 13:35:58 EDT | 0 | 263.0 |  |  | logs/S-fr-c2f-audit-recon.log
S-fr-c2f-legacy-fsrc | 2026-10-13 13:40:21 EDT | 0 | 11.9 |  |  | logs/S-fr-c2f-legacy-fsrc.log
r4-BR-C2bh | 2026-10-13 13:40:15 EDT | 0 | 23.5 |  | 84cf2bf4 | logs/r4-BR-C2bh.log
r4-PF-W | 2026-10-13 13:40:39 EDT | 0 | 24.5 |  | 84cf2bf4 | logs/r4-PF-W.log
r4-PF-C1 | 2026-10-13 13:41:03 EDT | 0 | 30.7 |  | 84cf2bf4 | logs/r4-PF-C1.log
r4-PF-C2a | 2026-10-13 13:41:34 EDT | 0 | 32.2 |  | 84cf2bf4 | logs/r4-PF-C2a.log
r4-x-PB-Wcount | 2026-10-13 13:42:06 EDT | 0 | 36.9 |  | 84cf2bf4 | logs/r4-x-PB-Wcount.log
r4-x-AD-Wcount | 2026-10-13 13:42:43 EDT | 0 | 25.8 |  | 84cf2bf4 | logs/r4-x-AD-Wcount.log
r4-x-BR-Wcount | 2026-10-13 13:43:09 EDT | 0 | 20.8 |  | 84cf2bf4 | logs/r4-x-BR-Wcount.log
r4-x-BR-Wreal | 2026-10-13 13:43:30 EDT | 0 | 27.6 |  | 84cf2bf4 | logs/r4-x-BR-Wreal.log
S-fr-c2f-audit-hostile | 2026-10-13 13:40:33 EDT | 0 | 234.1 |  |  | logs/S-fr-c2f-audit-hostile.log
r4-x-BR-Wrealtick | 2026-10-13 13:43:58 EDT | 0 | 38.3 |  | 84cf2bf4 | logs/r4-x-BR-Wrealtick.log
r4-x-BR-C1real | 2026-10-13 13:44:36 EDT | 0 | 29.2 |  | 84cf2bf4 | logs/r4-x-BR-C1real.log
S-fr-c2f-audit-inject | 2026-10-13 13:44:28 EDT | 0 | 62.6 |  |  | logs/S-fr-c2f-audit-inject.log
r4-x-BR-Wrealcount | 2026-10-13 13:45:06 EDT | 0 | 38.6 |  | 84cf2bf4 | logs/r4-x-BR-Wrealcount.log
S-fr-c2f-npm-check | 2026-10-13 13:45:31 EDT | 0 | 18.2 |  |  | logs/S-fr-c2f-npm-check.log
r4-x-BR-Wrealh | 2026-10-13 13:45:44 EDT | 0 | 41.5 |  | 84cf2bf4 | logs/r4-x-BR-Wrealh.log
r4-x-O4-tick | 2026-10-13 13:46:26 EDT | 0 | 33.6 |  | 84cf2bf4 | logs/r4-x-O4-tick.log
r4-x-O4-tickh | 2026-10-13 13:46:59 EDT | 0 | 36.2 |  | 84cf2bf4 | logs/r4-x-O4-tickh.log
r4-x-BR-Wrealtickcount | 2026-10-13 13:47:36 EDT | 0 | 30.6 |  | 84cf2bf4 | logs/r4-x-BR-Wrealtickcount.log
r4-check | 2026-10-13 13:48:06 EDT | 0 | 0.5 |  |  | logs/r4-check.log
r4-xcheck | 2026-10-13 13:48:07 EDT | 0 | 0.7 |  |  | logs/r4-xcheck.log
fr4-rc-u20-c2f | 2026-10-13 13:48:39 EDT | 1 | 14.4 |  | 84cf2bf4 | logs/fr4-rc-u20-c2f.log
fr4-rc-u20-b0 | 2026-10-13 13:48:54 EDT | 1 | 16.9 |  | fce8a391 | logs/fr4-rc-u20-b0.log
```

Bounded text, copy and hash commands (`bin/bx.sh`), from `logs/bx.txt`:

```
# fix round started 2026-10-13 12:22:45 EDT
fr-cp-c1f start_et="2026-10-13 12:22:45 EDT" exit=0 wall_s=0.1
fr-cp-c2f start_et="2026-10-13 12:22:45 EDT" exit=0 wall_s=0.23
fr-mk-u20f start_et="2026-10-13 12:25:43 EDT" exit=0 wall_s=0.24
fr-mk-u30f start_et="2026-10-13 12:25:43 EDT" exit=0 wall_s=0.19
fr-rebuild1 start_et="2026-10-13 12:25:50 EDT" exit=0 wall_s=5.54
fr-mkentries start_et="2026-10-13 12:27:19 EDT" exit=0 wall_s=0.39
fr-ins-mut-c2f start_et="2026-10-13 12:27:19 EDT" exit=0 wall_s=0.29
fr-mcount-c1f start_et="2026-10-13 12:27:29 EDT" exit=0 wall_s=10.99
fr-mcount-c2f start_et="2026-10-13 12:27:40 EDT" exit=0 wall_s=10.44
fr-mkentries2 start_et="2026-10-13 12:29:18 EDT" exit=0 wall_s=0.5
fr-cp-mut-c2f start_et="2026-10-13 12:29:18 EDT" exit=0 wall_s=0.12
fr-ins-mut-c2f-2 start_et="2026-10-13 12:29:18 EDT" exit=0 wall_s=0.35
fr-mcount2-b0 start_et="2026-10-13 12:29:19 EDT" exit=0 wall_s=16.81
fr-mcount2-c1f start_et="2026-10-13 12:29:36 EDT" exit=0 wall_s=13.63
fr-mcount2-c2f start_et="2026-10-13 12:29:49 EDT" exit=0 wall_s=18.44
fr-overlap start_et="2026-10-13 12:31:09 EDT" exit=0 wall_s=30.67
fr-clone-c2f start_et="2026-10-13 12:32:10 EDT" exit=0 wall_s=2.45
fr-cpover-c2f start_et="2026-10-13 12:32:12 EDT" exit=0 wall_s=0.31
fr-mk-u30f-2 start_et="2026-10-13 12:34:21 EDT" exit=0 wall_s=0.3
fr-rebuild2 start_et="2026-10-13 12:34:21 EDT" exit=0 wall_s=7.73
fr-mkmut-c1f-v200-u20-wait-uncounted start_et="2026-10-13 12:34:48 EDT" exit=0 wall_s=0.59
fr-mkmut-c1f-v200-u20-failed-stays-counted start_et="2026-10-13 12:34:49 EDT" exit=0 wall_s=0.57
fr-mkmut-c2f-v200-u20-wait-uncounted start_et="2026-10-13 12:34:50 EDT" exit=0 wall_s=0.51
fr-mkmut-c2f-v200-u20-failed-stays-counted start_et="2026-10-13 12:34:50 EDT" exit=0 wall_s=0.46
fr-mkmut-c2f-v200-u30-base-whatever-on-screen start_et="2026-10-13 12:34:51 EDT" exit=0 wall_s=0.41
fr-mkmut-c2f-v200-u30-base-only-other-copy start_et="2026-10-13 12:34:51 EDT" exit=0 wall_s=0.57
fr-mkmut-c2f-v200-u30-unrecorded-said-after start_et="2026-10-13 12:34:52 EDT" exit=0 wall_s=0.54
fr-mkmut-c2f-v200-u30-recorded-said-unknown start_et="2026-10-13 12:34:52 EDT" exit=0 wall_s=0.55
fr-mkmut-c2f-v200-u30-unsaved-this-session-only start_et="2026-10-13 12:34:53 EDT" exit=0 wall_s=0.27
fr-mkmut-c2f-v200-u30-quiet-refresh-only start_et="2026-10-13 12:34:53 EDT" exit=0 wall_s=0.35
fr-mkmut-c2f-v200-u30-unsaved-only start_et="2026-10-13 12:34:53 EDT" exit=0 wall_s=0.34
fr-mkmut-c2f-v200-u30-putback-said-after start_et="2026-10-13 12:34:54 EDT" exit=0 wall_s=0.4
fr-mkmut-c2f-v200-u30-putback-said-unknown start_et="2026-10-13 12:34:54 EDT" exit=0 wall_s=0.6
fr-mkmut-c2f-v200-u30-putback-file-unknown start_et="2026-10-13 12:34:55 EDT" exit=0 wall_s=0.53
fr-mkmut-c2f-v200-u30-occupied-said-newer start_et="2026-10-13 12:34:55 EDT" exit=0 wall_s=0.59
fr-mkmut-c2f-v200-u30-occupied-said-unknown start_et="2026-10-13 12:34:56 EDT" exit=0 wall_s=0.33
fr-mkmut-c2f-v200-u2-putback-gen start_et="2026-10-13 12:34:56 EDT" exit=0 wall_s=6.63
fr-mkmut-c2f-v200-u2-putback-while-saving start_et="2026-10-13 12:35:03 EDT" exit=0 wall_s=0.77
fr-mkmut-c2f-v200-u13-pull-while-saving start_et="2026-10-13 12:35:04 EDT" exit=0 wall_s=0.72
fr-mkmut-c2f-v200-u13-base-while-saving start_et="2026-10-13 12:35:05 EDT" exit=0 wall_s=0.61
fr-mkmut-c2f-v200-u13-pull-unchecked start_et="2026-10-13 12:35:05 EDT" exit=0 wall_s=0.56
fr-mkmut-c2f-v200-u13-said-nothing-loaded start_et="2026-10-13 12:35:06 EDT" exit=0 wall_s=0.55
fr-mkmut-c2f-v200-u13-clash-while-saving start_et="2026-10-13 12:35:06 EDT" exit=0 wall_s=0.63
fr-mkmut-c2f-kept-theirs-wrong-word start_et="2026-10-13 12:35:07 EDT" exit=0 wall_s=0.58
fr-mkown-ownunsaved start_et="2026-10-13 12:35:08 EDT" exit=0 wall_s=0.24
fr-sed-check-84cf start_et="2026-10-13 12:36:25 EDT" exit=0 wall_s=12.07
fr-mkdiffs start_et="2026-10-13 12:43:31 EDT" exit=0 wall_s=1.13
fr-cp-rc start_et="2026-10-13 12:43:51 EDT" exit=0 wall_s=12.44
fr-mk-G-u2u13 start_et="2026-10-13 12:56:13 EDT" exit=0 wall_s=3.01
```

### PIDs

`pids.txt` lines 570–881 (312 lines) are this round's: 142 bounded commands (93 node, npm or Chromium-launching runs and 49
text, copy and hash commands), each with its `timeout` PID and its child (`gone` where it ended before `ps` looked: 17 lines),
and the wrappers (`lanes.sh` fr1/fr2 and their lane shells, `lane1.sh` fr3, `last.sh`, `suites.sh`, `repro2.sh`, and the outer
`setsid`/`timeout` of each background batch). At most two node processes of mine ran at any time: fr1 and fr2 were two lanes;
fr3 started only after F-folderA-c2f, the run lane B was on, had its exit record; the suites and the probe ran as two lanes
after everything else; Chromium ran alone.

**One process was stopped by me: PID 20867**, the loop shell of fr2's lane B, recorded at its launch ("lane lanes:fr2:B"). At
12:56:37 PM ET, after G-all-c2f took 576 s of the 600 s cap under load 31, I sent it TERM so that it would not start seven more
G-all mutant runs; its current run (F-folderA-c2f) was not touched and finished normally (exit 0, 297/297). The lines it had
not started were run in lane fr3 with the split harness G-u2u13 (and G-u20/G-u30 for the two U13 mutants only those catch).
Nothing else was killed; nothing was killed by name or pattern.

### Deviations, stated plainly

- **Read-only commands outside the wrapper**, as in round 1: `ls`, `cat`, `grep`, `sed -n`, `head`/`tail`, `diff`, `wc`, `ps`,
  `git log`/`show`/`status`/`hash-object`, and short `python3 -I` readers (`fails.py`, `labels.py`, `summ.py`, inline summaries).
- **Small writes outside the wrapper**: `mkdir`, `ln -s` (the `h/c1f`, `h/c2f` links, the clone's `node_modules`), `chmod`;
  `cp` of the folder harnesses into `h/c2f` and of c2f's audit-import into the clone after the rebuild; the heredocs that wrote
  scripts in `fr/src/`; the editor tool's edits of the c2f board, the block sources and the drafts; appending notes to
  `logs/runs.txt` and wrapper PIDs to `pids.txt`; and this section's assembly into README.md by a short unwrapped `python3 -I`
  script (from `fr/README-fr-part1.md`, `fr/README-fr-part2.md` and the generated tables; round 1's README kept first as
  `fr/README-round1-backup.md`). Every node, npm, Chromium, copy-of-a-copy and diff run that produced evidence was bounded.
- **The c2f board changed once after fr1 started.** The first board (`cc53cd39`, the review's call-site edit) broke an
  existing entry (mcount 1341/1342); I changed it to `84cf2bf4` at about 12:29 PM ET. No run used `cc53cd39`: every fr1 c2f run
  started later and its IDS line names `84cf2bf4`.
- **Early diffs regenerated.** Some `diff -u` files were first written unbounded before control (8d) existed; `fr/src/mkdiffs.sh`
  (bounded, `fr-mkdiffs`) rewrote every diff from the final copies, and only those are cited.
- **Lane B stopped** (above).

### Not done (plainly)

- The full audit-import and audit-board were not run (the lead's). `mutate.mjs` was never run, imported or executed; it was
  read as text only. `playwright install` was never run.
- Not re-run because nothing they read changed: the base's suites (the base is unchanged); F-folderA/B and the U20 probe on
  c1f (c1f's board and those harnesses are byte-identical to round 1's c1 runs, which passed).
- Real Chromium was run on c2f and the base, not on c1f (c1f's `saveSerial` is c2f's, byte for byte).
- Not covered by a test (and said in the drafts): ✍ Take the pen and Save yours over theirs as the operation that waits; Save
  yours over theirs holding the lock across its dialog; U2's refusal words when what waits is Load theirs; a folder copy with
  no stamp; a different copy stamped to the same millisecond; with a copy recorded that is later than the folder's (U29), the
  words "after" / "newer" (ADOPT's territory; the rebase note says what the merge must give them).
- The ADOPT merge itself was not done; only the rebase note is drafted.
- Nothing was committed or pushed. NEXT-VERSION.md and the ledger texts are drafts: `drafts/NEXT-VERSION-U20-U30-fr.txt`
  (`77edb264`), which supersedes `drafts/NEXT-VERSION-U20-U30.txt`.


## Drafts for the lead (fix round; supersede the round-1 drafts above)

The same text as `drafts/NEXT-VERSION-U20-U30-fr.txt`:

```
DRAFT for the lead, FIX ROUND (13 Oct). Not applied anywhere. It SUPERSEDES drafts/NEXT-VERSION-U20-U30.txt (round 1, 12 Oct),
which is kept unchanged as the record the reviews read. Everything for commit 1 is under "COMMIT 1", everything for commit 2
under "COMMIT 2". Every count below was read from the fix-round runs (README, "Fix round").

======================================================================================================================
COMMIT 1 (U20) -- NEXT-VERSION.md
======================================================================================================================

(1a) NEW ENTRY, under "### v2.00", after the U14 entry and before "- **Unresolved after R1–R5 (11 Oct).**":

- **U20 — a save waiting for another tab's save is under way** (the lead's decision under Brad's word of 12 Oct, about
  5:30 PM ET: "Don't wait for me. Let's keep pressing throughout to get this next version published."). A save waits for
  the 'orbit-save' Web Lock, so that one save runs at a time across this browser's tabs. It was counted as under way only
  once it held the lock. While it waited for another tab's save, ↶ Put back (U2) and the folder's refresh (U13) took it for
  no save at all: Put back went ahead under it, a refresh loaded a newer copy under it, and a refresh with nothing recorded
  for the folder took the folder's copy as the one the work came from. The waiting save then wrote over that copy without
  asking. With a history copy kept less than ten minutes before, the copy written over was kept only as a recent copy, and
  one more Save removed it: it was in no copy the board could reach. Now a save is counted from the moment it is asked for,
  waiting included, until it has finished, however it ends: saved, refused, failed, thrown, or its lock request refused.
  Load theirs, which waits in the same queue, is counted the same way.
  - **What users may see:** while a Save or Load theirs waits for another tab's save, ↶ Put back is refused in U2's words
    ("⏳ Not put back: a save was under way …"). A Connect that finds a newer copy in the folder says it was not loaded, in
    U13's words; one that finds a copy no newer than the screen says nothing and records nothing, as during a save. A second
    Save asked meanwhile says "⏳ A save is already under way — this one runs as soon as it finishes." Once the save has
    finished, both work as before.
  - **Test:** audit-import "v2.00 (U20) — the Web Locks stand-in behaves as the API does" (19 checks). This is the U20
    probe's lock mock, ported as the suite helper `webLocks()`, with its own tests: first come first served across tabs, a
    rejection and a throw letting go, let go before request() settles, independent names, ifAvailable, shared and
    exclusive, query and a closing tab, what it does not model refused, and 300 seeded requests. Then audit-import
    "v2.00 (U20) — a save waiting for another tab’s save is under way" (65 checks): two tabs of one browser share one lock
    manager, and the second tab's 💾 Save waits for the first tab's held save. It covers ↶ Put back, a refresh of a newer
    copy, and Live view's ↻ Refresh now with nothing recorded, with and without a history copy kept minutes before; after
    the refresh it checks Save yours over theirs and one more Save. It also covers the screen exactly the folder's copy,
    and Load theirs as the operation that waits. Controls: a second Save waiting behind this tab's own save; the waiting
    save counted by the harness itself (the uncounted wait alone was the cause). Checks labelled a GUARD pass on the board
    before the change too, by design: the stand-in's sanity at the end of each case, how a save ends when the autosave
    throws, when the lock request is refused and when asking for it throws, and Save yours over theirs without a history
    copy; each holds what a wrong form of the change would break. 23 checks fail on the board before the change, and every
    one of them is neither a control nor a guard; every control and guard passes on both.
  - **Mutations:** `v200-u20-wait-uncounted`, `v200-u20-failed-stays-counted`; each caught by the focused block (full-suite
    sensitivity runs in the final-tree queue).
  - **Not covered:** the first waiting Save gives no sign that it waits (the U20 probe's O1). Not run as the operation that
    waits: ✍ Take the pen and Save yours over theirs. Save yours over theirs asks its question inside the queue, so a tab
    with that dialog open holds the lock: saves, ↶ Put back and adoption in this browser's other ORBIT tabs wait or are
    refused meanwhile, in words that do not say the save is in another tab (no copy is lost). When what waits is Load
    theirs, U2's refusal still says "a save was under way". Real Chromium: the round-1 money review ran this change in real
    Chromium with Chromium's own Web Locks (board `c42be8e7`, whose `saveSerial` is this commit's): two and three tabs, a
    waiting save counted, ↶ Put back refused while it waits, a second Save counted as two, a waiting save that throws, a tab
    closed while it holds the lock, and the board opened from file://; all of that passed. It was run again on the final
    board of the fix round (`84cf2bf4`), with the same result: every behavioural check passed, and on the board before the
    change the six checks of a waiting save fail. (The script's own check that the page makes no other request fails on both
    boards, because the board asks for its shared state file; that is the script's assumption, not the board.) A refresh that
    records the folder's copy as the base with no second tab is U30, next.

(1b) REPLACEMENTS IN THE SAME COMMIT (the tests review's S3; principle 4: each line is false once U20 lands):

  U2 entry (2 of 2), its "Not covered" bullet (NEXT-VERSION.md line 701 at 7ee498a):
    old: "  - **Not covered:** a save waiting for another tab's Web Lock is not counted as under way until it starts."
    new: "  - **Not covered:** a save waiting for another tab's Web Lock was not counted as under way until it started; U20
         (below) counts it from the moment it is asked for."
  U13 entry, its "Not covered" bullet (line 727):
    old: "    a save waiting for another tab's Web Lock is not counted (U20); the other adoption paths in the ledger (U24)."
    new: "    a save waiting for another tab's Web Lock was not counted (U20, below, counts it); the other adoption paths in the
         ledger (U24)."

(1c) "Unresolved after R1–R5 (11 Oct)":
  New line after the U14 line:
  - **U20: built as its own commit** (the lead's decision under Brad's word of 12 Oct, about 5:30 PM ET, to keep pressing):
    a save, or Load theirs, waiting for another tab's Web Lock is counted as under way from the moment it is asked for,
    until it ends (above). U2's refusal and U13's two guards now see it.
  Edits in existing lines:
    U2 line (786):  "Its separate reopening and adoption findings stay open in the ledger (U15–U20)."
                ->  "Its separate reopening and adoption findings stay open in the ledger (U15–U19); U20 is built (below)."
    U13 line (800-801): "stay open in the ledger (U16–U18,\n    U20)"  ->  "stay open in the ledger (U16–U18; U20 is built,
                below)"

======================================================================================================================
COMMIT 2 (U30) -- NEXT-VERSION.md
======================================================================================================================

(2a) NEW ENTRY, after the U20 entry:

- **U30 — a refresh takes the folder's copy as the one the work came from only when it is what is on screen** (the lead's
  decision, as for U20). It applies with nothing recorded for the folder: an opening that found no copy there and a
  colleague's or another machine's save after it, a reopen with unsaved work, a board saved to its own file, a board file
  handed over, another year never loaded here, or a browser that never kept a record. A refresh that found the folder's
  copy not newer than the screen took it as the one the work on screen came from, "as it always was" (v1.89), whatever was
  on screen. The next 💾 Save then wrote the work on screen over that copy without asking. So did the Live timer's
  autosave, one tick after it had said "Nothing was written" and offered the choice. With a history copy kept less than
  ten minutes before, the copy written over was kept only as a recent copy, and one more Save removed it. No second tab
  was needed; U20 was its two-tab form. Now the refresh records the folder's copy only when it is what is on screen: the
  same stamp, as every change stamps the board anew. Otherwise it records nothing and says nothing, and Save asks: Load
  theirs (your work kept aside), or Save yours over theirs (theirs kept in the folder's history as a spaced copy, whatever
  the spacing). With nothing recorded, nothing the board says on that route claims an order it cannot know: Save's
  question no longer says theirs was saved "after the copy you are working from"; ↶ Put back, after Load theirs, no longer
  says Alice saved the folder's copy "after it"; and Load theirs refused for work already kept no longer calls the
  folder's copy "a newer copy".
  - **What users may see:** with nothing recorded and other work on screen, 💾 Save and every autosave tick say
    "⛔ Alice saved O&M FY27 to the shared folder 2 minutes ago, and this browser has no record of which copy in the folder,
    if any, the work on screen came from. Nothing was written. Load theirs … · Save yours over theirs …" until one is
    chosen. After Load theirs, ↶ Put back says "… 💾 Save will ask before it writes over the shared folder, which Alice
    saved; this browser has no record of which copy there, if any, this work came from." With other work already kept,
    Load theirs says "⚠ Alice saved a copy to the shared folder (…), but this browser already keeps earlier work aside …
    so their copy was not loaded and nothing was lost." Until now the board wrote over the folder's copy without asking.
    A board showing exactly the folder's copy is recorded as before and saves with no question. With a copy recorded, all
    three lines are unchanged, and so are the words for work kept aside from a board file.
  - **Test:** audit-import "v2.00 (U30) — a refresh takes the folder’s copy as the base only when it is on screen" (89
    checks). The rule is the stamp, so it is run through every way a refresh comes with nothing recorded:
    - the Live timer alone in one tab, with and without a history copy kept minutes before: tick 1, tick 2 and 💾 Save
      each ask and write nothing, and the words are checked; then Save yours over theirs, one more Save and a reopen, with
      the folder's copy kept as a spaced history copy throughout;
    - ↻ Refresh now, then Save; and Save, then a refresh, then Save;
    - a second tab whose Save waits while the Live timer ticks twice (U20's case, with the first tick's own refresh after
      the wait);
    - a reopen with unsaved work, whose opening's own connect is not quiet, with and without the history copy; and a board
      saved to its own file, then ↻ Refresh now (the tests review's cases; both then Save yours over theirs, one more Save
      and a reopen);
    - a board file handed over, newer than the folder's copy: Save, Load theirs and ↶ Put back, with the put-back line
      checked word for word; and the same with other work already kept, with the refusal checked word for word;
    - another year: FY28 saved by another machine and never loaded here, ↻ Refresh now on FY28, then Save;
    - controls: the screen exactly the folder's copy, recorded and saved with no question (and during a save, U13's rule
      holds); the first save of a new board into an empty folder; an ordinary refresh with nothing unsaved; and, with a
      copy recorded, the question's words, the put-back line and the kept-work refusal as they always were; and work kept
      aside from a board file, put back with its old words.
    Checks labelled a GUARD pass on the board before the change too, by design (the first Save's question, the stand-in,
    and Save yours over theirs with no history copy). 46 checks fail on the board before U20, and 44 on the U20 board; each
    is neither a control nor a guard. Every control and guard passes on all three.
  - **Mutations:** `v200-u30-base-whatever-on-screen`, `v200-u30-base-only-other-copy`, `v200-u30-unrecorded-said-after`,
    `v200-u30-recorded-said-unknown`, `v200-u30-unsaved-this-session-only`, `v200-u30-quiet-refresh-only`,
    `v200-u30-unsaved-only`, `v200-u30-putback-said-after`, `v200-u30-putback-said-unknown`, `v200-u30-putback-file-unknown`,
    `v200-u30-occupied-said-newer`, `v200-u30-occupied-said-unknown`; each caught by the focused block. U13's case (3c) has
    other work on screen, which this rule now stops before U13's guard is reached; on this board U13's
    `v200-u13-base-while-saving` and `v200-u13-clash-while-saving` are caught by the U20 and U30 blocks' same-copy cases.
  - **Not covered:** a different folder copy stamped to the same millisecond as the screen (clock skew) is recorded, as
    before. A folder copy with no stamp at all is written over with no question, as before (every copy this board writes
    is stamped). The ⛔ line repeats at every autosave tick until Load theirs or Save yours over theirs is chosen. A
    non-quiet Connect in this case says nothing about the folder's copy, as before. With a copy recorded and the folder's
    copy not later than it (a copy put on screen from elsewhere: U29, in the ADOPT track), the words "after the copy you
    are working from", "saved after it" and "a newer copy" are still said, unchanged. This commit was not run in real
    Chromium: what it changes (the refresh's rule and three status lines) does not depend on the browser's locks, and was
    run in jsdom with the folder stand-in.

(2b) REPLACEMENT IN THE SAME COMMIT (the tests review's S2), the U13 entry's "Mutations" bullet (lines 723-725):
    old: "  - **Mutations:** `v200-u13-pull-while-saving`, `v200-u13-base-while-saving`, `v200-u13-pull-unchecked`,
         `v200-u13-said-nothing-loaded`, `v200-u13-clash-while-saving`; each caught by the focused block (full-suite sensitivity
         runs in the final-tree queue)."
    new: "  - **Mutations:** `v200-u13-pull-while-saving`, `v200-u13-base-while-saving`, `v200-u13-pull-unchecked`,
         `v200-u13-said-nothing-loaded`, `v200-u13-clash-while-saving`; each caught by the focused block (full-suite sensitivity
         runs in the final-tree queue). Since U30 (below), this block's case (3c) stops at U30's rule before U13's
         base-record guard, so `v200-u13-base-while-saving` and `v200-u13-clash-while-saving` are caught by the U20 and U30
         blocks' cases that put the folder's copy itself on screen (U20 (4), U30 (5b))."

(2c) "Unresolved after R1–R5 (11 Oct)", new line after the U20 line (scoped, as the money review asked):
  - **U30: built as its own commit after U20** (the same decision): a refresh records the folder's copy as the one the
    work came from only when it is what is on screen; otherwise Save asks, and with nothing recorded nothing on that route
    says theirs came after, or is newer (above). In this case no copy is written over unasked, and none is left only as a
    recent history copy. U29 (another copy put on screen, then Save; the ADOPT track) is a separate finding.

======================================================================================================================
UNRESOLVED-LEDGER.md -- text to APPEND to the Status cell of each row (the lead fills <sha>, <time>)
======================================================================================================================

  Row U20 (the main table, "| U20 | **A save waiting for another tab's Web Lock …"):
    " **Decided by the lead, 12 Oct (Brad, about 5:30 PM ET: "Don't wait for me. Let's keep pressing throughout to get
    this next version published."):** count a save from the moment it is asked for. **COMMITTED as `<sha>` (<date>, <time>
    ET)**: board `83b87782`, audit-import `d7d41c6a`, mutate `6b4c83d6`. `saveSerial` counts a save in `_saveBusy` when it
    is asked for, waiting for the lock included, and uncounts it once it has settled, however it ends (saved, refused,
    failed, thrown, lock request refused); Load theirs waits in the same queue and is counted the same way. U2's put-back
    refusal and U13's two guards now see a waiting save. Focused blocks 84 checks (the lock stand-in's 19 self-tests and 65
    on the board): 23 fail before, all pass after; guards labelled. Two mutations caught by the block. Reviewed (round 1,
    money and tests lenses) and fixed in a fix round (13 Oct): labels, Load theirs waiting, drafts. Full audit-import and
    full-suite sensitivity: in the final-tree queue."

  Row U20 (the triage table, "| U20 | P2 (P1 if reproduced) | Two tabs: …"):
    " **COMMITTED as `<sha>` (<date>, <time> ET)**; see the U20 row above."

  Row U30 ("| U30 | **A refresh that records the folder's copy as the base before a Save …"):
    " **Decided by the lead, 12 Oct (as U20).** **COMMITTED as `<sha>` (<date>, <time> ET)**, after U20: board `84cf2bf4`,
    audit-import `3a34d922`, mutate `d174d05d`. `driveStorePull` records the folder's copy as the base only when it is what
    is on screen (`theirs===ours`); otherwise it records nothing and says nothing, and Save asks. With nothing recorded,
    Save's question, ↶ Put back's line and Load theirs refused for kept work no longer claim theirs came after or is newer.
    Focused block 89 checks: 46 fail before U20, 44 on the U20 board, all pass after; guards labelled. Twelve mutations
    caught by the block, among them three wrong forms of the rule (this session's flag, unsaved work, quiet refresh only)
    that the round-1 block let through. U13's `v200-u13-base-while-saving` and `v200-u13-clash-while-saving` are caught on
    this board by the U20 and U30 blocks' same-copy cases. Full audit-import and full-suite sensitivity: in the final-tree
    queue."

======================================================================================================================
FOR WHICHEVER OF U30 AND ADOPT (U24/U29/U31) LANDS SECOND -- a rebase note, not a change of this track
======================================================================================================================

  The ADOPT board (rec/L6/adopt/diffs/all-c3-vs-base.diff) does NOT touch driveStorePull (round 1's finding 4 said it did;
  that was wrong). It rewrites the same `driveClashSay` line U30 rewords, and adds `loadedNotSaved`, which records a
  loaded copy's own stamp in `_driveBase`. So:
  - the two `driveClashSay` hunks conflict textually; the merged phrase needs three cases:
      +(!driveBaseOf(ap)? ', and this browser has no record of which copy in the folder, if any, the work on screen came from. '
        : theirs>driveBaseOf(ap)? ', after the copy you are working from. '
        : ', and that is not the copy you are working from. ')
  - mutation entries that stop matching once the other lands: U30's `v200-u30-unrecorded-said-after` and
    `v200-u30-recorded-said-unknown`, and ADOPT's `v200-adopt-u29-clash-after`; each needs its find rewritten against the
    merged text (listed, never silently);
  - the two lines U30 now words for nothing recorded (↶ Put back's "saved after it" and Load theirs's "a newer copy") test
    only whether a copy is recorded. With ADOPT's `loadedNotSaved`, a copy can be recorded that is later than the folder's
    (U29's case), and those two lines would then still say "after" / "newer". The merge should give them the same three
    cases as `driveClashSay` (no record / theirs later / neither), with a check each.
```

---
Fix-round section finalised at 1:51 PM ET on Tue 13 Oct 2026 (read with `TZ=America/New_York date`). The last bounded run, fr4-rc-u20-b0, started at
1:48:54 PM ET and ended at 1:49:11 PM ET.
