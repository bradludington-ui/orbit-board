# U20U30: independent adversarial verification, round 2, LENS A (data loss and money)

This is the verifier's own directory. Times are Eastern, each read with `TZ=America/New_York date`. The review started at
1:53 PM ET on Tue 13 Oct 2026; this README was finished at 2:42 PM ET. No earlier attempt of this review existed: `verify-money-r2/` did not exist
at 1:53 PM ET, so nothing was carried over.

**What I did not touch.**
- Nothing in `/home/user/orbit-board` or `/home/user/orbit-ui` was edited, staged, committed or pushed. orbit-board was only
  read: `git log`, `git diff --stat`, `git show HEAD:NEXT-VERSION.md` and the ledger.
- The builder's files were read only. My copies are in `copies/`.
- `tools/export-audit/mutate.mjs` was never imported or run. It was read as text only, through `rec/bin/mkmut.py` and
  `rec/bin/mcount.py` with `python3 -I`.
- `playwright install` was never run. Chromium is `/opt/pw-browsers/chromium`, with playwright-core from the copy's
  `node_modules`.
- The full audit-import and audit-board were not run.

## VERDICT: sound-with-issues (no must-fix in the two commits)

**What holds.**
- U20 counts a save, and Load theirs, from the moment it is asked for. That holds in real Chromium too.
- U30's rule (`if(!base && theirs!==ours) return false;`) closes the unasked overwrite on every route the builder, round 1 and
  I tried.
- Both commits leave money and exports alone: no money or export code is in either board diff.
- The export audit passes on c2f and on the base alike.
- Every builder number I re-ran matches.

**What I found.** None of it is caused or made worse by these commits, so none of it is a must-fix for them:
1. **A new P1 data-loss route, already on the base and still on c2f: two tabs of one browser on the same board.** The tabs
   share the board's browser storage, and three variants lose work (details and evidence under SF1):
   - (T) folder mode: a Save writes over a folder copy it never showed, unasked, and that copy is gone after one more Save;
   - (TF) file mode: the same with the board file;
   - (TD) the opening's own connect replaces unsaved work and keeps nothing aside.

   This is not U20 or U30. It is a separate mechanism: the board and its record are written separately by each tab. It
   needs its own ledger row before v2.00 is published. A 1-line sketch closes all three variants and keeps the U20/U30 blocks
   green; it has been checked against those only.
2. **Unwritten merge conflicts with two other proposed tracks.** U19 rewrites the same ↶ Put back status line that U30 changes.
   U18 rewrites the same `driveClashSay` lines. The builder's rebase note covers ADOPT only. I resolved both merges and checked
   them with mcount (text only). Details under SF2.
3. **Draft and test nits** (minor list).

## Identities (`git hash-object`)

| what | blob |
|---|---|
| base board (`rec/L6/base` = orbit-board `7ee498a`, product `d66dd60`) | `fce8a391bd8a248d5185e199d22190c1687eaea0` |
| base audit-import / mutate.mjs.txt | `4aba2506…` / `cbc6defc…` |
| **c1f** board (U20) / audit-import / mutate | `83b87782710c2dee6ca2dbc030aabb22a92c9a0f` / `d7d41c6accb997073280c9a172fa27ae1feab7c0` / `6b4c83d64559b77fe1995c53bde366e0f94067e4` |
| **c2f** board (U20+U30) / audit-import / mutate | `84cf2bf4ef12f2e6dbef255503c4c2ecf23034e2` / `3a34d922731dbb5c67dc0de656cd567250793da1` / `d174d05da7e5efc45e3478b192605a02899d7dc7` |
| audit-recon / audit-board / audit-other (all copies) | `529e36f7` / `a7c575e5` / `d89396b0` |
| boot.mjs (all copies) | `9c4f49ad8cec537097bdf485458cfd2a09b06594` |
| focused harness G-u2030 (U20 + U30 blocks, verbatim from c2f's audit-import) / G-u20 / G-u30 | `64b7c4b0` / `23fa9b42` / `e4100af9` |
| probe block `bin/probe3-block.mjs.txt` (final) | `045fb4456fdaabaf0b1a093ba9499344fd2d4a76` |
| probe harness P3-verify (T, Tc) / P3b-verify (T, Tc, TF, TFc, TD) | `90d4134d` / `53ca7b43c05df0c2e3923d89c8ee36ae7caba291` |
| own mutation entries `bin/own-entries.mjs.txt` | `41c8662c737a8b8589578be63a180ed6c2e237fa` |
| real-Chromium script `bin/rc-u20.mjs` (round 1's, temp dir moved) | `41f3fe6321979463014f3f2d913d4083c5904dfa` |
| **sketch for SF1** `copies/c2x` board (c2f + 1 line in `persist()`) / its diff | `eea8fc4da8ce3285ce8464ee60780a67ad4cb023` / `diffs/c2x-sketch-vs-c2f.diff` `6f22ca85` |
| resolved merge c2f + U19 (`u19/fr/c1`, board `f6ac4b9d`) | `merge/u19_fr_c1.resolved.html` `2fe63074`; diff vs U19 `diffs/merge-u19-resolved-vs-u19.diff` `f15069d4` |
| resolved merge c2f + U18 (`u18/c1`, board `e3986f30`) | `merge/u18_c1.resolved.html` `5c4663f7`; diff vs U18 `diffs/merge-u18-resolved-vs-u18.diff` `03aeedd3` |

orbit-board HEAD is now `191daf0`, a records-only commit. NEXT-VERSION.md at HEAD has the same blob as at `7ee498a`
(`65265c13`), so the drafts' quoted lines are still current.

The diffs were re-made in `diffs/` and agree with the builder's:
- the board diffs are 1/8 lines (c1f vs base) and 5/22 lines (c2f vs c1f), removed/added;
- the audit-import and mutate diffs are additions only (0 removed lines): +531 and +7 for c1f vs base, +369 and +39 for c2f vs c1f.

## Reading the change against every caller

**`saveSerial`** is called by `saveInPlace` (and through it `takePen`), `saveInPlaceFile`, `driveStorePush` and
`driveResolve`.
- `_saveBusy++` runs before `_saveChain.then(run, run)`.
- `p.then(done, done)` is registered before the caller can `await p`, so `done` runs first. Every continuation after a save,
  including the same Live tick's refresh, sees the save uncounted.
- `_saveBusy` has four readers: the queued notice, ↶ Put back, and the two branches of `driveStorePull`. Nothing waits on it,
  so it cannot deadlock.
- Exits:
  - a lock request that rejects or throws: `done` runs;
  - a function that throws: `done` runs;
  - a hang: the save stays counted, as before.
- Real Chromium on c2f, with Chromium's own Web Locks:
  - W1 to W7 and file:// all pass;
  - on the base, W1 to W6 fail;
  - the only failure on both is the script's own "no other request" check (the board fetches `prio-state-om.json`).

**`driveStorePull` (U30).** The new line sits in the not-newer branch, with no wait after `ours` is read.
- Equal stamps mean the same copy, because every folder copy is written by a push that stamps `MS.ts` and every edit
  (`save()`) restamps.
- Paths that put a copy on screen without restamping keep that copy's own stamp: ↶ Put back, the history put-back,
  `adoptShared`/`sharedArrived`.
- Two `persist()`-only changes do not restamp: `MS.spAce` (line 14550) and the reprogramming migration (line 22720). Each is
  this browser's own metadata, not someone else's work, so no copy can be lost through them. That is why "every change stamps
  the board anew" in the comment and the draft is slightly too wide (minor m3).

**`driveClashSay`, `keptPutBack`, `keptOccupiedMsg`, `_driveResolveRun('theirs')`.** I read the words on every route that
reaches them.
- With nothing recorded, each says only what is known.
- With a record, the old words stay.
- `keptOccupiedMsg`'s other four callers pass three arguments, so their words are unchanged.
- The swap case of ↶ Put back keeps the old "the saved file, which X saved after it" words. That is false in folder mode and
  pre-existing, and U19's track rewrites it (see SF2).

**Paths next to it, with nothing changed by these commits:**
- the history put-back records the folder's current copy only after force-keeping it as a spaced copy;
- "Save yours over theirs" force-keeps theirs;
- `driveResolve` with no copy records 0 and pushes (nothing to write over);
- the boot file path (`PUB_FILE_TS`) leaves the folder record alone (U29/ADOPT territory).

## SF1 (should-fix: a NEW ledger row, P1 data loss, pre-existing). Two tabs of one browser share the board's storage

The board under `_AP.key` and its record under `_AP.key+'.base'` (`{file, folder, dirty}`) live in browser storage, which
every tab of the same origin shares. That includes every file:// page in Chromium.
- Each tab keeps its own board (`MS`) and its own record (`_driveBase`, `LASTKNOWN`, `_baseDirty`) in memory.
- `persist()` writes the board.
- `driveBaseSet` and `baseSet` write the record, at other moments, and `baseSet` merges into whatever another tab left there.
- So after both tabs have written, a reopen, or a new tab, can pair one tab's work with the other tab's record.

The board has no `storage` listener and no BroadcastChannel (grep: none).

**Probe.** `bin/probe3-block.mjs.txt` builds `probe/P3b-verify.mjs`. jsdom gives each board its own storage, so after each
step the acting tab's whole storage is copied into the other tab's. That is exactly what one shared store holds after the
step, because only one tab acts per step. Expected values are written by hand.

- **(T) folder mode.**
  1. Tabs A and B both load F0 from the folder.
  2. A saves A-EDIT; A's record goes to storage.
  3. B, still on F0's work, types B-EDIT. B's board goes to storage, beside A's record.
  4. The board is opened again (a reload, or a new tab). The opening's connect says nothing.
  5. 💾 Save writes B-EDIT over A-EDIT **without asking**: "✅ Saved O&M FY27 …".
  6. One more Save: history `[["F0",false],["B-EDIT",true]]`. **A-EDIT is in no copy the board can reach.**
- **(TF) file mode, the same steps with the board file.** 💾 Save writes B-EDIT over A-EDIT's save with **no HOLD ON**
  (`questions=[]`, `writes=1`). The stored record `file` is A's save.
- **(TD) the record's "unsaved" flag.**
  1. B types B-EDIT1.
  2. A saves A-EDIT, so storage says `dirty:false`.
  3. B types B-EDIT2. B had already marked its work unsaved, so it does not write `dirty:true` again.
  4. Alice's other machine saves X-EDIT.
  5. The board is opened again. The opening's connect loads X-EDIT and **keeps nothing aside**: "⬇ Loaded … saved by Alice
     just now".
  6. B-EDIT2 is in no copy at all.
- **Controls (Tc, TFc):** one tab saves, reopens and saves with no question. Both pass.

**Results.** On the base (`fce8a391`) and on c2f (`84cf2bf4`), 6 of 15 checks fail, identically: (T) 3, (TF) 1, (TD) 2.
Every control passes. The first probe, P3-verify ((T) and (Tc) only), gives 3 of 7 failing on both. So this is
**pre-existing and unchanged by U20/U30**.

**Sketch, not for commit as is (`copies/c2x`, `diffs/c2x-sketch-vs-c2f.diff`).** Write this tab's record with the board, so
the stored pair always comes from one tab:

```js
    localStorage.setItem(_AP.key, JSON.stringify(MS));
    try{ baseSet({file:LASTKNOWN, folder:_driveBase, dirty:_baseDirty}); }catch(e){}
```

On c2x:
- **P3b-verify passes 15 of 15**:
  - (T): the connect says the clash, and Save asks;
  - (TF): HOLD ON is asked, and nothing is written;
  - (TD): B-EDIT2 is kept aside.
- **G-u2030 passes 173 of 173.**

Not run on c2x: the full suites, mutants, or real Chromium.

**Proposed ledger row** (for the lead):

> | Uxx | **Two tabs of one browser on the same board pair one tab's work with the other tab's record.** The board and its record
> (which saved copy it came from; unsaved or not) share browser storage across tabs and are written separately. After both
> tabs have written, a reopen or a new tab shows tab B's work with tab A's record: 💾 Save then writes it over the folder
> copy (or board file) tab A saved, without asking, and one more Save prunes that copy from the history (folder) / the file
> holds only B's work; or, with A's "saved" flag, the opening's connect loads a newer folder copy and keeps B's unsaved work
> nowhere. | U20U30 money review r2, 13 Oct | Measured on fce8a391 and 84cf2bf4 (`verify-money-r2/probe/P3b-verify.mjs`,
> 6/15 fail on both; controls pass) | Open, P1 (data loss). A one-line sketch (`persist()` writes this tab's record with the
> board) passes the probe 15/15 and G-u2030 173/173; not otherwise run. |

The U20 draft's "Not covered" should also say that two tabs of one browser on the same board share its storage, and that
this is separate (the new row).

## SF2 (should-fix: drafts). The rebase note covers ADOPT only; U19 and U18 conflict too

`git merge-file` (text only, base `fce8a391`) of c2f with each other proposed track's board:

| track (board) | result | where |
|---|---|---|
| ADOPT `adopt/c3` | 1 conflict | `driveClashSay`, already in the builder's note |
| **U19 `u19/fr/c1` (`f6ac4b9d`)** | **1 conflict** | **the ↶ Put back status lines.** U19 splits them on `k.meta.why==='swap'`; U30 adds `after` |
| **U18 `u18/c1` (`e3986f30`)** | **1 conflict** | **`driveClashSay`.** U18 adds the `refused==='late'` words on the line after the one U30 rewords |
| HOLD `hold/c2` | clean | — |

Both conflicts resolve without loss.

**U19 resolution:** keep U19's lines, add U30's `const after=…` before `setStat`, and give the non-swap branch U30's phrase:

```js
    +(k.meta.why==='swap'? '💾 Save will ask before it writes over a copy saved after the one this work came from.'
      : '💾 Save will ask before it writes over '+esc(keptWhere(k.meta))+', which '+esc(k.meta.by||'someone')+(after? ' saved after it.' : ' saved; this browser has no record of which copy there, if any, this work came from.'))
```

**U18 resolution:** keep U30's three lines, then U18's `refused==='late'` branch. For a `late` refusal with nothing recorded
(the first save, into a folder that gained a copy meanwhile), the merged line says "no record", which is true. U18's text
alone says "after the copy you are working from", which is false there.

**mcount (text only) on the resolved boards:**
- c2f's 1342 entries match exactly once on both;
- U19's 1344 entries match exactly once on the U19 merge;
- U18's 1336 entries match exactly once on the U18 merge.

**Drafts:** add both to the "FOR WHICHEVER … LANDS SECOND" note, alongside ADOPT, naming the merged text above. U19's track is
still moving (`u19/git/fr2c1` is `7a6e29cb`), so re-check at landing.

## Minor

- **m1 (draft U20 "What users may see").** "one that finds a copy no newer than the screen says nothing and records nothing" is
  true only with nothing recorded. With a copy recorded that differs, the refresh says the clash, during a waiting save too.
  Suggested wording: "…says nothing new and records nothing; with a different copy recorded, it says the clash as before".
- **m2 (draft (1c)).** "U13 line (800-801)": the text "(U16–U18,\n U20)" is at NEXT-VERSION.md lines **799–800**. Lines 701,
  727, 723–725 and 786 are right.
- **m3 (board comment and U30 draft).** "as every change stamps the board anew" is too wide: `MS.spAce` and the reprogramming
  migration persist without restamping. No work of anyone's is lost through them. "as every edit stamps the board anew" would
  be exact.
- **m4 (tests).** My mutant `vr2-u30-putback-any-year` **survives**: 0 of 89 U30 checks fail. It makes ↶ Put back test "a
  record for ANY year" instead of this year's.
  - The real board is right, because it uses `driveBaseOf(mySlug())`.
  - The wrong form would say "saved after it" for work kept on FY27 with only an FY28 record.
  - A per-year put-back case would catch it. That is in the tests lens's domain; listed here for completeness.
- **m5 (pre-existing words).**
  - U2's refusal says "a save was under way" when what waits is Load theirs (the builder lists it).
  - The swap case of ↶ Put back says "the saved file, which X saved after it" in folder mode, and Save may then ask nothing;
    U19 fixes it.

## The lead's six principles, checked literally

1. **No copy lost.** Met for U20/U30's own routes. Mine and the builder's: real product paths, the history variants, Save
   yours over theirs (theirs kept spaced), and reopen. **Not met on the new two-tab storage route (SF1)**, which is
   pre-existing and identical on the base.
2. **Refuse or ask.** With nothing recorded, Save asks; the words claim no order.
3. **Money and exports.** Untouched by both diffs. The export audit `audit.mjs` passes on c2f and on the base.
4. **Words true.** Met on the changed lines: base fail/pass and c2f pass for (8), (9), and controls (8c), (8d), (9c).
   Pre-existing false words remain in the swap case (m5). Two drafts' lines are imprecise (m1, m3).
5. **Smallest change.** Commit 1 is 8 lines. Commit 2 is one rule line, one parameter, one boolean and one guarded line.
6. **Existing checks preserved.** Additions only. mcount: base 1328/1328, c1f 1330/1330, c2f 1342/1342. I did not re-run
   `kept-theirs-wrong-word` (F-folderA). By reading, its line is still reached with a copy recorded.

## Runs (each node, python and Chromium run bounded by `setsid -w timeout -k 10 600`; started through `bin/bx.sh`, which checks the lock first)

No run waited for the lock (`AUDIT_IMPORT_RUNNING` was absent at every check), and none was skipped or timed out.

| label | start (ET) | exit | wall s | result | log | PID |
|---|---|---|---|---|---|---|
| G-u2030-c2f | 2:02:26 PM | 0 | 345.2 | 173/173 (locks 19, U20 65, U30 89) | logs/G-u2030-c2f.log | 28227 |
| P3-verify-c2f | 2:05:45 PM | 1 | 57.2 | 4/7; (T) 3 fail (SF1) | logs/P3-verify-c2f.log | 32050 |
| mcount-base | 2:05:54 PM | 0 | 27.6 | 1328/1328 once | out/mcount-base.json | — |
| mcount-c1f | 2:06:21 PM | 0 | 28.4 | 1330/1330 once | out/mcount-c1f.json | — |
| P3-verify-base | 2:06:42 PM | 1 | 61.5 | 4/7; same 3 fail | logs/P3-verify-base.log | 630 |
| mcount-c2f | 2:06:50 PM | 0 | 26.0 | 1342/1342 once | out/mcount-c2f.json | — |
| G-u2030-base | 2:08:11 PM | 1 | 393.1 | 69 fail: U20 23/65, U30 46/89, locks 0/19 | logs/G-u2030-base.log | 2087 |
| M-c2f-v200-u20-wait-uncounted (G-u20) | 2:10:52 PM | 1 | 150.9 | caught, 17/84 | logs/M-c2f-v200-u20-wait-uncounted-G-u20.log | 4033 |
| M-c2f-v200-u20-failed-stays-counted (G-u20) | 2:13:24 PM | 1 | 146.9 | caught, 2/84 | logs/… | 6781 |
| G-u2030-c1f | 2:14:45 PM | 1 | 429.5 | 44 fail, all U30; U20 65/65 | logs/G-u2030-c1f.log | 7949 |
| M-c2f-vr2-u20-uncount-early (own; G-u20) | 2:15:52 PM | 1 | 185.3 | caught, 18/84 | logs/… | 8920 |
| merge-file c2f × {u18, u19, hold, adopt} (text) | 2:16 PM | 1/1/0/1 | <1 | conflicts as in SF2 | merge/ | — |
| mcount on resolved merges (text) | 2:18 PM | 0 | <30 | all once (SF2) | (stdout above) | — |
| M-c2f-v200-u30-base-whatever-on-screen (G-u30) | 2:18:58 PM | 1 | 238.7 | caught, 42/89 | logs/… | 11100 |
| P3b-verify-c2f | 2:21:57 PM | 1 | 84.1 | 9/15; 6 fail (SF1) | logs/P3b-verify-c2f.log | 13532 |
| M-c2f-v200-u30-unsaved-only (G-u30) | 2:22:58 PM | 1 | 209.6 | caught, 14/89 | logs/… | 14068 |
| P3b-verify-base | 2:23:21 PM | 1 | 76.4 | 9/15; same 6 fail | logs/P3b-verify-base.log | 14241 |
| rc-u20-c2f (real Chromium) | 2:24:38 PM | 1 | 12.5 | 13/14; only the script's env check fails | logs/rc-u20-c2f.log, out/rc-u20-c2f.json | 15360 |
| rc-u20-base (real Chromium) | 2:24:50 PM | 1 | 12.6 | 7/14; W1–W6 fail, as expected | logs/rc-u20-base.log | 15620 |
| P3b-verify-c2x (sketch) | 2:25:04 PM | 0 | 90.5 | 15/15 | logs/P3b-verify-c2x.log | 15892 |
| M-c2f-v200-u30-quiet-refresh-only (G-u30) | 2:26:31 PM | 1 | 267.0 | caught, 16/89 | logs/… | 16970 |
| G-u2030-c2x (sketch) | 2:26:34 PM | 0 | 335.7 | 173/173 | logs/G-u2030-c2x.log | 17020 |
| M-c2f-v200-u30-unsaved-this-session-only (G-u30) | 2:30:59 PM | 1 | 117.7 | caught, 21/89 | logs/… | 19489 |
| audit-export-c2f (`audit.mjs`) | 2:32:32 PM | 0 | 29.8 | all checks passed | logs/audit-export-c2f.log | 20160 |
| M-c2f-v200-u30-putback-said-after (G-u30) | 2:32:57 PM | 1 | 102.0 | caught, 1/89 | logs/… | 20437 |
| audit-export-base (`audit.mjs`) | 2:33:01 PM | 0 | 26.4 | all checks passed | logs/audit-export-base.log | 20463 |
| M-c2f-v200-u30-occupied-said-newer (G-u30) | 2:34:40 PM | 1 | 91.6 | caught, 1/89 | logs/… | 21406 |
| M-c2f-v200-u30-putback-file-unknown (G-u30) | 2:36:12 PM | 1 | 105.0 | caught, 1/89 | logs/… | 22363 |
| M-c2f-vr2-u30-putback-any-year (own; G-u30) | 2:37:58 PM | 0 | 111.8 | **survives**, 0/89 (m4) | logs/… | 23339 |

Mutant builds (`mk-*`, `mkmut.py`, text only) each exited 0, and each find matched exactly once. They are listed in
`logs/runs.txt`.

All counts agree with the builder's: base U20 23, U30 46; c1f U30 44; c2f all pass; the mutant counts; and real Chromium
13/14 against 7/14.

**PIDs** are in `pids.txt`: every lane shell and every bounded run, with label and start time. I killed nothing; every
process ended on its own. At 2:40 PM ET no process of mine was running.

## Deviations (said plainly)

- **The lane wrapper shells** (`bin/lane-*.sh`) ran under `setsid -w timeout -k 10` with bounds of 1300–7000 s, longer than
  600 s, because each runs several runs in sequence. Every node, python and Chromium run inside them was bounded at 600 s
  through `bx.sh`.
- **One `node --check` (a syntax check of `probe/P3b-verify.mjs`)** at about 2:12 PM ET ran without `setsid`/`timeout` and
  without the lock check. It ran while two of my node runs were going, so it briefly made a third. It took well under a
  second.
- **Some small text commands ran without the 600 s wrapper:** `grep`, `sed`, `diff` of small files, `git hash-object`, and
  writing scripts.
- **Two lanes overlapped** (the mutant lane and a probe or harness lane), never more than two of my node or Chromium runs at
  once apart from the `node --check` above. The machine's load was 36 to 40 throughout.

## Not done

- **Not run:**
  - the full audit-import or audit-board;
  - F-folderA / F-folderB;
  - the builder's other existing-entry mutants (`kept-theirs-wrong-word`, `u13-*`, `u2-*`);
  - npm run check, audit-recon, audit-other, audit-ppt, hostile, inject, legacy and boot-same.

  The builder ran all of these on c2f in `clones/c2f`. I re-ran only the export audit.
- **The sketch `c2x`** was run only through P3b-verify and G-u2030. It is a proposal for a new track, not a change to these
  commits.
- **The two-tab storage route was not run in real Chromium.** That storage is shared across one origin's tabs is standard; the
  route needs the folder or file pickers, which the headless script does not provide.
- **Nothing was committed or pushed anywhere.**
