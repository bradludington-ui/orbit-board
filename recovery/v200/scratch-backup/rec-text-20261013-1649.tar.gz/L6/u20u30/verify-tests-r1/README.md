# U20U30, verify-tests round 1 (lens B: test adequacy and regressions)

This is the independent adversarial verifier's record for ORBIT v2.00 release track U20U30:

- U20: a save waiting for the Web Lock is counted.
- U30: a refresh that records the folder copy as the base never lets a Save overwrite unasked.

The builder's work is in `..` (README.md, c1/, c2/, blocks/, mut/, drafts/). I read the builder's files and never changed
them. Every run here used my own copies. **I committed and pushed nothing. I edited, staged and committed nothing in
/home/user/orbit-board or /home/user/orbit-ui.** I never imported, executed or ran `mutate.mjs`, not even to count. I read
it only as text, through `rec/bin/mcount.py`, `mcread.py` and `mkmut.py`, all with `python3 -I`. I never ran
`playwright install`, and I ran no Chromium. I did not run the full audit-import or audit-board.

Times are Eastern, read with `TZ=America/New_York date`.

- **First attempt:** 10:27 AM ET on Tue 13 Oct 2026, until the lead stopped it at about 11:45 AM ET. Its last run's
  exit record is at 11:54 AM ET.
- **This attempt:** resumed at 12:00 PM ET, after I checked that no process recorded in `pids.txt` was still running. It
  reused every run of the first attempt that has an exit record on the same blobs, and re-ran the one run that had none.
- **Closing time:** at the end of this file.

## Verdict

**sound-with-issues.** There is one must-fix, and it is in the tests (U30). There is none in the board.

- **U20 (commit 1): no must-fix.** The change does what it claims. Its new checks catch every plausible wrong fix I wrote
  (5 of 5) and both of the builder's mutations.
- **U30 (commit 2), the board:** the rule (`if(!base && theirs!==ours) return false;`, the stamp) is right on every route I
  tried. That includes two routes the U30 block never takes.
- **U30 (commit 2), the tests:** the U30 block reaches the rule only through **quiet** refreshes: the Live timer and ↻
  Refresh now. Both go through `drivePoll`, which always calls `driveStorePull(true)`. It also reaches the rule only with
  work typed **in the same session** (DIRTY true). Four plausible wrong forms of the rule pass every new check, every
  U2/U13 check and every one of the 21 other folder scenarios. Each brings the unasked overwrite back on a real product
  path, and with a recent history copy it also brings back the loss of F0. The two paths are:
  - a reopen with unsaved work: the opening's own connect, which is not quiet, with DIRTY false;
  - a board saved to its own file that then works out of the folder.
- **Must-fix M1** (below) gives a tested minimal fix: three cases, 20 checks and three mutation entries.

## Identities (git hash-object), checked again at 12:00 PM ET before any use

| copy | board | audit-import | mutate.mjs.txt | other suites |
|---|---|---|---|---|
| b0 (= ../../base, the 7ee498a archive) | fce8a391 | 4aba2506 | cbc6defc | recon 529e36f7, board a7c575e5, other d89396b0 |
| c1 (= ../c1) | 83b87782 | 776c6680 | 6b4c83d6 | unchanged |
| c2 (= ../c2) | c42be8e7 | e0d4186b | 54c7d928 | unchanged |
| c2x (mine: c2 + the proposed test fix, M1) | c42be8e7 (unchanged) | 0ab5fa2b | 6eb9eb61 | unchanged |

The first attempt of this review made the copies in `copies/` with `cp -a` from `../../base`, `../c1` and `../c2`.
`node_modules` is a symlink, as in the base. The builder's c1 and c2 still hold the same three blobs.

`diff -rq` shows that b0 and c1, and b0 and c2, differ only in the board, audit-import and mutate.mjs.txt.

The diffs are in `diffs/`, each against the previous copy:

| diff | blob |
|---|---|
| c1-prioritization-board-grid.html.diff | 8da56921 |
| c1-audit-import.mjs.diff | 5c7bd1e1 |
| c1-mutate.mjs.txt.diff | f0b730fb |
| c2-prioritization-board-grid.html.diff | 22fba455 |
| c2-audit-import.mjs.diff | 5f7d4508 |
| c2-mutate.mjs.txt.diff | 26b770f1 |
| c2x-audit-import.proposal.diff (mine) | e002342d |
| c2x-mutate.mjs.txt.proposal.diff (mine) | b25bdbe3 |

## Every existing expectation is preserved; every new expected value is a literal

- **Additions only.** The suite and mutate diffs remove no lines. In line counts: c1 audit-import +503 (one of them
  empty), c2 audit-import +217 (one empty), c1 mutate +7, c2 mutate +13. No existing check, fixture, expected value or
  mutation entry changed.
- **The blocks.** `../blocks/u20.mjs.txt` (85beabde) and `../blocks/u30.mjs.txt` (9b6c5259) each occur exactly once,
  verbatim, in c2's suite.
- **Literals.** `bin/wants.py` splits each `chk(...)` call at the top level. It flags any call in the expected argument
  other than `J(...)` or the literal builders `SANEW`/`UNRECW`.
  - U20: 70 of 70 expected values are literals.
  - U30: 36 of 36 are literals.
  - The named constants (`WAITW`, `SAID`, `UNSAID`, `SANEW(...)`, `UNRECW(...)`) are hand-written literals.
- **mcount** (text only; `rec/bin/mcount.py`, `python3 -I`; this attempt's runs mcount2-*, 12:01 PM ET):

  | copy | entries matching exactly once |
  |---|---|
  | b0 | 1328 of 1328 |
  | c1 | 1330 of 1330 |
  | c2 | 1334 of 1334 |
  | c2x (with my 3 proposed entries) | 1337 of 1337 |

  No entry is missing, multiple or unparsed.
- **Coverage of the changed code.** Every audit-import scenario that touches `saveInPlace`, `saveSerial`, `_saveBusy`,
  `keptPutBack`, `driveStore*`, `livePoll`, `drivePoll`, `driveAutoConnect`, `driveResolve` or autosave is in one of the
  focused harnesses: F-folderA/B, plus U2 ×2, U13, U20 and U30. I checked this by script at 12:03 PM ET. No other suite
  (audit-board, audit-recon, audit-other, audit, audit-ppt, audit-hostile, audit-inject) names any of them.

## The builder's runs, re-run and compared check by check

`bin/cmp.py` compares every (scenario, case, check) verdict with the builder's `../out/*.checks.jsonl`. The focused
harnesses were rebuilt with a byte-identical copy of the builder's `mkfocused-multi.py` from my copies' suites.

| run | mine | builder | differing verdicts |
|---|---|---|---|
| F-u20, on b0 / c1 / c2 | 20 of 78 fail / 0 / 0 | 20 / 0 / 0 | 0 / 0 / 0 |
| F-u30, on b0 / c1 / c2 | 23 of 48 fail / 21 / 0 | 23 / 21 / 0 | 0 / 0 / 0 |
| F-all (U2 ×2, U13, U20 ×2, U30), on b0 / c1 / c2 | 43 of 254 fail / 21 / 0 | 43 / 21 / 0 | 0 / 0 / 0 |
| F-folder (A+B, 439 checks), on b0 / c2 | 0 / 0 | 0 / 0 | 0 / 0 |
| F-folderA (297) / F-folderB (142), on c1 | 0 / 0 | 0 / 0 | 0 / 0 |

The builder's 15 mutant runs:

| mutant | checks failing (mine) | builder | differing |
|---|---|---|---|
| c1 v200-u20-wait-uncounted | 20 | 20 | 0 |
| c1 v200-u20-failed-stays-counted | 2 | 2 | 0 |
| c2 v200-u20-wait-uncounted | 14 | 14 | 0 |
| c2 v200-u20-failed-stays-counted | 2 | 2 | 0 |
| c2 v200-u30-base-whatever-on-screen | 19 | 19 | 0 |
| c2 v200-u30-base-only-other-copy | 21 | 21 | 0 |
| c2 v200-u30-unrecorded-said-after | 2 | 2 | 0 |
| c2 v200-u30-recorded-said-unknown | 1 | 1 | 0 |
| c2 v200-u2-putback-gen | 1 | 1 | 0 |
| c2 v200-u2-putback-while-saving | 39 | 39 | 0 |
| c2 v200-u13-pull-while-saving (re-run as rd-, after an OOM kill) | 43 | 43 | 0 |
| c2 v200-u13-base-while-saving | 4 | 4 | 0 |
| c2 v200-u13-pull-unchecked | 47 | 47 | 0 |
| c2 v200-u13-said-nothing-loaded | 11 | 11 | 0 |
| c2 v200-u13-clash-while-saving | 2 | 2 | 0 |

Every check labelled a CONTROL passes on all three boards: U20 27 of 27 on each, U30 19 of 19 on each.

**The U20 probe and the checker** (`bin/repro.sh`; the probe scripts are byte-identical copies of the builder's):

| pass | probe | checker |
|---|---|---|
| v3, on c2 | U20 77/77, OUT 26/26, CTL 109/109, locktest 19/19. Only PRE fails (10): the fix changes that premise. | U20 24/24, CNT 45/45, CTL 10/10. O4 fails 2, its two "observed mechanism" checks. PRE fails 8 and INFO 4 (the mechanism). |
| v0, on the base | U20 fails 9 and OUT fails 6 (the triage's 15); CTL 109/109; locktest 19/19 | U20 fails 5 and O4 fails 5; CNT 45/45 |

Both match the builder's r3 and r0 exactly.

**The other suites, in scratch clones** (`clones/b0`, `clones/c2`, `git clone --shared` with my files copied over; never
committed there): boot-same, audit, audit-ppt, audit-other, audit-recon, legacy-fsrc, audit-hostile, audit-inject and
`npm run check` all pass on the base and on c2. The logs are identical apart from the board's size.

## An existing mutation entry in the changed function (this attempt)

`saves-not-serial` (`saveSerial`: `const p=_saveChain.then(run, run);` → `const p=run();`) is the only existing entry
whose find lies in the U20 diff's function that the builder did not run. Run e-c2-saves-not-serial-F-folderA, on c2
(mutant 5236dad5), catches it: 5 of 297 fail (end: 2026-10-13 12:06:59 EDT  exit: 1  wall_s: 265.7) -- the v1.95 W1 checks that two saves never overlap (I did not run it on the base).

## My own mutants: 11 plausible wrong fixes

They are built by `bin/mkmine.py`, and each find matches c2 exactly once. Each ran through F-u20 and F-u30 on c2. The four
survivors also ran through U2 ×2 + U13 (F-u2u13) and the 21 other folder scenarios (F-folderA/B).

| mutant (board blob) | what it is | F-u20 fails | F-u30 fails | verdict |
|---|---|---|---|---|
| mine-u20-uncount-in-go (4b066696) | counted from the ask, uncounted only when the save's own work ends (in go) | 1: (6b) stays 1 | 0 | caught |
| mine-u20-flag (bcf3ee86) | a flag, not a count (`=1` / `=0`) | 1: (6d) count 1 | 1: (4) count 1 | caught |
| mine-u20-count-before-said (a9503a56) | counted before the "already under way" test, so every Save says so | 1: (6d) words | 0 | caught |
| mine-u20-toolbar-only (517afae2) | the count left in go, plus one around saveInPlace only | 1: (6d) words | 1: (4) count 1 | caught |
| mine-u20-count-lock-wait (380863a6) | counted only while waiting in the lock queue (down when granted) | 3: (6b), (6c), (6d) | 1: (4) | caught |
| mine-u30-loud-only (b8add70d) | only a non-quiet refresh stopped | 0 | 19 | caught |
| mine-u30-clash-said (a2cfc9c4) | the refresh says the clash instead of nothing | 0 | 7 | caught |
| **mine-u30-dirty-rule (14cb1676)** | `if(!base && DIRTY)`: this session's flag, not the stamp | 0 | **0** | **survives** |
| **mine-u30-dirty-or-record (22e0c93d)** | `if(!base && (DIRTY \|\| _baseDirty))` | 0 | **0** | **survives** |
| **mine-u30-quiet-only (00dca176)** | `if(!base && theirs!==ours && quiet)`: the Live timer route only | 0 | **0** | **survives** |
| **mine-u30-ownunsaved-rule (376f9e93)** | `if(!base && ownUnsaved(MS, j.store, baseGet()))` | 0 | **0** | **survives** |

The survivors through the other harnesses:

| survivor | F-u2u13 (128) | F-folderA (297) | F-folderB (142) |
|---|---|---|---|
| mine-u30-dirty-rule | 128/128 pass | 297/297 pass | 142/142 pass |
| mine-u30-dirty-or-record | 128/128 pass | 297/297 pass | 142/142 pass (rd-, after an OOM kill) |
| mine-u30-quiet-only | 128/128 pass | 297/297 pass | 142/142 pass (rf-, this attempt; the first try hit the 600 s cap, the second was stopped with the attempt) |
| mine-u30-ownunsaved-rule | 128/128 pass | 0 of 297 fail (end: 2026-10-13 12:09:55 EDT  exit: 0  wall_s: 282.4) | 0 of 142 fail (end: 2026-10-13 12:17:06 EDT  exit: 0  wall_s: 431.4) |

## M1 (must-fix, tests): U30's tests let four wrong forms of the rule through, and each brings the data loss back

**What is not tested.** Every U30 harm case in the block reaches `driveStorePull` the same way. It is a quiet refresh: the
Live timer's tick, or ↻ Refresh now, which goes `livePoll(false)` → `drivePoll` → `driveStorePull(true)`. And it is on a
board whose unsaved work was typed in the same session (`DIRTY` true).

The rule the board needs, and has, is the stamp (`theirs!==ours`). Nothing in the block tells the stamp apart from "this
session has unsaved work", or from "this refresh is the Live timer's". So these plausible wrong fixes pass every check:

- `if(!base && DIRTY) return false;`
- `if(!base && (DIRTY || _baseDirty)) return false;`
- `if(!base && theirs!==ours && quiet) return false;` (the O4-tick route only)
- `if(!base && ownUnsaved(MS, j.store, baseGet())) return false;`

**Why it matters: data loss, on real product paths.** The probe is `harness/P-gap.mjs` (6a60750d), built from block
`probe/gap-block.mjs.txt` (3b62f246): the focused U30 harness with its block replaced and its helpers verbatim.

- **(R1/R1h):**
  1. B's opening connects to an empty folder, so nothing is recorded.
  2. Alice's other machine saves F00, then F0.
  3. B-EDIT is typed after that.
  4. **The page is reopened** from this browser's storage. DIRTY is false, and the record says unsaved.
  5. The opening's own connect (`driveStorePull(false)`, not quiet) finds F0 older than the screen.
  6. 💾 Save, then one more Save.
- **(R2):**
  1. Alice's other machine saved F00 and F0.
  2. B works on its board file, types B-WORK and saves it to the file, so nothing is unsaved.
  3. B then works out of the folder and refreshes.
  4. 💾 Save, then one more Save.

On the base (fce8a391), 8 of 12 checks fail (run pg-P-gap-b0, 10:36 AM ET):

- The connect or refresh records F0 (`got 1791902233415`).
- Save writes B-EDIT over F0 without asking (`[1,"B-EDIT",false,0]`).
- In R1h and R2, after one more Save, F0 is in no copy the board can reach (`[false]`).

On c2, all 12 pass (pg-P-gap-c2).

Under the surviving mutants, the same harm comes back. The proposed cases below fail 12 checks under
mine-u30-dirty-rule, 7 under -quiet-only, 5 under -dirty-or-record and 5 under -ownunsaved-rule (pm-*). Under the DIRTY
rule, for example:

- (6) gets `[1,0,"B-EDIT",false,false]` where `[0,0,"F0",true,true]` is wanted: Save wrote B-EDIT over F0 unasked.
- In (6h) and (7), F0 is no longer kept as a spaced copy after one more Save (`spaced(F0)` false).

**Minimal fix (tested): three cases added to the U30 block, and three mutation entries.**

1. **The cases.** `proposal/u30-cases-6-7.mjs.txt` (blob 55f34f65) goes into the U30 block just before its
   `} catch (e) {`. That gives c2x's audit-import 0ab5fa2b. The diff is `diffs/c2x-audit-import.proposal.diff`: 36 added
   lines, additions only. It reuses the block's own helpers (`unrecorded`, `open`, `chooseMine`, `UNSAID`, `asks`,
   `W1H.disk`).
   - **(6)/(6h):** reopened with unsaved work. The opening's own connect, then 💾 Save, with and without F00 kept
     minutes before. Then Save yours over theirs, one more Save and a reopen.
   - **(7):** a board saved to its own file that is not the folder's copy. ↻ Refresh now, then 💾 Save, then the same
     choice.
   - **The checks.** There are 20 new checks, and every expected value is a literal. Harness F-u30x (f555fe3c):
     - c2: 68 of 68 pass.
     - Base: 35 of 68 fail (the 23 as before, plus 12 new).
     - c1: 33 of 68 fail (the 21 as before, plus 12 new).
     - The new CONTROL checks (the premises) pass on all three.
   - **Base-pass caveat.** In (6), without the history copy, the three `chooseMine` checks also pass on the base. That is
     the S1 point below, in my own proposal, and it takes the same labelling.
2. **The entries.** `proposal/u30-entries.txt` (blob 83772e2e) goes in before the R3 line. That gives c2x's
   mutate.mjs.txt 6eb9eb61; the diff is `diffs/c2x-mutate.mjs.txt.proposal.diff`.
   - The ids are `v200-u30-unsaved-this-session-only`, `v200-u30-quiet-refresh-only` and `v200-u30-unsaved-only`, in
     house format.
   - Each find matches c2 exactly once, and mcount on c2x is 1337/1337.
   - Their mutants, built by `mkmut.py` (in `mut/p/`), are byte-identical to mine-u30-dirty-rule (14cb1676),
     -quiet-only (00dca176) and -dirty-or-record (22e0c93d). The new cases catch them with 12, 7 and 5 failing checks.
3. **The drafts then change:**
   - U30 "Test": 48 → 68 checks; 23 → 35 fail before U20, and 21 → 33 on the U20 board. Add "a reopen with unsaved work,
     whose opening connect is not quiet" and "a board saved to its own file".
   - "Mutations": three more ids.
   - "Not covered": nothing it says now is lost.

If the lead does not take M1, U30's "Not covered" must say plainly that the rule is tested only through the Live timer
and ↻ Refresh now with unsaved work typed in the same session. It must also say that a reopen's connect and a board saved
to its file are not tested.

The proposed suite lines (exact text, `proposal/u30-cases-6-7.mjs.txt`):

```js
  // (6) A REOPEN WITH UNSAVED WORK, NO TIMER AND NO SECOND TAB: as (1), but the page is reopened first, so this session has
  // nothing unsaved (DIRTY false) and only this browser's record says so; the refresh is the opening's own connect, which
  // is not quiet. It used to take F0 as the copy B-EDIT came from, and the next Save wrote B-EDIT over it unasked; (6h), with
  // F00 kept minutes before, F0 was then kept only as a recent copy and the next Save removed it.
  for (const h0 of [false, true]) {
    const sc = '(6' + (h0 ? 'h' : '') + ') reopened with unsaved work: the opening’s own connect, then 💾 Save' + (h0 ? '; a history copy kept minutes before' : '');
    const x = await unrecorded(null, h0); const { fold } = x;
    chk(name, sc, UNREC(h0), unrec(x), UNRECW(h0));
    const C = await open(null, 'C', { html: F1, ls: lsOf(x.B.ev) }); connect(C.ev, C.w, fold); C.ev(`_liveCfg.folder='shared'; 'ok'`);
    await C.ev('driveAutoConnect()'); await pause(5);
    chk(name, sc, 'reopened: B-EDIT on screen, unsaved by this browser’s record, not by this session (a CONTROL) -- [on screen, DIRTY, the record]',
      J([scr(C.ev), C.ev('DIRTY'), unsaved(C.ev)[2]]), J(['B-EDIT', false, true]));
    chk(name, sc, 'the opening’s own connect records nothing', based(C.ev), 0);
    const w0 = omWrites(fold), q0 = qs(C.ev).length; await C.ev('saveInPlace()'); await pause(5);
    chk(name, sc, '💾 Save asks: nothing written, nothing asked in a dialog, F0 still the folder’s copy, the choice offered in the words for nothing recorded',
      J([omWrites(fold) - w0, qs(C.ev).length - q0, fold.note(2027, 'A'), asks(C.ev), UNSAID.test(status(C.ev))]), J([0, 0, 'F0', true, true]));
    await chooseMine(C, fold, sc, h0);
  }
  // (7) A BOARD SAVED TO ITS OWN FILE, SO NOTHING IS UNSAVED, THAT IS NOT THE FOLDER'S COPY: Alice's other machine saved F00
  // and F0 to the shared folder; B-EDIT was then typed and saved to the board file; the board then works out of the folder
  // and ↻ Refresh now finds F0, older than the screen. F0 was never on screen: it used to be taken as the copy B-EDIT came
  // from, and the next Save wrote B-EDIT over it unasked, F0 kept only as a recent copy.
  { const sc = '(7) a board saved to its own file, not the folder’s copy: ↻ Refresh now, then 💾 Save';
    const fold = folder(); await other(fold, ['F00', 'F0']);
    const B = await open(null, 'B'); const dk = W1H.disk(B.w, F1);
    B.ev(`setNote('A','B-EDIT'); 'ok'`); await pause(5); await B.ev('saveInPlaceFile()'); await pause(5);
    connect(B.ev, B.w, fold); B.ev(`_liveCfg.folder='shared'; 'ok'`);
    chk(name, sc, 'B-EDIT saved to the board file, nothing unsaved; F0 the folder’s copy, older than the screen; F00 a spaced copy; nothing recorded (a CONTROL)',
      J([dk.writes, unsaved(B.ev), scr(B.ev), fold.note(2027, 'A'), headTs(fold) < +B.ev('MS.ts'), hist(fold), based(B.ev)]),
      J([1, [false, false, false], 'B-EDIT', 'F0', true, [['F00', false]], 0]));
    await B.ev('livePoll(false)'); await pause(5);
    chk(name, sc, '↻ Refresh now records nothing', based(B.ev), 0);
    const w0 = omWrites(fold); await B.ev('saveInPlace()'); await pause(5);
    chk(name, sc, '💾 Save asks: nothing written, F0 still the folder’s copy, the choice offered', J([omWrites(fold) - w0, fold.note(2027, 'A'), asks(B.ev)]), J([0, 'F0', true]));
    await chooseMine(B, fold, sc, true);
  }
```

The proposed mutation entries (exact text, `proposal/u30-entries.txt`):

```js
  // v2.00 (U30): the refresh's rule keyed on anything but the stamp misses a reopen, a Connect, or a board saved to its own file.
  { id: "v200-u30-unsaved-this-session-only", area: "driveStorePull", what: "the refresh's rule keyed on this session's unsaved flag (DIRTY) instead of the stamp: after a reopen with unsaved work, the opening's own connect takes the folder's copy as the one the work came from, and the next Save writes over it without asking (with a history copy kept minutes before, it is gone after one more Save)",
    find: "    if(!base && theirs!==ours) return false;\n",
    repl: "    if(!base && DIRTY) return false;\n" },
  { id: "v200-u30-quiet-refresh-only", area: "driveStorePull", what: "only the quiet refresh (the Live timer, ↻ Refresh now) is stopped: a Connect, or the opening's own connect after a reopen, still takes the folder's copy as the one the work came from, and the next Save writes over it without asking",
    find: "    if(!base && theirs!==ours) return false;\n",
    repl: "    if(!base && theirs!==ours && quiet) return false;\n" },
  { id: "v200-u30-unsaved-only", area: "driveStorePull", what: "the rule keyed on unsaved work (this session's or this browser's record) instead of the stamp: a board saved to its own file, which is not the folder's copy, takes that copy as the one the work came from, and the next Save writes over it without asking",
    find: "    if(!base && theirs!==ours) return false;\n",
    repl: "    if(!base && (DIRTY || _baseDirty)) return false;\n" },
```

## Should-fix

- **S1. The base-fail rule holds per case, not per check, and three U20 cases are neither defect nor labelled control.**
  - U20's (6a), (6b) and (6c) pass every check on the base: 6 checks, 0 failing. They are the count coming back down
    when the autosave throws, when the lock request is refused, and when asking for the lock throws.
  - They are sound guards. (6b) catches mine-u20-uncount-in-go, and (6b) and (6c) catch mine-u20-count-lock-wait. But
    they are not labelled CONTROL in the block. The draft calls them controls; the block's case names do not.
  - In all, 18 new non-control checks pass on the base:
    - U20: the 5 lock-stand-in sanity checks of non-control cases, (3)'s two history checks, (6a)–(6c), and (6d)'s
      landing and stand-in checks;
    - U30: (1)'s four history, choice and reopen checks, (3)'s first-Save check, and (4)'s stand-in check.
  - The fix: label them, for example "(a guard: passes before the change too)", or say so in the drafts' "Test" lines.
- **S2. Coverage moved off U13's own case.** On c2, U13's (3c) returns at the U30 rule. So `v200-u13-base-while-saving`
  and `v200-u13-clash-while-saving` are caught only by U20 (4) and U30 (5b), with 4 and 2 failing checks. The builder
  says so. The U13 entry's "Mutations" line in NEXT-VERSION should say where they are caught now.
- **S3. The U2 and U13 "Not covered" lines** become false once U20 lands. The builder drafted replacements, and the lead
  should apply them with the commit (principle 4).

## Minor

- The `v200-u20-wait-uncounted` find spans 11 lines, including the "⏳ A save is already under way" message line. Any
  later edit of that message breaks the entry. mcount would show it as missing, so it cannot pass silently.
- U20 (5b), the harness-counted control, double-counts on c1/c2, because both the wrapper and the board count. It reads
  `_saveBusy > 0`, so the check is not affected.
- The money lens (its own result file) reports false words after Load theirs / Put back on the route U30 opens. No check
  in the U30 block reads those lines. If the lead takes that fix, its checks belong in the same block.

## Deviations (said plainly)

- **The first attempt of this review broke the two-process rule.** It ran its batches as parallel streams (A–E). Up to
  six recorded node runs overlapped (at 11:05:54 AM ET), and more than two ran at once for about 70 minutes between
  10:31 and 11:55 AM ET. The lead stopped it to lower the machine's load. This attempt ran at most two node processes at
  a time: rf, then e and sv3, each batch serial.
- **Runs that did not finish:**
  - At 11:25 AM ET the cgroup's OOM killer killed two of the first attempt's runs (exit 137). They are
    sv-mine-u30-dirty-or-record-F-folderB and bm-c2-v200-u13-pull-while-saving. Both were re-run, as rd-*, with exit
    records.
  - One run reached the 600 s cap under load (exit 124): sv-mine-u30-quiet-only-F-folderB. Its re-run (re-) was stopped
    with the attempt, with 82 of 142 checks recorded and no exit record. This attempt re-ran it as rf- (exit 0, 142/142).
  - None of these is reported as a result of the change.
- **The v1 batch** (6 runs at 10:30 AM ET) failed at once on a setup slip: jsdom could not be resolved from `h/`. No check
  ran. It was re-run as v2.
- **Commands outside the wrapper.** Read-only shell commands (cat, grep, ls, git hash-object, ps) and the small Python
  text scripts (cmp.py, fails.py, wants.py, the coverage scan) ran without the setsid/timeout wrapper. Every node run,
  mcount and mkmut ran bounded, with its PIDs in `pids.txt`.

## What I did not do

- I did not run the full audit-import or audit-board; the lead runs those alone.
- I did not run real Chromium.
- I did not import, execute or run `mutate.mjs`, and I did not run `playwright install`.
- I committed, pushed and staged nothing anywhere.
- I made no change to the builder's files or to `/home/user/orbit-board` or `/home/user/orbit-ui`.
- I did not test as the waiting operation: Take the pen, Load theirs or Save yours over theirs. I did not test a tab
  closed while it holds the lock, or clock-skewed equal stamps. These are the builder's own "Not covered" items, and I
  agree they are untested.
- I did not write a board fix. The board is right on every route I tried.

## Every run (from logs/runs.txt; the log of each is under logs/)

| label | start (ET) | exit | wall s | log | result |
|---|---|---|---|---|---|
| # focused batch v1 launched 2026-10-13 10:30:51 EDT | | | | | |
| v1-F-u20-b0 | 10:30:51 | 1 | 0.7 | logs/v1-F-u20-b0.log |  |
| v1-F-u20-c1 | 10:30:51 | 1 | 0.7 | logs/v1-F-u20-c1.log |  |
| v1-F-u20-c2 | 10:30:52 | 1 | 0.8 | logs/v1-F-u20-c2.log |  |
| v1-F-u30-b0 | 10:30:53 | 1 | 0.8 | logs/v1-F-u30-b0.log |  |
| v1-F-u30-c1 | 10:30:54 | 1 | 0.7 | logs/v1-F-u30-c1.log |  |
| v1-F-u30-c2 | 10:30:55 | 1 | 0.7 | logs/v1-F-u30-c2.log |  |
| # v1 runs above failed at once: jsdom not resolvable from h/ (no node_modules link there); a setup slip, no check ran. Re-run as v2. | | | | | |
| # focused batch v2 launched 2026-10-13 10:31:28 EDT | | | | | |
| # focused batch va launched 2026-10-13 10:31:29 EDT | | | | | |
| v2-F-u20-b0 | 10:31:28 | 1 | 30.7 | logs/v2-F-u20-b0.log | 78 checks, 20 fail |
| v2-F-u20-c1 | 10:31:58 | 0 | 32.6 | logs/v2-F-u20-c1.log | 78 checks, 0 fail |
| v2-F-u20-c2 | 10:32:31 | 0 | 31.0 | logs/v2-F-u20-c2.log | 78 checks, 0 fail |
| v2-F-u30-b0 | 10:33:02 | 1 | 30.9 | logs/v2-F-u30-b0.log | 48 checks, 23 fail |
| va-F-all-b0 | 10:31:29 | 1 | 126.4 | logs/va-F-all-b0.log | 254 checks, 43 fail |
| v2-F-u30-c1 | 10:33:33 | 1 | 41.6 | logs/v2-F-u30-c1.log | 48 checks, 21 fail |
| v2-F-u30-c2 | 10:34:15 | 0 | 35.2 | logs/v2-F-u30-c2.log | 48 checks, 0 fail |
| # my mutants batch mm launched 2026-10-13 10:34:57 EDT | | | | | |
| mm-mine-u20-uncount-in-go-u20 | 10:34:57 | 1 | 74.7 | logs/mm-mine-u20-uncount-in-go-u20.log | 78 checks, 1 fail |
| # probe batch pg launched 2026-10-13 10:36:15 EDT | | | | | |
| pg-P-gap-c2 | 10:36:15 | 0 | 39.5 | logs/pg-P-gap-c2.log | 12 checks, 0 fail |
| pg-P-gap-b0 | 10:36:54 | 1 | 49.1 | logs/pg-P-gap-b0.log | 12 checks, 8 fail |
| mm-mine-u20-uncount-in-go-u30 | 10:36:12 | 0 | 100.4 | logs/mm-mine-u20-uncount-in-go-u30.log | 48 checks, 0 fail |
| va-F-all-c1 | 10:33:35 | 1 | 276.8 | logs/va-F-all-c1.log | 254 checks, 21 fail |
| # suites on the base clone launched 2026-10-13 10:38:38 EDT | | | | | |
| S-b0-boot-same | 10:38:38 | 0 | 54.3 | logs/S-b0-boot-same.log | every page, source, save and error list is identical either way |
| mm-mine-u20-flag-u20 | 10:37:52 | 1 | 129.3 | logs/mm-mine-u20-flag-u20.log | 78 checks, 1 fail |
| S-b0-audit | 10:39:33 | 0 | 48.4 | logs/S-b0-audit.log | ALL CHECKS PASSED |
| # proposal batch px launched 2026-10-13 10:40:31 EDT | | | | | |
| S-b0-audit-ppt | 10:40:21 | 0 | 22.4 | logs/S-b0-audit-ppt.log | ALL CHECKS PASSED |
| mm-mine-u20-flag-u30 | 10:40:02 | 1 | 145.0 | logs/mm-mine-u20-flag-u30.log | 48 checks, 1 fail |
| S-b0-audit-other | 10:40:44 | 0 | 177.8 | logs/S-b0-audit-other.log | ALL CHECKS PASSED |
| px-F-u30x-c2 | 10:40:31 | 0 | 194.2 | logs/px-F-u30x-c2.log | 68 checks, 0 fail |
| mm-mine-u20-count-before-said-u20 | 10:42:27 | 1 | 134.9 | logs/mm-mine-u20-count-before-said-u20.log | 78 checks, 1 fail |
| px-F-u30x-b0 | 10:43:46 | 1 | 147.9 | logs/px-F-u30x-b0.log | 68 checks, 35 fail |
| mm-mine-u20-count-before-said-u30 | 10:44:42 | 0 | 108.0 | logs/mm-mine-u20-count-before-said-u30.log | 48 checks, 0 fail |
| va-F-all-c2 | 10:38:12 | 0 | 545.5 | logs/va-F-all-c2.log | 254 checks, 0 fail |
| # builder mutants batch bm launched 2026-10-13 10:47:25 EDT | | | | | |
| mm-mine-u20-toolbar-only-u20 | 10:46:30 | 1 | 109.7 | logs/mm-mine-u20-toolbar-only-u20.log | 78 checks, 1 fail |
| px-F-u30x-c1 | 10:46:14 | 1 | 133.5 | logs/px-F-u30x-c1.log | 68 checks, 33 fail |
| # proposal-vs-my-U30-mutants batch pm launched 2026-10-13 10:48:38 EDT | | | | | |
| bm-c1-v200-u20-wait-uncounted | 10:47:25 | 1 | 93.4 | logs/bm-c1-v200-u20-wait-uncounted.log | 78 checks, 20 fail |
| mm-mine-u20-toolbar-only-u30 | 10:48:20 | 1 | 73.6 | logs/mm-mine-u20-toolbar-only-u30.log | 48 checks, 1 fail |
| S-b0-audit-recon | 10:43:42 | 0 | 395.6 | logs/S-b0-audit-recon.log | ALL CHECKS PASSED |
| pm-mine-u30-dirty-rule | 10:48:38 | 1 | 102.3 | logs/pm-mine-u30-dirty-rule.log | 68 checks, 12 fail |
| S-b0-legacy-fsrc | 10:50:17 | 0 | 10.9 | logs/S-b0-legacy-fsrc.log | every legacy Force setting computes exactly as before |
| bm-c1-v200-u20-failed-stays-counted | 10:48:59 | 1 | 92.0 | logs/bm-c1-v200-u20-failed-stays-counted.log | 78 checks, 2 fail |
| mm-mine-u20-count-lock-wait-u20 | 10:49:33 | 1 | 88.0 | logs/mm-mine-u20-count-lock-wait-u20.log | 78 checks, 3 fail |
| bm-c2-v200-u20-wait-uncounted | 10:50:31 | 1 | 94.7 | logs/bm-c2-v200-u20-wait-uncounted.log | 78 checks, 14 fail |
| pm-mine-u30-dirty-or-record | 10:50:20 | 1 | 113.6 | logs/pm-mine-u30-dirty-or-record.log | 68 checks, 5 fail |
| mm-mine-u20-count-lock-wait-u30 | 10:51:02 | 1 | 88.7 | logs/mm-mine-u20-count-lock-wait-u30.log | 48 checks, 1 fail |
| S-b0-audit-hostile | 10:50:28 | 0 | 180.6 | logs/S-b0-audit-hostile.log | ALL CHECKS PASSED |
| bm-c2-v200-u20-failed-stays-counted | 10:52:06 | 1 | 97.9 | logs/bm-c2-v200-u20-failed-stays-counted.log | 78 checks, 2 fail |
| mm-mine-u30-dirty-rule-u20 | 10:52:30 | 0 | 97.7 | logs/mm-mine-u30-dirty-rule-u20.log | 78 checks, 0 fail |
| S-b0-audit-inject | 10:53:29 | 0 | 42.4 | logs/S-b0-audit-inject.log | ALL CHECKS PASSED |
| pm-mine-u30-quiet-only | 10:52:14 | 1 | 120.5 | logs/pm-mine-u30-quiet-only.log | 68 checks, 7 fail |
| S-b0-npm-check | 10:54:12 | 0 | 13.4 | logs/S-b0-npm-check.log | all checks passed |
| # suites on the c2 clone launched 2026-10-13 10:54:25 EDT | | | | | |
| S-c2-boot-same | 10:54:25 | 0 | 36.3 | logs/S-c2-boot-same.log | every page, source, save and error list is identical either way |
| bm-c2-v200-u30-base-whatever-on-screen | 10:53:44 | 1 | 92.8 | logs/bm-c2-v200-u30-base-whatever-on-screen.log | 48 checks, 19 fail |
| S-c2-audit | 10:55:02 | 0 | 35.3 | logs/S-c2-audit.log | ALL CHECKS PASSED |
| mm-mine-u30-dirty-rule-u30 | 10:54:08 | 0 | 98.1 | logs/mm-mine-u30-dirty-rule-u30.log | 48 checks, 0 fail |
| S-c2-audit-ppt | 10:55:37 | 0 | 23.1 | logs/S-c2-audit-ppt.log | ALL CHECKS PASSED |
| pm-mine-u30-loud-only | 10:54:14 | 1 | 140.4 | logs/pm-mine-u30-loud-only.log | 68 checks, 24 fail |
| bm-c2-v200-u30-base-only-other-copy | 10:55:17 | 1 | 112.7 | logs/bm-c2-v200-u30-base-only-other-copy.log | 48 checks, 21 fail |
| mm-mine-u30-dirty-or-record-u20 | 10:55:46 | 0 | 117.5 | logs/mm-mine-u30-dirty-or-record-u20.log | 78 checks, 0 fail |
| S-c2-audit-other | 10:56:00 | 0 | 128.2 | logs/S-c2-audit-other.log | ALL CHECKS PASSED |
| bm-c2-v200-u30-unrecorded-said-after | 10:57:09 | 1 | 102.1 | logs/bm-c2-v200-u30-unrecorded-said-after.log | 48 checks, 2 fail |
| pm-mine-u30-clash-said | 10:56:35 | 1 | 138.5 | logs/pm-mine-u30-clash-said.log | 68 checks, 7 fail |
| mm-mine-u30-dirty-or-record-u30 | 10:57:44 | 0 | 97.7 | logs/mm-mine-u30-dirty-or-record-u30.log | 48 checks, 0 fail |
| bm-c2-v200-u30-recorded-said-unknown | 10:58:52 | 1 | 88.4 | logs/bm-c2-v200-u30-recorded-said-unknown.log | 48 checks, 1 fail |
| pm-mine-u30-ownunsaved-rule | 10:58:53 | 1 | 121.9 | logs/pm-mine-u30-ownunsaved-rule.log | 68 checks, 5 fail |
| mm-mine-u30-quiet-only-u20 | 10:59:22 | 0 | 103.9 | logs/mm-mine-u30-quiet-only-u20.log | 78 checks, 0 fail |
| mm-mine-u30-quiet-only-u30 | 11:01:06 | 0 | 88.7 | logs/mm-mine-u30-quiet-only-u30.log | 48 checks, 0 fail |
| # survivor batches sv1/sv2 launched 2026-10-13 11:02:50 EDT | | | | | |
| mm-mine-u30-loud-only-u20 | 11:02:34 | 0 | 106.0 | logs/mm-mine-u30-loud-only-u20.log | 78 checks, 0 fail |
| S-c2-audit-recon | 10:58:08 | 0 | 384.0 | logs/S-c2-audit-recon.log | ALL CHECKS PASSED |
| S-c2-legacy-fsrc | 11:04:33 | 0 | 14.8 | logs/S-c2-legacy-fsrc.log | every legacy Force setting computes exactly as before |
| mm-mine-u30-loud-only-u30 | 11:04:21 | 1 | 93.1 | logs/mm-mine-u30-loud-only-u30.log | 48 checks, 19 fail |
| sv-mine-u30-dirty-or-record-F-u2u13 | 11:02:50 | 0 | 239.2 | logs/sv-mine-u30-dirty-or-record-F-u2u13.log | 128 checks, 0 fail |
| bm-c2-v200-u2-putback-gen | 11:00:20 | 1 | 396.8 | logs/bm-c2-v200-u2-putback-gen.log | 254 checks, 1 fail |
| sv-mine-u30-dirty-rule-F-u2u13 | 11:02:50 | 0 | 246.6 | logs/sv-mine-u30-dirty-rule-F-u2u13.log | 128 checks, 0 fail |
| mm-mine-u30-clash-said-u20 | 11:05:54 | 0 | 128.3 | logs/mm-mine-u30-clash-said-u20.log | 78 checks, 0 fail |
| S-c2-audit-hostile | 11:04:48 | 0 | 238.2 | logs/S-c2-audit-hostile.log | ALL CHECKS PASSED |
| S-c2-audit-inject | 11:08:46 | 0 | 58.1 | logs/S-c2-audit-inject.log | ALL CHECKS PASSED |
| S-c2-npm-check | 11:09:44 | 0 | 16.8 | logs/S-c2-npm-check.log | all checks passed |
| # repro v3 on c2 (c42be8e7) launched 2026-10-13 11:10:01 EDT | | | | | |
| v3-locktest | 11:10:01 | 0 | 7.4 | logs/v3-locktest.log | PASS T10 [finished, FIFO = request order, most inside at once, v |
| mm-mine-u30-clash-said-u30 | 11:08:02 | 1 | 130.3 | logs/mm-mine-u30-clash-said-u30.log | 48 checks, 7 fail |
| v3-PB-W | 11:10:09 | 0 | 35.4 | logs/v3-PB-W.log |  |
| v3-PB-Wtick | 11:10:44 | 0 | 36.2 | logs/v3-PB-Wtick.log |  |
| v3-PB-C1 | 11:11:20 | 0 | 33.9 | logs/v3-PB-C1.log |  |
| mm-mine-u30-ownunsaved-rule-u20 | 11:10:13 | 0 | 123.6 | logs/mm-mine-u30-ownunsaved-rule-u20.log | 78 checks, 0 fail |
| v3-PB-C2a | 11:11:54 | 0 | 27.6 | logs/v3-PB-C2a.log |  |
| v3-PB-C2b | 11:12:22 | 0 | 27.9 | logs/v3-PB-C2b.log |  |
| v3-PB-NL | 11:12:50 | 0 | 32.1 | logs/v3-PB-NL.log |  |
| sv-mine-u30-dirty-or-record-F-folderA | 11:06:50 | 0 | 406.7 | logs/sv-mine-u30-dirty-or-record-F-folderA.log | 297 checks, 0 fail |
| sv-mine-u30-dirty-rule-F-folderA | 11:06:57 | 0 | 409.8 | logs/sv-mine-u30-dirty-rule-F-folderA.log | 297 checks, 0 fail |
| v3-AD-W | 11:13:22 | 0 | 31.4 | logs/v3-AD-W.log |  |
| mm-mine-u30-ownunsaved-rule-u30 | 11:12:16 | 0 | 103.6 | logs/mm-mine-u30-ownunsaved-rule-u30.log | 48 checks, 0 fail |
| # folder batch vf launched 2026-10-13 11:14:05 EDT | | | | | |
| v3-AD-Wtick | 11:13:54 | 0 | 32.5 | logs/v3-AD-Wtick.log |  |
| v3-AD-C1 | 11:14:26 | 0 | 34.6 | logs/v3-AD-C1.log |  |
| bm-c2-v200-u2-putback-while-saving | 11:06:57 | 1 | 502.5 | logs/bm-c2-v200-u2-putback-while-saving.log | 254 checks, 39 fail |
| v3-AD-C2a | 11:15:01 | 0 | 35.4 | logs/v3-AD-C2a.log |  |
| v3-AD-C2b | 11:15:36 | 0 | 29.1 | logs/v3-AD-C2b.log |  |
| v3-BR-W | 11:16:05 | 0 | 23.2 | logs/v3-BR-W.log |  |
| v3-BR-Wtick | 11:16:29 | 0 | 27.6 | logs/v3-BR-Wtick.log |  |
| v3-BR-C1 | 11:16:56 | 0 | 24.8 | logs/v3-BR-C1.log |  |
| v3-BR-C2a | 11:17:21 | 0 | 23.4 | logs/v3-BR-C2a.log |  |
| v3-BR-C2b | 11:17:45 | 0 | 26.8 | logs/v3-BR-C2b.log |  |
| v3-BR-Wperm | 11:18:12 | 0 | 26.9 | logs/v3-BR-Wperm.log |  |
| v3-BR-C1perm | 11:18:39 | 0 | 28.8 | logs/v3-BR-C1perm.log |  |
| bm-c2-v200-u13-pull-while-saving | 11:15:20 | 137 | 260.0 | logs/bm-c2-v200-u13-pull-while-saving.log | 147 checks, 40 fail |
| v3-BR-Wh | 11:19:07 | 0 | 37.1 | logs/v3-BR-Wh.log |  |
| v3-BR-C1h | 11:19:45 | 0 | 60.9 | logs/v3-BR-C1h.log |  |
| vf-F-folderA-b0 | 11:14:05 | 0 | 416.3 | logs/vf-F-folderA-b0.log | 297 checks, 0 fail |
| v3-BR-Wpermh | 11:20:46 | 0 | 35.4 | logs/v3-BR-Wpermh.log |  |
| v3-BR-C2ah | 11:21:21 | 0 | 29.8 | logs/v3-BR-C2ah.log |  |
| v3-BR-C2bh | 11:21:51 | 0 | 30.4 | logs/v3-BR-C2bh.log |  |
| sv-mine-u30-dirty-or-record-F-folderB | 11:13:37 | 137 | 550.8 | logs/sv-mine-u30-dirty-or-record-F-folderB.log | 129 checks, 0 fail |
| v3-PF-W | 11:22:21 | 0 | 35.9 | logs/v3-PF-W.log |  |
| sv-mine-u30-dirty-rule-F-folderB | 11:13:47 | 0 | 566.3 | logs/sv-mine-u30-dirty-rule-F-folderB.log | 142 checks, 0 fail |
| v3-PF-C1 | 11:22:57 | 0 | 26.9 | logs/v3-PF-C1.log |  |
| v3-PF-C2a | 11:23:24 | 0 | 23.8 | logs/v3-PF-C2a.log |  |
| v3-x-PB-Wcount | 11:23:48 | 0 | 29.7 | logs/v3-x-PB-Wcount.log |  |
| v3-x-AD-Wcount | 11:24:18 | 0 | 28.8 | logs/v3-x-AD-Wcount.log |  |
| v3-x-BR-Wcount | 11:24:47 | 0 | 26.2 | logs/v3-x-BR-Wcount.log |  |
| # 2026-10-13 11:25:28 EDT: the cgroup's OOM killer (dmesg: 'Memory cgroup out of memory: Killed process 32151 (node)') killed sv-mine-u30-dirty-or-record-F-folderB and bm-c2-v200-u13-pull-while-saving (exit 137, not timeouts; nothing of mine killed them). To lower memory, I stopped my own batch wrapper sv2 (PID 25035, recorded in pids.txt; its current run left to finish); the two killed runs are re-run later, one at a time. | | | | | |
| v3-x-BR-Wreal | 11:25:13 | 0 | 26.3 | logs/v3-x-BR-Wreal.log |  |
| v3-x-BR-Wrealtick | 11:25:39 | 0 | 31.6 | logs/v3-x-BR-Wrealtick.log |  |
| v3-x-BR-C1real | 11:26:11 | 0 | 29.9 | logs/v3-x-BR-C1real.log |  |
| v3-x-BR-Wrealcount | 11:26:41 | 0 | 29.5 | logs/v3-x-BR-Wrealcount.log |  |
| sv-mine-u30-ownunsaved-rule-F-u2u13 | 11:22:48 | 0 | 270.9 | logs/sv-mine-u30-ownunsaved-rule-F-u2u13.log | 128 checks, 0 fail |
| sv-mine-u30-quiet-only-F-u2u13 | 11:23:13 | 0 | 264.6 | logs/sv-mine-u30-quiet-only-F-u2u13.log | 128 checks, 0 fail |
| v3-x-BR-Wrealh | 11:27:11 | 0 | 27.7 | logs/v3-x-BR-Wrealh.log |  |
| v3-x-O4-tick | 11:27:38 | 0 | 17.6 | logs/v3-x-O4-tick.log |  |
| bm-c2-v200-u13-base-while-saving | 11:19:40 | 1 | 497.9 | logs/bm-c2-v200-u13-base-while-saving.log | 254 checks, 4 fail |
| v3-x-O4-tickh | 11:27:56 | 0 | 25.3 | logs/v3-x-O4-tickh.log |  |
| v3-x-BR-Wrealtickcount | 11:28:21 | 0 | 25.8 | logs/v3-x-BR-Wrealtickcount.log |  |
| v3-check | 11:28:47 | 0 | 0.4 | logs/v3-check.log | FAILING 10 ["PRE PB-W: at the action: [B _saveBusy, A _saveBusy, |
| v3-xcheck | 11:28:48 | 0 | 0.3 | logs/v3-xcheck.log | FAILING 14 ["PRE PB-Wcount: at the action: [B _saveBusy, A _save |
| repro v3 done 11:28:48 EDT | | | | | |
| # repro v0 on the base (fce8a391) launched 2026-10-13 11:28:48 EDT | | | | | |
| v0-locktest | 11:28:48 | 0 | 4.9 | logs/v0-locktest.log | PASS T10 [finished, FIFO = request order, most inside at once, v |
| vf-F-folderB-b0 | 11:21:02 | 0 | 497.3 | logs/vf-F-folderB-b0.log | 142 checks, 0 fail |
| v0-PB-W | 11:28:53 | 0 | 30.3 | logs/v0-PB-W.log |  |
| v0-PB-Wtick | 11:29:23 | 0 | 30.1 | logs/v0-PB-Wtick.log |  |
| v0-PB-C1 | 11:29:54 | 0 | 29.9 | logs/v0-PB-C1.log |  |
| v0-PB-C2a | 11:30:24 | 0 | 32.0 | logs/v0-PB-C2a.log |  |
| v0-PB-C2b | 11:30:56 | 0 | 33.1 | logs/v0-PB-C2b.log |  |
| v0-PB-NL | 11:31:29 | 0 | 28.6 | logs/v0-PB-NL.log |  |
| v0-AD-W | 11:31:57 | 0 | 32.0 | logs/v0-AD-W.log |  |
| v0-AD-Wtick | 11:32:30 | 0 | 35.6 | logs/v0-AD-Wtick.log |  |
| sv-mine-u30-quiet-only-F-folderA | 11:27:38 | 0 | 352.8 | logs/sv-mine-u30-quiet-only-F-folderA.log | 297 checks, 0 fail |
| v0-AD-C1 | 11:33:05 | 0 | 35.5 | logs/v0-AD-C1.log |  |
| v0-AD-C2a | 11:33:41 | 0 | 35.7 | logs/v0-AD-C2a.log |  |
| v0-AD-C2b | 11:34:17 | 0 | 37.2 | logs/v0-AD-C2b.log |  |
| v0-BR-W | 11:34:54 | 0 | 33.8 | logs/v0-BR-W.log |  |
| bm-c2-v200-u13-pull-unchecked | 11:27:58 | 1 | 460.8 | logs/bm-c2-v200-u13-pull-unchecked.log | 254 checks, 47 fail |
| vf-F-folderA-c2 | 11:29:19 | 0 | 388.3 | logs/vf-F-folderA-c2.log | 297 checks, 0 fail |
| v0-BR-Wtick | 11:35:28 | 0 | 35.0 | logs/v0-BR-Wtick.log |  |
| v0-BR-C1 | 11:36:03 | 0 | 31.9 | logs/v0-BR-C1.log |  |
| v0-BR-C2a | 11:36:35 | 0 | 35.5 | logs/v0-BR-C2a.log |  |
| v0-BR-C2b | 11:37:10 | 0 | 38.6 | logs/v0-BR-C2b.log |  |
| v0-BR-Wperm | 11:37:49 | 0 | 47.6 | logs/v0-BR-Wperm.log |  |
| v0-BR-C1perm | 11:38:37 | 0 | 49.8 | logs/v0-BR-C1perm.log |  |
| v0-BR-Wh | 11:39:27 | 0 | 52.6 | logs/v0-BR-Wh.log |  |
| v0-BR-C1h | 11:40:19 | 0 | 44.3 | logs/v0-BR-C1h.log |  |
| v0-BR-Wpermh | 11:41:04 | 0 | 46.2 | logs/v0-BR-Wpermh.log |  |
| v0-BR-C2ah | 11:41:50 | 0 | 41.0 | logs/v0-BR-C2ah.log |  |
| v0-BR-C2bh | 11:42:31 | 0 | 42.3 | logs/v0-BR-C2bh.log |  |
| sv-mine-u30-quiet-only-F-folderB | 11:33:31 | 124 | 600.5 | logs/sv-mine-u30-quiet-only-F-folderB.log | 103 checks, 0 fail |
| v0-PF-W | 11:43:14 | 0 | 38.6 | logs/v0-PF-W.log |  |
| # 2026-10-13 11:43:57 EDT: sv-mine-u30-quiet-only-F-folderB reached the 600 s cap (exit 124) with 103 of F-folderB's 142 checks recorded, none failing; queued again (streamE). | | | | | |
| v0-PF-C1 | 11:43:52 | 0 | 24.3 | logs/v0-PF-C1.log |  |
| v0-PF-C2a | 11:44:17 | 0 | 18.7 | logs/v0-PF-C2a.log |  |
| v0-x-PB-Wcount | 11:44:35 | 0 | 22.6 | logs/v0-x-PB-Wcount.log |  |
| v0-x-AD-Wcount | 11:44:58 | 0 | 20.5 | logs/v0-x-AD-Wcount.log |  |
| bm-c2-v200-u13-said-nothing-loaded | 11:35:39 | 1 | 589.1 | logs/bm-c2-v200-u13-said-nothing-loaded.log | 254 checks, 11 fail |
| vf-F-folderB-c2 | 11:35:48 | 0 | 587.6 | logs/vf-F-folderB-c2.log | 142 checks, 0 fail |
| v0-x-BR-Wcount | 11:45:19 | 0 | 18.1 | logs/v0-x-BR-Wcount.log |  |
| v0-x-BR-Wreal | 11:45:37 | 0 | 15.3 | logs/v0-x-BR-Wreal.log |  |
| v0-x-BR-Wrealtick | 11:45:52 | 0 | 15.0 | logs/v0-x-BR-Wrealtick.log |  |
| v0-x-BR-C1real | 11:46:07 | 0 | 11.5 | logs/v0-x-BR-C1real.log |  |
| v0-x-BR-Wrealcount | 11:46:19 | 0 | 13.1 | logs/v0-x-BR-Wrealcount.log |  |
| v0-x-BR-Wrealh | 11:46:32 | 0 | 14.8 | logs/v0-x-BR-Wrealh.log |  |
| v0-x-O4-tick | 11:46:47 | 0 | 14.2 | logs/v0-x-O4-tick.log |  |
| v0-x-O4-tickh | 11:47:01 | 0 | 13.7 | logs/v0-x-O4-tickh.log |  |
| v0-x-BR-Wrealtickcount | 11:47:15 | 0 | 14.5 | logs/v0-x-BR-Wrealtickcount.log |  |
| v0-check | 11:47:29 | 0 | 0.3 | logs/v0-check.log | FAILING 15 ["U20 BR-W: B’s save: did not write over a copy witho |
| v0-xcheck | 11:47:30 | 0 | 0.1 | logs/v0-xcheck.log | FAILING 10 ["U20 BR-Wreal: B’s save: did not write over a copy w |
| repro v0 done 11:47:30 EDT | | | | | |
| streamC done 11:47:30 EDT | | | | | |
| vf-F-folderA-c1 | 11:45:36 | 0 | 177.4 | logs/vf-F-folderA-c1.log | 297 checks, 0 fail |
| bm-c2-v200-u13-clash-while-saving | 11:45:28 | 1 | 221.7 | logs/bm-c2-v200-u13-clash-while-saving.log | 254 checks, 2 fail |
| streamA done 11:49:10 EDT | | | | | |
| # redo batch rd launched 2026-10-13 11:49:25 EDT | | | | | |
| rd-bm-c2-v200-u13-pull-while-saving | 11:49:25 | 1 | 123.7 | logs/rd-bm-c2-v200-u13-pull-while-saving.log | 254 checks, 43 fail |
| vf-F-folderB-c1 | 11:48:33 | 0 | 210.7 | logs/vf-F-folderB-c1.log | 142 checks, 0 fail |
| streamB done 11:52:04 EDT | | | | | |
| rd-sv-mine-u30-dirty-or-record-F-folderB | 11:51:28 | 0 | 174.2 | logs/rd-sv-mine-u30-dirty-or-record-F-folderB.log | 142 checks, 0 fail |
| # redo batch re launched 2026-10-13 11:54:28 EDT | | | | | |
| # 2026-10-13 12:00:06 EDT: RESUMED ATTEMPT of this review (the earlier attempt was stopped by the lead at about 11:45 AM ET; its last runs had exit records up to rd-sv-mine-u30-dirty-or-record-F-folderB; re-sv-mine-u30-quiet-only-F-folderB has none, 82 of 142 checks, so it is re-run as rf-). At most two node processes of mine at a time from here on. | | | | | |
| # 2026-10-13 12:02:33 EDT: batch e launched -- an existing entry in the changed function (saves-not-serial, saveSerial) on c2 through F-folderA; the builder did not run it | | | | | |
| rf-sv-mine-u30-quiet-only-F-folderB | 12:00:10 | 0 | 289.7 | logs/rf-sv-mine-u30-quiet-only-F-folderB.log | 142 checks, 0 fail |
| # 2026-10-13 12:05:12 EDT: batch sv3 launched -- the fourth survivor (mine-u30-ownunsaved-rule) through F-folderA and F-folderB, one at a time | | | | | |
| e-c2-saves-not-serial-F-folderA | 12:02:33 | 1 | 265.7 | logs/e-c2-saves-not-serial-F-folderA.log | 297 checks, 5 fail |
| sv-mine-u30-ownunsaved-rule-F-folderA | 12:05:12 | 0 | 282.4 | logs/sv-mine-u30-ownunsaved-rule-F-folderA.log | 297 checks, 0 fail |
| sv-mine-u30-ownunsaved-rule-F-folderB | 12:09:55 | 0 | 431.4 | logs/sv-mine-u30-ownunsaved-rule-F-folderB.log | 142 checks, 0 fail |


Bounded non-node runs (text helpers: mcount, mkmut, hashes, diffs, copies) are in `logs/bx.txt`. This attempt's ones:

- `mcount2-b0 start_et="2026-10-13 12:01:09 EDT" exit=0 wall_s=1.98`
- `mcount2-c1 start_et="2026-10-13 12:01:11 EDT" exit=0 wall_s=1.94`
- `mcount2-c2 start_et="2026-10-13 12:01:13 EDT" exit=0 wall_s=2.1`
- `mcount2-c2x start_et="2026-10-13 12:01:15 EDT" exit=0 wall_s=2.13`
- `mk-e-saves-not-serial start_et="2026-10-13 12:02:26 EDT" exit=0 wall_s=0.24`

`README-body.md` and `README-findings.md` are the first attempt's drafts of this file; this README supersedes them.

PIDs: every timeout, node, python and wrapper PID, with its command and start time, is in `pids.txt`. That covers 467+
lines across both attempts; this attempt's lines start at 12:00:10 PM ET. I killed nothing in this attempt.

Closed: 12:17 PM ET on Tue 13 Oct 2026.
