# ADOPT track (U24, U29 with U17, U31) — independent adversarial verifier, round 1, LENS A (data loss and money)

Directory: `rec/L6/adopt/verify-money-r1` (absolute:
`/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/adopt/verify-money-r1`).
Started 10:27 AM ET on 13 Oct 2026 (the folder held only an empty skeleton made at 10:27 AM ET: no earlier attempt's work to reuse).

Nothing was edited, staged, committed or pushed in `/home/user/orbit-board` or `/home/user/orbit-ui`, and nothing in the
builder's directory was changed: I worked on my own copies (`c1/ c2/ c3/` = `cp -a` of the builder's, `chmod u+w`, node_modules
symlink kept; `fx/` = my c3 plus my two proposed board lines). `mutate.mjs` was never imported or run: entries were counted and
applied as text only (`rec/bin/mcount.py`, `rec/bin/mkmut.py`, `python3 -I`). No `playwright install`, no Chromium run. The full
`audit-import.mjs` and `audit-board.mjs` were not run. Every board is the empty template; every fixture is synthetic, made at run time.
Every node run went through `bin/run.sh`, which checks the lock `AUDIT_IMPORT_RUNNING` before it starts (waiting up to 30 min); `logs/runs.txt`
has no "waiting" or "SKIPPED" line, so the lock was absent before every run and none waited or was skipped. (Four `node --check`
syntax checks of my probe harnesses, which execute nothing, were made outside run.sh, between 10:39 and 10:52 AM ET; I found the lock
absent when I looked at 10:40 and 10:48 AM ET.)

## Identities (re-hashed here, all equal to the builder's claims)

| copy | board | audit-import | mutate.mjs.txt | audit-recon / audit-board / audit-other |
|---|---|---|---|---|
| base `rec/L6/base` | `fce8a391` | `4aba2506` | `cbc6defc` | `529e36f7` / `a7c575e5` / `d89396b0` |
| c1 (U24) | `00c2ac152cd2f022efea656a3be40dca55c4ac8a` | `b111bfe1b976878b3431c0f118e9d69f2e45f2f0` | `d8f3956b6b0225cdca01a1937d4ddb4ba82d1d8b` | = base |
| c2 (U29) | `d020543e2166b087ad0ac1bdfdb39924c99b74b6` | `16ae994982de083003a8910b2ad3d4ceafaa07be` | `22df04f5152e6ecd6062da3237427b16af38594b` | = base |
| c3 (U31) | `c0d14fcdfb0b90d774c947277e0c8601af779930` | `97bc28bf559ad733c6cb6d813f801a843e43f3fc` | `f0c7dbf44d435092ae5dd271983ecd0121627d42` | = base |
| fx (mine: c3 + the two must-fix lines) | `e3df724d078168880de7d941c3746329e7d27a6e` | = c3 | = c3 | = base |

Focused harnesses built here from c3's suite by the builder's `mkfocused-import.py` (`252c00ef`, = rec/L2/u2impl/mkfocused-u2.py) are
byte-identical to the builder's: focused-U24 `7ee3334e`, focused-U29 `9f428d43`, focused-U31 `f2f7e9a9`; preservation v1.96 `e9a73126`,
W1 `310b30b8`, v2.00 R3–U13 `edd74fd9` (= the builder's `harness/pres-c3/`). runner.mjs `f851f139` (= the builder's; rec/L2's but for
its first comment line).

## Verdict: sound-with-issues — three must-fix items, none of them a loss of anyone's work

The three board changes do what the builder says on every route I tried, and no route I tried loses a copy of anyone's work,
writes over a copy unasked, or touches money or an export. The builder's focused blocks reproduce byte for byte here (identical
verdict sets on base, c1, c2 and c3), every new mutation I ran on the FINAL c3 is caught (the builder ran the U24 and U29 ones
only on c1 and c2), and mcount (text only) gives every entry exactly once on all four copies. But U29 makes the board say two
untrue things it did not say before, both measured, and the U31 release-note draft states a visible change that does not happen.

### Must fix before commit

**M1 (U29, words: principle 4). Working out of the shared folder, when the shared state file answers an opening before the
folder is read, every opening shows the shared state file instead of the folder's newer copy and says "reload to take theirs" —
and a reload never takes theirs.** Probe P8 (`harness/probe/probe3.mjs`, run P3-on-c3 vs P3-on-base): Brad's browser holds BRAD-1
(saved to the folder); Carol's SHARED is newer than it; Brad's other browser then saves BRAD-2, newer than SHARED, to the folder.
Each opening: the answer, then the opening's own connect (`driveAutoConnect`).
- c3, openings 1, 2 and 3 alike: `[screen SHARED 600, kept null, unsaved true/true/true, "⚠ Brad saved O&M to the shared folder just
  now, and you have unsaved changes. Nothing was replaced. Save yours, or reload to take theirs."]`.
- base: opening 1 loads BRAD-2 ("⬇ Loaded O&M FY27 from the shared folder"); openings 2 and 3 show BRAD-2 and offer the link.
- Cause: at every opening `sharedArrived` re-loads the very save already on screen (`st.ts===MS.ts`) and `loadedNotSaved` sets
  `DIRTY=true` again, so the connect's `driveStorePull` takes its "unsaved changes" branch instead of keeping the copy aside and
  loading the newer one. Nothing is lost (BRAD-2 stays in the folder; Save asks; Load theirs keeps SHARED aside), but the remedy the
  board names is untrue and the opening never shows the folder's newest copy. Whether the answer or the connect comes first is
  network timing; with the connect first the opening is right.
- Minimal fix (in `fx/`, `diffs/fx-vs-c3.diff`): in `sharedArrived`, inside `if((st.ts||0)>=(MS.ts||0))`, before the U24 guard:
  `if(+st.ts && +st.ts===+MS.ts && baseGet().dirty) return;` — the same save, already counted, is not loaded or counted again.
  Measured on fx: P8 passes (opening 2 keeps SHARED aside and loads BRAD-2), and the U24, U29 and U31 blocks and the v1.96, W1 and
  v2.00 R3–U13 preservation harnesses pass (table below). Taking the line back out of fx is caught by P8 (MF-fxm-same-save-recounted).
  Test to add: P8 as a scenario of the U29 block; mutation: that line removed.

**M2 (U29, words: principle 4). The folder's clash line says "What is on screen does not have their changes." in the builder's new
"and that is not the copy you are working from" branch, where the copy on screen came from a copy NEWER than the folder's and can
hold their changes.** Probe P9: Carol loads Brad's BRAD-2 from the folder, adds a note to B and downloads the shared state file
(A = BRAD-2 in it). It loads on its own on Brad's board (recorded saved against BRAD-2); a refresh then says
"⛔ Brad saved O&M FY27 to the shared folder just now, and that is not the copy you are working from. What is on screen does not have
their changes. …" while the screen shows A = BRAD-2, $720 (c3, P3-on-c3). On base the refresh said nothing (base is falsely clean,
U29). The builder lists these words under "Not covered", but the line is the one U29 changed, the branch is U29's own, and the claim
is untrue exactly there; it steers the choice between Load theirs and Save yours over theirs.
- Minimal fix (in `fx/`): `+(refused? '<b>Nothing was written.</b> ' : theirs>driveBaseOf(ap)? 'What is on screen does not have their
  changes. ' : 'What is on screen came from another copy, which may not have their changes. ')`. Measured on fx: P9 passes, the three
  blocks and the preservation harnesses pass; taking it back out is caught by P9 (MF-fxm-clash-lacks). Test: P9 in the U29 block;
  mutation: the unconditional words back.

**M3 (drafts: a false release note).** The U31 NEXT-VERSION draft says "What users may see: after a batch import, a reopen, or a
switch to another appropriation it imported, says the board has unsaved changes (or that work was kept aside), where it said
Saved." Measured (P1, c3, folder and file alike): after the import and a reopen the header reads `Saved 10:41 AM`, exactly as on
the base (`Saved 10:44 AM`), and as it does after any unsaved edit (the control) — that is ledger row U15, still open (the header
reads DIRTY only). Only the record changed (`baseGet().dirty` true on c3, false on base). The U31 block's header comment and the
board comment ("a reopen took the imported board as saved, the header said Saved") imply the header is fixed too. Fix: say what
changes — "a reopen keeps the imported board recorded unsaved, and keeps it aside before a newer saved copy replaces it; the header
after a reopen still reads Saved (U15)" — and drop "the header said Saved" from the two comments or add "(U15, unchanged)".

### Should fix

- **S1 (data loss next to U31, not addressed and under-described): "📁 File → ⬅ Import a full board" leaves the record of the board
  on screen clean, so a newer saved copy replaces the import with nothing kept aside.** P7-full (c3 and base alike): BRAD-1 saved to
  the folder; Carol's board imported through `fullImportText` (record after it: `"dirty":false`); Brad's other browser saves OTHER-2;
  this browser reopens: OTHER-2 on screen, kept aside null — the import is only in Carol's file. P7-batch (the U31 path) on c3 keeps
  IMPORT aside (base: null). The drafts' "Not covered" names only paths that write ANOTHER appropriation's board; the full import
  (and Import one appropriation, `lsSet` + reload) write this appropriation's board too. Recommend a ledger row (U31's shape, P2
  provisional) and correcting the "Not covered" line; the fix is the same as U31's (mark `_SLUGMAP[k].key+'.base'` dirty for every
  key the import writes, inside its all-or-nothing set).
- **S2 (principle 6): the existing check audit-import base L3935 ("the next refresh raises no false clash", `/after the copy you are
  working from/` must be absent) no longer sees every false clash**: U29 gives the clash line a second wording, so a false clash
  with the folder's copy older than the record passes it. The builder's principle-6 note calls the three existing checks of that
  wording "unchanged"; they are, but L3935 is weaker. List it (file:line, old meaning, new meaning); a sibling check on
  `/Save yours over theirs/` absent would restore it (new check, not an edit). L7656 is still guarded by its status-line equality.
- **S3: U29 sets `LASTKNOWN=0` in file mode**, which also silences the opening's "the file has been saved since then as well"
  notice (`_bootMoved` needs `LASTKNOWN`), and Save's question then says "this browser cannot tell whether that was before or after
  the copy you are working from" where it could tell. Save still asks, so nothing is lost (P6). By code; worth one line in "Not covered".

### Minor

- ↶ Put back's question after "load the shared one" on a board recorded saved now says "What is on screen now has changes no saved
  copy has, so it is kept aside in its place — nothing is lost" (P4, c3) — the screen is the shared state file. It keeps rather than
  drops, so it is safe; the base's words ("still in the shared folder it came from") were the false ones (U17).
- After a non-quiet save lands, the U24 refusals' "Once the save has finished, load the shared one / open the file's version" link
  is gone with the line; only a reopen offers it again (the words say so).
- The U24 refusal "what is on screen and the work kept aside are as they were" stays on screen after a quiet autosave; a later quiet
  Live refresh that loads a newer folder copy changes the screen under it (the same is true of U2's words). By code.

### Checked and sound (lens A)

- U24: the guard sits after each load's last wait in all three; with a save held (folder write, history copy, read, autosave; file
  close) nothing changes byte for byte and the save lands recorded against its own copy (builder's block, re-run). Extra: "open the
  file's version" working out of the folder while a folder save or the Live autosave is held (P3W, P3Wauto, P3b): refused on c3
  (base: CAROL-F on screen recorded saved against BRAD-2's copy, and the next Save wrote it over BRAD-2 unasked); after a quiet
  autosave the line and its link stay, and the link then loads the file's version counted, and the next Save asks.
- U29: the next Save asks in both modes; the record stops naming the person's copy for EVERY year — P2: two years in the folder,
  the link, then FY28 saved: c3 refuses with the choice (BRAD-28 kept), base wrote SHARED-28 over BRAD-28 unasked. P6 (file, the
  shared state file stamped an hour ahead): c3 asks before writing over BRAD-2; base wrote over it unasked.
- U31: P1/P5/P7-batch: the record is dirty after the batch, the import is kept aside at a reopen under a newer saved copy.
- Money and exports: no money path is touched (diff read line by line); `boot-same` ("every page, source, save and error list is
  identical either way"), `audit` (exports) and `audit-ppt` re-run on c3: all pass (S-* below).

## Every run (bounded: setsid -w timeout -k 10 600, through bin/run.sh; times ET, 13 Oct 2026)

Labels: R-* the builder's focused blocks re-run (harness from c3; "on base/c1/c2" = BOARD set to that board); P1/P2/P3-* my probes
(round 1/2/3); MV-* each new mutation made AS TEXT from c3's mutate.mjs.txt on the FINAL c3, under its own block; FX-* my fix copy
fx/ under the blocks, probe round 3 and the preservation harnesses; MF-* my two fix lines taken back out of fx, under probe round 3;
S-* suites on c3. "checks"/"failing" are from each run's SUITE_CHECKS record (out/*.checks.jsonl) or its log.

| run | start (ET) | exit | wall s | checks | failing | log |
|---|---|---|---|---|---|---|
| R-U24-on-c3 | 2026-10-13 10:35:11 | 0 | 90.0 | 58 | 0 | logs/R-U24-on-c3.log |
| R-U24-on-base | 2026-10-13 10:36:41 | 1 | 128.3 | 58 | 28 | logs/R-U24-on-base.log |
| R-U29-on-c3 | 2026-10-13 10:38:50 | 0 | 120.6 | 33 | 0 | logs/R-U29-on-c3.log |
| R-U29-on-base | 2026-10-13 10:40:51 | 1 | 144.0 | 33 | 24 | logs/R-U29-on-base.log |
| P1-on-c3 | 2026-10-13 10:40:55 | 1 | 170.6 | 7 | 2 | logs/P1-on-c3.log |
| R-U29-on-c1 | 2026-10-13 10:43:15 | 1 | 113.0 | 33 | 24 | logs/R-U29-on-c1.log |
| P1-on-base | 2026-10-13 10:43:46 | 1 | 134.5 | 7 | 6 | logs/P1-on-base.log |
| R-U31-on-c3 | 2026-10-13 10:45:08 | 0 | 90.7 | 34 | 0 | logs/R-U31-on-c3.log |
| P2-on-c3 | 2026-10-13 10:46:19 | 1 | 65.2 | 3 | 1 | logs/P2-on-c3.log |
| R-U31-on-base | 2026-10-13 10:46:38 | 1 | 87.3 | 34 | 14 | logs/R-U31-on-base.log |
| P2-on-base | 2026-10-13 10:47:25 | 1 | 58.5 | 3 | 3 | logs/P2-on-base.log |
| R-U31-on-c2 | 2026-10-13 10:48:06 | 1 | 65.9 | 34 | 14 | logs/R-U31-on-c2.log |
| P3-on-c3 | 2026-10-13 10:48:54 | 1 | 33.1 | 2 | 2 | logs/P3-on-c3.log |
| P3-on-base | 2026-10-13 10:49:27 | 0 | 36.8 | 2 | 0 | logs/P3-on-base.log |
| MV-v200-adopt-u29-no-count | 2026-10-13 10:49:45 | 1 | 79.5 | 33 | 6 | logs/MV-v200-adopt-u29-no-count.log |
| MV-v200-adopt-u24-link-guard | 2026-10-13 10:49:44 | 1 | 111.0 | 58 | 20 | logs/MV-v200-adopt-u24-link-guard.log |
| MV-v200-adopt-u29-session-clean | 2026-10-13 10:51:05 | 1 | 82.3 | 33 | 12 | logs/MV-v200-adopt-u29-session-clean.log |
| MV-v200-adopt-u24-answer-guard | 2026-10-13 10:51:36 | 1 | 104.6 | 58 | 8 | logs/MV-v200-adopt-u24-answer-guard.log |
| MV-v200-adopt-u29-record-clean | 2026-10-13 10:52:28 | 1 | 84.6 | 33 | 9 | logs/MV-v200-adopt-u29-record-clean.log |
| MV-v200-adopt-u24-file-guard | 2026-10-13 10:53:21 | 1 | 116.3 | 58 | 2 | logs/MV-v200-adopt-u24-file-guard.log |
| MV-v200-adopt-u29-file-base-kept | 2026-10-13 10:53:53 | 1 | 89.2 | 33 | 5 | logs/MV-v200-adopt-u29-file-base-kept.log |
| MV-v200-adopt-u29-folder-base-kept | 2026-10-13 10:55:23 | 1 | 103.8 | 33 | 11 | logs/MV-v200-adopt-u29-folder-base-kept.log |
| MV-v200-adopt-u24-link-words-later | 2026-10-13 10:55:18 | 1 | 128.9 | 58 | 6 | logs/MV-v200-adopt-u24-link-words-later.log |
| MV-v200-adopt-u29-link-uncounted | 2026-10-13 10:57:08 | 1 | 90.7 | 33 | 14 | logs/MV-v200-adopt-u29-link-uncounted.log |
| MV-v200-adopt-u24-link-words-record | 2026-10-13 10:57:28 | 1 | 122.3 | 58 | 6 | logs/MV-v200-adopt-u24-link-words-record.log |
| MV-v200-adopt-u29-answer-uncounted | 2026-10-13 10:58:39 | 1 | 83.5 | 33 | 5 | logs/MV-v200-adopt-u29-answer-uncounted.log |
| MV-v200-adopt-u24-file-words-record | 2026-10-13 10:59:30 | 1 | 107.3 | 58 | 1 | logs/MV-v200-adopt-u24-file-words-record.log |
| MV-v200-adopt-u29-takefile-uncounted | 2026-10-13 11:00:03 | 1 | 87.5 | 33 | 3 | logs/MV-v200-adopt-u29-takefile-uncounted.log |
| MV-v200-adopt-u31-no-mark | 2026-10-13 11:01:18 | 1 | 75.6 | 34 | 11 | logs/MV-v200-adopt-u31-no-mark.log |
| MV-v200-adopt-u29-same-save-kept | 2026-10-13 11:01:31 | 1 | 87.7 | 33 | 1 | logs/MV-v200-adopt-u29-same-save-kept.log |
| MV-v200-adopt-u31-memory-only | 2026-10-13 11:02:35 | 1 | 79.5 | 34 | 11 | logs/MV-v200-adopt-u31-memory-only.log |
| MV-v200-adopt-u29-clash-after | 2026-10-13 11:02:59 | 1 | 87.7 | 33 | 4 | logs/MV-v200-adopt-u29-clash-after.log |
| MV-v200-adopt-u31-other-unmarked | 2026-10-13 11:03:55 | 1 | 84.3 | 34 | 3 | logs/MV-v200-adopt-u31-other-unmarked.log |
| MV-v200-adopt-u29-promise-yours | 2026-10-13 11:04:28 | 1 | 88.3 | 33 | 1 | logs/MV-v200-adopt-u29-promise-yours.log |
| MV-v200-adopt-u29-promise-what-you-have | 2026-10-13 11:05:57 | 1 | 114.4 | 33 | 1 | logs/MV-v200-adopt-u29-promise-what-you-have.log |
| S-boot-same-c3 | 2026-10-13 11:08:01 | 0 | 51.2 |  |  | logs/S-boot-same-c3.log |
| FX-P3 | 2026-10-13 11:08:07 | 0 | 57.2 | 2 | 0 | logs/FX-P3.log |
| S-audit-c3 | 2026-10-13 11:08:53 | 0 | 48.5 |  | 0 | logs/S-audit-c3.log |
| S-audit-ppt-c3 | 2026-10-13 11:09:41 | 0 | 25.0 |  | 0 | logs/S-audit-ppt-c3.log |
| FX-U24 | 2026-10-13 11:09:05 | 0 | 144.7 | 58 | 0 | logs/FX-U24.log |
| FX-U29 | 2026-10-13 11:11:30 | 0 | 94.8 | 33 | 0 | logs/FX-U29.log |
| FX-U31 | 2026-10-13 11:13:04 | 0 | 93.2 | 34 | 0 | logs/FX-U31.log |
| FX-pres-v196 | 2026-10-13 11:14:38 | 0 | 116.0 | 22 | 0 | logs/FX-pres-v196.log |
| FX-pres-w1 | 2026-10-13 11:16:34 | 0 | 124.6 | 53 | 0 | logs/FX-pres-w1.log |
| FX-pres-v200 | 2026-10-13 11:18:38 | 0 | 402.9 | 167 | 0 | logs/FX-pres-v200.log |
| MF-fxm-same-save-recounted | 2026-10-13 11:25:26 | 1 | 50.1 | 2 | 1 | logs/MF-fxm-same-save-recounted.log |
| MF-fxm-clash-lacks | 2026-10-13 11:26:16 | 1 | 51.5 | 2 | 1 | logs/MF-fxm-clash-lacks.log |

### The builder's focused runs compared with the builder's own records (bin/cmp.py: same checks, same verdict for each)

```
R-U24-on-c3.checks.jsonl checks 58 failing 0
  vs F5-U24-on-c3.checks.jsonl checks 58 failing 0 identical verdict sets: True
R-U24-on-base.checks.jsonl checks 58 failing 28
  vs F2-U24-on-base.checks.jsonl checks 58 failing 28 identical verdict sets: True
R-U29-on-c3.checks.jsonl checks 33 failing 0
  vs F5-U29-on-c3.checks.jsonl checks 33 failing 0 identical verdict sets: True
R-U29-on-base.checks.jsonl checks 33 failing 24
  vs F2-U29-on-base.checks.jsonl checks 33 failing 24 identical verdict sets: True
R-U29-on-c1.checks.jsonl checks 33 failing 24
  vs F2-U29-on-c1.checks.jsonl checks 33 failing 24 identical verdict sets: True
R-U31-on-c3.checks.jsonl checks 34 failing 0
  vs F4-U31-on-c3.checks.jsonl checks 34 failing 0 identical verdict sets: True
R-U31-on-base.checks.jsonl checks 34 failing 14
  vs F4-U31-on-base.checks.jsonl checks 34 failing 14 identical verdict sets: True
R-U31-on-c2.checks.jsonl checks 34 failing 14
  vs F4-U31-on-c2.checks.jsonl checks 34 failing 14 identical verdict sets: True
```

### The 21 new mutations, each made as text from c3's mutate.mjs.txt and run on the FINAL c3 (all caught)

| id | matches on c3 | checks | failing here (final c3) | failing in the builder's run (c1 for U24, c2 for U29, c3 for U31) |
|---|---|---|---|---|
| `v200-adopt-u24-link-guard` | 1 | 58 | 20 | 18 |
| `v200-adopt-u24-answer-guard` | 1 | 58 | 8 | 8 |
| `v200-adopt-u24-file-guard` | 1 | 58 | 2 | 2 |
| `v200-adopt-u24-link-words-later` | 1 | 58 | 6 | 6 |
| `v200-adopt-u24-link-words-record` | 1 | 58 | 6 | 6 |
| `v200-adopt-u24-file-words-record` | 1 | 58 | 1 | 1 |
| `v200-adopt-u29-no-count` | 1 | 33 | 6 | 6 |
| `v200-adopt-u29-session-clean` | 1 | 33 | 12 | 12 |
| `v200-adopt-u29-record-clean` | 1 | 33 | 9 | 9 |
| `v200-adopt-u29-file-base-kept` | 1 | 33 | 5 | 5 |
| `v200-adopt-u29-folder-base-kept` | 1 | 33 | 11 | 11 |
| `v200-adopt-u29-link-uncounted` | 1 | 33 | 14 | 14 |
| `v200-adopt-u29-answer-uncounted` | 1 | 33 | 5 | 5 |
| `v200-adopt-u29-takefile-uncounted` | 1 | 33 | 3 | 3 |
| `v200-adopt-u29-same-save-kept` | 1 | 33 | 1 | 1 |
| `v200-adopt-u29-clash-after` | 1 | 33 | 4 | 4 |
| `v200-adopt-u29-promise-yours` | 1 | 33 | 1 | 1 |
| `v200-adopt-u29-promise-what-you-have` | 1 | 33 | 1 | 1 |
| `v200-adopt-u31-no-mark` | 1 | 34 | 11 | 11 |
| `v200-adopt-u31-memory-only` | 1 | 34 | 11 | 11 |
| `v200-adopt-u31-other-unmarked` | 1 | 34 | 3 | 3 |

Only `-u24-link-guard` differs (20 here, 18 on the builder's c1; c3 carries the two later commits; the difference was not investigated). Every one exits 1.

### Suites summary

```
S-boot-same-c3 | every page, source, save and error list is identical either way | exit: 0
S-audit-c3 | ALL CHECKS PASSED | exit: 0
S-audit-ppt-c3 | ALL CHECKS PASSED | exit: 0
```

### mcount (text only, python3 -I rec/bin/mcount.py <mutate.mjs.txt> <board>)

```
base {"entries": 1328, "once": 1328, "missing": [], "multiple": [], "unparsed": []}
c1 {"entries": 1334, "once": 1334, "missing": [], "multiple": [], "unparsed": []}
c2 {"entries": 1346, "once": 1346, "missing": [], "multiple": [], "unparsed": []}
c3 {"entries": 1349, "once": 1349, "missing": [], "multiple": [], "unparsed": []}
```

## My diff and blobs

The proposed fix lines (`diffs/fx-vs-c3.diff`, blob 8f9192f33f1ef5747eff78a136e2da2fdce12e96):

```diff
--- c3/prioritization-board-grid.html	2026-10-13 03:44:10.665652481 +0000
+++ fx/prioritization-board-grid.html	2026-10-13 14:51:56.833125121 +0000
@@ -27014,7 +27014,8 @@
   setStat('\u26d4 <b>'+esc((j&&j.by)||'someone')+'</b> saved '+esc(APPN_LBL[ap]||ap)+' FY'+(MS.cur%100)
     // v2.00 (U29): "after" only when it is. A copy loaded from elsewhere (loadedNotSaved) can be newer than the folder's.
     +' to the shared folder '+esc(liveAge(theirs))+(theirs>driveBaseOf(ap)? ', after the copy you are working from. ' : ', and that is not the copy you are working from. ')
-    +(refused? '<b>Nothing was written.</b> ' : 'What is on screen does not have their changes. ')
+    +(refused? '<b>Nothing was written.</b> ' : theirs>driveBaseOf(ap)? 'What is on screen does not have their changes. '
+      : 'What is on screen came from another copy, which may not have their changes. ')
     +'<button type="button" class="nb lnk" onclick="driveResolve(\'theirs\')">Load theirs</button> '
     +'(your work is kept aside, and one click puts it back) \u00b7 '
     +'<button type="button" class="nb lnk" onclick="driveResolve(\'mine\')">Save yours over theirs</button> '
@@ -31714,6 +31715,10 @@
     return;
   }
   if((st.ts||0)>=(MS.ts||0)){
+    // v2.00 (U29): THE SAME SAVE AS THE ONE ON SCREEN, ALREADY COUNTED -- its time is its identity, and this browser's record says
+    // unsaved -- is not loaded again. Counted again at every opening, it held off the opening's own connect: the folder's newer
+    // copy was never loaded, and "reload to take theirs" was untrue.
+    if(+st.ts && +st.ts===+MS.ts && baseGet().dirty) return;
     // v2.00 (U24): AN ANSWER THAT ARRIVES WHILE A SAVE IS UNDER WAY is not loaded (see adoptShared): it is offered instead.
     if(_saveBusy){
       setStat('⏳ The shared state file ('+esc(fmtTs(st.ts))+') arrived while a save was under way, so it was <b>not loaded</b> and '
```

| file | blob |
|---|---|
| `bin/run.sh` | `1dc7b80c5aa3ea5c53f3479124b9732f7e1d2c7f` |
| `bin/rerun.sh` | `df83e938069c1c5ce28c03d1333326314775b521` |
| `bin/probe.sh` | `59445e8ff82fd3475455deb36dea01562cca9a77` |
| `bin/mut.sh` | `d2ac79086a8df3d29b4500fd463f553ab5d09125` |
| `bin/suites.sh` | `eed0b59b8b641deee6892e83164f4e4148fb106c` |
| `bin/fx.sh` | `76e28ffaf55b6b2e07a4f7b33a354031f4f0684d` |
| `bin/fxmut.sh` | `731e8a39f89813779613c825541da508c53b7259` |
| `bin/cmp.py` | `ede5fbd94fe66cbbff760a74e33cd47a5ccda809` |
| `bin/table.py` | `a22da68bcd4fd3dbb557a0e70d4bad524734f079` |
| `bin/mkreadme.sh` | `24018d27c48be24a6a900a77e8811bb125b4ef91` |
| `bin/runner.mjs` | `f851f1391102e59aa12f0ca301b40bb4ddd005f3` |
| `bin/mkfocused-import.py` | `252c00ef658b2db1d8810b0f3d42348f151b1136` |
| `probe/block-probe.mjs.txt` | `b48fee5ae344c4e01111b1f3801414c7a9c22ac0` |
| `probe/block-probe2.mjs.txt` | `a7ef6fc5cfac99ef50f86f1437eb7656cdbd2c1c` |
| `probe/block-probe3.mjs.txt` | `e00404a70afbec7b84fe184f05a580b4e675f0ca` |
| `probe/p3-scenarios.txt` | `91383e9d3374fd466894bc5e6897a8d53327eff2` |
| `harness/probe/probe.mjs` | `4d54aa015b8920f5ba046abb7e217de7c2f4f7c7` |
| `harness/probe/probe2.mjs` | `1ff44f9e4c6273969659d85cdd439fb97246e45a` |
| `harness/probe/probe3.mjs` | `cd4287592b697766353fe5046bf3a48a2e9e0f23` |
| `harness/pres/v196.mjs` | `e9a731268d16a9834640c8bd7e93ad9443ca0805` |
| `harness/pres/w1.mjs` | `310b30b831e82f87cac80e305cad689a72c4f291` |
| `harness/pres/v200.mjs` | `edd74fd910fc2ecaae2f2555cda2173be98e3bf9` |
| `harness/c3/focused-U24.mjs` | `7ee3334e45743331dcd54fbb4b4d94cae59ae99e` |
| `harness/c3/focused-U29.mjs` | `9f428d43bf3f64072cfa80c355cb4c4ba62f5290` |
| `harness/c3/focused-U31.mjs` | `f2f7e9a9308b03d3279ed514d1f2b687e53d92ec` |
| `fx/prioritization-board-grid.html` | `e3df724d078168880de7d941c3746329e7d27a6e` |
| `mut/fxm-same-save-recounted.html` | `63ab5268bc1de043ac2579a0ef56c244e414e0fd` |
| `mut/fxm-clash-lacks.html` | `c4a1d4d1241a229ced8582a1b6cc013958a1aab5` |

## PIDs

Every PID this review started is in `pids.txt` (114 lines: each run's timeout PID and its node child, recorded by run.sh with the command, and each background launcher or wait loop). Nothing was killed: no PID was signalled except `kill -0` checks (which only test that a process exists) on my own launchers.

## Decisions, with reasons

1. **Fresh start.** The folder held only an empty skeleton (`notes.txt` "started 10:27:18 EDT", empty `logs/ diffs/ probe/`), so
   there was nothing of an earlier attempt to reuse.
2. **Re-ran the builder's focused runs on base, c1/c2 and c3 from my own copies** (blobs equal), and compared the full
   (scenario, place, claim, verdict) sets with the builder's records (`bin/cmp.py`): identical for all eight.
3. **Ran every new mutation on the FINAL c3**, not on c1/c2 as the builder did, to close the builder's own "not done" item.
4. **Probes were written as a block in the suite's own style and assembled with the builder's `mkfocused-import.py`** from a copy of
   c3's suite with the block appended (`probe/suite-probe*.mjs`), so they use W1H's folder and disk mocks exactly as the blocks do.
   Expected values are literals; `OBS` lines print what was read. Round 1 (`probe.mjs`): P1–P6; round 2 (`probe2.mjs`): P3b, P7;
   round 3 (`probe3.mjs`): P8, P9. (Round 2's first build lost two template literals to an unquoted shell heredoc; I found it before
   any run — `node --check` passed but two `A.ev()` calls were empty — rebuilt it with a quoted heredoc, and only the rebuilt
   `probe2.mjs`, `1ff44f9e`, was ever run.)
5. **M1 and M2 are must-fix although no work is lost**: both are words the board did not say before U29, measured untrue on c3,
   on the lines and branches this change adds or touches (principle 4 is a release principle here). Each has a one-line fix that I
   measured on `fx/` against the track's own blocks and the existing blocks next to the change, and each fix line, taken out again,
   is caught by its probe. I did not write the suite blocks or mutation entries for them: that is the builder's.
   M1's fix has one consequence to state: in file mode the same-save answer no longer sets DIRTY at each opening, so the header after
   such a reopen reads "Saved" like every reopened unsaved board (U15, open); the record still says unsaved and Save still asks.
6. **S1 is should-fix, not must-fix**: the full import is not this commit's path and the commit does not make it worse; it is the
   same loss as U31 on the neighbouring path, so it belongs in the ledger and in the drafts' "Not covered" line.
7. **`bin/probe.sh` was edited once** (sed, after round 1 had run) to take the harness number as a second argument; round 1
   (P1-*) ran its first form, which booted `harness/probe/probe.mjs`; the blob listed is the edited form.
8. **Suites**: `boot-same`, `audit` (exports) and `audit-ppt` were re-run on c3 for the money lens, from my copy's root (they do not
   need git). The builder's other suites (audit-other, legacy-fsrc, audit-inject, audit-recon, audit-hostile, npm run check) were not
   re-run: the change touches no path they exercise beyond what the focused and preservation harnesses cover.

## What I did not do

- Nothing committed, staged or pushed; nothing edited in orbit-board, orbit-ui or the builder's directory.
- `mutate.mjs` never imported or run (text only). No full `audit-import.mjs` / `audit-board.mjs`. No Chromium, no `playwright install`.
- No real-browser timing measurement of which comes first at an opening, the shared state file's answer or the folder's connect (M1
  is shown with the answer first, by calling the page's own callbacks in that order).
- P6 meant to have a colleague save the board file between two openings; that save did not land (the file still held BRAD-2 at the
  next opening — by code, the file's one-writer rule refuses Dana, who is not its writer), so S3 stays by code. P3/P3Wauto's last step ("link after the autosave
  landed") clicked after a Save had replaced the line (`buttons: 0`); P3b repeats it in the right order.
- I did not re-run audit-other, legacy-fsrc, audit-inject, audit-recon, audit-hostile or npm run check (the builder's are on the same blobs).
- I did not write suite blocks, mutation entries or draft texts for M1–M3 or S1; the README gives the fixes and the tests they need.
