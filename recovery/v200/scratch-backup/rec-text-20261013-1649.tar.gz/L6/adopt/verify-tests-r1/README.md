# ADOPT track (U24, U29 with U17, U31) -- independent verification, LENS B (test adequacy and regressions), round 1

Directory: `rec/L6/adopt/verify-tests-r1` (absolute:
`/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/adopt/verify-tests-r1`).

**Two attempts, one folder.** The first attempt of this review started at 10:27 AM ET on 13 Oct (this folder did not exist)
and was stopped by the lead at about 11:45 AM ET to lower the machine's load (it had run up to six lanes at once). This attempt
resumed at 11:57 AM ET, after checking `/proc` for every PID in `pids.txt` (none alive). Every run of the first attempt that has
an exit record in `logs/runs.txt` was made on the same blobs as now (checked below) and is reused; the four runs that had none
were re-run (`-r2` labels, or the same label for `VS-audit-recon-base`, whose stopped log is kept as
`logs/VS-audit-recon-base.STOPPED-1145.log`). From the resume on, at most two node processes of this review ran at once
(`npm run check`, which is two node processes by itself, ran alone).

`README.head.md` is the first attempt's unfinished opening, superseded by this file.

Everything here is my own copy; I never edited the builder's files, `/home/user/orbit-board` or `/home/user/orbit-ui`. Nothing
was committed or pushed anywhere. `mutate.mjs` was never imported or run: entries were read as text by `rec/bin/mkmut.py`
and `rec/bin/mcount.py` (`python3 -I`). No `playwright install`, no Chromium run. The full `audit-import.mjs` and
`audit-board.mjs` were not run. Every board stays the empty template; every fixture is synthetic, made at run time.

## Verdict: sound-with-issues -- one must-fix (a data-loss route the change fixes but no test drives), five should-fixes

The three board changes do what the builder says on every route the builder tests, and on the extra routes driven here (probe
G1-G4, G2b). Every builder run re-run here reproduces exactly: same checks, same failing set, same observed values once clock
times are normalised. The suites are pure insertions (one hunk each in `audit-import.mjs` and `mutate.mjs.txt`; no other suite
changed): no existing check, fixture or expected value was edited. Every new expected value is a hand-written literal. mcount
(text only): every entry matches exactly once on base/c1/c2/c3 (1328/1334/1346/1349), and on c3 with the four entries proposed
here (1353). The other suites pass on the base clone and the final-c3 clone with identical output.

But the new blocks do not drive every route the change fixes, and on one of them a one-word wrong fix brings back DATA LOSS
with nothing failing:

- **MUST FIX (M1).** Saving to the board file, the shared state file's OWN load (`sharedArrived` on a board recorded saved --
  SHaC in file mode, the automatic sibling of the tested XFSHn) is driven by no check. The mutant `loadedNotSaved(st, false)` in
  `sharedArrived` (`vt-u29-answer-file-kept`; the same board, blob `a58a59ae`, as the proposed entry `v200-adopt-u29-answer-file-kept` makes) passes the U24
  and U29 blocks on c2 and on the final c3, and the v1.89, W1 and v1.96 harnesses on c3 (v1.96's NR05 block is the only other suite code
  that calls `sharedArrived`). On it -- and on the base -- the next 💾 Save asks nothing, writes the shared state file over BRAD-1, and
  BRAD-1 is then in no browser-storage value, not kept aside and not in the board file (probe G2b, both answers: `asked 0,
  writes 1, BRAD-1 nowhere`). On c3 the same Save asks first and, answered Cancel, BRAD-1 stays in the file. Minimal fix:
  scenario (9) in the U29 block (`proposals/u29-scenario-9.mjs.txt`; 5 checks: 4 fail on the base, all pass on c2 and c3, 3
  fail on the mutant) and the entry `v200-adopt-u29-answer-file-kept` (`proposals/entries-proposed.mjs.txt`).

The should-fixes are three more surviving wrong fixes on routes the change fixes (S1-S3: no copy lost outright -- the
overwritten copy is in the folder's history, or the save's copy is kept aside), two claims in the drafts that are not true as
written (S4), and BTC's record going falsely clean again at a reopen, the one triage contract still failing on c3 (S5).
Details below.

## Identities (git hash-object; my copies `c/*` are byte-identical to the builder's `c1`-`c3` and to `rec/L6/base`)

| copy | board | audit-import | mutate.mjs.txt | audit-recon / audit-board / audit-other |
|---|---|---|---|---|
| base (`7ee498a`, product `d66dd60`) | `fce8a391` | `4aba2506` | `cbc6defc` | `529e36f7` / `a7c575e5` / `d89396b0` |
| c1 (U24) | `00c2ac15` | `b111bfe1` | `d8f3956b` | = base |
| c2 (U29) | `d020543e` | `16ae9949` | `22df04f5` | = base |
| c3 (U31, final) | `c0d14fcd` | `97bc28bf` | `f0c7dbf4` | = base |

Every other file under `tools/export-audit` is identical on base and c3 (`cmp`). The focused harnesses here (`harness/*`, built
verbatim from each copy's own `audit-import.mjs` by `bin/mkfocused-import.py` = `rec/L2/u2impl/mkfocused-u2.py`) have the same
blobs as the builder's: focused-U24 `7ee3334e`, focused-U29 `9f428d43`, focused-U31 `f2f7e9a9`, v189 `ed54e613`, w1 `310b30b8`,
v196 `e9a73126`, w3 `e231e09f`, v200 (R3-U13) `edd74fd9`; boot.mjs `9c4f49ad`. Each run's log opens with an `IDS` line naming
the board blob, harness blob and boot.mjs it ran.

Scratch clones for the other suites: `git/base` and `git/c3` (`git clone --shared /home/user/orbit-board`, detached at
`7ee498a`; `git/c3` has c3's board and audit-import copied over; nothing committed; `node_modules` symlink and the base shim).

## Diffs against the base (`diffs/`; the builder's changes, re-made from my copies)

| file | blob | what |
|---|---|---|
| `board-c1-vs-base.diff` | `a5cfb906` | U24: three `_saveBusy` refusals (bootTakeFile after its question, adoptShared, sharedArrived) |
| `board-c2-vs-c1.diff` | `d7a4b49c` | U29: `loadedNotSaved()`, called by adoptShared/sharedArrived (`file` true) and bootTakeFile in folder mode; sharedKeepMine same-save; driveClashSay "after" only when it is; two link promises |
| `board-c3-vs-c2.diff` | `ef45e982` | U31: importBoards marks the record of the board on screen and of every other appropriation it wrote |
| `audit-import.mjs.c1-vs-base.diff` / `c2-vs-c1` / `c3-vs-c2` / `c3-vs-base` | `e671553c` / `4cfc334c` / `9a00b603` / `f5248083` | ONE inserted hunk each (`7799a7800,8039`, `8039a8040,8254`, `8254a8255,8389`): the U24, U29, U31 blocks after "end v2.00 (U13)"; 0 lines removed |
| `mutate.mjs.txt.c1-vs-base.diff` / `c2-vs-c1` / `c3-vs-c2` / `c3-vs-base` | `660f357a` / `c27c66ff` / `01f4339d` / `d043a447` | ONE inserted hunk each (6 + 12 + 3 entries) just before "// v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan."; 0 lines removed |

**Changed existing expectations: none.** No line of any existing suite, fixture or expected value is changed or removed.
One existing check is weaker in meaning without being edited (by code, minor N4 below): `audit-import.mjs` base L3935.

## Findings

### M1 (MUST FIX) -- SHaC in file mode is fixed but never driven; one word brings back data loss unseen

- **Route.** Saving to the board file, a board recorded saved (BRAD-1, $700, saved into the file and reopened). The shared state
  file answers (SHARED, $600, stamped an hour ahead) and `sharedArrived` loads it on its own. The base then records the screen
  clean against the file's save, and the next 💾 Save writes SHARED over BRAD-1 without a question. Commit 2 fixes it with
  `loadedNotSaved(st, true)` in `sharedArrived` (c3 L31726): `file` true makes LASTKNOWN and the record's `file` 0, so Save asks.
  The draft U29 entry claims it ("for the board file nothing is recorded, so Save asks before it writes over the file"), and the
  ledger draft lists "SHaC ... covered" -- but the U29 block drives SHaC in folder mode only ((5)); its file-mode scenarios
  ((2), (4)) are the LINK (`adoptShared`), whose own `true` is a different line.
- **Wrong fix that survives.** `loadedNotSaved(st, false)` in `sharedArrived` -- the argument `bootTakeFile` uses, so a plausible
  slip. Mutant `mut/own/vt-u29-answer-file-kept--c3.html` (`a58a59ae`; `--c2` `932e93b4`): **0 failing checks** in
  VO-...--c2-focused-U29 (33), --c2-focused-U24 (58), --c3-focused-U24 (58), --c3-focused-U29 (33), --c3-v196 (22),
  --c3-v189 (40), --c3-w1 (53). By search, the only other suite code that calls `sharedArrived`/`adoptShared` is the v1.96
  NR05 block (inside the v196 harness), and no other suite under `tools/export-audit` names them.
- **The loss, measured.** Probe G2b (`probe/block-g2b.mjs.txt` `2d7e5f30`, harness `harness/c3/probe-g2b.mjs` `2402502f`), the
  route above, then 💾 Save answered Cancel (and, separately, "overwrite anyway"), then a search of every browser-storage value,
  the kept-aside slot and the board file for the marker BRAD-1:
  - **mutant** (VG2b-on-answer-file-kept, exit 1): `asked 0, writes 1`, BRAD-1 found nowhere (`brad1: []`), with either answer --
    the question is never asked.
  - **base** (VG2b-on-base, exit 1): the same (`asked 0, writes 1, brad1: []`).
  - **c3** (VG2b-on-c3): `asked 1` both times; Cancel: `writes 0`, BRAD-1 in the board file. ("Overwrite anyway" writes it, as
    the person chose after the question -- the probe's "still somewhere" check in that leg encodes a wrong expectation and is
    read as an observation only; `logs/notes.txt`.)
  - The first attempt's probe G2 (VP2-gaps-*, VO2-...answer-file-kept) shows the same from the record's side: on the mutant
    `[SHARED, 600, true, true, true, <file ts>, <file ts>]` (counted, but LASTKNOWN and the record still name the file's save)
    and the Save `[asked 0, writes 1, file SHARED]`.
- **Reachability.** The same as the tested XFSHn: the shared state file must answer (served over http, or the old launcher with
  `spmtSidecar=1`); `loadShared` skips it otherwise. The automatic load needs no click, so it is the less visible of the two.
- **Minimal fix.** Add scenario (9) to the U29 block, before (8) -- text in `proposals/u29-scenario-9.mjs.txt` (`40db0638`), in
  the block's own helpers and voice, literals only. Measured in the U29 block with (9) inserted (`harness/c3/proposed-U29-9.mjs`
  `dca41095`): 38 checks; **base: 28 fail** (the 24 known + 4 of the 5 new, the fifth is its CONTROL); **c2 and c3: 0 fail**;
  **the mutant: 3 fail**, all new ([LASTKNOWN, record file] `[<ts>, <ts>]` vs `[0, 0]`; the Save `[0, 1, SHARED, ...]` vs
  `[1, 0, BRAD-1, ...]`; the reopen). And add the entry `v200-adopt-u29-answer-file-kept`
  (`proposals/entries-proposed.mjs.txt`): find `    loadedNotSaved(st, true);               // v2.00 (U29): a change from what is
  saved (see adoptShared)\n`, repl the same with `false` -- matches c3 exactly once (mcount below).

### S1 (should fix) -- another year in the folder: the other-years loop of `loadedNotSaved` is not driven

`loadedNotSaved` moves the record of EVERY year of this appropriation (two `forEach` loops, c3 L8467-8468). The U29 block works
with FY27 only. Wrong fix `vt-u29-year-on-screen-only` (only `_driveBase[driveBaseKey(ap)]=ts`): 0 failing in VO-...--c2-focused-U29
(33). Probe G3 (`probe/block-gaps.mjs.txt`): Brad saved BRAD-28 (FY28) and BRAD-1 (FY27) to the folder and reopened; the link
loads Carol's SHARED (FY27 SHARED, FY28 SHARED-28); on FY28 💾 Save -- on the mutant (VO2-...year-on-screen-only, exit 1) and on
the base (VP2-gaps-on-base) the FY28 copy is written over without a question (`[false, false, false]` for [FY28 copy unchanged,
"Nothing was written", "Save yours over theirs"]); on c3 (VP2-gaps-on-c3) it asks. BRAD-28 then survives only as a folder
history copy (which pruning can later remove, ledger U17). Fix: G3 as a U29 scenario + entry `v200-adopt-u29-year-on-screen-only`
(proposed; matches once).

### S2 (should fix) -- "open the file's version" during a FOLDER save is refused by commit 1 but not driven

The U24 guard in `bootTakeFile` covers both modes; U24 (4) drives the board-file save only (the triage called folder mode
inconclusive). Wrong fix `vt-u24-takefile-guard-file-only` (`if(_saveBusy && !driveStoreOn())`): 0 failing in focused-U24 on c1
and c3, focused-U29 and v196 on c3. Probe G4 (U29 (6)'s steps, a folder save held at its write, the link clicked): on the
mutant (VO2-...takefile-guard-file-only, exit 1) and on the base, CAROL-F is opened mid-save and the save lands BRAD-2 in the
folder under it (`[clicked, 1, false, "📦 Opened the saved file’s version ..."]`, then `[CAROL-F, 650, BRAD-2, 720, ...]`); on c3
it is refused and the save lands clean. On c3+mutant the board is at least counted unsaved (commit 2). Fix: G4 as a U24
scenario + entry `v200-adopt-u24-takefile-guard-file-only` (proposed; matches once).

### S3 (should fix) -- the link clicked during a save on a board unsaved by the record only (DIRTY false) is not driven

U24 (1)/(2) click the link with DIRTY true; (3a)/(3b) create the DIRTY-false state but only let the answer arrive. Wrong fix
`vt-u24-link-guard-dirty-only` (`if(_saveBusy && DIRTY)`): 0 failing in focused-U24 on c1 and c3, focused-U29 and v196 on c3.
Probe G1 ((3a)'s state, the refused answer's own link clicked while the save is held): on the mutant (VO2-...link-guard-dirty-only)
SHARED is loaded mid-save (`["clicked", false, "Shared state loaded (published ...)"]`) and the landing leaves SHARED on screen,
BRAD-2 in the folder and kept aside -- the refusal U24 promises does not happen, though nothing is lost. Fix: G1 as a U24
scenario + entry `v200-adopt-u24-link-guard-dirty-only` (proposed; matches once).

### S4 (should fix) -- two claims in the drafts are not true as written

- U31 "What users may see": "after a batch import, a reopen, or a switch to another appropriation it imported, says the board
  has unsaved changes ... where it said Saved". By code the header reads this session only: `saveStateShow()` shows "Unsaved
  changes" when `unsavedNow()` = `!!DIRTY || sideUnsaved()` (c3 L25947-25957), and a reopen starts with DIRTY false -- ledger
  U15, open. Commit 3 changes this browser's record, which decides what the opening keeps aside; the U31 block checks the
  record and the kept copy, never the header or the status line, so nothing tested backs the sentence. Say what changes (the reopen keeps the import, or keeps it aside before a newer saved copy) and drop "says ...
  unsaved changes ... where it said Saved", or name U15.
- Ledger draft U29: "XSHn, XFSHn ..., XSHdL, XFSHdL, SHaC and BTC are covered" -- SHaC only in folder mode (M1). Same in the
  NEXT-VERSION U29 "Test" text ("the shared state file loading on its own (SHaC: ...)"). Correct once M1's scenario is in.

### S5 (should fix) -- "open the file's version" in the folder (BTC): the record is falsely clean again after a reopen

The triage's own contract for this route still fails on the final c3. The builder's reproduction re-run here on c3
(`R-c3-BT-fold-C1`, judged by `repro/check-l6.mjs`, `logs/R-chk-c3.log`): of every CONTRACT row on every route, ONE fails --
BT-fold-C1 `K3: reopened, not falsely clean` (got true). In the session the load is counted (K1, K2 pass); reopened from the
same file, the opening takes the file's own save as saved: `DIRTY false, _baseDirty false, record {file: CAROL-F, dirty: false,
folder: CAROL-F}`, header "Saved ...", while the folder still holds BRAD-1 (probe G5, `VP-g5-on-c3`: the status line does
offer the clash). No copy is lost -- 💾 Save still asks, which is all U29 (6)'s reopen check looks at -- and the base is worse
(no clash at all). But the drafts say BTC is covered (ledger U29: "... SHaC and BTC are covered"; NEXT-VERSION U29 Test:
"'open the file's version' in the folder (BTC)"), and FIX (2) asks that the record not be clean. Fix: either keep the record
unsaved through that reopen (a board change: the opening should not re-mark the file's own save clean while the folder's
record names another copy) with a U29 (6) check on `baseGet().dirty` after the reopen, or say plainly in U29's "Not covered"
and the ledger that a reopen makes BTC look saved again (Save still asks).

### Minor

- **N1. Nine new U24 checks pass on the base and are not labelled CONTROL.** The rule is that every new test fails on the base;
  every U24 SCENARIO does (each has failing checks), but these follow-on checks pass there too: "and the shared state file,
  answering that opening, is offered again" in (1W), (1Whist), (1Wread), (2); "then a refresh loads nothing and changes nothing"
  in (1Wread), (3a), (3b); and in (4) "the status line says it saved: the refusal and its link are gone with it" and "then
  reopened from the file: BRAD-2 on screen, saved ...". (U24 = 58 checks: 28 fail on the base, 17 carry "(a CONTROL)", 4 are
  the (5a)-(5c) controls, these 9 are neither.) U29 and U31 have none (every check that passes on the base is labelled a
  CONTROL or sits in a scenario named one). Fix: label them "(a CONTROL: as before)" or say so in the README/draft.
- **N2. Wrong fixes on false-word paths that survive** (no copy is lost; each makes a word untrue):
  `vt-u29-clash-vs-screen` ("after" decided against the screen's time) -- 0 failing in focused-U29 on c2;
  `vt-u29-count-before-apply` and `vt2-u29-answer-count-before-apply` (the load counted before `applyStore`'s verdict, so a
  refused load still says unsaved and moves the record) -- 0 failing in focused-U29 (the applyStore-refusal path is not driven);
  `vt-u31-other-before-checks` (other appropriations' records marked before the batch is decided) -- 0 failing in focused-U31 and
  in the W3 harness (111), because the W2/W3 fixtures' Full Fund record already says unsaved, so a refused batch cannot show
  the extra mark; and `vt2-u31-other-record-replaced` (another appropriation's record REPLACED by `{dirty:true}`, dropping its
  file and folder bases) -- 0 failing in focused-U31, since (4a)/(4b) check only `.dirty` and the switch's kept copy (by code
  the lost bases make that appropriation's next Save ask rather than write). Each needs one scenario if the lead wants them held.
- **N3.** (moved to S5.)
- **N7. Outside this track, measured.** In the same reproduction, folder mode, the OPENING that takes the board file's
  newer version on its own (BT-fold-C1 step `open2`: CAROL-1 on screen, KEPT-0 kept aside) records the screen clean against
  the folder's BRAD-1 (`falselyClean: true`) on the base and on c3 alike. It is not one of the three loads this track changes;
  for the ledger (U15-U20 family).
- **N4. One existing negative check means less after U29 (by code, not run).** `audit-import.mjs` base L3935, v1.95 item 47
  ("the next refresh raises no false clash") asserts `/after the copy you are working from/` is ABSENT. U29 gives the clash line
  a second wording (", and that is not the copy you are working from."), so a false clash where the folder's copy is older than
  the recorded one would now pass it. The check above it (L3933, the recorded base equals the copy written) still holds the
  main case. Not an edited expectation, but principle 6 asks for it to be listed: old meaning "no clash line"; new meaning "no
  clash line of the AFTER kind". A sibling check that `/Save yours over theirs/` is absent restores it. (L3618 is positive;
  L7656 is also held by its status-line equality.)
- **N5. Wall time.** The three blocks add roughly 2-6 minutes to a full audit-import run (focused runs here, under load 3-37:
  U24 58-179 s, U29 55-129 s, U31 53-102 s). For the lead's 600 s cap on the full suite, if it is near it.
- **N6.** The builder's U24 and U29 entries were run by the builder only on their own copies (c1, c2). Re-run here on the FINAL
  c3, the six U24 entries are all caught (table below); `-u24-link-guard` fails 20 there against 18 on c1 (on c3 the load is
  also counted, so the reopen checks fail instead of two refresh checks). The U29 entries were not re-run on c3: c3 differs from
  c2 only inside `importBoards`, which no U29 scenario reaches.

## What was checked (LENS B), and how

### 1. Every builder run, re-run and compared (`out/cmpall.txt`, by `bin/cmpall.py` and `bin/cmpnorm.py`; data only)

Each re-run used the same board blob and the same harness blob as the builder's run (its `IDS` line). Result: **every one
reproduces** -- same number of checks, same failing set, same observed values on every failing check (the seven pairs that
differ at all differ only in clock times: 0 differences left after normalising epoch-ms and m/d/yyyy h:mm times).

| builder run (theirs) | re-run here | checks | failing (theirs / mine) | same failing set, same values |
|---|---|---|---|---|
| F2-U24-on-base / -c1 / -c2, F5-U24-on-c3 | V-F-U24-on-base / -c1 / -c2 / -c3 | 58 | 28/28, 0/0, 0/0, 0/0 | yes (base: clock times only) |
| F2-U29-on-base / -c1 / -c2, F5-U29-on-c3 | V-F-U29-on-* | 33 | 24/24, 24/24, 0/0, 0/0 | yes |
| F4-U31-on-base / -c2 / -c3 | V-F-U31-on-* | 34 | 14/14, 14/14, 0/0 | yes |
| M2-c1-v200-adopt-u24-* (6) | V-M-c1-* | 58 | link-guard 18, answer-guard 8, file-guard 2, link-words-later 6, link-words-record 6, file-words-record 1 -- equal | yes |
| M2-c2-v200-adopt-u29-* (12) | V-M-c2-* | 33 | no-count 6, session-clean 12, record-clean 9, file-base-kept 5, folder-base-kept 11, link-uncounted 14, answer-uncounted 5, takefile-uncounted 3, same-save-kept 1, clash-after 4, promise-yours 1, promise-what-you-have 1 -- equal | yes |
| M4-c3-v200-adopt-u31-* (3) | V-M-c3-* | 34 | no-mark 11, memory-only 11, other-unmarked 3 -- equal | yes |
| MX-c3-* (5 existing entries) | V-MX-* (batch-adopt-unchecked as `-r2`) | 22 / 111 | sidecar-typed-replaced 1, sidecar-no-keep 2, adopt-shared-no-keep 1, batch-writes-each 22, batch-adopt-unchecked 22 -- equal | yes |
| P-{v189,w1,v196,w3,v200}-{base,c3} | V-P-* | 40, 53, 22, 111, 167 | 0 everywhere | yes |
| X-otherappn-on-base / on its c3 (d355db84, superseded) | VX-otherappn-on-base / -on-c3old | 8 | 2/2, 2/2 | yes; and VX-otherappn-on-c3 (final): 0 failing |
| the second builder's reproduction (23 routes + 4 X routes, `rec/L4/u24` probe and the U17 checker's x-probe, copied unchanged into `repro/`) | R-v1-* on the base, R-c3-* on c3, R-chk-v1 / R-chk-c3 | 353 rows | base: every triage CONTRACT failure reproduced (K1-K3 on SHc-*-W, SHc-*-C1clean, SHa-fold-W/-C1clean, BT-file-W, BT-fold-W/-C1); c3: one CONTRACT row fails -- BT-fold-C1 K3 (S5) | -- |
| other suites, base and final-c3 clones | VS-*-base, VS-*-c3 | -- | all pass on both; output identical (cmplogs.py) except check's two size lines | yes |

The builder's U24 and U29 entries were then also run on the FINAL c3 (the builder ran them on c1 and c2 only): see N6 and the
mutation table.

### 2. Every new expected value is a literal (`bin/wants.py` over each block as text, then read by eye)

All 33 + 30 + 17 `chk(...)` calls (U24, U29, U31; 58 + 33 + 34 checks with the loops) end in a hand-written literal:
`J([...])` of strings, numbers, booleans and null; `true`/`false`/numbers; or the word-for-word constants `SAID_LINK` and
`SAID_FILE` (string literals in the block) and `SAID_ARRIVED`, `AFTER`, `NOTIT` (regex literals, used only through `.test()` on
an observed line against a literal `true`/`false`). Board helpers (`fileTs`, `driveBaseOf`, `baseGet`, `w3Pub`) appear only
on the OBSERVED side (e.g. `onFile`, `onHead`, the (4a) fixture's record) -- none computes an expected value. One spread
`...(fold ? [true, true] : [1, true])` (U29 (3)/(4)) is a literal per mode.

### 3. Every new check fails on the base, or is a control (V-F-*-on-base)

| block | checks | fail on base | labelled CONTROL (or in a control scenario) | pass on base, not a control |
|---|---|---|---|---|
| U24 | 58 | 28 | 17 + 4 ((5a)-(5c)) | **9** (N1) |
| U29 | 33 | 24 | 7 + 2 ((8), named "a CONTROL") | 0 |
| U31 | 34 | 14 | 20 | 0 |

Every non-control check passes on its own copy and on c3; every check labelled a control passes on the base, c1, c2 and c3.
Every U24, U29 and U31 SCENARIO that is not a control fails on the base.

### 4. The suites against the base

Pure insertions (section "Diffs"). Changed existing expectation: none. Weakened in meaning: L3935 (N4, by code).

### 5. mcount, text only (`rec/bin/mcount.py`, `python3 -I`; `logs/mcount.txt` 10:33 AM ET and `logs/mcount-r2.txt` 12:04 PM ET)

base 1328/1328, c1 1334/1334, c2 1346/1346, c3 1349/1349 entries matching exactly once; none missing, multiple or unparsed;
each of the 21 `v200-adopt-*` ids once. With the four proposed entries inserted before the R3 line
(`proposals/mutate-c3-plus-proposed.mjs.txt` `b4e69594`): 1353/1353 on c3, each proposed id once.

### 6. Mutations: the builder's, on the final c3, and my own wrong fixes

The builder's six U24 entries on the FINAL c3 (mutants made by `rec/bin/mkmut.py` from c3's `mutate.mjs.txt`, `mut/c3u24/`),
each with the U24 block: **all caught** -- link-guard 20 (18 on c1), answer-guard 8, file-guard 2, link-words-later 6,
link-words-record 6, file-words-record 1 failing checks (V-M3-c3-*). The 12 U29 and 3 U31 entries: caught on c2 / c3 (re-runs
above).

My own wrong fixes -- 15 by the first attempt (`bin/ownmut.py`, `mut/own/`) and 5 by this one (`bin/ownmut2.py`, `mut/own2/`),
each a find matching its board once, written as text; each run with the block(s) of its area, BOARD set to the mutant
(`runner.mjs` asserts and records it). 11 caught, **9 survive** every block they were run with: M1 (`vt-u29-answer-file-kept`),
S1 (`year-on-screen-only`), S2 (`takefile-guard-file-only`), S3 (`link-guard-dirty-only`) and five on false-word paths (N2).

| mutant (wrong fix) | area | runs: copy harness -- failed/checks | by the builder's blocks and existing harnesses |
|---|---|---|---|
| `vt-u24-link-guard-after-keep`: the refusal is checked only after the work on screen has been kept aside: a refused link still writes the kept-aside slot | adoptShared | c1 focused-U24 -- 14/58 | CAUGHT |
| `vt-u24-link-guard-dirty-only`: the link is refused during a save only when this session has unsaved work: a board unsaved by this browser's record but not this session (reopened) loads the shared state file mid-save | adoptShared | c3 probe-gaps -- 2/14; c1 focused-U24 -- 0/58; c3 focused-U24 -- 0/58; c3 focused-U29 -- 0/33; c3 v196 -- 0/22 | **SURVIVES**; probe G1-G4: caught |
| `vt-u24-file-guard-early`: the save is checked before the question, not after its last wait: a save that starts while the question is open is not seen | bootTakeFile | c1 focused-U24 -- 1/58 | CAUGHT |
| `vt-u24-answer-guard-after-keep`: the answer is refused only after the work on screen has been kept aside: the kept-aside slot is written by a load that never happens | sharedArrived | c1 focused-U24 -- 6/58 | CAUGHT |
| `vt-u29-year-on-screen-only`: only the year on screen stops naming the folder's copy: another year the shared state file replaced stays recorded against the person's own folder copy, and saving that year writes over it unasked | loadedNotSaved | c3 probe-gaps -- 1/14; c2 focused-U29 -- 0/33 | **SURVIVES**; probe G1-G4: caught |
| `vt-u29-same-save-ge`: the same-save exemption also covers any NEWER shared state file: unsaved work is no longer kept aside before the shared state file replaces it | sharedKeepMine | c2 focused-U29 -- 0/33; c2 focused-U24 -- 1/58 | CAUGHT |
| `vt-u29-folder-memory-only`: the folder bases are moved in memory only, not in this browser's record: a reopen names the person's own folder copy again | loadedNotSaved | c2 focused-U29 -- 1/33 | CAUGHT |
| `vt-u29-clash-vs-screen`: "after" is decided against the time of the copy on screen instead of the copy recorded: an edit made after a colleague saved makes their later save read as not after | driveClashSay | c2 focused-U29 -- 0/33 | **SURVIVES** |
| `vt-u29-takefile-count-always`: the file's version is counted as a change in file mode too: the file's own save, opened, reads unsaved and Save asks for nothing new | bootTakeFile | c2 focused-U29 -- 1/33; c2 focused-U24 -- 0/58 | CAUGHT |
| `vt-u29-count-before-apply`: the load is counted before applyStore's verdict: a load applyStore refuses still marks the board unsaved and moves the record's folder bases | adoptShared | c2 focused-U29 -- 0/33 | **SURVIVES** |
| `vt-u29-answer-file-kept`: the shared state file's own load still names the board file's save: saving to the board file, the next Save writes the shared state file over the person's own copy in the file without asking, into no copy the board can reach | sharedArrived | c3 probe-gaps -- 2/14; c2 focused-U29 -- 0/33; c2 focused-U24 -- 0/58; c3 focused-U24 -- 0/58; c3 focused-U29 -- 0/33; c3 v196 -- 0/22; c3 v189 -- 0/40; c3 w1 -- 0/53 | **SURVIVES**; probe G1-G4: caught |
| `vt-u24-takefile-guard-file-only`: the file's version is refused during a save only when saving to the board file: working out of the shared folder, it is opened while a folder save is under way | bootTakeFile | c3 probe-gaps -- 2/14; c1 focused-U24 -- 0/58; c3 focused-U24 -- 0/58; c3 focused-U29 -- 0/33; c3 v196 -- 0/22 | **SURVIVES**; probe G1-G4: caught |
| `vt-u31-other-only-if-record`: only an appropriation that already has a record is marked: one with none is left with no record, so its next opening decides by the journal alone | importBoards | c3 focused-U31 -- 1/34 | CAUGHT |
| `vt-u31-mark-before-verdict`: the board on screen is marked unsaved as soon as the batch is written, before applyStore's verdict: a batch put back whole still leaves the record changed | importBoards | c3 focused-U31 -- 0/34; c3 w3 -- 6/111 | CAUGHT |
| `vt-u31-other-before-checks`: the other appropriations' records are marked before the batch is decided: a refused batch leaves them changed | importBoards | c3 focused-U31 -- 0/34; c3 w3 -- 0/111 | **SURVIVES** |
| `vt2-u29-answer-count-before-apply`: the shared state file's own load is counted before applyStore's verdict: a load applyStore refuses still marks the board unsaved and moves the record | sharedArrived | c3 focused-U29 -- 0/33 | **SURVIVES** |
| `vt2-u29-file-memory-kept`: only the record forgets the board file's save; this session still names it (LASTKNOWN): in the same session the next Save writes the loaded copy over the person's own file copy without asking | loadedNotSaved | c3 focused-U29 -- 5/33 | CAUGHT |
| `vt2-u29-folder-base-zero`: the folder bases are cleared (0) instead of naming the loaded copy's own save: the clash line then says the folder's copy is "after" the copy on screen whichever is newer | loadedNotSaved | c3 focused-U29 -- 6/33 | CAUGHT |
| `vt2-u31-other-record-replaced`: another appropriation's record is replaced by {dirty:true} instead of marked: what it recorded (the file's save, the folder bases) is lost | importBoards | c3 focused-U31 -- 0/34 | **SURVIVES** |
| `vt2-u31-mark-folder-only`: the board on screen is marked unsaved only when working out of the shared folder: saving to the board file, a reopen takes the import as saved | importBoards | c3 focused-U31 -- 4/34 | CAUGHT |

Probe G1-G4 (`probe/block-gaps.mjs.txt`, harness `harness/c3/probe-gaps.mjs` `066d872c`): 14 checks; c3 0 failing (VP2-gaps-on-c3),
base 8 failing (VP2-gaps-on-base); each of the four surviving mutants fails exactly its own route (VO2-*). Probe G5
(`probe/block-g5.mjs.txt`, `0bb7e3db`): S5/N3. Probe G2b (`probe/block-g2b.mjs.txt`, `2402502f` as built): M1. The first probe
build (10:44 ET) put the block before the suite's head and was discarded (`logs/superseded-probe1/`).

## Decisions, with reasons

- **M1 is a must-fix, not a should-fix.** The can't-fail is DATA LOSS. Commit 2 fixes this route (one argument on one line), the
  drafts say it is fixed and covered, and a one-word slip back makes the next Save write over the person's only copy with no
  question -- measured (G2b: `asked 0`, BRAD-1 in nothing the board can reach) -- while every new block and every neighbouring
  existing harness stays green. The fix is small and measured (scenario (9) + one entry). Its reach is the same as XFSHn's,
  which the builder treats as P1 and tests.
- **S1-S3 are should-fixes**: the same kind of gap, but on the surviving mutant the overwritten copy is still in the folder's
  history (S1, S2) or the save's copy is kept aside (S3). S4 is words in the drafts; S5 is a residual false "saved" at a reopen
  with Save still asking.
- **Reuse.** Runs of the first attempt with an exit record were reused: the board, suite and harness blobs are unchanged
  (checked at 11:57 AM ET and in each log's `IDS` line). The four without an exit record were re-run.
- **Lane C split (12:10 PM ET).** The single lane `resume-C.sh` (my own driver, PID 27804, recorded) was stopped in its wait loop
  before it had started any run, and its work split into `resume-C1.sh` (started in the slot lane A had freed) and
  `resume-C2.sh` (after lane B), so two node processes ran at a time instead of one. Recorded in `logs/notes.txt`.
- **G2b's "overwrite anyway" leg.** Its "BRAD-1 is still somewhere" check encodes a wrong expectation for c3 (the person is
  asked and chooses); it is read as an observation only. The Cancel leg and `asked` carry the finding.
- **U29 entries not re-run on c3** (N6): c3 differs from c2 only inside `importBoards`, which no U29 scenario reaches.
- **BTC reopen as S5** rather than minor: it is the only triage CONTRACT row still failing on the final c3, and the drafts claim
  the route covered.

## PIDs

`pids.txt`: every timeout wrapper and its child (node, npm or python3) with its label and command, and each lane driver (bash).
The resume is marked `--- RESUME 2026-10-13 11:59:31 EDT ---`. No process was killed by name or pattern; the only kill was of my
own recorded lane-C driver, PID 27804, while it was sleeping in its wait loop. The `Monitor` watches and the waiting loops that
only read `logs/runs.txt` (tasks run through the tool, never a node process) are not in `pids.txt`. At the end of this review
no process of mine is running (checked by PID).

## Locks

`AUDIT_IMPORT_RUNNING` was absent before every run of both attempts; `run.sh` logs a wait or a skip when it is present, and
`logs/runs.txt` has none. One `node --check` (syntax only, under 1 s) in the first attempt was run outside `run.sh`
(`logs/notes.txt`, 10:41:55 AM ET).

## What I did NOT do

- Nothing committed, staged or pushed; nothing edited in `/home/user/orbit-board` or `/home/user/orbit-ui`; the builder's files
  untouched. The scratch clones `git/base`, `git/c3` have no commits.
- `mutate.mjs` never imported or run (text only, `mkmut.py` / `mcount.py`). No `playwright install`, no Chromium, no verify:grid.
- The full `audit-import.mjs` and `audit-board.mjs` not run (the lead's); full-suite sensitivity of the mutants not measured.
  "Survives" above means: survives every block and harness named beside it, and, by search, no other suite code calls the
  function.
- The 12 U29 entries not re-run on the final c3 (N6). The U31 entries were run on c3 only (their own copy).
- No scenario text written for S1-S3 beyond the probe's (G1, G3, G4 in `probe/block-gaps.mjs.txt` are in the block's helpers
  and voice, but not inserted into a block and measured as part of one); only M1's scenario (9) was inserted and measured.
- S5's board-side fix not drafted or measured. N4 (L3935) and the U31 header claim (S4) are by code; N7 by measurement only.
- No NEXT-VERSION or ledger text drafted (not this lens's task); the builder's drafts were read and S4/S5 name what to correct.

## Every run (logs/runs.txt; start times ET, 13 Oct 2026; checks = SUITE_CHECKS records, failed in brackets)

Labels: `V-F-*` focused blocks; `V-M-*`/`V-M3-*` the builder's entries (on their copy / on the final c3); `V-MX-*` existing
entries; `V-P-*` preservation harnesses; `VO-*`/`VO2-*`/`VO3-*` my own mutants (block / probe G1-G4 / second set); `VP-*`,
`VP2-*`, `VG2b-*`, `VQ-*` probes and the proposed scenario; `VX-*` the builder's other-appropriation probe; `R-*`/`RX-*` the
builder's reproduction (RX-c3-* exit 1 in ~3 s: the x-probe refuses a board blob it does not know -- not a defect of c3; the X
routes are driven on c3 by the U29 block); `VS-*` other suites. Superseded: the first probe build's six runs at 10:44 ET
(`VP-gaps-*`, `VO-*-probe-gaps`, logs in `logs/superseded-probe1/`), and `V-MX-batch-adopt-unchecked` (exit 137 = killed by the
memory-cgroup OOM killer at load 30-37, incomplete; re-run as `-r2`). Stopped at 11:45 AM ET with no exit record, re-run:
`V-MX-batch-adopt-unchecked-2`, `VO-vt-u31-mark-before-verdict--c3-w3`, `VS-audit-recon-base` (stopped log kept as
`.STOPPED-1145.log`).

| label | start (ET) | exit | wall s | checks (failed) | log |
|---|---|---|---|---|---|
| V-F-U31-on-c3 | 2026-10-13 10:34:52 | 0 | 53.4 | 34 (0) | logs/V-F-U31-on-c3.log |
| V-F-U29-on-c2 | 2026-10-13 10:34:52 | 0 | 58.5 | 33 (0) | logs/V-F-U29-on-c2.log |
| V-F-U24-on-c1 | 2026-10-13 10:34:52 | 0 | 78.9 | 58 (0) | logs/V-F-U24-on-c1.log |
| V-F-U31-on-base | 2026-10-13 10:35:45 | 1 | 73.4 | 34 (14) | logs/V-F-U31-on-base.log |
| V-F-U29-on-base | 2026-10-13 10:35:50 | 1 | 84.5 | 33 (24) | logs/V-F-U29-on-base.log |
| V-F-U24-on-base | 2026-10-13 10:36:11 | 1 | 125.6 | 58 (28) | logs/V-F-U24-on-base.log |
| V-F-U31-on-c2 | 2026-10-13 10:36:59 | 1 | 91.1 | 34 (14) | logs/V-F-U31-on-c2.log |
| V-F-U29-on-c1 | 2026-10-13 10:37:15 | 1 | 111.0 | 33 (24) | logs/V-F-U29-on-c1.log |
| V-M-c3-v200-adopt-u31-no-mark-U31 | 2026-10-13 10:38:30 | 1 | 101.8 | 34 (11) | logs/V-M-c3-v200-adopt-u31-no-mark-U31.log |
| V-F-U24-on-c2 | 2026-10-13 10:38:16 | 0 | 142.0 | 58 (0) | logs/V-F-U24-on-c2.log |
| V-F-U29-on-c3 | 2026-10-13 10:39:06 | 0 | 128.6 | 33 (0) | logs/V-F-U29-on-c3.log |
| V-M-c3-v200-adopt-u31-memory-only-U31 | 2026-10-13 10:40:13 | 1 | 121.9 | 34 (11) | logs/V-M-c3-v200-adopt-u31-memory-only-U31.log |
| V-M-c2-v200-adopt-u29-no-count-U29 | 2026-10-13 10:41:15 | 1 | 134.5 | 33 (6) | logs/V-M-c2-v200-adopt-u29-no-count-U29.log |
| V-F-U24-on-c3 | 2026-10-13 10:40:38 | 0 | 178.9 | 58 (0) | logs/V-F-U24-on-c3.log |
| V-M-c3-v200-adopt-u31-other-unmarked-U31 | 2026-10-13 10:42:16 | 1 | 104.4 | 34 (3) | logs/V-M-c3-v200-adopt-u31-other-unmarked-U31.log |
| VP-gaps-on-c3 | 2026-10-13 10:44:08 | 1 | 3.2 |  | logs/VP-gaps-on-c3.log |
| VP-gaps-on-base | 2026-10-13 10:44:12 | 1 | 3.6 |  | logs/VP-gaps-on-base.log |
| VO-vt-u24-link-guard-dirty-only--c3-probe-gaps | 2026-10-13 10:44:15 | 1 | 4.5 |  | logs/VO-vt-u24-link-guard-dirty-only--c3-probe-gaps.log |
| VO-vt-u29-answer-file-kept--c3-probe-gaps | 2026-10-13 10:44:20 | 1 | 3.9 |  | logs/VO-vt-u29-answer-file-kept--c3-probe-gaps.log |
| VO-vt-u29-year-on-screen-only--c3-probe-gaps | 2026-10-13 10:44:24 | 1 | 2.8 |  | logs/VO-vt-u29-year-on-screen-only--c3-probe-gaps.log |
| VO-vt-u24-takefile-guard-file-only--c3-probe-gaps | 2026-10-13 10:44:27 | 1 | 3.1 |  | logs/VO-vt-u24-takefile-guard-file-only--c3-probe-gaps.log |
| V-M-c2-v200-adopt-u29-session-clean-U29 | 2026-10-13 10:43:30 | 1 | 111.6 | 33 (12) | logs/V-M-c2-v200-adopt-u29-session-clean-U29.log |
| VP2-gaps-on-c3 | 2026-10-13 10:44:51 | 0 | 66.0 | 14 (0) | logs/VP2-gaps-on-c3.log |
| V-M-c1-v200-adopt-u24-link-guard-U24 | 2026-10-13 10:43:38 | 1 | 144.4 | 58 (18) | logs/V-M-c1-v200-adopt-u24-link-guard-U24.log |
| VP2-gaps-on-base | 2026-10-13 10:45:57 | 1 | 66.3 | 14 (8) | logs/VP2-gaps-on-base.log |
| V-M-c2-v200-adopt-u29-record-clean-U29 | 2026-10-13 10:45:23 | 1 | 102.4 | 33 (9) | logs/V-M-c2-v200-adopt-u29-record-clean-U29.log |
| VO2-vt-u24-link-guard-dirty-only--c3-probe-gaps | 2026-10-13 10:47:04 | 1 | 61.9 | 14 (2) | logs/VO2-vt-u24-link-guard-dirty-only--c3-probe-gaps.log |
| V-M-c1-v200-adopt-u24-answer-guard-U24 | 2026-10-13 10:46:03 | 1 | 123.1 | 58 (8) | logs/V-M-c1-v200-adopt-u24-answer-guard-U24.log |
| V-M-c2-v200-adopt-u29-file-base-kept-U29 | 2026-10-13 10:47:06 | 1 | 90.3 | 33 (5) | logs/V-M-c2-v200-adopt-u29-file-base-kept-U29.log |
| VO2-vt-u29-answer-file-kept--c3-probe-gaps | 2026-10-13 10:48:05 | 1 | 45.7 | 14 (2) | logs/VO2-vt-u29-answer-file-kept--c3-probe-gaps.log |
| VO2-vt-u29-year-on-screen-only--c3-probe-gaps | 2026-10-13 10:48:51 | 1 | 44.0 | 14 (1) | logs/VO2-vt-u29-year-on-screen-only--c3-probe-gaps.log |
| V-M-c1-v200-adopt-u24-file-guard-U24 | 2026-10-13 10:48:07 | 1 | 92.1 | 58 (2) | logs/V-M-c1-v200-adopt-u24-file-guard-U24.log |
| V-M-c2-v200-adopt-u29-folder-base-kept-U29 | 2026-10-13 10:48:36 | 1 | 70.3 | 33 (11) | logs/V-M-c2-v200-adopt-u29-folder-base-kept-U29.log |
| VO2-vt-u24-takefile-guard-file-only--c3-probe-gaps | 2026-10-13 10:49:35 | 1 | 51.3 | 14 (2) | logs/VO2-vt-u24-takefile-guard-file-only--c3-probe-gaps.log |
| V-M-c2-v200-adopt-u29-link-uncounted-U29 | 2026-10-13 10:49:47 | 1 | 79.3 | 33 (14) | logs/V-M-c2-v200-adopt-u29-link-uncounted-U29.log |
| V-M-c1-v200-adopt-u24-link-words-later-U24 | 2026-10-13 10:49:39 | 1 | 102.9 | 58 (6) | logs/V-M-c1-v200-adopt-u24-link-words-later-U24.log |
| VO-vt-u29-year-on-screen-only--c2-focused-U29 | 2026-10-13 10:50:46 | 0 | 76.4 | 33 (0) | logs/VO-vt-u29-year-on-screen-only--c2-focused-U29.log |
| V-M-c2-v200-adopt-u29-answer-uncounted-U29 | 2026-10-13 10:51:08 | 1 | 81.2 | 33 (5) | logs/V-M-c2-v200-adopt-u29-answer-uncounted-U29.log |
| R-v1-SHc-fold-W | 2026-10-13 10:52:16 | 0 | 25.0 |  | logs/R-v1-SHc-fold-W.log |
| R-v1-SHc-fold-C1 | 2026-10-13 10:52:41 | 0 | 23.3 |  | logs/R-v1-SHc-fold-C1.log |
| V-M-c1-v200-adopt-u24-link-words-record-U24 | 2026-10-13 10:51:23 | 1 | 106.6 | 58 (6) | logs/V-M-c1-v200-adopt-u24-link-words-record-U24.log |
| R-v1-SHc-fold-C2 | 2026-10-13 10:53:04 | 0 | 20.1 |  | logs/R-v1-SHc-fold-C2.log |
| VO-vt-u29-same-save-ge--c2-focused-U29 | 2026-10-13 10:52:02 | 0 | 85.6 | 33 (0) | logs/VO-vt-u29-same-save-ge--c2-focused-U29.log |
| R-v1-SHc-file-W | 2026-10-13 10:53:24 | 0 | 23.8 |  | logs/R-v1-SHc-file-W.log |
| V-M-c2-v200-adopt-u29-takefile-uncounted-U29 | 2026-10-13 10:52:29 | 1 | 82.6 | 33 (3) | logs/V-M-c2-v200-adopt-u29-takefile-uncounted-U29.log |
| R-v1-SHc-file-C1 | 2026-10-13 10:53:48 | 0 | 24.1 |  | logs/R-v1-SHc-file-C1.log |
| R-v1-SHc-file-C2 | 2026-10-13 10:54:12 | 0 | 26.3 |  | logs/R-v1-SHc-file-C2.log |
| VO-vt-u29-folder-memory-only--c2-focused-U29 | 2026-10-13 10:53:28 | 1 | 87.1 | 33 (1) | logs/VO-vt-u29-folder-memory-only--c2-focused-U29.log |
| R-v1-SHc-fold-C1clean | 2026-10-13 10:54:39 | 0 | 23.9 |  | logs/R-v1-SHc-fold-C1clean.log |
| V-M-c1-v200-adopt-u24-file-words-record-U24 | 2026-10-13 10:53:10 | 1 | 112.6 | 58 (1) | logs/V-M-c1-v200-adopt-u24-file-words-record-U24.log |
| V-M-c2-v200-adopt-u29-same-save-kept-U29 | 2026-10-13 10:53:53 | 1 | 87.6 | 33 (1) | logs/V-M-c2-v200-adopt-u29-same-save-kept-U29.log |
| R-v1-SHc-file-C1clean | 2026-10-13 10:55:03 | 0 | 21.1 |  | logs/R-v1-SHc-file-C1clean.log |
| R-v1-SHa-fold-W | 2026-10-13 10:55:24 | 0 | 31.8 |  | logs/R-v1-SHa-fold-W.log |
| R-v1-SHa-fold-C1 | 2026-10-13 10:55:56 | 0 | 29.8 |  | logs/R-v1-SHa-fold-C1.log |
| VO-vt-u29-clash-vs-screen--c2-focused-U29 | 2026-10-13 10:54:55 | 0 | 98.0 | 33 (0) | logs/VO-vt-u29-clash-vs-screen--c2-focused-U29.log |
| R-v1-SHa-fold-C2 | 2026-10-13 10:56:26 | 0 | 33.1 |  | logs/R-v1-SHa-fold-C2.log |
| V-M-c2-v200-adopt-u29-clash-after-U29 | 2026-10-13 10:55:21 | 1 | 99.8 | 33 (4) | logs/V-M-c2-v200-adopt-u29-clash-after-U29.log |
| VO-vt-u24-link-guard-after-keep--c1-focused-U24 | 2026-10-13 10:55:19 | 1 | 127.3 | 58 (14) | logs/VO-vt-u24-link-guard-after-keep--c1-focused-U24.log |
| R-v1-SHa-fold-C1clean | 2026-10-13 10:56:59 | 0 | 29.7 |  | logs/R-v1-SHa-fold-C1clean.log |
| R-v1-SHa-file-Wread | 2026-10-13 10:57:29 | 0 | 27.6 |  | logs/R-v1-SHa-file-Wread.log |
| VO-vt-u29-takefile-count-always--c2-focused-U29 | 2026-10-13 10:56:33 | 1 | 97.0 | 33 (1) | logs/VO-vt-u29-takefile-count-always--c2-focused-U29.log |
| R-v1-BT-file-W | 2026-10-13 10:57:56 | 0 | 28.4 |  | logs/R-v1-BT-file-W.log |
| V-M-c2-v200-adopt-u29-promise-yours-U29 | 2026-10-13 10:57:01 | 1 | 96.3 | 33 (1) | logs/V-M-c2-v200-adopt-u29-promise-yours-U29.log |
| R-v1-BT-file-C1 | 2026-10-13 10:58:25 | 0 | 30.8 |  | logs/R-v1-BT-file-C1.log |
| VO-vt-u24-link-guard-dirty-only--c1-focused-U24 | 2026-10-13 10:57:27 | 0 | 114.6 | 58 (0) | logs/VO-vt-u24-link-guard-dirty-only--c1-focused-U24.log |
| R-v1-BT-file-C2 | 2026-10-13 10:58:55 | 0 | 30.1 |  | logs/R-v1-BT-file-C2.log |
| VO-vt-u29-count-before-apply--c2-focused-U29 | 2026-10-13 10:58:10 | 0 | 86.9 | 33 (0) | logs/VO-vt-u29-count-before-apply--c2-focused-U29.log |
| R-v1-BT-fold-W | 2026-10-13 10:59:26 | 0 | 30.1 |  | logs/R-v1-BT-fold-W.log |
| V-M-c2-v200-adopt-u29-promise-what-you-have-U29 | 2026-10-13 10:58:39 | 1 | 86.4 | 33 (1) | logs/V-M-c2-v200-adopt-u29-promise-what-you-have-U29.log |
| R-v1-BT-fold-C1 | 2026-10-13 10:59:56 | 0 | 31.0 |  | logs/R-v1-BT-fold-C1.log |
| R-v1-IB-fold-C1 | 2026-10-13 11:00:27 | 0 | 24.5 |  | logs/R-v1-IB-fold-C1.log |
| VO-vt-u29-answer-file-kept--c2-focused-U29 | 2026-10-13 10:59:37 | 0 | 88.5 | 33 (0) | logs/VO-vt-u29-answer-file-kept--c2-focused-U29.log |
| VO-vt-u24-file-guard-early--c1-focused-U24 | 2026-10-13 10:59:21 | 1 | 110.8 | 58 (1) | logs/VO-vt-u24-file-guard-early--c1-focused-U24.log |
| R-v1-IB-fold-C1clean | 2026-10-13 11:00:51 | 0 | 23.7 |  | logs/R-v1-IB-fold-C1clean.log |
| V-P-v189-base | 2026-10-13 11:00:18 | 0 | 60.0 | 40 (0) | logs/V-P-v189-base.log |
| R-v1-IB-file-C1clean | 2026-10-13 11:01:15 | 0 | 19.4 |  | logs/R-v1-IB-file-C1clean.log |
| R-v1-IB-fold-Wclean | 2026-10-13 11:01:35 | 0 | 23.9 |  | logs/R-v1-IB-fold-Wclean.log |
| V-P-v189-c3 | 2026-10-13 11:01:18 | 0 | 59.5 | 40 (0) | logs/V-P-v189-c3.log |
| R-v1-IB-file-C1 | 2026-10-13 11:01:59 | 0 | 24.7 |  | logs/R-v1-IB-file-C1.log |
| RX-v1-XSHn-save | 2026-10-13 11:02:23 | 0 | 22.3 |  | logs/RX-v1-XSHn-save.log |
| VO-vt-u29-same-save-ge--c2-focused-U24 | 2026-10-13 11:01:06 | 1 | 110.7 | 58 (1) | logs/VO-vt-u29-same-save-ge--c2-focused-U24.log |
| VO-vt-u24-answer-guard-after-keep--c1-focused-U24 | 2026-10-13 11:01:12 | 1 | 106.4 | 58 (6) | logs/VO-vt-u24-answer-guard-after-keep--c1-focused-U24.log |
| RX-v1-XFSHn-save | 2026-10-13 11:02:46 | 0 | 25.4 |  | logs/RX-v1-XFSHn-save.log |
| RX-v1-XSHdL-save | 2026-10-13 11:03:11 | 0 | 21.0 |  | logs/RX-v1-XSHdL-save.log |
| RX-v1-XFSHdL-save | 2026-10-13 11:03:32 | 0 | 21.5 |  | logs/RX-v1-XFSHdL-save.log |
| R-chk-v1 | 2026-10-13 11:03:54 | 0 | 0.4 |  | logs/R-chk-v1.log |
| V-P-w1-base | 2026-10-13 11:02:17 | 0 | 115.4 | 53 (0) | logs/V-P-w1-base.log |
| R-c3-SHc-fold-W | 2026-10-13 11:03:54 | 0 | 24.5 |  | logs/R-c3-SHc-fold-W.log |
| R-c3-SHc-fold-C1 | 2026-10-13 11:04:19 | 0 | 27.2 |  | logs/R-c3-SHc-fold-C1.log |
| VO-vt-u24-takefile-guard-file-only--c1-focused-U24 | 2026-10-13 11:02:59 | 0 | 114.6 | 58 (0) | logs/VO-vt-u24-takefile-guard-file-only--c1-focused-U24.log |
| VO-vt-u29-takefile-count-always--c2-focused-U24 | 2026-10-13 11:02:57 | 0 | 117.8 | 58 (0) | logs/VO-vt-u29-takefile-count-always--c2-focused-U24.log |
| R-c3-SHc-fold-C2 | 2026-10-13 11:04:46 | 0 | 25.0 |  | logs/R-c3-SHc-fold-C2.log |
| VX-otherappn-on-base | 2026-10-13 11:04:53 | 1 | 32.5 | 8 (2) | logs/VX-otherappn-on-base.log |
| R-c3-SHc-file-W | 2026-10-13 11:05:11 | 0 | 24.6 |  | logs/R-c3-SHc-file-W.log |
| R-c3-SHc-file-C1 | 2026-10-13 11:05:36 | 0 | 19.1 |  | logs/R-c3-SHc-file-C1.log |
| VX-otherappn-on-c3old | 2026-10-13 11:05:26 | 1 | 29.1 | 8 (2) | logs/VX-otherappn-on-c3old.log |
| V-P-w1-c3 | 2026-10-13 11:04:13 | 0 | 112.8 | 53 (0) | logs/V-P-w1-c3.log |
| R-c3-SHc-file-C2 | 2026-10-13 11:05:55 | 0 | 24.1 |  | logs/R-c3-SHc-file-C2.log |
| VX-otherappn-on-c3 | 2026-10-13 11:05:55 | 0 | 36.7 | 8 (0) | logs/VX-otherappn-on-c3.log |
| R-c3-SHc-fold-C1clean | 2026-10-13 11:06:19 | 0 | 29.6 |  | logs/R-c3-SHc-fold-C1clean.log |
| VO-vt-u29-answer-file-kept--c2-focused-U24 | 2026-10-13 11:04:55 | 0 | 119.1 | 58 (0) | logs/VO-vt-u29-answer-file-kept--c2-focused-U24.log |
| R-c3-SHc-file-C1clean | 2026-10-13 11:06:49 | 0 | 26.4 |  | logs/R-c3-SHc-file-C1clean.log |
| R-c3-SHa-fold-W | 2026-10-13 11:07:15 | 0 | 36.9 |  | logs/R-c3-SHa-fold-W.log |
| V-P-v196-base | 2026-10-13 11:06:06 | 0 | 129.3 | 22 (0) | logs/V-P-v196-base.log |
| R-c3-SHa-fold-C1 | 2026-10-13 11:07:52 | 0 | 36.6 |  | logs/R-c3-SHa-fold-C1.log |
| V-MX-sidecar-typed-replaced | 2026-10-13 11:06:33 | 1 | 129.0 | 22 (1) | logs/V-MX-sidecar-typed-replaced.log |
| VO-vt-u31-other-only-if-record--c3-focused-U31 | 2026-10-13 11:06:54 | 1 | 110.1 | 34 (1) | logs/VO-vt-u31-other-only-if-record--c3-focused-U31.log |
| R-c3-SHa-fold-C2 | 2026-10-13 11:08:29 | 0 | 35.8 |  | logs/R-c3-SHa-fold-C2.log |
| R-c3-SHa-fold-C1clean | 2026-10-13 11:09:05 | 0 | 36.1 |  | logs/R-c3-SHa-fold-C1clean.log |
| R-c3-SHa-file-Wread | 2026-10-13 11:09:41 | 0 | 35.6 |  | logs/R-c3-SHa-file-Wread.log |
| V-P-v196-c3 | 2026-10-13 11:08:15 | 0 | 126.1 | 22 (0) | logs/V-P-v196-c3.log |
| VO-vt-u31-mark-before-verdict--c3-focused-U31 | 2026-10-13 11:08:44 | 0 | 107.1 | 34 (0) | logs/VO-vt-u31-mark-before-verdict--c3-focused-U31.log |
| V-MX-sidecar-no-keep | 2026-10-13 11:08:43 | 1 | 122.8 | 22 (2) | logs/V-MX-sidecar-no-keep.log |
| R-c3-BT-file-W | 2026-10-13 11:10:17 | 0 | 35.9 |  | logs/R-c3-BT-file-W.log |
| R-c3-BT-file-C1 | 2026-10-13 11:10:53 | 0 | 36.9 |  | logs/R-c3-BT-file-C1.log |
| R-c3-BT-file-C2 | 2026-10-13 11:11:30 | 0 | 35.4 |  | logs/R-c3-BT-file-C2.log |
| VO-vt-u31-other-before-checks--c3-focused-U31 | 2026-10-13 11:10:31 | 0 | 95.3 | 34 (0) | logs/VO-vt-u31-other-before-checks--c3-focused-U31.log |
| V-MX-adopt-shared-no-keep | 2026-10-13 11:10:46 | 1 | 110.6 | 22 (1) | logs/V-MX-adopt-shared-no-keep.log |
| R-c3-BT-fold-W | 2026-10-13 11:12:05 | 0 | 34.1 |  | logs/R-c3-BT-fold-W.log |
| R-c3-BT-fold-C1 | 2026-10-13 11:12:39 | 0 | 32.2 |  | logs/R-c3-BT-fold-C1.log |
| R-c3-IB-fold-C1 | 2026-10-13 11:13:12 | 0 | 30.4 |  | logs/R-c3-IB-fold-C1.log |
| R-c3-IB-fold-C1clean | 2026-10-13 11:13:42 | 0 | 28.3 |  | logs/R-c3-IB-fold-C1clean.log |
| R-c3-IB-file-C1clean | 2026-10-13 11:14:11 | 0 | 28.1 |  | logs/R-c3-IB-file-C1clean.log |
| R-c3-IB-fold-Wclean | 2026-10-13 11:14:39 | 0 | 33.7 |  | logs/R-c3-IB-fold-Wclean.log |
| R-c3-IB-file-C1 | 2026-10-13 11:15:13 | 0 | 28.2 |  | logs/R-c3-IB-file-C1.log |
| RX-c3-XSHn-save | 2026-10-13 11:15:41 | 1 | 3.6 |  | logs/RX-c3-XSHn-save.log |
| RX-c3-XFSHn-save | 2026-10-13 11:15:44 | 1 | 3.2 |  | logs/RX-c3-XFSHn-save.log |
| RX-c3-XSHdL-save | 2026-10-13 11:15:48 | 1 | 3.1 |  | logs/RX-c3-XSHdL-save.log |
| RX-c3-XFSHdL-save | 2026-10-13 11:15:51 | 1 | 3.7 |  | logs/RX-c3-XFSHdL-save.log |
| R-chk-c3 | 2026-10-13 11:15:55 | 0 | 0.4 |  | logs/R-chk-c3.log |
| V-P-v200-base | 2026-10-13 11:10:21 | 0 | 366.3 | 167 (0) | logs/V-P-v200-base.log |
| V-MX-batch-writes-each | 2026-10-13 11:12:38 | 1 | 309.2 | 111 (22) | logs/V-MX-batch-writes-each.log |
| VP-g5-on-c3 | 2026-10-13 11:20:01 | 1 | 71.1 | 4 (1) | logs/VP-g5-on-c3.log |
| VO-vt-u29-answer-file-kept--c3-focused-U24 | 2026-10-13 11:18:39 | 0 | 182.0 | 58 (0) | logs/VO-vt-u29-answer-file-kept--c3-focused-U24.log |
| VP-g5-on-base | 2026-10-13 11:21:12 | 1 | 40.8 | 4 (2) | logs/VP-g5-on-base.log |
| V-MX-batch-adopt-unchecked | 2026-10-13 11:17:48 | 137 | 282.5 | 96 (22) | logs/V-MX-batch-adopt-unchecked.log |
| VO-vt-u29-answer-file-kept--c3-focused-U29 | 2026-10-13 11:21:41 | 0 | 107.2 | 33 (0) | logs/VO-vt-u29-answer-file-kept--c3-focused-U29.log |
| V-P-v200-c3 | 2026-10-13 11:16:27 | 0 | 430.9 | 167 (0) | logs/V-P-v200-c3.log |
| VO-vt-u29-answer-file-kept--c3-v196 | 2026-10-13 11:23:28 | 0 | 99.1 | 22 (0) | logs/VO-vt-u29-answer-file-kept--c3-v196.log |
| VO-vt-u29-answer-file-kept--c3-v189 | 2026-10-13 11:25:07 | 0 | 69.4 | 40 (0) | logs/VO-vt-u29-answer-file-kept--c3-v189.log |
| VO-vt-u29-answer-file-kept--c3-w1 | 2026-10-13 11:26:17 | 0 | 124.5 | 53 (0) | logs/VO-vt-u29-answer-file-kept--c3-w1.log |
| VQ-U29plus9-on-c3 | 2026-10-13 11:28:34 | 0 | 97.6 | 38 (0) | logs/VQ-U29plus9-on-c3.log |
| V-P-w3-base | 2026-10-13 11:23:38 | 0 | 394.4 | 111 (0) | logs/V-P-w3-base.log |
| VO-vt-u24-link-guard-dirty-only--c3-focused-U24 | 2026-10-13 11:28:21 | 0 | 114.8 | 58 (0) | logs/VO-vt-u24-link-guard-dirty-only--c3-focused-U24.log |
| VO-vt-u24-link-guard-dirty-only--c3-focused-U29 | 2026-10-13 11:30:16 | 0 | 97.0 | 33 (0) | logs/VO-vt-u24-link-guard-dirty-only--c3-focused-U29.log |
| VQ-U29plus9-on-base | 2026-10-13 11:30:11 | 1 | 107.9 | 38 (28) | logs/VQ-U29plus9-on-base.log |
| VO-vt-u24-link-guard-dirty-only--c3-v196 | 2026-10-13 11:31:53 | 0 | 109.7 | 22 (0) | logs/VO-vt-u24-link-guard-dirty-only--c3-v196.log |
| VQ-U29plus9-on-c2 | 2026-10-13 11:31:59 | 0 | 109.4 | 38 (0) | logs/VQ-U29plus9-on-c2.log |
| VQ-U29plus9-on-answer-file-kept | 2026-10-13 11:33:49 | 1 | 126.0 | 38 (3) | logs/VQ-U29plus9-on-answer-file-kept.log |
| VO-vt-u24-takefile-guard-file-only--c3-focused-U24 | 2026-10-13 11:33:43 | 0 | 154.6 | 58 (0) | logs/VO-vt-u24-takefile-guard-file-only--c3-focused-U24.log |
| VS-boot-same-base | 2026-10-13 11:35:55 | 0 | 54.5 |  | logs/VS-boot-same-base.log |
| VS-audit-base | 2026-10-13 11:36:50 | 0 | 56.5 |  | logs/VS-audit-base.log |
| VS-audit-ppt-base | 2026-10-13 11:37:46 | 0 | 32.8 |  | logs/VS-audit-ppt-base.log |
| V-P-w3-c3 | 2026-10-13 11:30:13 | 0 | 499.8 | 111 (0) | logs/V-P-w3-c3.log |
| VO-vt-u24-takefile-guard-file-only--c3-focused-U29 | 2026-10-13 11:36:18 | 0 | 150.9 | 33 (0) | logs/VO-vt-u24-takefile-guard-file-only--c3-focused-U29.log |
| VO-vt-u24-takefile-guard-file-only--c3-v196 | 2026-10-13 11:38:49 | 0 | 175.7 | 22 (0) | logs/VO-vt-u24-takefile-guard-file-only--c3-v196.log |
| VS-audit-other-base | 2026-10-13 11:38:19 | 0 | 218.5 |  | logs/VS-audit-other-base.log |
| VS-legacy-fsrc-base | 2026-10-13 11:41:58 | 0 | 21.2 |  | logs/VS-legacy-fsrc-base.log |
| VS-check-base | 2026-10-13 11:42:19 | 0 | 20.2 |  | logs/VS-check-base.log |
| VS-audit-inject-base | 2026-10-13 11:42:40 | 0 | 68.5 |  | logs/VS-audit-inject-base.log |
| V-MX-batch-adopt-unchecked-r2 | 2026-10-13 11:59:33 | 1 | 60.5 | 111 (22) | logs/V-MX-batch-adopt-unchecked-r2.log |
| VS-audit-recon-base | 2026-10-13 11:59:31 | 0 | 72.1 |  | logs/VS-audit-recon-base.log |
| VS-audit-hostile-base | 2026-10-13 12:00:44 | 0 | 42.5 |  | logs/VS-audit-hostile-base.log |
| VS-boot-same-c3 | 2026-10-13 12:01:26 | 0 | 7.0 |  | logs/VS-boot-same-c3.log |
| VS-audit-c3 | 2026-10-13 12:01:33 | 0 | 5.8 |  | logs/VS-audit-c3.log |
| VS-audit-ppt-c3 | 2026-10-13 12:01:39 | 0 | 3.2 |  | logs/VS-audit-ppt-c3.log |
| VS-audit-other-c3 | 2026-10-13 12:01:42 | 0 | 22.5 |  | logs/VS-audit-other-c3.log |
| VS-legacy-fsrc-c3 | 2026-10-13 12:02:04 | 0 | 2.4 |  | logs/VS-legacy-fsrc-c3.log |
| VS-audit-inject-c3 | 2026-10-13 12:02:07 | 0 | 11.1 |  | logs/VS-audit-inject-c3.log |
| VO-vt-u31-mark-before-verdict--c3-w3-r2 | 2026-10-13 12:00:34 | 1 | 273.0 | 111 (6) | logs/VO-vt-u31-mark-before-verdict--c3-w3-r2.log |
| VS-audit-recon-c3 | 2026-10-13 12:02:18 | 0 | 281.6 |  | logs/VS-audit-recon-c3.log |
| VS-audit-hostile-c3 | 2026-10-13 12:07:00 | 0 | 149.6 |  | logs/VS-audit-hostile-c3.log |
| VG2b-on-c3 | 2026-10-13 12:10:09 | 1 | 27.3 | 8 (1) | logs/VG2b-on-c3.log |
| VG2b-on-base | 2026-10-13 12:10:37 | 1 | 25.2 | 8 (4) | logs/VG2b-on-base.log |
| VG2b-on-answer-file-kept | 2026-10-13 12:11:02 | 1 | 25.1 | 8 (4) | logs/VG2b-on-answer-file-kept.log |
| VO-vt-u31-other-before-checks--c3-w3-r2 | 2026-10-13 12:05:07 | 0 | 382.3 | 111 (0) | logs/VO-vt-u31-other-before-checks--c3-w3-r2.log |
| VO3-vt2-u29-answer-count-before-apply--c3-focused-U29 | 2026-10-13 12:11:27 | 0 | 89.6 | 33 (0) | logs/VO3-vt2-u29-answer-count-before-apply--c3-focused-U29.log |
| V-M3-c3-v200-adopt-u24-link-guard-U24 | 2026-10-13 12:11:30 | 1 | 119.5 | 58 (20) | logs/V-M3-c3-v200-adopt-u24-link-guard-U24.log |
| VO3-vt2-u29-file-memory-kept--c3-focused-U29 | 2026-10-13 12:12:57 | 1 | 93.9 | 33 (5) | logs/VO3-vt2-u29-file-memory-kept--c3-focused-U29.log |
| V-M3-c3-v200-adopt-u24-answer-guard-U24 | 2026-10-13 12:13:29 | 1 | 118.5 | 58 (8) | logs/V-M3-c3-v200-adopt-u24-answer-guard-U24.log |
| VO3-vt2-u29-folder-base-zero--c3-focused-U29 | 2026-10-13 12:14:31 | 1 | 81.7 | 33 (6) | logs/VO3-vt2-u29-folder-base-zero--c3-focused-U29.log |
| VO3-vt2-u31-other-record-replaced--c3-focused-U31 | 2026-10-13 12:15:53 | 0 | 62.7 | 34 (0) | logs/VO3-vt2-u31-other-record-replaced--c3-focused-U31.log |
| V-M3-c3-v200-adopt-u24-file-guard-U24 | 2026-10-13 12:15:28 | 1 | 95.6 | 58 (2) | logs/V-M3-c3-v200-adopt-u24-file-guard-U24.log |
| VO3-vt2-u31-mark-folder-only--c3-focused-U31 | 2026-10-13 12:16:55 | 1 | 60.4 | 34 (4) | logs/VO3-vt2-u31-mark-folder-only--c3-focused-U31.log |
| V-M3-c3-v200-adopt-u24-link-words-later-U24 | 2026-10-13 12:17:03 | 1 | 86.8 | 58 (6) | logs/V-M3-c3-v200-adopt-u24-link-words-later-U24.log |
| V-M3-c3-v200-adopt-u24-link-words-record-U24 | 2026-10-13 12:18:30 | 1 | 54.8 | 58 (6) | logs/V-M3-c3-v200-adopt-u24-link-words-record-U24.log |
| V-M3-c3-v200-adopt-u24-file-words-record-U24 | 2026-10-13 12:19:25 | 1 | 66.9 | 58 (1) | logs/V-M3-c3-v200-adopt-u24-file-words-record-U24.log |
| VS-check-c3 | 2026-10-13 12:20:49 | 0 | 10.9 |  | logs/VS-check-c3.log |

