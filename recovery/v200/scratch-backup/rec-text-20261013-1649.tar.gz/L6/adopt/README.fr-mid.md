# Fix round (13 Oct)

Started at 1:32 PM ET on 13 Oct, after the two verifiers' verdicts (money lens: `wfstate/verify_adopt_r1_money.json`,
`verify-money-r1/`; tests lens: in the task, `verify-tests-r1/`). Both: "sound-with-issues". Base files re-hashed at 1:54 PM ET:
all six equal the blobs above.

**Resume check.** Nothing of an earlier fix-round attempt was in this directory: no copy, log, diff or draft dated after the
build (README.md, 12:00 AM ET on 13 Oct) other than the verifiers' own folders (`verify-money-r1/`, `verify-tests-r1/`) and
`wfstate/`; no "Fix round" section; no fix-round label in `logs/runs.txt`. So this fix round started from the build and kept
none of a stopped attempt (there was none). The verifiers' folders were read, never written.

**Kept from the build:** commit order and subjects; `bin/edit-c1.py` (commit 1's board change, unchanged: c1's board is still
`00c2ac15`); the U31 board change and block (only comments reworded); the 21 build entries (one find follows a changed line);
the reproduction on the base; the base's suite and preservation runs (the base is the same blob and the preservation harnesses
are byte-identical, below). **Superseded:** the build's c1–c3 (their suites and mutate files), harness/, mut/, blocks, entries,
diffs and drafts -- moved or copied to `superseded-r3/`, nothing deleted -- and every build run on those copies.

## What the verifiers found, and what this round did

| item | verifier | what was wrong | what this round did | where |
|---|---|---|---|---|
| **M1** | money | Working out of the folder, when the shared state file answers an opening before the folder is read, each opening re-loaded the very save on screen and counted it again (`loadedNotSaved` set DIRTY), so the opening's own refresh never loaded the folder's newer copy, and "reload to take theirs" was untrue. | **Fixed (commit 2).** The very save on screen (`+st.ts===+MS.ts`, its identity) is not another copy: `sharedArrived` loads it as before and does not count it. I chose this over the verifier's measured line (`if(... && baseGet().dirty) return;`, which skips only when the record is already unsaved), because the verifier's line leaves a second case counted: a board whose shared state file is its OWN save (📁 File → "download the .json state file" right after 💾 Save, the state-file workflow) answering an opening of a board recorded saved -- U29 as built marked it unsaved at every such opening (`LASTKNOWN=0`, so Save then asks "cannot tell"), measured: U29 (13) fails 3 checks on the build's c3 (FR-U29-on-c3build), in the file and the folder. Not counting the same save closes both, and in both keeps the base's behaviour for it exactly (loaded, said, not counted). Test: U29 (11) (P8, the verifier's route, with literals; 2 of its checks fail on the build's c3) and U29 (13) (the own-save case, a CONTROL: the base passes it; the build's c3 fails it). Mutation `v200-adopt-u29-same-save-recounted`. | `bin/edit-c2.py`; `block-u29.mjs.txt` (11), (13) |
| **M2** | money | In the clash line's new branch ("and that is not the copy you are working from"), the refresh still said "What is on screen does not have their changes", while the copy on screen came from one newer than the folder's and can hold them. | **Fixed (commit 2)**, the verifier's words: in that branch the refresh says "What is on screen came from another copy, which may not have their changes." The "after" branch and the refused (Save) branch are unchanged. Test: U29 (12) (P9, with the words checked both ways; its refresh check fails on the build's c3). Mutation `v200-adopt-u29-clash-lacks`. | `bin/edit-c2.py`; U29 (12) |
| **M3** | money | The U31 "What users may see" said a reopen now says unsaved where it said Saved; measured false (the header reads this session only: U15). The U31 block's and board's comments implied the same. | **Corrected.** Draft reworded to what changes (the record, and what an opening keeps); both comments say the header after a reopen reads this session only and says Saved either way (U15, unchanged). | drafts; `bin/edit-c3.py`; `block-u31.mjs.txt` header |
| **M1** | tests | No check drove the shared state file's own load SAVING TO THE BOARD FILE (SHaC file mode); the one-word wrong fix `loadedNotSaved(st, false)` survived every block. | **Fixed (test).** The verifier's scenario text, verbatim, as U29 (9); mutation `v200-adopt-u29-answer-file-kept` (its find follows the line's new form). Drafts now say which modes are covered. | U29 (9) |
| S1 | tests | No check drove the other-years loop of `loadedNotSaved`. | **Added**: G3 as U29 (10) (two years in the folder, the link, then Save on FY28); mutation `v200-adopt-u29-year-on-screen-only`. | U29 (10) |
| S2 | tests | U24 checked the `bootTakeFile` refusal only for a board-file save. | **Added**: G4 as U24 (7) (working out of the folder, a folder save held); mutation `v200-adopt-u24-takefile-guard-file-only`. | U24 (7) |
| S3 | tests | U24 never clicked the link during a save with nothing typed in the session. | **Added**: G1 as U24 (6); mutation `v200-adopt-u24-link-guard-dirty-only`. | U24 (6) |
| S4 | tests | Two draft claims untrue: U31's header claim (= money M3); "SHaC and BTC are covered". | **Corrected**: SHaC now covered in both modes (U29 (5), (9)); BTC's reopen is named as not covered (S5). | drafts |
| S5 | tests | After "open the file's version" in folder mode, a reopen from that same file records the board saved again (BT-fold-C1 K3). | **Stated, not changed.** The reopen's record comes from the opening's own rule -- the file's own save on screen is recorded saved (`fileTs===ours`) -- which is also what the opening that takes the file's newer version on its own does (the verifier's N7, base and fix alike: the U15–U20 family). Changing that rule is outside these three loads and wider than the finding (principle 5). Nothing is lost: the copy on screen is the board file's own save, so it stays in the file; the record still names no folder copy the screen did not come from, so a refresh offers the choice rather than loading the folder's older copy, and 💾 Save still asks, which U29 (6) checks. A folder copy NEWER than it would be loaded at that reopen with nothing kept aside -- the file's copy then only in the file, as for every opening the file's own save starts. Written into U29's "Not covered" and the ledger draft. | drafts |
| S1 | money | ⬅ Import a full board (and Import one appropriation, by code) leaves this appropriation's record clean: data loss next to U31, measured on the base and the build's c3 alike (P7-full). | **New ledger row drafted** (U31's shape, P2 provisional, fix pattern named); U31's "Not covered" corrected. Not changed: outside U31's finding (`importBoards`) and the lead's three fixes; it needs its own reproduction, block and mutations. | `drafts/LEDGER-append.md` |
| S2 / N4 | money / tests | audit-import base L3935 (v1.95 item 47, "the next refresh raises no false clash", `/after the copy you are working from/` absent) no longer sees a false clash in U29's second wording. | **Listed** (principle 6, below, and in U29's "Not covered"). Not edited, and no sibling check added to that existing block: a sibling (`/Save yours over theirs/` absent) passes on the base as well, so it would be a control in an old block, and the lead may prefer to add it there; offered below. | this README; drafts |
| S3 | money | U29's `LASTKNOWN=0` (file mode) silences the opening's "saved since then as well" notice, and Save's question says "cannot tell" where it could. | **Stated** in U29's "Not covered" (Save still asks; nothing lost). | drafts |
| N1 | tests | Nine new U24 checks pass on the base and were not labelled CONTROL. | **Labelled** in the block: "(a CONTROL)" on each, and on the (1) loop's refresh check only for (1Wread), "(a CONTROL here: …)". Labels only; no expectation changed. | `block-u24.mjs.txt` |
| N2 | tests | Wrong fixes on word-only paths survive (clash-vs-screen, count-before-apply, U31 other-before-checks / record-replaced). | **Not done**: no copy is lost on any of them; each needs a refused-load or refused-import route no block reaches. Listed under "not done". | -- |
| N5 | tests | The blocks add 2–6 minutes to a full audit-import. | Noted; the fix round adds about a fifth more checks (below). | -- |
| N6 | tests | The build ran its U24 entries on c1 only. | **Done**: every entry of all three commits is run on the final c3 (MF-c3-*), and the two new U24 entries on c1 too. | runs |
| N7 | tests | Folder mode: the opening that takes the board file's newer version on its own records the screen clean against the folder's copy (base and c3 alike). | Outside this track's three loads; named in U29's "Not covered" and the ledger draft (U15–U20 family). | drafts |
| minors | money | ↶ Put back's question after "load the shared one" (conservative, keeps); the U24 link gone after a non-quiet save; a quiet refresh changing the screen under a refusal a quiet autosave left; link-guard failing 20 checks on c3 against 18 on c1. | The middle two are now in U24's "Not covered". The first is safe (it keeps rather than drops) and unchanged. The 18/20 difference, read from the two runs' records (the build's M2-c1 and the tests verifier's V-M3-c3, both on the build's copies): on c3 the mutant's mid-save load is counted (U29), so at the reopen the shared state file is the very save on screen and is not offered again (4 checks fail only there), and the refresh holds off (2 checks fail only on c1). | -- |

## The fix round's board changes (all in commit 2, plus comments in commit 3)

Commit 1's board is unchanged (`00c2ac15`). Commit 2's board (`0bbfedb6`, was `d020543e`) against the build's:

```diff
@@ function driveClashSay(j, refused){
-    // v2.00 (U29): "after" only when it is. A copy loaded from elsewhere (loadedNotSaved) can be newer than the folder's.
+    // v2.00 (U29): "after" only when it is. A copy loaded from elsewhere (loadedNotSaved) can be newer than the folder's, and
+    // can hold their changes: then the words say only what is known.
     +' to the shared folder '+esc(liveAge(theirs))+(theirs>driveBaseOf(ap)? ', after the copy you are working from. ' : ', and that is not the copy you are working from. ')
-    +(refused? '<b>Nothing was written.</b> ' : 'What is on screen does not have their changes. ')
+    +(refused? '<b>Nothing was written.</b> ' : theirs>driveBaseOf(ap)? 'What is on screen does not have their changes. '
+      : 'What is on screen came from another copy, which may not have their changes. ')
@@ function sharedArrived(st){   (inside if((st.ts||0)>=(MS.ts||0)), after U24's guard)
+    // v2.00 (U29): the very save on screen (the same time: its identity) is not another copy. It loads as before and is not
+    // counted -- else every opening of a board whose shared state file is its own save would say unsaved, and, working out of
+    // the shared folder, would hold off the opening's own refresh, so the folder's newer copy never loaded.
+    const same=!!(+st.ts && +st.ts===+MS.ts);
     if(!sharedKeepMine(st)) return;
     if(applyStore(st)===false) return;
-    loadedNotSaved(st, true);               // v2.00 (U29): a change from what is saved (see adoptShared)
+    if(!same) loadedNotSaved(st, true);     // v2.00 (U29): a change from what is saved (see adoptShared)
```

`same` is read before `applyStore` (after it, `MS.ts` is always `st.ts`). Commit 3's board (`d1cdcdf5`, was `c0d14fcd`)
differs from the build's only in that commit-2 change and the U31 comment:

```diff
-    // edit. It was counted in this session only (lsSet): a reopen took the imported board as saved, the header said Saved, and
-    // a copy in the shared folder newer than it replaced it with nothing kept aside -- the import then only in the file it came from.
+    // edit. It was counted in this session only: a reopen took the imported board as saved, and a copy in the shared folder newer
+    // than it replaced it with nothing kept aside -- the import then only in the file it came from. (The header after a reopen
+    // reads this session only and says Saved either way: U15, unchanged.)
```

## The fix round's suite changes (pure insertions into each new block; no existing block touched)

- **U24 block**: (6) the link a refused answer offers, clicked while that save is still held, with nothing typed in this
  session (the verifier's G1, 3 checks); (7) "open the file's version" working out of the shared folder while a folder save is
  held (G4, 4 checks); the nine base-passing checks labelled CONTROL (N1); two header lines naming (6) and (7).
- **U29 block**: (9) SHaC saving to the board file (the verifier's text, verbatim; 5 checks); (10) two years in the folder
  (G3; 4); (11) the shared state file answering each opening before the folder is read (money P8; 4); (12) the shared state
  file built on the folder's own copy, then a refresh (money P9; 3); (13) the very save on screen, in the file and the folder
  (a CONTROL; 6); `sharedOf` takes an optional FY28 copy; `tsOf`; four header lines.
- **U31 block**: header comment only (M3).
- Every expected value is a hand-written literal; board helpers read observed values only. Every new check that is not
  marked a CONTROL fails on the base (below); the new CONTROLs pass on it.

## Mutation entries (the fix round's: 6 new, 1 find changed; 27 in all for the track)

New, inserted with their commit's entries before the R3 line: `v200-adopt-u24-link-guard-dirty-only`,
`v200-adopt-u24-takefile-guard-file-only` (commit 1; the verifier's text); `v200-adopt-u29-year-on-screen-only`,
`v200-adopt-u29-answer-file-kept` (commit 2; the verifier's, the second's find following the line's new form),
`v200-adopt-u29-same-save-recounted` (`const same=false;`), `v200-adopt-u29-clash-lacks` (the unconditional words back).
Changed find: `v200-adopt-u29-answer-uncounted` (the line it removes now reads `if(!same) loadedNotSaved(st, true);`).
All made by `bin/mk-entries.py`, each find asserted once on its own board.

## How each commit meets the lead's decision principles (fix round)

| principle | U24 | U29 | U31 |
|---|---|---|---|
| (1) never lose any copy | refused during any save, whatever was typed and wherever the save goes (now tested for both); nothing replaced | the person's own copy stays where it was saved until they choose, for every year (now tested); a reopen keeps the loaded copy aside before a saved copy replaces it, and that now happens at the opening the board said it would (11) | the import kept aside before a newer saved copy replaces it |
| (2) refuse or ask | refuses, says so | Save asks wherever the record cannot vouch; the very save on screen is not "another copy", so nothing needless is asked (13) | the record says unsaved: an opening keeps rather than guesses |
| (3) money and exports | untouched | untouched | untouched |
| (4) words true after landing | unchanged words; checked word for word | "reload to take theirs" is now true (11); the refresh no longer says the screen lacks changes it may hold (12); a board whose state file is its own save no longer says unsaved (13) | no new board words; the drafts no longer claim a header change (M3) |
| (5) smallest change | no board change this round | one read and one condition in `sharedArrived`; one condition in `driveClashSay` | comment only this round |
| (6) existing checks | no existing check, fixture or expected value edited (suite diffs are insertions only); see the list below | same | same |

**Principle 6, listed:** no existing line of any suite was removed or changed (diffs: audit-import +281/+321/+136, −0;
mutate +25/+49/+10, −0). One existing check is weaker in MEANING, not in text: **audit-import (base) line 3935**, v1.95 item
47, "the next refresh raises no false clash" -- old meaning: no clash line at all after the refresh (the clash line had one
wording); new meaning: no clash line of the "after the copy you are working from" kind (U29 adds ", and that is not the copy
you are working from."). Why it cannot be kept as it was: U29 must not say "after" where the folder's copy is older (principle
4). A sibling check `/Save yours over theirs/.test(H.status(R.ev))` → `false` beside it would restore the old meaning in
full; it passes on the base and on every copy here (by code: that scenario raises no clash on any of them), so it is a
control, offered for the lead to add to that block rather than added here. Lines 3618 and 7656 expect the "after" wording
where a colleague saved later, or its absence guarded by a status-line equality; both unchanged in meaning.

