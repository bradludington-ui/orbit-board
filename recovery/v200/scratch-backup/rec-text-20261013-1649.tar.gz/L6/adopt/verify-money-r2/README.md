# ADOPT track (U24, U29 with U17, U31) — independent verifier, round 2, LENS A (data loss and money)

Directory: `rec/L6/adopt/verify-money-r2` (absolute:
`/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/adopt/verify-money-r2`).
Started 3:42 PM ET on 13 Oct 2026 (`TZ=America/New_York date`: Tue Oct 13 15:42:46 EDT 2026). No earlier attempt of this
review existed (the folder did not exist), so nothing was reused; every run below is this review's. The builder's folder
(`rec/L6/adopt`) and the round-1 verifiers' folders (`verify-money-r1/`, `verify-tests-r1/`) were read, never written.
`/home/user/orbit-board` and `/home/user/orbit-ui` were only read (`git log`, `git diff --stat`, `grep`); nothing was
edited, staged, committed or pushed anywhere. `mutate.mjs` was never imported or run (entries read as text by
`rec/bin/mcount.py` and `rec/bin/mkmut.py`, `python3 -I`); the scratch clone `git/c3` carries `tools/export-audit/mutate.mjs`
from orbit-board's tree and it was not touched. No `playwright install`, no Chromium run. The full `audit-import.mjs` and
`audit-board.mjs` were not run. The board files stay the empty template; all data is synthetic, made at run time.

## Verdict: sound-with-issues — one must-fix (words, measured; no copy lost), two should-fixes, minors

No route I tried on c3 loses a copy of anyone's work, writes over a copy without asking or without the folder's history
keeping it, or touches money or an export. The fix-round changes (the very-save rule in `sharedArrived`; the clash line's
second sentence) close round 1's money M1 and M2 as measured. But U29's clash words still decide "after the copy you are
working from" by comparing two computers' clocks once a loaded copy is the record's base; with the saver's clock 5 or 60
minutes ahead, the Save refusal says "after" of a folder copy that was saved BEFORE the copy on screen was built on it
(measured; must-fix M1, a three-line fix measured below). The should-fixes are two round-1 items the builder stated rather
than changed: the full import still loses an import from this browser (measured again on the final c3, the same on the
base), and the weakened check at base L3935. Minors include the U24 words during Load theirs (measured).

## Identities (all `git hash-object`; equal to the builder's README, "Fix round: blobs")

| copy | board | audit-import | mutate.mjs.txt |
|---|---|---|---|
| base (`rec/L6/base`) | `fce8a391bd8a248d5185e199d22190c1687eaea0` | `4aba2506a7ea3bd367fb74436172b188bb4fc887` | `cbc6defc6803851e847844848fc9b186daeeb268` |
| c1 | `00c2ac152cd2f022efea656a3be40dca55c4ac8a` | `195381b5759e3f497c091a7a8cc0f95ef79e7089` | `8a7a83e84dfe85cc491e97a0b1bbc77c1e33302b` |
| c2 | `0bbfedb6ca8e3115191fbd2b0c3260a5531a37e8` | `54efb128de20d0bfe41fc6b4857bcb2f7e24cffd` | `4a533f68073eaafad6b1a37f972fb1c345211bce` |
| c3 | `d1cdcdf522be87f7ffd4e37236c84201873ae72c` | `fb163d3c64b8f2d682cad6a5debfe7c3d8f7727d` | `1fcc407eb435b0120d88a6448e6f282b6a41e2d2` |

My copies are `copies/{base,c1,c2,c3}` (`cp -a` of the builder's, node_modules symlink kept, `chmod -R u+w`); boot.mjs
`9c4f49ad`, runtime-encoding-shim.mjs `6e2ce2e6` in all four. `diff -rq base c3` differs only in the board, audit-import and
mutate.mjs.txt. I re-made the four diffs from my copies (`diffs/`): each is byte-identical to the builder's —
commit1 `f1bdf7ab` (+336 −0), commit2 `066ae150` (+408 −6), commit3 `5c7513e7` (+156 −1), all `d6a9fded` (+900 −7); the
only removed lines are board lines (six in commit 2, one in commit 3). The focused harnesses I built from my c3's own
audit-import with the builder's `mkfocused-import.py` are byte-identical to the builder's: U24 `eb7ebabd`, U29 `cb62a1c6`,
U31 `50264d6a`; preservation v1.96 `e9a73126` and W1 `310b30b8` likewise. orbit-board HEAD is now `4bbec77` (records only):
`git diff --stat 7ee498a HEAD -- prioritization-board-grid.html tools/` is empty, and the two NEXT-VERSION anchors the drafts
replace (lines 801 and 727) are present verbatim.

## Findings

### Must fix before commit

**M1 (new; principle 4; residue of round-1 money M2: U29's clash words depend on two computers' clocks).** U29 decides "after the copy you are working
from" by comparing the folder copy's stamp (the saver's clock) with the LOADED copy's stamp (another computer's clock). The
board's own rule is that clocks disagree ("a colleague's clock an hour slow", `ownUnsaved`). Probe `Q3`/`probe-r2d`
(`harness/probe/probe-r2d.mjs`): Brad saves BRAD-2 from a computer whose clock is 5 min (and 60 min) ahead; Carol loads
BRAD-2 from the folder, adds CAROL-B and downloads the shared state file (stamped before BRAD-2's stamp, though made after
it); Brad's board loads it by its link (counted, as U29 intends); 💾 Save then refuses with "⛔ Brad saved O&M FY27 to the
shared folder just now, **after the copy you are working from**. Nothing was written. Load theirs … · Save yours over theirs …"
— untrue: BRAD-2 was saved before the copy on screen, which holds BRAD-2's changes (A = BRAD-2 $720) and CAROL-B. It steers
the same choice round-1 M2 was about (Load theirs would put CAROL-B aside). Nothing is lost (both choices keep the other
copy). On the base the link is not counted, so the refresh loads BRAD-2 over the screen ("⬇ Loaded O&M FY27 from the shared
folder", B empty) and the next Save writes it ("✅ Saved"), CAROL-B no longer on the board and nothing kept aside, the record
being clean (PRC-/PRD-probe-on-base; the keep by code) — so U29 is a large improvement; the words are the defect. Measured: PRD-probe-on-c3
(fails), PRD-probe-on-fx (passes). Minimal fix (`fx/board-fx.html`, `diffs/fx-vs-c3.diff`, +3 −2 board lines): record which
recorded copy is the loaded one (`loaded:ts` in `loadedNotSaved`'s `baseSet`) and in `driveClashSay` say "after" (and "does
not have their changes") only when the base is not that loaded copy:
`const lt=+(baseGet().loaded||0), after=theirs>driveBaseOf(ap) && !(lt && driveBaseOf(ap)===lt);` with `after` replacing
both `theirs>driveBaseOf(ap)` tests. Cost: two of the builder's NEW U29 checks encode "after" against a loaded copy with the
clocks agreeing and would change from AFTER to the hedged words — U29 (1) "the next 💾 Save writes nothing and asks … BRAD-2
said to be saved after the copy on screen" (last literal `true` → `false`, or test NOTIT instead) and U29 (7) "the next 💾
Save writes nothing over BRAD-1 and asks" (same); FX-U29-on-fx fails exactly those 2 checks and no other. No existing check
changes: FX-W1-on-fx (the v1.95 W1 block, which holds the "after" checks of ordinary saves) and FX-U24-on-fx pass. Test to
add: Q3 with literals (in `harness/probe/probe-r2d.mjs`, block "probes, d"); mutation: `after` back to `theirs>driveBaseOf(ap)`.
Why must-fix: it is a sentence the change adds, it is untrue where it is said, and it steers the choice (round 1 held M2, the
same sentence family, to this standard); the U29 comment ("\"after\" only when it is") and the U29 draft ("says \"after the copy you
are working from\" only when that is so") are untrue under clock skew too. Nothing is lost either way.

### Should fix

**S1 (carried from round-1 money S1; data loss next to U31; still open, measured again on the FINAL c3).** ⬅ Import a full
board (`fullImportText`) leaves this browser's record clean. Probe `R2-P7full` (`harness/probe/probe-r2.mjs`): working out of
the folder, BRAD-1 saved; Carol's board fully imported (record after it `{"file":…,"dirty":false,"folder":{…}}`); Brad's
other browser saves OTHER-2; this browser reopens → `[screen OTHER-2 $730, kept null, unsaved false/false/false, "⬇ Loaded
O&M FY27 from the shared folder"]` on c3 (PR-probe-on-c3) and on the base (PR-probe-on-base) alike: the import is in no copy
this browser can reach (only in Carol's file). The builder drafted a new ledger row (P2 provisional) rather than fixing it;
its text is accurate (I checked `fullImportText`: everything stamped `now`, one `lsAll` set, `location.reload()`, no
`.base` write). Recommend the lead decide explicitly before release: the fix is U31's own pattern, a `<key>.base` with
`dirty:true` for each board key inside the import's all-or-nothing `lsAll` set (Import one appropriation likewise).

**S2 (carried from round-1 money S2 / tests N4; principle 6).** audit-import base L3935 ("the next refresh raises no false
clash", `/after the copy you are working from/` absent) no longer sees a false clash worded "and that is not the copy you are
working from". The builder lists it (principle 6 satisfied in letter) and offers a sibling check
(`/Save yours over theirs/.test(H.status(R.ev))` → `false`) without adding it. It is one line and restores the old meaning;
add it beside L3935 (a new check, nothing edited) or as a replay in the U29 block.

### Minor

- **m1 (U24 words, measured).** Load theirs runs in the save queue (`saveSerial`), so U24 refuses during it — rightly — but says
  "a save was under way … Once the save has finished, load the shared one". Probe `Q2` (`probe-r2b.mjs`, PRB-probe-on-c3): the
  shared state file answers while Load theirs reads the folder → that line; Load theirs then lands and its "⬇ Loaded Brad's
  copy" line replaces it. U13's line names both ("a save or Load theirs was under way"); U2's put-back line has the same
  imprecision as U24. Reachable only for the automatic answer at an opening (the other two links are not on screen while the
  clash line is). Nothing lost (the file is looked for again at the next opening). Fix if wanted: U13's words.
- **m2 (the very-save rule trusts the record).** In the N7 state (folder; the opening took the board file's newer version
  and recorded it clean against the folder's older copy — the builder's "Not covered", base and c3 alike), the shared state
  file that is that file's own save is not counted (as on the base); the build's always-count, or round 1's narrower line,
  would have made the next Save ask. The next Save writes over the folder copy, which goes to the folder's history. N7 itself
  is the U15–U20 family; by code, not run.
- **m3 (U24 guard before the same-save test).** The very save on screen arriving during a save is refused, and its link,
  used after a folder save has restamped the board, loads the older copy over the just-saved screen (counted; Save then asks).
  No loss; by code. Putting `same` before the guard would load the identical copy instead (harmless).
- **m4 (`_dlOnly`).** `loadedNotSaved` is "counted as an edit is", but an edit (`save()`, `fileMark`) also clears `_dlOnly`;
  after a download the header could read "downloaded — not on the shared file yet" for a loaded copy that was never
  downloaded. Not reachable from the page as far as I found (every download replaces the status line that holds the load
  links); by code.
- **m5 (pre-existing words next to U31).** After a batch import working out of the shared folder the board says "💾 Save to
  bake all of it into this file", but Save then writes this appropriation's year to the folder only; the other
  appropriations' imports stay in this browser (now recorded unsaved by U31, so nothing is lost). Unchanged by U31; by code.
- **m6 (tests, for the record).** My wrong-fix mutant `OM-keep-never` (the very-save exclusion widened from `===` to `>=`,
  which keeps nothing aside before the shared state file replaces unsaved work) passes the U29 block (OM-keep-never-U29,
  exit 0) and is caught only by the existing v1.96 block (OM-keep-never-v196, 3 failing). The full suite catches it.

## Checked and sound (lens A), against the lead's six principles

Read line by line: every board hunk of the three commits (`diffs/all-c3-vs-base.diff`), and every caller and neighbour they
reach — `save()`, `persist()`, `saveSerial()` and its four callers (file save, folder push, `saveInPlace`, `driveResolve`),
`_saveInPlaceFileRun` (LASTKNOWN and its "cannot tell" question), `buildSavedHtml` (calls `save()`, so a file save stamps
`MS.ts` and marks the record before its bytes), `publishState`/`publishJson`, the boot's PUB/LASTKNOWN rule and `_bootOwn`,
`ownUnsaved`, `keepAside`, `keptPutBack` (its swap carries the kept copy's own checkpoint, so U29's `file:0` never leaks into
put-back work), `driveStorePull`, `_driveStorePushRun`, `_driveResolveRun`, `driveClashSay`, `livePayload` (each folder year
file carries the whole store), `applyStore`, `lsSet`/`lsAll`/`fileMark` (why `importBoards` already counts), `importBoards`,
`fullImportText`, `loadShared`/`sharedArrived`, `adoptShared`, `bootTakeFile` and its three offering lines.

- **The very-save rule (`same`, fix round).** It is an identity by time, as LASTKNOWN already is: every edit goes through
  `save()`, which stamps `MS.ts`; a file save stamps it through `buildSavedHtml()`; a folder save stamps it before its bytes.
  I looked for a path that changes the work on screen and marks the record unsaved WITHOUT stamping `MS.ts` (which would let
  `sharedKeepMine` skip keeping real work aside): the only `persist()` callers that do not stamp are loads that carry their
  own copy's time (keptPutBack, history put-back, the folder pull, Load theirs, bootTakeFile, the shared load itself), the
  spend-plan ACE choice (`MS.spAce`) and the reprogramming migration (`MS.rpMigrated`) — settings, never marked unsaved, and
  loaded over identically on the base. None loses work. A wrong fix that widens the rule (`===` to `>=`, my mutant
  `OM-keep-never`) is caught by the existing v1.96 block (3 checks), so the suite guards the line the round changed.
- **Principle 1 (no copy lost; keep both and ask).** U24: all three loads refuse during any save, whatever was typed and
  wherever the save goes; re-run of the builder's U24 block, verdicts identical (65 checks; 33 fail on the base). U29: the
  person's own copy stays in its file or folder copy, Save asks in both modes (file: "cannot tell"; folder: the clash line,
  every year of this appropriation, also the Live autosave), and a reopen keeps the loaded copy aside before a newer saved
  copy replaces it (U29 block, 55 checks; 34 fail on the base). U31: the batch marks this board's record and every other
  appropriation's record it wrote, outside nothing it can roll back (`batchImportUndone` returns first), so a reopen or a
  switch keeps the import aside (U31 block, 34 checks; 14 fail on the base). Mutants of the fix round's new entries are all
  caught (table below).
- **Principle 2 (refuse or ask).** No route found where the changed board writes over a copy without asking or without the
  folder's history keeping it. The same-save rule trusts the record (minor m2).
- **Principle 3 (money and exports).** No money, total, export or code path is touched (diff read line by line; the only
  board lines are in the five functions above and `importBoards`). `boot-same` (every page, source, save and error list is
  identical both ways), `audit` (exports) and `audit-ppt` were re-run on the c3 board in my scratch clone and compared with
  the builder's base logs (runs below).
- **Principle 4 (every word true).** The round-1 M2 words are fixed (U29 (12); `clash-lacks` caught). New words checked by
  reading and by probe: the three U24 refusals, the U29 clash branch, the two link promises, the U31 comment. Two new
  inaccuracies measured: the clash line's "after" under clock skew (must-fix M1) and the U24 words during Load theirs (minor
  m1); m4 and m5 are by code.
- **Principle 5 (smallest change).** Commit 2's fix-round change is one read and one condition in `sharedArrived` and one
  condition in `driveClashSay`; U31's other-appropriation marking is wider than the finding's words but measured as loss on
  the base by the builder (X-* probe) and by U31 (4a).
- **Principle 6 (existing checks).** Suite diffs remove nothing (audit-import +738 −0, mutate +84 −0); mcount (text only)
  finds every entry exactly once on all four copies (1328/1336/1352/1355); the existing v1.96 preservation harness passes on
  c3. The one weakened check (base L3935) is listed by the builder; see should-fix S2.

## Runs (every node run through `run.sh`: `setsid -w timeout -k 10 600`, its own process group, the AUDIT_IMPORT_RUNNING lock checked first — absent before every run, 0 waits, 0 skips; PIDs in `pids.txt`; at most two node runs of mine at a time)

Harnesses: `harness/c3/focused-{U24,U29,U31}.mjs` (built verbatim from c3's audit-import, = the builder's blobs);
`harness/pres/{v196,w1}.mjs` (verbatim, = the builder's); `harness/probe/probe-r2{,b,c,d}.mjs` (my probes: the c3 U29
harness's preamble and closing guard verbatim, my block between; blobs `989bed1f`, `b4e551bb`, `fdf5ef7c`, `3a3ab1ae`).
"on base" / "on fx" / mutants = the c3 harness booted from `copies/c3` with BOARD set to that board (runner.mjs asserts it).
Mutant boards: `mut/<id>.html`, made by `rec/bin/mkmut.py` from c3's mutate.mjs.txt (text only; each find matched once),
and my own `mut/om-keep-never.html`. Fix candidate: `fx/board-fx.html` (`3f75fa5f`), diff `diffs/fx-vs-c3.diff` (`d7f07b37`).

| label | start (ET) | exit | wall s | result | log |
|---|---|---|---|---|---|
| V-U24-on-c3 | 3:53:16 PM | 0 | 170.5 | ALL CHECKS PASSED | logs/V-U24-on-c3.log |
| V-U29-on-c3 | 3:53:15 PM | 0 | 176.5 | ALL CHECKS PASSED | logs/V-U29-on-c3.log |
| V-U24-on-base | 3:56:06 PM | 1 | 145.2 | 33 failing | logs/V-U24-on-base.log |
| V-U29-on-base | 3:56:12 PM | 1 | 149.4 | 34 failing | logs/V-U29-on-base.log |
| V-U31-on-c3 | 3:58:53 PM | 0 | 75.3 | ALL CHECKS PASSED | logs/V-U31-on-c3.log |
| V-U31-on-base | 4:00:08 PM | 1 | 78.2 | 14 failing | logs/V-U31-on-base.log |
| M-v200-adopt-u29-same-save-recounted | 4:01:09 PM | 1 | 126.9 | 5 failing | logs/M-v200-adopt-u29-same-save-recounted.log |
| M-v200-adopt-u24-link-guard-dirty-only | 4:01:29 PM | 1 | 122.1 | 2 failing | logs/M-v200-adopt-u24-link-guard-dirty-only.log |
| M-v200-adopt-u29-clash-lacks | 4:03:16 PM | 1 | 177.9 | 1 failing | logs/M-v200-adopt-u29-clash-lacks.log |
| M-v200-adopt-u24-takefile-guard-file-only | 4:03:31 PM | 1 | 185.4 | 2 failing | logs/M-v200-adopt-u24-takefile-guard-file-only.log |
| OM-keep-never-v196 | 4:06:37 PM | 1 | 111.3 | 3 failing | logs/OM-keep-never-v196.log |
| M-v200-adopt-u29-answer-file-kept | 4:06:14 PM | 1 | 151.4 | 3 failing | logs/M-v200-adopt-u29-answer-file-kept.log |
| P-v196-c3 | 4:08:41 PM | 0 | 90.5 | ALL CHECKS PASSED | logs/P-v196-c3.log |
| PR-probe-on-c3 | 4:10:12 PM | 1 | 40.1 | 1 failing | logs/PR-probe-on-c3.log |
| M-v200-adopt-u29-same-save-kept | 4:08:45 PM | 1 | 130.7 | 1 failing | logs/M-v200-adopt-u29-same-save-kept.log |
| PR-probe-on-base | 4:10:52 PM | 1 | 41.2 | 1 failing | logs/PR-probe-on-base.log |
| PRB-probe-on-c3 | 4:11:34 PM | 1 | 30.2 | 1 failing | logs/PRB-probe-on-c3.log |
| PRB-probe-on-base | 4:12:05 PM | 0 | 33.5 | ALL CHECKS PASSED | logs/PRB-probe-on-base.log |
| M-v200-adopt-u29-year-on-screen-only | 4:10:56 PM | 1 | 191.3 | 1 failing | logs/M-v200-adopt-u29-year-on-screen-only.log |
| PRC-probe-on-c3 | 4:13:40 PM | 0 | 46.8 | ALL CHECKS PASSED | logs/PRC-probe-on-c3.log |
| PRC-probe-on-base | 4:14:27 PM | 1 | 46.1 | 2 failing | logs/PRC-probe-on-base.log |
| PRC-probe-on-fx | 4:15:16 PM | 0 | 50.2 | ALL CHECKS PASSED | logs/PRC-probe-on-fx.log |
| OM-keep-never-U29 | 4:14:07 PM | 0 | 178.4 | ALL CHECKS PASSED | logs/OM-keep-never-U29.log |
| S-boot-same-c3 | 4:17:12 PM | 0 | 57.7 | identical either way | logs/S-boot-same-c3.log |
| S-audit-c3 | 4:18:10 PM | 0 | 52.6 | ALL CHECKS PASSED | logs/S-audit-c3.log |
| FX-U29-on-fx | 4:16:06 PM | 1 | 192.9 | 2 failing | logs/FX-U29-on-fx.log |
| S-audit-ppt-c3 | 4:19:02 PM | 0 | 26.2 | ALL CHECKS PASSED | logs/S-audit-ppt-c3.log |
| FX-W1-on-fx | 4:19:19 PM | 0 | 148.7 | ALL CHECKS PASSED | logs/FX-W1-on-fx.log |
| PRD-probe-on-c3 | 4:21:13 PM | 1 | 45.4 | 2 failing | logs/PRD-probe-on-c3.log |
| PRD-probe-on-fx | 4:21:59 PM | 0 | 45.5 | ALL CHECKS PASSED | logs/PRD-probe-on-fx.log |
| PRD-probe-on-base | 4:22:44 PM | 1 | 39.5 | 4 failing | logs/PRD-probe-on-base.log |
| FX-U24-on-fx | 4:21:48 PM | 0 | 145.2 | ALL CHECKS PASSED | logs/FX-U24-on-fx.log |

What the runs show:
- **Focused blocks re-run (V-*)**: my verdict lists equal the builder's FR-* lists check for check (U24 65 checks: 0 failing on
  c3, 33 on the base; U29 55: 0 / 34; U31 34: 0 / 14). Every CONTROL-labelled check passes on the base (U24 28, U29 21 counting
  the (8) scenario's label, U31 20) and the four unlabelled U24 (5) checks pass on it too — as the drafts say.
- **The fix round's entries (M-*)**, on the final c3: all caught, with the builder's counts — `-same-save-recounted` 5,
  `-link-guard-dirty-only` 2, `-clash-lacks` 1, `-takefile-guard-file-only` 2, `-answer-file-kept` 3, `-same-save-kept` 1,
  `-year-on-screen-only` 1.
- **My wrong-fix mutant** `OM-keep-never` (data loss: nothing kept aside before the shared state file replaces unsaved work):
  not caught by the U29 block (exit 0), caught by the existing v1.96 block (3 failing); P-v196-c3 is that block's baseline on
  c3 (passes).
- **Probes**: PR-* (R2-P7full fails on c3 and the base alike: should-fix S1; its Q2 part had a set-up error — the other
  browser was not the copy's writer, so no clash arose; its check passed vacuously and is superseded by PRB). PRB-* (Q2,
  corrected: the U24 words during Load theirs, fails on c3 = minor m1; passes vacuously on the base, which has no refusal).
  PRC-* (Q3 checked at the refresh: c3 and fx pass — the refresh takes its "unsaved changes" branch, whose words are true;
  the base fails: the screen loses CAROL-B). PRD-* (Q3 checked at the Save refusal: c3 fails 2 = must-fix M1; fx passes;
  the base fails 4, its U29 loss).
- **Fix candidate (FX-*)**: U24 65/65 same verdicts as c3; W1 (existing "after" checks of ordinary saves) passes; U29 fails
  exactly U29 (1) and U29 (7)'s "after" literals (the cost named in M1).
- **Other suites** on my scratch clone `git/c3` (`git clone --shared` of orbit-board at `7ee498a`, the c3 board and
  audit-import copied in, nothing committed): `boot-same` "every page, source, save and error list is identical either way",
  `audit` and `audit-ppt` ALL CHECKS PASSED; each log equals the builder's base log line for line once times and durations are
  normalised.

**mcount (text only, `python3 -I rec/bin/mcount.py`, 3:54–3:55 PM ET, `logs/mcount.txt`)**: base 1328/1328, c1 1336/1336,
c2 1352/1352, c3 1355/1355 entries match exactly once; the 27 `v200-adopt-*` ids each match once on c3, inserted directly
before "  // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan." (line 4372).

## PIDs

`pids.txt`: each node run's `timeout` PID and its child with the time (ET), label and command (64 lines). The lane drivers
and wait loops (`bin/lane-*.sh`, `until grep …` loops, two Monitor watches) ran as Bash-tool background tasks reading only
`logs/runs.txt`; they are not in `pids.txt`. I stopped two of my own: a Monitor watch duplicated by a second one, and one
queued PRD lane before it had started any run (re-queued at once in its own lane). Nothing else was stopped or killed; no
process of mine is running.

## Decisions, with reasons

- M1 is must-fix rather than should-fix: the sentence is new in U29, measured untrue, and steers the same choice round 1's
  M2 did; the fix is three board lines and changes only two of the builder's new checks.
- S1 stays should-fix: the loss is real and measured on the final c3, but it is on a path these commits do not touch and is
  the same on the base; the builder's ledger row is accurate.
- The U24 words during Load theirs are minor: U2's existing put-back refusal uses the same words, and only the automatic
  answer at an opening can meet Load theirs.
- I re-ran the builder's blocks on base and c3 only (not c1/c2): the c1/c2 runs are the builder's, and c3 carries all three
  blocks.

## What I did not do (plainly)

- Nothing committed, staged or pushed; nothing written in `/home/user/orbit-board` or `/home/user/orbit-ui` (read only:
  `git log`, `git diff --stat`, `grep` of NEXT-VERSION.md and the ledger). The builder's and round-1 folders were not written.
- `mutate.mjs` was never imported or run (the clone's copy untouched); no `playwright install`; no Chromium run; no full
  `audit-import.mjs` or `audit-board.mjs`; no `npm run check`, `audit-recon`, `audit-other`, `audit-hostile`, `audit-inject`,
  `legacy-fsrc` (the builder ran them; my lens needed the money/export suites, which I re-ran).
- Not every one of the 27 entries was re-run: the seven fix-round entries were (all caught); the 20 build entries rest on the
  builder's MF-c3-* runs and round 1's.
- I did not fix anything in the builder's copies; `fx/` is my candidate for M1 only, measured, not proposed as a commit.
- Short text commands (blob hashes, `diff`, `mcount.py`, `mkmut.py`, the git clone, log comparisons) ran directly under the
  Bash tool's own time limit, not under `setsid -w timeout -k 10 600`; each finished in seconds. Every node run was bounded.
- Not probed by run: m2–m5 (by code, as said); cross-tab saves (a load in one tab while another tab saves is outside
  `_saveBusy`, as for every edit; not U24's claim).
