# ADOPT track (U24, U29 with U17, U31): builder's record

Directory: `rec/L6/adopt` (absolute: `/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/adopt`).
Base (read-only): `rec/L6/base` = `git archive` of orbit-board `7ee498a` (product = `d66dd60`, U14): board `fce8a391`,
audit-import `4aba2506`, audit-recon `529e36f7`, audit-board `a7c575e5`, audit-other `d89396b0`, mutate.mjs.txt `cbc6defc`.
orbit-board's HEAD has moved since (to `6f5fc1b`, 28 commits), but by records only: `git diff --stat 7ee498a HEAD --
prioritization-board-grid.html tools/` is empty (checked read-only on 13 Oct, before the rebuild at 1:44 PM ET).

This README has two parts. **"Fix round (13 Oct)"** comes first and is current. **"Build record (12–13 Oct)"** below it is the
build's README unchanged; where the fix round changed something, the fix round says so and the build's text is superseded on
that point (its copies, blocks, entries, blobs, counts and drafts are kept in `superseded-r3/`).

Nothing was edited, staged, committed or pushed in `/home/user/orbit-board` or `/home/user/orbit-ui`. `mutate.mjs` was never
imported or run: entries were read as text only (`rec/bin/mcount.py`, `rec/bin/mkmut.py`, both `python3 -I`). No
`playwright install`, and no Chromium run was needed. The full audit-import and audit-board were not run (the lead's). Every
board stays the empty template; every fixture is synthetic and made at run time.

