
## Fix round: what I did not do (plainly)

- I committed nothing, pushed nothing, and wrote nothing in `/home/user/orbit-board` or `/home/user/orbit-ui`. The scratch
  clone `git/c3fr` is a `--shared` clone at `7ee498a` with the fix-round c3's board and audit-import copied into its work
  tree; nothing was committed there. NEXT-VERSION.md and ledger texts are drafts in `drafts/` only.
- I did not run the full `audit-import.mjs` or `audit-board.mjs` (the lead's). Full-suite sensitivity of the three blocks and
  the full mutation run are for the final-tree queue.
- I did not import, execute or run `mutate.mjs`; entries were counted and applied as text (`mcount.py`, `mkmut.py`).
- No Chromium run: nothing here draws differently (status-line text only); no `verify:grid`; no `playwright install`.
- I did not change the opening's rule that records the file's own save as saved (tests S5, N7): it is outside the three loads
  and shared with the opening's other paths; stated in U29's "Not covered" and the ledger draft.
- I did not change ⬅ Import a full board, Import one appropriation, or the other paths that write another appropriation's
  board (money S1; decision 4 of the build): a new ledger row is drafted for the first two.
- I did not add the sibling check beside audit-import base L3935 (an existing block): offered to the lead (principle 6 list).
- I did not build tests for the word-only wrong fixes the tests verifier listed (N2: clash-vs-screen, count-before-apply, U31
  other-before-checks and record-replaced): no copy is lost on any; each needs a refused load or refused import that no block
  reaches.
- I did not run the U29 entries on c2 (commit 2's own copy): they were run on the final c3, which differs from c2 only inside
  `importBoards` (code and a comment) -- no U29 scenario reaches it -- and the U29 block passes on c2 and c3 alike. The six
  build U24 entries were run on the final c3 (all eight), and the two new ones on c1 as well; the six old ones on c1 are the
  build's runs with the build's block (superseded by the c3 runs).
- I did not re-run the base's other suites or its preservation harnesses: the base blob, the suites and the preservation
  harnesses are byte-identical to the build's, whose base runs stand (S-*-base, P-*-base).
- Waiting and drivers: the lane drivers (`focused-fr.sh A|B`, `queue-fr.sh 1|2`, `queue-fr-suites.sh 1|2`, `rerun-fr.sh`,
  `rerun2-fr.sh`) ran as Bash-tool background tasks (tool-bounded at 1 to 2 hours), not under `setsid -w timeout -k 10
  600`, because each drives many runs; their PIDs are in `pids.txt`, marked as such. Every node run inside them went
  through `run.sh` (`setsid -w timeout -k 10 600`, own process group, PIDs in `pids.txt`); so did the rebuild, mcount,
  mkmut, harness, clone and diff steps, through `bx.sh`. Reads (`cat`, `grep`, `sed`, `ps`, `free`), the data-only
  summarisers (`bin/summ.py`, `frcmp.py`, `cmpfail.py`, `newchecks.py`, `suitecmp.py`) and the text edits of my own
  scripts, blocks and drafts ran directly from the Bash tool, each in a second or two. Several Bash-tool wait loops
  (`until grep …; do sleep 10|15; done`) and the Monitor watches read only `logs/runs.txt`; they are not in `pids.txt`.
  I stopped or killed nothing.
