
## The three proposed commits (the lead commits; I did not)

Each copy is CUMULATIVE (`cp -a` of the previous one, node_modules symlink kept, `chmod u+w`); only the board,
`tools/export-audit/audit-import.mjs` and `tools/export-audit/mutate.mjs.txt` differ (`diff -rq`), and in the two suites the
change is pure insertion (no existing line removed or changed: `diffs/*.diff`, counted per file below).

| # | subject | copy | board | audit-import | mutate.mjs.txt | diff against the previous copy |
|---|---|---|---|---|---|---|
| 1 | v2.00 U24: another copy is not put on screen during a save | `c1/` | `00c2ac152cd2f022efea656a3be40dca55c4ac8a` | `b111bfe1b976878b3431c0f118e9d69f2e45f2f0` | `d8f3956b6b0225cdca01a1937d4ddb4ba82d1d8b` | `diffs/commit1-c1-vs-base.diff` (`8bee57c1`): board +30 −0, audit-import +240 −0, mutate +19 −0 |
| 2 | v2.00 U29 (with U24, closes U17): another copy put on screen is a change from what is saved | `c2/` | `d020543e2166b087ad0ac1bdfdb39924c99b74b6` | `16ae994982de083003a8910b2ad3d4ceafaa07be` | `22df04f5152e6ecd6062da3237427b16af38594b` | `diffs/commit2-c2-vs-c1.diff` (`284aeeec`): board +31 −5, audit-import +215 −0, mutate +37 −0 |
| 3 | v2.00 U31: a batch import marks this browser’s records unsaved | `c3/` | `c0d14fcdfb0b90d774c947277e0c8601af779930` | `97bc28bf559ad733c6cb6d813f801a843e43f3fc` | `f0c7dbf44d435092ae5dd271983ecd0121627d42` | `diffs/commit3-c3-vs-c2.diff` (`947ac513`): board +9 −1, audit-import +135 −0, mutate +10 −0 |

All three together: `diffs/all-c3-vs-base.diff` (`7ee209da`): board +70 −6, audit-import +590 −0, mutate +66 −0. Every other file of each copy is the base's byte for byte
(audit-recon `529e36f7`, audit-board `a7c575e5`, audit-other `d89396b0`, package.json `7cf8186f`, NEXT-VERSION.md `65265c13`,
boot.mjs `9c4f49ad`, the shim `6e2ce2e6`). The copies are built by `bin/edit-c1.py`, `bin/edit-c2.py`, `bin/edit-c3.py`
(each asserts its source blob and that each anchor occurs exactly once), `bin/insert-block.py` (each block after the
previous block's end marker; U24's after `// ==== end v2.00 (U13) ====`) and `bin/insert-before.py` (the entries before
`  // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.`).

**Order.** U24 first: it is the release blocker of the three (U13's shape, data loss in FBT), it follows the pattern Brad chose
for U13, and it stands alone. U29 second: it changes what a load records, which U24's refusal leaves untouched; its block
fails identically with or without U24 (24 of 33 on the base and on c1), and U24's block passes on c2 and c3, so the two do not
lean on each other's tests. U31 last: independent of both (its block fails identically on the base and on c2).

### Commit 1 (U24): what changes in the board

`adoptShared`, `sharedArrived`'s own load (inside `if((st.ts||0)>=(MS.ts||0))`, before `sharedKeepMine`) and
`bootTakeFile` (after its `confirm`) each get `if(_saveBusy){ setStat(...); [render();] return; }`. Nothing waits between
the check and the load in any of the three: `adoptShared` and `sharedArrived` are synchronous from the guard on, and
`bootTakeFile`'s question is a modal `confirm` -- its last wait -- before the guard (U13's late-guard pattern).

### Commit 2 (U29): what changes in the board

- `loadedNotSaved(st, file)` (new, beside `sharedKeepMine`): `_saveGen++; DIRTY=true; _baseDirty=true;` every folder base of
  this appropriation, and one per year the board holds, set to the loaded copy's own time; `file` → `LASTKNOWN=0` and the
  record's `file:0`; then `baseSet({folder, dirty:true[, file:0]})`.
- Called after `applyStore` in `adoptShared` and in `sharedArrived`'s own load (`file` true), and in `bootTakeFile` when
  working out of the shared folder (`file` false: the file's version IS the file's save, so its record stays).
- `sharedKeepMine`: the same save as the one on screen (`st.ts===MS.ts`, a time the board uses as an identity throughout)
  keeps nothing aside -- otherwise the shared state file answering the next opening would keep a copy of itself, now that the
  record says unsaved after the load.
- `driveClashSay`: "after the copy you are working from" only when the folder's copy is newer than the recorded one; else
  "and that is not the copy you are working from".
- The two links' promise: "(work no saved copy has is kept aside first)" for "(what you have …)" and "(yours …)".

What Save then does, by the code it already has: the file save sees `fts>0 && fts!==LASTKNOWN` with `LASTKNOWN` 0 and asks
"this browser cannot tell whether that was before or after the copy you are working from"; the folder save sees
`theirs!==driveBaseOf(ap, fy)` and refuses with the clash line (Load theirs keeps the screen aside; Save yours over theirs keeps
theirs in the history). With nothing in the folder, nothing is overwritten and the save goes ahead.

### Commit 3 (U31): what changes in the board

`if(applied){ persist(); render(); }` → `if(applied){ try{ if(!_baseDirty){ _baseDirty=true; baseSet({dirty:true}); } }catch(e){}
persist(); render(); }` -- `save()`'s own lines for the record, run only when the board on screen took the import -- and then,
for every other appropriation the batch wrote (`take`, all written by then: a refused or undone batch has returned before),
its own record (`_SLUGMAP[slug].key+'.base'`, the key its board's `baseGet()` reads when it is opened) gets `dirty:true`,
merged into what it holds, in a try (as `baseSet` swallows a refusal). An appropriation whose stored copy turns out to be the
file's own save is marked clean again by its own opening (`fileTs===ours`), as today.

## How each commit meets the lead's decision principles

| principle | U24 | U29 | U31 |
|---|---|---|---|
| (1) never lose any copy; keep both and ask or say | the save's copy is never recorded against another copy on screen; refused, nothing is replaced and the copy offered stays where it was (`SHARED` in memory and next to the board; `PUB` in the board file) | the person's own copy stays in its saved copy until they choose (Save asks); a reopen keeps the loaded copy aside before the saved copy replaces it (U29 (1), (2)) | the import is kept aside before a newer saved copy replaces it (U31 (2), (3)) |
| (2) refuse or ask rather than guess | refuses during a save, says so | Save asks wherever the record cannot vouch for the copy it would write over | the record says unsaved: an opening keeps rather than guesses |
| (3) money and every export match exactly | no money path is touched | no money path is touched | no money path is touched |
| (4) every word stays true after the operation lands | the refusals name only what a save leaves as it is (screen, kept work); checked word for word, and after a quiet autosave lands (U24 (1Wauto)); mutations put the old untrue words back and are caught | "after" said only when it is (U29 (5), (6)); the links promise only what is kept | no new words |
| (5) smallest change | three guards | one helper, three calls, one condition, two words | one line for the board on screen, three for the others the batch wrote (decision 4) |
| (6) existing checks preserved | pure insertion in both suites; preservation runs (below); the existing mutations beside the changed code (`sidecar-typed-replaced`, `sidecar-no-keep`, `adopt-shared-no-keep`, `batch-writes-each`, `batch-adopt-unchecked`) still caught on the final c3 (MX-*) | same; the changed words are in no existing check (searched: "kept aside first", "after the copy you are working from" -- the three existing checks of the latter expect it where a colleague saved later, or expect it absent, both unchanged) | same; the v1.97 W3 batch-import block passes unchanged |

No existing check, fixture or expected value was edited.

## Decisions, with reasons

1. **The U24 refusal words were changed** (see the table above). Measured: on c1 after the Live autosave lands, the refusal is
   still on screen and this browser's record is no longer what it was when the link was refused (U24 (1Wauto), checked).
2. **U29 is built as the U17 checker's P3 plus the U17 builder's P2, not as P1 alone**: P1 (refuse during a save) cannot touch
   the no-save routes (XSHn, XFSHn, SHaC, BTC), which the triage measured as the same falsely clean record. Counting alone
   (P3 as drafted) would leave the record naming the person's copy, so the next Save would write over it unasked; hence the
   record stops naming it. Measured: the mutants `v200-adopt-u29-folder-base-kept` and `-file-base-kept` are exactly P3 as
   drafted in each mode, and with them the next 💾 Save writes the loaded copy over the person's own without asking (U29
   (1), (3), (5), (6), (7) fail with the first; (2), (4) with the second; README "Mutants").
3. **U24 stays a refusal even though U29 counts the load**: Brad's U13 rule (refuse, re-check after the last wait), and a
   counted load during a save would still put another copy on screen mid-save.
4. **U31 marks every appropriation the batch wrote, not only the one on screen.** First built (as the second builder had it)
   for the board on screen only; reading `importBoards` showed the batch writes the other appropriations' storage too and
   never their records. I measured it before changing anything (`probe/other-appn/`, runs X-otherappn-on-base and
   -on-c3, on the then c3 `d355db84`, now `superseded-r2/c3-third-v1`): an O&M board whose browser's Full Fund record says
   it is the file's own save takes a batch of one Full Fund board older than the file's; switching to Full Fund opens the
   file's Full Fund and keeps nothing aside -- the import then only in the person's file. Identical on the base and on that
   c3 (2 of 8 checks fail on each). The probe's second case was meant to have no Full Fund record, but the fixture's own
   browser storage carries one saying unsaved, so the import was kept aside there; the block's (4b) takes that record out
   and is the real no-record control (the journal's comparison keeps the import aside). It is
   the same finding (U31: "never marks this browser's record") on the batch's main use, several boards, with the same loss,
   so commit 3 now marks each one (three lines), with scenario (4) in the U31 block and the mutation
   `v200-adopt-u31-other-unmarked`. **No other path that writes another appropriation's board into browser storage marks
   that appropriation's record either**: by code, `lsSet(_SLUGMAP[…].key, …)` at c3 L8770, L9245, L9445, L9839, L10232,
   L10267 and L17760 (package and appropriation imports, plan and band-ladder writes among them). Not measured, not changed:
   for the lead.
5. **IB-fold-Wclean added to the U31 block** (the triage's measured loss route); IB-file-Wclean beside it as a control (the
   file save marks the record itself while building its bytes, measured consistent on the base).
6. **Mutants were run on each commit's own copy** (the copy whose block they target), as the earlier attempt did.

## Drafts for the lead (not committed anywhere)

- `drafts/NEXT-VERSION-entries.md`: the three NEXT-VERSION.md entries under v2.00 (what was wrong, what changes, "What users
  may see", "Test", "Mutations", "Not covered"), and the replacement text for "Unresolved after R1–R5" (U13's line amended;
  U24, U29, U31 lines added).
- `drafts/LEDGER-append.md`: the text to append to the Status cells of U24, U29, U17 and U31 in
  `recovery/v200/UNRESOLVED-LEDGER.md`, with `<sha>`/`<time>` placeholders.

## The triage's routes and controls, and where each is tested (audit-import blocks, literals throughout)

| triage route (rec/L4/u24, u24-check, u17-check) | block and scenario | on the base |
|---|---|---|
| SHc-fold-W, SHc-fold-Whist, SHc-fold-Wread, SHc-fold-Wauto | U24 (1W), (1Whist), (1Wread), (1Wauto) | falsely clean / loaded mid-save (fails) |
| SHc-file-W | U24 (2) | fails |
| SHa-fold-W, SHa-fold-Wlate | U24 (3a), (3b) | fails, through a refresh and a reopen |
| BT-file-W (FBT: the save's copy then in no copy the board can reach) | U24 (4) | fails |
| SHc-*-C1, SHa-fold-C1, BT-file-C1, SHc-fold-Wedit (controls) | U24 (5a), (5b), (5c), (5d) | pass |
| XSHn, XFSHn | U29 (1), (2) | fail |
| XSHdL, XFSHdL | U29 (3), (4) | fail |
| SHaC (the shared state file's own load, no save) | U29 (5) | fails |
| BTC / BT-fold-C1 (folder mode, no save) | U29 (6) | fails |
| SHdC-like (link with unsaved work) and BT-file-C1 (controls) | U29 (7) control part, (8) | pass |
| IB-fold-C1clean, IB-file-C1clean | U31 (1, folder), (1, file) | fail |
| IB-fold-C1oldclean (and the file twin) | U31 (2, folder), (2, file) | fail |
| IB-fold-Wclean (measured loss) / IB-file-Wclean (control) | U31 (3, folder) / (3, file) | fails / passes |
| the batch's other appropriation (found and measured here) | U31 (4a) / (4b) | (4a) fails; (4b)'s controls pass, its record check fails (no record is made) |
| IB-fold-W, IB-file-W, IB-*-C1, IB-*-C2 (counted, consistent) | not repeated: the v1.97 W3 batch-import block and U31's controls cover the counting | -- |
| SHa-file-W (DIRTY guard), SHa-fold-Wnow | not repeated: paths U24 does not change (the DIRTY branch, before its guard; the "your local changes are newer" branch, beside it) | -- |
