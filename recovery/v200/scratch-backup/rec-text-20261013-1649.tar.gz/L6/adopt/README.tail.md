
## What I did not do (plainly)

- I committed nothing, pushed nothing, and wrote nothing in `/home/user/orbit-board` or `/home/user/orbit-ui` (the scratch
  clones under `git/` are `--shared` clones with files copied over in the work tree; nothing was committed there either).
- I did not run the full `audit-import.mjs` or `audit-board.mjs` (the lead's). The blocks' sensitivity in the full suite,
  and the full mutation run, are for the final-tree queue.
- I did not import, execute or run `mutate.mjs`; entries were counted and applied as text (`mcount.py`, `mkmut.py`).
- I did not run any Chromium tool (no layout or drawing changes; the new status lines are text in the existing status bar;
  no `verify:grid` run).
- I did not run the U24 and U29 mutants on the final c3 (each was run on its own commit's copy, where its block was added);
  the U24 and U29 blocks themselves pass on the final c3 (F5-*).
- I did not measure or change the other paths that write another appropriation's board into browser storage without marking
  its record (decision 4): by code only.
- I did not re-run the second builder's reproduction (kept; its logs are complete and on the same base blob). My focused runs
  on the base reproduce every defect the three blocks test.
- I did not change any existing check, fixture, expected value or mutation entry.
- I did not write the NEXT-VERSION.md or ledger text into any repository: they are drafts in `drafts/`.
- Waiting: two kinds of wait were not under `setsid -w timeout`: Monitor-tool watches (tool-bounded, at most 30 min; they
  read `logs/runs.txt` and `ps` only) and one background wait loop (Bash tool, 590 s cap) meant to start a lane through
  `bx.sh` once an earlier lane ended. That loop never ended (its own command line matched its `pgrep -f` pattern), started
  nothing, and was stopped through the tool as my own background task; I started the lane by hand (both noted in
  `logs/runs.txt`). Later waits were `setsid -w timeout -k 5 300|590 bash -c 'until …; do sleep 5; done'` loops that only
  read `ps` and `logs/runs.txt`; they are bounded but not recorded in `pids.txt`. Every node run and every other command went through
  `run.sh` or `bx.sh` (`setsid -w timeout -k 10 600`, its own process group, PIDs in `pids.txt`). Apart from stopping that
  waiting loop of mine through the tool, I stopped or killed nothing.
