# ADOPT track (U24, U29 with U17, U31): builder's record

Directory: `rec/L6/adopt` (absolute: `/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/adopt`).
Base (read-only): `rec/L6/base` = `git archive` of orbit-board `7ee498a` (product = `d66dd60`, U14): board `fce8a391`,
audit-import `4aba2506`, audit-recon `529e36f7`, audit-board `a7c575e5`, audit-other `d89396b0`, mutate.mjs.txt `cbc6defc`.
orbit-board's HEAD has moved since (to `6f5fc1b`, 28 commits), but by records only: `git diff --stat 7ee498a HEAD --
prioritization-board-grid.html tools/` is empty (checked read-only on 13 Oct, before the rebuild at 1:44 PM ET).

This README has two parts. **"Fix round (13 Oct)"** comes first and is current. **"Build record (12–13 Oct)"** below it is the
build's README unchanged; where the fix round changed something, the fix round says so and the build's text is superseded on
that point (its copies, blocks, entries, blobs, counts and drafts are kept in `superseded-r3/`).

Nothing was edited, staged, committed or pushed in `/home/user/orbit-board` or `/home/user/orbit-ui`. `mutate.mjs` was never
imported or run: entries were read as text only (`rec/bin/mcount.py`, `rec/bin/mkmut.py`, both `python3 -I`). No
`playwright install`, and no Chromium run was needed. The full audit-import and audit-board were not run (the lead's). Every
board stays the empty template; every fixture is synthetic and made at run time.

# Fix round (13 Oct)

Started at 1:32 PM ET on 13 Oct, after the two verifiers' verdicts (money lens: `wfstate/verify_adopt_r1_money.json`,
`verify-money-r1/`; tests lens: in the task, `verify-tests-r1/`). Both: "sound-with-issues". Base files re-hashed at 1:54 PM ET:
all six equal the blobs above.

**Resume check.** Nothing of an earlier fix-round attempt was in this directory: no copy, log, diff or draft dated after the
build (README.md, 12:00 AM ET on 13 Oct) other than the verifiers' own folders (`verify-money-r1/`, `verify-tests-r1/`) and
`wfstate/`; no "Fix round" section; no fix-round label in `logs/runs.txt`. So this fix round started from the build and kept
none of a stopped attempt (there was none). The verifiers' folders were read, never written.

**Kept from the build:** commit order and subjects; `bin/edit-c1.py` (commit 1's board change, unchanged: c1's board is still
`00c2ac15`); the U31 board change and block (only comments reworded); the 21 build entries (one find follows a changed line);
the reproduction on the base; the base's suite and preservation runs (the base is the same blob and the preservation harnesses
are byte-identical, below). **Superseded:** the build's c1–c3 (their suites and mutate files), harness/, mut/, blocks, entries,
diffs and drafts -- moved or copied to `superseded-r3/`, nothing deleted -- and every build run on those copies.

## What the verifiers found, and what this round did

| item | verifier | what was wrong | what this round did | where |
|---|---|---|---|---|
| **M1** | money | Working out of the folder, when the shared state file answers an opening before the folder is read, each opening re-loaded the very save on screen and counted it again (`loadedNotSaved` set DIRTY), so the opening's own refresh never loaded the folder's newer copy, and "reload to take theirs" was untrue. | **Fixed (commit 2).** The very save on screen (`+st.ts===+MS.ts`, its identity) is not another copy: `sharedArrived` loads it as before and does not count it. I chose this over the verifier's measured line (`if(... && baseGet().dirty) return;`, which skips only when the record is already unsaved), because the verifier's line leaves a second case counted: a board whose shared state file is its OWN save (📁 File → "download the .json state file" right after 💾 Save, the state-file workflow) answering an opening of a board recorded saved -- U29 as built marked it unsaved at every such opening (`LASTKNOWN=0`, so Save then asks "cannot tell"), measured: U29 (13) fails 3 checks on the build's c3 (FR-U29-on-c3build), in the file and the folder. Not counting the same save closes both, and in both keeps the base's behaviour for it exactly (loaded, said, not counted). Test: U29 (11) (P8, the verifier's route, with literals; 2 of its checks fail on the build's c3) and U29 (13) (the own-save case, a CONTROL: the base passes it; the build's c3 fails it). Mutation `v200-adopt-u29-same-save-recounted`. | `bin/edit-c2.py`; `block-u29.mjs.txt` (11), (13) |
| **M2** | money | In the clash line's new branch ("and that is not the copy you are working from"), the refresh still said "What is on screen does not have their changes", while the copy on screen came from one newer than the folder's and can hold them. | **Fixed (commit 2)**, the verifier's words: in that branch the refresh says "What is on screen came from another copy, which may not have their changes." The "after" branch and the refused (Save) branch are unchanged. Test: U29 (12) (P9, with the words checked both ways; its refresh check fails on the build's c3). Mutation `v200-adopt-u29-clash-lacks`. | `bin/edit-c2.py`; U29 (12) |
| **M3** | money | The U31 "What users may see" said a reopen now says unsaved where it said Saved; measured false (the header reads this session only: U15). The U31 block's and board's comments implied the same. | **Corrected.** Draft reworded to what changes (the record, and what an opening keeps); both comments say the header after a reopen reads this session only and says Saved either way (U15, unchanged). | drafts; `bin/edit-c3.py`; `block-u31.mjs.txt` header |
| **M1** | tests | No check drove the shared state file's own load SAVING TO THE BOARD FILE (SHaC file mode); the one-word wrong fix `loadedNotSaved(st, false)` survived every block. | **Fixed (test).** The verifier's scenario text, verbatim, as U29 (9); mutation `v200-adopt-u29-answer-file-kept` (its find follows the line's new form). Drafts now say which modes are covered. | U29 (9) |
| S1 | tests | No check drove the other-years loop of `loadedNotSaved`. | **Added**: G3 as U29 (10) (two years in the folder, the link, then Save on FY28); mutation `v200-adopt-u29-year-on-screen-only`. | U29 (10) |
| S2 | tests | U24 checked the `bootTakeFile` refusal only for a board-file save. | **Added**: G4 as U24 (7) (working out of the folder, a folder save held); mutation `v200-adopt-u24-takefile-guard-file-only`. | U24 (7) |
| S3 | tests | U24 never clicked the link during a save with nothing typed in the session. | **Added**: G1 as U24 (6); mutation `v200-adopt-u24-link-guard-dirty-only`. | U24 (6) |
| S4 | tests | Two draft claims untrue: U31's header claim (= money M3); "SHaC and BTC are covered". | **Corrected**: SHaC now covered in both modes (U29 (5), (9)); BTC's reopen is named as not covered (S5). | drafts |
| S5 | tests | After "open the file's version" in folder mode, a reopen from that same file records the board saved again (BT-fold-C1 K3). | **Stated, not changed.** The reopen's record comes from the opening's own rule -- the file's own save on screen is recorded saved (`fileTs===ours`) -- which is also what the opening that takes the file's newer version on its own does (the verifier's N7, base and fix alike: the U15–U20 family). Changing that rule is outside these three loads and wider than the finding (principle 5). Nothing is lost: the copy on screen is the board file's own save, so it stays in the file; the record still names no folder copy the screen did not come from, so a refresh offers the choice rather than loading the folder's older copy, and 💾 Save still asks, which U29 (6) checks. A folder copy NEWER than it would be loaded at that reopen with nothing kept aside -- the file's copy then only in the file, as for every opening the file's own save starts. Written into U29's "Not covered" and the ledger draft. | drafts |
| S1 | money | ⬅ Import a full board (and Import one appropriation, by code) leaves this appropriation's record clean: data loss next to U31, measured on the base and the build's c3 alike (P7-full). | **New ledger row drafted** (U31's shape, P2 provisional, fix pattern named); U31's "Not covered" corrected. Not changed: outside U31's finding (`importBoards`) and the lead's three fixes; it needs its own reproduction, block and mutations. | `drafts/LEDGER-append.md` |
| S2 / N4 | money / tests | audit-import base L3935 (v1.95 item 47, "the next refresh raises no false clash", `/after the copy you are working from/` absent) no longer sees a false clash in U29's second wording. | **Listed** (principle 6, below, and in U29's "Not covered"). Not edited, and no sibling check added to that existing block: a sibling (`/Save yours over theirs/` absent) passes on the base as well, so it would be a control in an old block, and the lead may prefer to add it there; offered below. | this README; drafts |
| S3 | money | U29's `LASTKNOWN=0` (file mode) silences the opening's "saved since then as well" notice, and Save's question says "cannot tell" where it could. | **Stated** in U29's "Not covered" (Save still asks; nothing lost). | drafts |
| N1 | tests | Nine new U24 checks pass on the base and were not labelled CONTROL. | **Labelled** in the block: "(a CONTROL)" on each, and on the (1) loop's refresh check only for (1Wread), "(a CONTROL here: …)". Labels only; no expectation changed. | `block-u24.mjs.txt` |
| N2 | tests | Wrong fixes on word-only paths survive (clash-vs-screen, count-before-apply, U31 other-before-checks / record-replaced). | **Not done**: no copy is lost on any of them; each needs a refused-load or refused-import route no block reaches. Listed under "not done". | -- |
| N5 | tests | The blocks add 2–6 minutes to a full audit-import. | Noted; the fix round adds about a fifth more checks (below). | -- |
| N6 | tests | The build ran its U24 entries on c1 only. | **Done**: every entry of all three commits is run on the final c3 (MF-c3-*), and the two new U24 entries on c1 too. | runs |
| N7 | tests | Folder mode: the opening that takes the board file's newer version on its own records the screen clean against the folder's copy (base and c3 alike). | Outside this track's three loads; named in U29's "Not covered" and the ledger draft (U15–U20 family). | drafts |
| minors | money | ↶ Put back's question after "load the shared one" (conservative, keeps); the U24 link gone after a non-quiet save; a quiet refresh changing the screen under a refusal a quiet autosave left; link-guard failing 20 checks on c3 against 18 on c1. | The middle two are now in U24's "Not covered". The first is safe (it keeps rather than drops) and unchanged. The 18/20 difference, read from the two runs' records (the build's M2-c1 and the tests verifier's V-M3-c3, both on the build's copies): on c3 the mutant's mid-save load is counted (U29), so at the reopen the shared state file is the very save on screen and is not offered again (4 checks fail only there), and the refresh holds off (2 checks fail only on c1). | -- |

## The fix round's board changes (all in commit 2, plus comments in commit 3)

Commit 1's board is unchanged (`00c2ac15`). Commit 2's board (`0bbfedb6`, was `d020543e`) against the build's:

```diff
@@ function driveClashSay(j, refused){
-    // v2.00 (U29): "after" only when it is. A copy loaded from elsewhere (loadedNotSaved) can be newer than the folder's.
+    // v2.00 (U29): "after" only when it is. A copy loaded from elsewhere (loadedNotSaved) can be newer than the folder's, and
+    // can hold their changes: then the words say only what is known.
     +' to the shared folder '+esc(liveAge(theirs))+(theirs>driveBaseOf(ap)? ', after the copy you are working from. ' : ', and that is not the copy you are working from. ')
-    +(refused? '<b>Nothing was written.</b> ' : 'What is on screen does not have their changes. ')
+    +(refused? '<b>Nothing was written.</b> ' : theirs>driveBaseOf(ap)? 'What is on screen does not have their changes. '
+      : 'What is on screen came from another copy, which may not have their changes. ')
@@ function sharedArrived(st){   (inside if((st.ts||0)>=(MS.ts||0)), after U24's guard)
+    // v2.00 (U29): the very save on screen (the same time: its identity) is not another copy. It loads as before and is not
+    // counted -- else every opening of a board whose shared state file is its own save would say unsaved, and, working out of
+    // the shared folder, would hold off the opening's own refresh, so the folder's newer copy never loaded.
+    const same=!!(+st.ts && +st.ts===+MS.ts);
     if(!sharedKeepMine(st)) return;
     if(applyStore(st)===false) return;
-    loadedNotSaved(st, true);               // v2.00 (U29): a change from what is saved (see adoptShared)
+    if(!same) loadedNotSaved(st, true);     // v2.00 (U29): a change from what is saved (see adoptShared)
```

`same` is read before `applyStore` (after it, `MS.ts` is always `st.ts`). Commit 3's board (`d1cdcdf5`, was `c0d14fcd`)
differs from the build's only in that commit-2 change and the U31 comment:

```diff
-    // edit. It was counted in this session only (lsSet): a reopen took the imported board as saved, the header said Saved, and
-    // a copy in the shared folder newer than it replaced it with nothing kept aside -- the import then only in the file it came from.
+    // edit. It was counted in this session only: a reopen took the imported board as saved, and a copy in the shared folder newer
+    // than it replaced it with nothing kept aside -- the import then only in the file it came from. (The header after a reopen
+    // reads this session only and says Saved either way: U15, unchanged.)
```

## The fix round's suite changes (pure insertions into each new block; no existing block touched)

- **U24 block**: (6) the link a refused answer offers, clicked while that save is still held, with nothing typed in this
  session (the verifier's G1, 3 checks); (7) "open the file's version" working out of the shared folder while a folder save is
  held (G4, 4 checks); the nine base-passing checks labelled CONTROL (N1); two header lines naming (6) and (7).
- **U29 block**: (9) SHaC saving to the board file (the verifier's text, verbatim; 5 checks); (10) two years in the folder
  (G3; 4); (11) the shared state file answering each opening before the folder is read (money P8; 4); (12) the shared state
  file built on the folder's own copy, then a refresh (money P9; 3); (13) the very save on screen, in the file and the folder
  (a CONTROL; 6); `sharedOf` takes an optional FY28 copy; `tsOf`; four header lines.
- **U31 block**: header comment only (M3).
- Every expected value is a hand-written literal; board helpers read observed values only. Every new check that is not
  marked a CONTROL fails on the base (below); the new CONTROLs pass on it.

## Mutation entries (the fix round's: 6 new, 1 find changed; 27 in all for the track)

New, inserted with their commit's entries before the R3 line: `v200-adopt-u24-link-guard-dirty-only`,
`v200-adopt-u24-takefile-guard-file-only` (commit 1; the verifier's text); `v200-adopt-u29-year-on-screen-only`,
`v200-adopt-u29-answer-file-kept` (commit 2; the verifier's, the second's find following the line's new form),
`v200-adopt-u29-same-save-recounted` (`const same=false;`), `v200-adopt-u29-clash-lacks` (the unconditional words back).
Changed find: `v200-adopt-u29-answer-uncounted` (the line it removes now reads `if(!same) loadedNotSaved(st, true);`).
All made by `bin/mk-entries.py`, each find asserted once on its own board.

## How each commit meets the lead's decision principles (fix round)

| principle | U24 | U29 | U31 |
|---|---|---|---|
| (1) never lose any copy | refused during any save, whatever was typed and wherever the save goes (now tested for both); nothing replaced | the person's own copy stays where it was saved until they choose, for every year (now tested); a reopen keeps the loaded copy aside before a saved copy replaces it, and that now happens at the opening the board said it would (11) | the import kept aside before a newer saved copy replaces it |
| (2) refuse or ask | refuses, says so | Save asks wherever the record cannot vouch; the very save on screen is not "another copy", so nothing needless is asked (13) | the record says unsaved: an opening keeps rather than guesses |
| (3) money and exports | untouched | untouched | untouched |
| (4) words true after landing | unchanged words; checked word for word | "reload to take theirs" is now true (11); the refresh no longer says the screen lacks changes it may hold (12); a board whose state file is its own save no longer says unsaved (13) | no new board words; the drafts no longer claim a header change (M3) |
| (5) smallest change | no board change this round | one read and one condition in `sharedArrived`; one condition in `driveClashSay` | comment only this round |
| (6) existing checks | no existing check, fixture or expected value edited (suite diffs are insertions only); see the list below | same | same |

**Principle 6, listed:** no existing line of any suite was removed or changed (diffs: audit-import +281/+321/+136, −0;
mutate +25/+49/+10, −0). One existing check is weaker in MEANING, not in text: **audit-import (base) line 3935**, v1.95 item
47, "the next refresh raises no false clash" -- old meaning: no clash line at all after the refresh (the clash line had one
wording); new meaning: no clash line of the "after the copy you are working from" kind (U29 adds ", and that is not the copy
you are working from."). Why it cannot be kept as it was: U29 must not say "after" where the folder's copy is older (principle
4). A sibling check `/Save yours over theirs/.test(H.status(R.ev))` → `false` beside it would restore the old meaning in
full; it passes on the base and on every copy here (by code: that scenario raises no clash on any of them), so it is a
control, offered for the lead to add to that block rather than added here. Lines 3618 and 7656 expect the "after" wording
where a colleague saved later, or its absence guarded by a status-line equality; both unchanged in meaning.

## Fix round: the three proposed commits (the lead commits; I did not)

Order unchanged, for the build's reasons: U24 first (the release blocker, U13's pattern, standalone); U29 second (it changes what a load records, which U24's refusal leaves untouched; its block fails identically on the base and on c1, below); U31 last (independent; its block fails identically on the base and on c2). Each copy is cumulative (`cp -a`, node_modules symlink kept, `chmod u+w`), built from the base by `rebuild-fr.sh`; only the board, `tools/export-audit/audit-import.mjs` and `tools/export-audit/mutate.mjs.txt` differ (`diff -rq`, `logs/rebuild-fr.log`).

| # | subject | copy | board | audit-import | mutate.mjs.txt | diff against the previous copy (blob; lines added/removed per file) |
|---|---|---|---|---|---|---|
| 1 | v2.00 U24: another copy is not put on screen during a save | `c1/` | `00c2ac152cd2f022efea656a3be40dca55c4ac8a` | `195381b5759e3f497c091a7a8cc0f95ef79e7089` | `8a7a83e84dfe85cc491e97a0b1bbc77c1e33302b` | `diffs/commit1-c1-vs-base.diff` (`f1bdf7ab`): board +30 −0, audit-import +281 −0, mutate +25 −0 |
| 2 | v2.00 U29 (with U24, closes U17): another copy put on screen is a change from what is saved | `c2/` | `0bbfedb6ca8e3115191fbd2b0c3260a5531a37e8` | `54efb128de20d0bfe41fc6b4857bcb2f7e24cffd` | `4a533f68073eaafad6b1a37f972fb1c345211bce` | `diffs/commit2-c2-vs-c1.diff` (`066ae150`): board +38 −6, audit-import +321 −0, mutate +49 −0 |
| 3 | v2.00 U31: a batch import marks this browser’s records unsaved | `c3/` | `d1cdcdf522be87f7ffd4e37236c84201873ae72c` | `fb163d3c64b8f2d682cad6a5debfe7c3d8f7727d` | `1fcc407eb435b0120d88a6448e6f282b6a41e2d2` | `diffs/commit3-c3-vs-c2.diff` (`5c7513e7`): board +10 −1, audit-import +136 −0, mutate +10 −0 |

All three: `diffs/all-c3-vs-base.diff` (`d6a9fded`): board +78 −7, audit-import +738 −0, mutate +84 −0. Every other file of each copy is the base's byte for byte.

## Fix round: runs (every run through run.sh: setsid -w timeout -k 10 600, the lock checked first, PIDs in pids.txt)

Lock: `AUDIT_IMPORT_RUNNING` was absent before every run: 0 runs of this round logged a wait or a skip. At most two node runs of mine ran at once (two lanes). Load average was about 30–45 on 4 CPUs throughout.

### Focused runs (harnesses built verbatim from each copy's own audit-import by `mk-harness.sh`; "on base"/"on c1"/"on c3build" = the carrying copy's harness with BOARD set to that board; c3build = the build's final c3 board `c0d14fcd`, `superseded-r3/c3`)

| label | start (ET) | exit | wall s | log |
|---|---|---|---|---|
| FR-U24-on-c1 | 2026-10-13 13:48:18 | 0 | 208.4 | logs/FR-U24-on-c1.log |
| FR-U29-on-c2 | 2026-10-13 13:48:18 | 0 | 234.1 | logs/FR-U29-on-c2.log |
| FR-U24-on-base | 2026-10-13 13:51:46 | 1 | 236.6 | logs/FR-U24-on-base.log |
| FR-U29-on-base | 2026-10-13 13:52:12 | 1 | 249.6 | logs/FR-U29-on-base.log |
| FR-U24-on-c2 | 2026-10-13 13:55:43 | 0 | 224.4 | logs/FR-U24-on-c2.log |
| FR-U29-on-c1 | 2026-10-13 13:56:22 | 1 | 240.8 | logs/FR-U29-on-c1.log |
| FR-U24-on-c3 | 2026-10-13 13:59:28 | 0 | 182.0 | logs/FR-U24-on-c3.log |
| FR-U29-on-c3build | 2026-10-13 14:00:23 | 1 | 194.2 | logs/FR-U29-on-c3build.log |
| FR-U31-on-c3 | 2026-10-13 14:02:41 | 0 | 101.1 | logs/FR-U31-on-c3.log |
| FR-U31-on-base | 2026-10-13 14:04:22 | 1 | 101.1 | logs/FR-U31-on-base.log |
| FR-U29-on-c3 | 2026-10-13 14:03:37 | 0 | 173.1 | logs/FR-U29-on-c3.log |
| FR-U31-on-c2 | 2026-10-13 14:06:03 | 1 | 117.0 | logs/FR-U31-on-c2.log |
| FR-syntax-c1 | 2026-10-13 15:15:24 | 0 | 0.5 | logs/FR-syntax-c1.log |
| FR-syntax-c2 | 2026-10-13 15:15:25 | 0 | 0.6 | logs/FR-syntax-c2.log |
| FR-syntax-c3 | 2026-10-13 15:15:26 | 0 | 0.5 | logs/FR-syntax-c3.log |

```
FR-U24-on-base: 65 checks, 33 failed
FR-U24-on-c1: 65 checks, 0 failed
FR-U24-on-c2: 65 checks, 0 failed
FR-U24-on-c3: 65 checks, 0 failed
FR-U29-on-base: 55 checks, 34 failed
FR-U29-on-c1: 55 checks, 34 failed
FR-U29-on-c2: 55 checks, 0 failed
FR-U29-on-c3: 55 checks, 0 failed
FR-U29-on-c3build: 55 checks, 6 failed
FR-U31-on-base: 34 checks, 14 failed
FR-U31-on-c2: 34 checks, 14 failed
FR-U31-on-c3: 34 checks, 0 failed
```

Against the build's runs of the same blocks (`bin/frcmp.py`: checks matched by scenario and label, "(a CONTROL…)" suffixes ignored, dates and clock times normalised):

```
F2-U24-on-base.checks.jsonl -> FR-U24-on-base.checks.jsonl: checks 58 -> 65, failing 28 -> 33; build's checks all present: True; build's failing set kept: True
F2-U24-on-c1.checks.jsonl -> FR-U24-on-c1.checks.jsonl: checks 58 -> 65, failing 0 -> 0; build's checks all present: True; build's failing set kept: True
F2-U24-on-c2.checks.jsonl -> FR-U24-on-c2.checks.jsonl: checks 58 -> 65, failing 0 -> 0; build's checks all present: True; build's failing set kept: True
F5-U24-on-c3.checks.jsonl -> FR-U24-on-c3.checks.jsonl: checks 58 -> 65, failing 0 -> 0; build's checks all present: True; build's failing set kept: True
F2-U29-on-base.checks.jsonl -> FR-U29-on-base.checks.jsonl: checks 33 -> 55, failing 24 -> 34; build's checks all present: True; build's failing set kept: True
F2-U29-on-c1.checks.jsonl -> FR-U29-on-c1.checks.jsonl: checks 33 -> 55, failing 24 -> 34; build's checks all present: True; build's failing set kept: True
F2-U29-on-c2.checks.jsonl -> FR-U29-on-c2.checks.jsonl: checks 33 -> 55, failing 0 -> 0; build's checks all present: True; build's failing set kept: True
F5-U29-on-c3.checks.jsonl -> FR-U29-on-c3.checks.jsonl: checks 33 -> 55, failing 0 -> 0; build's checks all present: True; build's failing set kept: True
F4-U31-on-base.checks.jsonl -> FR-U31-on-base.checks.jsonl: checks 34 -> 34, failing 14 -> 14; build's checks all present: True; build's failing set kept: True
F4-U31-on-c2.checks.jsonl -> FR-U31-on-c2.checks.jsonl: checks 34 -> 34, failing 14 -> 14; build's checks all present: True; build's failing set kept: True
F4-U31-on-c3.checks.jsonl -> FR-U31-on-c3.checks.jsonl: checks 34 -> 34, failing 0 -> 0; build's checks all present: True; build's failing set kept: True
FR-U29-on-base.checks.jsonl vs FR-U29-on-c1.checks.jsonl: checks 55/55, failing 34/34, same failing set: True, same observed values on them: False
FR-U31-on-base.checks.jsonl vs FR-U31-on-c2.checks.jsonl: checks 34/34, failing 14/14, same failing set: True, same observed values on them: True
```

(The base/c1 and base/c2 pairs fail the same checks; their observed values differ only in times and dates.) Every build check is still in each block, with the same verdict on each board. **The checks this round added**, with each board's verdict (a check that is not marked a CONTROL fails on the base; every CONTROL passes on it):

**U24** (7 new: (6) and (7)):

| scenario | check | base | c1 | c2 | c3 |
|---|---|---|---|---|---|
| (6) the link a refused answer offers, clicked wh… | the save is held; nothing typed in this session; the answer was refused and offers the link -- [held, a save under way, … | **FAIL** | pass | pass | pass |
| (6) the link a refused answer offers, clicked wh… | the link, clicked while the save is held, loads nothing -- [clicked, nothing changed byte for byte, said word for word] | **FAIL** | pass | pass | pass |
| (6) the link a refused answer offers, clicked wh… | once the save lands: BRAD-2 on screen and the folder’s copy; saved, recorded against it; nothing kept aside | **FAIL** | pass | pass | pass |
| (7) open the file’s version, working out of the … | BRAD-2 on screen, KEPT-0 kept aside, BRAD-1 the folder’s copy; the link offered (a CONTROL) | pass | pass | pass | pass |
| (7) open the file’s version, working out of the … | the save is held; BRAD-1 is still the folder’s copy (a CONTROL) | pass | pass | pass | pass |
| (7) open the file’s version, working out of the … | while the save is held, the link asks, then opens nothing -- [clicked, asked, a save under way, nothing changed byte for… | **FAIL** | pass | pass | pass |
| (7) open the file’s version, working out of the … | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in t… | **FAIL** | pass | pass | pass |

**U29** (22 new: (9)–(13)); c3build is the build's final c3, the board the verifiers checked:

| scenario | check | base | c1 | c3build | c2 | c3 |
|---|---|---|---|---|---|---|
| (9) the shared state file loaded on its own, fro… | BRAD-1 on screen, saved, recorded against the file (a CONTROL) | pass | pass | pass | pass | pass |
| (9) the shared state file loaded on its own, fro… | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved… | **FAIL** | **FAIL** | pass | pass | pass |
| (9) the shared state file loaded on its own, fro… | and the record names no save of the file as the one the screen came from -- [LASTKNOWN, the record’s file] | **FAIL** | **FAIL** | pass | pass | pass |
| (9) the shared state file loaded on its own, fro… | the next 💾 Save asks before it writes over BRAD-1; answered Cancel -- [asked, writes, the file, on screen, unsaved] | **FAIL** | **FAIL** | pass | pass | pass |
| (9) the shared state file loaded on its own, fro… | then reopened from the file: SHARED, newer than BRAD-1, stays on screen, unsaved by the record; BRAD-1 still in the file | **FAIL** | **FAIL** | pass | pass | pass |
| (10) the link, from a board recorded saved, two … | BRAD-1 on screen, saved; BRAD-28 the folder’s FY28 copy; the link offered (a CONTROL) | pass | pass | pass | pass | pass |
| (10) the link, from a board recorded saved, two … | the link loads SHARED (a CONTROL) | pass | pass | pass | pass | pass |
| (10) the link, from a board recorded saved, two … | FY28 on screen is SHARED-28 (a CONTROL) | pass | pass | pass | pass | pass |
| (10) the link, from a board recorded saved, two … | the FY28 💾 Save writes nothing over BRAD-28 and offers the choice -- [FY28 copy unchanged, Nothing was written, Save you… | **FAIL** | **FAIL** | pass | pass | pass |
| (11) the shared state file answers each opening … | BRAD-2 the folder’s copy; SHARED newer than BRAD-1 and older than BRAD-2 (a CONTROL) | pass | pass | pass | pass | pass |
| (11) the shared state file answers each opening … | opening 1, the answer first: SHARED loaded and counted; the connect does not load BRAD-2 over it, and says a reload take… | **FAIL** | **FAIL** | pass | pass | pass |
| (11) the shared state file answers each opening … | opening 2, the reload, the answer first: the very save on screen, loaded as before and not counted again -- [on screen, … | **FAIL** | **FAIL** | **FAIL** | pass | pass |
| (11) the shared state file answers each opening … | then its connect takes theirs, as the board said: BRAD-2 loaded, SHARED kept aside first; saved, recorded against BRAD-2… | **FAIL** | **FAIL** | **FAIL** | pass | pass |
| (12) the shared state file built on the folder’s… | Carol’s shared state file holds BRAD-2 and her note on B (a CONTROL) | pass | pass | pass | pass | pass |
| (12) the shared state file built on the folder’s… | it loads on its own, counted -- [on screen, B, unsaved (DIRTY, _baseDirty, the record)] | **FAIL** | **FAIL** | pass | pass | pass |
| (12) the shared state file built on the folder’s… | a refresh offers the choice, saying truly that the copy on screen came from another copy -- [not the copy you are workin… | **FAIL** | **FAIL** | **FAIL** | pass | pass |
| (13, file) the shared state file that is the ver… | BRAD-1 on screen, saved, recorded against the file; the shared state file is that same save (a CONTROL) | pass | pass | pass | pass | pass |
| (13, file) the shared state file that is the ver… | the answer is not counted: still saved, recorded against the file -- [on screen, saved, recorded, the change count moved… | pass | pass | **FAIL** | pass | pass |
| (13, file) the shared state file that is the ver… | the next 💾 Save asks nothing and writes it, saved -- [asked, the file, saved] (a CONTROL) | pass | pass | **FAIL** | pass | pass |
| (13, folder) the shared state file that is the v… | BRAD-1 on screen, saved, recorded against the folder; the shared state file is that same save (a CONTROL) | pass | pass | pass | pass | pass |
| (13, folder) the shared state file that is the v… | the answer is not counted: still saved, recorded against the folder -- [on screen, saved, recorded, the change count mov… | pass | pass | **FAIL** | pass | pass |
| (13, folder) the shared state file that is the v… | the next 💾 Save asks nothing and writes it, saved -- [asked, the folder, saved] (a CONTROL) | pass | pass | pass | pass | pass |

Every failing check of each focused run on an earlier board (`out/<label>.checks.jsonl` has every check, verdict and observed value):

```
FR-U24-on-base: 65 checks, 33 failed
   FAIL (1W) the link, while a save to the folder is held at the close of its write of the folder’s copy | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1W) the link, while a save to the folder is held at the close of its write of the folder’s copy | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (1W) the link, while a save to the folder is held at the close of its write of the folder’s copy | then a refresh loads nothing and changes nothing
   FAIL (1W) the link, while a save to the folder is held at the close of its write of the folder’s copy | then reopened (the opening’s connect, then a refresh): BRAD-2 on screen and the folder’s copy, saved, recorded against it; nothing kept aside
   FAIL (1Whist) the link, while a save to the folder is held at the close of its history copy | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Whist) the link, while a save to the folder is held at the close of its history copy | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (1Whist) the link, while a save to the folder is held at the close of its history copy | then a refresh loads nothing and changes nothing
   FAIL (1Whist) the link, while a save to the folder is held at the close of its history copy | then reopened (the opening’s connect, then a refresh): BRAD-2 on screen and the folder’s copy, saved, recorded against it; nothing kept aside
   FAIL (1Wread) the link, while a save to the folder is held at its read of the folder’s copy, before its bytes are built | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Wread) the link, while a save to the folder is held at its read of the folder’s copy, before its bytes are built | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (1Wread) the link, while a save to the folder is held at its read of the folder’s copy, before its bytes are built | then reopened (the opening’s connect, then a refresh): BRAD-2 on screen and the folder’s copy, saved, recorded against it; nothing kept aside
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | once the autosave lands, the refusal is still on screen, word for word, with its link -- [said, links, this browser’s record as it was when the link was refused]: the record has moved on under words that do not name it
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | then its link loads the shared state file, as it does with no save under way -- [clicked, on screen, the folder’s copy]
   FAIL (2) the link, while a save to the board file is held at the close of its write | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (2) the link, while a save to the board file is held at the close of its write | once the save lands: BRAD-2 on screen, in browser storage and the file; saved, recorded against the file; nothing kept aside
   FAIL (2) the link, while a save to the board file is held at the close of its write | then reopened from the file: BRAD-2 on screen, saved, recorded against the file; nothing kept aside
   FAIL (3a) the shared state file answers, stamped an hour ahead, while a save to the folder is held at its write | while the save is held, the answer loads nothing -- [a save under way, nothing changed byte for byte, said]
   FAIL (3a) the shared state file answers, stamped an hour ahead, while a save to the folder is held at its write | and it offers the link instead
   FAIL (3a) the shared state file answers, stamped an hour ahead, while a save to the folder is held at its write | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (3a) the shared state file answers, stamped an hour ahead, while a save to the folder is held at its write | then reopened (the opening’s connect): BRAD-2 on screen and the folder’s copy, saved, recorded against it; nothing kept aside
   FAIL (3b) the shared state file answers, stamped after the save began, while a save to the folder is held at its write | while the save is held, the answer loads nothing -- [a save under way, nothing changed byte for byte, said]
   FAIL (3b) the shared state file answers, stamped after the save began, while a save to the folder is held at its write | and it offers the link instead
   FAIL (3b) the shared state file answers, stamped after the save began, while a save to the folder is held at its write | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (3b) the shared state file answers, stamped after the save began, while a save to the folder is held at its write | then reopened (the opening’s connect): BRAD-2 on screen and the folder’s copy, saved, recorded against it; nothing kept aside
   FAIL (4) open the file’s version, while a save to the board file is held at the close of its write | while the save is held, the link asks, then opens nothing -- [clicked, asked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (4) open the file’s version, while a save to the board file is held at the close of its write | once the save lands: BRAD-2 on screen, in browser storage and the file; saved, recorded against the file; KEPT-0 still kept aside
   FAIL (6) the link a refused answer offers, clicked while that save to the folder is still held, nothing typed in this session | the save is held; nothing typed in this session; the answer was refused and offers the link -- [held, a save under way, DIRTY, links, on screen]
   FAIL (6) the link a refused answer offers, clicked while that save to the folder is still held, nothing typed in this session | the link, clicked while the save is held, loads nothing -- [clicked, nothing changed byte for byte, said word for word]
   FAIL (6) the link a refused answer offers, clicked while that save to the folder is still held, nothing typed in this session | once the save lands: BRAD-2 on screen and the folder’s copy; saved, recorded against it; nothing kept aside
   FAIL (7) open the file’s version, working out of the shared folder, while a save to the folder is held at its write | while the save is held, the link asks, then opens nothing -- [clicked, asked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (7) open the file’s version, working out of the shared folder, while a save to the folder is held at its write | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; KEPT-0 still kept aside
FR-U29-on-base: 55 checks, 34 failed
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | the link promises to keep aside what no saved copy has -- not "yours", which is in the folder’s copy and is not kept aside
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | it loads SHARED and counts it as a change -- [clicked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, the folder’s copy]
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | and the record no longer names the folder’s copy as the one the screen came from
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | the next 💾 Save writes nothing and asks -- [the folder’s copy, on screen, unsaved, nothing written, the choice offered, BRAD-2 said to be saved after the copy on screen]
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | then reopened: the opening loads BRAD-2, the folder’s copy, and keeps SHARED aside first -- both kept
   FAIL (2) the link, from a board recorded saved, saving to the board file | it loads SHARED and counts it as a change -- [clicked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, the file]
   FAIL (2) the link, from a board recorded saved, saving to the board file | and the record names no save of the file as the one the screen came from -- [LASTKNOWN, the record’s file]
   FAIL (2) the link, from a board recorded saved, saving to the board file | the next 💾 Save asks before it writes over BRAD-2; answered Cancel -- [asked, the question, writes, the file, on screen, unsaved, said]
   FAIL (2) the link, from a board recorded saved, saving to the board file | then reopened from the file: BRAD-2 opened, SHARED kept aside first -- both kept
   FAIL (2) the link, from a board recorded saved, saving to the board file | asked again and answered "overwrite anyway": SHARED written into the file, saved, recorded against it
   FAIL (3) the load after a save has landed, in the same session, working out of the shared folder | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside]
   FAIL (3) the load after a save has landed, in the same session, working out of the shared folder | the next 💾 Save writes nothing over BRAD-2 without a choice -- [the folder, on screen, unsaved, nothing written, the choice offered]
   FAIL (4) the load after a save has landed, in the same session, saving to the board file | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside]
   FAIL (4) the load after a save has landed, in the same session, saving to the board file | the next 💾 Save writes nothing over BRAD-2 without a choice -- [the file, on screen, unsaved, asked, canceled]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, said]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | a refresh loads nothing and does not take BRAD-1 as the copy the screen came from; it says the folder’s copy is not the one on screen
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | the Live autosave writes nothing over BRAD-1, and the choice is offered -- [the folder’s copy, on screen, unsaved, the choice offered, said truly]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | and so does 💾 Save
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | then reopened, the shared state file answering that opening too: SHARED on screen, still unsaved by the record; nothing kept aside, it being the very save on screen; BRAD-1 the folder’s copy
   FAIL (6) open the file’s version, working out of the shared folder | it asks once and opens CAROL-F, counted as a change -- [clicked, asked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, recorded as the file’s own save]
   FAIL (6) open the file’s version, working out of the shared folder | the next 💾 Save writes nothing over BRAD-1 and asks, saying truly that BRAD-1 is not the copy on screen
   FAIL (6) open the file’s version, working out of the shared folder | then reopened: CAROL-F on screen; the opening does not take BRAD-1 as the copy it came from, and 💾 Save still asks
   FAIL (7) the link with unsaved work, working out of the shared folder | the link’s promise names what it keeps aside
   FAIL (7) the link with unsaved work, working out of the shared folder | the next 💾 Save writes nothing over BRAD-1 and asks
   FAIL (9) the shared state file loaded on its own, from a board recorded saved, saving to the board file | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, said]
   FAIL (9) the shared state file loaded on its own, from a board recorded saved, saving to the board file | and the record names no save of the file as the one the screen came from -- [LASTKNOWN, the record’s file]
   FAIL (9) the shared state file loaded on its own, from a board recorded saved, saving to the board file | the next 💾 Save asks before it writes over BRAD-1; answered Cancel -- [asked, writes, the file, on screen, unsaved]
   FAIL (9) the shared state file loaded on its own, from a board recorded saved, saving to the board file | then reopened from the file: SHARED, newer than BRAD-1, stays on screen, unsaved by the record; BRAD-1 still in the file
   FAIL (10) the link, from a board recorded saved, two years in the shared folder, then 💾 Save on FY28 | the FY28 💾 Save writes nothing over BRAD-28 and offers the choice -- [FY28 copy unchanged, Nothing was written, Save yours over theirs]
   FAIL (11) the shared state file answers each opening before the folder is read, working out of the shared folder | opening 1, the answer first: SHARED loaded and counted; the connect does not load BRAD-2 over it, and says a reload takes theirs -- [on screen, kept aside, unsaved (DIRTY, _baseDirty, the record), said]
   FAIL (11) the shared state file answers each opening before the folder is read, working out of the shared folder | opening 2, the reload, the answer first: the very save on screen, loaded as before and not counted again -- [on screen, DIRTY, the record, the change count moved by, said]
   FAIL (11) the shared state file answers each opening before the folder is read, working out of the shared folder | then its connect takes theirs, as the board said: BRAD-2 loaded, SHARED kept aside first; saved, recorded against BRAD-2 -- [on screen, kept aside, saved, recorded against the folder’s copy, said]
   FAIL (12) the shared state file built on the folder’s copy, loaded on its own, then a refresh | it loads on its own, counted -- [on screen, B, unsaved (DIRTY, _baseDirty, the record)]
   FAIL (12) the shared state file built on the folder’s copy, loaded on its own, then a refresh | a refresh offers the choice, saying truly that the copy on screen came from another copy -- [not the copy you are working from, may not have their changes, does not have their changes, the choice offered, on screen]
FR-U29-on-c3build: 55 checks, 6 failed
   FAIL (11) the shared state file answers each opening before the folder is read, working out of the shared folder | opening 2, the reload, the answer first: the very save on screen, loaded as before and not counted again -- [on screen, DIRTY, the record, the change count moved by, said]
   FAIL (11) the shared state file answers each opening before the folder is read, working out of the shared folder | then its connect takes theirs, as the board said: BRAD-2 loaded, SHARED kept aside first; saved, recorded against BRAD-2 -- [on screen, kept aside, saved, recorded against the folder’s copy, said]
   FAIL (12) the shared state file built on the folder’s copy, loaded on its own, then a refresh | a refresh offers the choice, saying truly that the copy on screen came from another copy -- [not the copy you are working from, may not have their changes, does not have their changes, the choice offered, on screen]
   FAIL (13, file) the shared state file that is the very save on screen, answering an opening (a CONTROL) | the answer is not counted: still saved, recorded against the file -- [on screen, saved, recorded, the change count moved by, kept aside] (a CONTROL)
   FAIL (13, file) the shared state file that is the very save on screen, answering an opening (a CONTROL) | the next 💾 Save asks nothing and writes it, saved -- [asked, the file, saved] (a CONTROL)
   FAIL (13, folder) the shared state file that is the very save on screen, answering an opening (a CONTROL) | the answer is not counted: still saved, recorded against the folder -- [on screen, saved, recorded, the change count moved by, kept aside] (a CONTROL)
FR-U31-on-base: 34 checks, 14 failed
   FAIL (1, folder) an import newer than the saved copy, then a reopen | and this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (1, folder) an import newer than the saved copy, then a reopen | reopened: IMPORT on screen, unsaved by the record; nothing kept aside
   FAIL (2, folder) an import older than the saved copy, then a reopen | this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (2, folder) an import older than the saved copy, then a reopen | reopened: BRAD-1, the saved copy, on screen, saved and recorded against it; IMPORT kept aside first -- both kept
   FAIL (3, folder) an import while a save is held, on a board recorded saved, then a reopen | and this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (3, folder) an import while a save is held, on a board recorded saved, then a reopen | and this browser’s record still says it is unsaved -- [_baseDirty, the record]
   FAIL (3, folder) an import while a save is held, on a board recorded saved, then a reopen | reopened: BRAD-1, the saved copy stamped after the import, on screen, saved and recorded against it; IMPORT kept aside first -- both kept
   FAIL (1, file) an import newer than the saved copy, then a reopen | and this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (1, file) an import newer than the saved copy, then a reopen | reopened: IMPORT on screen, unsaved by the record; nothing kept aside
   FAIL (2, file) an import older than the saved copy, then a reopen | this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (2, file) an import older than the saved copy, then a reopen | reopened: BRAD-1, the saved copy, on screen, saved and recorded against it; IMPORT kept aside first -- both kept
   FAIL (4a) another appropriation the batch wrote, its own record saying it is the file’s own save | and Full Fund’s own record says unsaved
   FAIL (4a) another appropriation the batch wrote, its own record saying it is the file’s own save | switched to Full Fund: the file’s newer (OLD) Full Fund on screen, the imported (NEW) one kept aside first -- both kept
   FAIL (4b) another appropriation the batch wrote, with no record of its own | and Full Fund’s own record says unsaved (made by the import)
```

The nine U24 checks the tests verifier listed (N1) are now labelled CONTROL; with them, every U24 check that passes on the base is either labelled a CONTROL or in the "(5) CONTROLS" scenarios ((5a)–(5c), whose four checks are as the build wrote them).

### Mutants (made by mkmut.py from the copy's own mutate.mjs.txt, read as text; the copy's focused harness of the entry's block run on it)

MF-c3-*: every entry of all three commits on the final c3; MF-c1-*: the two new U24 entries on c1, commit 1's own copy.

| label | start (ET) | exit | wall s | log |
|---|---|---|---|---|
| MF-c3-v200-adopt-u29-no-count | 2026-10-13 14:06:42 | 1 | 183.1 | logs/MF-c3-v200-adopt-u29-no-count.log |
| MF-c3-v200-adopt-u24-link-guard | 2026-10-13 14:08:01 | 1 | 233.8 | logs/MF-c3-v200-adopt-u24-link-guard.log |
| MF-c3-v200-adopt-u29-session-clean | 2026-10-13 14:09:46 | 1 | 223.5 | logs/MF-c3-v200-adopt-u29-session-clean.log |
| MF-c3-v200-adopt-u24-answer-guard | 2026-10-13 14:11:55 | 1 | 171.3 | logs/MF-c3-v200-adopt-u24-answer-guard.log |
| MF-c3-v200-adopt-u29-record-clean | 2026-10-13 14:13:30 | 1 | 183.1 | logs/MF-c3-v200-adopt-u29-record-clean.log |
| MF-c3-v200-adopt-u24-file-guard | 2026-10-13 14:14:47 | 1 | 218.3 | logs/MF-c3-v200-adopt-u24-file-guard.log |
| MF-c3-v200-adopt-u29-file-base-kept | 2026-10-13 14:16:34 | 1 | 249.5 | logs/MF-c3-v200-adopt-u29-file-base-kept.log |
| MF-c3-v200-adopt-u24-link-words-later | 2026-10-13 14:18:27 | 1 | 189.3 | logs/MF-c3-v200-adopt-u24-link-words-later.log |
| MF-c3-v200-adopt-u29-folder-base-kept | 2026-10-13 14:20:44 | 1 | 158.5 | logs/MF-c3-v200-adopt-u29-folder-base-kept.log |
| MF-c3-v200-adopt-u24-link-words-record | 2026-10-13 14:21:37 | 1 | 163.5 | logs/MF-c3-v200-adopt-u24-link-words-record.log |
| MF-c3-v200-adopt-u29-year-on-screen-only | 2026-10-13 14:23:24 | 1 | 181.4 | logs/MF-c3-v200-adopt-u29-year-on-screen-only.log |
| MF-c3-v200-adopt-u24-file-words-record | 2026-10-13 14:24:21 | 1 | 198.2 | logs/MF-c3-v200-adopt-u24-file-words-record.log |
| MF-c3-v200-adopt-u29-link-uncounted | 2026-10-13 14:26:26 | 1 | 247.4 | logs/MF-c3-v200-adopt-u29-link-uncounted.log |
| MF-c3-v200-adopt-u24-link-guard-dirty-only | 2026-10-13 14:27:40 | 1 | 189.0 | logs/MF-c3-v200-adopt-u24-link-guard-dirty-only.log |
| MF-c3-v200-adopt-u29-answer-uncounted | 2026-10-13 14:30:34 | 1 | 99.3 | logs/MF-c3-v200-adopt-u29-answer-uncounted.log |
| MF-c3-v200-adopt-u24-takefile-guard-file-only | 2026-10-13 14:30:49 | 1 | 91.6 | logs/MF-c3-v200-adopt-u24-takefile-guard-file-only.log |
| MF-c3-v200-adopt-u31-no-mark | 2026-10-13 14:32:22 | 1 | 60.4 | logs/MF-c3-v200-adopt-u31-no-mark.log |
| MF-c3-v200-adopt-u29-answer-file-kept | 2026-10-13 14:32:14 | 1 | 97.8 | logs/MF-c3-v200-adopt-u29-answer-file-kept.log |
| MF-c3-v200-adopt-u31-memory-only | 2026-10-13 14:33:22 | 1 | 49.2 | logs/MF-c3-v200-adopt-u31-memory-only.log |
| MF-c3-v200-adopt-u31-other-unmarked | 2026-10-13 14:34:12 | 1 | 38.8 | logs/MF-c3-v200-adopt-u31-other-unmarked.log |
| MF-c3-v200-adopt-u29-same-save-recounted | 2026-10-13 14:33:52 | 1 | 68.3 | logs/MF-c3-v200-adopt-u29-same-save-recounted.log |
| MF-c1-v200-adopt-u24-link-guard-dirty-only | 2026-10-13 14:34:51 | 1 | 71.0 | logs/MF-c1-v200-adopt-u24-link-guard-dirty-only.log |
| MF-c3-v200-adopt-u29-takefile-uncounted | 2026-10-13 14:35:01 | 1 | 87.1 | logs/MF-c3-v200-adopt-u29-takefile-uncounted.log |
| MF-c1-v200-adopt-u24-takefile-guard-file-only | 2026-10-13 14:36:03 | 1 | 82.7 | logs/MF-c1-v200-adopt-u24-takefile-guard-file-only.log |
| MF-c3-v200-adopt-u29-same-save-kept | 2026-10-13 14:36:28 | 1 | 85.9 | logs/MF-c3-v200-adopt-u29-same-save-kept.log |
| MF-c3-v200-adopt-u29-clash-after | 2026-10-13 14:37:55 | 1 | 95.1 | logs/MF-c3-v200-adopt-u29-clash-after.log |
| MF-c3-v200-adopt-u29-clash-lacks | 2026-10-13 14:39:30 | 1 | 96.6 | logs/MF-c3-v200-adopt-u29-clash-lacks.log |
| MF-c3-v200-adopt-u29-promise-yours | 2026-10-13 14:41:07 | 1 | 62.5 | logs/MF-c3-v200-adopt-u29-promise-yours.log |
| MF-c3-v200-adopt-u29-promise-what-you-have | 2026-10-13 14:42:10 | 1 | 71.9 | logs/MF-c3-v200-adopt-u29-promise-what-you-have.log |

Each mutant, its failing checks (`out/MF-*.checks.jsonl`):

```
MF-c1-v200-adopt-u24-link-guard-dirty-only: 65 checks, 2 failed
   FAIL (6) the link a refused answer offers, clicked while that save to the folder is still held, nothing typed in this session | the link, clicked while the save is held, loads nothing -- [clicked, nothing changed byte for byte, said word for word]
   FAIL (6) the link a refused answer offers, clicked while that save to the folder is still held, nothing typed in this session | once the save lands: BRAD-2 on screen and the folder’s copy; saved, recorded against it; nothing kept aside
MF-c1-v200-adopt-u24-takefile-guard-file-only: 65 checks, 2 failed
   FAIL (7) open the file’s version, working out of the shared folder, while a save to the folder is held at its write | while the save is held, the link asks, then opens nothing -- [clicked, asked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (7) open the file’s version, working out of the shared folder, while a save to the folder is held at its write | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; KEPT-0 still kept aside
MF-c3-v200-adopt-u24-answer-guard: 65 checks, 11 failed
   FAIL (3a) the shared state file answers, stamped an hour ahead, while a save to the folder is held at its write | while the save is held, the answer loads nothing -- [a save under way, nothing changed byte for byte, said]
   FAIL (3a) the shared state file answers, stamped an hour ahead, while a save to the folder is held at its write | and it offers the link instead
   FAIL (3a) the shared state file answers, stamped an hour ahead, while a save to the folder is held at its write | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (3a) the shared state file answers, stamped an hour ahead, while a save to the folder is held at its write | then reopened (the opening’s connect): BRAD-2 on screen and the folder’s copy, saved, recorded against it; nothing kept aside
   FAIL (3b) the shared state file answers, stamped after the save began, while a save to the folder is held at its write | while the save is held, the answer loads nothing -- [a save under way, nothing changed byte for byte, said]
   FAIL (3b) the shared state file answers, stamped after the save began, while a save to the folder is held at its write | and it offers the link instead
   FAIL (3b) the shared state file answers, stamped after the save began, while a save to the folder is held at its write | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (3b) the shared state file answers, stamped after the save began, while a save to the folder is held at its write | then reopened (the opening’s connect): BRAD-2 on screen and the folder’s copy, saved, recorded against it; nothing kept aside
   FAIL (6) the link a refused answer offers, clicked while that save to the folder is still held, nothing typed in this session | the save is held; nothing typed in this session; the answer was refused and offers the link -- [held, a save under way, DIRTY, links, on screen]
   FAIL (6) the link a refused answer offers, clicked while that save to the folder is still held, nothing typed in this session | the link, clicked while the save is held, loads nothing -- [clicked, nothing changed byte for byte, said word for word]
   FAIL (6) the link a refused answer offers, clicked while that save to the folder is still held, nothing typed in this session | once the save lands: BRAD-2 on screen and the folder’s copy; saved, recorded against it; nothing kept aside
MF-c3-v200-adopt-u24-file-guard: 65 checks, 4 failed
   FAIL (4) open the file’s version, while a save to the board file is held at the close of its write | while the save is held, the link asks, then opens nothing -- [clicked, asked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (4) open the file’s version, while a save to the board file is held at the close of its write | once the save lands: BRAD-2 on screen, in browser storage and the file; saved, recorded against the file; KEPT-0 still kept aside
   FAIL (7) open the file’s version, working out of the shared folder, while a save to the folder is held at its write | while the save is held, the link asks, then opens nothing -- [clicked, asked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (7) open the file’s version, working out of the shared folder, while a save to the folder is held at its write | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; KEPT-0 still kept aside
MF-c3-v200-adopt-u24-file-words-record: 65 checks, 2 failed
   FAIL (4) open the file’s version, while a save to the board file is held at the close of its write | while the save is held, the link asks, then opens nothing -- [clicked, asked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (7) open the file’s version, working out of the shared folder, while a save to the folder is held at its write | while the save is held, the link asks, then opens nothing -- [clicked, asked, a save under way, nothing changed byte for byte, said word for word]
MF-c3-v200-adopt-u24-link-guard-dirty-only: 65 checks, 2 failed
   FAIL (6) the link a refused answer offers, clicked while that save to the folder is still held, nothing typed in this session | the link, clicked while the save is held, loads nothing -- [clicked, nothing changed byte for byte, said word for word]
   FAIL (6) the link a refused answer offers, clicked while that save to the folder is still held, nothing typed in this session | once the save lands: BRAD-2 on screen and the folder’s copy; saved, recorded against it; nothing kept aside
MF-c3-v200-adopt-u24-link-guard: 65 checks, 22 failed
   FAIL (1W) the link, while a save to the folder is held at the close of its write of the folder’s copy | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1W) the link, while a save to the folder is held at the close of its write of the folder’s copy | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (1W) the link, while a save to the folder is held at the close of its write of the folder’s copy | then reopened (the opening’s connect, then a refresh): BRAD-2 on screen and the folder’s copy, saved, recorded against it; nothing kept aside
   FAIL (1W) the link, while a save to the folder is held at the close of its write of the folder’s copy | and the shared state file, answering that opening, is offered again (a CONTROL)
   FAIL (1Whist) the link, while a save to the folder is held at the close of its history copy | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Whist) the link, while a save to the folder is held at the close of its history copy | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (1Whist) the link, while a save to the folder is held at the close of its history copy | then reopened (the opening’s connect, then a refresh): BRAD-2 on screen and the folder’s copy, saved, recorded against it; nothing kept aside
   FAIL (1Whist) the link, while a save to the folder is held at the close of its history copy | and the shared state file, answering that opening, is offered again (a CONTROL)
   FAIL (1Wread) the link, while a save to the folder is held at its read of the folder’s copy, before its bytes are built | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Wread) the link, while a save to the folder is held at its read of the folder’s copy, before its bytes are built | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (1Wread) the link, while a save to the folder is held at its read of the folder’s copy, before its bytes are built | then reopened (the opening’s connect, then a refresh): BRAD-2 on screen and the folder’s copy, saved, recorded against it; nothing kept aside
   FAIL (1Wread) the link, while a save to the folder is held at its read of the folder’s copy, before its bytes are built | and the shared state file, answering that opening, is offered again (a CONTROL)
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | once the autosave lands, the refusal is still on screen, word for word, with its link -- [said, links, this browser’s record as it was when the link was refused]: the record has moved on under words that do not name it
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | then its link loads the shared state file, as it does with no save under way -- [clicked, on screen, the folder’s copy]
   FAIL (2) the link, while a save to the board file is held at the close of its write | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (2) the link, while a save to the board file is held at the close of its write | once the save lands: BRAD-2 on screen, in browser storage and the file; saved, recorded against the file; nothing kept aside
   FAIL (2) the link, while a save to the board file is held at the close of its write | then reopened from the file: BRAD-2 on screen, saved, recorded against the file; nothing kept aside
   FAIL (2) the link, while a save to the board file is held at the close of its write | and the shared state file, answering that opening, is offered again (a CONTROL)
   FAIL (6) the link a refused answer offers, clicked while that save to the folder is still held, nothing typed in this session | the link, clicked while the save is held, loads nothing -- [clicked, nothing changed byte for byte, said word for word]
   FAIL (6) the link a refused answer offers, clicked while that save to the folder is still held, nothing typed in this session | once the save lands: BRAD-2 on screen and the folder’s copy; saved, recorded against it; nothing kept aside
MF-c3-v200-adopt-u24-link-words-later: 65 checks, 7 failed
   FAIL (1W) the link, while a save to the folder is held at the close of its write of the folder’s copy | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Whist) the link, while a save to the folder is held at the close of its history copy | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Wread) the link, while a save to the folder is held at its read of the folder’s copy, before its bytes are built | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | once the autosave lands, the refusal is still on screen, word for word, with its link -- [said, links, this browser’s record as it was when the link was refused]: the record has moved on under words that do not name it
   FAIL (2) the link, while a save to the board file is held at the close of its write | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (6) the link a refused answer offers, clicked while that save to the folder is still held, nothing typed in this session | the link, clicked while the save is held, loads nothing -- [clicked, nothing changed byte for byte, said word for word]
MF-c3-v200-adopt-u24-link-words-record: 65 checks, 7 failed
   FAIL (1W) the link, while a save to the folder is held at the close of its write of the folder’s copy | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Whist) the link, while a save to the folder is held at the close of its history copy | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Wread) the link, while a save to the folder is held at its read of the folder’s copy, before its bytes are built | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | once the autosave lands, the refusal is still on screen, word for word, with its link -- [said, links, this browser’s record as it was when the link was refused]: the record has moved on under words that do not name it
   FAIL (2) the link, while a save to the board file is held at the close of its write | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (6) the link a refused answer offers, clicked while that save to the folder is still held, nothing typed in this session | the link, clicked while the save is held, loads nothing -- [clicked, nothing changed byte for byte, said word for word]
MF-c3-v200-adopt-u24-takefile-guard-file-only: 65 checks, 2 failed
   FAIL (7) open the file’s version, working out of the shared folder, while a save to the folder is held at its write | while the save is held, the link asks, then opens nothing -- [clicked, asked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (7) open the file’s version, working out of the shared folder, while a save to the folder is held at its write | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; KEPT-0 still kept aside
MF-c3-v200-adopt-u29-answer-file-kept: 55 checks, 3 failed
   FAIL (9) the shared state file loaded on its own, from a board recorded saved, saving to the board file | and the record names no save of the file as the one the screen came from -- [LASTKNOWN, the record’s file]
   FAIL (9) the shared state file loaded on its own, from a board recorded saved, saving to the board file | the next 💾 Save asks before it writes over BRAD-1; answered Cancel -- [asked, writes, the file, on screen, unsaved]
   FAIL (9) the shared state file loaded on its own, from a board recorded saved, saving to the board file | then reopened from the file: SHARED, newer than BRAD-1, stays on screen, unsaved by the record; BRAD-1 still in the file
MF-c3-v200-adopt-u29-answer-uncounted: 55 checks, 14 failed
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, said]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | a refresh loads nothing and does not take BRAD-1 as the copy the screen came from; it says the folder’s copy is not the one on screen
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | the Live autosave writes nothing over BRAD-1, and the choice is offered -- [the folder’s copy, on screen, unsaved, the choice offered, said truly]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | and so does 💾 Save
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | then reopened, the shared state file answering that opening too: SHARED on screen, still unsaved by the record; nothing kept aside, it being the very save on screen; BRAD-1 the folder’s copy
   FAIL (9) the shared state file loaded on its own, from a board recorded saved, saving to the board file | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, said]
   FAIL (9) the shared state file loaded on its own, from a board recorded saved, saving to the board file | and the record names no save of the file as the one the screen came from -- [LASTKNOWN, the record’s file]
   FAIL (9) the shared state file loaded on its own, from a board recorded saved, saving to the board file | the next 💾 Save asks before it writes over BRAD-1; answered Cancel -- [asked, writes, the file, on screen, unsaved]
   FAIL (9) the shared state file loaded on its own, from a board recorded saved, saving to the board file | then reopened from the file: SHARED, newer than BRAD-1, stays on screen, unsaved by the record; BRAD-1 still in the file
   FAIL (11) the shared state file answers each opening before the folder is read, working out of the shared folder | opening 1, the answer first: SHARED loaded and counted; the connect does not load BRAD-2 over it, and says a reload takes theirs -- [on screen, kept aside, unsaved (DIRTY, _baseDirty, the record), said]
   FAIL (11) the shared state file answers each opening before the folder is read, working out of the shared folder | opening 2, the reload, the answer first: the very save on screen, loaded as before and not counted again -- [on screen, DIRTY, the record, the change count moved by, said]
   FAIL (11) the shared state file answers each opening before the folder is read, working out of the shared folder | then its connect takes theirs, as the board said: BRAD-2 loaded, SHARED kept aside first; saved, recorded against BRAD-2 -- [on screen, kept aside, saved, recorded against the folder’s copy, said]
   FAIL (12) the shared state file built on the folder’s copy, loaded on its own, then a refresh | it loads on its own, counted -- [on screen, B, unsaved (DIRTY, _baseDirty, the record)]
   FAIL (12) the shared state file built on the folder’s copy, loaded on its own, then a refresh | a refresh offers the choice, saying truly that the copy on screen came from another copy -- [not the copy you are working from, may not have their changes, does not have their changes, the choice offered, on screen]
MF-c3-v200-adopt-u29-clash-after: 55 checks, 5 failed
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | a refresh loads nothing and does not take BRAD-1 as the copy the screen came from; it says the folder’s copy is not the one on screen
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | the Live autosave writes nothing over BRAD-1, and the choice is offered -- [the folder’s copy, on screen, unsaved, the choice offered, said truly]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | and so does 💾 Save
   FAIL (6) open the file’s version, working out of the shared folder | the next 💾 Save writes nothing over BRAD-1 and asks, saying truly that BRAD-1 is not the copy on screen
   FAIL (12) the shared state file built on the folder’s copy, loaded on its own, then a refresh | a refresh offers the choice, saying truly that the copy on screen came from another copy -- [not the copy you are working from, may not have their changes, does not have their changes, the choice offered, on screen]
MF-c3-v200-adopt-u29-clash-lacks: 55 checks, 1 failed
   FAIL (12) the shared state file built on the folder’s copy, loaded on its own, then a refresh | a refresh offers the choice, saying truly that the copy on screen came from another copy -- [not the copy you are working from, may not have their changes, does not have their changes, the choice offered, on screen]
MF-c3-v200-adopt-u29-file-base-kept: 55 checks, 8 failed
   FAIL (2) the link, from a board recorded saved, saving to the board file | and the record names no save of the file as the one the screen came from -- [LASTKNOWN, the record’s file]
   FAIL (2) the link, from a board recorded saved, saving to the board file | the next 💾 Save asks before it writes over BRAD-2; answered Cancel -- [asked, the question, writes, the file, on screen, unsaved, said]
   FAIL (2) the link, from a board recorded saved, saving to the board file | then reopened from the file: BRAD-2 opened, SHARED kept aside first -- both kept
   FAIL (2) the link, from a board recorded saved, saving to the board file | asked again and answered "overwrite anyway": SHARED written into the file, saved, recorded against it
   FAIL (4) the load after a save has landed, in the same session, saving to the board file | the next 💾 Save writes nothing over BRAD-2 without a choice -- [the file, on screen, unsaved, asked, canceled]
   FAIL (9) the shared state file loaded on its own, from a board recorded saved, saving to the board file | and the record names no save of the file as the one the screen came from -- [LASTKNOWN, the record’s file]
   FAIL (9) the shared state file loaded on its own, from a board recorded saved, saving to the board file | the next 💾 Save asks before it writes over BRAD-1; answered Cancel -- [asked, writes, the file, on screen, unsaved]
   FAIL (9) the shared state file loaded on its own, from a board recorded saved, saving to the board file | then reopened from the file: SHARED, newer than BRAD-1, stays on screen, unsaved by the record; BRAD-1 still in the file
MF-c3-v200-adopt-u29-folder-base-kept: 55 checks, 13 failed
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | and the record no longer names the folder’s copy as the one the screen came from
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | the next 💾 Save writes nothing and asks -- [the folder’s copy, on screen, unsaved, nothing written, the choice offered, BRAD-2 said to be saved after the copy on screen]
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | then reopened: the opening loads BRAD-2, the folder’s copy, and keeps SHARED aside first -- both kept
   FAIL (3) the load after a save has landed, in the same session, working out of the shared folder | the next 💾 Save writes nothing over BRAD-2 without a choice -- [the folder, on screen, unsaved, nothing written, the choice offered]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | a refresh loads nothing and does not take BRAD-1 as the copy the screen came from; it says the folder’s copy is not the one on screen
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | the Live autosave writes nothing over BRAD-1, and the choice is offered -- [the folder’s copy, on screen, unsaved, the choice offered, said truly]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | and so does 💾 Save
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | then reopened, the shared state file answering that opening too: SHARED on screen, still unsaved by the record; nothing kept aside, it being the very save on screen; BRAD-1 the folder’s copy
   FAIL (6) open the file’s version, working out of the shared folder | the next 💾 Save writes nothing over BRAD-1 and asks, saying truly that BRAD-1 is not the copy on screen
   FAIL (6) open the file’s version, working out of the shared folder | then reopened: CAROL-F on screen; the opening does not take BRAD-1 as the copy it came from, and 💾 Save still asks
   FAIL (7) the link with unsaved work, working out of the shared folder | the next 💾 Save writes nothing over BRAD-1 and asks
   FAIL (10) the link, from a board recorded saved, two years in the shared folder, then 💾 Save on FY28 | the FY28 💾 Save writes nothing over BRAD-28 and offers the choice -- [FY28 copy unchanged, Nothing was written, Save yours over theirs]
   FAIL (12) the shared state file built on the folder’s copy, loaded on its own, then a refresh | a refresh offers the choice, saying truly that the copy on screen came from another copy -- [not the copy you are working from, may not have their changes, does not have their changes, the choice offered, on screen]
MF-c3-v200-adopt-u29-link-uncounted: 55 checks, 15 failed
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | it loads SHARED and counts it as a change -- [clicked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, the folder’s copy]
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | and the record no longer names the folder’s copy as the one the screen came from
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | the next 💾 Save writes nothing and asks -- [the folder’s copy, on screen, unsaved, nothing written, the choice offered, BRAD-2 said to be saved after the copy on screen]
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | then reopened: the opening loads BRAD-2, the folder’s copy, and keeps SHARED aside first -- both kept
   FAIL (2) the link, from a board recorded saved, saving to the board file | it loads SHARED and counts it as a change -- [clicked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, the file]
   FAIL (2) the link, from a board recorded saved, saving to the board file | and the record names no save of the file as the one the screen came from -- [LASTKNOWN, the record’s file]
   FAIL (2) the link, from a board recorded saved, saving to the board file | the next 💾 Save asks before it writes over BRAD-2; answered Cancel -- [asked, the question, writes, the file, on screen, unsaved, said]
   FAIL (2) the link, from a board recorded saved, saving to the board file | then reopened from the file: BRAD-2 opened, SHARED kept aside first -- both kept
   FAIL (2) the link, from a board recorded saved, saving to the board file | asked again and answered "overwrite anyway": SHARED written into the file, saved, recorded against it
   FAIL (3) the load after a save has landed, in the same session, working out of the shared folder | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside]
   FAIL (3) the load after a save has landed, in the same session, working out of the shared folder | the next 💾 Save writes nothing over BRAD-2 without a choice -- [the folder, on screen, unsaved, nothing written, the choice offered]
   FAIL (4) the load after a save has landed, in the same session, saving to the board file | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside]
   FAIL (4) the load after a save has landed, in the same session, saving to the board file | the next 💾 Save writes nothing over BRAD-2 without a choice -- [the file, on screen, unsaved, asked, canceled]
   FAIL (7) the link with unsaved work, working out of the shared folder | the next 💾 Save writes nothing over BRAD-1 and asks
   FAIL (10) the link, from a board recorded saved, two years in the shared folder, then 💾 Save on FY28 | the FY28 💾 Save writes nothing over BRAD-28 and offers the choice -- [FY28 copy unchanged, Nothing was written, Save yours over theirs]
MF-c3-v200-adopt-u29-no-count: 55 checks, 7 failed
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | it loads SHARED and counts it as a change -- [clicked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, the folder’s copy]
   FAIL (2) the link, from a board recorded saved, saving to the board file | it loads SHARED and counts it as a change -- [clicked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, the file]
   FAIL (3) the load after a save has landed, in the same session, working out of the shared folder | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside]
   FAIL (4) the load after a save has landed, in the same session, saving to the board file | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, said]
   FAIL (6) open the file’s version, working out of the shared folder | it asks once and opens CAROL-F, counted as a change -- [clicked, asked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, recorded as the file’s own save]
   FAIL (9) the shared state file loaded on its own, from a board recorded saved, saving to the board file | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, said]
MF-c3-v200-adopt-u29-promise-what-you-have: 55 checks, 1 failed
   FAIL (7) the link with unsaved work, working out of the shared folder | the link’s promise names what it keeps aside
MF-c3-v200-adopt-u29-promise-yours: 55 checks, 1 failed
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | the link promises to keep aside what no saved copy has -- not "yours", which is in the folder’s copy and is not kept aside
MF-c3-v200-adopt-u29-record-clean: 55 checks, 15 failed
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | it loads SHARED and counts it as a change -- [clicked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, the folder’s copy]
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | then reopened: the opening loads BRAD-2, the folder’s copy, and keeps SHARED aside first -- both kept
   FAIL (2) the link, from a board recorded saved, saving to the board file | it loads SHARED and counts it as a change -- [clicked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, the file]
   FAIL (2) the link, from a board recorded saved, saving to the board file | then reopened from the file: BRAD-2 opened, SHARED kept aside first -- both kept
   FAIL (3) the load after a save has landed, in the same session, working out of the shared folder | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside]
   FAIL (4) the load after a save has landed, in the same session, saving to the board file | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, said]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | then reopened, the shared state file answering that opening too: SHARED on screen, still unsaved by the record; nothing kept aside, it being the very save on screen; BRAD-1 the folder’s copy
   FAIL (6) open the file’s version, working out of the shared folder | it asks once and opens CAROL-F, counted as a change -- [clicked, asked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, recorded as the file’s own save]
   FAIL (9) the shared state file loaded on its own, from a board recorded saved, saving to the board file | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, said]
   FAIL (9) the shared state file loaded on its own, from a board recorded saved, saving to the board file | then reopened from the file: SHARED, newer than BRAD-1, stays on screen, unsaved by the record; BRAD-1 still in the file
   FAIL (11) the shared state file answers each opening before the folder is read, working out of the shared folder | opening 1, the answer first: SHARED loaded and counted; the connect does not load BRAD-2 over it, and says a reload takes theirs -- [on screen, kept aside, unsaved (DIRTY, _baseDirty, the record), said]
   FAIL (11) the shared state file answers each opening before the folder is read, working out of the shared folder | opening 2, the reload, the answer first: the very save on screen, loaded as before and not counted again -- [on screen, DIRTY, the record, the change count moved by, said]
   FAIL (11) the shared state file answers each opening before the folder is read, working out of the shared folder | then its connect takes theirs, as the board said: BRAD-2 loaded, SHARED kept aside first; saved, recorded against BRAD-2 -- [on screen, kept aside, saved, recorded against the folder’s copy, said]
   FAIL (12) the shared state file built on the folder’s copy, loaded on its own, then a refresh | it loads on its own, counted -- [on screen, B, unsaved (DIRTY, _baseDirty, the record)]
MF-c3-v200-adopt-u29-same-save-kept: 55 checks, 1 failed
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | then reopened, the shared state file answering that opening too: SHARED on screen, still unsaved by the record; nothing kept aside, it being the very save on screen; BRAD-1 the folder’s copy
MF-c3-v200-adopt-u29-same-save-recounted: 55 checks, 5 failed
   FAIL (11) the shared state file answers each opening before the folder is read, working out of the shared folder | opening 2, the reload, the answer first: the very save on screen, loaded as before and not counted again -- [on screen, DIRTY, the record, the change count moved by, said]
   FAIL (11) the shared state file answers each opening before the folder is read, working out of the shared folder | then its connect takes theirs, as the board said: BRAD-2 loaded, SHARED kept aside first; saved, recorded against BRAD-2 -- [on screen, kept aside, saved, recorded against the folder’s copy, said]
   FAIL (13, file) the shared state file that is the very save on screen, answering an opening (a CONTROL) | the answer is not counted: still saved, recorded against the file -- [on screen, saved, recorded, the change count moved by, kept aside] (a CONTROL)
   FAIL (13, file) the shared state file that is the very save on screen, answering an opening (a CONTROL) | the next 💾 Save asks nothing and writes it, saved -- [asked, the file, saved] (a CONTROL)
   FAIL (13, folder) the shared state file that is the very save on screen, answering an opening (a CONTROL) | the answer is not counted: still saved, recorded against the folder -- [on screen, saved, recorded, the change count moved by, kept aside] (a CONTROL)
MF-c3-v200-adopt-u29-session-clean: 55 checks, 18 failed
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | it loads SHARED and counts it as a change -- [clicked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, the folder’s copy]
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | the next 💾 Save writes nothing and asks -- [the folder’s copy, on screen, unsaved, nothing written, the choice offered, BRAD-2 said to be saved after the copy on screen]
   FAIL (2) the link, from a board recorded saved, saving to the board file | it loads SHARED and counts it as a change -- [clicked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, the file]
   FAIL (2) the link, from a board recorded saved, saving to the board file | the next 💾 Save asks before it writes over BRAD-2; answered Cancel -- [asked, the question, writes, the file, on screen, unsaved, said]
   FAIL (3) the load after a save has landed, in the same session, working out of the shared folder | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside]
   FAIL (3) the load after a save has landed, in the same session, working out of the shared folder | the next 💾 Save writes nothing over BRAD-2 without a choice -- [the folder, on screen, unsaved, nothing written, the choice offered]
   FAIL (4) the load after a save has landed, in the same session, saving to the board file | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside]
   FAIL (4) the load after a save has landed, in the same session, saving to the board file | the next 💾 Save writes nothing over BRAD-2 without a choice -- [the file, on screen, unsaved, asked, canceled]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, said]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | the Live autosave writes nothing over BRAD-1, and the choice is offered -- [the folder’s copy, on screen, unsaved, the choice offered, said truly]
   FAIL (6) open the file’s version, working out of the shared folder | it asks once and opens CAROL-F, counted as a change -- [clicked, asked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, recorded as the file’s own save]
   FAIL (6) open the file’s version, working out of the shared folder | the next 💾 Save writes nothing over BRAD-1 and asks, saying truly that BRAD-1 is not the copy on screen
   FAIL (9) the shared state file loaded on its own, from a board recorded saved, saving to the board file | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, said]
   FAIL (9) the shared state file loaded on its own, from a board recorded saved, saving to the board file | the next 💾 Save asks before it writes over BRAD-1; answered Cancel -- [asked, writes, the file, on screen, unsaved]
   FAIL (11) the shared state file answers each opening before the folder is read, working out of the shared folder | opening 1, the answer first: SHARED loaded and counted; the connect does not load BRAD-2 over it, and says a reload takes theirs -- [on screen, kept aside, unsaved (DIRTY, _baseDirty, the record), said]
   FAIL (11) the shared state file answers each opening before the folder is read, working out of the shared folder | opening 2, the reload, the answer first: the very save on screen, loaded as before and not counted again -- [on screen, DIRTY, the record, the change count moved by, said]
   FAIL (11) the shared state file answers each opening before the folder is read, working out of the shared folder | then its connect takes theirs, as the board said: BRAD-2 loaded, SHARED kept aside first; saved, recorded against BRAD-2 -- [on screen, kept aside, saved, recorded against the folder’s copy, said]
   FAIL (12) the shared state file built on the folder’s copy, loaded on its own, then a refresh | it loads on its own, counted -- [on screen, B, unsaved (DIRTY, _baseDirty, the record)]
MF-c3-v200-adopt-u29-takefile-uncounted: 55 checks, 3 failed
   FAIL (6) open the file’s version, working out of the shared folder | it asks once and opens CAROL-F, counted as a change -- [clicked, asked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, recorded as the file’s own save]
   FAIL (6) open the file’s version, working out of the shared folder | the next 💾 Save writes nothing over BRAD-1 and asks, saying truly that BRAD-1 is not the copy on screen
   FAIL (6) open the file’s version, working out of the shared folder | then reopened: CAROL-F on screen; the opening does not take BRAD-1 as the copy it came from, and 💾 Save still asks
MF-c3-v200-adopt-u29-year-on-screen-only: 55 checks, 1 failed
   FAIL (10) the link, from a board recorded saved, two years in the shared folder, then 💾 Save on FY28 | the FY28 💾 Save writes nothing over BRAD-28 and offers the choice -- [FY28 copy unchanged, Nothing was written, Save yours over theirs]
MF-c3-v200-adopt-u31-memory-only: 34 checks, 11 failed
   FAIL (1, folder) an import newer than the saved copy, then a reopen | and this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (1, folder) an import newer than the saved copy, then a reopen | reopened: IMPORT on screen, unsaved by the record; nothing kept aside
   FAIL (2, folder) an import older than the saved copy, then a reopen | this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (2, folder) an import older than the saved copy, then a reopen | reopened: BRAD-1, the saved copy, on screen, saved and recorded against it; IMPORT kept aside first -- both kept
   FAIL (3, folder) an import while a save is held, on a board recorded saved, then a reopen | and this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (3, folder) an import while a save is held, on a board recorded saved, then a reopen | and this browser’s record still says it is unsaved -- [_baseDirty, the record]
   FAIL (3, folder) an import while a save is held, on a board recorded saved, then a reopen | reopened: BRAD-1, the saved copy stamped after the import, on screen, saved and recorded against it; IMPORT kept aside first -- both kept
   FAIL (1, file) an import newer than the saved copy, then a reopen | and this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (1, file) an import newer than the saved copy, then a reopen | reopened: IMPORT on screen, unsaved by the record; nothing kept aside
   FAIL (2, file) an import older than the saved copy, then a reopen | this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (2, file) an import older than the saved copy, then a reopen | reopened: BRAD-1, the saved copy, on screen, saved and recorded against it; IMPORT kept aside first -- both kept
MF-c3-v200-adopt-u31-no-mark: 34 checks, 11 failed
   FAIL (1, folder) an import newer than the saved copy, then a reopen | and this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (1, folder) an import newer than the saved copy, then a reopen | reopened: IMPORT on screen, unsaved by the record; nothing kept aside
   FAIL (2, folder) an import older than the saved copy, then a reopen | this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (2, folder) an import older than the saved copy, then a reopen | reopened: BRAD-1, the saved copy, on screen, saved and recorded against it; IMPORT kept aside first -- both kept
   FAIL (3, folder) an import while a save is held, on a board recorded saved, then a reopen | and this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (3, folder) an import while a save is held, on a board recorded saved, then a reopen | and this browser’s record still says it is unsaved -- [_baseDirty, the record]
   FAIL (3, folder) an import while a save is held, on a board recorded saved, then a reopen | reopened: BRAD-1, the saved copy stamped after the import, on screen, saved and recorded against it; IMPORT kept aside first -- both kept
   FAIL (1, file) an import newer than the saved copy, then a reopen | and this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (1, file) an import newer than the saved copy, then a reopen | reopened: IMPORT on screen, unsaved by the record; nothing kept aside
   FAIL (2, file) an import older than the saved copy, then a reopen | this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (2, file) an import older than the saved copy, then a reopen | reopened: BRAD-1, the saved copy, on screen, saved and recorded against it; IMPORT kept aside first -- both kept
MF-c3-v200-adopt-u31-other-unmarked: 34 checks, 3 failed
   FAIL (4a) another appropriation the batch wrote, its own record saying it is the file’s own save | and Full Fund’s own record says unsaved
   FAIL (4a) another appropriation the batch wrote, its own record saying it is the file’s own save | switched to Full Fund: the file’s newer (OLD) Full Fund on screen, the imported (NEW) one kept aside first -- both kept
   FAIL (4b) another appropriation the batch wrote, with no record of its own | and Full Fund’s own record says unsaved (made by the import)
```

### Existing mutation entries beside the changed code, on the final c3 (MXF-*; preservation harnesses)

| label | start (ET) | exit | wall s | log |
|---|---|---|---|---|
| MXF-c3-sidecar-typed-replaced | 2026-10-13 14:43:22 | 1 | 66.1 | logs/MXF-c3-sidecar-typed-replaced.log |
| MXF-c3-sidecar-no-keep | 2026-10-13 14:44:29 | 1 | 66.9 | logs/MXF-c3-sidecar-no-keep.log |
| MXF-c3-adopt-shared-no-keep | 2026-10-13 14:45:36 | 1 | 75.2 | logs/MXF-c3-adopt-shared-no-keep.log |
| MXF-c3-v200-u13-clash-while-saving | 2026-10-13 14:46:53 | 1 | 399.3 | logs/MXF-c3-v200-u13-clash-while-saving.log |
| MXF-c3-v200-u13-base-while-saving | 2026-10-13 14:53:33 | 137 | 396.4 | logs/MXF-c3-v200-u13-base-while-saving.log |
| MXF-c3-batch-writes-each | 2026-10-13 15:00:11 | 1 | 403.7 | logs/MXF-c3-batch-writes-each.log |
| MXF-c3-batch-adopt-unchecked | 2026-10-13 15:06:55 | 1 | 498.5 | logs/MXF-c3-batch-adopt-unchecked.log |
| MXF-c3-v200-u13-base-while-saving-r2 | 2026-10-13 15:25:59 | 1 | 482.6 | logs/MXF-c3-v200-u13-base-while-saving-r2.log |

```
MXF-c3-adopt-shared-no-keep: 22 checks, 1 failed
MXF-c3-batch-adopt-unchecked: 111 checks, 22 failed
MXF-c3-batch-writes-each: 111 checks, 22 failed
MXF-c3-sidecar-no-keep: 22 checks, 2 failed
MXF-c3-sidecar-typed-replaced: 22 checks, 1 failed
MXF-c3-v200-u13-base-while-saving-r2: 167 checks, 2 failed
MXF-c3-v200-u13-base-while-saving: 165 checks, 2 failed
MXF-c3-v200-u13-clash-while-saving: 167 checks, 1 failed
```

Equal to the build's counts on its c3 (MX-*): sidecar-typed-replaced 1, sidecar-no-keep 2, adopt-shared-no-keep 1, batch-writes-each 22, batch-adopt-unchecked 22 failing. The two U13 entries beside `driveClashSay` (not run by the build) are caught by the v2.00 R3–U13 block on the fix-round c3: clash-while-saving 1, base-while-saving 2 failing (its -r2 run; the first run was cut short, exit 137).

### Preservation: existing audit-import blocks this change reaches, built verbatim (mk-pres.sh), on the fix-round c3

The harnesses are byte-identical to the build's (`logs/mk-pres-fr.log`: v189 `ed54e613`, w1 `310b30b8`, v196 `e9a73126`, w3 `e231e09f`, v200 `edd74fd9`), so the build's base runs (P-*-base) stand.

| label | start (ET) | exit | wall s | log |
|---|---|---|---|---|
| PF-v189-c3 | 2026-10-13 14:37:25 | 0 | 32.6 | logs/PF-v189-c3.log |
| PF-w1-c3 | 2026-10-13 14:37:58 | 0 | 84.2 | logs/PF-w1-c3.log |
| PF-v196-c3 | 2026-10-13 14:39:22 | 0 | 69.1 | logs/PF-v196-c3.log |
| PF-w3-c3 | 2026-10-13 14:40:31 | 0 | 287.0 | logs/PF-w3-c3.log |
| PF-v200-c3 | 2026-10-13 14:45:18 | 0 | 371.3 | logs/PF-v200-c3.log |

```
PF-v189-c3: 40 checks, 0 failed
PF-v196-c3: 22 checks, 0 failed
PF-v200-c3: 167 checks, 0 failed
PF-w1-c3: 53 checks, 0 failed
PF-w3-c3: 111 checks, 0 failed
P-v189-base: 40 checks, 0 failed
P-v196-base: 22 checks, 0 failed
P-v200-base: 167 checks, 0 failed
P-w1-base: 53 checks, 0 failed
P-w3-base: 111 checks, 0 failed
```

### Syntax and other suites on the fix-round c3 (scratch clone git/c3fr, `--shared` at 7ee498a, never committed in; npm run check = tools/check.mjs)

| label | start (ET) | exit | wall s | log |
|---|---|---|---|---|
| FR-syntax-c1 | 2026-10-13 15:15:24 | 0 | 0.5 | logs/FR-syntax-c1.log |
| FR-syntax-c2 | 2026-10-13 15:15:25 | 0 | 0.6 | logs/FR-syntax-c2.log |
| FR-syntax-c3 | 2026-10-13 15:15:26 | 0 | 0.5 | logs/FR-syntax-c3.log |
| S-audit-hostile-c3fr | 2026-10-13 15:15:24 | 0 | 296.1 | logs/S-audit-hostile-c3fr.log |
| S-audit-ppt-c3fr | 2026-10-13 15:20:21 | 0 | 24.3 | logs/S-audit-ppt-c3fr.log |
| S-audit-recon-c3fr | 2026-10-13 15:15:26 | 137 | 503.3 | logs/S-audit-recon-c3fr.log |
| S-audit-other-c3fr | 2026-10-13 15:20:45 | 0 | 189.8 | logs/S-audit-other-c3fr.log |
| S-boot-same-c3fr | 2026-10-13 15:23:50 | 0 | 52.6 | logs/S-boot-same-c3fr.log |
| S-audit-inject-c3fr | 2026-10-13 15:23:55 | 0 | 62.5 | logs/S-audit-inject-c3fr.log |
| S-check-c3fr | 2026-10-13 15:24:58 | 0 | 19.2 | logs/S-check-c3fr.log |
| S-audit-c3fr | 2026-10-13 15:24:42 | 0 | 54.7 | logs/S-audit-c3fr.log |
| S-legacy-fsrc-c3fr | 2026-10-13 15:25:37 | 0 | 20.6 | logs/S-legacy-fsrc-c3fr.log |
| S-audit-recon-c3fr-r2 | 2026-10-13 15:26:12 | 0 | 544.7 | logs/S-audit-recon-c3fr-r2.log |

Exit 137 is SIGKILL before the 600 s cap, by its timing most likely for memory on the shared machine (about 2.5 GB of 16 GB was free at 3:00 PM ET): S-audit-recon-c3fr was cut short and re-run as S-audit-recon-c3fr-r2, which passed; so was MXF-c3-v200-u13-base-while-saving (re-run as -r2, above). Each re-run ran with at most one other node run of mine.

```
S-audit-hostile-c3fr | ALL CHECKS PASSED | exit: 0
S-audit-ppt-c3fr | ALL CHECKS PASSED | exit: 0
S-audit-recon-c3fr |  | exit: 137
S-audit-other-c3fr | ALL CHECKS PASSED | exit: 0
S-boot-same-c3fr | every page, source, save and error list is identical either way | exit: 0
S-audit-inject-c3fr | ALL CHECKS PASSED | exit: 0
S-check-c3fr | all checks passed | exit: 0
S-audit-c3fr | ALL CHECKS PASSED | exit: 0
S-legacy-fsrc-c3fr | every legacy Force setting computes exactly as before | exit: 0
S-audit-recon-c3fr-r2 | ALL CHECKS PASSED | exit: 0
```

Base clone (the build's S-*-base) vs the fix-round c3 clone, line for line (`logs/suites-compare-fr.txt`; header and timing lines left out):

```
boot-same: lines base 6, c3fr 6, differing 0
audit: lines base 4, c3fr 4, differing 0
audit-ppt: lines base 4, c3fr 4, differing 0
audit-other: lines base 4, c3fr 4, differing 0
legacy-fsrc: lines base 7, c3fr 7, differing 0
audit-inject: lines base 8, c3fr 8, differing 0
audit-hostile: lines base 4, c3fr 4, differing 0
check: lines base 63, c3fr 63, differing 2
   '31672 lines, 3.57 MB' -> '31743 lines, 3.58 MB'
   '  ok    main script parses (29650 lines)' -> '  ok    main script parses (29721 lines)'
audit-recon: lines base 13, c3fr-r2 13, differing 0
check: the 2 differing lines are the size lines only: 31672 -> 31743 lines and 29650 -> 29721 parsed lines (+71 = the board diff's +78 -7); every check line is the same.
audit-recon: S-audit-recon-c3fr (exit 137, SIGKILL at 503 s, incomplete) is superseded by S-audit-recon-c3fr-r2.
```

### mcount (text only)

```
# mcount (text only), 2026-10-13 13:45:23 EDT -- fix round
base: {"entries": 1328, "once": 1328, "missing": [], "multiple": [], "unparsed": []}
c1: {"entries": 1336, "once": 1336, "missing": [], "multiple": [], "unparsed": []}
c2: {"entries": 1352, "once": 1352, "missing": [], "multiple": [], "unparsed": []}
c3: {"entries": 1355, "once": 1355, "missing": [], "multiple": [], "unparsed": []}
c3 adopt ids: {"entries": 1355, "once": 1355, "missing": [], "multiple": [], "unparsed": [], "detail": {"v200-adopt-u24-link-guard": 1, "v200-adopt-u24-answer-guard": 1, "v200-adopt-u24-file-guard": 1, "v200-adopt-u24-link-words-later": 1, "v200-adopt-u24-link-words-record": 1, "v200-adopt-u24-file-words-record": 1, "v200-adopt-u24-link-guard-dirty-only": 1, "v200-adopt-u24-takefile-guard-file-only": 1, "v200-adopt-u29-no-count": 1, "v200-adopt-u29-session-clean": 1, "v200-adopt-u29-record-clean": 1, "v200-adopt-u29-file-base-kept": 1, "v200-adopt-u29-folder-base-kept": 1, "v200-adopt-u29-year-on-screen-only": 1, "v200-adopt-u29-link-uncounted": 1, "v200-adopt-u29-answer-uncounted": 1, "v200-adopt-u29-answer-file-kept": 1, "v200-adopt-u29-same-save-recounted": 1, "v200-adopt-u29-takefile-uncounted": 1, "v200-adopt-u29-same-save-kept": 1, "v200-adopt-u29-clash-after": 1, "v200-adopt-u29-clash-lacks": 1, "v200-adopt-u29-promise-yours": 1, "v200-adopt-u29-promise-what-you-have": 1, "v200-adopt-u31-no-mark": 1, "v200-adopt-u31-memory-only": 1, "v200-adopt-u31-other-unmarked": 1}}
```

## Fix round: blobs (git hash-object)

```
c1 00c2ac152cd2f022efea656a3be40dca55c4ac8a prioritization-board-grid.html
c1 195381b5759e3f497c091a7a8cc0f95ef79e7089 tools/export-audit/audit-import.mjs
c1 8a7a83e84dfe85cc491e97a0b1bbc77c1e33302b tools/export-audit/mutate.mjs.txt
c2 0bbfedb6ca8e3115191fbd2b0c3260a5531a37e8 prioritization-board-grid.html
c2 54efb128de20d0bfe41fc6b4857bcb2f7e24cffd tools/export-audit/audit-import.mjs
c2 4a533f68073eaafad6b1a37f972fb1c345211bce tools/export-audit/mutate.mjs.txt
c3 d1cdcdf522be87f7ffd4e37236c84201873ae72c prioritization-board-grid.html
c3 fb163d3c64b8f2d682cad6a5debfe7c3d8f7727d tools/export-audit/audit-import.mjs
c3 1fcc407eb435b0120d88a6448e6f282b6a41e2d2 tools/export-audit/mutate.mjs.txt
d6a9fded1e9120d338886f684f82785a5325eff4 diffs/all-c3-vs-base.diff
f1bdf7ab84e9969d84b377beb54aa3cabf861935 diffs/commit1-c1-vs-base.diff
066ae1507293d252ec189fa26ed342a76ceef77a diffs/commit2-c2-vs-c1.diff
5c7513e7afe13713dcd37675866c6d78e72840a7 diffs/commit3-c3-vs-c2.diff
a887a9a78aaab3a04274d4b599e15c10993538e1 block-u24.mjs.txt
61723a821d64b9608878ad22b987154b37b5df86 block-u29.mjs.txt
63b45abb85b20478d951eb921b5dcfaa09577982 block-u31.mjs.txt
b74d9627a1779dc5472357518a9b6b61ae3bec3d entries-u24.mjs.txt
75dd46d862467a5402d93271f86f6d697fd3e34c entries-u29.mjs.txt
b126d7850620d6b19e3d79b74522e0e028fbce99 entries-u31.mjs.txt
eb7ebabda53e12b39dfc9717cc36703279c2d03f harness/c1/focused-U24.mjs
eb7ebabda53e12b39dfc9717cc36703279c2d03f harness/c2/focused-U24.mjs
cb62a1c6eec89c60cc24b3a8d264c8ee4c52ff54 harness/c2/focused-U29.mjs
eb7ebabda53e12b39dfc9717cc36703279c2d03f harness/c3/focused-U24.mjs
cb62a1c6eec89c60cc24b3a8d264c8ee4c52ff54 harness/c3/focused-U29.mjs
50264d6ad59ae62f07e05ae1a96c80127eb3b17d harness/c3/focused-U31.mjs
8e4a1bb3f3c6e209b51078e1aff1bbdebde6f578 drafts/LEDGER-append.md
2ce7a605d79b06d028822593d3dc875ee60dc3c0 drafts/NEXT-VERSION-entries.md
f851f1391102e59aa12f0ca301b40bb4ddd005f3 runner.mjs
a6ecc18273435ba94361fc79e9454678d34efb0c run.sh
101a25abcb6ebfe9bb558d2b92af956936ed12eb bx.sh
b942132307b42ddbb096382dde6431a91fadc080 rebuild-fr.sh
2e495e7cf530f3b148e403bffa7b333bf6f8bae0 focused-fr.sh
697b22348b2c8d8f8155ecccc7cf0c5b7e782d2f queue-fr.sh
1ca2e8ecdc7ad9694008567f2be1ec07f2de5640 queue-fr-suites.sh
b88d46e53f3a90c4d42f4752ee9e89f0998ffc92 mutruns-r3.sh
1b9eb24a01777252a678325480670c5fd34e68a1 mutruns-exist-fr.sh
55779c66273247d87c0702c9f6ff828534292061 pres-fr.sh
22da977dd94c21468ea7f77e9aa0066b0cea4423 suites.sh
3c33d300f75c315b7a2071213ebdb1484c6b9ca7 git/mkclone-c3fr.sh
4ae9483024a990e76ee3e0082d801ef7062a9e87 bin/cmpfail.py
189985953e32468bc9a88128cba7e6f9abccf991 bin/edit-c1.py
27f556a397d472b4652f941eca862cb90d6761a1 bin/edit-c2.py
6411cbfc8f91db9b89703fb7a2202ae20874f646 bin/edit-c3.py
5a43f8069a7a0f5efcb8f4c545407c3ace183bb2 bin/frcmp.py
0c1ff3d19aba360d6e550fe3404507c3be7cd902 bin/insert-before.py
1052ceb2628ad41c965e7d75b5251a907492274b bin/insert-block.py
709ea79ffbbbddbfc4251c5c7bc0fc1a31fe4af3 bin/mk-entries.py
252c00ef658b2db1d8810b0f3d42348f151b1136 bin/mkfocused-import.py
4fd471e2f94cb33ed45cf0cd700d26a9297f34b6 bin/newchecks.py
550754006ef002004710a230c7fcd309f3993baa bin/runtable.py
91deb369dae73b94d6b1e9370bcd0b896799b1cf bin/suitecmp.py
29a28da1295409397a474d595e06c41a2604cba2 bin/summ.py
```

## Fix round: PIDs

`pids.txt` from the line "# FIX ROUND (13 Oct 2026, from 1:32 PM ET)" (line 647) to line 871 are this round's: each run's timeout PID and its child, with the time (ET) and the command, and the lane drivers, marked as Bash-tool background tasks. The lines before it are the build's (and the two earlier builders').

## Fix round: what I did not do (plainly)

- I committed nothing, pushed nothing, and wrote nothing in `/home/user/orbit-board` or `/home/user/orbit-ui`. The scratch
  clone `git/c3fr` is a `--shared` clone at `7ee498a` with the fix-round c3's board and audit-import copied into its work
  tree; nothing was committed there. NEXT-VERSION.md and ledger texts are drafts in `drafts/` only.
- I did not run the full `audit-import.mjs` or `audit-board.mjs` (the lead's). Full-suite sensitivity of the three blocks and
  the full mutation run are for the final-tree queue.
- I did not import, execute or run `mutate.mjs`; entries were counted and applied as text (`mcount.py`, `mkmut.py`).
- No Chromium run: nothing here draws differently (status-line text only); no `verify:grid`; no `playwright install`.
- I did not change the opening's rule that records the file's own save as saved (tests S5, N7): it is outside the three loads
  and shared with the opening's other paths; stated in U29's "Not covered" and the ledger draft.
- I did not change ⬅ Import a full board, Import one appropriation, or the other paths that write another appropriation's
  board (money S1; decision 4 of the build): a new ledger row is drafted for the first two.
- I did not add the sibling check beside audit-import base L3935 (an existing block): offered to the lead (principle 6 list).
- I did not build tests for the word-only wrong fixes the tests verifier listed (N2: clash-vs-screen, count-before-apply, U31
  other-before-checks and record-replaced): no copy is lost on any; each needs a refused load or refused import that no block
  reaches.
- I did not run the U29 entries on c2 (commit 2's own copy): they were run on the final c3, which differs from c2 only inside
  `importBoards` (code and a comment) -- no U29 scenario reaches it -- and the U29 block passes on c2 and c3 alike. The six
  build U24 entries were run on the final c3 (all eight), and the two new ones on c1 as well; the six old ones on c1 are the
  build's runs with the build's block (superseded by the c3 runs).
- I did not re-run the base's other suites or its preservation harnesses: the base blob, the suites and the preservation
  harnesses are byte-identical to the build's, whose base runs stand (S-*-base, P-*-base).
- Waiting and drivers: the lane drivers (`focused-fr.sh A|B`, `queue-fr.sh 1|2`, `queue-fr-suites.sh 1|2`, `rerun-fr.sh`,
  `rerun2-fr.sh`) ran as Bash-tool background tasks (tool-bounded at 1 to 2 hours), not under `setsid -w timeout -k 10
  600`, because each drives many runs; their PIDs are in `pids.txt`, marked as such. Every node run inside them went
  through `run.sh` (`setsid -w timeout -k 10 600`, own process group, PIDs in `pids.txt`); so did the rebuild, mcount,
  mkmut, harness, clone and diff steps, through `bx.sh`. Reads (`cat`, `grep`, `sed`, `ps`, `free`), the data-only
  summarisers (`bin/summ.py`, `frcmp.py`, `cmpfail.py`, `newchecks.py`, `suitecmp.py`) and the text edits of my own
  scripts, blocks and drafts ran directly from the Bash tool, each in a second or two. Several Bash-tool wait loops
  (`until grep …; do sleep 10|15; done`) and the Monitor watches read only `logs/runs.txt`; they are not in `pids.txt`.
  I stopped or killed nothing.

# Build record (12–13 Oct; superseded where the fix round above says so)


Directory: `rec/L6/adopt` (absolute: `/tmp/claude-0/-home-user-Word-Matching-/0eabf6ef-e470-5d8a-8224-885f500b9576/scratchpad/rec/L6/adopt`).
Base (read-only): `rec/L6/base` = `git archive` of orbit-board `7ee498a` (product = `d66dd60`, U14): board `fce8a391`,
audit-import `4aba2506`, audit-recon `529e36f7`, audit-board `a7c575e5`, audit-other `d89396b0`, mutate.mjs.txt `cbc6defc`
(all re-hashed here soon after 11:13 PM ET, and equal to `rec/L6/BASE.txt`).

Nothing was edited, staged, committed or pushed in `/home/user/orbit-board` or `/home/user/orbit-ui`. `mutate.mjs` was never
imported or run: mutation entries were read as text only (`rec/bin/mcount.py`, `rec/bin/mkmut.py`, both `python3 -I`). No
`playwright install`; no Chromium run was needed by this track. The full audit-import and audit-board were not run (the
lead's). Every board stays the empty template; every fixture is synthetic and made at run time.

## This is the third builder on this track

- **First stop (about 6:16 PM ET):** nothing of that attempt was in this directory (the second builder's `pids.txt` header:
  "Started fresh Mon 12 Oct 2026 08:13:35 PM EDT: no earlier adopt directory existed").
- **Second builder (from 8:13 PM ET; stopped about 8:47 PM ET by a usage limit; the container restarted at 11:11 PM ET):**
  reproduced on the base, built c1-c3, the three blocks, the entries, focused runs and 16 mutant runs, and wrote no
  README, no diffs and no drafts.
- **This builder (from 11:13 PM ET):** read all of it, re-checked it, and kept what is sound:

| from the second builder | what I did with it | why |
|---|---|---|
| Reproduction on the base (`probe/`, `logs/r1-*`, `logs/xr1-*`, `chk-r1.log`, `cmp-repro.log`; 8:22-8:29 PM ET) | **kept, not re-run** | every log has its end record and exit; the base is the same blob (`fce8a391`); `cmp-repro.log` shows the 315 rows identical to the L4 triage's, and the 4 U17-checker routes identical; the healthy controls pass. My own focused runs on the base (below) reproduce every defect again, with literals. |
| Board change for U29 (`bin/edit-c2.py`) | **kept** (only the script's source-blob assertion updated to the new c1) | read line by line against the save, folder and file code (README "Commit 2"); the c1→c2 board diff is byte-identical to the earlier attempt's except for line numbers (`logs/old-c1c2.diff` vs `logs/new-c1c2.diff`) |
| Board change for U31 (`bin/edit-c3.py`) | **kept and extended** (source-blob assertion updated; three lines added) | the batch's other appropriations' records were never marked, a loss I measured on the base (decision 4) |
| Board change for U24 (`bin/edit-c1.py`) | **kept, with the refusal words corrected** | the earlier words said "this browser’s record [is] as [it was]". A quiet autosave says nothing when it lands, so the line stays on screen after the record has moved on (the block's own (1Wauto) case): untrue after the operation lands (principle 4). The words now name only what a save leaves as it is, as U2's do. |
| Blocks: U29 (`block-u29.mjs.txt`) | **kept unchanged** | literals checked against the board code |
| Block U24 | **kept; its two literal refusal texts updated** to the corrected words, and the (1Wauto) check now also shows the record moved on under the words | |
| Block U31 | **extended** with (3): an import while a save is held on a board recorded saved (IB-fold-Wclean, the measured data-loss route of the triage, and IB-file-Wclean as a control), and (4): another appropriation the batch wrote (decision 4); named "records" | the triage's IB-fold-Wclean was not covered |
| Entries U29, U31 | U29 **kept unchanged** (regenerated by `bin/mk-entries.py`; byte-identical); U31's two kept, **one added** (`-other-unmarked`) and its header line says "records" | |
| Entries U24 | `-link-words-later`'s find follows the new words; **two added**: `-link-words-record`, `-file-words-record` (the old words back) | |
| Copies c1-c3, harness/, mut/ | **moved to `superseded-r2/`**, rebuilt from the base by the scripts | c1's board changed, so every later copy changes |
| Focused runs F1-*, mutant runs M-* (`logs/`, `out/`) | **kept as a record, not relied on** | they ran on the superseded copies; every one was re-run on the new copies as F2-* / M2-* (the final U31 as F4-* / M4-*) |
| `run.sh`, `bx.sh`, `runner.mjs`, `mk-harness.sh`, `mk-pres.sh`, `bin/*.py` | **kept** (runner.mjs is rec/L2/u2impl's, unchanged but for its first comment line; `bin/mkfocused-import.py` is rec/L2/u2impl/mkfocused-u2.py, unchanged) | read; they do what their headers say |
| `pids.txt`, `logs/runs.txt` | **appended to** | as the rules ask |

New files of mine: `focused-r3.sh`, `mutruns-r3.sh`, `mutruns-exist.sh`, `pres-r3.sh`, `suites.sh` (paths adapted from
`rec/L6/u19/suites.sh`), `git/mkclones.sh` (paths adapted from `rec/L6/u19/git/mkclones.sh`), `git/mkclone-c3f.sh`,
`rebuild-c3.sh`, `mkdiffs.sh`, `mkreadme.sh`, `bin/summ.py`, `bin/runtable.py`, `bin/cmpfail.py`, `probe/other-appn/`,
`drafts/`, `diffs/`, this README (assembled by `mkreadme.sh` from `README.head.md`, `README.mid.md`, the run records and
`README.tail.md`).

## The three proposed commits (the lead commits; I did not)

Each copy is CUMULATIVE (`cp -a` of the previous one, node_modules symlink kept, `chmod u+w`); only the board,
`tools/export-audit/audit-import.mjs` and `tools/export-audit/mutate.mjs.txt` differ (`diff -rq`), and in the two suites the
change is pure insertion (no existing line removed or changed: `diffs/*.diff`, counted per file below).

| # | subject | copy | board | audit-import | mutate.mjs.txt | diff against the previous copy |
|---|---|---|---|---|---|---|
| 1 | v2.00 U24: another copy is not put on screen during a save | `c1/` | `00c2ac152cd2f022efea656a3be40dca55c4ac8a` | `b111bfe1b976878b3431c0f118e9d69f2e45f2f0` | `d8f3956b6b0225cdca01a1937d4ddb4ba82d1d8b` | `diffs/commit1-c1-vs-base.diff` (`8bee57c1`): board +30 −0, audit-import +240 −0, mutate +19 −0 |
| 2 | v2.00 U29 (with U24, closes U17): another copy put on screen is a change from what is saved | `c2/` | `d020543e2166b087ad0ac1bdfdb39924c99b74b6` | `16ae994982de083003a8910b2ad3d4ceafaa07be` | `22df04f5152e6ecd6062da3237427b16af38594b` | `diffs/commit2-c2-vs-c1.diff` (`284aeeec`): board +31 −5, audit-import +215 −0, mutate +37 −0 |
| 3 | v2.00 U31: a batch import marks this browser’s records unsaved | `c3/` | `c0d14fcdfb0b90d774c947277e0c8601af779930` | `97bc28bf559ad733c6cb6d813f801a843e43f3fc` | `f0c7dbf44d435092ae5dd271983ecd0121627d42` | `diffs/commit3-c3-vs-c2.diff` (`947ac513`): board +9 −1, audit-import +135 −0, mutate +10 −0 |

All three together: `diffs/all-c3-vs-base.diff` (`7ee209da`): board +70 −6, audit-import +590 −0, mutate +66 −0. Every other file of each copy is the base's byte for byte
(audit-recon `529e36f7`, audit-board `a7c575e5`, audit-other `d89396b0`, package.json `7cf8186f`, NEXT-VERSION.md `65265c13`,
boot.mjs `9c4f49ad`, the shim `6e2ce2e6`). The copies are built by `bin/edit-c1.py`, `bin/edit-c2.py`, `bin/edit-c3.py`
(each asserts its source blob and that each anchor occurs exactly once), `bin/insert-block.py` (each block after the
previous block's end marker; U24's after `// ==== end v2.00 (U13) ====`) and `bin/insert-before.py` (the entries before
`  // v2.00 (R3, Brad 11 Oct): a save that lands under a locked view says it saved the working plan.`).

**Order.** U24 first: it is the release blocker of the three (U13's shape, data loss in FBT), it follows the pattern Brad chose
for U13, and it stands alone. U29 second: it changes what a load records, which U24's refusal leaves untouched; its block
fails identically with or without U24 (24 of 33 on the base and on c1), and U24's block passes on c2 and c3, so the two do not
lean on each other's tests. U31 last: independent of both (its block fails identically on the base and on c2).

### Commit 1 (U24): what changes in the board

`adoptShared`, `sharedArrived`'s own load (inside `if((st.ts||0)>=(MS.ts||0))`, before `sharedKeepMine`) and
`bootTakeFile` (after its `confirm`) each get `if(_saveBusy){ setStat(...); [render();] return; }`. Nothing waits between
the check and the load in any of the three: `adoptShared` and `sharedArrived` are synchronous from the guard on, and
`bootTakeFile`'s question is a modal `confirm` -- its last wait -- before the guard (U13's late-guard pattern).

### Commit 2 (U29): what changes in the board

- `loadedNotSaved(st, file)` (new, beside `sharedKeepMine`): `_saveGen++; DIRTY=true; _baseDirty=true;` every folder base of
  this appropriation, and one per year the board holds, set to the loaded copy's own time; `file` → `LASTKNOWN=0` and the
  record's `file:0`; then `baseSet({folder, dirty:true[, file:0]})`.
- Called after `applyStore` in `adoptShared` and in `sharedArrived`'s own load (`file` true), and in `bootTakeFile` when
  working out of the shared folder (`file` false: the file's version IS the file's save, so its record stays).
- `sharedKeepMine`: the same save as the one on screen (`st.ts===MS.ts`, a time the board uses as an identity throughout)
  keeps nothing aside -- otherwise the shared state file answering the next opening would keep a copy of itself, now that the
  record says unsaved after the load.
- `driveClashSay`: "after the copy you are working from" only when the folder's copy is newer than the recorded one; else
  "and that is not the copy you are working from".
- The two links' promise: "(work no saved copy has is kept aside first)" for "(what you have …)" and "(yours …)".

What Save then does, by the code it already has: the file save sees `fts>0 && fts!==LASTKNOWN` with `LASTKNOWN` 0 and asks
"this browser cannot tell whether that was before or after the copy you are working from"; the folder save sees
`theirs!==driveBaseOf(ap, fy)` and refuses with the clash line (Load theirs keeps the screen aside; Save yours over theirs keeps
theirs in the history). With nothing in the folder, nothing is overwritten and the save goes ahead.

### Commit 3 (U31): what changes in the board

`if(applied){ persist(); render(); }` → `if(applied){ try{ if(!_baseDirty){ _baseDirty=true; baseSet({dirty:true}); } }catch(e){}
persist(); render(); }` -- `save()`'s own lines for the record, run only when the board on screen took the import -- and then,
for every other appropriation the batch wrote (`take`, all written by then: a refused or undone batch has returned before),
its own record (`_SLUGMAP[slug].key+'.base'`, the key its board's `baseGet()` reads when it is opened) gets `dirty:true`,
merged into what it holds, in a try (as `baseSet` swallows a refusal). An appropriation whose stored copy turns out to be the
file's own save is marked clean again by its own opening (`fileTs===ours`), as today.

## How each commit meets the lead's decision principles

| principle | U24 | U29 | U31 |
|---|---|---|---|
| (1) never lose any copy; keep both and ask or say | the save's copy is never recorded against another copy on screen; refused, nothing is replaced and the copy offered stays where it was (`SHARED` in memory and next to the board; `PUB` in the board file) | the person's own copy stays in its saved copy until they choose (Save asks); a reopen keeps the loaded copy aside before the saved copy replaces it (U29 (1), (2)) | the import is kept aside before a newer saved copy replaces it (U31 (2), (3)) |
| (2) refuse or ask rather than guess | refuses during a save, says so | Save asks wherever the record cannot vouch for the copy it would write over | the record says unsaved: an opening keeps rather than guesses |
| (3) money and every export match exactly | no money path is touched | no money path is touched | no money path is touched |
| (4) every word stays true after the operation lands | the refusals name only what a save leaves as it is (screen, kept work); checked word for word, and after a quiet autosave lands (U24 (1Wauto)); mutations put the old untrue words back and are caught | "after" said only when it is (U29 (5), (6)); the links promise only what is kept | no new words |
| (5) smallest change | three guards | one helper, three calls, one condition, two words | one line for the board on screen, three for the others the batch wrote (decision 4) |
| (6) existing checks preserved | pure insertion in both suites; preservation runs (below); the existing mutations beside the changed code (`sidecar-typed-replaced`, `sidecar-no-keep`, `adopt-shared-no-keep`, `batch-writes-each`, `batch-adopt-unchecked`) still caught on the final c3 (MX-*) | same; the changed words are in no existing check (searched: "kept aside first", "after the copy you are working from" -- the three existing checks of the latter expect it where a colleague saved later, or expect it absent, both unchanged) | same; the v1.97 W3 batch-import block passes unchanged |

No existing check, fixture or expected value was edited.

## Decisions, with reasons

1. **The U24 refusal words were changed** (see the table above). Measured: on c1 after the Live autosave lands, the refusal is
   still on screen and this browser's record is no longer what it was when the link was refused (U24 (1Wauto), checked).
2. **U29 is built as the U17 checker's P3 plus the U17 builder's P2, not as P1 alone**: P1 (refuse during a save) cannot touch
   the no-save routes (XSHn, XFSHn, SHaC, BTC), which the triage measured as the same falsely clean record. Counting alone
   (P3 as drafted) would leave the record naming the person's copy, so the next Save would write over it unasked; hence the
   record stops naming it. Measured: the mutants `v200-adopt-u29-folder-base-kept` and `-file-base-kept` are exactly P3 as
   drafted in each mode, and with them the next 💾 Save writes the loaded copy over the person's own without asking (U29
   (1), (3), (5), (6), (7) fail with the first; (2), (4) with the second; README "Mutants").
3. **U24 stays a refusal even though U29 counts the load**: Brad's U13 rule (refuse, re-check after the last wait), and a
   counted load during a save would still put another copy on screen mid-save.
4. **U31 marks every appropriation the batch wrote, not only the one on screen.** First built (as the second builder had it)
   for the board on screen only; reading `importBoards` showed the batch writes the other appropriations' storage too and
   never their records. I measured it before changing anything (`probe/other-appn/`, runs X-otherappn-on-base and
   -on-c3, on the then c3 `d355db84`, now `superseded-r2/c3-third-v1`): an O&M board whose browser's Full Fund record says
   it is the file's own save takes a batch of one Full Fund board older than the file's; switching to Full Fund opens the
   file's Full Fund and keeps nothing aside -- the import then only in the person's file. Identical on the base and on that
   c3 (2 of 8 checks fail on each). The probe's second case was meant to have no Full Fund record, but the fixture's own
   browser storage carries one saying unsaved, so the import was kept aside there; the block's (4b) takes that record out
   and is the real no-record control (the journal's comparison keeps the import aside). It is
   the same finding (U31: "never marks this browser's record") on the batch's main use, several boards, with the same loss,
   so commit 3 now marks each one (three lines), with scenario (4) in the U31 block and the mutation
   `v200-adopt-u31-other-unmarked`. **No other path that writes another appropriation's board into browser storage marks
   that appropriation's record either**: by code, `lsSet(_SLUGMAP[…].key, …)` at c3 L8770, L9245, L9445, L9839, L10232,
   L10267 and L17760 (package and appropriation imports, plan and band-ladder writes among them). Not measured, not changed:
   for the lead.
5. **IB-fold-Wclean added to the U31 block** (the triage's measured loss route); IB-file-Wclean beside it as a control (the
   file save marks the record itself while building its bytes, measured consistent on the base).
6. **Mutants were run on each commit's own copy** (the copy whose block they target), as the earlier attempt did.

## Drafts for the lead (not committed anywhere)

- `drafts/NEXT-VERSION-entries.md`: the three NEXT-VERSION.md entries under v2.00 (what was wrong, what changes, "What users
  may see", "Test", "Mutations", "Not covered"), and the replacement text for "Unresolved after R1–R5" (U13's line amended;
  U24, U29, U31 lines added).
- `drafts/LEDGER-append.md`: the text to append to the Status cells of U24, U29, U17 and U31 in
  `recovery/v200/UNRESOLVED-LEDGER.md`, with `<sha>`/`<time>` placeholders.

## The triage's routes and controls, and where each is tested (audit-import blocks, literals throughout)

| triage route (rec/L4/u24, u24-check, u17-check) | block and scenario | on the base |
|---|---|---|
| SHc-fold-W, SHc-fold-Whist, SHc-fold-Wread, SHc-fold-Wauto | U24 (1W), (1Whist), (1Wread), (1Wauto) | falsely clean / loaded mid-save (fails) |
| SHc-file-W | U24 (2) | fails |
| SHa-fold-W, SHa-fold-Wlate | U24 (3a), (3b) | fails, through a refresh and a reopen |
| BT-file-W (FBT: the save's copy then in no copy the board can reach) | U24 (4) | fails |
| SHc-*-C1, SHa-fold-C1, BT-file-C1, SHc-fold-Wedit (controls) | U24 (5a), (5b), (5c), (5d) | pass |
| XSHn, XFSHn | U29 (1), (2) | fail |
| XSHdL, XFSHdL | U29 (3), (4) | fail |
| SHaC (the shared state file's own load, no save) | U29 (5) | fails |
| BTC / BT-fold-C1 (folder mode, no save) | U29 (6) | fails |
| SHdC-like (link with unsaved work) and BT-file-C1 (controls) | U29 (7) control part, (8) | pass |
| IB-fold-C1clean, IB-file-C1clean | U31 (1, folder), (1, file) | fail |
| IB-fold-C1oldclean (and the file twin) | U31 (2, folder), (2, file) | fail |
| IB-fold-Wclean (measured loss) / IB-file-Wclean (control) | U31 (3, folder) / (3, file) | fails / passes |
| the batch's other appropriation (found and measured here) | U31 (4a) / (4b) | (4a) fails; (4b)'s controls pass, its record check fails (no record is made) |
| IB-fold-W, IB-file-W, IB-*-C1, IB-*-C2 (counted, consistent) | not repeated: the v1.97 W3 batch-import block and U31's controls cover the counting | -- |
| SHa-file-W (DIRTY guard), SHa-fold-Wnow | not repeated: paths U24 does not change (the DIRTY branch, before its guard; the "your local changes are newer" branch, beside it) | -- |

## Runs (this builder; every run through run.sh: setsid -w timeout -k 10 600, the lock checked first, PIDs in pids.txt)

Lock: `AUDIT_IMPORT_RUNNING` was absent before every run (run.sh waits for it; no run logged a wait or a skip).

### Syntax and focused runs

FINAL: F2-U24-on-base/-c1/-c2, F2-U29-on-base/-c1/-c2, F4-U31-*, F5-U24-on-c3, F5-U29-on-c3 (the final c3). SUPERSEDED, kept as a record: F2-U24-on-c3 and F2-U29-on-c3 (an earlier c3; they passed there too), F2-U31-* (the U31 board and block before the other-appropriation change), F3-U31-* (before (4b) took the fixture’s own record out); R3-syntax-c3 and -c3f are earlier c3s, R3-syntax-c3g the final one.

| label | start (ET) | exit | wall s | log |
|---|---|---|---|---|
| R3-syntax-c1 | 2026-10-12 23:24:41 | 0 | 0.2 | logs/R3-syntax-c1.log |
| R3-syntax-c2 | 2026-10-12 23:24:41 | 0 | 0.2 | logs/R3-syntax-c2.log |
| R3-syntax-c3 | 2026-10-12 23:24:41 | 0 | 0.3 | logs/R3-syntax-c3.log |
| F2-U31-on-c3 | 2026-10-12 23:25:24 | 0 | 25.6 | logs/F2-U31-on-c3.log |
| F2-U24-on-c1 | 2026-10-12 23:25:23 | 0 | 58.2 | logs/F2-U24-on-c1.log |
| F2-U31-on-base | 2026-10-12 23:25:49 | 1 | 35.5 | logs/F2-U31-on-base.log |
| F2-U31-on-c2 | 2026-10-12 23:26:25 | 1 | 53.3 | logs/F2-U31-on-c2.log |
| F2-U24-on-base | 2026-10-12 23:26:21 | 1 | 90.7 | logs/F2-U24-on-base.log |
| F2-U29-on-c2 | 2026-10-12 23:26:41 | 0 | 72.9 | logs/F2-U29-on-c2.log |
| F2-U29-on-base | 2026-10-12 23:27:54 | 1 | 59.3 | logs/F2-U29-on-base.log |
| F2-U24-on-c2 | 2026-10-12 23:27:52 | 0 | 84.9 | logs/F2-U24-on-c2.log |
| F2-U29-on-c1 | 2026-10-12 23:28:54 | 1 | 54.8 | logs/F2-U29-on-c1.log |
| F2-U24-on-c3 | 2026-10-12 23:29:17 | 0 | 77.4 | logs/F2-U24-on-c3.log |
| F2-U29-on-c3 | 2026-10-12 23:29:49 | 0 | 64.2 | logs/F2-U29-on-c3.log |
| R3-syntax-c3f | 2026-10-12 23:39:21 | 0 | 0.5 | logs/R3-syntax-c3f.log |
| F3-U31-on-c3 | 2026-10-12 23:39:58 | 0 | 53.2 | logs/F3-U31-on-c3.log |
| F3-U31-on-base | 2026-10-12 23:40:51 | 1 | 58.2 | logs/F3-U31-on-base.log |
| F3-U31-on-c2 | 2026-10-12 23:41:49 | 1 | 57.6 | logs/F3-U31-on-c2.log |
| R3-syntax-c3g | 2026-10-12 23:44:11 | 0 | 0.3 | logs/R3-syntax-c3g.log |
| F4-U31-on-c3 | 2026-10-12 23:44:42 | 0 | 58.7 | logs/F4-U31-on-c3.log |
| F4-U31-on-base | 2026-10-12 23:45:41 | 1 | 74.2 | logs/F4-U31-on-base.log |
| F4-U31-on-c2 | 2026-10-12 23:46:55 | 1 | 79.3 | logs/F4-U31-on-c2.log |
| F5-U24-on-c3 | 2026-10-12 23:48:34 | 0 | 106.8 | logs/F5-U24-on-c3.log |
| F5-U29-on-c3 | 2026-10-12 23:50:21 | 0 | 81.2 | logs/F5-U29-on-c3.log |

Checks per focused run (`out/<label>.checks.jsonl`):

```
F2-U24-on-base: 58 checks, 28 failed
F2-U24-on-c1: 58 checks, 0 failed
F2-U24-on-c2: 58 checks, 0 failed
F2-U24-on-c3: 58 checks, 0 failed
F2-U29-on-base: 33 checks, 24 failed
F2-U29-on-c1: 33 checks, 24 failed
F2-U29-on-c2: 33 checks, 0 failed
F2-U29-on-c3: 33 checks, 0 failed
F2-U31-on-base: 26 checks, 11 failed
F2-U31-on-c2: 26 checks, 11 failed
F2-U31-on-c3: 26 checks, 0 failed
F3-U31-on-base: 34 checks, 13 failed
F3-U31-on-c2: 34 checks, 13 failed
F3-U31-on-c3: 34 checks, 0 failed
F4-U31-on-base: 34 checks, 14 failed
F4-U31-on-c2: 34 checks, 14 failed
F4-U31-on-c3: 34 checks, 0 failed
F5-U24-on-c3: 58 checks, 0 failed
F5-U29-on-c3: 33 checks, 0 failed
```

Failing checks on the earlier boards, final blocks (each a defect check; every check labelled a CONTROL passes on every board):

```
F2-U24-on-base: 58 checks, 28 failed
   FAIL (1W) the link, while a save to the folder is held at the close of its write of the folder’s copy | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1W) the link, while a save to the folder is held at the close of its write of the folder’s copy | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (1W) the link, while a save to the folder is held at the close of its write of the folder’s copy | then a refresh loads nothing and changes nothing
   FAIL (1W) the link, while a save to the folder is held at the close of its write of the folder’s copy | then reopened (the opening’s connect, then a refresh): BRAD-2 on screen and the folder’s copy, saved, recorded against it; nothing kept aside
   FAIL (1Whist) the link, while a save to the folder is held at the close of its history copy | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Whist) the link, while a save to the folder is held at the close of its history copy | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (1Whist) the link, while a save to the folder is held at the close of its history copy | then a refresh loads nothing and changes nothing
   FAIL (1Whist) the link, while a save to the folder is held at the close of its history copy | then reopened (the opening’s connect, then a refresh): BRAD-2 on screen and the folder’s copy, saved, recorded against it; nothing kept aside
   FAIL (1Wread) the link, while a save to the folder is held at its read of the folder’s copy, before its bytes are built | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Wread) the link, while a save to the folder is held at its read of the folder’s copy, before its bytes are built | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (1Wread) the link, while a save to the folder is held at its read of the folder’s copy, before its bytes are built | then reopened (the opening’s connect, then a refresh): BRAD-2 on screen and the folder’s copy, saved, recorded against it; nothing kept aside
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | once the autosave lands, the refusal is still on screen, word for word, with its link -- [said, links, this browser’s record as it was when the link was refused]: the record has moved on under words that do not name it
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | then its link loads the shared state file, as it does with no save under way -- [clicked, on screen, the folder’s copy]
   FAIL (2) the link, while a save to the board file is held at the close of its write | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (2) the link, while a save to the board file is held at the close of its write | once the save lands: BRAD-2 on screen, in browser storage and the file; saved, recorded against the file; nothing kept aside
   FAIL (2) the link, while a save to the board file is held at the close of its write | then reopened from the file: BRAD-2 on screen, saved, recorded against the file; nothing kept aside
   FAIL (3a) the shared state file answers, stamped an hour ahead, while a save to the folder is held at its write | while the save is held, the answer loads nothing -- [a save under way, nothing changed byte for byte, said]
   FAIL (3a) the shared state file answers, stamped an hour ahead, while a save to the folder is held at its write | and it offers the link instead
   FAIL (3a) the shared state file answers, stamped an hour ahead, while a save to the folder is held at its write | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (3a) the shared state file answers, stamped an hour ahead, while a save to the folder is held at its write | then reopened (the opening’s connect): BRAD-2 on screen and the folder’s copy, saved, recorded against it; nothing kept aside
   FAIL (3b) the shared state file answers, stamped after the save began, while a save to the folder is held at its write | while the save is held, the answer loads nothing -- [a save under way, nothing changed byte for byte, said]
   FAIL (3b) the shared state file answers, stamped after the save began, while a save to the folder is held at its write | and it offers the link instead
   FAIL (3b) the shared state file answers, stamped after the save began, while a save to the folder is held at its write | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (3b) the shared state file answers, stamped after the save began, while a save to the folder is held at its write | then reopened (the opening’s connect): BRAD-2 on screen and the folder’s copy, saved, recorded against it; nothing kept aside
   FAIL (4) open the file’s version, while a save to the board file is held at the close of its write | while the save is held, the link asks, then opens nothing -- [clicked, asked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (4) open the file’s version, while a save to the board file is held at the close of its write | once the save lands: BRAD-2 on screen, in browser storage and the file; saved, recorded against the file; KEPT-0 still kept aside
F2-U29-on-base: 33 checks, 24 failed
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | the link promises to keep aside what no saved copy has -- not "yours", which is in the folder’s copy and is not kept aside
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | it loads SHARED and counts it as a change -- [clicked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, the folder’s copy]
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | and the record no longer names the folder’s copy as the one the screen came from
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | the next 💾 Save writes nothing and asks -- [the folder’s copy, on screen, unsaved, nothing written, the choice offered, BRAD-2 said to be saved after the copy on screen]
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | then reopened: the opening loads BRAD-2, the folder’s copy, and keeps SHARED aside first -- both kept
   FAIL (2) the link, from a board recorded saved, saving to the board file | it loads SHARED and counts it as a change -- [clicked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, the file]
   FAIL (2) the link, from a board recorded saved, saving to the board file | and the record names no save of the file as the one the screen came from -- [LASTKNOWN, the record’s file]
   FAIL (2) the link, from a board recorded saved, saving to the board file | the next 💾 Save asks before it writes over BRAD-2; answered Cancel -- [asked, the question, writes, the file, on screen, unsaved, said]
   FAIL (2) the link, from a board recorded saved, saving to the board file | then reopened from the file: BRAD-2 opened, SHARED kept aside first -- both kept
   FAIL (2) the link, from a board recorded saved, saving to the board file | asked again and answered "overwrite anyway": SHARED written into the file, saved, recorded against it
   FAIL (3) the load after a save has landed, in the same session, working out of the shared folder | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside]
   FAIL (3) the load after a save has landed, in the same session, working out of the shared folder | the next 💾 Save writes nothing over BRAD-2 without a choice -- [the folder, on screen, unsaved, nothing written, the choice offered]
   FAIL (4) the load after a save has landed, in the same session, saving to the board file | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside]
   FAIL (4) the load after a save has landed, in the same session, saving to the board file | the next 💾 Save writes nothing over BRAD-2 without a choice -- [the file, on screen, unsaved, asked, canceled]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, said]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | a refresh loads nothing and does not take BRAD-1 as the copy the screen came from; it says the folder’s copy is not the one on screen
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | the Live autosave writes nothing over BRAD-1, and the choice is offered -- [the folder’s copy, on screen, unsaved, the choice offered, said truly]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | and so does 💾 Save
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | then reopened, the shared state file answering that opening too: SHARED on screen, still unsaved by the record; nothing kept aside, it being the very save on screen; BRAD-1 the folder’s copy
   FAIL (6) open the file’s version, working out of the shared folder | it asks once and opens CAROL-F, counted as a change -- [clicked, asked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, recorded as the file’s own save]
   FAIL (6) open the file’s version, working out of the shared folder | the next 💾 Save writes nothing over BRAD-1 and asks, saying truly that BRAD-1 is not the copy on screen
   FAIL (6) open the file’s version, working out of the shared folder | then reopened: CAROL-F on screen; the opening does not take BRAD-1 as the copy it came from, and 💾 Save still asks
   FAIL (7) the link with unsaved work, working out of the shared folder | the link’s promise names what it keeps aside
   FAIL (7) the link with unsaved work, working out of the shared folder | the next 💾 Save writes nothing over BRAD-1 and asks
F4-U31-on-base: 34 checks, 14 failed
   FAIL (1, folder) an import newer than the saved copy, then a reopen | and this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (1, folder) an import newer than the saved copy, then a reopen | reopened: IMPORT on screen, unsaved by the record; nothing kept aside
   FAIL (2, folder) an import older than the saved copy, then a reopen | this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (2, folder) an import older than the saved copy, then a reopen | reopened: BRAD-1, the saved copy, on screen, saved and recorded against it; IMPORT kept aside first -- both kept
   FAIL (3, folder) an import while a save is held, on a board recorded saved, then a reopen | and this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (3, folder) an import while a save is held, on a board recorded saved, then a reopen | and this browser’s record still says it is unsaved -- [_baseDirty, the record]
   FAIL (3, folder) an import while a save is held, on a board recorded saved, then a reopen | reopened: BRAD-1, the saved copy stamped after the import, on screen, saved and recorded against it; IMPORT kept aside first -- both kept
   FAIL (1, file) an import newer than the saved copy, then a reopen | and this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (1, file) an import newer than the saved copy, then a reopen | reopened: IMPORT on screen, unsaved by the record; nothing kept aside
   FAIL (2, file) an import older than the saved copy, then a reopen | this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (2, file) an import older than the saved copy, then a reopen | reopened: BRAD-1, the saved copy, on screen, saved and recorded against it; IMPORT kept aside first -- both kept
   FAIL (4a) another appropriation the batch wrote, its own record saying it is the file’s own save | and Full Fund’s own record says unsaved
   FAIL (4a) another appropriation the batch wrote, its own record saying it is the file’s own save | switched to Full Fund: the file’s newer (OLD) Full Fund on screen, the imported (NEW) one kept aside first -- both kept
   FAIL (4b) another appropriation the batch wrote, with no record of its own | and Full Fund’s own record says unsaved (made by the import)
```

F2-U29-on-c1 fails the same checks as F2-U29-on-base, and F4-U31-on-c2 the same as F4-U31-on-base (compared line for line; logs/cmp-earlier.txt).

### Mutants (each made by mkmut.py from the copy’s own mutate.mjs.txt, read as text; the copy’s focused harness run on it)

FINAL: M2-c1-* (U24, on c1), M2-c2-* (U29, on c2), M4-c3-* (U31, on the final c3). SUPERSEDED: M2-c3-*, M3-c3-* (earlier c3s).

| label | start (ET) | exit | wall s | log |
|---|---|---|---|---|
| M2-c3-v200-adopt-u31-no-mark | 2026-10-12 23:29:41 | 1 | 43.3 | logs/M2-c3-v200-adopt-u31-no-mark.log |
| M2-c1-v200-adopt-u24-link-guard | 2026-10-12 23:29:41 | 1 | 89.1 | logs/M2-c1-v200-adopt-u24-link-guard.log |
| M2-c3-v200-adopt-u31-memory-only | 2026-10-12 23:30:25 | 1 | 52.7 | logs/M2-c3-v200-adopt-u31-memory-only.log |
| M2-c2-v200-adopt-u29-no-count | 2026-10-12 23:31:00 | 1 | 82.8 | logs/M2-c2-v200-adopt-u29-no-count.log |
| M2-c1-v200-adopt-u24-link-words-later | 2026-10-12 23:30:44 | 1 | 103.1 | logs/M2-c1-v200-adopt-u24-link-words-later.log |
| M2-c2-v200-adopt-u29-file-base-kept | 2026-10-12 23:31:27 | 1 | 86.0 | logs/M2-c2-v200-adopt-u29-file-base-kept.log |
| M2-c1-v200-adopt-u24-answer-guard | 2026-10-12 23:31:11 | 1 | 115.0 | logs/M2-c1-v200-adopt-u24-answer-guard.log |
| M2-c2-v200-adopt-u29-session-clean | 2026-10-12 23:32:24 | 1 | 94.6 | logs/M2-c2-v200-adopt-u29-session-clean.log |
| M2-c1-v200-adopt-u24-link-words-record | 2026-10-12 23:32:27 | 1 | 123.3 | logs/M2-c1-v200-adopt-u24-link-words-record.log |
| M2-c2-v200-adopt-u29-folder-base-kept | 2026-10-12 23:32:54 | 1 | 99.5 | logs/M2-c2-v200-adopt-u29-folder-base-kept.log |
| M2-c1-v200-adopt-u24-file-guard | 2026-10-12 23:33:07 | 1 | 121.7 | logs/M2-c1-v200-adopt-u24-file-guard.log |
| M2-c2-v200-adopt-u29-record-clean | 2026-10-12 23:33:59 | 1 | 100.8 | logs/M2-c2-v200-adopt-u29-record-clean.log |
| M2-c2-v200-adopt-u29-link-uncounted | 2026-10-12 23:34:34 | 1 | 101.1 | logs/M2-c2-v200-adopt-u29-link-uncounted.log |
| M2-c1-v200-adopt-u24-file-words-record | 2026-10-12 23:34:31 | 1 | 127.0 | logs/M2-c1-v200-adopt-u24-file-words-record.log |
| M2-c2-v200-adopt-u29-clash-after | 2026-10-12 23:35:55 | 1 | 90.2 | logs/M2-c2-v200-adopt-u29-clash-after.log |
| M2-c2-v200-adopt-u29-answer-uncounted | 2026-10-12 23:36:09 | 1 | 86.8 | logs/M2-c2-v200-adopt-u29-answer-uncounted.log |
| M2-c2-v200-adopt-u29-promise-yours | 2026-10-12 23:37:26 | 1 | 75.5 | logs/M2-c2-v200-adopt-u29-promise-yours.log |
| M2-c2-v200-adopt-u29-takefile-uncounted | 2026-10-12 23:37:37 | 1 | 66.6 | logs/M2-c2-v200-adopt-u29-takefile-uncounted.log |
| M2-c2-v200-adopt-u29-same-save-kept | 2026-10-12 23:38:44 | 1 | 75.1 | logs/M2-c2-v200-adopt-u29-same-save-kept.log |
| M2-c2-v200-adopt-u29-promise-what-you-have | 2026-10-12 23:38:42 | 1 | 79.8 | logs/M2-c2-v200-adopt-u29-promise-what-you-have.log |
| M3-c3-v200-adopt-u31-no-mark | 2026-10-12 23:40:46 | 1 | 57.8 | logs/M3-c3-v200-adopt-u31-no-mark.log |
| M3-c3-v200-adopt-u31-memory-only | 2026-10-12 23:41:44 | 1 | 58.6 | logs/M3-c3-v200-adopt-u31-memory-only.log |
| M3-c3-v200-adopt-u31-other-unmarked | 2026-10-12 23:42:43 | 1 | 64.3 | logs/M3-c3-v200-adopt-u31-other-unmarked.log |
| M4-c3-v200-adopt-u31-no-mark | 2026-10-12 23:44:42 | 1 | 61.1 | logs/M4-c3-v200-adopt-u31-no-mark.log |
| M4-c3-v200-adopt-u31-memory-only | 2026-10-12 23:45:44 | 1 | 63.4 | logs/M4-c3-v200-adopt-u31-memory-only.log |
| M4-c3-v200-adopt-u31-other-unmarked | 2026-10-12 23:46:48 | 1 | 79.3 | logs/M4-c3-v200-adopt-u31-other-unmarked.log |

Every mutant is caught. The failing checks of each:

```
M2-c1-v200-adopt-u24-answer-guard: 58 checks, 8 failed
   FAIL (3a) the shared state file answers, stamped an hour ahead, while a save to the folder is held at its write | while the save is held, the answer loads nothing -- [a save under way, nothing changed byte for byte, said]
   FAIL (3a) the shared state file answers, stamped an hour ahead, while a save to the folder is held at its write | and it offers the link instead
   FAIL (3a) the shared state file answers, stamped an hour ahead, while a save to the folder is held at its write | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (3a) the shared state file answers, stamped an hour ahead, while a save to the folder is held at its write | then reopened (the opening’s connect): BRAD-2 on screen and the folder’s copy, saved, recorded against it; nothing kept aside
   FAIL (3b) the shared state file answers, stamped after the save began, while a save to the folder is held at its write | while the save is held, the answer loads nothing -- [a save under way, nothing changed byte for byte, said]
   FAIL (3b) the shared state file answers, stamped after the save began, while a save to the folder is held at its write | and it offers the link instead
   FAIL (3b) the shared state file answers, stamped after the save began, while a save to the folder is held at its write | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (3b) the shared state file answers, stamped after the save began, while a save to the folder is held at its write | then reopened (the opening’s connect): BRAD-2 on screen and the folder’s copy, saved, recorded against it; nothing kept aside
M2-c1-v200-adopt-u24-file-guard: 58 checks, 2 failed
   FAIL (4) open the file’s version, while a save to the board file is held at the close of its write | while the save is held, the link asks, then opens nothing -- [clicked, asked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (4) open the file’s version, while a save to the board file is held at the close of its write | once the save lands: BRAD-2 on screen, in browser storage and the file; saved, recorded against the file; KEPT-0 still kept aside
M2-c1-v200-adopt-u24-file-words-record: 58 checks, 1 failed
   FAIL (4) open the file’s version, while a save to the board file is held at the close of its write | while the save is held, the link asks, then opens nothing -- [clicked, asked, a save under way, nothing changed byte for byte, said word for word]
M2-c1-v200-adopt-u24-link-guard: 58 checks, 18 failed
   FAIL (1W) the link, while a save to the folder is held at the close of its write of the folder’s copy | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1W) the link, while a save to the folder is held at the close of its write of the folder’s copy | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (1W) the link, while a save to the folder is held at the close of its write of the folder’s copy | then a refresh loads nothing and changes nothing
   FAIL (1W) the link, while a save to the folder is held at the close of its write of the folder’s copy | then reopened (the opening’s connect, then a refresh): BRAD-2 on screen and the folder’s copy, saved, recorded against it; nothing kept aside
   FAIL (1Whist) the link, while a save to the folder is held at the close of its history copy | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Whist) the link, while a save to the folder is held at the close of its history copy | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (1Whist) the link, while a save to the folder is held at the close of its history copy | then a refresh loads nothing and changes nothing
   FAIL (1Whist) the link, while a save to the folder is held at the close of its history copy | then reopened (the opening’s connect, then a refresh): BRAD-2 on screen and the folder’s copy, saved, recorded against it; nothing kept aside
   FAIL (1Wread) the link, while a save to the folder is held at its read of the folder’s copy, before its bytes are built | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Wread) the link, while a save to the folder is held at its read of the folder’s copy, before its bytes are built | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (1Wread) the link, while a save to the folder is held at its read of the folder’s copy, before its bytes are built | then reopened (the opening’s connect, then a refresh): BRAD-2 on screen and the folder’s copy, saved, recorded against it; nothing kept aside
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | once the save lands: BRAD-2 on screen, in browser storage and the folder’s copy; saved, recorded against it; BRAD-1 in the folder’s history; nothing kept aside
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | once the autosave lands, the refusal is still on screen, word for word, with its link -- [said, links, this browser’s record as it was when the link was refused]: the record has moved on under words that do not name it
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | then its link loads the shared state file, as it does with no save under way -- [clicked, on screen, the folder’s copy]
   FAIL (2) the link, while a save to the board file is held at the close of its write | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (2) the link, while a save to the board file is held at the close of its write | once the save lands: BRAD-2 on screen, in browser storage and the file; saved, recorded against the file; nothing kept aside
   FAIL (2) the link, while a save to the board file is held at the close of its write | then reopened from the file: BRAD-2 on screen, saved, recorded against the file; nothing kept aside
M2-c1-v200-adopt-u24-link-words-later: 58 checks, 6 failed
   FAIL (1W) the link, while a save to the folder is held at the close of its write of the folder’s copy | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Whist) the link, while a save to the folder is held at the close of its history copy | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Wread) the link, while a save to the folder is held at its read of the folder’s copy, before its bytes are built | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | once the autosave lands, the refusal is still on screen, word for word, with its link -- [said, links, this browser’s record as it was when the link was refused]: the record has moved on under words that do not name it
   FAIL (2) the link, while a save to the board file is held at the close of its write | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
M2-c1-v200-adopt-u24-link-words-record: 58 checks, 6 failed
   FAIL (1W) the link, while a save to the folder is held at the close of its write of the folder’s copy | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Whist) the link, while a save to the folder is held at the close of its history copy | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Wread) the link, while a save to the folder is held at its read of the folder’s copy, before its bytes are built | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
   FAIL (1Wauto) the link, while a save to the folder is held the Live autosave, at the close of its write | once the autosave lands, the refusal is still on screen, word for word, with its link -- [said, links, this browser’s record as it was when the link was refused]: the record has moved on under words that do not name it
   FAIL (2) the link, while a save to the board file is held at the close of its write | while the save is held, the link loads nothing -- [clicked, a save under way, nothing changed byte for byte, said word for word]
M2-c2-v200-adopt-u29-answer-uncounted: 33 checks, 5 failed
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, said]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | a refresh loads nothing and does not take BRAD-1 as the copy the screen came from; it says the folder’s copy is not the one on screen
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | the Live autosave writes nothing over BRAD-1, and the choice is offered -- [the folder’s copy, on screen, unsaved, the choice offered, said truly]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | and so does 💾 Save
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | then reopened, the shared state file answering that opening too: SHARED on screen, still unsaved by the record; nothing kept aside, it being the very save on screen; BRAD-1 the folder’s copy
M2-c2-v200-adopt-u29-clash-after: 33 checks, 4 failed
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | a refresh loads nothing and does not take BRAD-1 as the copy the screen came from; it says the folder’s copy is not the one on screen
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | the Live autosave writes nothing over BRAD-1, and the choice is offered -- [the folder’s copy, on screen, unsaved, the choice offered, said truly]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | and so does 💾 Save
   FAIL (6) open the file’s version, working out of the shared folder | the next 💾 Save writes nothing over BRAD-1 and asks, saying truly that BRAD-1 is not the copy on screen
M2-c2-v200-adopt-u29-file-base-kept: 33 checks, 5 failed
   FAIL (2) the link, from a board recorded saved, saving to the board file | and the record names no save of the file as the one the screen came from -- [LASTKNOWN, the record’s file]
   FAIL (2) the link, from a board recorded saved, saving to the board file | the next 💾 Save asks before it writes over BRAD-2; answered Cancel -- [asked, the question, writes, the file, on screen, unsaved, said]
   FAIL (2) the link, from a board recorded saved, saving to the board file | then reopened from the file: BRAD-2 opened, SHARED kept aside first -- both kept
   FAIL (2) the link, from a board recorded saved, saving to the board file | asked again and answered "overwrite anyway": SHARED written into the file, saved, recorded against it
   FAIL (4) the load after a save has landed, in the same session, saving to the board file | the next 💾 Save writes nothing over BRAD-2 without a choice -- [the file, on screen, unsaved, asked, canceled]
M2-c2-v200-adopt-u29-folder-base-kept: 33 checks, 11 failed
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | and the record no longer names the folder’s copy as the one the screen came from
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | the next 💾 Save writes nothing and asks -- [the folder’s copy, on screen, unsaved, nothing written, the choice offered, BRAD-2 said to be saved after the copy on screen]
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | then reopened: the opening loads BRAD-2, the folder’s copy, and keeps SHARED aside first -- both kept
   FAIL (3) the load after a save has landed, in the same session, working out of the shared folder | the next 💾 Save writes nothing over BRAD-2 without a choice -- [the folder, on screen, unsaved, nothing written, the choice offered]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | a refresh loads nothing and does not take BRAD-1 as the copy the screen came from; it says the folder’s copy is not the one on screen
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | the Live autosave writes nothing over BRAD-1, and the choice is offered -- [the folder’s copy, on screen, unsaved, the choice offered, said truly]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | and so does 💾 Save
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | then reopened, the shared state file answering that opening too: SHARED on screen, still unsaved by the record; nothing kept aside, it being the very save on screen; BRAD-1 the folder’s copy
   FAIL (6) open the file’s version, working out of the shared folder | the next 💾 Save writes nothing over BRAD-1 and asks, saying truly that BRAD-1 is not the copy on screen
   FAIL (6) open the file’s version, working out of the shared folder | then reopened: CAROL-F on screen; the opening does not take BRAD-1 as the copy it came from, and 💾 Save still asks
   FAIL (7) the link with unsaved work, working out of the shared folder | the next 💾 Save writes nothing over BRAD-1 and asks
M2-c2-v200-adopt-u29-link-uncounted: 33 checks, 14 failed
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | it loads SHARED and counts it as a change -- [clicked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, the folder’s copy]
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | and the record no longer names the folder’s copy as the one the screen came from
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | the next 💾 Save writes nothing and asks -- [the folder’s copy, on screen, unsaved, nothing written, the choice offered, BRAD-2 said to be saved after the copy on screen]
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | then reopened: the opening loads BRAD-2, the folder’s copy, and keeps SHARED aside first -- both kept
   FAIL (2) the link, from a board recorded saved, saving to the board file | it loads SHARED and counts it as a change -- [clicked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, the file]
   FAIL (2) the link, from a board recorded saved, saving to the board file | and the record names no save of the file as the one the screen came from -- [LASTKNOWN, the record’s file]
   FAIL (2) the link, from a board recorded saved, saving to the board file | the next 💾 Save asks before it writes over BRAD-2; answered Cancel -- [asked, the question, writes, the file, on screen, unsaved, said]
   FAIL (2) the link, from a board recorded saved, saving to the board file | then reopened from the file: BRAD-2 opened, SHARED kept aside first -- both kept
   FAIL (2) the link, from a board recorded saved, saving to the board file | asked again and answered "overwrite anyway": SHARED written into the file, saved, recorded against it
   FAIL (3) the load after a save has landed, in the same session, working out of the shared folder | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside]
   FAIL (3) the load after a save has landed, in the same session, working out of the shared folder | the next 💾 Save writes nothing over BRAD-2 without a choice -- [the folder, on screen, unsaved, nothing written, the choice offered]
   FAIL (4) the load after a save has landed, in the same session, saving to the board file | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside]
   FAIL (4) the load after a save has landed, in the same session, saving to the board file | the next 💾 Save writes nothing over BRAD-2 without a choice -- [the file, on screen, unsaved, asked, canceled]
   FAIL (7) the link with unsaved work, working out of the shared folder | the next 💾 Save writes nothing over BRAD-1 and asks
M2-c2-v200-adopt-u29-no-count: 33 checks, 6 failed
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | it loads SHARED and counts it as a change -- [clicked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, the folder’s copy]
   FAIL (2) the link, from a board recorded saved, saving to the board file | it loads SHARED and counts it as a change -- [clicked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, the file]
   FAIL (3) the load after a save has landed, in the same session, working out of the shared folder | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside]
   FAIL (4) the load after a save has landed, in the same session, saving to the board file | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, said]
   FAIL (6) open the file’s version, working out of the shared folder | it asks once and opens CAROL-F, counted as a change -- [clicked, asked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, recorded as the file’s own save]
M2-c2-v200-adopt-u29-promise-what-you-have: 33 checks, 1 failed
   FAIL (7) the link with unsaved work, working out of the shared folder | the link’s promise names what it keeps aside
M2-c2-v200-adopt-u29-promise-yours: 33 checks, 1 failed
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | the link promises to keep aside what no saved copy has -- not "yours", which is in the folder’s copy and is not kept aside
M2-c2-v200-adopt-u29-record-clean: 33 checks, 9 failed
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | it loads SHARED and counts it as a change -- [clicked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, the folder’s copy]
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | then reopened: the opening loads BRAD-2, the folder’s copy, and keeps SHARED aside first -- both kept
   FAIL (2) the link, from a board recorded saved, saving to the board file | it loads SHARED and counts it as a change -- [clicked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, the file]
   FAIL (2) the link, from a board recorded saved, saving to the board file | then reopened from the file: BRAD-2 opened, SHARED kept aside first -- both kept
   FAIL (3) the load after a save has landed, in the same session, working out of the shared folder | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside]
   FAIL (4) the load after a save has landed, in the same session, saving to the board file | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, said]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | then reopened, the shared state file answering that opening too: SHARED on screen, still unsaved by the record; nothing kept aside, it being the very save on screen; BRAD-1 the folder’s copy
   FAIL (6) open the file’s version, working out of the shared folder | it asks once and opens CAROL-F, counted as a change -- [clicked, asked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, recorded as the file’s own save]
M2-c2-v200-adopt-u29-same-save-kept: 33 checks, 1 failed
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | then reopened, the shared state file answering that opening too: SHARED on screen, still unsaved by the record; nothing kept aside, it being the very save on screen; BRAD-1 the folder’s copy
M2-c2-v200-adopt-u29-session-clean: 33 checks, 12 failed
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | it loads SHARED and counts it as a change -- [clicked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, the folder’s copy]
   FAIL (1) the link, from a board recorded saved, working out of the shared folder | the next 💾 Save writes nothing and asks -- [the folder’s copy, on screen, unsaved, nothing written, the choice offered, BRAD-2 said to be saved after the copy on screen]
   FAIL (2) the link, from a board recorded saved, saving to the board file | it loads SHARED and counts it as a change -- [clicked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, the file]
   FAIL (2) the link, from a board recorded saved, saving to the board file | the next 💾 Save asks before it writes over BRAD-2; answered Cancel -- [asked, the question, writes, the file, on screen, unsaved, said]
   FAIL (3) the load after a save has landed, in the same session, working out of the shared folder | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside]
   FAIL (3) the load after a save has landed, in the same session, working out of the shared folder | the next 💾 Save writes nothing over BRAD-2 without a choice -- [the folder, on screen, unsaved, nothing written, the choice offered]
   FAIL (4) the load after a save has landed, in the same session, saving to the board file | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside]
   FAIL (4) the load after a save has landed, in the same session, saving to the board file | the next 💾 Save writes nothing over BRAD-2 without a choice -- [the file, on screen, unsaved, asked, canceled]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | it loads SHARED and counts it as a change -- [on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, kept aside, said]
   FAIL (5) the shared state file loaded on its own, from a board recorded saved, working out of the shared folder | the Live autosave writes nothing over BRAD-1, and the choice is offered -- [the folder’s copy, on screen, unsaved, the choice offered, said truly]
   FAIL (6) open the file’s version, working out of the shared folder | it asks once and opens CAROL-F, counted as a change -- [clicked, asked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, recorded as the file’s own save]
   FAIL (6) open the file’s version, working out of the shared folder | the next 💾 Save writes nothing over BRAD-1 and asks, saying truly that BRAD-1 is not the copy on screen
M2-c2-v200-adopt-u29-takefile-uncounted: 33 checks, 3 failed
   FAIL (6) open the file’s version, working out of the shared folder | it asks once and opens CAROL-F, counted as a change -- [clicked, asked, on screen, unsaved (DIRTY, _baseDirty, the record), the change count moved by, recorded as the file’s own save]
   FAIL (6) open the file’s version, working out of the shared folder | the next 💾 Save writes nothing over BRAD-1 and asks, saying truly that BRAD-1 is not the copy on screen
   FAIL (6) open the file’s version, working out of the shared folder | then reopened: CAROL-F on screen; the opening does not take BRAD-1 as the copy it came from, and 💾 Save still asks
M2-c3-v200-adopt-u31-memory-only: 26 checks, 11 failed
   FAIL (1, folder) an import newer than the saved copy, then a reopen | and this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (1, folder) an import newer than the saved copy, then a reopen | reopened: IMPORT on screen, unsaved by the record; nothing kept aside
   FAIL (2, folder) an import older than the saved copy, then a reopen | this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (2, folder) an import older than the saved copy, then a reopen | reopened: BRAD-1, the saved copy, on screen, saved and recorded against it; IMPORT kept aside first -- both kept
   FAIL (3, folder) an import while a save is held, on a board recorded saved, then a reopen | and this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (3, folder) an import while a save is held, on a board recorded saved, then a reopen | and this browser’s record still says it is unsaved -- [_baseDirty, the record]
   FAIL (3, folder) an import while a save is held, on a board recorded saved, then a reopen | reopened: BRAD-1, the saved copy stamped after the import, on screen, saved and recorded against it; IMPORT kept aside first -- both kept
   FAIL (1, file) an import newer than the saved copy, then a reopen | and this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (1, file) an import newer than the saved copy, then a reopen | reopened: IMPORT on screen, unsaved by the record; nothing kept aside
   FAIL (2, file) an import older than the saved copy, then a reopen | this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (2, file) an import older than the saved copy, then a reopen | reopened: BRAD-1, the saved copy, on screen, saved and recorded against it; IMPORT kept aside first -- both kept
M2-c3-v200-adopt-u31-no-mark: 26 checks, 11 failed
   FAIL (1, folder) an import newer than the saved copy, then a reopen | and this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (1, folder) an import newer than the saved copy, then a reopen | reopened: IMPORT on screen, unsaved by the record; nothing kept aside
   FAIL (2, folder) an import older than the saved copy, then a reopen | this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (2, folder) an import older than the saved copy, then a reopen | reopened: BRAD-1, the saved copy, on screen, saved and recorded against it; IMPORT kept aside first -- both kept
   FAIL (3, folder) an import while a save is held, on a board recorded saved, then a reopen | and this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (3, folder) an import while a save is held, on a board recorded saved, then a reopen | and this browser’s record still says it is unsaved -- [_baseDirty, the record]
   FAIL (3, folder) an import while a save is held, on a board recorded saved, then a reopen | reopened: BRAD-1, the saved copy stamped after the import, on screen, saved and recorded against it; IMPORT kept aside first -- both kept
   FAIL (1, file) an import newer than the saved copy, then a reopen | and this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (1, file) an import newer than the saved copy, then a reopen | reopened: IMPORT on screen, unsaved by the record; nothing kept aside
   FAIL (2, file) an import older than the saved copy, then a reopen | this browser’s record says it is unsaved -- [_baseDirty, the record]
   FAIL (2, file) an import older than the saved copy, then a reopen | reopened: BRAD-1, the saved copy, on screen, saved and recorded against it; IMPORT kept aside first -- both kept
```

### Existing mutation entries beside this code, on the final c3 (MX-*), and the other-appropriation probe (X-*: on the base and on the c3 before the change, d355db84)

| label | start (ET) | exit | wall s | log |
|---|---|---|---|---|
| X-otherappn-on-c3 | 2026-10-12 23:36:43 | 1 | 33.0 | logs/X-otherappn-on-c3.log |
| X-otherappn-on-base | 2026-10-12 23:37:16 | 1 | 28.5 | logs/X-otherappn-on-base.log |
| MX-c3-sidecar-typed-replaced | 2026-10-12 23:51:52 | 1 | 104.9 | logs/MX-c3-sidecar-typed-replaced.log |
| MX-c3-sidecar-no-keep | 2026-10-12 23:53:37 | 1 | 86.9 | logs/MX-c3-sidecar-no-keep.log |
| MX-c3-adopt-shared-no-keep | 2026-10-12 23:55:05 | 1 | 73.5 | logs/MX-c3-adopt-shared-no-keep.log |
| MX-c3-batch-adopt-unchecked | 2026-10-12 23:56:35 | 1 | 186.7 | logs/MX-c3-batch-adopt-unchecked.log |
| MX-c3-batch-writes-each | 2026-10-12 23:56:35 | 1 | 189.2 | logs/MX-c3-batch-writes-each.log |

```
MX-c3-adopt-shared-no-keep: 22 checks, 1 failed
   FAIL and then loaded by choice | loading it then keeps the typed work aside first
MX-c3-batch-adopt-unchecked: 111 checks, 22 failed
   FAIL the board on screen refuses after the write | every appropriation is put back in storage and memory, and it says nothing was imported
   FAIL the board refuses, and O&M, written last will not go back | every other list is put back: only the stuck ones still hold the import, and the mix is marked
   FAIL the board refuses, and O&M, written last will not go back | the mark names exactly the lists not as they were, and says it was this batch
   FAIL the board refuses, and O&M, written last will not go back | it says it stopped part-way and names what each list holds -- never "exactly as it was", never "Imported"
   FAIL the board refuses, and O&M, written last will not go back | the board as it was and the file it took are offered to save, and memory is as it was
   FAIL the board refuses, and Full Fund, written first will not go back | every other list is put back: only the stuck ones still hold the import, and the mix is marked
   FAIL the board refuses, and Full Fund, written first will not go back | the mark names exactly the lists not as they were, and says it was this batch
   FAIL the board refuses, and Full Fund, written first will not go back | it says it stopped part-way and names what each list holds -- never "exactly as it was", never "Imported"
   FAIL the board refuses, and Full Fund, written first will not go back | the board as it was and the file it took are offered to save, and memory is as it was
   FAIL the board refuses, and both will not go back | every other list is put back: only the stuck ones still hold the import, and the mix is marked
   FAIL the board refuses, and both will not go back | the mark names exactly the lists not as they were, and says it was this batch
   FAIL the board refuses, and both will not go back | it says it stopped part-way and names what each list holds -- never "exactly as it was", never "Imported"
   FAIL the board refuses, and both will not go back | the board as it was and the file it took are offered to save, and memory is as it was
   FAIL the board refuses, and O&M (Full Fund held nothing before) will not go back | every other list is put back: only the stuck ones still hold the import, and the mix is marked
   FAIL the board refuses, and O&M (Full Fund held nothing before) will not go back | the mark names exactly the lists not as they were, and says it was this batch
   FAIL the board refuses, and O&M (Full Fund held nothing before) will not go back | it says it stopped part-way and names what each list holds -- never "exactly as it was", never "Imported"
   FAIL the board refuses, and O&M (Full Fund held nothing before) will not go back | the board as it was and the file it took are offered to save, and memory is as it was
   FAIL the board throws part-way through taking its appropriation | storage and memory are as they were (the board on screen included), and it says nothing was imported
   FAIL the board throws part-way through taking its appropriation | and the journal records edits again
   FAIL held: 💾 Save to the board file | refused: the file is not written, and the message offers the copies
   FAIL held: 💾 Save to the shared folder | refused, the autosave included: nothing is written in the folder
   FAIL held, then reloaded | the mark is kept, the message names the batch, and 💾 Save is still refused
MX-c3-batch-writes-each: 111 checks, 22 failed
   FAIL the board on screen refuses after the write | every appropriation is put back in storage and memory, and it says nothing was imported
   FAIL the board refuses, and O&M, written last will not go back | every other list is put back: only the stuck ones still hold the import, and the mix is marked
   FAIL the board refuses, and O&M, written last will not go back | the mark names exactly the lists not as they were, and says it was this batch
   FAIL the board refuses, and O&M, written last will not go back | it says it stopped part-way and names what each list holds -- never "exactly as it was", never "Imported"
   FAIL the board refuses, and O&M, written last will not go back | the board as it was and the file it took are offered to save, and memory is as it was
   FAIL the board refuses, and Full Fund, written first will not go back | every other list is put back: only the stuck ones still hold the import, and the mix is marked
   FAIL the board refuses, and Full Fund, written first will not go back | the mark names exactly the lists not as they were, and says it was this batch
   FAIL the board refuses, and Full Fund, written first will not go back | it says it stopped part-way and names what each list holds -- never "exactly as it was", never "Imported"
   FAIL the board refuses, and Full Fund, written first will not go back | the board as it was and the file it took are offered to save, and memory is as it was
   FAIL the board refuses, and both will not go back | every other list is put back: only the stuck ones still hold the import, and the mix is marked
   FAIL the board refuses, and both will not go back | the mark names exactly the lists not as they were, and says it was this batch
   FAIL the board refuses, and both will not go back | it says it stopped part-way and names what each list holds -- never "exactly as it was", never "Imported"
   FAIL the board refuses, and both will not go back | the board as it was and the file it took are offered to save, and memory is as it was
   FAIL the board refuses, and O&M (Full Fund held nothing before) will not go back | every other list is put back: only the stuck ones still hold the import, and the mix is marked
   FAIL the board refuses, and O&M (Full Fund held nothing before) will not go back | the mark names exactly the lists not as they were, and says it was this batch
   FAIL the board refuses, and O&M (Full Fund held nothing before) will not go back | it says it stopped part-way and names what each list holds -- never "exactly as it was", never "Imported"
   FAIL the board refuses, and O&M (Full Fund held nothing before) will not go back | the board as it was and the file it took are offered to save, and memory is as it was
   FAIL storage cannot be read before the write | nothing is written: storage and memory are as they were, and it says nothing was imported
   FAIL the board throws part-way through taking its appropriation | storage and memory are as they were (the board on screen included), and it says nothing was imported
   FAIL held: 💾 Save to the board file | refused: the file is not written, and the message offers the copies
   FAIL held: 💾 Save to the shared folder | refused, the autosave included: nothing is written in the folder
   FAIL held, then reloaded | the mark is kept, the message names the batch, and 💾 Save is still refused
MX-c3-sidecar-no-keep: 22 checks, 2 failed
   FAIL a reopened draft | the shared copy is loaded only once the earlier session’s work is kept aside
   FAIL other work already kept | nothing is loaded: the earlier session’s work stays on screen, and what was kept stays kept
MX-c3-sidecar-typed-replaced: 22 checks, 1 failed
   FAIL typed, then a later answer | nothing is replaced: the note typed stays on screen and in this browser, and the board says what arrived
X-otherappn-on-base: 8 checks, 2 failed
   FAIL (1) Full Fund’s own record says it is the file’s own save | Full Fund’s own record says unsaved after the import -- [its dirty]
   FAIL (1) Full Fund’s own record says it is the file’s own save | switched to Full Fund: the file’s newer (OLD) Full Fund on screen, the imported (NEW) one kept aside -- [on screen as, which, kept aside]
X-otherappn-on-c3: 8 checks, 2 failed
   FAIL (1) Full Fund’s own record says it is the file’s own save | Full Fund’s own record says unsaved after the import -- [its dirty]
   FAIL (1) Full Fund’s own record says it is the file’s own save | switched to Full Fund: the file’s newer (OLD) Full Fund on screen, the imported (NEW) one kept aside -- [on screen as, which, kept aside]
```

### Other suites, base clone vs the final c3 clone (git/; npm run check = tools/check.mjs)

FINAL: S-*-base (git/base, 7ee498a as committed) and S-*-c3f (git/c3f: the final c3 board c0d14fcd and audit-import). SUPERSEDED, kept as a record: S-*-c3 (git/c3: the c3 board d355db84, before the other-appropriation change).

| label | start (ET) | exit | wall s | log |
|---|---|---|---|---|
| S-boot-same-base | 2026-10-12 23:31:22 | 0 | 38.5 | logs/S-boot-same-base.log |
| S-audit-base | 2026-10-12 23:32:00 | 0 | 37.9 | logs/S-audit-base.log |
| S-audit-ppt-base | 2026-10-12 23:32:38 | 0 | 18.8 | logs/S-audit-ppt-base.log |
| S-audit-other-base | 2026-10-12 23:32:57 | 0 | 129.3 | logs/S-audit-other-base.log |
| S-legacy-fsrc-base | 2026-10-12 23:35:06 | 0 | 12.9 | logs/S-legacy-fsrc-base.log |
| S-check-base | 2026-10-12 23:35:19 | 0 | 15.0 | logs/S-check-base.log |
| S-audit-inject-base | 2026-10-12 23:35:35 | 0 | 52.3 | logs/S-audit-inject-base.log |
| S-boot-same-c3 | 2026-10-12 23:36:43 | 0 | 39.4 | logs/S-boot-same-c3.log |
| S-audit-c3 | 2026-10-12 23:37:23 | 0 | 34.3 | logs/S-audit-c3.log |
| S-audit-ppt-c3 | 2026-10-12 23:37:57 | 0 | 16.3 | logs/S-audit-ppt-c3.log |
| S-audit-other-c3 | 2026-10-12 23:38:14 | 0 | 97.2 | logs/S-audit-other-c3.log |
| S-legacy-fsrc-c3 | 2026-10-12 23:39:51 | 0 | 10.1 | logs/S-legacy-fsrc-c3.log |
| S-check-c3 | 2026-10-12 23:40:01 | 0 | 9.2 | logs/S-check-c3.log |
| S-audit-inject-c3 | 2026-10-12 23:40:10 | 0 | 29.6 | logs/S-audit-inject-c3.log |
| S-boot-same-c3f | 2026-10-12 23:40:50 | 0 | 27.1 | logs/S-boot-same-c3f.log |
| S-audit-c3f | 2026-10-12 23:41:17 | 0 | 27.1 | logs/S-audit-c3f.log |
| S-audit-ppt-c3f | 2026-10-12 23:41:44 | 0 | 13.1 | logs/S-audit-ppt-c3f.log |
| S-audit-other-c3f | 2026-10-12 23:41:58 | 0 | 90.9 | logs/S-audit-other-c3f.log |
| S-legacy-fsrc-c3f | 2026-10-12 23:43:29 | 0 | 9.0 | logs/S-legacy-fsrc-c3f.log |
| S-check-c3f | 2026-10-12 23:43:38 | 0 | 8.4 | logs/S-check-c3f.log |
| S-audit-inject-c3f | 2026-10-12 23:43:46 | 0 | 31.5 | logs/S-audit-inject-c3f.log |
| S-audit-recon-base | 2026-10-12 23:40:45 | 0 | 292.3 | logs/S-audit-recon-base.log |
| S-audit-hostile-base | 2026-10-12 23:45:04 | 0 | 177.0 | logs/S-audit-hostile-base.log |
| S-audit-recon-c3f | 2026-10-12 23:44:42 | 0 | 347.9 | logs/S-audit-recon-c3f.log |
| S-audit-hostile-c3f | 2026-10-12 23:48:08 | 0 | 179.8 | logs/S-audit-hostile-c3f.log |

```
S-boot-same-base | every page, source, save and error list is identical either way | exit: 0
S-audit-base | ALL CHECKS PASSED | exit: 0
S-audit-ppt-base | ALL CHECKS PASSED | exit: 0
S-audit-other-base | ALL CHECKS PASSED | exit: 0
S-legacy-fsrc-base | every legacy Force setting computes exactly as before | exit: 0
S-check-base | all checks passed | exit: 0
S-audit-inject-base | ALL CHECKS PASSED | exit: 0
S-boot-same-c3 | every page, source, save and error list is identical either way | exit: 0
S-audit-c3 | ALL CHECKS PASSED | exit: 0
S-audit-ppt-c3 | ALL CHECKS PASSED | exit: 0
S-audit-other-c3 | ALL CHECKS PASSED | exit: 0
S-legacy-fsrc-c3 | every legacy Force setting computes exactly as before | exit: 0
S-check-c3 | all checks passed | exit: 0
S-audit-inject-c3 | ALL CHECKS PASSED | exit: 0
S-boot-same-c3f | every page, source, save and error list is identical either way | exit: 0
S-audit-c3f | ALL CHECKS PASSED | exit: 0
S-audit-ppt-c3f | ALL CHECKS PASSED | exit: 0
S-audit-other-c3f | ALL CHECKS PASSED | exit: 0
S-legacy-fsrc-c3f | every legacy Force setting computes exactly as before | exit: 0
S-check-c3f | all checks passed | exit: 0
S-audit-inject-c3f | ALL CHECKS PASSED | exit: 0
S-audit-recon-base | ALL CHECKS PASSED | exit: 0
S-audit-hostile-base | ALL CHECKS PASSED | exit: 0
S-audit-recon-c3f | ALL CHECKS PASSED | exit: 0
S-audit-hostile-c3f | ALL CHECKS PASSED | exit: 0
```

Base vs final c3, line for line (`logs/suites-compare.txt`; header and timing lines left out):

```
boot-same: lines base 12, c3f 12, differing (timing lines removed) 0
audit: lines base 10, c3f 10, differing (timing lines removed) 0
audit-ppt: lines base 10, c3f 10, differing (timing lines removed) 0
audit-other: lines base 10, c3f 10, differing (timing lines removed) 0
legacy-fsrc: lines base 13, c3f 13, differing (timing lines removed) 0
check: lines base 69, c3f 69, differing (timing lines removed) 4
audit-inject: lines base 14, c3f 14, differing (timing lines removed) 0
audit-recon: lines base 19, c3f 19, differing (timing lines removed) 0
audit-hostile: lines base 10, c3f 10, differing (timing lines removed) 0
check: the 4 differing lines are the size lines only: '31672 lines, 3.57 MB' -> '31736 lines, 3.58 MB' and 'main script parses (29650 lines)' -> '(29714 lines)' (+64 = the board diff's +70 -6); every check line is the same.
```

### Preservation: existing audit-import blocks this change reaches, built verbatim (mk-pres.sh), on base and on c3

| label | start (ET) | exit | wall s | log |
|---|---|---|---|---|
| P-v189-base | 2026-10-12 23:45:52 | 0 | 61.1 | logs/P-v189-base.log |
| P-w1-base | 2026-10-12 23:46:53 | 0 | 120.6 | logs/P-w1-base.log |
| P-v189-c3 | 2026-10-12 23:48:14 | 0 | 59.5 | logs/P-v189-c3.log |
| P-v196-base | 2026-10-12 23:48:54 | 0 | 88.7 | logs/P-v196-base.log |
| P-w1-c3 | 2026-10-12 23:49:13 | 0 | 115.2 | logs/P-w1-c3.log |
| P-v196-c3 | 2026-10-12 23:51:09 | 0 | 99.7 | logs/P-v196-c3.log |
| P-w3-c3 | 2026-10-12 23:48:25 | 0 | 397.3 | logs/P-w3-c3.log |
| P-v200-base | 2026-10-12 23:50:31 | 0 | 310.9 | logs/P-v200-base.log |
| P-w3-base | 2026-10-12 23:50:31 | 0 | 352.2 | logs/P-w3-base.log |
| P-v200-c3 | 2026-10-12 23:51:51 | 0 | 280.1 | logs/P-v200-c3.log |

```
P-v189-base: 40 checks, 0 failed
P-v189-c3: 40 checks, 0 failed
P-v196-base: 22 checks, 0 failed
P-v196-c3: 22 checks, 0 failed
P-v200-base: 167 checks, 0 failed
P-v200-c3: 167 checks, 0 failed
P-w1-base: 53 checks, 0 failed
P-w1-c3: 53 checks, 0 failed
P-w3-base: 111 checks, 0 failed
P-w3-c3: 111 checks, 0 failed
```

### mcount (text only)

```
# mcount (text only), 2026-10-12 23:24:09 EDT -- third builder
base: {"entries": 1328, "once": 1328, "missing": [], "multiple": [], "unparsed": []}
c1: {"entries": 1334, "once": 1334, "missing": [], "multiple": [], "unparsed": []}
c2: {"entries": 1346, "once": 1346, "missing": [], "multiple": [], "unparsed": []}
c3: {"entries": 1348, "once": 1348, "missing": [], "multiple": [], "unparsed": []}
c3 adopt ids: {"entries": 1348, "once": 1348, "missing": [], "multiple": [], "unparsed": [], "detail": {"v200-adopt-u24-link-guard": 1, "v200-adopt-u24-answer-guard": 1, "v200-adopt-u24-file-guard": 1, "v200-adopt-u24-link-words-later": 1, "v200-adopt-u24-link-words-record": 1, "v200-adopt-u24-file-words-record": 1, "v200-adopt-u29-no-count": 1, "v200-adopt-u29-session-clean": 1, "v200-adopt-u29-record-clean": 1, "v200-adopt-u29-file-base-kept": 1, "v200-adopt-u29-folder-base-kept": 1, "v200-adopt-u29-link-uncounted": 1, "v200-adopt-u29-answer-uncounted": 1, "v200-adopt-u29-takefile-uncounted": 1, "v200-adopt-u29-same-save-kept": 1, "v200-adopt-u29-clash-after": 1, "v200-adopt-u29-promise-yours": 1, "v200-adopt-u29-promise-what-you-have": 1, "v200-adopt-u31-no-mark": 1, "v200-adopt-u31-memory-only": 1}}
# mcount (text only), 2026-10-12 23:39:22 EDT -- c3 rebuilt (commit 3 extended)
c3: {"entries": 1349, "once": 1349, "missing": [], "multiple": [], "unparsed": []}
c3 adopt ids: {"entries": 1349, "once": 1349, "missing": [], "multiple": [], "unparsed": [], "detail": {"v200-adopt-u24-link-guard": 1, "v200-adopt-u24-answer-guard": 1, "v200-adopt-u24-file-guard": 1, "v200-adopt-u24-link-words-later": 1, "v200-adopt-u24-link-words-record": 1, "v200-adopt-u24-file-words-record": 1, "v200-adopt-u29-no-count": 1, "v200-adopt-u29-session-clean": 1, "v200-adopt-u29-record-clean": 1, "v200-adopt-u29-file-base-kept": 1, "v200-adopt-u29-folder-base-kept": 1, "v200-adopt-u29-link-uncounted": 1, "v200-adopt-u29-answer-uncounted": 1, "v200-adopt-u29-takefile-uncounted": 1, "v200-adopt-u29-same-save-kept": 1, "v200-adopt-u29-clash-after": 1, "v200-adopt-u29-promise-yours": 1, "v200-adopt-u29-promise-what-you-have": 1, "v200-adopt-u31-no-mark": 1, "v200-adopt-u31-memory-only": 1, "v200-adopt-u31-other-unmarked": 1}}
# mcount (text only), 2026-10-12 23:44:11 EDT -- final c3
c3: {"entries": 1349, "once": 1349, "missing": [], "multiple": [], "unparsed": []}
c3 adopt ids: {"entries": 1349, "once": 1349, "missing": [], "multiple": [], "unparsed": [], "detail": {"v200-adopt-u24-link-guard": 1, "v200-adopt-u24-answer-guard": 1, "v200-adopt-u24-file-guard": 1, "v200-adopt-u24-link-words-later": 1, "v200-adopt-u24-link-words-record": 1, "v200-adopt-u24-file-words-record": 1, "v200-adopt-u29-no-count": 1, "v200-adopt-u29-session-clean": 1, "v200-adopt-u29-record-clean": 1, "v200-adopt-u29-file-base-kept": 1, "v200-adopt-u29-folder-base-kept": 1, "v200-adopt-u29-link-uncounted": 1, "v200-adopt-u29-answer-uncounted": 1, "v200-adopt-u29-takefile-uncounted": 1, "v200-adopt-u29-same-save-kept": 1, "v200-adopt-u29-clash-after": 1, "v200-adopt-u29-promise-yours": 1, "v200-adopt-u29-promise-what-you-have": 1, "v200-adopt-u31-no-mark": 1, "v200-adopt-u31-memory-only": 1, "v200-adopt-u31-other-unmarked": 1}}
```

## Blobs (git hash-object)

```
c1 00c2ac152cd2f022efea656a3be40dca55c4ac8a prioritization-board-grid.html
c1 b111bfe1b976878b3431c0f118e9d69f2e45f2f0 tools/export-audit/audit-import.mjs
c1 d8f3956b6b0225cdca01a1937d4ddb4ba82d1d8b tools/export-audit/mutate.mjs.txt
c2 d020543e2166b087ad0ac1bdfdb39924c99b74b6 prioritization-board-grid.html
c2 16ae994982de083003a8910b2ad3d4ceafaa07be tools/export-audit/audit-import.mjs
c2 22df04f5152e6ecd6062da3237427b16af38594b tools/export-audit/mutate.mjs.txt
c3 c0d14fcdfb0b90d774c947277e0c8601af779930 prioritization-board-grid.html
c3 97bc28bf559ad733c6cb6d813f801a843e43f3fc tools/export-audit/audit-import.mjs
c3 f0c7dbf44d435092ae5dd271983ecd0121627d42 tools/export-audit/mutate.mjs.txt
7ee209da104b0f03d43d1b90765c3de590ddb571 diffs/all-c3-vs-base.diff
8bee57c1f91b4c7d888e4c86c3bce1e8998730ef diffs/commit1-c1-vs-base.diff
284aeeec8722e6c3201dbd4ec154da0fc6c665bd diffs/commit2-c2-vs-c1.diff
947ac513c749a7fed425834e885a783fe57f7ee8 diffs/commit3-c3-vs-c2.diff
868ae764e5f37557c52aae0220156bf2b3bf80b3 block-u24.mjs.txt
cad2fae862aa9b4e4e9272f37b8d3d783a5dd120 block-u29.mjs.txt
aab496533a66fb2b0b5f26abded0b6a1315b2698 block-u31.mjs.txt
78269c0d6fe52a614e1225cd9598165b67da54eb entries-u24.mjs.txt
e1806e5b44bf3dc5098517c21710c7275d76f84b entries-u29.mjs.txt
b126d7850620d6b19e3d79b74522e0e028fbce99 entries-u31.mjs.txt
7ee3334e45743331dcd54fbb4b4d94cae59ae99e harness/c3/focused-U24.mjs
9f428d43bf3f64072cfa80c355cb4c4ba62f5290 harness/c3/focused-U29.mjs
f2f7e9a9308b03d3279ed514d1f2b687e53d92ec harness/c3/focused-U31.mjs
e17d5ecf6046b1224bfe8974b22fe374b978659e drafts/LEDGER-append.md
791414debbb94904eb27a51dafe8457b970ef6b2 drafts/NEXT-VERSION-entries.md
f851f1391102e59aa12f0ca301b40bb4ddd005f3 runner.mjs
a6ecc18273435ba94361fc79e9454678d34efb0c run.sh
4ae9483024a990e76ee3e0082d801ef7062a9e87 bin/cmpfail.py
189985953e32468bc9a88128cba7e6f9abccf991 bin/edit-c1.py
9f10c309df0c0d403f514a6ebcdebb0aad4a5d27 bin/edit-c2.py
7748002d1114a13cfed0208267846482ac7b701b bin/edit-c3.py
0c1ff3d19aba360d6e550fe3404507c3be7cd902 bin/insert-before.py
1052ceb2628ad41c965e7d75b5251a907492274b bin/insert-block.py
39accfb5fef75565e8429a98fe12dae23bdc9cf4 bin/mk-entries.py
252c00ef658b2db1d8810b0f3d42348f151b1136 bin/mkfocused-import.py
550754006ef002004710a230c7fcd309f3993baa bin/runtable.py
29a28da1295409397a474d595e06c41a2604cba2 bin/summ.py
```

## PIDs

`pids.txt` lines 216-615 are this builder's (lines 1-215 the second builder's): each run's timeout PID and its child, with the time (ET) and the command. The lanes' drivers (`bx:lane-*`) are recorded the same way.

## What I did not do (plainly)

- I committed nothing, pushed nothing, and wrote nothing in `/home/user/orbit-board` or `/home/user/orbit-ui` (the scratch
  clones under `git/` are `--shared` clones with files copied over in the work tree; nothing was committed there either).
- I did not run the full `audit-import.mjs` or `audit-board.mjs` (the lead's). The blocks' sensitivity in the full suite,
  and the full mutation run, are for the final-tree queue.
- I did not import, execute or run `mutate.mjs`; entries were counted and applied as text (`mcount.py`, `mkmut.py`).
- I did not run any Chromium tool (no layout or drawing changes; the new status lines are text in the existing status bar;
  no `verify:grid` run).
- I did not run the U24 and U29 mutants on the final c3 (each was run on its own commit's copy, where its block was added);
  the U24 and U29 blocks themselves pass on the final c3 (F5-*).
- I did not measure or change the other paths that write another appropriation's board into browser storage without marking
  its record (decision 4): by code only.
- I did not re-run the second builder's reproduction (kept; its logs are complete and on the same base blob). My focused runs
  on the base reproduce every defect the three blocks test.
- I did not change any existing check, fixture, expected value or mutation entry.
- I did not write the NEXT-VERSION.md or ledger text into any repository: they are drafts in `drafts/`.
- Waiting: two kinds of wait were not under `setsid -w timeout`: Monitor-tool watches (tool-bounded, at most 30 min; they
  read `logs/runs.txt` and `ps` only) and one background wait loop (Bash tool, 590 s cap) meant to start a lane through
  `bx.sh` once an earlier lane ended. That loop never ended (its own command line matched its `pgrep -f` pattern), started
  nothing, and was stopped through the tool as my own background task; I started the lane by hand (both noted in
  `logs/runs.txt`). Later waits were `setsid -w timeout -k 5 300|590 bash -c 'until …; do sleep 5; done'` loops that only
  read `ps` and `logs/runs.txt`; they are bounded but not recorded in `pids.txt`. Every node run and every other command went through
  `run.sh` or `bx.sh` (`setsid -w timeout -k 10 600`, its own process group, PIDs in `pids.txt`). Apart from stopping that
  waiting loop of mine through the tool, I stopped or killed nothing.
