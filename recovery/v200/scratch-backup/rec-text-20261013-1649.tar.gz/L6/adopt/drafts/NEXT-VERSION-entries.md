# Drafts for NEXT-VERSION.md (ADOPT track: U24, U29 (U17), U31) -- for the lead; nothing here is committed

FIX ROUND (13 Oct 2026). These texts replace the build's (kept as `superseded-r3/drafts/NEXT-VERSION-entries.md`). What
changed, and why, is in README.md, "Fix round". Each entry goes under "### v2.00", after the U14 entry and before
"Unresolved after R1–R5", in commit order. The check counts and failure counts are the focused runs' (README.md, "Fix round:
runs"); full audit-import sensitivity is the lead's to run.

## Entry for commit 1 (U24)

- **U24 — another copy is not put on screen during a save** (the lead's decision under Brad's "Don't wait for me. Let's keep
  pressing throughout to get this next version published", 12 Oct, about 5:30 PM ET; U13's late-guard pattern, as Brad chose
  it for U13 on 12 Oct, 6:00 AM ET). Three loads put another copy on screen while a save was still writing: "load the shared
  one" (`adoptShared`), the shared state file's own load when its answer arrives (`sharedArrived`), and "open the file's
  version" (`bootTakeFile`). The save, landing, found nothing changed, marked the board saved and recorded the copy it wrote
  as the one the work on screen came from, while the screen showed the copy loaded -- U13's shape, reproduced in folder and
  file mode for the link, in folder mode for the answer (through a refresh and a reopen), and in both modes for "open the
  file's version". The next 💾 Save then wrote the loaded copy over the save's copy without asking; from the board file
  (FBT), the save's copy was then in no copy the board can reach. Now each of the three checks for a save under way just
  before it would change anything -- after `bootTakeFile`'s question, its last wait; nothing waits in the other two -- and
  while one is under way it loads nothing and changes nothing: what is on screen, browser storage, this browser's record, the
  change count and the work kept aside stay byte for byte as they were. It says what was not loaded, how to load it once the
  save has finished, and when it is looked for again. The refusal does not depend on whether anything was typed in this
  session, nor on where the save goes. With no save under way each load works as before.
  - **What users may see:** a click during a save must be made again once the save has finished. The lines are: "⏳ The
    shared state file was not loaded: a save was under way. Nothing was changed: what is on screen and the work kept aside are
    as they were. Once the save has finished, load the shared one; the shared state file is also looked for again the next
    time the board is opened."; "⏳ The shared state file (<time>) arrived while a save was under way, so it was not loaded
    and nothing was replaced. Once the save has finished, load the shared one; it is also looked for again the next time the
    board is opened."; and "⏳ The saved file’s version was not opened: a save was under way. Nothing was changed: what is on
    screen is as it was. Once the save has finished, open the file’s version; the file is also checked again the next time it
    is opened." Each names only what a save leaves as it is, never this browser's record: a quiet autosave says nothing when it
    lands, so a line can still be on screen after it. A 💾 Save that lands replaces the line with its own, as every save does.
    Two behaviour changes that were consistent before: the link clicked while a folder save was still reading the folder's
    copy, and the answer arriving while a file save was reading, loaded the shared state file and the save then wrote it; both
    are now refused like the rest (the first is tested, U24 (1Wread); the second is by code).
  - **Test:** audit-import "v2.00 (U24) — another copy is not put on screen during a save" (65 checks): the link while a
    folder save is held at its write, at its history copy, at its read, and as the Live autosave (whose landing leaves the
    refusal on screen, still true, and whose link then loads); the link while a board-file save is held; the answer, stamped an
    hour ahead and stamped after the save began, while a folder save is held; "open the file's version" while a board-file
    save is held (asked, then refused); the link a refused answer offers, clicked while that save is still held with nothing
    typed in this session (6); and "open the file's version" working out of the shared folder while a folder save is held (7).
    Each refusal is checked byte for byte (screen, storage, record, change count, kept work) and word for word, then the
    landing, a refresh and a reopen, and the shared state file offered again at that opening. Controls: each load with no save
    under way, and an ordinary edit during a held save. 33 checks fail on the board before the change; every check
    marked a CONTROL (28), and the four of the "(5)" control scenarios, pass on it.
  - **Mutations:** `v200-adopt-u24-link-guard`, `-answer-guard`, `-file-guard` (each guard switched off),
    `-link-guard-dirty-only` (the link refused only when this session has typed), `-takefile-guard-file-only` ("open the
    file's version" refused only when saving to the board file), `-link-words-later` (the refusal promises a load nothing
    makes), `-link-words-record` and `-file-words-record` (the refusal says this browser's record is as it was); each caught
    by the focused block (full-suite sensitivity runs in the final-tree queue).
  - **Not covered:** a save waiting for another tab's Web Lock is not counted as under way until it starts (U20); a refused
    "open the file's version" is offered again only by the line itself or by an opening that holds the file back; after a
    non-quiet save lands, the refusal's link is gone with the line, and only a reopen offers the load again (the words say
    so); a later quiet Live refresh can change the screen under a refusal that a quiet autosave left on screen (as with U2's
    words; by code). The shared state file's link and load leaving a board recorded saved are the next commit (U29).

## Entry for commit 2 (U29, and with commit 1 the rest of U17)

- **U29 — another copy put on screen is a change from what is saved** (the lead's decision of 12 Oct under Brad's "Don't
  wait for me"; the U17 checker's P3, count the load as a change, with the U17 builder's P2 for `bootTakeFile` in folder
  mode). "Load the shared one", the shared state file's own load and -- working out of the shared folder -- "open the file's
  version" counted nothing. A board recorded saved stayed recorded saved against the copy it had come from while it showed
  the copy loaded, with no save anywhere near: the header said Saved, a reopen kept nothing aside, and the next 💾 Save wrote
  the loaded copy over the person's own without asking. From the board file, the person's copy was then in no copy the board
  can reach (XFSHn, and the shared state file's own load in file mode); in the folder, only in its history (for every year
  the loaded copy replaced). Now such a load is counted as an edit is (the change count, this session and this browser's
  record all say unsaved), and the record stops naming a saved copy the screen did not come from: for the board file nothing
  is recorded, so Save asks before it writes over the file; for this appropriation's copies in the shared folder, every year
  of them, the loaded copy's own save is recorded, so Save -- and the Live autosave -- asks before writing over any other.
  The person's own copy stays where it was saved until they choose, and a reopen keeps the loaded copy aside before a saved
  copy replaces it. The shared state file that is the very save on screen (the same time) is not another copy: it loads as
  before, is not counted and keeps nothing aside -- so a board whose shared state file is its own save still opens saved, and,
  answering an opening before the folder is read, it leaves that opening free to load the folder's newer copy. The folder's
  clash line says "after the copy you are working from" only when that is so, and otherwise "and that is not the copy you are
  working from"; in that case the refresh says "What is on screen came from another copy, which may not have their changes."
  (the copy on screen can hold them). The two links' promise names what they keep aside: "work no saved copy has is kept
  aside first" (it said "yours" and "what you have", which a board recorded saved did not get).
  - **What users may see:** after "load the shared one", or the shared state file loading on its own, the header says
    unsaved changes in that session. After a reopen that keeps the loaded copy on screen, the header reads Saved, as after any
    unsaved work (ledger U15, unchanged), while this browser's record still says unsaved. The next 💾 Save asks first: to the
    board file, "⚠ HOLD ON —
    this file was last saved by <name> at <time>, and this browser cannot tell whether that was before or after the copy you
    are working from." (OK writes, Cancel keeps the file as it is); to the shared folder, "⛔ <name> saved O&M FY27 to the
    shared folder <age>, after the copy you are working from. Nothing was written. Load theirs (your work is kept aside, and
    one click puts it back) · Save yours over theirs (theirs is kept in the folder’s history)." -- or, where the folder's copy
    is older than the copy on screen, "…, and that is not the copy you are working from. …". With Live view on, the refresh
    offers the same choice (saying "What is on screen does not have their changes." when the folder's copy is the later one,
    and "What is on screen came from another copy, which may not have their changes." when it is not), and the autosave writes
    nothing until the person chooses. The links read "load the shared one (work no saved copy has is kept aside first)".
  - **Test:** audit-import "v2.00 (U29) — another copy put on screen is a change from what is saved" (55 checks): the
    link from a board recorded saved, in the folder (XSHn) and the board file (XFSHn: Cancel keeps the file, a reopen keeps
    both copies, "overwrite anyway" writes as chosen); the load after a save has landed in the same session (XSHdL, XFSHdL);
    the shared state file loading on its own, in the folder (SHaC: refresh, Live autosave, Save and a reopen, with the words
    checked both ways round) and saving to the board file (9: Save asks, Cancel keeps BRAD-1 in the file, a reopen keeps the
    record unsaved); "open the file's version" in the folder (BTC: counted, Save asks, and after a reopen Save still asks);
    the link with two years in the folder, then Save on the other year (10); the shared state file answering each opening
    before the folder is read (11: the first opening says a reload takes theirs, and the reload does, keeping SHARED aside);
    the shared state file built on the folder's own copy, then a refresh (12: the words); and controls -- the link with
    unsaved work keeps it aside first; "open the file’s version" saving to the board file stays recorded saved against it; and
    the shared state file that is the very save on screen, in the file and the folder, leaves the board saved and Save asking
    nothing (13). 34 checks fail on the board before U24 and 34 on the U24 commit; every check marked a CONTROL
    (21) passes on both.
  - **Mutations:** `v200-adopt-u29-no-count`, `-session-clean`, `-record-clean`, `-file-base-kept`, `-folder-base-kept`,
    `-year-on-screen-only`, `-link-uncounted`, `-answer-uncounted`, `-answer-file-kept`, `-same-save-recounted`,
    `-takefile-uncounted`, `-same-save-kept`, `-clash-after`, `-clash-lacks`, `-promise-yours` and `-promise-what-you-have`;
    each caught by the focused block (full-suite sensitivity runs in the final-tree queue).
  - **Not covered:** "open the file's version" working out of the folder, then a reopen from that same file: the opening
    finds the file's own save on screen and records the board saved, as every such opening does (also the opening that takes
    the file's newer version on its own: the U15–U20 family). Nothing is lost there: the copy on screen is the board file's own
    save, and the record still names no folder copy the screen did not come from, so 💾 Save still asks, which U29 (6)
    checks. Saving to the board file, the loaded copy's record names no save of the file, so an opening no longer says "the
    file has been saved since then as well", and Save's question says "this browser cannot tell whether that was before or
    after" where it could tell; Save still asks. The clash line's
    other words ("their" for one's own save from another browser) are as they were; with Live view on, the refresh and the
    autosave repeat the choice at every tick until the person makes it, as they do for any clash; Save a copy (a download) is
    not a save of the file or the folder and is unchanged. Changed in meaning, not in text (principle 6): audit-import's v1.95
    item-47 check "the next refresh raises no false clash" (`/after the copy you are working from/` absent, base line 3935)
    no longer sees a false clash worded "and that is not the copy you are working from".

## Entry for commit 3 (U31)

- **U31 — a batch import marks this browser's records unsaved** (the lead's decision of 12 Oct under Brad's "Don't wait for
  me"; the U24 builder's P3, widened to every appropriation the batch writes). ⇊ Import several boards at once (📁 File →
  Boards and appropriations) counted the board it put on screen as a change in this session only, and wrote the other
  appropriations' boards into browser storage without a word to their records. Each record still said saved: a reopen took
  the imported board as saved, and when the saved copy was newer than the import -- an older board file imported, or a save
  landing during the import -- the opening loaded the saved copy with nothing kept aside, leaving the import only in the file
  it came from. The same happened on switching to another appropriation the batch wrote, where that appropriation's record
  said it was the file's own save. Now the import marks the record unsaved, as `save()` marks it for every edit: for the
  board on screen, and for every other appropriation it wrote. A reopen keeps the imported board, unsaved by the record, or
  keeps it aside before a newer saved copy replaces it; an appropriation whose stored copy is the file's own save is marked
  saved again by its own opening, as before.
  - **What users may see:** after a batch import, an opening that finds a newer saved copy keeps the imported board aside
    first ("kept aside", with ↶ Put back) where it replaced it with nothing kept; the same on switching to another
    appropriation the batch wrote. The header after a reopen still reads Saved, as it does after any unsaved work (ledger
    U15, unchanged); only this browser's record, and what an opening does with it, change.
  - **Test:** audit-import "v2.00 (U31) — a batch import marks this browser’s records unsaved" (34 checks): in the folder
    and the board file, an import newer than the saved copy (IB-*-C1clean), one older than it (IB-*-C1oldclean), and one made
    while a save is held, which lands stamped after it (IB-fold-Wclean; the board-file case is a control: the file save marks
    the record itself), each reopened; and another appropriation the batch wrote (W2's consolidated fixture): Full Fund
    imported older than the file's, with its record saying it is the file's own save, then the switch to Full Fund (with no
    record, as a control). It checks the record and what is kept, not the header. 14 checks fail on the board before the
    change and on the U29 commit alike; every check marked a CONTROL passes on all three. The v1.97 W3 batch-import block is
    unchanged.
  - **Mutations:** `v200-adopt-u31-no-mark`, `v200-adopt-u31-memory-only`, `v200-adopt-u31-other-unmarked`; each caught by
    the focused block.
  - **Not covered:** other imports leave the record clean too. 📁 File → ⬅ Import a full board (`fullImportText`) writes THIS
    appropriation's board into browser storage without marking its record: measured by the money verifier on the board
    before this track and on this track's earlier c3 alike (probe P7-full: a reopen under a newer saved copy loads it and
    keeps nothing aside, the import then only in the file it came from); Import one appropriation does the same by code. A
    new ledger row is drafted. And the paths that write ANOTHER appropriation's board into browser storage (package and
    appropriation imports, plan and band-ladder writes) do not mark that appropriation's record (by code, not measured).
    None of them is changed here.

## Replacement texts for "Unresolved after R1–R5"

- In the U13 line, replace "three other adoption paths that do not wait for a save (unverified);" with "three other adoption
  paths that did not wait for a save (U24, built below);".
- In the U13 entry's "Not covered" (above the list), "the other adoption paths in the ledger (U24)." could read "the other
  adoption paths in the ledger (U24, built after it)." -- optional; it is true as it stands of the time it was written.
- Add, after the U14 line:
  - **U24: built as its own commit** (the lead's decision of 12 Oct under Brad's "Don't wait for me"): "load the shared
    one", the shared state file's own load and "open the file's version" refuse while a save is under way, checked after
    their last wait, and change nothing (above). `importBoards` needed nothing here: it is counted (see U31).
  - **U29: built as its own commit after U24**: a load of another copy is counted as a change, the record stops naming a
    copy the screen did not come from, and the next Save asks; the very save on screen is not another copy and is not
    counted. With U24 this answers the routes the U17 triage still reached (FBT, SHd, SHdk and FSHd through U24's refusal;
    the no-save routes, XSHn, XFSHn, XSHdL, XFSHdL and SHaC in both modes, through U29). Left open: after "open the file's
    version" working out of the folder, a reopen from that file records the board saved (the U15–U20 family); Save still asks.
  - **U31: built as its own commit after U29**: a batch import marks this browser's records unsaved -- the board on screen
    and every other appropriation it wrote (the latter measured too). Left open, for Brad's decision: ⬅ Import a full board
    and Import one appropriation leave this appropriation's record clean (measured; new ledger row), and other paths that
    write another appropriation's board into browser storage do not mark its record (by code, not measured).
