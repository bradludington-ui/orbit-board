# Drafts for recovery/v200/UNRESOLVED-LEDGER.md (ADOPT track) -- text to APPEND to each row's Status cell, and one new row

FIX ROUND (13 Oct 2026): these texts replace the build's (kept as `superseded-r3/drafts/LEDGER-append.md`). Placeholders:
`<sha1>`, `<sha2>`, `<sha3>` = the lead's commits; `<time>` = the lead's commit time (ET). Blobs are the proposed copies'
(README.md, "Fix round: blobs"); if the lead's commits differ in any byte, the blobs must be re-read from them.

## U24 (append to its Status cell)

**COMMITTED as `<sha1>` (<time>)**: board `00c2ac15`, audit-import `195381b5`, mutate `8a7a83e8`. `adoptShared`
("load the shared one"), `sharedArrived`'s own load and `bootTakeFile` ("open the file's version") check `_saveBusy` just
before they would change anything (after `bootTakeFile`'s question, its last wait; nothing waits in the other two) and,
while a save is under way, load nothing and change nothing (screen, storage, record, change count, kept work byte for
byte); the words name only what a save leaves as it is. The refusal holds whether or not anything was typed in this session,
and for "open the file's version" working out of the folder too. Focused block "v2.00 (U24)" 65 checks: 33 fail
on the base (`fce8a391`), all pass on the U24, U29 and U31 copies; every CONTROL passes on the base. Eight mutations caught.
`importBoards` needed no change here (it is counted; its record is U31). Full audit-import sensitivity: in the final-tree
queue.

## U29 (append to its Status cell)

**COMMITTED as `<sha2>` (<time>)**, after U24: board `0bbfedb6`, audit-import `54efb128`, mutate `4a533f68`.
`loadedNotSaved()`: "load the shared one", the shared state file's own load and (working out of the folder) "open the file's
version" count as an edit (`_saveGen`, `DIRTY`, `_baseDirty`, the record's `dirty`), and the record stops naming a copy the
screen did not come from (the file: nothing recorded, Save asks; the folder: the loaded copy's own save recorded for every
year, Save and the Live autosave ask). The shared state file that is the very save on screen is not another copy: loaded as
before, not counted, nothing kept aside. The folder clash says "after" only when it is, and otherwise does not say the screen
lacks their changes; the links promise to keep aside "work no saved copy has". Focused block "v2.00 (U29)" 55 checks:
34 fail on the base and 34 on the U24 copy, all pass on the U29 and U31 copies. Sixteen mutations caught.
Covered: XSHn, XFSHn (Cancel keeps BRAD-2 in the file; a reopen keeps both copies), XSHdL, XFSHdL, SHaC in the folder and
in the board file, BTC (counted, and 💾 Save asks, also after a reopen), two years in the folder, the shared state file
answering an opening before the folder is read, and the very save on screen (a control). **Not covered:** after BTC, a
reopen from that same file records the board saved again (the opening's own rule for the file's own save; the same as the
opening that takes the file's newer version on its own, U15–U20 family); nothing is lost, Save still asks.

## U17 (append to its Status cell)

**Addressed by U24 (`<sha1>`) and U29 (`<sha2>`)** (<time>; for the lead to close): FBT (`bootTakeFile` during a file save)
and SHd/SHdk/FSHd (`adoptShared` during a save) are refused under U24; the same falsely clean record with no save (U29's
XSHn, XFSHn, XSHdL, XFSHdL, SHaC) is counted under U29, so the next Save asks and the person's copy stays where it was saved.
Its V3next/V4putback routes through U13 were already closed by `63bd8b0`.

## U31 (append to its Status cell)

**COMMITTED as `<sha3>` (<time>)**, after U29: board `d1cdcdf5`, audit-import `fb163d3c`, mutate `1fcc407e`.
`importBoards` marks this browser's record unsaved when the board on screen took the import, as `save()` does, and marks
the record of every other appropriation it wrote (`<key>.base`, `dirty:true`). Focused block "v2.00 (U31)" 34 checks:
14 fail on the base and on the U29 copy alike, all pass on the U31 copy. IB-fold-C1clean, IB-file-C1clean,
IB-*-C1oldclean, IB-fold-Wclean (the measured loss: the import kept aside at the reopen) and another appropriation the batch
wrote (measured on the base: switching to it opened the file's newer copy with nothing kept aside) are covered;
IB-file-Wclean and the no-record case are controls. Three mutations caught. The header after a reopen still reads Saved
(U15, unchanged): what changes is the record and what an opening keeps. **Not covered:** ⬅ Import a full board and Import
one appropriation (new row below); other paths that write another appropriation's board into browser storage do not mark
its record (by code, not measured). For Brad's decision.

## New row (after U43, or wherever the lead numbers it): the full import leaves this browser's record clean

| U<n> | **⬅ Import a full board leaves this browser's record clean.** `fullImportText` writes every appropriation's board (stamped now), the locked cycles and the board-wide lists into browser storage in one all-or-nothing set, then reopens -- and never marks any record unsaved. Reopened, the board shows the import as this browser's own copy, recorded saved against the copy it came from; when a newer saved copy is in the shared folder, the opening loads it with nothing kept aside, and the import is then only in the file it came from. Import one appropriation (`lsSet` and a reopen) does the same by code. U31's shape. | ADOPT money verifier r1 (13 Oct, `rec/L6/adopt/verify-money-r1`, probe P7-full) | Measured on the base (`fce8a391`) and on the ADOPT track's build c3 (`c0d14fcd`) alike: BRAD-1 saved to the folder, Carol's board fully imported, OTHER-2 saved from Brad's other browser, reopen → OTHER-2 on screen, nothing kept aside | Open, P2 provisional (the import survives in the file it came from). Fix, by U31's pattern: inside the import's all-or-nothing set, mark `<key>.base` `dirty:true` for every board key it writes. Not applied. |
