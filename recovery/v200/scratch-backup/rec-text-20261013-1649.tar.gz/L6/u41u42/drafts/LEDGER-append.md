<!-- recovery/v200/UNRESOLVED-LEDGER.md: text to APPEND to the Status cell of rows U41 and U42 (after the lead's 1:19 PM ET
     note). <sha1>/<sha2> are the two commits, <time> the time each lands (Eastern). Nothing in either row is replaced. -->

## U41: append to the Status cell

**Fixed in `<sha1>` (<time> ET, 13 Oct; fix track u41u42, from Codex's A4 proposal after review).** `applyState` keeps the
code exactly as saved; `siOf` reads such a code as no SI code, never the derived one (on the fixture R1, an LM prime holding
"at", had its $1,100,000 under LA before; now it is under "— no recognized code —", and LA holds only R3's $50,000). On O&M it
is listed in Needs attention and Pre-flight; the Navy SI code field shows it selected (also on a requirement with no Navy or
Marine money); Go to it opens that field; a bulk write counts it as an answer it would overwrite; the overview's and the
workbook's no-code rows say "no recognized" code while one is held, the overview's note splits that row's money, and the CR
cash return's status line counts those rows apart. Full Fund, Initial Spares and OPN keep it and list nothing. Beyond
Codex's proposal: the bulk write's count (it said "0 would be overwritten" for a kept code), the words of the overview, the
SI tab and the CR status (they said "no code set" over such money), the O&M-only listing (Codex's listed it on Full Fund,
where its field does not exist), and Go to it opening the field. Test: audit-recon "v2.00 (U41) — …" (37 checks; 29 fail on
`7ee498a`, the 8 controls pass on both). Mutations: 17 `v200-u41-*`, each caught by the focused block. Not covered: a PMO
submittal holding one is still left out and named at the door (`pmoNorm`, unchanged); a locked-cycle view; Initial Spares
and OPN by code only (Full Fund run); no browser or Excel run. **Closed when the lead integrates `<sha1>`.**

## U42: append to the Status cell

**Fixed in `<sha2>` (<time> ET, 13 Oct; fix track u41u42).** exportFlow's `tabName` keeps the 28- and 26-unit cuts but
drops a first half of a two-part character the cut leaves at the end, and strips apostrophes (and spaces) at either end, before
a name is used, whether the name had them or the cut left them; an apostrophe inside a name stays. Measured from the
workbook's bytes on the working board and after a save and reopen: "D" x27 + 😀 + "tail" is the sheet "D" x27 (it was
"D" x27 + U+FFFD), the repeat's 26-unit cut gives "E" x25 + " 2" (it was "E" x25 + U+FFFD + " 2"), 'Quoted depot' is
Quoted depot, "F" x27 + "'tail" is "F" x27, and `xl/workbook.xml` holds no U+FFFD. Test: audit-recon "v2.00 (U42) — …" (18
checks; 8 fail on `7ee498a`, the 10 controls pass on both). Mutations: 5 `v200-u42-*`, each caught. Composes with U37's
refusal (`_xlsxRefused` checks each sheet name as written, after `tabName`; `tabName` only removes characters, so it never
makes a name U37 refuses). Not covered: whole grapheme clusters (joined emoji, combining marks, flags) can still be split
between code points (well-formed text, not U+FFFD); `buildXlsx`'s own 31-unit cut and the Priority drill's "PMO " sheet
names; the slide deck's 56-unit title cut (the registry-text track's note); a sheet named "History"; Excel itself.
**Closed when the lead integrates `<sha2>`.**
