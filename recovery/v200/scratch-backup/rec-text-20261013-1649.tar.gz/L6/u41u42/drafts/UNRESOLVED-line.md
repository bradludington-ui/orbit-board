<!-- NEXT-VERSION.md, "Unresolved after R1–R5 (11 Oct)". At 7ee498a (and at orbit-board 4bbec77, read 13 Oct) that list has NO
     line for U41 or U42, so there is nothing of its own to replace. Two cases:

     (a) The registry-text track (rec/L6/regtext, still in review) has NOT landed: add this line after the U14 line, in the
         commit that lands second (commit 2), or split it -- the U41 half in commit 1, the U42 half in commit 2: -->
  - **U41 and U42: fixed, each its own commit** (fix track u41u42, from Codex's A4 proposal; joining v2.00 by the lead's
    rule of 13 Oct, 1:19 PM ET, only if both reviews are clean by the time U37's and U40's are). An SI code a file carried
    that is not one of the five is kept as saved, listed, and its money counted under no recognized code (U41, above); a
    funds-flow sheet name never ends in half a character or begins or ends with an apostrophe (U42, above).

<!-- (b) The registry-text track HAS landed first: its line "The registry-text review …" carries two sub-bullets that these
         commits supersede. Replace its sub-bullet beginning "- **U41 (P2 proposed; a fix track joins v2.00 only if its reviews
         are clean in time).**" (three lines) with: -->
    - **U41: fixed above** (its own commit): the code is kept as saved, listed in Needs attention and Pre-flight, its money
      counted under no recognized code, never the derived one, and chosen again in the Navy SI code field.
<!--     and its sub-bullet beginning "- **U42 (P2; the same fix track).**" (three lines) with the following. The slide-deck
         sentence stays, because U42's commit does not change the deck: -->
    - **U42: the sheet name fixed above** (its own commit): a funds-flow sheet name no longer ends in half an emoji or
      begins or ends with an apostrophe. Still open: the slide deck's 56-unit cut of a requirement title can split an emoji
      the same way (a replacement mark in the slide).
<!--     Its NEXT-VERSION entry's U41 and U42 sub-bullets under U36's "Not covered" (beginning "- **U41 (P2; fix track u41u42
         under way on 13 Oct …" and "- **U42 (P2; the same fix track as U41).**") are superseded the same way: drop the U41
         one, and cut the U42 one down to its slide-deck sentence and its sentence on the writer's 31-unit cut. -->
