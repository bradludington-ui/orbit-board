<!-- Two entries for NEXT-VERSION.md, under "### v2.00", after the U14 entry and before "- **Unresolved after R1–R5 (11 Oct).**"
     (the U13 / U1 / U14 style). Commit 1 adds the U41 entry; commit 2 adds the U42 entry after it. Counts are from the runs in
     README.md (F3-*, M-*); the lead re-checks them against the final tree. -->
- **U41 — an SI code a file carried that is not one of the five is kept, listed and never guessed** (lead, 13 Oct, 1:19 PM
  ET: a fix track from Codex's A4 proposal, joining v2.00 only if both reviews are clean by the time U37's and U40's are).
  Opening a year deleted any SI code that was not exactly LA, EN, OT, FL or AT (for example "at", "LA " or "ZZ") without a
  word, and the next save lost it. The requirement then read its derived code, so on the test fixture an LM prime's
  $1,100,000 was filed under LA in the Special Interest overview, the workbook's SI Codes by Month tab and the CR cash
  return. Only a file ORBIT did not write can carry such a code: the board's own picker writes only the five. Now the code is
  kept exactly as it was saved, opened and after a save, and nothing guesses at it: it is not trimmed, put in capitals or
  replaced by the derived code. On O&M its money is counted under no recognized SI code, and the code is named in Needs
  attention ("🏷 SI codes to repair") and in Pre-flight ("SI codes the board does not recognize"). The requirement's Navy SI
  code field shows it, selected, as "“at” — not one of the five, kept as saved", also on a requirement with no Navy or Marine
  money (which had no field before). Go to it opens that field. Choosing a code there replaces it, and the change journal
  keeps the code as saved. A bulk write counts it as an answer it would overwrite. While such a code is held, the overview's
  no-code row and the workbook's say "no recognized" code, the overview's note says how much of that row is under such codes,
  and the CR cash return's status line counts those rows apart from "no SI code". Every report that prints SI codes (the CR
  cash return, the Spend Plan Source, the ACE workbook) leaves its SI code blank. On Full Fund, Initial Spares and OPN, where
  nothing reads an SI code, it is kept and not listed.
  - **What users may see:** only with a file ORBIT did not write. A "🏷 n SI codes to repair" entry under Needs attention
    and a Pre-flight row. Money that was under a derived code is now under "— no recognized code —", with the note saying so.
    The Navy SI code field on a USAF / ANG / AFRC requirement holding such a code. A CR cash return status line that counts
    those rows apart.
  - **Test:** audit-recon "v2.00 (U41) — an SI code a file carried that is not one of the five is kept, listed, counted under
    no recognized code and chosen again in its field" (37 checks). The fixture: an O&M file holding "at" on an LM prime
    (derived LA) and "ZZ" beside the five codes, a blank by hand and a derived EN; nine requirements, $1,910,000 on STOVL /
    USMC CV / USN. Opened, and after a save and reopen: the stored map, the codes read, Needs attention (its strip entry, list
    and Go to it), Pre-flight, the bulk write's question, the overview's rows ($1,210,000 = 63.4% under no recognized code, LA
    only R3's $50,000) and note, the workbook's SI tab from its bytes, and the CR cash return's SI cells and status. Then AT
    and none chosen in the field, saved and reopened: the list empties, the money moves to AT, the rows say "no SI code set"
    again, and the journal holds "at" → AT. Also "LA ", "la", "__proto__", 7, {"x":1} and null kept and listed, Full Fund
    keeping and not listing, and a USAF / ANG requirement given the field. 29 checks fail on the board before the change; the
    8 controls pass on both.
  - **Mutations:** `v200-u41-dropped-on-opening`, `-derived-guess`, `-capitals`, `-trim-known`, `-unlisted`,
    `-listed-off-om`, `-no-field`, `-field-shows-none`, `-bulk-blank`, `-strip-silent`, `-preflight-silent`,
    `-goto-row-only`, `-overview-label`, `-overview-note-none`, `-workbook-label`, `-cr-counts-twice` and `-cr-silent`. The
    focused block catches each one.
  - **Not covered:** a PMO submittal or proposal carrying such a code is still left out at the portfolio board's door and
    named there (`pmoNorm`, unchanged), and a PMO copy published from a board holding one carries it in its baseline as saved.
    A requirement removed while it holds one keeps it, unlisted, until restored (seen in a probe, not a suite check). A
    locked-cycle view lists the codes it holds; choosing one there is refused like any edit in a view (not exercised). Nothing
    offers the nearest of the five as a choice: a person picks. Initial Spares and OPN take Full Fund's path by code (only
    Full Fund was run). jsdom only; no browser, Excel or LibreOffice was run.
- **U42 — a funds-flow sheet name never ends in half a character or begins or ends with an apostrophe** (lead, 13 Oct,
  1:19 PM ET: the same fix track as U41). On the destination axis each destination gets a sheet named after it, cut to 28
  UTF-16 units (26 when it numbers a repeat). A cut through an emoji left its first half at the end, and the workbook wrote
  that as U+FFFD: a destination named with 27 letters and an emoji became a sheet named with 27 letters and a replacement
  mark. A name beginning or ending with an apostrophe, or one the cut left ending with one, became a sheet name a
  spreadsheet may not have. Now a cut that would end on the first half of a two-part character leaves that half out (in the
  first cut and in a repeat's), and an apostrophe or space at either end of a sheet name goes. The lengths are as before,
  every other name is exactly what it was, and an apostrophe inside a name (O'Brien) stays. Only the sheet name changes: the
  destination's name in the board and in the workbook's cells is never cut.
  - **What users may see:** a destination sheet named "Quoted depot" for 'Quoted depot', and one character shorter where an
    emoji fell on the cut ("EEEE… 2" where it was "EEEE…� 2").
  - **Test:** audit-recon "v2.00 (U42) — a funds-flow sheet name never ends in half a character or begins or ends with an
    apostrophe" (18 checks): seven destinations added by hand (27 D's and an emoji; 'Quoted depot'; two names whose 28-unit
    cuts match, the first keeping its emoji whole and the repeat's 26-unit cut ending on the first half; 27 F's then an
    apostrophe; O'Brien; Plain depot), the sheet names read from `xl/workbook.xml` in the workbook's bytes, on the working
    board and after a save and reopen. No U+FFFD in the part, no name beginning or ending with an apostrophe, every name 31
    units or fewer and unique, the part parses; the money (TOTAL FUNDING $1,100,000, R1's two service rows on its
    destination's sheet) and the seven names in the board's data unchanged. 8 checks fail on the board before the change;
    the 10 controls pass on both.
  - **Mutations:** `v200-u42-half-first`, `-half-repeat`, `-wrong-half`, `-edge-apostrophe` and `-interior-apostrophe`.
    The focused block catches each one.
  - **Not covered:** whole grapheme clusters (an emoji joined from several, a letter with a combining mark, a flag) can still
    be split between their code points. That is well-formed text, not U+FFFD. Other sheet names: the workbook writer's own
    31-unit cut (`buildXlsx`) and the Priority drill's "PMO " sheets (cut at 31) are unchanged; no funds-flow name reaches
    31. The slide deck's 56-unit cut of a requirement title can still split an emoji (found by the registry-text track; not
    a sheet name). A sheet named "History", which Excel reserves, is not prevented. Excel itself was not run.
